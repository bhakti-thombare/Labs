import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedService } from './../../shared/shared.service';
import { ToastService } from '../../shared/toast.service';

@Component({
  selector: 'app-statutary-matrices',
  templateUrl: './statutary-matrices.component.html',
  styleUrls: ['./statutary-matrices.component.scss']
})
export class StatutaryMatricesComponent implements OnInit {
  selectedTabIndex = 0;
  hasFilteredData: any = {};

  billAmountMatrixData: any = [];
  totalBillAmountMatrix!: any;
  filterBillAmountMatrixColumField: any  = [
    { field: 'buCode', header: 'BU Code' },
  ];

  bonusMatrixData: any = [];
  totalBonusMatrix!: any;
  filterBonusMatrixColumField: any  = [
    { field: 'buCode', header: 'BU Code' },
  ];

  CESSMatrixData: any = [];
  totalCESSMatrix!: any;
  filterCESSMatrixColumField: any  = [
    { field: 'buCode', header: 'BU Code' },
  ];

  ESICMatrixData: any = [];
  totalESICMatrix!: any;
  filterESICMatrixColumField: any  = [
    { field: 'buCode', header: 'BU Code' },
  ];

  LeavesMatrixData: any = [];
  totalLeavesMatrix!: any;
  filterLeavesMatrixColumField: any  = [
    { field: 'buCode', header: 'BU Code' },
  ];

  PFMatrixData: any = [];
  totalPFMatrix!: any;
  filterPFMatrixColumField: any  = [
    { field: 'buCode', header: 'BU Code' },
  ];



  billAmountMatrixCols: any = [];
  bonusMatrixCols: any =[];
  CESSMatrixCols: any =[];
  ESICMatrixCols: any =[];
  LeavesMatrixCols: any =[];
  PFMatrixCols: any =[];

  pageNo: number = 0;
  pageSize: number = 5;

  editFlag = false;
  changeTitleAddViewEdit: string = 'Add';

  vendorForm!: FormGroup;
  submitted = false;

  constructor(private _shared: SharedService, private toast: ToastService,private fb: FormBuilder) {
    this._shared.sendpageTitle('STATUTORY MATRICES');
    this.vendorForm = this.fb.group({
      
        
       VendorName: ['', [Validators.required, Validators.maxLength(150)]],
    })
   }

  ngOnInit() {
    this.getUnitColumns();
    this.getBillAmountMatrixData(this.pageNo, this.pageSize);
  }

  get formControl() {
    return this.vendorForm.controls;
  }

  getBillAmountMatrixData(pageNo: number, pageSize: number) {
    let obj = {
      pageNumber: pageNo,
      pageSize: pageSize,
      departmentCode: sessionStorage.getItem('departmentCode'),
      positionCode: sessionStorage.getItem('positionCode'),
      sectionCode: sessionStorage.getItem('sectionCode'),
      unit: sessionStorage.getItem('unit'),
      status: "Disputed"
    }

    this._shared.post('Invoice/GetBillApprovalInvoices', obj, 'admin').subscribe(res => {
      // this.loader = false;
      this.billAmountMatrixData = res.item2;
      this.totalBillAmountMatrix = res.item1;
    });
  }

  edit(data: any, status: any) {
    if (status == 'edit') {
      this.changeTitleAddViewEdit = 'Edit';
      this.selectedTabIndex =6 ;
      this.editFlag = true;
      // this.vendorForm.value.VendorID = data.VendorID;
    } else if (status == 'view') {
      this.selectedTabIndex = 6;
      this.changeTitleAddViewEdit = 'View';
      this.editFlag = false;
    }else{

    }

    // this.vendorForm.patchValue({
     
    //   VendorName: data.VendorName,
    //   isActive: data.isActive, 
    // })
  }

  onPageChange(event:any){
    if (Object.keys(this.hasFilteredData).length != 0) {
      this.hasFilteredData.pageNo = event.page;
      this.hasFilteredData.pageSize = event.rows;
      this.pageSize = event.rows;
      // this._shared.post('User/SearchUsers', this.hasFilteredData, 'admin').subscribe(res => {
      //   this.loader = false;
      //   this.vendorsData = res.item2;
      //   this.totalVendors = res.item1;
      // });
    } else {
      this.pageSize = event.rows;
      this.pageNo = event.page;
      // this.getBusinessUnitsData(event.page, event.rows);
    }
  }

  getUnitColumns() {
    this.billAmountMatrixCols = [
      
      { field: 'buCode', header: 'BU Code' },
      { field: 'Section', header: 'Section' },
      { field: 'Department', header: 'Department' },
      { field: 'Function', header: 'Function' },
      { field: 'Unit', header: 'Unit' },
      { field: 'isActive', header: 'Status' },
      { field: 'Action', header: 'Action' },
     
    ];

    this.bonusMatrixCols = [
      
      { field: 'buCode', header: 'BU Code' },
      { field: 'MinWorkingDays', header: 'Minimum Working Days' },
      { field: 'BonusRate', header: 'Bonus Rate' },
      { field: 'BonusAmount', header: 'Bonus Amount' },
      { field: 'ExGratiaRate', header: 'Ex Gratia Rate' },
      { field: 'ExGratiaAmount', header: 'Ex Gratia Amount' },
      { field: 'Action', header: 'Action' },
     
    ];

    this.CESSMatrixCols = [
      
      { field: 'buCode', header: 'BU Code' },
      { field: 'EmployeeCESSRate', header: 'Employee CESS Rate' },
      { field: 'EmployerCESSRate', header: 'Employer CESS Rate' },
      { field: 'Action', header: 'Action' },
     
    ];

    this.ESICMatrixCols = [
      { field: 'buCode', header: 'BU Code' },
      { field: 'EmployeeESICRate', header: 'Employee ESIC Rate' },
      { field: 'EmployerESICRate', header: 'Employer ESIC Rate' },
      { field: 'Action', header: 'Action' },
    ];

    this.LeavesMatrixCols = [
      { field: 'buCode', header: 'BU Code' },
      { field: 'MinWorkingDays', header: 'Minimum Working Days' },
      { field: 'WorkingDaysPerLeave', header: 'Working Days Per Leave' },
      { field: 'Action', header: 'Action' },
    ];

    this.PFMatrixCols = [
      { field: 'buCode', header: 'BU Code' },
      { field: 'EmployeePFRate', header: 'Employee PF Rate' },
      { field: 'EmployerPFRate', header: 'Employer PF Rate' },
      { field: 'CapAmount', header: 'Cap Amount' },
      { field: 'Action', header: 'Action' },
    ];
  }

  filterData(evntData:any){
  
    
    // evntData.pageSize = this.pageSize;
    // evntData.pageNo = this.pageNo;

    // let obj = {
    //   pageNumber: this.pageNo,
    //   pageSize: this.pageSize,
    //   searchCriteria: evntData.searchCriteria,
    //   value: evntData.value
    // }

    // let obj1 = {
    //   departmentCode: sessionStorage.getItem('departmentCode'),
    //   pageNumber: this.pageNo,
    //   pageSize: this.pageSize,
    //   positionCode: sessionStorage.getItem('positionCode'),
    //   sectionCode: sessionStorage.getItem('sectionCode'),
    //   status: "Disputed",
    //   unit: sessionStorage.getItem('unit'),
    // }

    // const formData = new FormData();
    // formData.append('searchPageDTO', JSON.stringify(obj));
    // formData.append('invBvrSearchDTO', JSON.stringify(obj1));

    // this._shared.post('Invoice/SearchBillApprovalInvoices', formData, 'admin').subscribe(res => {
    //   this.loader = false;
    //   this.billAmountMatrixData = res.item2;
      this.hasFilteredData = evntData;
    // });
  }

  refresh(event:any){
    if(event){
      // this.getBusinessUnitsData(this.pageNo, this.pageSize);
      this.hasFilteredData = {};
    }
  }

  tabChange(e: any) {
    this.editFlag = true;
    this.changeTitleAddViewEdit = 'Add';
    // this.vendorForm.reset();
    // this.vendorForm.patchValue({ 'isActive': true });
    let index = e.index;
    if (index == 0) {
      this.selectedTabIndex = 0;
      // this.getBusinessUnitsData(this.pageNo, this.pageSize);
    }
  }

  open(content: any, flag:any) {
    if (flag == 'Add') {
      this.vendorForm.value.isActive = this.vendorForm.value.isActive ? true : false,
      this.vendorForm.value.createdBy = sessionStorage.getItem('username');
      // this._shared.post('businessunit/CreateBusinessUnit', this.vendorForm.value,'admin').subscribe(res=>{
      //   this.toast.show("Records saved successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.getBillAmountMatrixData(this.pageNo, this.pageSize);
        this.selectedTabIndex = 6;
        // this.vendorForm.reset();
      // })
    } else{
      //this.vendorForm.value.buid = data.buid;
      this.vendorForm.value.isActive = this.vendorForm.value.isActive ? true : false,
      this.vendorForm.value.modifiedBy = sessionStorage.getItem('username');
      // this._shared.put('businessunit/UpdateBusinessUnit', this.vendorForm.value, 'admin').subscribe(res => {
      //   this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      //   // this.loader = false;
        this.getBillAmountMatrixData(this.pageNo, this.pageSize);
        this.selectedTabIndex = 6;
        this.changeTitleAddViewEdit = 'Add';
      // });
    }
  }

}
