import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { BehaviorSubject,Subscription } from 'rxjs';
import { SharedService } from './../../shared/shared.service';
import { ExcelService } from '../../shared/excel.service';
import * as JSPDF from 'jspdf';
import 'jspdf-autotable';
import { ToastService } from '../../shared/toast.service';

@Component({
  selector: 'app-companies',
  templateUrl: './companies.component.html',
  styleUrls: ['./companies.component.scss']
})
export class CompaniesComponent implements OnInit {
showMe:boolean = false;
  cols: any = [];
  closeResult = '';
  companyForm!: FormGroup;
  companyData: any = [];
  submitted = false;
  pageNo: number = 0;
  pageSize: number = 5;
  loader: boolean = true;
  totalCompany!:any;
  
  businessVerticalForm:FormGroup;
  BVDropdown : any =[];
  BVDropdown1 : any =[];
  getUserDropdownData:any = [];
  selectedItems:any = [];
  dropdownSettings = {};
  roles!: any[];
  tableDrop1:any = [];
  countryDropdown:any =[];
  StateDropdown:any=[];
  cityDropdown:any =[];
  bvData:any ={};
  subscription!:Subscription;
  subscription1!:Subscription;
  editFlag = false;
  changeTitleAddViewEdit:string = 'Add';
  selectedTabIndex = 0;
  showBVScreen = true;
  compDropdown: any = [];
  hasFilteredData: any = {};
  country:any[] = [ ]
  state: any[] = [ ]
  city: any[] = [ ]

  filterColumField: any  = [
    { field: 'companyName', header: 'Company Name' },
    { field: 'companyCode', header: 'Company Code' },
  ];
 

  constructor(private modalService: NgbModal, private fb: FormBuilder, private _shared: SharedService, 
    private excelService: ExcelService, private toast: ToastService) {
    this.companyForm = this.fb.group({
      companyId: [''],
      companyCode: ['', [Validators.required, Validators.maxLength(18),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      companyName: ['', [Validators.required, Validators.maxLength(150),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      companyHead: ['', [Validators.required, Validators.maxLength(120)]],
      addressLine1: ['', [Validators.required, Validators.maxLength(150),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      addressLine2: [''],
      addressLine3: [''],
      city: ['', Validators.required],
      state: ['', Validators.required],
      country: ['', Validators.required],
      pinCode: ['', [Validators.required, Validators.maxLength(10),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      TANNumber: ['', [Validators.required, Validators.maxLength(10),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      TINNumber: ['', [Validators.required, Validators.maxLength(12),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      PANNumber: ['', [Validators.required, Validators.maxLength(10),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      GSTINNumber: ['', [Validators.required, Validators.maxLength(16),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      isActive: ['true'],
    })

    this.businessVerticalForm = this.fb.group({
      bvCode: ['', [Validators.required, Validators.maxLength(18),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      companyCode: ['', [Validators.required, Validators.maxLength(18)]],
      bvName: ['', [Validators.required, Validators.maxLength(150),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/) ]],
      bvHead: ['', [Validators.required, Validators.maxLength(120)]],
      isActive: ['false'],   
    })
  }

  ngOnInit() {
    
    // this.getCityDropdownList(0,100);
    this.getCompanyColumns();
    this.getCompanyData(this.pageNo, this.pageSize);
    this.getHeadsDropdownList(0,100);
    this.getUserDropdownList();
    this.getCompDropdownList(0,100);
    // this.getBVDropdownList1(0,100);
    this.getCountryList(this.pageNo, this.pageSize);

    this.dropdownSettings = {
      enableSearchFilter: true,
      addNewItemOnFilter: true,
      singleSelection: true, 
      text: "Select User Id",
      primaryKey: "id",
      labelKey: "userId",
      searchBy: ['userId']
    };
  }

  avoidSpecialChar(event:any)
  {   
     var k;  
     k = event.charCode;  //         k = event.keyCode;  (Both can be used)
     return((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57)); 
  }


  get formControl() {
    return this.companyForm.controls;
  }

  get formBVControl() {
    return this.businessVerticalForm.controls;
  }

  ngAfterViewInit(){
    this._shared.sendpageTitle('COMPANIES');
  }

  getCompanyColumns() {
    this.cols = [
      { field: 'Action', header: 'Action' },
      { field: 'companyCode', header: 'Company Code' },
      { field: 'companyName', header: 'Company Name' },
      { field: 'companyHead', header: 'Company Head' },
      { field: 'isActive', header: 'Status' },

    ];
  }

  getCountryList(pageNo:number, pageSize:number){
    let obj={
      pageNo:pageNo,
      pageSize:pageSize
    } 
    this._shared.post('Country/GetCountryList',obj,'admin').subscribe(res => {
      this.country = res;
    });
  }

  changeCountry(e:any, pageNo:number, pageSize:number){
    let obj = {
      pageNo: pageNo,
      pageSize: pageSize,
      countryCode: this.companyForm.value.country
    }
    this._shared.post('State/GetStateList',obj,'admin').subscribe(res => {
      let state = res.filter((itm:any) => itm.countryCode == e.target.value);
      this.state = state;
    });
  }

  changeState(e: any,pageNo:number, pageSize:number) {
    let obj = {
      pageNo: pageNo,
      pageSize: pageSize,
    countryCode: this.companyForm.value.country,
    stateCode: this.companyForm.value.state
    }
    this._shared.post('City/GetCityList',obj, 'admin').subscribe(res => {
      let city = res.filter((itm: any) => itm.stateCode == e.target.value);
      this.city = city;
    });
  }

  // getCityDropdownList(pageNo:number, pageSize:number){
  //   let obj = {
  //     pageNo: pageNo,
  //     pageSize: pageSize
  //   }
  //   this._shared.post('City/GetCities', obj, 'admin').subscribe(res => {
  //     this.loader = false;
  //     this.cityDropdown = res.item2;
  //   });
  // }

  //create BV  by clicking on icon
  createBV(data: any, status: any){
    this.showMe = !this.showMe
    this.selectedTabIndex = 2;
    this._shared.post('BusinessVertical/GetBVbyId', {StringID: data.bvid}, 'admin').subscribe(res => {
      this.bvData = res[0];
      this.businessVerticalForm.patchValue({
        bvid: this.bvData != undefined ? this.bvData.bvid  : data.bvid,
        bvCode:this.bvData != undefined ? this.bvData.bvcode  : data.bvcode,
        companyCode:this.bvData != undefined ? this.bvData.companyCode  : data.companyCode,
        bvName:this.bvData != undefined ? this.bvData.bvname  : data.bvname,
        bvHead:this.bvData != undefined ? this.bvData.bvHead[0].userId  : data.bvHead,
        isActive: this.bvData != undefined ? this.bvData.isActive : false
      })
     });
  }

  createNupdateBV(data:any) {
    if (this.bvData ==undefined){
      this.businessVerticalForm.value.bvcode= this.businessVerticalForm.value.bvcode,
      this.businessVerticalForm.value.bvname= this.businessVerticalForm.value.bvname,
      this.businessVerticalForm.value.bvHead= this.businessVerticalForm.value.bvHead[0].userId,
      this.businessVerticalForm.value.isActive = this.businessVerticalForm.value.isActive ? true : false,
      this.businessVerticalForm.value.createdBy = sessionStorage.getItem('username');
      this.businessVerticalForm.value.modifiedBy = sessionStorage.getItem('username');
      this._shared.post('BusinessVertical/CreateBusinessVertical', this.businessVerticalForm.value, 'admin').subscribe(res => {
        this.toast.show("BV assigned successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.businessVerticalForm.reset();
        this.getCompanyData(this.pageNo, this.pageSize);
        this.selectedTabIndex = 0;
      });
    }else {
      this.businessVerticalForm.value.isActive = this.businessVerticalForm.value.isActive ? true : false;
      this.businessVerticalForm.value.modifiedBy = sessionStorage.getItem('username');
      this._shared.put('BusinessVertical/UpdateBusinessVertical', this.businessVerticalForm.value, 'admin').subscribe(res => {
        this.toast.show("Role updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.bvData = {};
        this.getCompanyData(this.pageNo, this.pageSize);
        this.selectedTabIndex = 0;
      });
    }
  }

  //search data from dropdown
  onSearch(evt: any) {
    if (evt.target.value == ""){
      this.getCompDropdownList(0,100);
    } else {
      console.log(evt.target.value);
      this.getUserDropdownData= [];
      let obj = { "searchcriteria": "user", "value": `${evt.target.value}` }
      this._shared.post('User/GetUsersListByCriteria', obj, 'admin').subscribe(res => {
        this.loader = false;
        this.getUserDropdownData = res;
      });
    }
  }

  //BV Head Dropdown form field
  getUserDropdownList(){
    this._shared.post('User/GetUsersListByCriteria', {}, 'admin').subscribe(res => {
      this.loader = false;
      this.getUserDropdownData = res;

    });
  } 

  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  OnItemDeSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  onDeSelectAll(items: any) {
    console.log(items);
  }


  getCompDropdownList(pageNo:number, pageSize:number){
    let obj = {
      pageNo: pageNo,
      pageSize: pageSize
    }
    this._shared.post('Company/GetCompanies', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.BVDropdown = res.item2;
    });
  }

  //user heads dropdown list 
  getHeadsDropdownList(pageNo:number, pageSize:number){
    let obj = {
      pageNo: pageNo,
      pageSize: pageSize
    }
  
    this._shared.post('User/GetUsersListByCriteria', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.compDropdown = res;
    });
    
  }

  //show company data in table
  getCompanyData(pageNo:number, pageSize:number){
    let obj = {
      pageNo: pageNo,
      pageSize: pageSize
    }
    this._shared.post('Company/GetCompanies', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.companyData = res.item2;
      this.totalCompany = res.item1;
    });
  }


//save company data
  saveModal(content: any,flag:any) {
    if(flag == 'Add'){
      this.companyForm.value.isActive = this.companyForm.value.isActive ? true : false,
      this.companyForm.value.city =  this.companyForm.value.city,
      this.companyForm.value.stateCode =  this.companyForm.value.state,
      this.companyForm.value.countryCode =  this.companyForm.value.country,
      this.companyForm.value.createdBy = sessionStorage.getItem('username');

      this._shared.post('Company/CreateCompany', this.companyForm.value ,'admin').subscribe(res=>{
      this.toast.show("Records saved successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      this.getCompanyData(this.pageNo, this.pageSize);
      this.selectedTabIndex = 0;
      this.companyForm.reset();
    })
    }else{
    this.companyForm.value.city =  this.companyForm.value.city,
      // this.companyForm.value.districtid = this.companyForm.value.district,
      this.companyForm.value.state =  this.companyForm.value.state,
      this.companyForm.value.country = this.companyForm.value.country,
      this.companyForm.value.modifiedBy = sessionStorage.getItem('username');
    this._shared.put('Company/UpdateCompany', this.companyForm.value, 'admin').subscribe(res => {
      this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      this.loader = false;
      this.getCompanyData(this.pageNo, this.pageSize);
      this.selectedTabIndex = 0;
      this.changeTitleAddViewEdit = 'Add';
    });
    }  
  }

  edit(data:any, status:any) {
    if(status == 'edit'){
      this.changeTitleAddViewEdit = 'Edit';
      this.selectedTabIndex = 1;
      this.editFlag = true;
      this.companyForm.value.companyId = data.companyId;
      
    }else if(status == 'view'){
      this.selectedTabIndex = 1;
      this.changeTitleAddViewEdit = 'View';
      this.editFlag = false;
    }else{}
      this.companyForm.patchValue({
        companyId:data.companyId,
        companyCode: data.companyCode ,
        companyName: data.companyName,
        companyHead: data.companyHead,
        addressLine1: data.addressLine1,
        addressLine2: data.addressLine2,
        addressLine3: data.addressLine3,
        city: data.cityId,
        state: data.stateId,
        country: data.countryId,
        pinCode: data.pinCode,
        TANNumber: data.tannumber,
        TINNumber: data.tinnumber,
        PANNumber: data.pannumber,
        GSTINNumber: data.gstinnumber,
        isActive: data.isActive,
        createdOn: data.created,  
        createdBy: data.createdBy,
        modifiedOn: data.modified,
        modifiedBy: data.modifiedBy,   
    })
  }


  //to filter table data
  filterData(event:any){
    event.pageSize = this.pageSize;
    event.pageNo = this.pageNo;
    console.log(event);
    this._shared.post('Company/SearchCompanies',event,'admin').subscribe(res=>{
      this.loader = false;
      this.companyData = res.item2;
      this.hasFilteredData = event;
      this.totalCompany = res.item1;
    });
  }

  //to clear search field
  refresh(event:any){
    if(event){
      this.getCompanyData(this.pageNo, this.pageSize);
      this.hasFilteredData={};
    }
  }

  //pagination
  onPageChange(event:any){
    if (Object.keys(this.hasFilteredData).length !=0){
      this.hasFilteredData.pageNo = event.page;
      this.hasFilteredData.pageSize = event.rows;
      this.pageSize = event.rows;
      this._shared.post('Company/SearchCompanies', this.hasFilteredData , 'admin').subscribe(res => {
        this.loader = false;
        this.companyData = res.item2;
        this.totalCompany = res.item1;
      });
    } else {
      this.pageSize = event.rows;
      this.pageNo = event.page;
      this.getCompanyData(event.page, event.rows);
    }
  }

  //change tab value on click
  tabChange(e:any){
    this.editFlag = true;
    this.changeTitleAddViewEdit = 'Add';
    this.companyForm.reset();
    this.companyForm.patchValue({'isActive':true});
    let index = e.index;
    if(index ==0){
      this.selectedTabIndex = 0;
      this.getCompanyData(this.pageNo, this.pageSize);
      this.showMe = false
    }
  }

  //to create and download excel
  exportAsXLSX() {
    if (this.companyData.length > 0) {
      this.excelService.exportAsExcelFile(this.companyData, 'sample');
    }
  }

  //to create and download pdf
  createPdf() {
    // debugger;
    let head:any = [[]];
    let data:any = [[]];
    this.companyData.forEach((res:any, index:any) => {
      if (index == 0) {
        for (let obj in res) { 
          if(head[index].length<=8){
            head[0].push(obj);
            data[index].push(res[obj]); 
          }
        }
      } else {
        data.push([])
        for (let obj in res) {
          if (data[index].length <= 8) {
            data[index].push(res[obj])
          }
        }
      }
    })
  
    let doc = new JSPDF.jsPDF("l", "in"); 

    doc.setFontSize(9);
    doc.text('', 11, 8);
    doc.setFontSize(9);
    doc.setTextColor(100);


    (doc as any).autoTable({
      head: head,
      body: data,
      theme: 'plain',
      didDrawCell: (data:any) => {
        console.log(data.column.index)
      }
    })

    // Open PDF document in new tab
    doc.output('dataurlnewwindow')

    // Download PDF document  
    doc.save('table.pdf');
  }

  ngOnDestroy(){
 /*this.subscription.unsubscribe();
     this.subscription1.unsubscribe();*/
  }

}


<app-loader></app-loader>

<p-tabView [(activeIndex)]="selectedTabIndex" (onChange)="tabChange($event)">
  <p-tabPanel class="tab" header="List" [selected]="true">
    <div class="companyWrapper shadow-sm">
      
      <div class="align-items-center d-flex mb-2 m-0 row">
        <div class="col-12 col-sm-5 ps-0 text-center text-sm-start"> </div>
        
        <div class="col-12 col-sm-2 pe-2 text-end" style="font-size: 24px;">
          <!-- <span><i placement="bottom" ngbTooltip="Download PDF" (click)="createPdf()"
              class="border-end cursor fa-file-pdf fas pe-3" style="color:#c70a29;"></i></span> -->
          <span><i placement="bottom" ngbTooltip="Download Excel" (click)="exportAsXLSX()"
              class="border-end border-dark cursor fa-file-excel fas pe-3" style="color:#07af07;"></i></span>
        </div>

        <div class="col-12 col-sm-5 px-1">
          <app-filter (reload)="refresh($event)" (filter)="filterData($event)" [dropdownFilterItems]="filterColumField">
          </app-filter>
        </div>
      </div>


    <p-table [value]="companyData" [columns]="cols" [paginator]="false" [rows]="5" responsiveLayout="scroll"
      [showCurrentPageReport]="true" currentPageReportTemplate="Total entries : {{totalCompany}}" 
      [responsive]="true" [autoLayout]="true" [rowsPerPageOptions]="[5, 10,50, 100]">

      <ng-template pTemplate="header">
        <tr>
          <th class="tableHeader" *ngFor="let col of cols" [pSortableColumn]="col.field">
            {{ col.header }}
            <p-sortIcon *ngIf="col.header != 'Action'" [field]="col.field"></p-sortIcon>
          </th>
        </tr>
      </ng-template>
        
      <ng-template pTemplate="body" let-rowdata let-columns="columns">
        <tr>
          <td style="width: 20%;">
            <i placement="bottom" ngbTooltip="Edit" class="fas fa-edit cursor pe-3" (click)="edit(rowdata, 'edit')"></i>
            <i placement="bottom" ngbTooltip="View" class="fa fa-eye cursor pe-3" (click)="edit(rowdata, 'view')"></i>
            <i placement="bottom" ngbTooltip="Create BV" class="fas fa-user-tag cursor pe-3" (click)="createBV(rowdata, 'bv')"></i>
          </td>
          <td style="width: 20%;"> {{ rowdata.companyCode }}</td>
          <td style="width: 20%;">{{ rowdata.companyName }}</td>
          <td style="width: 20%;">{{ rowdata.companyHead }}</td>
          <td style="width: 20%;">{{ rowdata.isActive ? 'Active' : 'Inactive' }}</td>

        </tr>
      </ng-template>
        
      <ng-template pTemplate="emptymessage" let-columns>
        <tr>
          <td [attr.colspan]="columns.length+2">
            <div class="py-3 text-center textColor">No records found</div>
          </td>
        </tr>
      </ng-template>
    </p-table>
    
      <div style="position:relative;" class="align-items-center d-flex justify-content-between">
        <span class="ps-2 textColor">Showing : <strong class="textColor">{{companyData.length}}</strong> entries </span>
          <p-paginator *ngIf="companyData" [rows]="5" [totalRecords]="totalCompany"
            [rowsPerPageOptions]="[5, 10, 50, 100]" (onPageChange)="onPageChange($event)">
          </p-paginator>
        <span class="pe-2 textColor">Total records : <strong class="textColor">{{totalCompany}}</strong> </span>
      </div>
     </div>
  </p-tabPanel>

  <p-tabPanel header="{{changeTitleAddViewEdit}}">
    <form [formGroup]="companyForm" (ngSubmit)="saveModal(companyForm,changeTitleAddViewEdit)">
      <div class="row">

        <div class="form-group col-12 col-sm-4 padTopZero">
          <label for="companyName">Company Name<span class="mandatoryField">*</span>
          </label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-building"></i></span>
            <input [readonly]="editFlag==false" type="text" formControlName="companyName" placeholder="Company Name"
              name="companyName" id="companyName" [ngClass]="{ 'is-invalid': submitted }" class="form-control" (keypress)="avoidSpecialChar($event)">
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.companyName.invalid  && formControl.companyName.errors && (formControl.companyName.dirty || formControl.companyName.touched)">
              <div *ngIf="formControl.companyName.errors.required">Company Name is required</div>
              <div *ngIf="formControl.companyName.errors.pattern">Please enter valid company name(Blank space not allowed)</div>
              <div *ngIf="formControl.companyName.errors.maxlength">Company Name can be max 150 characters long.</div>
            </div>
          </div>
        </div>

        <div class="form-group col-12 col-sm-4 padTopZero">
          <label for="companyCode">Company Code<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1">
              <i class="fas fa-building"></i>
            </span>
            <input [readonly]="editFlag==false" type="text" formControlName="companyCode" id="companyCode"
              placeholder="Company Code" name="companyCode" [ngClass]="{ 'is-invalid': submitted  }"
              class="form-control" (keypress)="avoidSpecialChar($event)">
            <div class="p-0 invalid-feedback" *ngIf="formControl.companyCode.invalid && formControl.companyCode.errors && (formControl.companyCode.dirty ||
            formControl.companyCode.touched)">
              <div *ngIf="formControl.companyCode.errors.required">Company Code is required</div>
              <div *ngIf="formControl.companyCode.errors.pattern">Please enter valid company code(Blank space not allowed)</div>
              <div *ngIf="formControl.companyCode.errors.maxlength">Company Codecan be max 100 characters long.</div>
            </div>
          </div>
        </div>

        <div class="form-group col-12 col-sm-4 padTopZero">
          <label for="companyHead">Company Head<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-globe"></i></span>
            <select [attr.disabled]="editFlag==false ? true : null" id="companyHead" formControlName="companyHead"
              name="companyHead" [ngClass]="{ 'is-invalid': submitted }" class="form-control form-select" cursor>
              <option [ngValue]="" disabled selected>Select Company Head</option>
              <option value="{{item.userId}}" *ngFor="let item of compDropdown">{{item.userId}}
              </option>
            </select>
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.companyHead.invalid  && formControl.companyHead.errors && (formControl.companyHead.dirty || formControl.companyHead.touched)">
              <div *ngIf="formControl.companyHead.errors.required">Company Head is required</div>
              <div *ngIf="formControl.companyHead.errors.maxlength">Company Head can be max 120 characters long.</div>
            </div>
          </div>
        </div>

        <div class="form-group  col-12 col-sm-4 ">
          <label for="addressLine1">Address Line1<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-map-marker-alt"></i></span>
            <input [readonly]="editFlag==false" type="text" formControlName="addressLine1" placeholder="Address Line1"
              name="addressLine1" id="addressLine1" [ngClass]="{ 'is-invalid': submitted  }" class="form-control">
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.addressLine1.invalid && formControl.addressLine1.errors && (formControl.addressLine1.dirty || formControl.addressLine1.touched)">
              <div *ngIf="formControl.addressLine1.errors.required">Address is required</div>
              <div *ngIf="formControl.addressLine1.errors.pattern">Please enter valid Address(Blank space not allowed)</div>
              <div *ngIf="formControl.addressLine1.errors.maxlength">Address can be max 150 characters long.</div>
            </div>
          </div>
        </div>

        <div class="form-group  col-12 col-sm-4">
          <label for="addressLine2">Address Line2</label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-map-marker-alt"></i></span>
            <input [readonly]="editFlag==false" type="text" formControlName="addressLine2" id="addressLine2"
              placeholder="Address Line2" name="addressLine2" class="form-control">
          </div>
        </div>

        <div class="form-group  col-12 col-sm-4 ">
          <label for="addressLine3">Address Line3</label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-map-marker-alt"></i></span>
            <input [readonly]="editFlag==false" type="text" formControlName="addressLine3" id="addressLine3"
              placeholder="Address Line3" name="addressLine3" class="form-control">
          </div>
        </div>

        <div class="form-group  col-12 col-sm-4 ">
          <label for="country">Country<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-flag"></i></span>
            <select (change)="changeCountry($event,0,10)" [attr.disabled]="editFlag==false ? true : null" id="country"
              formControlName="country" name="country"
              [ngClass]="{ 'is-invalid': submitted && formControl.country.errors }"
              class="form-control form-select cursor">
              <option [ngValue]="null" disabled selected>Select Country</option>
              <option value="{{c.countryCode}}" *ngFor="let c of country">{{c.countryName}}
              </option>
            </select>
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.country.invalid && (formControl.country.dirty || formControl.country.touched)">
              <div *ngIf="formControl.country.invalid">Country is required</div>
            </div>
          </div>
        </div>

        <div class="form-group  col-12 col-sm-4 ">
          <label for="state">State<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-crosshairs"></i></span>
            <select (change)="changeState($event,0,10)" [attr.disabled]="editFlag==false ? true : null" id="state"
              formControlName="state" name="state" [ngClass]="{ 'is-invalid': submitted  && formControl.state.errors }"
              class="form-control form-select cursor">
              <option [ngValue]="null" disabled selected>Select State</option>
              <option value="{{s.stateCode}}" *ngFor="let s of state">{{s.stateName}}
              </option>
            </select>
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.state.invalid && (formControl.state.dirty || formControl.state.touched)">
              <div *ngIf="formControl.state.invalid">State is required</div>
            </div>
          </div>
        </div>

        <div class="form-group  col-12 col-sm-4 ">
          <label for="city">City<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-crosshairs"></i></span>
            <select [attr.disabled]="editFlag==false ? true : null" id="city" formControlName="city" name="city"
              [ngClass]="{ 'is-invalid': submitted && formControl.city.errors }"
              class="form-control form-select cursor">
              <option [ngValue]="null" disabled selected>Select City </option>
              <option value="{{d.cityCode}}" *ngFor="let d of city">{{d.cityName}}
              </option>
            </select>
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.city.invalid && (formControl.city.dirty || formControl.city.touched)">
              <div *ngIf="formControl.city.invalid">City is required</div>
            </div>
          </div>
        </div>

        <div class="form-group  col-12 col-sm-4 ">
          <label for="pinCode">Pincode<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-crosshairs"></i></span>
            <input [readonly]="editFlag==false" type="text" formControlName="pinCode" id="pinCode" placeholder="pincode"
              name="pinCode" [ngClass]="{ 'is-invalid': submitted }" class="form-control" (keypress)="avoidSpecialChar($event)">
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.pinCode.invalid  && formControl.pinCode.errors && (formControl.pinCode.dirty || formControl.pinCode.touched)">
              <div *ngIf="formControl.pinCode.errors.required">Pincode is required</div>
              <div *ngIf="formControl.pinCode.errors.pattern">Please enter valid Pincode(Blank space not allowed)</div>
              <div *ngIf="formControl.pinCode.errors.maxlength">Pincode can be max 10 characters long.</div>
            </div>
          </div>
        </div>

        <div class="form-group  col-12 col-sm-4 ">
          <label for="TANNumber">TAN Number<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-crosshairs"></i></span>
            <input [readonly]="editFlag==false" type="text" formControlName="TANNumber" id="TANNumber"
              placeholder="TAN Number" name="TANNumber" [ngClass]="{ 'is-invalid': submitted}" class="form-control" (keypress)="avoidSpecialChar($event)">
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.TANNumber.invalid && formControl.TANNumber.errors  && (formControl.TANNumber.dirty || formControl.TANNumber.touched)">
              <div *ngIf="formControl.TANNumber.errors.required">TAN Number is required</div>
              <div *ngIf="formControl.TANNumber.errors.pattern">Please enter valid TAN Number(Blank space not allowed)</div>
              <div *ngIf="formControl.TANNumber.errors.maxlength">TAN Number can be max 10 characters long.</div>
            </div>
          </div>
        </div>

        <div class="form-group  col-12 col-sm-4 ">
          <label for="TINNumber">TIN Number<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-crosshairs"></i></span>
            <input [readonly]="editFlag==false" type="text" formControlName="TINNumber" id="TINNumber"
              placeholder="TIN Number" name="TINNumber" [ngClass]="{ 'is-invalid': submitted  }" class="form-control" (keypress)="avoidSpecialChar($event)">
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.TINNumber.invalid && formControl.TINNumber.errors && (formControl.TINNumber.dirty || formControl.TINNumber.touched)">
              <div *ngIf="formControl.TINNumber.errors.required">TIN Number is required</div>
              <div *ngIf="formControl.TINNumber.errors.pattern">Please enter valid TIN Number(Blank space not allowed)</div>
              <div *ngIf="formControl.TINNumber.errors.maxlength">TIN Number can be max 12 characters long.</div>
            </div>
          </div>
        </div>

        <div class="form-group  col-12 col-sm-4 ">
          <label for="PANNumber">PAN Number<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-crosshairs"></i></span>
            <input [readonly]="editFlag==false" type="text" formControlName="PANNumber" id="PANNumber"
              placeholder="PAN Number" name="PANNumber" [ngClass]="{ 'is-invalid': submitted  }" class="form-control" (keypress)="avoidSpecialChar($event)">
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.PANNumber.invalid && formControl.PANNumber.errors && (formControl.PANNumber.dirty || formControl.PANNumber.touched)">
              <div *ngIf="formControl.PANNumber.errors.required">PAN Number is required</div>
              <div *ngIf="formControl.PANNumber.errors.pattern">Please enter valid PAN Number(Blank space not allowed)</div>
              <div *ngIf="formControl.PANNumber.errors.maxlength">PAN Number can be max 10 characters long.</div>
            </div>
          </div>
        </div>

        <div class="form-group  col-12 col-sm-4 ">
          <label for="GSTINNumber">GSTIN Number<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-crosshairs"></i></span>
            <input [readonly]="editFlag==false" type="text" formControlName="GSTINNumber" id="GSTINNumber"
              placeholder="GSTIN Number" name="GSTINNumber" [ngClass]="{ 'is-invalid': submitted }"
              class="form-control" (keypress)="avoidSpecialChar($event)">
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.GSTINNumber.invalid  && formControl.GSTINNumber.errors && (formControl.GSTINNumber.dirty || formControl.GSTINNumber.touched)">
              <div *ngIf="formControl.GSTINNumber.errors.required">GSTIN Number is required</div>
              <div *ngIf="formControl.GSTINNumber.errors.pattern">Please enter valid GSTIN Number(Blank space not allowed)</div>
              <div *ngIf="formControl.GSTINNumber.errors.maxlength">GSTIN Number can be max 16 characters long.</div>
            </div>
          </div>
        </div>

        <div class="align-items-center col-12 col-sm-3 d-flex form-group">
          <div class="ms-3" style="margin-top: 20px;">
            <span for="status" class="pe-2">Active</span>
            <input [attr.disabled]="editFlag==false ? true : null" formControlName="isActive" class="form-check-input"
              type="checkbox" [ngClass]="{ 'is-invalid': submitted && formControl.isActive.errors }" value=""
              id="defaultCheck1">
          </div>
          <div class="p-0 invalid-feedback"
            *ngIf="formControl.isActive.invalid && (formControl.isActive.dirty || formControl.isActive.touched)">
            <div *ngIf="formControl.isActive.invalid">Status is required</div>
          </div>
        </div>
      </div>

      <button *ngIf="editFlag==true" type="submit" class="btn btnSuccess mt-3" [disabled]="!companyForm.valid">
        Save
      </button>
    </form>
  </p-tabPanel>

  <p-tabPanel *ngIf="showMe" header="Business Verticals">
    <form [formGroup]="businessVerticalForm" (ngSubmit)="createNupdateBV(businessVerticalForm)">
      <div class="row">

        <div class="form-group col-12 col-sm-5 padTopZero">
          <label for="companyCode">Company Name<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1">
              <i class="fas fa-building"></i></span>
            <select [attr.disabled]="true" id="companyCode" formControlName="companyCode" name="companyCode"
              [ngClass]="{ 'is-invalid': submitted }" class="form-control form-select" cursor>
              <option [ngValue]="" disabled selected>Select Company</option>
              <option value="{{item.companyCode}}" *ngFor="let item of BVDropdown">{{item.companyName}}
              </option>
            </select>
          </div>
        </div>

        <div class="form-group col-12 col-sm-3 padTopZero">
          <label for="bvCode">Business Vertical Code<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1">
              <i class="fas fa-layer-group"></i></span>
            <input type="text" formControlName="bvCode" placeholder="Business Vertical Code" name="bvCode" id="bvCode"
              [ngClass]="{ 'is-invalid': submitted }" class="form-control" (keypress)="avoidSpecialChar($event)">
            <div class="p-0 invalid-feedback"
              *ngIf="formBVControl.bvCode.invalid  && formBVControl.bvCode.errors && (formBVControl.bvCode.dirty || formBVControl.bvCode.touched)">
              <div *ngIf="formBVControl.bvCode.errors.required">Business Vertical Code is required</div>
              <div *ngIf="formBVControl.bvCode.errors.pattern">Please enter valid BV Code(Blank space not allowed)</div>
              <div *ngIf="formBVControl.bvCode.errors.maxlength">Business Vertical Code can be max 18 characters long.
              </div>
            </div>
          </div>
        </div>

        <div class="form-group col-12 col-sm-4 padTopZero ">
          <label for="bvName">Business Vertical Name<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1">
              <i class="fas fa-layer-group"></i>
            </span>
            <input type="text" formControlName="bvName" placeholder="Business Vertical Name" name="bvName" id="bvName"
              [ngClass]="{ 'is-invalid': submitted }" class="form-control" (keypress)="avoidSpecialChar($event)">
            <div class="p-0 invalid-feedback"
              *ngIf="formBVControl.bvName.invalid  && formBVControl.bvName.errors && (formBVControl.bvName.dirty || formBVControl.bvName.touched)">
              <div *ngIf="formBVControl.bvName.errors.required">Business Vertical Name is required</div>
              <div *ngIf="formBVControl.bvName.errors.pattern">Please enter valid BV Name(Blank space not allowed)</div>
              <div *ngIf="formBVControl.bvName.errors.maxlength">Business Vertical Name can be max 150 characters long.
              </div>
            </div>
          </div>
        </div>

        <div class="form-group col-12 col-sm-4 padTopZero">
          <label for="bvHead">Business Vertical Head<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <angular2-multiselect formControlName="bvHead" [data]="getUserDropdownData" [(ngModel)]="selectedItems"
              [settings]="dropdownSettings" (onSelect)="onItemSelect($event)" (onDeSelect)="OnItemDeSelect($event)"
              (onSelectAll)="onSelectAll($event)" (onDeSelectAll)="onDeSelectAll($event)" class="col-md-9">
              <c-search>
                <ng-template>
                    <input type="text" (keyup)="onSearch($event)" placeholder="Search User"
                      style="border: none;width: 100%; height: 100%;outline: none;" />
                </ng-template>
              </c-search>
              <ng-template let-item="item">
                <label>{{item.bvHead}}</label>
              </ng-template>
            </angular2-multiselect>
          </div>
        </div>

        <div class="align-items-center col-6 col-sm-4 d-flex form-group ">
          <div class="" style="margin-top: 20px;">
            <span for="status" class="pe-2">Active</span>
            <input formControlName="isActive" class="form-check-input" type="checkbox"
              [ngClass]="{ 'is-invalid': submitted && formBVControl.status.errors }" value="" id="defaultCheck1">
          </div>
          <div class="p-0 invalid-feedback"
            *ngIf="formBVControl.isActive.invalid && (formBVControl.isActive.dirty || formBVControl.isActive.touched)">
            <div *ngIf="formBVControl.isActive.invalid">Status is required</div>
          </div>
        </div>
      </div>

      <button type="submit" class="btn btnSuccess mt-3" [disabled]="!businessVerticalForm.valid">
        Save
      </button>
    </form>
  </p-tabPanel>
</p-tabView>
