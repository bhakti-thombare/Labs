import { Component, OnInit, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { BehaviorSubject, Subscription } from 'rxjs';
import { SharedService } from './../../shared/shared.service';
import { ExcelService } from '../../shared/excel.service';
import * as JSPDF from 'jspdf';
import 'jspdf-autotable';
import { ToastService } from '../../shared/toast.service';

@Component({
  selector: 'app-vendor-details',
  templateUrl: './vendor-details.component.html',
  styleUrls: ['./vendor-details.component.scss']
})
export class VendorDetailsComponent implements OnInit {
  dropdownSecSettings = {};
  dropdownStateSettings ={};
  dropdownCitySettings ={};
  cols: any = [];
  vendorForm!: FormGroup;
  vendorsData: any = [];
  submitted = false;
  pageNumber: number = 0;
  pageSize: number = 5;
  loader: boolean = true;
  totalVendors!:any;
  filterColumField: any  = [
    { field: 'vendorName', header: 'Vendor Name' },
    { field: 'vendorGroup', header: 'Vendor Group' },
  ];
  subscription!:Subscription;
  editFlag = false;
  country:any[] = []
  state: any[] = []
  city: any[] = [];

  changeTitleAddViewEdit: string = 'Add';
  selectedTabIndex = 0;
  hasFilteredData: any = {};

  BUDropdown : any =[];

  constructor( private renderer: Renderer2,private modalService: NgbModal, private fb: FormBuilder, private _shared: SharedService, 
    private excelService: ExcelService, private toast: ToastService) { 
      this._shared.sendpageTitle('VENDOR DETAILS');
      this.vendorForm = this.fb.group({
      
        bucode: ['', [Validators.required, Validators.maxLength(18),]],
        vendorSapcode:['',[Validators.required, Validators.maxLength(18),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        vendorSaccode:['',[Validators.required, Validators.maxLength(18),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        vendorName: ['', [Validators.required, Validators.maxLength(150),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        vendorGroup: ['', [Validators.required, Validators.maxLength(18),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        accountName: ['',  [Validators.required,Validators.maxLength(100),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        accountNumber: ['', [Validators.required,Validators.maxLength(20),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        bankName: ['', [Validators.required,Validators.maxLength(100),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        bankBranch: ['', [Validators.required,Validators.maxLength(50),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        ifsccode: ['', [Validators.required,Validators.maxLength(50),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        micrcode: ['', [Validators.required,Validators.maxLength(50),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        cinnumber: ['', [Validators.required,Validators.maxLength(18),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        tannumber: ['', [Validators.required,Validators.maxLength(10),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        tinnumber: ['', [Validators.required,Validators.maxLength(12),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        pannumber: ['',  [Validators.required,Validators.maxLength(50),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        gstinnumber: ['',[ Validators.required,Validators.maxLength(50),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        address1: ['', [Validators.required, Validators.maxLength(250),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
        address2: ['',Validators.maxLength(150)],
        address3: ['',Validators.maxLength(150)],
         city: [''],
         state: ['', Validators.required],
         country: ['', Validators.required],
         pinCode: ['', [Validators.required, Validators.maxLength(6),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$ ^[0-9]*$/)]],
         reverseCharge:['true'], 
         isActive: ['true'],
       })
    }

  ngOnInit() {
    this.getUnitColumns();
    this.getVendorsData(this.pageNumber, this.pageSize);
    this.getCountries(this.pageNumber, this.pageSize);

    this.getBUDropdownList(0,100);
    this.dropdownSecSettings = {
      enableSearchFilter: true,
      addNewItemOnFilter: false,
      singleSelection: true,
      text: "Select Country",
      primaryKey: "countryCode",
      labelKey: "countryName",
      searchBy: ['countryName'],
      lazyLoading: true,
      classes: "myclass custom-class",
      //autoPosition: false
    };
    this.dropdownStateSettings={
      enableSearchFilter: true,
      addNewItemOnFilter: false,
      singleSelection: true,
      text: "Select State",
      primaryKey: "stateCode",
      labelKey: "stateName",
      searchBy: ['stateName'],
      lazyLoading: true,
      classes: "myclass custom-class",
    };
    this.dropdownCitySettings={
      enableSearchFilter: true,
      addNewItemOnFilter: false,
      singleSelection: true,
      text: "Select City",
      primaryKey: "cityCode",
      labelKey: "cityName",
      searchBy: ['cityName'],
      lazyLoading: true,
      classes: "myclass custom-class",
    };
  }

  onCitySelect(event:any){
    this.renderer.removeStyle(this.getElementDropdown(), 'display');
  
  }
  private getElementDropdown(): HTMLElement {
    return document.getElementsByClassName("dropdown-list")[0] as HTMLElement;
  }


  checkSpecialCharInName = true;
  avoidSpecialCharInName(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    // if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      if (charCode > 31 && (charCode <= 57 || charCode > 57 ) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
     
    this.checkSpecialCharInName = false;
      return this.checkSpecialCharInName;
    } else {
      this.checkSpecialCharInName = true;
      return this.checkSpecialCharInName;
    }
  }

  checkSpecialCharInSAP = true;
  avoidSpecialCharInSAP(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInSAP = false;
      return this.checkSpecialCharInSAP;
    } else {
      this.checkSpecialCharInSAP = true;
      return this.checkSpecialCharInSAP;
    }
  }

  checkSpecialCharInSAC = true;
  avoidSpecialCharInSAC(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInSAC = false;
      return this.checkSpecialCharInSAC;
    } else {
      this.checkSpecialCharInSAC = true;
      return this.checkSpecialCharInSAC;
    }
  }

  checkSpecialCharInGrp = true;
  avoidSpecialCharInGrp(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInGrp = false;
      return this.checkSpecialCharInGrp;
    } else {
      this.checkSpecialCharInGrp = true;
      return this.checkSpecialCharInGrp;
    }
  }

  checkSpecialCharInAccName = true;
  avoidSpecialCharInAccName(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    // if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      if (charCode > 31 && (charCode <= 57 || charCode > 57 ) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
     
    this.checkSpecialCharInAccName = false;
      return this.checkSpecialCharInAccName;
    } else {
      this.checkSpecialCharInAccName = true;
      return this.checkSpecialCharInAccName;
    }
  }

  checkSpecialCharInAccNum = true;
  avoidSpecialCharInAccNum(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInAccNum = false;
      return this.checkSpecialCharInAccNum;
    } else {
      this.checkSpecialCharInAccNum = true;
      return this.checkSpecialCharInAccNum;
    }
  }

  checkSpecialCharInBankName = true;
  avoidSpecialCharInBankName(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    // if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      if (charCode > 31 && (charCode <= 57 || charCode > 57 ) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
       
    this.checkSpecialCharInBankName = false;
      return this.checkSpecialCharInBankName;
    } else {
      this.checkSpecialCharInBankName = true;
      return this.checkSpecialCharInBankName;
    }
  }

  checkSpecialCharInBankBranch = true;
  avoidSpecialCharBankBranch(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInBankBranch = false;
      return this.checkSpecialCharInBankBranch;
    } else {
      this.checkSpecialCharInBankBranch = true;
      return this.checkSpecialCharInBankBranch;
    }
  }

  checkSpecialCharInIfsc = true;
  avoidSpecialCharInIfsc(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInIfsc = false;
      return this.checkSpecialCharInIfsc;
    } else {
      this.checkSpecialCharInIfsc = true;
      return this.checkSpecialCharInIfsc;
    }
  }

  checkSpecialCharInMicr = true;
  avoidSpecialCharInMicr(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInMicr = false;
      return this.checkSpecialCharInMicr;
    } else {
      this.checkSpecialCharInMicr = true;
      return this.checkSpecialCharInMicr;
    }
  }

  checkSpecialCharInCin = true;
  avoidSpecialCharInCin(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInCin = false;
      return this.checkSpecialCharInCin;
    } else {
      this.checkSpecialCharInCin = true;
      return this.checkSpecialCharInCin;
    }
  }

  checkSpecialCharInTan = true;
  avoidSpecialCharInTan(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInTan = false;
      return this.checkSpecialCharInTan;
    } else {
      this.checkSpecialCharInTan = true;
      return this.checkSpecialCharInTan;
    }
  }

  checkSpecialCharInTin = true;
  avoidSpecialCharInTin(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInTin = false;
      return this.checkSpecialCharInTin;
    } else {
      this.checkSpecialCharInTin = true;
      return this.checkSpecialCharInTin;
    }
  }

  checkSpecialCharInPan = true;
  avoidSpecialCharInPan(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInPan = false;
      return this.checkSpecialCharInPan;
    } else {
      this.checkSpecialCharInPan = true;
      return this.checkSpecialCharInPan;
    }
  }

  checkSpecialCharInGstin = true;
  avoidSpecialCharInGstin(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      this.checkSpecialCharInGstin = false;
      return this.checkSpecialCharInGstin;
    } else {
      this.checkSpecialCharInGstin = true;
      return this.checkSpecialCharInGstin;
    }
  }

  checkSpecialCharInAddress = true;
  avoidSpecialCharInAddress(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 44 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      this.checkSpecialCharInAddress = false;
      return this.checkSpecialCharInAddress;
    } else {
      this.checkSpecialCharInAddress = true;
      return this.checkSpecialCharInAddress;
    }
  }

  checkSpecialCharInPin = true;
  avoidSpecialCharInPin(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) ) {
      this.checkSpecialCharInPin = false;
      return this.checkSpecialCharInPin;
    } else {
      this.checkSpecialCharInPin = true;
      return this.checkSpecialCharInPin;
    }
  }

  getBUDropdownList(pageNumber:number, pageSize:number){
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize
    }
    this._shared.post('BusinessUnit/GetBusinessUnits', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.BUDropdown = res.item2;
    });
  }

  getVendorsData(pageNumber:number, pageSize:number){
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize,
      unit: sessionStorage.getItem('unit')
    }
    
    this.subscription = this._shared.post('Vendor/GetVendors', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.vendorsData = res.item2;
      this.totalVendors = res.item1;
    });
  }

  getCountries(pageNumber:number, pageSize:number) {
    let obj={
      pageNumber:pageNumber,
      pageSize:pageSize
    }
    this._shared.post('Country/GetCountryList', obj,'admin').subscribe(res => {
      this.country = res;
    });
  }


  changeCountry(e:any,pageNumber:number, pageSize:number){
    let obj = {
      // pageNumber: pageNumber,
      // pageSize: pageSize,
      countryCode: this.vendorForm.value.country[0]?.countryCode
    }
    this._shared.post('State/GetStateList',obj,'admin').subscribe(res => {
      // let state = res.filter((itm:any) => itm.countryCode == e.target.value);
      this.state = res;
    });
  }

  changeState(e:any) {
    let obj = {
      // pageNumber: pageNumber,
      // pageSize: pageSize,
    countryCode: this.vendorForm.value.country[0]?.countryCode,
    stateCode: this.vendorForm.value.state[0]?.stateCode
    }
    this._shared.post('City/GetCityList',obj, 'admin').subscribe(res => {
      // let city = res.filter((itm: any) => itm.stateCode == e.target.value);
      this.city = res;
    });
  }

  get formControl() {
    return this.vendorForm.controls;
  }
  
  getUnitColumns() {
    this.cols = [
      { field: 'Action', header: 'Action' },
      { field: 'vendorName', header: 'Vendor Name' },
      { field: 'vendorGroup', header: 'Vendor Group' },
      { field: 'bankName', header: 'BankName' },
      { field: 'bankBranch', header: 'Bank Branch' },
      { field: 'isActive', header: 'Status' },

    ];
  }

  open(content: any, flag:any) {
    if (flag == 'Add') {
      this.vendorForm.value.reverseCharge = this.vendorForm.value.reverseCharge ? true : false,
      this.vendorForm.value.isActive = this.vendorForm.value.isActive ? true : false,
      this.vendorForm.value.city =  this.vendorForm.value.city[0]?.cityCode,
      this.vendorForm.value.state =  this.vendorForm.value.state[0]?.stateCdoe,
      this.vendorForm.value.country =  this.vendorForm.value.country[0]?.countryCode,
      this.vendorForm.value.createdBy = sessionStorage.getItem('username');
      this._shared.post('Vendor/CreateVendor', this.vendorForm.value,'admin').subscribe(res=>{
        this.toast.show("Records saved successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.getVendorsData(this.pageNumber, this.pageSize);
        this.selectedTabIndex = 0;
        this.vendorForm.reset();
      })
    } else{
      //this.vendorForm.value.buid = data.buid;
      this.vendorForm.value.reverseCharge = this.vendorForm.value.reverseCharge ? true : false,
      this.vendorForm.value.isActive = this.vendorForm.value.isActive ? true : false,
      this.vendorForm.value.city =  this.vendorForm.value.city,
      this.vendorForm.value.state =  this.vendorForm.value.state,
      this.vendorForm.value.country =  this.vendorForm.value.country,
      this.vendorForm.value.modifiedBy = sessionStorage.getItem('username');
      this._shared.put('Vendor/UpdateVendor', this.vendorForm.value, 'admin').subscribe(res => {
        this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.loader = false;
        this.getVendorsData(this.pageNumber, this.pageSize);
        this.selectedTabIndex = 0;
        this.changeTitleAddViewEdit = 'Add';
      });
    }
  }

  edit(data: any, status: any) {
    if (status == 'edit') {
      this.changeTitleAddViewEdit = 'Edit';
      this.selectedTabIndex = 1;
      this.editFlag = true;
      this.vendorForm.value.VendorID = data.VendorID;
    } else if (status == 'view') {
      this.selectedTabIndex = 1;
      this.changeTitleAddViewEdit = 'View';
      this.editFlag = false;
    }else{

    }

    this.vendorForm.patchValue({
      bucode: data.bucode,
      vendorSapcode: data.vendorSapcode,
      vendorSaccode: data.vendorSaccode,
      vendorName: data.vendorName,
      vendorGroup: data.vendorGroup,
      accountName: data.accountName,
      accountNumber: data.accountNumber,
      bankName: data.bankName,
      bankBranch: data.bankBranch,
      ifsccode: data.ifsccode,
      micrcode: data.micrcode,
      cinnumber: data.cinnumber,
      tannumber: data.tannumber,
      tinnumber: data.tinnumber,
      pannumber: data.pannumber,
      gstinnumber: data.gstinnumber,
      address1: data.address1,
      address2: data.address2,
      address3: data.address3,
         city: data.cityId,
         state: data.stateCode,
         country: data.countryCode,
         pinCode: data.pinCode,
         reverseCharge:data.reverseCharge, 
         isActive: data.isActive,
         createdOn: data.created,
         createdBy: data.createdBy,
         modifiedOn: data.modified,
         modifiedBy: data.modifiedBy,  
    })
  }

  filterData(event:any){
    console.log(event);
    event.pageNumber = this.pageNumber;
    event.pageSize = this.pageSize;
    event.unit = sessionStorage.getItem('unit');
   this._shared.post('Vendor/SearchVendors',event,'admin').subscribe(res=>{
      this.loader = false;
      this.vendorsData = res.item2;
    });
  }

  refresh(event:any){
    if(event){
      this.getVendorsData(this.pageNumber, this.pageSize);
      this.hasFilteredData = {};
    }
  }

  tabChange(e: any) {
    this.editFlag = true;
    this.changeTitleAddViewEdit = 'Add';
    this.vendorForm.reset();
    this.vendorForm.patchValue({ 'isActive': true });
    let index = e.index;
    if (index == 0) {
      this.selectedTabIndex = 0;
      this.getVendorsData(this.pageNumber, this.pageSize);
    }
  }

  onPageChange(event:any){
    if (Object.keys(this.hasFilteredData).length != 0) {
      this.hasFilteredData.pageNumber = event.page;
      this.hasFilteredData.pageSize = event.rows;
      this.pageSize = event.rows;
      this._shared.post('User/SearchUsers', this.hasFilteredData, 'admin').subscribe(res => {
        this.loader = false;
        this.vendorsData = res.item2;
        this.totalVendors = res.item1;
      });
    } else {
      this.pageSize = event.rows;
      this.pageNumber = event.page;
      this.getVendorsData(event.page, event.rows);
    }
  }

  exportAsXLSX() {
    if (this.vendorsData.length > 0) {
      this.excelService.exportAsExcelFile(this.vendorsData, 'sample');
    }
  }

  createPdf() {
    let head:any = [[]];
    let data:any = [[]];
    this.vendorsData.forEach((res:any, index:any) => {
      if (index == 0) {
        for (let obj in res) { 
          if(head[index].length<=8){
            head[0].push(obj);
            data[index].push(res[obj]); 
          }
        }
      } else {
        data.push([])
        for (let obj in res) {
          if (data[index].length <= 8) {
            data[index].push(res[obj])
          }
        }
      }
    })
  
    let doc = new JSPDF.jsPDF("l", "in"); 

    doc.setFontSize(9);
    doc.text('', 11, 8);
    doc.setFontSize(9);
    doc.setTextColor(100);


    (doc as any).autoTable({
      head: head,
      body: data,
      theme: 'plain',
      didDrawCell: (data:any) => {
        console.log(data.column.index)
      }
    })

    // Open PDF document in new tab
    doc.output('dataurlnewwindow')

    // Download PDF document  
    doc.save('table.pdf');
  }

  ngOnDestroy(){
    //this.subscription.unsubscribe();
    //this.subscription1.unsubscribe();
  }


}
