create database reactapp;
use reactapp;
-- ----------------------------------------category table
create table category(
RowId int not null auto_increment unique,
CategoryId varchar(20) primary key not null,
CategoryName varchar(100) not null
);
insert into category values(1,'catid-1','Electronics');
insert into category values(2,'catid-2','Electricals');
insert into category values(3,'catid-3','Food');
insert into category values(4,'catid-4','Furniture');
select * from category;
-- ---------------------------------------- customer table
create table customer(
RowId int not null auto_increment unique,
CustomerId varchar(20) primary key not null,
CustomerName varchar(50) not null,
CustomerPhone varchar(50) not null,
CustomerEmail varchar(50) not null,
CustomerAddress varchar(100) not null,
CustomerCity varchar(50) not null,
CustomerState varchar(50) not null,
CustomerCountry varchar(50) not null,
CustomerPassword varchar(50) not null
);
insert into customer values(1,'custid-1','Shubham',9999999999,'shubham@gmail.com',
'Opposite of Main Bus Stop','Udgir','Maharashtra','India','Shubham@123');
insert into customer values(2,'custid-2','Sid',9999999991,'sid@gmail.com',
'Opposite of Ganesh Temple','Pune','Maharashtra','India','Sid@123');
insert into customer values(3,'custid-3','Gauri',9999999992,'gauri@gmail.com',
'In front of Main Bus Stop','Mumbai','Maharashtra','India','Gauri@123');
select * from customer;
-- --------------------------------------------- orders table
create table orders(
RowId int not null auto_increment unique,
OrderId varchar(20) primary key not null,
CustomerId varchar(50) not null, constraint 
fk_CustomerId_in_orders_table foreign key(CustomerId) references customer(CustomerId),
GrandTotal decimal(10,2) not null,
OrderDate date not null,
ExpectedDeliveryDate date not null,
ActualDeliveryDate date not null,
Paid_by varchar(20) not null
);
delete from orders where OrderId='ord-1';
insert into orders values(1,'ord-1','custid-1',20300,'2021-06-04','2021-06-15','2021-06-16','Cash');
insert into orders values(2,'ord-2','custid-2',40300,'2021-06-14','2021-06-25','2021-06-26','UPI');
select * from orders;
-- --------------------------------------- dispatch table
create table dispatch(
RowId int not null auto_increment unique,
DispatchId varchar(20) primary key not null,
OrderId varchar(20) not null, constraint 
fk_OrderId_in_dispatch_table foreign key(OrderId) references orders(OrderId),
DispatchDate date not null,
DeliveryAgentName varchar(20) not null,
DeliveryAgentContact varchar(20) not null,
ActualDeliveryDate date,
DispatchStatus varchar(20) not null
);
insert into dispatch values(1,'disp-1','ord-1','2021-06-08','ABC',1111111111,'2021-06-16','In Transit');
insert into dispatch values(2,'disp-2','ord-2','2021-06-09','ABCD',2111111111,'2021-06-26','Deliverd');
select * from dispatch;
-- ------------------------------error msg table
create table errormessage(
message varchar(100) 
);
insert into errormessage values('Please enter correct ProductId');
select * from errormessage;
-- -----------------------------------------manufacturer table
create table manufacturer(
RowId int not null auto_increment unique,
ManufacturerId varchar(20) primary key not null,
ManufacturerName varchar(20) not null,
ManufacturerDescription varchar(50),
ManufacturerAddress varchar(100),
CategoryId varchar(20) not null, constraint 
fk_CategoryId_in_manufacturer_table foreign key(CategoryId) references category(CategoryId)
);
insert into manufacturer values(1,'manid-1','HP','HP Description','Mumbai','catid-1');
insert into manufacturer values(2,'manid-2','BAJAJ','BAJAJ Description','Delhi','catid-2');
insert into manufacturer values(3,'manid-3','NESTLE','NESTLE Description','Pune','catid-3');
insert into manufacturer values(4,'manid-4','AMERICAN SIGNATURE','AMERICAN SIGNATURE Description','Delhi','catid-4');
select * from manufacturer;
-- -----------------------------subcategories table 
create table subcategories(
RowId int not null auto_increment unique,
SubCategoryId varchar(20) primary key not null,
SubCategoryName varchar(200) not null,
CategoryId varchar(20) not null, constraint 
fk_CategoryId_in_subcategories_table foreign key(CategoryId) references category(CategoryId)
);
insert into subcategories values(1,'subcatid-1','SubCatName1','catid-1');
insert into subcategories values(2,'subcatid-2','SubCatName2','catid-2');
insert into subcategories values(3,'subcatid-3','SubCatName3','catid-3');
insert into subcategories values(4,'subcatid-4','SubCatName4','catid-4');
select * from subcategories;
-- ---------------------------- vendor table
create table vendor(
RowId int not null auto_increment unique,
VendorId varchar(20) primary key not null,
VendorName varchar(50) not null unique,
VendorPhone varchar(20) not null,
VendorEmail varchar(20) not null,
VendorAddress varchar(200) not null
);
insert into vendor values(1,'venid-1','Mayuri',8888888888,'mayuri@gmail.com','Pune');
insert into vendor values(2,'venid-2','Alia',8888888881,'alia@gmail.com','Mumbai');
insert into vendor values(3,'venid-3','Sai',8888888882,'sia@gmail.com','Nashik');
insert into vendor values(4,'venid-4','Sahil',8888888883,'sahil@gmail.com','Delhi');
select * from vendor;
-- ------------------------------------- product table
create table product(
RowId int not null auto_increment unique,
ProductId varchar(20) primary key not null,
ProductName varchar(100) not null,
Product_Price decimal(10,2) not null,
ProductDescription  varchar(100) not null,
CategoryId varchar(20) not null, constraint 
fk_CategoryId_in_product_table foreign key(CategoryId) references category(CategoryId),

SubCategoryId varchar(20) not null, constraint 
fk_SubCategoryId_in_product_table foreign key(SubCategoryId) references subcategories(SubCategoryId),

ManufacturerId varchar(20) not null, constraint 
fk_ManufacturerId_in_product_table foreign key(ManufacturerId) references manufacturer(ManufacturerId),

VendorId varchar(20) not null, constraint 
fk_VendorId_in_product_table foreign key(VendorId) references vendor(VendorId)
);
insert into product values(1,'prd-1','Laptop',40000,'Screen size 24 inch','catid-1','subcatid-1',
'manid-1','venid-1');
insert into product values(2,'prd-2','Cooler',6000,'Capacity of 20Litres','catid-2','subcatid-2',
'manid-2','venid-2');
insert into product values(3,'prd-3','Cadbury',1000,'Dark Chocolate','catid-3','subcatid-3',
'manid-3','venid-3');
insert into product values(4,'prd-4','Table',4000,'Wooden Table','catid-4','subcatid-4',
'manid-4','venid-4');
insert into product values(5,'prd-5','Mobile',20000,'128 GB storage','catid-1','subcatid-1',
'manid-1','venid-1');
select * from product;
-- --------------------------payment table
create table payment(
RowId int not null auto_increment unique,
PaymentId varchar(20) primary key not null,
OrderId varchar(20) not null, constraint 
fk_OrderId_in_payment_table foreign key(OrderId) references orders(OrderId),
Transaction_Date date not null,
Transaction_Status varchar(20) not null,
Paid_by varchar(20) not null
);
insert into payment values(1,'payid-1','ord-1','2021-06-04','Confirmed','UPI');
insert into payment values(2,'payid-2','ord-2','2021-06-05','Pending','Cash');
select * from payment;
-- --------------------------imagepath table
create table imagepath(
RowId int not null auto_increment primary key,
ProductId varchar(20) not null, constraint 
fk_ProductId_in_imagepath_table foreign key(ProductId) references product(ProductId),
fieldName varchar(50),
originalName varchar(50),
encoding varchar(50),
mimetype varchar(50),
destination varchar(50),
fileName varchar(50),
path varchar(50),
img_path varchar(200));
select * from imagepath;
-- -------------------------------- orderitem table
create table orderitem(
RowId int not null auto_increment unique,
OrderItemId varchar(20) not null primary key,
OrderItemName varchar(100),
OrderId varchar(20) not null, constraint 
fk_OrderId_in_orderitem_table foreign key(OrderId) references orders(OrderId),

ProductId varchar(20) not null, constraint 
fk_ProductId_in_orderitem_table foreign key(ProductId) references product(ProductId),

ProductPrice decimal(10,2) not null,
Tax_calculated decimal(10,2),
Quantity int not null,
Total_Price decimal(10,2) not null
);
insert into orderitem values(1,'itemid-1','Laptop','ord-1','prd-1',40000,40500,1,40500);
insert into orderitem values(2,'itemid-2','Cooler','ord-2','prd-2',6000,6500,1,6500);
select * from orderitem;
-- --------------------------------rolemaster table
create table rolemaster(
RowId int not null auto_increment unique,
RoleId varchar(20) primary key not null,
RoleName varchar(200) not null,
RoleDescription varchar(200) not null
);
insert into rolemaster values(1,'role-1','Admin','Admin User Description');
insert into rolemaster values(2,'role-2','Customer','Customer  Description');
insert into rolemaster values(3,'role-3','Manufacturer','Manufacturer Description');
insert into rolemaster values(4,'role-4','Vendor','Vendor Description');
select * from rolemaster;
-- ----------------------userlogininfo table
create table userlogininfo(
RowID int not null auto_increment primary key,
UserName varchar(20)  not null unique,
LoginDateTime datetime not null,
LogoutDateTime datetime not null
);
insert into userlogininfo values(1,'Bhakti','2021-06-04 04:45:00','2021-06-04 04:50:00');
insert into userlogininfo values(2,'Shubham','2021-06-03 01:10:00','2021-06-03 01:20:10');
insert into userlogininfo values(3,'Mahi','2021-06-02 04:20:00','2021-06-02 04:50:00');
select * from userlogininfo;
-- -----------------------usermaster table
create table usermaster(
RowId int not null auto_increment unique,
UserName varchar(200) primary key not null,
Password  varchar(50) not null,
EmailAddress varchar(50)  unique not null
);
insert into usermaster values(1,'Bhakti','Bhakti@123','Bhakti@gmail.com');
insert into usermaster values(2,'Shubham','Shubham@123','Shubham@gmail.com');
insert into usermaster values(3,'Virat','Virat@123','Virat@gmail.com');
insert into usermaster values(4,'Abhi','Abhi@123','Abhi@gmail.com');
select * from usermaster;
-- --------------------userinrole table
create table userinrole(
RowId int not null auto_increment primary key,
UserName varchar(200) not null, constraint 
fk_UserName_in_userinrole_table foreign key(UserName) references usermaster(UserName),
RoleName varchar(50) not null
);
insert into userinrole values(1,'Bhakti','Admin');
insert into userinrole values(2,'Shubham','Customer');
insert into userinrole values(3,'Virat','Manufacturer');
insert into userinrole values(4,'Abhi','Vendor');
select * from userinrole;

use reactapp;
select * from product;
select * from category;
select * from category;

delete from category where CategoryId="6";



