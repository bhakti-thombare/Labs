use pubs;
-- 1
CREATE TABLE EMPLOYEE
(
EMP_ID INT(4) PRIMARY KEY AUTO_INCREMENT,
NAME VARCHAR(25),
LAST_NAME VARCHAR(25),
BASIC_SAL FLOAT(9,2)
);

-- 2
DESC EMPLOYEE;
insert into EMPLOYEE values(1,'Patel','Ralph',795);
select * from  EMPLOYEE;
insert into EMPLOYEE values(2,'Dancs','Betty',860);
insert into EMPLOYEE values(3,'Biri','Ben',1100);
insert into EMPLOYEE values(4,'Newman','Chad',750);
insert into EMPLOYEE values(5,'Ropeburn','Audry',1550);

-- 3
desc employee;
ALTER TABLE employee MODIFY NAME varchar(5);
desc employee;

-- 4
select * from EMPLOYEE;
SELECT * FROM EMPLOYEE WHERE mod(EMP_ID,2) = 0;

-- 5 ,6
ALTER TABLE EMPLOYEE ADD SALARY BIGINT  NOT NULL;
select * from EMPLOYEE;

-- 7
ALTER TABLE EMPLOYEE ADD BASIC_SALARY BIGINT;
ALTER TABLE EMPLOYEE DROP COLUMN BASIC_SALARY;
SELECT * FROM EMPLOYEE;
 
-- 8
Alter table EMPLOYEE ADD COLUMN EMAIL_ID varchar(20) NOT NULL;

-- 9
insert into EMPLOYEE values(6,'Tom','Cruise',5000.00);
-- it returns error that -Error Code: 1136. Column count doesn't match value count at row

-- 10
alter table EMPLOYEE DROP COLUMN EMAIL_ID;
select * from EMPLOYEE;

-- 11
RENAME TABLE EMPLOYEE TO MY_EMP02;
show tables;

-- 12
DROP table MY_EMP02;

-- 13
DROP table if exists MY_EMP02;
-- its shows  1051 Unknown table 'pubs.my_emp02'	0.000 sec