use pubs;
-- 1
select * from titles;
select * from publishers;

-- 2
-- SELECT titles.title_id, titles.title, publishers.pub_id, publishers.pub_name FROM titles, publishers 
-- WHERE titles.pub_id = publishers.pub_id ;
SELECT t.title, p.pub_name FROM titles t JOIN publishers p ON p.pub_id = t.pub_id;

-- 3
select * from titles;
select * from publishers;
SELECT titles.title_id, titles.ytd_sales, titles.title, SUM(titles.ytd_sales) "Total Sales", publishers.pub_id, publishers.pub_name
FROM titles, publishers 
WHERE titles.pub_id = publishers.pub_id group by publishers.pub_name;

SELECT t.ytd_sales, p.pub_name FROM titles t JOIN publishers p ON p.pub_id = t.pub_id GROUP BY p.pub_name;

-- 4 
select * from authors;
select * from publishers;
select p.pub_name, p.city, a.au_fname, a.au_lname, a.city
from publishers p, authors a where p.city = a.city;


-- 5 same as 4-not confirm
select p.pub_name, p.city, a.au_fname, a.au_lname, a.city
from publishers p, authors a where p.city = a.city;

SELECT a.au_lname, a.city, p.pub_name, p.city
    FROM publishers p
     LEFT JOIN authors a ON p.city = a.city;

-- 6 not confirm


SELECT DISTINCT t.pub_id, p.pub_name FROM publishers p
     JOIN titles t ON t.pub_id = p.pub_id
	WHERE type = 'business';

select * from titles;

-- 7 
SELECT t.title, CONCAT(a.au_fname, ' ', a.au_lname) "Author's Name"
     FROM titles t
     JOIN titleauthor ta ON ta.title_id = t.title_id
    JOIN authors a ON a.au_id  = ta.au_id;

-- 8.a -create emp table
create table Employees(emp_id varchar(10), ename varchar(40), dept_id varchar(20),
job varchar(35), mgr_id varchar(20), bsal decimal(10,4));
show tables;
desc Employees;

insert into Employees values(101,'Sameer',10,'President',NULL,50000);
select * from Employees;
insert into Employees values(102,'Srinivas',10,'VP',101,40000);
insert into Employees values(103,'Nanda',20,'VP',101,40000);
insert into Employees values(104,'Ram',30,'DGM',102,35000);
insert into Employees values(105,'Vivek',20,'PM',103,30000);
insert into Employees values(106,'Venkat',20,'Tech Lead',105,25000);

-- 8.b create departments
create table Departments(dept_id varchar(20), dname varchar(40),
location varchar(40));
select * from departments;
insert into Departments values(10,'Crop','Dallas');
insert into Departments values(20,'PW','Bangalore');
insert into Departments values(30,'SP','Pune');
insert into Departments values(40,'MS','Hyderabad');

-- 8.c create salgrade function
create table salgrades(grade varchar(20), min_sal decimal(10,4), max_sal decimal(10,4));
select * from salgrades;
desc salgrades;
insert into salgrades values('A',40001,50000);
insert into salgrades values('B',30001,40000);
insert into salgrades values('C',20001,30000);

-- 9
desc employees;
SELECT e.emp_id , e.ename , e.dept_id , d.dname FROM employees e 
JOIN departments d ON e.dept_id = d.dept_id;

-- 10
select * from employees;
select * from departments;
SELECT DISTINCT e.job, e.dept_id, d.location	FROM  employees e,  departments d
WHERE e.dept_id = d.dept_id AND e.dept_id = 30;
    
    
-- 11 not sure commission is not there
desc employees;
desc departments;

SELECT e.ename, d.dname, d.location, e.bsal
	FROM employees e, departments d
	WHERE e.dept_id = d.dept_id;
    
-- 12
select * from employees;
SELECT e.ename, d.dname FROM employees e, departments d 
WHERE e.dept_id = d.dept_id AND e.ename LIKE '%A%';

SELECT e.ename, d.dname
    FROM employees e
     JOIN departments d on d.dept_id = e.dept_id
    WHERE e.ename regexp '[S]';

-- 13
select * from employees;
SELECT 	e.ename, e.job, e.dept_id,d.dname, d.location FROM 	employees e JOIN departments d
ON 	(e.dept_id = d.dept_id) WHERE 	LOWER(d.location) = 'Dallas';

-- 14
select * from employees;
select * from departments;
-- SELECT	 e.ename "Employee", e.emp_id "Employee Number", e.mgr_id "Manager" FROM     employees e ;
SELECT e.ename "Employee", e.emp_id "Emp No", m.ename "Manager", m.emp_id "Manager No."
FROM employees e JOIN employees m ON m.emp_id = e.mgr_id;

-- 15
SELECT	e.ename "Employee", e.emp_id "Emp No",e.mgr_id  FROM employees e where e.mgr_id IS NULL ;

-- 16 
DESC salgrades;
select * from salgrades;
SELECT e.ename, e.job, d.dname,
	e.bsal, s.grade
	FROM employees e, departments d, salgrades s
	WHERE e.dept_id = d.dept_id
	AND e.bsal BETWEEN s.min_sal AND s.max_sal;
    
    
