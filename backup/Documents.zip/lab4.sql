-- 1
use pubs;
show tables;

-- 2
select * from titles;
select MIN(price) as MINIMUM_PRICE , MAX(price) as MAXIMUM_PRICE,  AVG(price) as AVERAGE_PRICE from titles;
select MIN(price)  "MINIMUM_PRICE" , MAX(price)  "MAXIMUM_PRICE",  AVG(price) "AVERAGE_PRICE" from titles;


-- 3.a
SELECT * FROM titles; 
select distinct type from titles;
select COUNT(title) "CountByType", type FROM titles GROUP BY type order by CountByType desc;
select title,type, COUNT(*) TypeCount from titles where type="Business";
select title,type, COUNT(*) TypeCount from titles where type="mod_cook";
select title,type, COUNT(*) TypeCount from titles where type="UNDECIDED";
select title,type, COUNT(*) TypeCount from titles where type="popular_comp";
select title,type, COUNT(*) TypeCount from titles where type="psychology";
select title,type, COUNT(*) TypeCount from titles where type="trad_cook";

-- 3.b
select * from titles;
desc titles;
desc authors;
select distinct type from titles;
SELECT type,  COUNT(*) 'CountType' from titles WHERE type = 'business';
SELECT type,  COUNT(*) 'CountType' from titles WHERE type = 'business' GROUP BY type;

-- 4
select * from titles;
select distinct type from titles;
SELECT type "Book Category", ROUND(AVG(price), 2) "Average Price" FROM titles GROUP BY type;
-- select title, type "Book Category" , price, AVG(ROUND(price,2)) "Average Price"   from titles where type="business";
-- select title, type "Book Category" , price, AVG(ROUND(price,2)) "Average Price"   from titles where type="mod_cook";
-- select title, type "Book Category" , price, AVG(ROUND(price,2)) "Average Price"   from titles where type="UNDECIDED";
-- select title, type "Book Category" , price, AVG(ROUND(price,2)) "Average Price"   from titles where type="popular_comp";
-- select title, type "Book Category" , price, AVG(ROUND(price,2)) "Average Price"   from titles where type="psychology";
-- select title, type "Book Category" , price, AVG(ROUND(price,2)) "Average Price"   from titles where type="trad_cook";

-- 5

select title, UPPER(type) "Book Category", COUNT(title) "# Books" from titles group by type;
SELECT CONCAT(UPPER(SUBSTRING(type,1,1)),LOWER(SUBSTRING(type,2))) "Book Category",
 COUNT(type) "# of Books" FROM titles GROUP BY type;
 
-- 6
select * from titles;
select title, UPPER(type) "Book Category", COUNT(title) "BooksCount" 
from titles group by type order by BooksCount;

 SELECT CONCAT(UPPER(SUBSTRING(type,1,1)),LOWER(SUBSTRING(type,2))) "Book Category", COUNT(type) "# of Books" FROM titles
 GROUP BY type ORDER BY 2;

-- 7
SELECT type, AVG(price) FROM titles GROUP BY type WITH ROLLUP;


-- 8
select title, type, AVG(Price) "AveragePrice" from titles group by type with rollup limit 2 ;
SELECT type, AVG(price) FROM titles GROUP BY type ORDER BY 2 DESC  LIMIT 2;

-- 9
select  type, count(type)  from titles group by type HAVING count(type) < 4 order by count(type) DESC;
 SELECT type, COUNT(type) "count" FROM titles GROUP BY type HAVING count(type) < 4 ORDER BY count(type) DESC;
    
-- 10
select * from authors;
select au_id, au_fname, au_lname, phone, address, city, state, COUNT(*) 
Authors_Count from authors GROUP BY state;


-- 11
select * from titles;
select title_id,title, ytd_sales, pub_id "Publisher ID" , SUM(ytd_sales) Quantity_Of_Sales from titles GROUP BY pub_id;
SELECT title, type, SUM(ytd_sales) "Quantity of Sales", pub_id "Publisher ID" 
FROM titles GROUP BY pub_id ORDER BY 1 DESC;
    
-- 12
SELECT  IFNULL(type, 'ALL types') "Book Type", SUM(ytd_sales) "Quantity of Sales" 
FROM titles GROUP BY type WITH ROLLUP;

-- select title_id,title, type "Book Type",ytd_sales ,COUNT(*) Quantity_Of_Sales, ytd_sales * COUNT(*) Total_Sales
-- from titles GROUP BY type ;



-- 13.a
select * from titles;
SELECT title, type, ytd_sales, SUM(ytd_sales) "TotalQuantitySales" FROM titles GROUP BY type
    HAVING totalQuantitySales < 10000;

-- 13.b
SELECT title, type, ytd_sales, SUM(ytd_sales) "TotalQuantitySales" FROM titles GROUP BY type
    HAVING totalQuantitySales >= 10000 AND totalQuantitySales < 25000;

-- 13.c
SELECT title, type, ytd_sales, SUM(ytd_sales) "TotalQuantitySales" FROM titles GROUP BY type
    HAVING totalQuantitySales >= 25000;

-- 14
SELECT title, type, pub_id,ytd_sales, SUM(ytd_sales) "TotalQuantitySales" FROM titles GROUP BY pub_id
    HAVING totalQuantitySales > 25000;

-- 15
-- select title, AVG(price),SUM(ytd_sales) from titles group by type order by pub_id;
-- select type, pub_id, AVG(price) "Average Price",SUM(ytd_sales) "Quantity_Of_Sales" from titles group by type order by pub_id;
SELECT type, pub_id, AVG(price), SUM(ytd_sales) "totalQuantitySales" FROM titles GROUP BY type, pub_id;

-- 16
SELECT IFNULL(type, "AllTypes") "Book Type", IFNULL(pub_id, "====>") "Publisher ID", ROUND(AVG(price), 2) "Average Price", SUM(ytd_sales) "Qty of Sales"
FROM titles GROUP BY type, pub_id WITH ROLLUP;

-- select type, pub_id, AVG(price) "Average Price",SUM(ytd_sales) "Quantity_Of_Sales" 
-- from titles group by type with rollup;

-- select type, pub_id, AVG(price) "Average Price",SUM(ytd_sales) "Quantity_Of_Sales" 
-- from titles group by type with rollup limit 2;

-- select title, type, AVG(Price) "AveragePrice" from titles group by type with rollup limit 2 ;

-- 16.a
select  title,title_id, type "Book Type" , pub_id "Publisher_ID", AVG(price) "Average Price",
ytd_sales "Quantity Of Sales" from titles group by pub_id ;

-- 16.c

SELECT * FROM titles 
WHERE title IS NOT NULL AND 
title_id IS NOT NULL AND
type IS NOT NULL AND 
pub_id IS NOT NULL AND
price IS NOT NULL AND
advance IS NOT NULL AND
royalty IS NOT NULL AND
ytd_sales IS NOT NULL AND
notes IS NOT NULL AND
pubdate IS NOT NULL;

-- 16.d
select type "Book Type" from titles where type IS NOT NULL;
select type "Book Type" from titles GROUP BY type  WITH ROLLUP limit 2 ;

-- 16.e
SELECT * FROM titles WHERE pub_id  IS NOT NULL ;