create database eshoppingapp;
use eshoppingapp;
create table Vendor(
VendorRowId int not null auto_increment unique,
VendorId varchar(20) not null unique primary key,
VendorName varchar(100) not null,
VendorAddress varchar(200) not null,
VendorEmail varchar(100) not null,
VendorMobile varchar(100) not null,
VendorContactName varchar(100) not null);
insert into Vendor values(1,'venid-01','ABC Electricals','Pune','abc@gmail.com',9999888877,'ABC');
insert into Vendor values(2,'venid-02','DEF Electronics','Mumbai','def@gmail.com',9999888866,'DEF');
insert into Vendor values(3,'venid-03','Sweet Food','Pune','sweetf@gmail.com',9999888855,'SweetF');
insert into Vendor values(4,'venid-04','Relax Furniture','Nashik','relax@gmail.com',9999888844,'RelaxF');
select * from Vendor;

create table Categories(
CategoryRowId int not null auto_increment unique,
CategoryId varchar(20) not null unique primary key,
CategoryName varchar(100) not null
);
insert into Categories values(1,'catid-01','Electricals');
insert into Categories values(2,'catid-02','Electronics');
insert into Categories values(3,'catid-03','Food');
insert into Categories values(4,'catid-04','Furniture');
select * from Categories;

create table SubCategories(
SubCategoryRowId int not null auto_increment unique ,
SubCategoryId varchar(20) not null unique primary key,
SubCategoryName varchar(100) not null,
CategoryRowId int not null, constraint fk_CategoryRowId_in_SubCategories_table
 foreign key(CategoryRowId) references Categories(CategoryRowId)
);
insert into SubCategories values(1,'subcatid-01','TV',1);
insert into SubCategories values(2,'subcatid-02','Mobile',2);
insert into SubCategories values(3,'subcatid-03','Cadbury',3);
insert into SubCategories values(4,'subcatid-04','Table',4);
select *  from SubCategories;

create table Manufacturer(
ManufacturerRowId int not null auto_increment unique,
ManufacturerId varchar(20) not null unique primary key,
ManufacturerName varchar(100) not null,
ManufacturerDescription varchar(200) not null,
ManufacturerAddress varchar(200) not null,
CategoryRowId int not null, constraint fk_CategoryRowId_in_Manufacturer_table 
foreign key(CategoryRowId) references Categories(CategoryRowId)
);
insert into Manufacturer values(1,'manid-01','BAJAJ','Description for Bajaj','Pune',1);
insert into Manufacturer values(2,'manid-02','IBM','Description for IBM','Mumbai',2);
insert into Manufacturer values(3,'manid-03','HP','Description for HP','Pune',2);
insert into Manufacturer values(4,'manid-04','PARLE','Description for Parle','Nashik',3);
insert into Manufacturer values(5,'manid-05','Hawai','Description for Hawai','Pune',4);
select * from Manufacturer;


create table Product(
ProductRowId int not null auto_increment unique,
ProductId varchar(20) not null unique primary key,
ProductName varchar(100) not null,
ProductPrice int not null,
ProductDescription varchar(200) not null,
SubCategoryRowId int not null, constraint fk_SubCategoryRowId_in_Product_table
 foreign key(SubCategoryRowId) references SubCategories(SubCategoryRowId),
VendorRowId int not null, constraint fk_VendorRowId_in_Product_table 
foreign key(VendorRowId) references Vendor(VendorRowId),
ManufacturerRowId int not null, constraint fk_ManufacturerRowId_in_Product_table 
foreign key(ManufacturerRowId) references Manufacturer(ManufacturerRowId),
ProductQuantity int not null,
CategoryRowId int not null, constraint fk_CategoryRowId_in_Product_table 
foreign key(CategoryRowId) references Categories(CategoryRowId)
);
insert into Product values(1,'prd-01','Laptop',40000,'Laptop with 1TB Hard Disk',1,1,2,1,1);
insert into Product values(5,'prd-05','Mouse',1200,'Optical Mouse',1,1,2,1,1);
insert into Product values(2,'prd-02','Mobile',20000,'128 gb',1,2,1,1,2);
insert into Product values(3,'prd-03','Cadbury',1000,'frozen cadburies',3,3,3,100,3);
insert into Product values(4,'prd-04','Table',2000,'Table Description',4,4,4,2,4);

select * from Product;


create table Customer(
CustomerRowId int not null auto_increment unique,
CustomerId varchar(20) not null unique primary key,
CustomerName varchar(200) not null,
CustomerAddress varchar(200) not null,
CustomerCity varchar(200) not null,
State varchar(200) not null,
Country varchar(200) not null,
Email varchar(80)not null,
CustomerMobile int not null,
CustomerPassword varchar(100) not null
);
insert into Customer values(1,'custid-01','Sid','Street-19','Mumbai','Maharashtra','India','sid@gmail.com',9991110001,'Sid@123');
insert into Customer values(2,'custid-02','Alia','Street-20','Pune','Maharashtra','India','alia@gmail.com',8991110001,'Alia@123');
insert into Customer values(3,'custid-03','Dev','Street-21','Mumbai','Maharashtra','India','dev@gmail.com',7991110001,'Dev@123');
insert into Customer values(4,'custid-04','Max','Street-22','Mumbai','Maharashtra','India','max@gmail.com',9991110002,'Max@123');
insert into Customer values(5,'custid-05','John','Street-23','NYC','NYC','NewYork','john@gmail.com',9991110003,'John@123');
select * from Customer;



create table  OrderMaster(
OrderRowId int not null auto_increment unique,
OrderId  varchar(20) not null unique primary key,
CustomerRowId int not null, constraint fk_CustomerRowId_in_OrderMaster_table 
foreign key(CustomerRowId) references Customer(CustomerRowId),
OrderDate DATE not null,
TotalAmount int not null,
ExpectedDeliveryDate DATE not null,
ActualDeliveryDate DATE not null,
ProductRowId int not null, constraint fk_ProductRowId_in_OrderMaster_table 
foreign key(ProductRowId) references Product(ProductRowId)
);
insert into OrderMaster values(1,'ord-01',1,'2021-10-02',40000,'2021-11-02','2021-12-02',1);
insert into OrderMaster values(2,'ord-02',2,'2021-12-02',20000,'2021-22-02','2021-23-02',2);
insert into OrderMaster values(2,'ord-02',2,'2021-10-02',20000,'2021-11-02','2021-12-02',1);
insert into OrderMaster values(3,'ord-03',3,'2021-1-02',40000,'2021-2-02','2021-2-02',3);
insert into OrderMaster values(4,'ord-04',4,'2021-11-02',4000,'2021-22-02','2021-23-02',4);
select * from  OrderMaster;
delete from OrderMaster where OrderRowId=2;
delete from OrderMaster;
drop table OrderMaster;

create table OrderMasterItemDetails(
OrderItemRowId int not null auto_increment unique,
OrderItemId varchar(20) not null unique primary key,
ProductRowId int not null, constraint fk_ProductRowId_in_OrderMasterItemDetails_table foreign key(ProductRowId) references Product(ProductRowId),
UnitPrice int not null,
Quantity int not null,
TotalItemPrice int not null,
OrderRowId int not null, constraint fk_OrderRowId_in_OrderMasterItemDetails_table 
foreign key(OrderRowId) references OrderMaster(OrderRowId),
OrderItemDescription varchar(200) not null
);
insert into OrderMasterItemDetails values(1,'oritem-01',1,40000,1,40000,1,'Laptop with 1TB HardDisk');
insert into OrderMasterItemDetails values(2,'oritem-02',2,20000,1,20000,2,'128 gb');
insert into OrderMasterItemDetails values(3,'oritem-03',3,1000,3,3000,3,'Cadburies');
insert into OrderMasterItemDetails values(4,'oritem-04',2,900,2,1800,4,'Chairs');
select * from OrderMasterItemDetails;
delete from OrderMasterItemDetails where OrderItemRowId=3;



create table Dispatch(
DispatchRowId int not null auto_increment unique,
DispatchId varchar(20) not null unique primary key,
OrderRowId int not null, constraint fk_OrderRowId_in_Dispatch_table 
foreign key(OrderRowId) references OrderMaster(OrderRowId),
DispatchDate DATE not null,
ActualDeliveryDate DATE not null,
DispatchStatus varchar(100) not null,
DeliveryAgentName varchar(200) not null,
DeliveryAgentMobile int not null
);
insert into Dispatch values(1,'dispid-01',1,'2020-04-04','2020-04-10','Delivered','ABCD',2147483647);
insert into Dispatch values(2,'dispid-02',2,'2020-04-05','2020-04-15','In Transit','ABCDED',2147483647);
insert into Dispatch values(3,'dispid-03',3,'2020-04-15','2020-04-25','Pending','DEF',1999000000);
select * from Dispatch;

create table RoleMaster(
RoleMasterRowId int not null auto_increment unique,
RoleMasterId varchar(20) not null unique primary key,
RoleName varchar(20) not null,
RoleDescription varchar(200) not null
);
insert into RoleMaster values(1,'roleid-01','Admin','This is Admin Role.Has all access');
insert into RoleMaster values(2,'roleid-02','Customer','This is Customer Role.Can see all product Information');
insert into RoleMaster values(3,'roleid-03','Vendor','This is Vendor Role.Can add product Information');
insert into RoleMaster values(4,'roleid-04','Manufacturer','This is Manufacturer Role.Can Add product');
select * from RoleMaster;

create table UserLoginInfo(
LoginCountId int not null auto_increment  primary key,
UserName varchar(50) not null,
LoginDateTime DATE not null,
LogoutDateTime DATE not null
);
insert into UserLoginInfo values(1,'Sai','2021-05-08 10:00:00','2021-05-08 10:21:00');
insert into UserLoginInfo values(2,'Sahil','2021-05-09 10:10:00','2021-05-10 10:21:00');
insert into UserLoginInfo values(3,'Varad','2021-05-19 10:20:00','2021-05-20 10:22:00');
select * from UserLoginInfo;


create table UserMaster(
UserMasterRowId int not null auto_increment unique,
UserMasterId varchar(20) not null unique,
UserName varchar(40) not null primary key,
Password varchar(20) not null,
Email varchar(50) unique not null
);
insert into UserMaster values(1,'user_m_id-01','Bhakti','Bhakti@123','Bhakti@gmail.com');
insert into UserMaster values(2,'user_m_id-02','Mahesh','Mahesh@123','Mahesh@gmail.com');
insert into UserMaster values(3,'user_m_id-03','Kavya','Kavya@123','Kavya@gmail.com');
select * from UserMaster;
delete from userMaster where UserMasterRowId=3;

create table UserInRole(
UserInRoleRowId  int not null auto_increment unique,
UserInRoleId varchar(50) not null unique primary key,
UserName varchar(40) not null,
UserRoleName varchar(20) not null
);
insert into UserInRole values(1,'user_role_id-01','Bhakti','Admin');
insert into UserInRole values(2,'user_role_id-02','Virat','Admin');
insert into UserInRole values(3,'user_role_id-03','Mahesh','Customer');
insert into UserInRole values(4,'user_role_id-04','Shubham','Customer');
insert into UserInRole values(5,'user_role_id-05','Vinod','Vendor');
insert into UserInRole values(6,'user_role_id-06','Mayur','Vendor');
insert into UserInRole values(7,'user_role_id-07','Prasad','Manufacturer');
insert into UserInRole values(8,'user_role_id-08','Rushi','Manufacturer');
select * from UserInRole;

create table Payment(
PaymentRowId  int not null auto_increment unique,
PaymentId varchar(50) not null primary key,
PaymentType varchar(100) not null,
OrderRowId int not null, constraint fk_OrderRowId_in_Payment_table foreign key(OrderRowId) 
references OrderMaster(OrderRowId)
);
insert into Payment values(1,'payid-01','Online',1);
insert into Payment values(2,'payid-02','COD',2);
select * from Payment;

use reactapp;
select * from usermaster;
delete from usermaster where EmailAddress='abc@gmail.com';
insert into UserMaster values(8,'Kavya','Kavya@123','Kavya@gmail.com');
select * from imagepath;