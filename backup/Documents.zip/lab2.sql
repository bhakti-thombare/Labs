-- lab2 started *******************************************************************************
-- publishers table
-- 1
use pubs;

-- 2
select * from publishers;
desc publishers;

-- 3.a
select pub_id, pub_name from publishers;

-- 3.b
select * from publishers;

-- 3.c
select distinct country from publishers;
select * from publishers;

-- 3.d
select pub_id "Publishers Identity", pub_name "Publishers Name" from publishers;

-- 3.e
select concat(pub_id, ' Publishers Name is : ' , pub_name) AS "ID and Name" from publishers;

-- titles table
-- 4.a
select * from titles;
select title_id, title, price from titles;

-- 4.b, 4.c
SELECT title_id,price,5+price,ytd_sales,5*ytd_sales  FROM titles;

-- 4.d
SELECT title_id,price,5+price "Revised Price",ytd_sales,5*ytd_sales "Forecased Sales"  FROM titles;
SELECT title_id, price, price + 5 "Revised Price", ytd_sales, ytd_sales * 5 "Forecasted Sales" FROM titles;

-- 4.e
select * from titles where notes IN(select notes from titles group by notes)  IS NULL;

-- 5
select * from publishers;
select * from publishers where state='MA';

-- 6
select * from publishers where country='USA';

-- 7
select * from titles;
select title, price from titles where price >= 2.9900;
 select title, price from titles where price >= 19.9900;
 
 -- 8 
 select  title, pubdate from titles where pubdate ="1991-06-12";
 
 -- 9
select  title, pubdate from titles where pubdate >="1991-06-30";

-- 10
select title , type from titles where type="business";

-- 11
select title , type from titles where type="psychology";

-- 12
select* from titles;
select title, price, advance from titles where advance between 2000 and 5000;
select title, price, advance from titles where advance not between 2000 and 5000;

-- 13
select title, price, advance from titles where advance NOT IN (4000,5000);
select title, price, advance from titles where advance not between 2000 and 5000;

-- 14
select * from publishers where state='MA' OR state="DC";

-- 15
select * from publishers where state != 'MA';
select * from publishers where state != 'DC';
select * from publishers where state != 'MA' AND state != 'DC';
select * from publishers where not (state='MA' OR state='DC');

-- 16
select * from publishers;
-- using logical operator
select * from publishers where country="Germany" OR country="France";
-- using list operator 
select * from publishers where country IN('Germany','France');

-- 17
select * from titles where ytd_sales IS NULL;

-- 18
 select * from titles;
desc titles; 
select title,price,type from titles where (type IN ('business','mod_cook') and price>10);


-- 19
select * from titles;
select type from titles where type LIKE 'bus%';


-- 20
select * from publishers;
-- select * from publishers where country REGEXP 'us.';
-- select * from publishers where country regexp '^US.';
SELECT * FROM publishers WHERE country LIKE 'US_';

-- 21
select * from titles;
select title_id, title from titles where title_id REGEXP '^P';
select title_id, title from titles where title_id REGEXP '^M';

-- 22
select title_id, title from titles where title_id REGEXP '^P' OR title_id REGEXP '^M';
select title,title_id from titles where title_id REGEXP '^[^PM]';

-- 23
select title_id, title from titles where title_id NOT  REGEXP '^P' AND title_id NOT REGEXP '^M';
select title_id,title from titles where NOT(title_id REGEXP '^P' OR title_id REGEXP '^M');
select title_id,title from titles where title_id REGEXP '^[^PM]';

-- 24
select * from titles;
select title_id, title from titles where title_id LIKE '_C%';
-- using REGEX
select title, title_id from titles where title_id REGEXP '^.C';
-- select title, title_id from titles where title_id REGEXP '.C..';

-- 25
select * from titles;
select title, title_id from titles where title REGEXP '!$';
select  title,title_id from titles where title LIKE '%!';

-- 26
-- author table started 
select * from authors;
select au_id ,au_fname,au_lname from authors where au_id LIKE '___-72%';
select au_id, au_fname, au_lname from authors where au_id LIKE '___-72-____';
select au_id ,au_fname,au_lname from authors where au_id REGEXP '^...-72';


-- 27
select * from authors;
desc authors;
select au_id, au_fname, au_lname from authors where au_id REGEXP '-[5-8].-';

-- 28
select au_id, au_fname, au_lname, address from authors where au_id LIKE '___-08-____' OR  au_id LIKE '___-80-____' AND address REGEXP 'Av.$';
select au_id, au_fname, address from Authors where (au_id REGEXP '-80-|-08-' AND address REGEXP 'av.$');

-- 29
select state ,city,address from authors WHERE city REGEXP '[aeiou]$';
select address, city, state from authors WHERE  RIGHT(city,1) IN('a','e','i','o','u');

-- 30
select address, city, state, contract from authors WHERE contract != 0  and state="CA";