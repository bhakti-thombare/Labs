import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { SharedService } from './../../shared/shared.service';
import { ExcelService } from '../../shared/excel.service';
import * as JSPDF from 'jspdf';
import 'jspdf-autotable';
import { ToastService } from '../../shared/toast.service';

@Component({
  selector: 'app-locations',
  templateUrl: './locations.component.html',
  styleUrls: ['./locations.component.scss']
})
export class LocationsComponent implements OnInit {
  countryCols: any = [];
  stateCols: any = [];
  cityCols: any = [];
  country: any[] = []
  state: any[] = []
  city: any[] = [];

  locationForm!: FormGroup
  addlocationForm!: FormGroup
  addCountryForm!: FormGroup;
  addStateForm!: FormGroup;
  addCityForm!: FormGroup;

  selectedValue!: any;

  countries: any=[];
  states: any=[];
  cities: any=[];
  
  locations: any[] = [
    { name: 'Country', id: '1' },
    { name: 'State', id: '2' },
    { name: 'City', id: '3' }
  ];
  filterCountryColumField: any = [
    { field: 'countryCode', header: 'Country Code' },
    { field: 'countryName', header: 'Country Name' },
  ];

  filterStatesColumField:any=[
    { field: 'stateCode', header: 'State Code' },
    { field: 'stateName', header: 'State Name' },
  ];

  filterCityColumField:any=[
    { field: 'cityCode', header: 'City Code' },
    { field: 'cityName', header: 'City Name' },
  ];

  submitted = false;
  pageNo: number = 0;
  pageSize: number = 10;
  loader: boolean = true;
  totalUserDetailsCount!: any;
  selectedTabIndex = 0;
  hasFilteredData: any = {};


  constructor(private modalService: NgbModal, private fb: FormBuilder,
    private _shared: SharedService, private toast: ToastService) {
    this._shared.sendpageTitle('LOCATIONS');

    this.locationForm = this.fb.group({
      country: ['', Validators.required],
      state: ['', Validators.required],
      city: ['', Validators.required],
    })

    this.addlocationForm = this.fb.group({
      locations: ['', Validators.required],
    })

    this.addCountryForm = this.fb.group({
      countryCode: ['', [Validators.required, Validators.maxLength(18)]],
      countryName: ['', [Validators.required, Validators.maxLength(150)]],
      isActive: ['false'],
    })

    this.addStateForm = this.fb.group({
      countryCode: ['', Validators.required],
      stateCode: ['', [Validators.required, Validators.maxLength(18)]],
      stateName: ['', [Validators.required, Validators.maxLength(150)]],
      isActive: ['false'],
    })

    this.addCityForm = this.fb.group({
      countryCode: ['', Validators.required],
      stateCode: ['', Validators.required],
      cityCode: ['', [Validators.required, Validators.maxLength(18)]],
      cityName: ['', [Validators.required, Validators.maxLength(150)]],
      isActive: ['false'],
    })

  }

  ngOnInit() {
    this.getUserColumns();
    this.getCountryList();
    this.getCountries(this.pageNo, this.pageSize);
    // this.getStateList();

    // this.getCityList();
  }

  optionSelected(value: string) {
    console.log("the selected value is " + value);
  }

  selectedOption(selectedValue: any) {
    this.selectedValue = selectedValue;
    console.log(this.selectedValue);
  }


  getCountryList() {
    this._shared.get('Country/GetCountryList', 'admin').subscribe(res => {
      this.country = res;
    });
  }

  getStateList() {
    this._shared.get('State/GetStateList', 'admin').subscribe(res => {
      this.state = res;
    });
  }

  getCityList(e:any) {
    this._shared.get('City/GetCityList', 'admin').subscribe(res => {
      let city = res.filter((itm: any) => itm.stateCode == e.target.value);
      this.city = city;
    });
  }


  changeCountry(e: any) {
    this._shared.get('State/GetStateList', 'admin').subscribe(res => {
      let state = res.filter((itm: any) => itm.countryCode == e.target.value);
      this.state = state;   
    });
  }

  // changeCountry(e: any,pageNo:number, pageSize:number) {
  //   let obj = {
  //     pageNumber: pageNo,
  //     pageSize: pageSize,
  //   }

  //   this._shared.post('State/GetStates',obj, 'admin').subscribe(res => {
  //     let state = res.filter((itm: any) => itm.countryCode == e.target.value);
  //     this.state = state;   
  //   });
  // }

  changeState(e: any,pageNo:number, pageSize:number) {
    let obj = {
      pageNumber: pageNo,
      pageSize: pageSize,
    }
    this._shared.post('City/GetCities', obj, 'admin').subscribe(res => {
      let city = res.filter((itm: any) => itm.stateCode == e.target.value);
      this.city = city;
    });
  }

  get formControl() {
    return this.locationForm.controls;
  }

  get locationFormControl() {
    return this.addlocationForm.controls;
  }

  get addCountryFormControl() {
    return this.addCountryForm.controls;
  }

  get addStateFormControl() {
    return this.addStateForm.controls;
  }

  get addCityFormControl(){
    return this.addCityForm.controls;
  }

  //Country Start
  openCountry(content: any) {
    this.createCountry();
  }

  createCountry(){
    this.addCountryForm.value.countryCode = this.addCountryForm.value.countryCode;
    this.addCountryForm.value.countryName = this.addCountryForm.value.countryName;
    this.addCountryForm.value.isActive = this.addCountryForm.value.isActive ? true : false,
    this.addCountryForm.value.createdBy = sessionStorage.getItem('username');
    this.addCountryForm.value.modifiedBy = sessionStorage.getItem('username');

    this._shared.post('Country/CreateCountry', this.addCountryForm.value, 'admin').subscribe(res => {
      this.toast.show("Records saved successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      this.addCountryForm.reset();
      this.getCountries(this.pageNo, this.pageSize)
    });
  }

  getCountries(pageNo: number, pageSize: number){
    let obj = {
      pageNumber: pageNo,
      pageSize: pageSize
    }
    this._shared.post('Country/GetCountries', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.countries = res.item2;
    });
  }

  //Country End

  //State Start
  openState(content: any) {
  this.createState();
  }

  createState(){
    this.addStateForm.value.countryCode = this.addStateForm.value.countryCode;
    this.addStateForm.value.stateCode = this.addStateForm.value.stateCode;
    this.addStateForm.value.stateName = this.addStateForm.value.stateName;
    this.addStateForm.value.isActive = this.addStateForm.value.isActive ? true : false,
    this.addStateForm.value.createdBy = sessionStorage.getItem('username');
    this.addStateForm.value.modifiedBy = sessionStorage.getItem('username');

    this._shared.post('State/CreateState', this.addStateForm.value, 'admin').subscribe(res => {
      this.toast.show("Records saved successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      this.addStateForm.reset();
      this.getStates(this.pageNo, this.pageSize)
    });
  }

  getStates(pageNo: number, pageSize: number){
    let obj = {
      pageNumber: pageNo,
      pageSize: pageSize
    }
    this._shared.post('State/GetStates', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.states = res.item2;
    });
  }

  //State End

  //City Start
  openCity(content: any){
    this.createCity();
  }

  createCity(){
    this.addCityForm.value.countryCode = this.addCityForm.value.countryCode;
    // this.addCityForm.value.state = this.addCityForm.value.state;
    this.addCityForm.value.stateCode = this.addCityForm.value.stateCode;

    this.addCityForm.value.cityCode = this.addCityForm.value.cityCode;
    this.addCityForm.value.cityName = this.addCityForm.value.cityName;
    this.addCityForm.value.isActive = this.addCityForm.value.isActive ? true : false,
    this.addCityForm.value.createdBy = sessionStorage.getItem('username');
    this.addCityForm.value.modifiedBy = sessionStorage.getItem('username');

    this._shared.post('City/CreateCity', this.addCityForm.value, 'admin').subscribe(res => {
      this.toast.show("Records saved successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      this.addStateForm.reset();
      this.getCities(this.pageNo, this.pageSize)
    });
  }
  getCities(pageNo: number, pageSize: number){
    let obj = {
      pageNumber: pageNo,
      pageSize: pageSize
    }
    this._shared.post('City/GetCities', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.cities = res.item2;
    });
  }

  //City End

  getUserColumns() {
    this.countryCols = [
      { field: 'countryCode', header: 'Country Code' },
      { field: 'countryName', header: 'country Name' },
      { field: 'isActive', header: 'Status' },
      { field: 'Action', header: 'Action' },
    ];

    this.stateCols = [
      { field: 'stateCode', header: 'State Code' },
      { field: 'stateName', header: 'State Name' },
      { field: 'countryCode', header: 'Country Code' },
      { field: 'isActive', header: 'Status' },
      { field: 'Action', header: 'Action' },
    ];

    this.cityCols = [
      { field: 'cityCode', header: 'City Code' },
      { field: 'cityName', header: 'City Name' },
      { field: 'stateName', header: 'State Name' },
      { field: 'isActive', header: 'Status' },
      { field: 'Action', header: 'Action' },

    ]

  }

  refresh(event: any) {
    if (event) {
      this.getCountries(this.pageNo, this.pageSize);
      this.hasFilteredData = {};
      this.getStates(this.pageNo, this.pageSize);
      this.getCities(this.pageNo, this.pageSize)
      
    }
  }

  filterCountryData(evntData: any) {
    evntData.pageSize = this.pageSize;
    evntData.pageNo = this.pageNo;
    this._shared.post('Country/SearchCountries', evntData, 'admin').subscribe(res => {
      this.loader = false;
      this.countries = res.item2;
      this.hasFilteredData = evntData;
    //   this.totalUserDetailsCount = res.item1;
    });
  }

  filterStateData(evntData: any) {
    evntData.pageSize = this.pageSize;
    evntData.pageNo = this.pageNo;
    this._shared.post('State/SearchStates', evntData, 'admin').subscribe(res => {
      this.loader = false;
      this.state = res.item2;
      this.hasFilteredData = evntData;
    //   this.totalUserDetailsCount = res.item1;
    });
  }

  filterCityData(evntData: any) {
    evntData.pageSize = this.pageSize;
    evntData.pageNo = this.pageNo;
    this._shared.post('City/SearchCities', evntData, 'admin').subscribe(res => {
      this.loader = false;
      this.city = res.item2;
      this.hasFilteredData = evntData;
    //   this.totalUserDetailsCount = res.item1;
    });
  }

  onPageChange(event: any) {
    // this.getCountries(event.page, event.rows);
    // this.getStates(event.page, event.rows)
    // this.getCities(event.page, event.rows)
    this.getCountryList();


   
  }
  
  onPageChangeState(event: any) {
    // this.getCountries(event.page, event.rows);
    // this.getStates(event.page, event.rows)
    // this.getCities(event.page, event.rows)
    this.getStateList();


   
  }

  tabChange(e: any) {
    // this.getCountryList();
    // this.getStateList();
    // this.getCityList();
    e.target.value = ""
  }

  ngOnDestroy() {
    //this.subscription.unsubscribe();
  }
  
  //edit country
  cloneRecordCountry:any ={};
  onRowEditInitCountry(data:any){
    this.cloneRecordCountry[data.countryId] = {...data};
  }

  onRowEditSaveCountry(data: any){
    this.addCountryForm.value.countryId = data.countryId;
    this.addCountryForm.value.countryCode = data.countryCode;
    this.addCountryForm.value.countryName = data.countryName;
    
    this.addCountryForm.value.isActive = data.isActive ? true : false,
    this.addCountryForm.value.createdBy = sessionStorage.getItem('username');
    this.addCountryForm.value.modifiedBy = sessionStorage.getItem('username');

    this._shared.put('Country/UpdateCountry', this.addCountryForm.value, 'admin').subscribe(res => {
      this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      this.getCountries(0, 10);
    });
  }

  onRowEditCancelCountry(data: any){
    this.getCountries(this.pageNo, this.pageSize);
  }

  //edit State
  cloneRecordState:any ={};
  onRowEditInitState(data:any){
    this.cloneRecordState[data.stateId] = {...data};
  }

  onRowEditSaveState(data: any){
    this.addStateForm.value.stateId = data.stateId;
    this.addStateForm.value.stateCode = data.stateCode;
    this.addStateForm.value.stateName = data.stateName;
    this.addStateForm.value.countryCode = data.countryCode;
    
    this.addStateForm.value.isActive = data.isActive ? true : false,
    this.addStateForm.value.createdBy = sessionStorage.getItem('username');
    this.addStateForm.value.modifiedBy = sessionStorage.getItem('username');

    this._shared.put('State/UpdateState', this.addStateForm.value, 'admin').subscribe(res => {
      this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      this.getStates(0, 10);
    });
  }

  onRowEditCancelState(data: any){
    this.getStates(this.pageNo, this.pageSize);
  }

  //edit city
  cloneRecordCity:any ={};
  onRowEditInitCity(data:any){
    this.cloneRecordCity[data.cityId] = {...data};
  }

  onRowEditSaveCity(data: any){
    this.addCityForm.value.cityId = data.cityId;
    this.addCityForm.value.cityCode = data.cityCode;
    this.addCityForm.value.cityName = data.cityName;
    this.addCityForm.value.countryCode = data.countryCode;
    this.addCityForm.value.stateCode = data.stateCode;
   
    
    this.addCityForm.value.isActive = data.isActive ? true : false,
    this.addCityForm.value.createdBy = sessionStorage.getItem('username');
    this.addCityForm.value.modifiedBy = sessionStorage.getItem('username');

    this._shared.put('City/UpdateCity', this.addCityForm.value, 'admin').subscribe(res => {
      this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      this.getCities(0, 10);
    });
  }

  onRowEditCancelCity(data: any){
    this.getCities(this.pageNo, this.pageSize);
  }

 

}



<app-loader></app-loader>
<p-tabView [(activeIndex)]="selectedTabIndex" (onChange)="tabChange($event)">
  <p-tabPanel header="Countries">
    <div class="loationWrapper shadow-sm">
      <div class="align-items-center d-flex mb-2 m-0 row">
        <div class="col-12 col-sm-5 ps-0 text-center text-sm-start">
        </div>
        <div class="col-12 col-sm-2 pe-2 text-end" style="font-size: 24px;">

        </div>
        <div class="col-12 col-sm-5 px-1">
          <app-filter (reload)="refresh($event)" (filter)="filterCountryData($event)"
            [dropdownFilterItems]="filterCountryColumField">
          </app-filter>
        </div>
      </div>

      <p-table [value]="countries" editMode="row" dataKey="countryId" [columns]="countryCols" [paginator]="false"
        [rows]="5" responsiveLayout="scroll" [showCurrentPageReport]="true" currentPageReportTemplate="Total entries :
    {{countries.length}}" [responsive]="true" [autoLayout]="true" [rowsPerPageOptions]="[5, 10,50, 100]">
        <ng-template pTemplate="header">
          <tr>
            <th class="tableHeader" *ngFor="let col of countryCols" [pSortableColumn]="col.field">
              {{ col.header }}
              <p-sortIcon *ngIf="col.header != 'Action'" [field]="col.field"></p-sortIcon>
            </th>
          </tr>
        </ng-template>
        <ng-template pTemplate="body" let-rowdata let-editing="editing" let-ri="rowIndex">
          <tr [pEditableRow]="rowdata">

            <td style="width: 25%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <input pInputText type="text" [(ngModel)]="rowdata.countryCode" [style]="{'width':'100%'}" />
                </ng-template>
                <ng-template pTemplate="output">
                  {{ rowdata.countryCode }}
                </ng-template>
              </p-cellEditor>
            </td>

            <td style="width: 25%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <input pInputText type="text" [(ngModel)]="rowdata.countryName" [style]="{'width':'100%'}" />
                </ng-template>
                <ng-template pTemplate="output">
                  {{ rowdata.countryName }}
                </ng-template>
              </p-cellEditor>
            </td>

            <td style="width: 25%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <label class="pe-2">Active</label>
                  <input type="checkbox" class="form-check-input" [(ngModel)]="rowdata.isActive"
                    [checked]="rowdata.isActive" />
                </ng-template>
                <ng-template pTemplate="output">
                  {{rowdata.isActive }}
                </ng-template>
              </p-cellEditor>
            </td>

            <td style="width: 25%;">
              <button style="color: #343a40;" *ngIf="!editing" pButton pRipple type="button" pInitEditableRow
                icon="pi pi-pencil" (click)="onRowEditInitCountry(rowdata)"
                class="p-button-rounded p-button-text"></button>
              <button *ngIf="editing" pButton pRipple type="button" pSaveEditableRow icon="pi pi-check"
                (click)="onRowEditSaveCountry(rowdata)"
                class="p-button-rounded p-button-text p-button-success p-mr-2"></button>
              <button *ngIf="editing" pButton pRipple type="button" pCancelEditableRow icon="pi pi-times"
                (click)="onRowEditCancelCountry(rowdata)"
                class="p-button-rounded p-button-text p-button-danger"></button>
            </td>
          </tr>
        </ng-template>
        <ng-template pTemplate="emptymessage" let-columns>
          <tr>
            <td [attr.colspan]="columns.length+2">
              <div class="py-3 text-center textColor">No records found</div>
            </td>
          </tr>
        </ng-template>
      </p-table>
      <div style="position:relative;" class="align-items-center d-flex justify-content-between">
        <span class="ps-2 textColor">Showing : <strong class="textColor">{{countries.length}}</strong> entries
        </span>
        <p-paginator *ngIf="countries" [rows]="5" [totalRecords]="totalUserDetailsCount"
          [rowsPerPageOptions]="[5, 10, 50, 100]" (onPageChange)="onPageChange($event)">
        </p-paginator>
        <span class="pe-2 textColor">Total records : <strong class="textColor">{{countries.length}}</strong>
        </span>
      </div>


    </div>
  </p-tabPanel>

  <p-tabPanel header="States">
    <div class="loationWrapper shadow-sm">
      <div class="align-items-center d-flex mb-2 m-0 row">
        <label for="country">Select Country<span class="mandatoryField">*</span></label>
        <div class="col-12 col-sm-5 ps-0 text-center text-sm-start">
          <!-- <label for="country">Country<span class="mandatoryField">*</span></label> -->
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-puzzle-piece"></i></span>
            <select (change)="changeCountry($event)" id=" country" formControlName="country" name="country"
              [ngClass]="{ 'is-invalid': submitted && formControl.country.errors }"
              class="form-control form-select cursor">
              <option [ngValue]="null" disabled selected>Select Country</option>
              <option value="{{c.countryCode}}" *ngFor="let c of country">{{c.countryName}}</option>
            </select>
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.country.invalid && (formControl.country.dirty || formControl.country.touched)">
              <div *ngIf="formControl.country.invalid">Country is required</div>
            </div>
          </div>
        </div>
        <div class="col-12 col-sm-2 pe-2 text-end" style="font-size: 24px;">

        </div>
        <div class="col-12 col-sm-5 px-1">
          <app-filter (reload)="refresh($event)" (filter)="filterStateData($event)"
            [dropdownFilterItems]="filterStatesColumField">
          </app-filter>
        </div>
      </div>
      <div class="form-group  col-6 col-sm-4 pb-3">
        <!-- <label for="country">Country<span class="mandatoryField">*</span></label>
        <div class="input-group">
          <span class="input-group-text" id="basic-addon1"><i class="fas fa-puzzle-piece"></i></span>
          <select (change)="changeCountry($event)" id=" country" formControlName="country" name="country"
            [ngClass]="{ 'is-invalid': submitted && formControl.country.errors }"
            class="form-control form-select cursor">
            <option [ngValue]="null" disabled selected>Select Country</option>
            <option value="{{c.countryCode}}" *ngFor="let c of countries">{{c.countryName}}</option>
          </select>
          <div class="p-0 invalid-feedback"
            *ngIf="formControl.country.invalid && (formControl.country.dirty || formControl.country.touched)">
            <div *ngIf="formControl.country.invalid">Country is required</div>
          </div>
        </div> -->
      </div>

      <p-table [value]="state" editMode="row" dataKey="stateId" [columns]="stateCols" [paginator]="false" [rows]="5"
        responsiveLayout="scroll" [showCurrentPageReport]="true" currentPageReportTemplate="Total entries :
    {{state.length}}" [responsive]="true" [autoLayout]="true" [rowsPerPageOptions]="[5, 10,50, 100]">
        <ng-template pTemplate="header">
          <tr>
            <th class="tableHeader" *ngFor="let col of stateCols" [pSortableColumn]="col.field">
              {{ col.header }}
              <p-sortIcon *ngIf="col.header != 'Action'" [field]="col.field"></p-sortIcon>
            </th>
          </tr>
        </ng-template>
        <ng-template pTemplate="body" let-rowdata let-editing="editing" let-ri="rowIndex">
          <tr [pEditableRow]="rowdata">

            <td style="width: 25%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <input pInputText type="text" [(ngModel)]="rowdata.stateCode" [style]="{'width':'100%'}" />
                </ng-template>
                <ng-template pTemplate="output">
                  {{ rowdata.stateCode }}
                </ng-template>
              </p-cellEditor>
            </td>

            <td style="width: 25%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <input pInputText type="text" [(ngModel)]="rowdata.stateName" [style]="{'width':'100%'}" />
                </ng-template>
                <ng-template pTemplate="output">
                  {{ rowdata.stateName }}
                </ng-template>
              </p-cellEditor>
            </td>

            <td style="width: 25%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <input pInputText type="text" [(ngModel)]="rowdata.countryCode" [style]="{'width':'100%'}" />
                </ng-template>
                <ng-template pTemplate="output">
                  {{ rowdata.countryCode }}
                </ng-template>
              </p-cellEditor>
            </td>

            <td style="width: 25%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <label class="pe-2">Active</label>
                  <input type="checkbox" class="form-check-input" [(ngModel)]="rowdata.isActive"
                    [checked]="rowdata.isActive" />
                </ng-template>
                <ng-template pTemplate="output">
                  {{rowdata.isActive }}
                </ng-template>
              </p-cellEditor>
            </td>

            <td style="width: 25%;">
              <button style="color: #343a40;" *ngIf="!editing" pButton pRipple type="button" pInitEditableRow
                icon="pi pi-pencil" (click)="onRowEditInitState(rowdata)"
                class="p-button-rounded p-button-text"></button>
              <button *ngIf="editing" pButton pRipple type="button" pSaveEditableRow icon="pi pi-check"
                (click)="onRowEditSaveState(rowdata)"
                class="p-button-rounded p-button-text p-button-success p-mr-2"></button>
              <button *ngIf="editing" pButton pRipple type="button" pCancelEditableRow icon="pi pi-times"
                (click)="onRowEditCancelState(rowdata)"
                class="p-button-rounded p-button-text p-button-danger"></button>
            </td>

          </tr>
        </ng-template>
        <ng-template pTemplate="emptymessage" let-columns>
          <tr>
            <td [attr.colspan]="columns.length+2">
              <div class="py-3 text-center textColor">No records found</div>
            </td>
          </tr>
        </ng-template>
      </p-table>
      <div style="position:relative;" class="align-items-center d-flex justify-content-between">
        <span class="ps-2 textColor">Showing : <strong class="textColor">{{state.length}}</strong> entries
        </span>
        <p-paginator *ngIf="state" [rows]="5" [totalRecords]="totalUserDetailsCount"
          [rowsPerPageOptions]="[5, 10, 50, 100]" (onPageChange)="onPageChangeState($event)">
        </p-paginator>
        <span class="pe-2 textColor">Total records : <strong class="textColor">{{state.length}}</strong>
        </span>
      </div>
    </div>
  </p-tabPanel>

  <p-tabPanel header="Cities">
    <div class="loationWrapper shadow-sm">
      <div class="align-items-center d-flex mb-2 m-0 row col-sm-12">
        <div class="col-12 col-sm-3 ps-0 text-center text-sm-start">
          <label for="country">Select Country<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-puzzle-piece"></i></span>
            <select (change)="changeCountry($event)" id=" country" formControlName="country" name="country"
              [ngClass]="{ 'is-invalid': submitted && formControl.country.errors }"
              class="form-control form-select cursor">
              <option [ngValue]="null" disabled selected>Select Country</option>
              <option value="{{c.countryCode}}" *ngFor="let c of country">{{c.countryName}}</option>
            </select>
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.country.invalid && (formControl.country.dirty || formControl.country.touched)">
              <div *ngIf="formControl.country.invalid">Country is required</div>
            </div>
          </div>
        </div>
        <div class="col-12 col-sm-3">
          <label for="state">Select State<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-at"></i></span>
            <select (change)="changeState($event,0,10)" id="state" formControlName="state" name="country"
              [ngClass]="{ 'is-invalid': submitted && formControl.state.errors }" class="form-control form-select
            cursor">
              <option [ngValue]="null" disabled>Select State</option>
              <option value="{{s.stateCode}}" *ngFor="let s of state">{{s.stateName}}</option>
            </select>
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.state.invalid && (formControl.state.dirty || formControl.state.touched)">
              <div *ngIf="formControl.state.invalid">State is required</div>
            </div>
          </div>

        </div>
        <!-- <div class="col-12 col-sm-6  text-end" style="font-size: 24px;">

        </div> -->
        <div class="col-13 col-sm-6 px-5 pt-4">
          <app-filter (reload)="refresh($event)" (filter)="filterCityData($event)"
            [dropdownFilterItems]="filterCityColumField">
          </app-filter>
        </div>
      </div>
      <!-- <div class="row pb-3">
        <div class="form-group  col-12 col-sm-4 padTopZero">
          <label for="country">Country<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-puzzle-piece"></i></span>
            <select (change)="changeCountry($event)" id=" country" formControlName="country" name="country"
              [ngClass]="{ 'is-invalid': submitted && formControl.country.errors }"
              class="form-control form-select cursor">
              <option [ngValue]="null" disabled selected>Select Country</option>
              <option value="{{c.countryCode}}" *ngFor="let c of countries">{{c.countryName}}</option>
            </select>
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.country.invalid && (formControl.country.dirty || formControl.country.touched)">
              <div *ngIf="formControl.country.invalid">Country is required</div>
            </div>
          </div>
        </div>

        <div class="form-group col-12 col-sm-4 padTopZero">
          <label for="state">State<span class="mandatoryField">*</span></label>
          <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fas fa-at"></i></span>
            <select (change)="changeState($event)" id="state" formControlName="state" name="country"
              [ngClass]="{ 'is-invalid': submitted && formControl.state.errors }" class="form-control form-select
            cursor">
              <option [ngValue]="null" disabled>Select State</option>
              <option value="{{s.stateCode}}" *ngFor="let s of state">{{s.stateName}}</option>
            </select>
            <div class="p-0 invalid-feedback"
              *ngIf="formControl.state.invalid && (formControl.state.dirty || formControl.state.touched)">
              <div *ngIf="formControl.state.invalid">State is required</div>
            </div>
          </div>
        </div>
      </div> -->

      <p-table [value]="city" editMode="row" dataKey="cityId" [columns]="cityCols" [paginator]="false" [rows]="5"
        responsiveLayout="scroll" [showCurrentPageReport]="true" currentPageReportTemplate="Total entries :
    {{city.length}}" [responsive]="true" [autoLayout]="true" [rowsPerPageOptions]="[5, 10,50, 100]">
        <ng-template pTemplate="header">
          <tr>
            <th class="tableHeader" *ngFor="let col of cityCols" [pSortableColumn]="col.field">
              {{ col.header }}
              <p-sortIcon *ngIf="col.header != 'Action'" [field]="col.field"></p-sortIcon>
            </th>
          </tr>
        </ng-template>
        <ng-template pTemplate="body" let-rowdata let-editing="editing" let-ri="rowIndex">
          <tr [pEditableRow]="rowdata">

            <td style="width: 20%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <input pInputText type="text" [(ngModel)]="rowdata.cityCode" [style]="{'width':'100%'}" />
                </ng-template>
                <ng-template pTemplate="output">
                  {{rowdata.cityCode}}
                </ng-template>
              </p-cellEditor>
            </td>

            <td style="width: 20%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <input pInputText type="text" [(ngModel)]="rowdata.cityName" [style]="{'width':'100%'}" />
                </ng-template>
                <ng-template pTemplate="output">
                  {{rowdata.cityName}}
                  </ng-template>
                  </p-cellEditor>
                </td>
            <td style="width: 20%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <input pInputText type="text" [(ngModel)]="rowdata.stateCode" [style]="{'width':'100%'}" />
                </ng-template>
                <ng-template pTemplate="output">
              {{rowdata.stateCode}}
            </ng-template>
            </p-cellEditor>
            </td>

            <td style="width: 25%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <label class="pe-2">Active</label>
                  <input type="checkbox" class="form-check-input" [(ngModel)]="rowdata.isActive"
                    [checked]="rowdata.isActive" />
                </ng-template>
                <ng-template pTemplate="output">
                  {{rowdata.isActive }}
                </ng-template>
              </p-cellEditor>
            </td>

            <td style="width: 25%;">
              <button style="color: #343a40;" *ngIf="!editing" pButton pRipple type="button" pInitEditableRow
                icon="pi pi-pencil" (click)="onRowEditInitCity(rowdata)"
                class="p-button-rounded p-button-text"></button>
              <button *ngIf="editing" pButton pRipple type="button" pSaveEditableRow icon="pi pi-check"
                (click)="onRowEditSaveCity(rowdata)"
                class="p-button-rounded p-button-text p-button-success p-mr-2"></button>
              <button *ngIf="editing" pButton pRipple type="button" pCancelEditableRow icon="pi pi-times"
                (click)="onRowEditCancelCity(rowdata)"
                class="p-button-rounded p-button-text p-button-danger"></button>
            </td>


          </tr>
        </ng-template>
        <ng-template pTemplate="emptymessage" let-columns>
          <tr>
            <td [attr.colspan]="columns.length+2">
              <div class="py-3 text-center textColor">No records found</div>
            </td>
          </tr>
        </ng-template>
      </p-table>
      <div style="position:relative;" class="align-items-center d-flex justify-content-between">
        <span class="ps-2 textColor">Showing : <strong class="textColor">{{city.length}}</strong> entries
        </span>
        <p-paginator *ngIf="city" [rows]="5" [totalRecords]="totalUserDetailsCount"
          [rowsPerPageOptions]="[5, 10, 50, 100]" (onPageChange)="onPageChange($event)">
        </p-paginator>
        <span class="pe-2 textColor">Total records : <strong class="textColor">{{city.length}}</strong>
        </span>
      </div>
    </div>
  </p-tabPanel>

  <p-tabPanel header="Add">
    <div class="form-group  col-6 col-sm-4 pb-3">
      <label for="locations">Add <span class="mandatoryField">*</span></label>
      <div class="input-group">
        <span class="input-group-text" id="basic-addon1"><i class="fas fa-puzzle-piece"></i></span>
        <!-- <select  id="locations" formControlName="locations" name="locations" [(ngModel)]="locations"   #mySelect  
          (change)='optionSelected(mySelect.value)'  
         [ngClass]="{ 'is-invalid': submitted && locationFormControl.locations.errors }"
            class="form-control form-select cursor"> -->
        <select id="locations" formControlName="locations" name="locations" [(ngModel)]="locations" #mySelect
          (change)="selectedOption(mySelect.value)"
          [ngClass]="{ 'is-invalid': submitted && locationFormControl.locations.errors }"
          class="form-control form-select cursor">
          <option [ngValue]="null" disabled selected>Select Country</option>

          <!-- <option *ngFor="let loc of locations" [value]="loc.id">
            {{loc.name}}
            </option> -->
          <option id="1" value="Country">Country</option>
          <option id="2" value="State">State</option>
          <option id="3" value="City">City</option>
        </select>
        <div class="p-0 invalid-feedback"
          *ngIf="locationFormControl.locations.invalid && (locationFormControl.locations.dirty || locationFormControl.locations.touched)">
          <div *ngIf="locationFormControl.locations.invalid">Option is required</div>
        </div>
      </div>
    </div>

    <div *ngIf="this.selectedValue== 'Country'">
      <h1>Add Country</h1>
      <form [formGroup]="addCountryForm" (ngSubmit)="openCountry(addCountryForm)">
        <div class="row">

          <div class="form-group col-12 col-sm-4 padTopZero">
            <label for="countryCode">Country Code<span class="mandatoryField">*</span></label>
            <div class="input-group">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
              <input type="text" formControlName="countryCode" id="countryCode" placeholder="Country Code"
                name="countryCode" [ngClass]="{ 'is-invalid': submitted  }" class="form-control">
              <div class="p-0 invalid-feedback" *ngIf="addCountryFormControl.countryCode.invalid && addCountryFormControl.countryCode.errors && (addCountryFormControl.countryCode.dirty ||
                addCountryFormControl.countryCode.touched)">
                <div *ngIf="addCountryFormControl.countryCode.errors.required">Country Code Id is required</div>
                <div *ngIf="addCountryFormControl.countryCode.errors.maxlength">Country Codecan be max 18 characters
                  long.</div>
              </div>
            </div>
          </div>

          <div class="form-group col-12 col-sm-4 padTopZero">
            <label for="countryName">Country Name<span class="mandatoryField">*</span></label>
            <div class="input-group">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
              <input type="text" formControlName="countryName" id="countryName" placeholder="Country Name"
                name="countryName" [ngClass]="{ 'is-invalid': submitted  }" class="form-control">
              <div class="p-0 invalid-feedback" *ngIf="addCountryFormControl.countryName.invalid && addCountryFormControl.countryName.errors && (addCountryFormControl.countryName.dirty ||
                addCountryFormControl.countryName.touched)">
                <div *ngIf="addCountryFormControl.countryName.errors.required">Country Name Id is required</div>
                <div *ngIf="addCountryFormControl.countryName.errors.maxlength">Country Codecan be max 150 characters
                  long.</div>
              </div>
            </div>
          </div>
          <div class="align-items-center col-6 col-sm-4 d-flex">
            <div class="" style="margin-top: 20px;">
              <span for="isActive" class="pe-2">Active</span>
              <input formControlName="isActive" class="form-check-input" type="checkbox"
                [ngClass]="{ 'is-invalid': submitted && addCountryFormControl.isActive.errors }" value=""
                id="defaultCheck1">
            </div>
            <div class="p-0 invalid-feedback"
              *ngIf="addCountryFormControl.isActive.invalid && (addCountryFormControl.isActive.dirty || addCountryFormControl.isActive.touched)">
              <div *ngIf="addCountryFormControl.isActive.invalid">Status is required</div>
            </div>
          </div>
          <div class="form-group pt-7 ">
            <button type="button" class="btn btn-success" (click)="createCountry()"
              [disabled]="!addCountryForm.valid">Add
              Country</button>
          </div>
        </div>
      </form>

    </div>

    <div *ngIf="this.selectedValue== 'State'">

      <h1>Add State</h1>
      <form [formGroup]="addStateForm" (ngSubmit)="openState(addStateForm)">
        <div class="row">

          <div class="form-group  col-6 col-sm-4 pb-3 padTopZero">
            <label for="countryCode">Country<span class="mandatoryField">*</span></label>
            <div class="input-group">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-puzzle-piece"></i></span>
              <select (change)="changeCountry($event)" id=" countryCode" formControlName="countryCode"
                name="countryCode" [ngClass]="{ 'is-invalid': submitted && addStateFormControl.countryCode.errors }"
                class="form-control form-select cursor">
                <option [ngValue]="null" disabled selected>Select Country</option>
                <option value="{{c.countryCode}}" *ngFor="let c of countries">{{c.countryName}}</option>
              </select>
              <div class="p-0 invalid-feedback"
                *ngIf="addStateFormControl.countryCode.invalid && (addStateFormControl.countryCode.dirty || addStateFormControl.countryCode.touched)">
                <div *ngIf="addStateFormControl.countryCode.invalid">Country is required</div>
              </div>
            </div>
          </div>

          <div class="form-group col-12 col-sm-4 padTopZero">
            <label for="stateCode">State Code<span class="mandatoryField">*</span></label>
            <div class="input-group">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
              <input type="text" formControlName="stateCode" id="stateCode" placeholder="State Code" name="stateCode"
                [ngClass]="{ 'is-invalid': submitted  }" class="form-control">
              <div class="p-0 invalid-feedback" *ngIf="addStateFormControl.stateCode.invalid && addStateFormControl.stateCode.errors && (addStateFormControl.stateCode.dirty ||
                addStateFormControl.stateCode.touched)">
                <div *ngIf="addStateFormControl.stateCode.errors.required">State Code Id is required</div>
                <div *ngIf="addStateFormControl.stateCode.errors.maxlength">State Code can be max 18 characters long.
                </div>
              </div>
            </div>
          </div>

          <div class="form-group col-12 col-sm-4 padTopZero">
            <label for="stateName">State Name<span class="mandatoryField">*</span></label>
            <div class="input-group">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
              <input type="text" formControlName="stateName" id="stateName" placeholder="State Name" name="stateName"
                [ngClass]="{ 'is-invalid': submitted  }" class="form-control">
              <div class="p-0 invalid-feedback" *ngIf="addStateFormControl.stateName.invalid && addStateFormControl.stateName.errors && (addStateFormControl.stateName.dirty ||
                addStateFormControl.stateName.touched)">
                <div *ngIf="addStateFormControl.stateName.errors.required">State Name Id is required</div>
                <div *ngIf="addStateFormControl.stateName.errors.maxlength">State Codecan be max 150 characters long.
                </div>
              </div>
            </div>
          </div>

          <div class="align-items-center col-6 col-sm-4 d-flex">
            <div class="" style="margin-top: 20px;">
              <span for="isActive" class="pe-2">Active</span>
              <input formControlName="isActive" class="form-check-input" type="checkbox"
                [ngClass]="{ 'is-invalid': submitted && addStateFormControl.isActive.errors }" value=""
                id="defaultCheck1">
            </div>
            <div class="p-0 invalid-feedback"
              *ngIf="addStateFormControl.isActive.invalid && (addStateFormControl.isActive.dirty || addStateFormControl.isActive.touched)">
              <div *ngIf="addStateFormControl.isActive.invalid">Status is required</div>
            </div>
          </div>

          <div class="form-group pt-7 ">
            <button type="button" class="btn btn-success" (click)="createState()" [disabled]="!addStateForm.valid">Add
              State</button>
          </div>
        </div>
      </form>
    </div>

    <div *ngIf="this.selectedValue== 'City'">
      <h1>Add City</h1>
      <form [formGroup]="addCityForm" (ngSubmit)="openCity(addCityForm)">
        <div class="row">

          <div class="form-group  col-12 col-sm-4 padTopZero">
            <label for="countryCode">Country<span class="mandatoryField">*</span></label>
            <div class="input-group">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-puzzle-piece"></i></span>
              <select (change)="changeCountry($event)" id=" countryCode" formControlName="countryCode" name="countryCode"
                [ngClass]="{ 'is-invalid': submitted && addCityFormControl.countryCode.errors }"
                class="form-control form-select cursor">
                <option [ngValue]="null" disabled selected>Select Country</option>
                <option value="{{c.countryCode}}" *ngFor="let c of countries">{{c.countryName}}</option>
              </select>
              <div class="p-0 invalid-feedback"
                *ngIf="addCityFormControl.countryCode.invalid && (addCityFormControl.countryCode.dirty || addCityFormControl.countryCode.touched)">
                <div *ngIf="addCityFormControl.countryCode.invalid">Country is required</div>
              </div>
            </div>
          </div>

          <div class="form-group col-12 col-sm-4 padTopZero">
            <label for="stateCode">State<span class="mandatoryField">*</span></label>
            <div class="input-group">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-at"></i></span>
              <select (change)="changeState($event,0,10)" id="stateCode" formControlName="stateCode" name="stateCode"
                [ngClass]="{ 'is-invalid': submitted && addCityFormControl.stateCode.errors }" class="form-control form-select
                cursor">
                <option [ngValue]="null" disabled selected>Select State</option>
                <option value="{{s.stateCode}}" *ngFor="let s of state">{{s.stateName}}</option>
              </select>
              <div class="p-0 invalid-feedback"
                *ngIf="addCityFormControl.stateCode.invalid && (addCityFormControl.stateCode.dirty || addCityFormControl.stateCode.touched)">
                <div *ngIf="addCityFormControl.stateCode.invalid">State is required</div>
              </div>
            </div>
          </div>

          <div class="form-group col-12 col-sm-4 padTopZero">
            <label for="cityCode">City Code<span class="mandatoryField">*</span></label>
            <div class="input-group">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
              <input type="text" formControlName="cityCode" id="cityCode" placeholder="City Code" name="cityCode"
                [ngClass]="{ 'is-invalid': submitted  }" class="form-control">
              <div class="p-0 invalid-feedback" *ngIf="addCityFormControl.cityCode.invalid && addCityFormControl.cityCode.errors && (addCityFormControl.cityCode.dirty ||
                addCityFormControl.cityCode.touched)">
                <div *ngIf="addCityFormControl.cityCode.errors.required">City Code Id is required</div>
                <div *ngIf="addCityFormControl.cityCode.errors.maxlength">City Codecan be max 18 characters long.</div>
              </div>
            </div>
          </div>

          <div class="form-group col-12 col-sm-4 padTopZero">
            <label for="cityName">City Name<span class="mandatoryField">*</span></label>
            <div class="input-group">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
              <input type="text" formControlName="cityName" id="cityName" placeholder="City Name" name="cityName"
                [ngClass]="{ 'is-invalid': submitted  }" class="form-control">
              <div class="p-0 invalid-feedback" *ngIf="addCityFormControl.cityName.invalid && addCityFormControl.cityName.errors && (addCityFormControl.cityName.dirty ||
                addCityFormControl.cityName.touched)">
                <div *ngIf="addCityFormControl.cityName.errors.required">City Name Id is required</div>
                <div *ngIf="addCityFormControl.cityName.errors.maxlength">City Codecan be max 150 characters long.</div>
              </div>
            </div>
          </div>

          <div class="align-items-center col-6 col-sm-4 d-flex">
            <div class="" style="margin-top: 20px;">
              <span for="isActive" class="pe-2">Active</span>
              <input formControlName="isActive" class="form-check-input" type="checkbox"
                [ngClass]="{ 'is-invalid': submitted && addCityFormControl.isActive.errors }" value=""
                id="defaultCheck1">
            </div>
            <div class="p-0 invalid-feedback"
              *ngIf="addCityFormControl.isActive.invalid && (addCityFormControl.isActive.dirty || addCityFormControl.isActive.touched)">
              <div *ngIf="addCityFormControl.isActive.invalid">Status is required</div>
            </div>
          </div>

          <div class="form-group pt-7 ">
            <button type="button" class="btn btn-success" (click)="createCity()" [disabled]="!addCityForm.valid">Add
              City</button>
          </div>
        </div>
      </form>
    </div>
  </p-tabPanel>

</p-tabView>