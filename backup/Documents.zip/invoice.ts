import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ExcelService } from '../shared/excel.service';
import { ToastService } from '../shared/toast.service';
import { SharedService } from './../shared/shared.service';
import * as JSPDF from 'jspdf'; 
import 'jspdf-autotable';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import html2canvas from 'html2canvas';
import Swal from 'sweetalert2'
import { Router } from '@angular/router';

import {MenuModule} from 'primeng/menu';
// import {MenuItem} from 'primeng/api';
import {StepsModule} from 'primeng/steps';
import {MenuItem} from 'primeng/api';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.scss']
})
export class InvoiceComponent implements OnInit {
//  items!: MenuItem[];
    items!: MenuItem[];
    activeIndex: number = 1;
  getUserDataOnInvoice:any= [];
  cols: any = [];
  frozenCols: any = [];
  woCols: any = [];
  invoiceCols: any = [];
  selectedTabIndex = 0;
  invoiceForm!: FormGroup;
  disputeForm!: FormGroup;
  filterForm!: FormGroup;
  dSignForm!: FormGroup;
  submitted = false;
  pageNo: number = 0;
  pageSize: number = 5;
  totalInvoiceCount!: any;
  subscription!: Subscription;
  filterColumField: any = [
    { field: 'invoiceNo', header: 'Invoice No' },
    { field: 'invoiceDate', header: 'Invoice Date' },
    { field: 'workOrder', header: 'Work Order' },
    { field: 'woValidFrom', header: 'WO Valid From' },
    { field: 'woValidTo', header: 'WO Valid To' },
    { field: 'businessUnit', header: 'Business Unit' },
    { field: 'glCode', header: 'GL Code' },
    { field: 'function', header: 'Function' },
    { field: 'department', header: 'Department' },
    { field: 'section', header: 'Section' },
    { field: 'edit', header: 'Action' }
  ];
  dropdownSettings = {};
  dropdownDeptSettings = {};
  dropdownSecSettings = {};
  getUnitDropdownData:any = [];
  getDeptDropdownData:any = [];
  getSectDropdownData:any = [];
  selectedItems: any = [];
  selectedDeptItems: any = [];
  selectedSectItems: any = [];
  collapsed = false;
  today:any;
  invoiceList:any;
  InvoiceDetails:any;
  unitSelected = false;
  workOrderListCount : any;
  workOrderList : any;
  selectedWorkOrderRow:any = [];
  selectedInvoiceRow:any = [];
  wageSum: any;
  otSum: any;
  marginSum: any;
  totalSum: any;

  totalInvoiceListModalCount:any;
  invoiceListModal:any;

  selectedInvoice = 'service';

  isButtonVisible = true;
  userData: any = [];
  totalUserDetailsCount!: any;
  selectedValue!: string;
  disputeCols: any = [];
  invoiceDisputeList:any = [];
  totalInvoiceDisputeCount:any;
  fileUploadName:any = [];
  acceptForm!: FormGroup;
  totalApprovedInvoiceCount!: any;
  apprCols: any = [];
  approvedInvoiceList: any = [];
  city: any = [
    { label: 'Mumbai', id: '1' },
    { label: 'Bangalore', id: '2' },
  ];

  show: boolean = false;
  showMe: boolean = false;
  clickedAccept: boolean = false;
  clickedDispute: boolean = false;
  approvedInvoiceDetails: any;

  pdfPath = null;

  constructor(private modalService: NgbModal, private fb: FormBuilder,
    private _shared: SharedService, private excelService: ExcelService, private toast: ToastService,
    private router: Router) {
    this._shared.sendpageTitle('INVOICE');
    
    const currentDate: Date = new Date();
    let dd: any = currentDate.getDate();
    let mm: any = currentDate.getMonth() + 1;
    let yyyy: any = (currentDate.getFullYear()-2);

    if (dd < 10) {
      dd = '0' + dd
    }

    if (mm < 10) {
      mm = '0' + mm
    }

    this.today = yyyy + '-' + mm + '-' + dd;
  }

   getUsersByCodeOnInvoice(){
    let obj ={
      // pageNumber: pageNumber,
      // pageSize: pageSize,
      departmentCode: sessionStorage.getItem('departmentCode'),
      sectionCode: sessionStorage.getItem('sectionCode'),
      unitCode: sessionStorage.getItem('unit'),
    }
    this._shared.post('User/GetUserByCodes', obj, 'admin').subscribe(res => {
      this.getUserDataOnInvoice = res;
      // this.totalUserCode = res.item1;

    });
  }
  ngOnInit(): void {
    this.items = [
      {label: 'Accepted'},
      {label: 'Approved By SH'},
      {label: 'Approved By FH'},
      {label: 'Approved By HOD'},
      {label: 'Approved By UH'},
      {label: 'Resolved'}
  ];
   // this.items = [{
  //     label: 'File',
  //     items: [
  //         {label: 'New', icon: 'pi pi-plus'},
  //         {label: 'Open', icon: 'pi pi-download'}
  //     ]
  // },
  // {
  //     label: 'Edit',
  //     items: [
  //         {label: 'Undo', icon: 'pi pi-refresh'},
  //         {label: 'Redo', icon: 'pi pi-repeat'}
  //     ]
  // }];

    this.getUserColumns();
    this.getDisputeColumns();
    this.getDisputeList(0, 5);

    this.getApproveHistoryColumns();

    this.invoiceForm = this.fb.group({
      invoiceId: ['',[Validators.required]],
    })
    this.disputeForm = this.fb.group({
      fileUpload: [''],
      remarks: ['',[Validators.required]],
    })

    this.acceptForm = this.fb.group({
      remarks: ['', [Validators.required]],
    })
    this.dSignForm = this.fb.group({
      fileUpload: ['', [Validators.required]],
    })

    this.filterForm = this.fb.group({
      unit: [null,[Validators.required]],
      department: [null],
      section:[null],
      fromDate:[null],
      toDate:[null],
      workOrderNo:[null],
      invoiceNo:[null]
    })
    
    this.dropdownSettings = {
      enableSearchFilter: true,
      addNewItemOnFilter: false,
      singleSelection: true,
      text: "Select Unit",
      primaryKey: "bucode",
      labelKey: "buname",
      searchBy: ['buname'],
    };
    this.dropdownDeptSettings = {
      enableSearchFilter: true,
      addNewItemOnFilter: false,
      singleSelection: true,
      text: "Select Department",
      primaryKey: "departmentCode",
      labelKey: "departmentName",
      searchBy: ['departmentName'],
    };
    this.dropdownSecSettings = {
      enableSearchFilter: true,
      addNewItemOnFilter: false,
      singleSelection: true,
      text: "Select Section",
      primaryKey: "sectionCode",
      labelKey: "sectionName",
      searchBy: ['sectionName'],
    };
    let obj = {
      "PageNumber": 1,
      "PageSize": 10,
      "Unit": "RC01"
    }
    this.getInvoiceData(this.pageNo, this.pageSize);
    this.getUnit();
  }

  get filterFrm() {
    return this.filterForm.controls;
  }
  pMenuCollapsed = false;
  clicked(event:any){
    this.pMenuCollapsed = false;
    if (event.target.classList.contains('pi-plus')){
      this.pMenuCollapsed = true;
    } 
    /* if (event.target.classList.contains('pi-plus'))  {
      this.collapsed = false;
    } */
  }

  onChange(event:any, row:any, index:any){
    debugger;
  }

  onItemSelect(event:any){
    if(this.filterForm.value.unit.length){
      this.unitSelected = true;
    }
    this.getDepartmentData(event.bucode);
    this.getSectionData(event.bucode);
  }

  getInvoiceData(pageNumber: number, pageSize: number) {
    let obj = {
      pageNo: pageNumber,
      pageSize: pageSize,
      Unit: "RC01",
    }

    this._shared.post('Invoice/GetInvoices', obj, 'admin').subscribe(res => {
      this.totalInvoiceCount = res.item1;
      this.invoiceList = res.item2;
    });
  }

  getUnit(){
    this._shared.get('businessunit/GetBusinessUnitList',  'admin').subscribe(res => {
      this.getUnitDropdownData = res;
    });
  }

  getDepartmentData(unit: any) {
    let obj = {
      UNIT: unit
    }

    this._shared.post('department/GetDepartmentList', obj, 'admin').subscribe(res => {
      this.getDeptDropdownData = res;
    });
  }
  getSectionData(unit: any) {
    let obj = {
      UNIT: unit
    }

    this._shared.post('section/GetSectionList', obj, 'admin').subscribe(res => {
      this.getSectDropdownData = res;
    });
  }

  getWorkorder(pageNo:any, pageSize:any){
    let obj = {
      Unit: this.filterForm.value.unit[0].bucode,
      pageNumber: pageNo,
      pageSize: pageSize
    }
    this._shared.post('Workorder/GetWorkorders', obj ,'admin').subscribe(res => {
      this.workOrderListCount = res.item1;
      this.workOrderList = res.item2;
    });
  }
  
  getInvoice(pageNo:any, pageSize:any){
    let obj = {
      Unit: this.filterForm.value.unit[0].bucode,
      pageNumber: pageNo,
      pageSize: pageSize
    }
    this._shared.post('Invoice/GetInvoices', obj, 'admin').subscribe(res => {
      this.totalInvoiceListModalCount = res.item1;
      this.invoiceListModal = res.item2;
    });
  }

  getUserColumns() {
    this.cols = [
      { field: 'edit', header: 'Action' },
      { field: 'status', header: 'Status' },
      { field: 'category', header: 'Category' },
      { field: 'finalInvoiceId', header: 'Invoice No' },
      { field: 'invoiceDate', header: 'Invoice Date' },
      { field: 'workOrderNo', header: 'Work Order' },
      { field: 'billingPeriodStart', header: 'WO Valid From' },
      { field: 'billingPeriodEnd', header: 'WO Valid To' },
      { field: 'glcode', header: 'GL Code' },
      { field: 'bucode', header: 'Business Unit' },
      { field: 'function', header: 'Function' },
      { field: 'department', header: 'Department' },
      { field: 'section', header: 'Section' }
    ];

    this.frozenCols = [
      { field: 'edit', header: 'Action' },
    ];

    this.woCols = [
      { field: 'workOrder', header: 'Work Order No' },
      { field: 'unit', header: 'Unit' },
     /*  { field: 'department', header: 'Department' },
      { field: 'section', header: 'Section' }, */
    ];
    this.invoiceCols = [
      { field: 'invoiceNo', header: 'Invoice No' },
      { field: 'unit', header: 'Unit' },
     /*  { field: 'department', header: 'Department' },
      { field: 'section', header: 'Section' }, */
    ];
  }

  showInvoice(data:any){
    let obj={
      "InvoiceID": data.invoiceId
    };
    this.pdfPath = data.invoicePreDspdf != null ? data.invoicePreDspdf : null;

    this._shared.post('Invoice/GetInvoiceDetails', obj, 'admin').subscribe(res => {
      this.selectedInvoice = data.category;
      this.InvoiceDetails = res;
      this.selectedTabIndex = 1;
      this.wageSum = res.item2.reduce((prev:any, cur:any) => {
        return prev + cur.wageAmount;
      }, 0);

      this.otSum = res.item2.reduce((prev:any, cur:any) => {
        return prev + cur.ot;
      }, 0);

      this.marginSum = res.item2.reduce((prev:any, cur:any) => {
        return prev + cur.margin;
      }, 0);

      this.totalSum = res.item2.reduce((prev:any, cur:any) => {
        return prev + cur.total;
      }, 0);
    });
    this.showHideTabs();
  }

  openDispute(content: any) {
    this.fileUploadName = [];
    this.disputeForm.reset();
    this.modalService.open(content,
      { ariaLabelledBy: 'modal-basic-title', windowClass:'modalOpenDisputeWidth'  }).result.then((result) => {
        this.DisputeBill(this.InvoiceDetails.item1.invoiceId);
      }, (reason) => {
        this.disputeForm.get('fileUpload')?.enable();
      });
  }

  openApprove(content: any) {
    this.acceptForm.reset();
    this.modalService.open(content,
      { ariaLabelledBy: 'modal-basic-title', windowClass:'modalApprove'  }).result.then((result) => {
        this.AcceptBill(this.InvoiceDetails.item1.invoiceId);
        this.showHideButtons();
      }, (reason) => {
      });
  }
  openWorkOrder(content: any) {
    this.getWorkorder(this.pageNo, this.pageSize);
    this.modalService.open(content,
      { ariaLabelledBy: 'modal-basic-title', windowClass:'modalWorkOrder'  }).result.then((result) => {
        this.filterForm.get('workOrderNo')?.patchValue(this.selectedWorkOrderRow[0].workOrderNo);
      }, (reason) => {
      });
  }
  openInvoice(content: any) {
    this.getInvoice(this.pageNo, this.pageSize);
    this.modalService.open(content,
      { ariaLabelledBy: 'modal-basic-title', windowClass:'modalWorkOrder'  }).result.then((result) => {
        this.filterForm.get('invoiceNo')?.patchValue(this.selectedInvoiceRow[0].finalInvoiceId);
      }, (reason) => {
      });
  }
  
  uploadFile(event:any){
    var selectedFile = event.target.files[0];
    var idxDot = selectedFile.name.lastIndexOf(".") + 1;
    var extFile = selectedFile.name.substr(idxDot, selectedFile.name.length).toLowerCase();
    
    var validExtension = ['doc','docx', 'xls','xlsx','pdf','jpg','jpeg','gif'];

    if(validExtension.indexOf(extFile) ==-1){
      Swal.fire('<p class="m-1 swalTitle">Please select valid extension file. Like Word, Excel, Pdf, Image</p> <p style="font-size: 13px;" class="m-0">ex: doc, docx, xls, xlsx, pdf, jpg, jpeg, gif</p>');
      event.srcElement.value = '';
      return;
    }

    if (selectedFile.name.split('.')[0].length > 30){
      Swal.fire('<p class="m-1 swalTitle">File name should not exceed 30 character.</p>');
      event.srcElement.value = '';
      return;
    }
    
    const reader = new FileReader();
    const files = event.target.files[0];
    reader.readAsDataURL(files);
    reader.onload = () => {
      let FileSize = files.size / 1024; // in KB
      if (FileSize > 1048) {
        event.srcElement.value = '';
        Swal.fire('<p class="m-1 swalTitle">Please select a file less than or equal to 1 mb.</p>');
      } else{
        this.fileUploadName.push({ name: selectedFile.name, fileUpload: files});
        this.disputeForm.value.fileUpload = files;
        event.srcElement.value = '';
        if(this.fileUploadName.length == 2){
          this.disputeForm.get('fileUpload')?.disable();
        } 
      }
    }
  }

  downloadPdf(path:any){
    window.open(path, 'Download');
  }

  verifyInvoice(woNumber:any){
    this.router.navigate(['report/bill-Verification']);
    this._shared.verifyInvoiceByWorkOrder.next(woNumber);
  }

  ApplyFilter(){
      let searchDTO = {
        PageNumber : 0,
        PageSize : 10,
        //InvoiceID :
        InvoiceNumber: this.filterForm.value.invoiceNo == null ? null : this.filterForm.value.invoiceNo,
        Workorderno: this.filterForm.value.workOrderNo == null ? null : this.filterForm.value.workOrderNo,
        StartDate: this.filterForm.value.fromDate == null ? null : this.filterForm.value.fromDate,
        EndtDate: this.filterForm.value.toDate == null ? null : this.filterForm.value.toDate,
        DepartmentCode: this.filterForm.value.department?.length ? this.filterForm.value.department[0].departmentCode:null,
        //DepartmentCode: this.filterForm.value.department != null ? this.filterForm.value.department[0].departmentCode:null,
        //SectionCode: this.filterForm.value.section != null ? this.filterForm.value.section[0].sectionCode: null,
        SectionCode: this.filterForm.value.section?.length ? this.filterForm.value.section[0].sectionCode: null,
        //Vendorcode:
        Unit: this.filterForm.value.unit?.length ? this.filterForm.value.unit[0].bucode : null
    }
    this._shared.post('Invoice/GetInvoices', searchDTO, 'admin').subscribe(res => {
      this.totalInvoiceCount = res.item1;
      this.invoiceList = res.item2;
    });

  }

  checkboxWOChecked(rowIndex:any) {
    this.selectedWorkOrderRow = [this.workOrderList[rowIndex]];
  }
  
  checkboxInvoiceChecked(rowIndex:any) {
    this.selectedInvoiceRow = [this.invoiceListModal[rowIndex]];
  }

  clearBtn(){
    this.filterForm.reset();
    this.getInvoiceData(this.pageNo, this.pageSize);
  }

  tabChange(e: any) {
    this.getInvoiceData(this.pageNo, this.pageSize);
  }

  onPageChange(event: any) {
    this.getInvoiceData(event.page, event.rows);
  }
  
  onPageChangeWO(event: any) {
    this.getWorkorder(event.page, event.rows);
  }
  onPageChangeInvoice(event: any) {
    this.getInvoice(event.page, event.rows);
  }

  
  /* selectInvoice(e:any){
    this.selectedInvoice = e.target.value;
  } */

  deleteSelectedFile(fileindex:any){
    this.fileUploadName.splice(fileindex,1);
    if (this.fileUploadName.length < 2){
      this.disputeForm.get('fileUpload')?.enable();
    }
  }
  
  /* downloadPDF() {
    var data = <HTMLElement>document.getElementById('serviceInvoice');  //Id of the table
    var HTML_Width = data.offsetWidth;
    var HTML_Height = data.offsetHeight;
    var top_left_margin = 20;
    var PDF_Width = HTML_Width + (top_left_margin * 2);
    //var PDF_Height = (PDF_Width * 1.5) + (top_left_margin * 2);
    var PDF_Height = (841.995 * 1.5) + (top_left_margin * 2);
    var canvas_image_width = HTML_Width;
    var canvas_image_height = HTML_Height;
    //[HTML_Width + 30, HTML_Height]
    var pdf = new JSPDF.jsPDF('l', 'pt', [PDF_Width, PDF_Height]);
    pdf.html(data).then(data=>{
      pdf.save('test.pdf');
    })
  } */

  exportAsXLSX() {
        if (this.invoiceList.length > 0) {
          this.excelService.exportAsExcelFile(this.invoiceList, 'invoice');
        }
    }

  getDisputeColumns() {
    this.disputeCols = [
      { field: 'invoiceNo', header: 'Invoice No' },
      { field: 'businessUnit', header: 'Business Unit' },
      { field: 'function', header: 'Function' },
      { field: 'department', header: 'Department' },
      { field: 'section', header: 'Section' },
      { field: 'vendor', header: 'Vendor' },
      { field: 'workOrderNo', header: 'Work Order No' },
      { field: 'isActive', header: 'Status' },
      { field: 'edit', header: 'Action' },
    ];
  }

  getDisputeList(pageNo: number, pageSize: number) {
    let obj = {
      pageNo: pageNo,
      pageSize: pageSize,
      unit: "RC01",
      status: "DIS"
      // status: "COMP"
      // status: "CRT"
      // status: "NULL"
      // status: "RES"
      // status: "APSH"
      // status: "APHOD"

    }

    this._shared.post('Invoice/GetInvoices', obj, 'admin').subscribe(res => {
      this.invoiceDisputeList = res.item2;
      this.totalInvoiceDisputeCount = res.item1;
    });
  }

  getInvoiveDetails(data: any, status: any) {
    let obj = {
      "InvoiceID": data.invoiceId
    };
    this._shared.post('Invoice/GetInvoiceDetails', obj, 'admin').subscribe(res => {
      this.InvoiceDetails = res;
      this.selectedTabIndex = 1;
    });

  }

  signDoc(content: any) {
    this.url = "";
    this.dSignForm.reset();
    this.modalService.open(content,
      { ariaLabelledBy: 'modal-basic-title', windowClass: 'modalDisputeWidth' }).result.then((result) => {
        //this.uploadAndSubmit();
        this.dSignForm.reset();
      }, (reason) => {
      });
  }

  onPageDisputeChange(event: any) {
    this.getDisputeList(event.page, event.rows);
  }

  refresh(event: any) {
    if (event) {
      this.getInvoiveDetails(0, 1);
    }
  }

  uploadAndSubmit() {
    //this.toast.show("File Uploaded Successfully...", { classname: 'bg-success text-light', delay: 3000, autohide: true });
    // this.toast.show("Failed to Upload File...", { classname: 'bg-danger text-light', delay: 3000, autohide: true });
  }
  isDigitallySigned = "";
  submitDSign(modal:any){
    const formData = new FormData();
    formData.append('file', this.dSignUploadFile);
    let obj: any = {
      invoiceId: this.InvoiceDetails.item1.invoiceId,
    };

    formData.append('InvBvrSearchDTO', JSON.stringify(obj));

    this._shared.post('DigitalSignature/VerifySignedInvoice', formData, 'admin').subscribe(res => {
      debugger;
      if (res.item1) {
        this.isDigitallySigned = res.item2;
        this.dSignUploadFile = null;
        this.url = "";
        this.toast.show(res.item2, { classname: 'bg-success text-light', delay: 3000, autohide: true });
        modal.close();
      } else {
        this.url = "";
        this.dSignForm.reset();
        this.dSignUploadFile = null;
        Swal.fire('<p class="m-1 swalTitle">' + res.item2 + '</p>');
      }
    });
  }

  url = "";
  fileData: any;
  dSignUploadFile!: any;
  // onSelectFile(event:any){
  onDSignUploadFile(event: any) {
    var selectedFile = event.target.files[0];
    var idxDot = selectedFile.name.lastIndexOf(".") + 1;
    var extFile = selectedFile.name.substr(idxDot, selectedFile.name.length).toLowerCase();

    var validExtension = ['pdf'];

    if (validExtension.indexOf(extFile) == -1) {
      Swal.fire('<p class="m-1 swalTitle">Please select valid extension file. Like Pdf Image</p> <p style="font-size: 13px;" class="m-0">ex: pdf</p>');
      event.srcElement.value = '';
      return;
    }

    /* if (selectedFile.name.split('.')[0].length > 30) {
      Swal.fire('<p class="m-1 swalTitle">File name should not exceed 30 character.</p>');
      event.srcElement.value = '';
      return;
    } */

    const reader = new FileReader();
    this.dSignUploadFile = selectedFile;
    this.dSignForm.value.fileUpload = selectedFile;
    reader.readAsDataURL(selectedFile);
    reader.onload = (event: any) => {
      this.url = event.target.result;
    }
  }

  getApproveHistoryColumns() {
    this.apprCols = [
      { field: 'invoiceNo', header: 'Invoice No' },
      { field: 'status', header: 'Status' },
      { field: 'ActionBy', header: 'Action By' },
      { field: 'ActionDate', header: 'Action Date' },
      { field: 'AssignedTo', header: 'Assigned To ' },
      { field: 'Remarks', header: 'Reamrks' },
    ]
  }

  AcceptBill(invoiceId: any) {
    let obj: any = {
      invoiceWfid: 0,
      invoiceId: invoiceId,
      status: "Accepted",
      // previousStatusId: invoiceCurrentStatus,
      assigneTo: null,
      actionBy: sessionStorage.getItem('username'),
      actionDate: new Date(),
      isLatest: false,
      isFinalized: false,
      createdBy: sessionStorage.getItem('username'),
      created: new Date(),
      modifiedBy: sessionStorage.getItem('username'),
      modified: new Date(),
      remarks: this.acceptForm.value.remarks,
    }

    const formData = new FormData();
    formData.append('dto', JSON.stringify(obj));
    formData.append('files', '');

    this._shared.post('InvoiceStatusWorkflow/Create', formData, 'admin').subscribe(res => {
      this.invoiceList = res.item2;
      this.acceptForm.reset();
    });
  }

  DisputeBill(invoiceId: any) {
    let obj =
    {
      invoiceWfid: 0,
      invoiceId: invoiceId,
      status: "Disputed",
      // previousStatusId: invoiceCurrentStatus,
      documentId: null,
      assigneTo: null,
      actionBy: sessionStorage.getItem('username'),
      actionDate: new Date(),
      isLatest: false,
      isFinalized: false,
      createdBy: sessionStorage.getItem('username'),
      created: new Date(),
      modifiedBy: sessionStorage.getItem('username'),
      modified: new Date(),
      remarks: this.disputeForm.value.remarks
    }

    const formData = new FormData();
    var fileUploadArr: any = [];
    formData.append('dto', JSON.stringify(obj));

    for (var i = 0; i < this.fileUploadName.length; i++) {
      formData.append('files', this.fileUploadName[i].fileUpload);
    }
  
    this._shared.post('InvoiceStatusWorkflow/Create', formData, 'admin').subscribe(res => {
      this.invoiceList = res.item2;
      this.disputeForm.reset();
    });
  }

  viewDispute(content: any) {
    this.modalService.open(content,
      { ariaLabelledBy: 'modal-basic-title', windowClass: 'modalWidth' }).result.then((result) => {
        // this.clusterForm.reset();
        //this.closeResult = `Closed with: ${result}`;
      }, (reason) => {
        // this.clusterForm.reset();
        //this.closeResult =`Dismissed ${this.getDismissReason(reason)}`;
      });
  }
  resolveDispute() {
    // this.toast.show("Dispute Send For Resolving", { classname: 'bg-success text-light', delay: 3000, autohide: true });
  }

  showHideButtons() {
    this.show = !this.show;
  }
  showHideTabs() {
    this.showMe = !this.showMe;
  }

  getApprovalHistoryData(data: any) {
    let obj = {
      "invoiceId": data.invoiceId
    }
    this._shared.post('InvoiceStatusWorkflow/GetApprovalHistory', obj, 'admin').subscribe(res => {
      this.approvedInvoiceList = res;
    });
  }

  ngOnDestroy() {
    //this.subscription.unsubscribe();
  }
}
