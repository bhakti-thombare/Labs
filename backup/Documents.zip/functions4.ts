import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { BehaviorSubject, Subscription } from 'rxjs';
import { SharedService } from './../../shared/shared.service';
import { ExcelService } from '../../shared/excel.service';
import * as JSPDF from 'jspdf';
import 'jspdf-autotable';
import { ToastService } from '../../shared/toast.service';

@Component({
  selector: 'app-functions',
  templateUrl: './functions.component.html',
  styleUrls: ['./functions.component.scss']
})
export class FunctionsComponent implements OnInit {

  cols: any = [];
  closeResult = '';
  functionsForm: FormGroup;
  functionsData: any = [];
  page: number = 1;
  submitted = false;

  editFlag = false;
  pageNumber: number = 0;
  pageSize: number = 5;
  loader: boolean = true;
  totalFunctions!: any;
  filterColumField: any = [
    { field: 'functionCode', header: 'Function Code' },
    { field: 'functionName', header: 'Function Name' },
  ]
  tableDrop: any = []
  tableDrop1: any = [];
  BUDropdown: any = [];
  FHDropdown: any = [];
  getUserDropdownData: any = [];
  selectedItems: any = [];
  selectedItems1 : any =[];
  dropdownSettings = {};
  roles!: any[];
  roles1!: any[];

  selectedTabIndex = 0;
  deptsData: any = {};
  dropdownSecSettings = {};

  constructor(private modalService: NgbModal, private fb: FormBuilder, private _shared: SharedService,
    private excelService: ExcelService, private toast: ToastService) {


    this.functionsForm = this.fb.group({
      functionCode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(18), Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      bucode: ['', [Validators.required, Validators.maxLength(18)]],
      functionName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(150), Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      functionHead: ['', [Validators.required, Validators.maxLength(120)]],
      isActive: ['true'],
    })

  }

  ngOnInit() {

    this.getFunctionColumns();
    this.getFunctionsData(this.pageNumber, this.pageSize);
    this.getUserDropdownList();
    this.getFHDropdownList(0, 100);
    this.getBUDropdownList(0, 100);
    this.getBUDataFromAPI(0, 100);
    this.getHeadsDataFromAPI();
    this.getCountries(this.pageNumber, this.pageSize);

    this.dropdownSettings = {
      enableSearchFilter: true,
      addNewItemOnFilter: true,
      singleSelection: true,
      text: "Select User",
      primaryKey: "id",
      labelKey: "userId",
      searchBy: ['userId']

    };
    this.dropdownSecSettings = {
      enableSearchFilter: true,
      addNewItemOnFilter: true,
      singleSelection: true,
      text: "Select Unit",
      primaryKey: "bucode",
      labelKey: "buname",
      searchBy: ['buname'],
      lazyLoading: true,
      classes: "myclass custom-class",
      //autoPosition: false
    };
  }
  units:any[] = []
  getCountries(pageNumber:number, pageSize:number) {
    let obj={
      // pageNumber:pageNumber,
      // pageSize:pageSize,
      unit: sessionStorage.getItem('unit')
    }
    this._shared.post('Function/GetFunctionList', obj,'admin').subscribe(res => {
      this.units = res;
    });
  }

  checkSpecialCharInCode = true;
  avoidSpecialCharInCode(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      this.checkSpecialCharInCode = false;
      return this.checkSpecialCharInCode;
    } else {
      this.checkSpecialCharInCode = true;
      return this.checkSpecialCharInCode;
    }
  }

  checkSpecialCharInName = true;
  avoidSpecialCharInName(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    // if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      if (charCode > 31 && (charCode < 45 || charCode > 57 || charCode >= 47) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
     
    this.checkSpecialCharInName = false;
      return this.checkSpecialCharInName;
    } else {
      this.checkSpecialCharInName = true;
      return this.checkSpecialCharInName;
    }
}
// // units!: any[];
// changeCountry(event: any,pageNumber:number, pageSize:number){
//   let obj = {
//     // pageNumber: pageNumber,
//     // pageSize: pageSize,
   
//   }
//   this._shared.post('Function/GetFunctionList',obj,'admin').subscribe(res => {
//     // let state = res.filter((itm:any) => itm.countryCode == e.target.value);
//     this.units = res;
//   });
// }


  get formControl() {
    return this.functionsForm.controls;
  }

  getFunctionColumns() {
    this.cols = [
      { field: 'Action', header: 'Action' },
      { field: 'bucode', header: 'BU Name' },
      { field: 'functionCode', header: 'Function Code' },
      { field: 'functionName', header: 'Function Name' },
      { field: 'functionHead', header: 'Function Head' },
      { field: 'isActive', header: 'Status' },

    ];
  }

  open(content: any) {
    // this.functionsForm.value.functionCode = this.functionsForm.value.functionCode,
      this.functionsForm.value.bucode = this.functionsForm.value.bucode[0]?.bucode,
      this.functionsForm.value.functionName = this.functionsForm.value.functionName,
      this.functionsForm.value.functionHead = this.functionsForm.value.functionHead[0].userId,

      this.functionsForm.value.isActive = this.functionsForm.value.isActive ? true : false,
      this.functionsForm.value.createdBy = sessionStorage.getItem('username');
    this.functionsForm.value.modifiedBy = sessionStorage.getItem('username');
    this._shared.post('Function/CreateFunction', this.functionsForm.value, 'admin').subscribe(res => {
      this.toast.show("Records saved successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      this.getFunctionsData(0, 5);
      this.functionsForm.reset();
    });

  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onSearch(evt: any) {
    if (evt.target.value == "") {
      this.getUserDropdownList();
    } else {
      console.log(evt.target.value);
      this.getUserDropdownData = [];
      let obj = { "searchcriteria": "user", "value": `${evt.target.value}` }
      this._shared.post('User/GetUsersListByCriteria', obj, 'admin').subscribe(res => {
        this.loader = false;
        this.getUserDropdownData = res;
      });
    }
  }

  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  OnItemDeSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  onDeSelectAll(items: any) {
    console.log(items);
  }

  getHeadsDataFromAPI() {
    this._shared.post('User/GetUsersListByCriteria', {}, 'admin').subscribe(res => {
      this.loader = false;
      this.roles = res;
      res.forEach((list: any) => {
        this.tableDrop.push({ label: list.userId, value: list.userId });
      })
    });
  }

  getBUDataFromAPI(pageNumber: number, pageSize: number) {
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize
    }
    this._shared.post('BusinessUnit/GetBusinessUnits', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.roles1 = res;
      res.item2.forEach((list: any) => {
        this.tableDrop1.push({ label: list.bucode, value: list.bucode });
      })

    });
  }


  getUserDropdownList() {
    this._shared.post('User/GetUsersListByCriteria', {}, 'admin').subscribe(res => {
      this.loader = false;
      this.getUserDropdownData = res;
    });
  }

  getFHDropdownList(pageNumber: number, pageSize: number) {
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize,
      unit: sessionStorage.getItem('unit')
    }
    this._shared.post('Function/GetFunctions', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.FHDropdown = res.item2;

    });
  }

  getBUDropdownList(pageNumber: number, pageSize: number) {
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize
    }
    this._shared.post('BusinessUnit/GetBusinessUnits', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.BUDropdown = res.item2;
    });
  }




  tabChange(e: any) {
    this.functionsForm.reset();
    this.functionsForm.patchValue({ 'isActive': true });
    let index = e.index;
    if (index == 0) {
      this.getFunctionsData(0, 5);
    }
  }

  getFunctionsData(pageNumber: number, pageSize: number) {
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize,
      unit: sessionStorage.getItem('unit')
    }

    this._shared.post('Function/GetFunctions', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.functionsData = res.item2;
      this.totalFunctions = res.item1;
    });
  }

  refresh(event: any) {
    if (event) {
      this.getFunctionsData(0, 5);
    }
  }

  filterData(event: any) {
    event.pageSize = this.pageSize;
    event.unit = sessionStorage.getItem('unit')
    this._shared.post('Function/SearchFunctions', event, 'admin').subscribe(res => {
      this.loader = false;
      this.functionsData = res.item2;
    });
  }

  cloneRecord: any = {};
  onRowEditInit(data: any) {
    this.cloneRecord[data.functionCode] = { ...data };
  }

  onRowEditSave(data: any) {
    this.functionsForm.value.functionId = data.functionId;
    this.functionsForm.value.functionCode = data.functionCode;
    this.functionsForm.value.bucode = data.bucode;
    this.functionsForm.value.functionName = data.functionName;
    this.functionsForm.value.functionHead = data.functionHead;
    this.functionsForm.value.isActive = data.isActive ? true : false,
      this.functionsForm.value.modifiedBy = sessionStorage.getItem('username');
    this.functionsForm.value.created = data.created;
    this.functionsForm.value.createdBy = data.createdBy;
    this._shared.put('Function/UpdateFunction', this.functionsForm.value, 'admin').subscribe(res => {
      this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      this.getFunctionsData(0, 5);
    });
  }

  onRowEditCancel(data: any) {
    this.getFunctionsData(0, 5);
  }

  onPageChange(event: any) {
    this.getFunctionsData(event.page, event.rows);
  }

  ngAfterViewInit() {
    this._shared.sendpageTitle('FUNCTIONS');
  }

  exportAsXLSX() {
    if (this.functionsData.length > 0) {
      this.excelService.exportAsExcelFile(this.functionsData, 'sample');
    }
  }

  createPdf() {
    // debugger;
    let head: any = [[]];
    let data: any = [[]];
    this.functionsData.forEach((res: any, index: any) => {
      if (index == 0) {
        for (let obj in res) {
          if (head[index].length <= 8) {
            head[0].push(obj);
            data[index].push(res[obj]);
          }
        }
      } else {
        data.push([])
        for (let obj in res) {
          if (data[index].length <= 8) {
            data[index].push(res[obj])
          }
        }
      }
    })

    let doc = new JSPDF.jsPDF("l", "in");

    doc.setFontSize(9);
    doc.text('', 11, 8);
    doc.setFontSize(9);
    doc.setTextColor(100);


    (doc as any).autoTable({
      head: head,
      body: data,
      theme: 'plain',
      didDrawCell: (data: any) => {
        console.log(data.column.index)
      }
    })

    // Open PDF document in new tab
    doc.output('dataurlnewwindow')

    // Download PDF document  
    doc.save('table.pdf');
  }


}

