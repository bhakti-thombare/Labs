import { FormControl } from '@angular/forms';
// core
import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';

// 3rd party
import {
        isEmpty,
        map, 
        isUndefined, 
        isNull, 
        findWhere, 
        filter} from "underscore";
import * as $ from "jquery";
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { Subscription } from 'rxjs/Subscription';
import { NgbModalRef, NgbModal } from "@ng-bootstrap/ng-bootstrap";

// app
import { MissionDateChangeModalComponent } from '@app/supervisor/edit-survey/mission-date-change-modal/mission-date-change-modal.component';
import { CustomerSurveyAlertsService } from '@services/Alerts/customer-survey-alerts.service';
import { missionTypes, Globals } from '@app/constants/constants';
import { UTILS, GlobalUtility } from '@services/global-utility.service';
import { ApiService } from '@services/apiServices/api.service';
import { EventService } from '@services/events/event.service';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { TranslateService } from '@ngx-translate/core';
import { CreateSurveyUtilsService } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.service';
declare var google: any;

@Component({
    selector: 'app-edit-mission-customer-survey',
    templateUrl: './edit-mission-customer-survey.component.html',
    styleUrls: ['./edit-mission-customer-survey.component.css']
})

export class EditMissionCustomerSurveyComponent implements OnInit, OnDestroy {
    private utilityFunctions = new UtilityFunctions();  
    private subscriptions: Subscription[] = [];
    mission: any = {
        zones: []
    };
    zone: any = {}
    selectedMissionType: any = {
        name: 'Pedestrain Flow'
    };
    disableMapClick = false;
    zoneNameDisabled: boolean;
    isZoneNameExist: boolean;
    user: any = JSON.parse(localStorage.getItem('user-data'));
    /* Date related */
    today: Date = new Date();
    /* Mission Variables */
    missionId: any;
    missionData: any = {
        missionCampaign: {},
        missionType: {},
        missionZones: [{}],
    };
    missionZonesBackup: Array<any> = [];
    defaultUsrDataAssToZone: any = {};
    /* Dropdown options */
    maxDate: any;
    optionsUnassigned: Array<any> = [];
    existingZonesBackup: Array<any> = [];
    optionsExistingZones: Array<any> = [];
    selectedAssignee: any;
    selectedZone: any;
    assignUserConfig = { displayKey: "fullname", search: false, placeholder: "Select field agent", multiple: false };
    existingZonesConfig = { displayKey: "name", search: true, placeholder: "Select Zone", multiple: false };
    /* Datepicker variables */
    busyDates: Array<any> = [];
    localUtilInstance: any;
    isThereExistingZones: boolean;
    isAssignmentAvail: boolean = true;

    marketZone;
    constructor(
        public _event: EventService,
        public router: Router,
        public route: ActivatedRoute,
        public apiService: ApiService,
        public gobalUTL: GlobalUtility,
        public modalService: NgbModal,
        public translate: TranslateService,
        public custUtils: CreateSurveyUtilsService,
        public custSurveyAlerts: CustomerSurveyAlertsService) {
        route.params.subscribe(params => {
            this.missionId = params.id;
        });
        this.localUtilInstance = UTILS;
    }

    textControl = new FormControl();
    nameExists = false;
    count: number;
    missionName: any;
    ngOnInit() {
        this.isExistingZone = false;
        this._event.broadcast({ eventName: 'showLoader', data: {} });
        this.getMissions(this.missionId);
        this.getUserMissionDetails(this.missionId);
        this.getMarketZone();
        this.getAllZones();
        this.placeholderSearch();

        this.textControl.valueChanges.pipe(
        ).subscribe((res) => {
            if(res !=undefined){
                res = res.trim()
                if (res !== '') {
                    this.name = true
                } else {
                    this.name = false
                }
                console.log("this.name1=", this.name, this.description);
    
                if (this.name && this.description) {
                    this.buttonEnabled = true;
                } else {
                    this.buttonEnabled = false;
                }
                if (res !== '') {
    
                    // console.log("res=",res)
                    this.apiService.getMissionName(res).subscribe((res) => {
                        this.name = true;
                        this.nameExists = false;
                    }, (error) => {
                        this.name = false;
                        if (this.count == 1) {
                            this.nameExists = false;
                            this.count += 1;
                        }
                        else {
                            if (this.missionName == res) {
                                this.nameExists = false;
                            }
                            else this.nameExists = true;
                        }
                    })
                }
            }
        });
    }
    getLngLat(e) {
        if (!this.isExistingZone && !this.isOnMapClicked) this.isOnMapClicked = true;
        const api = new google.maps.Geocoder;
        this.missionData.missionZones[0].longitude = e[0];
        this.missionData.missionZones[0].latitude = e[1];
        this.missionData.missionZones[0].lng = e[0];
        this.missionData.missionZones[0].lat = e[1];
        this.missionData.missionZones[0].name = undefined;
        this.missionData.missionZones[0].adptId = null;
        this.zoneNameDisabled = false;
        api.geocode({ latLng: { lat: e[1], lng: e[0] } },
            res => { if (res) this.missionData.missionZones[0].address = res[0].formatted_address; }, err => err);
    }
    /* Togglers starts */
    isMorning: boolean;
    //changeShiftId(flag: boolean) { this.isMorning = flag; }
    /* Togglers ends */

    /* Getters Starts*/
    isMissionZones: boolean = true;
    isOnMapClicked: boolean = true;
    missionStartDate: Date;
    isReassigned = false;
    getMissions(missionId) {
        this.subscriptions.push(this.apiService.getAllMissions({ id: missionId })
            .subscribe(res => {
                this.missionData = res.data.missions[0];
                this.market = this.missionData.market;

                this.missionName = res.data.missions[0].missionName;
                this.count = 1;
                // this.isMissionZones = isEmpty(this.missionData.missionZones[0]);
                // if (this.isMissionZones) {
                //     this.isMissionZones = false;
                //     this.missionData.missionZones[0] = { latitude: 50.8503, longitude: 4.3517 };
                // }

                if (this.missionData.missionZones.length > 0) {
                    this.isMissionZones = false;
                    this.getExistingCheck = true;
                    this.isExistingZone = true;
                    this.disableMapClick = true;
                    this.selectedZone = [...this.missionData.missionZones];
                    this.mapObject = [{ 'longitude': this.missionData.missionZones[0].longitude, 'latitude': this.missionData.missionZones[0].latitude, flag: false }];
                } else {
                    this.isMissionZones = false;
                    this.isExistingZone = false;
                    this.getExistingCheck = false;
                    if (this.missionData.missionZones.length==0){
                        this.missionData.missionZones.push({ "address": "", "adptId": "", "name":" "});
                    }
                }

                if (this.missionData.missionMarketZoneList != null) {
                    if (this.missionData.missionMarketZoneList.length > 0) {
                        if (this.missionData.missionZones[0].longitude == undefined && this.missionData.missionZones[0].latitude == undefined){
                            this.mapObject = [
                                { 'longitude': this.missionData.missionMarketZoneList[0].longitude, 'latitude': this.missionData.missionMarketZoneList[0].latitude, flag: true }
                            ];    
                        } else{
                            this.mapObject = [
                                { 'longitude': this.missionData.missionZones[0].longitude, 'latitude': this.missionData.missionZones[0].latitude, flag: false },
                                { 'longitude': this.missionData.missionMarketZoneList[0].longitude, 'latitude': this.missionData.missionMarketZoneList[0].latitude, flag: true }
                            ];
                        }
                    }
                    this.marketid = res.data.missions[0].missionMarketZoneList[0].id;
                    this.selectedMarketZoneValue = res.data.missions[0].missionMarketZoneList[0].officialName;
                    this.missionData.markets = [];
                    this.missionData.markets.push({
                        longitude: res.data.missions[0].missionMarketZoneList[0].longitude,
                        latitude: res.data.missions[0].missionMarketZoneList[0].latitude
                    });
                }

                if (this.missionData.missionStartDate !=null){
                    this.missionStartDate = new Date(this.missionData.missionStartDate);
                    this.missionData.missionStartDate = UTILS.getDatePickerDateFormat(this.missionData.missionStartDate);
                    localStorage.setItem('date', JSON.stringify(this.missionData.missionStartDate));
                }
                this.missionZonesBackup = [...this.missionData.missionZones];
                this.maxDate = UTILS.getDatePickerDateFormat(this.missionData.missionCampaign.campaignEndDate);
                // this.getUnassignedUsers(missionId, true, this.missionData.missionStartDate);
                this.getUsedMissionDates(this.today);
                this.missionData.missionEndDate = UTILS.getDatePickerDateFormat(this.missionData.missionEndDate);

                if (this.missionData.shift==null){
                    this.isMorning = true;
                }else{
                    if (this.missionData.shift.shiftId ==1){
                        this.isMorning = true;
                    } else{
                        this.isMorning = false;
                    }
                }

                if (this.missionData.missionStatus.statusId == 10) {
                    this.isReassigned = true;
                }

                this.optionsUnassigned = [];
                //this.optionsUnassigned.push(this.missionData.agent.firstName + ' ' + this.missionData.agent.lastName);
                if(this.missionData.agent !=null){
                    this.optionsUnassigned.push(this.missionData.agent);
                    this.selectedAssignee = this.optionsUnassigned[0];
                }
                
                console.log("List binded", this.optionsUnassigned);
            }, err => {
                if (!err.data) this.router.navigate(['/supervisor/missions']);
            }));
    }
    getUnassignedUsers(missionId, sts, missionDate) {
        let obj = { missionId: missionId, startDate: UTILS.getDateFormat(missionDate), shift: this.isMorning ? 1 : 2 };
        this.subscriptions.push(this.apiService.getUnassignedUsers(obj)
            .subscribe(res => {
                this.optionsUnassigned = [];
                this.optionsUnassigned = map(res.users, (m) => UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` }));
                if(sts){
                    if (this.missionData.agent !=null){
                        let agent = this.optionsUnassigned.filter(res => res.userId == this.missionData.agent.userId);
                        if (agent.length == 0){
                            this.optionsUnassigned.splice(0, 0, this.missionData.agent);
                        }
                    }
                }
                this.selectedAssignee = this.optionsUnassigned[0];
                this._event.broadcast({ eventName: 'hideLoader', data: {} });
            }, err => {
                    const id = this.isMorning == true ? 1 : 2;
                    let flag = false;
                    if (this.missionData.shift !=null){
                        if(this.missionData.shift.shiftId == id) {
                            flag = true;
                            return flag;
                        }
                    }

                    if (sts && flag){
                        this.optionsUnassigned = [];
                        this.optionsUnassigned = map([this.missionData.agent], (m) => UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` }));
                        this.selectedAssignee = this.missionData.agent;
                    } else{
                        this.custUtils.translateMessageObject({
                            title: this.translate.instant('No Field agents available'),
                            text: this.translate.instant('Please change the mission date or  ask admin to add more field agents.'),
                            type: 'warning',
                            cancelBtnText: '',
                            confirmBtnText: 'OK',
                            outsideClick: false,
                            showCancelBtn: false
                        }, message => {
                            this.custUtils.translateAndPop(message).then(() => {
                                this.optionsUnassigned = [];
                                this.selectedAssignee = {};
                            }).catch(() => {
                                this.selectedAssignee = {};
                                this.optionsUnassigned = [];
    
                            });
                        });
                    }
                }));
    }
    getUsedMissionDates(date) {
        let currentDate = UTILS.getDatePickerDateFormat(date);
        this.subscriptions.push(this.apiService.getUsedMissionDates(UTILS.getDateFormat(currentDate), missionTypes.CUSTOMER_SURVEY_TYPE_ID)
            .subscribe(res => { Globals.BUSY_DATES = res.dateDto; }, err => Globals.BUSY_DATES = []));
    }
    userMissionDetails: any = { userZones: [{}] };
    getUserMissionDetails(missionId) {
        this.subscriptions.push(this.apiService.getUserMissionDetails({ missionId: missionId })
            .subscribe(res => {
                this.userMissionDetails = res.data;
                this.getAllUsers(res.data.userZones[0].userId, missionId);
            }, err => {
                //this.getUnassignedUsers(missionId, true, this.missionData.missionStartDate);
                this._event.broadcast({ eventName: 'hideLoader', data: {} });
                this.isAssignmentAvail = false;
            }));
    }
    existingZones = [];
    getAllZones() {
        this.subscriptions.push(this.apiService.getAllZones('')
            .subscribe(res => {
                this.optionsExistingZones = [...res.data.zones];
                this.existingZones = [...res.data.zones];
                if(this.missionData.missionZones == null){
                    this.selectedZone = [this.optionsExistingZones[0]];
                }
                this.isThereExistingZones = true;
            }, err => { this.isThereExistingZones = false; }));
    }
    isExistingZone: boolean;
    getExistingCheck:boolean;
    getExistingZone($event) {
        this.isMissionZones = false;
        if ($event.target.checked) { 
            this.getExistingCheck = true;
            let obj = this.existingZones;
            this.optionsExistingZones = [];
            this.optionsExistingZones = [...obj];
            let index = obj.findIndex((res: any) => res.id == this.missionZonesBackup[0].id);
            this.missionData.missionZones = [{ ...obj[index]}];
            this.selectedZone = [{ ...obj[index] }];
            this.mapObject = [{ 'longitude': this.missionData.missionZones[0].longitude, 'latitude': this.missionData.missionZones[0].latitude, flag: false }];
        } else {
            //this.missionData.missionZones = this.missionZonesBackup;
            this.marketUnchecked = false;
            
            this.getExistingCheck = false;
            this.missionData.missionZones[0].address = "";
            this.missionData.missionZones[0].adptId = "";
            this.missionData.missionZones[0].name = "";
            if(this.market){
                this.mapObject = [{ 'longitude': this.missionData.markets[0].longitude, 'latitude': this.missionData.markets[0].latitude, flag: true }];
            }
        };
        this.disableMapClick = this.isExistingZone = $event.target.checked;
        setTimeout(() => { this.placeholderSearch(); }, 500);
    }
    defaultAssignedUserid: any;
    getEndDate(d1) {
        let dateE = JSON.parse(localStorage.getItem('date'));
        if (dateE == null) {
            this.getUnassignedUsers(this.missionId, false, d1);
        } else {
            let datePickerDateSelected = new Date(UTILS.getDateFormat(d1));
            let existingDate = new Date(UTILS.getDateFormat(dateE));
            if (datePickerDateSelected.getTime() == existingDate.getTime()) {
                this.getUnassignedUsers(this.missionId, true, d1);
            } else {
                this.getUnassignedUsers(this.missionId, false, d1);
            }
        }
        // if (UTILS.isMatch(UTILS.minDate, d1, this.missionData.missionCampaign.campaignEndDate) && !this.isDisabled(d1, { month: d1.month })) {
        //     this.missionData.missionEndDate = d1;
        //     let d = new Date(UTILS.getDateFormat(d1))
        //     if (this.missionStartDate !=undefined){
        //         if (d.getTime() == this.missionStartDate.getTime()) {
        //             this.defaultUsrDataAssToZone = this.zoneAssignmentBack;
        //             this.defaultUsrDataAssToZone.userId = this.defaultAssignedUserid;
        //             this.getUnassignedUsers(this.missionId, true, d1);
        //         }
        //         else {
        //             this.defaultUsrDataAssToZone.userId = undefined;
        //             //this.selectedAssignee = [];
        //             this.getUnassignedUsers(this.missionId, false, d1);
        //         }
        //     } else{
        //         this.defaultUsrDataAssToZone.userId = undefined;
        //         //this.selectedAssignee = [];
        //         this.getUnassignedUsers(this.missionId, false, d1);
        //     }
        // }
    }
    isDisabled(date: NgbDate, current: { month: number }) { return (findWhere(Globals.BUSY_DATES, UTILS.getDatePickerIntFormat(date))) ? true : false; }
    getAllUsers(userId, missionId) {
        this.subscriptions.push(this.apiService.getAllUsers({ id: userId })
            .subscribe(res => {
                if (res) {
                    this.defaultUsrDataAssToZone = res.data.users[0];
                    this.defaultAssignedUserid = this.defaultUsrDataAssToZone.userId;
                    this.zoneAssignmentBack = { fullname: this.defaultUsrDataAssToZone.firstName + " " + this.defaultUsrDataAssToZone.lastName, userId: this.defaultUsrDataAssToZone.userId };
                    //this.getUnassignedUsers(missionId, true, this.missionData.missionStartDate);
                    this._event.broadcast({ eventName: 'hideLoader', data: {} });
                }
            }, err => console.log(err)));
    }
    getEditMissionRequestBody() {
        let obj = {
            "mission": {
                "missionId": this.missionId,
                "missionDescription": this.missionData.missionDescription,
                "missionStartDate": UTILS.getDateTimeFormat(this.missionData.missionStartDate),
                "missionEndDate": UTILS.getDateTimeFormat(this.missionData.missionStartDate),
                "missionName": this.missionData.missionName,
                "missionTypeId": this.missionData.missionType.id,
                "missionUpdatedById": this.user.userId,
                "missionCampaignId": this.missionData.missionCampaign.campaignId,
                "classic": this.missionData.classic,
                "market": this.missionData.market,
                "marketZone": this.marketid,  //null if market zone not selected
                "prm": false,
                "visits": false,
                "missionStatusId": this.missionData.missionStatus.statusId,
            },
            "circuits": [],
            "checkpoints": [],
            "assignments": [],
            "zones": [{
                "missionId": this.missionId,
                "zoneId": (!this.isOnMapClicked) ? this.missionData.missionZones[0].id : null,
                "zoneName": this.missionData.missionZones[0].name,
                "zoneDescription": null,
                "zoneLatitude": this.missionData.missionZones[0].latitude,
                "zoneLongitutde": this.missionData.missionZones[0].longitude,
                "zoneStart": null,
                "zoneEnd": null,
                "zoneCreatedBy": this.user.userId,
                "zoneUpdatedBy": this.user.userId,
                "zoneAdptId": this.missionData.missionZones[0].adptId,
                "zoneAddress": this.missionData.missionZones[0].address,
                "locationTypeId": 3
            }]
        };

        let eveningShift = {
            "campaignId": this.missionData.missionCampaign.campaignId,
            "userId": this.selectedAssignee.userId,
            "missionId": this.missionId,
            "circuitId": null,
            "checkpointId": null,
            "shiftId": 2,
            "startDate": `${UTILS.getDateFormatWithoutZero(this.missionData.missionStartDate)} 13:00:00`,
            "endDate": `${UTILS.getDateFormatWithoutZero(this.missionData.missionStartDate)} 17:15:00`,
            "iterations": null,
            "createdBy": this.user.userId,
            "updatedBy": this.user.userId,
            "status": this.missionData.missionStatus.statusId,
            "zone": (!this.isOnMapClicked) ? this.missionData.missionZones[0].id : null,
            "marketZone": this.marketid,  //null if market zone not selected
        }

        let morningShift = {
            "campaignId": this.missionData.missionCampaign.campaignId,
            "userId": this.selectedAssignee.userId,
            "missionId": this.missionId,
            "circuitId": null,
            "checkpointId": null,
            "shiftId": 1,
            "startDate": `${UTILS.getDateFormatWithoutZero(this.missionData.missionStartDate)} 08:45:00`,
            "endDate": `${UTILS.getDateFormatWithoutZero(this.missionData.missionStartDate)} 13:00:00`,
            "iterations": null,
            "createdBy": this.user.userId,
            "updatedBy": this.user.userId,
            "status": this.missionData.missionStatus.statusId,
            "zone": (!this.isOnMapClicked) ? this.missionData.missionZones[0].id : null,
            "marketZone": this.marketid,  //null if market zone not selected
        }

        if(this.isMorning){
            obj.assignments.push(morningShift);
        } else {
            obj.assignments.push(eveningShift);
        }
        return obj;
    }
    getExstingZone(zoneName) {
        this.subscriptions.push(this.apiService.getAllZones('')
            .subscribe(res => {
                let data = filter(res.data.zones, (z) => { return z.name.toLowerCase() == zoneName });
                this.missionData.missionZones = data;
                if (!isEmpty(this.missionData.missionZones)) { this.isOnMapClicked = false; };
            }, err => { this.isThereExistingZones = false; }));
    }
    /* Getters End*/

    /* Post Methods Starts */
    editMission() {
        if (this.isDataValid() || this.isModal) {
            this._event.broadcast({ eventName: 'showLoader', data: {} })
            console.log(this.getEditMissionRequestBody().assignments[0].userId);
            
            this.subscriptions.push(this.apiService.editMission(this.getEditMissionRequestBody(), '')
                .subscribe(res => {
                    console.log(res);
                    if (res.responseCode == 200) {
                        this._event.broadcast({ eventName: 'hideLoader', data: {} });
                        this.custSurveyAlerts.missionDeatailsUpdateSuccessAlert()
                            .then(() => { this.router.navigate(['supervisor/missions']); });
                    }
                }, err => {
                    this._event.broadcast({ eventName: 'hideLoader', data: {} });
                    this.custSurveyAlerts.somethingWentWrongWhileUpdateAlert().then(() => { });
                }));
        }
    }
    /* Post Methods Ends*/

    /* Events Starts */
    selectionChanged(event, type) { 
        if (type == 1 && event.value.length != 0) { 
            this.marketUnchecked = false;
            this.missionData.missionZones = [...event.value]; 
            this.mapObject = [{ 'longitude': this.missionData.missionZones[0].longitude, 'latitude': this.missionData.missionZones[0].latitude, flag: false }];
        } 
    }
    zoneAssignmentBack: any = {};
    selectionChanged2(event, type) {
        if (type == 2 && event.value.length != 0) this.defaultUsrDataAssToZone = event.value[0];
        else this.defaultUsrDataAssToZone = {};
    }
    /* Events Ends */

    /* Validations starts */
    isDataValid() {

            //if  AvailableUserListContains() this.getEditMissionRequestBody().assignments[0].userId)
            console.log(this.missionData);
            
            let user = this.optionsUnassigned;

            this.user.forEach((user =this.getEditMissionRequestBody().assignments[0].userId)=> {

            })
                
                
                
            
        let zoneData = this.missionData.missionZones[0];
        if ((!isUndefined(zoneData.address) && zoneData.address != "") &&
            (!isUndefined(zoneData.adptId) && zoneData.adptId != "" && !isNull(zoneData.adptId)) &&
            (!isUndefined(zoneData.name) && zoneData.name != "") &&
            //(!isUndefined(this.defaultUsrDataAssToZone.userId && this.defaultUsrDataAssToZone.userId != "")) &&
            (!isUndefined(this.missionData.missionName) && this.missionData.missionName != "")) return true;
        else return false;
    }

    isZoneNameExistCheck() {
        let is = UTILS.isNameExistList(map(this.optionsExistingZones, (z) => z.name.toLowerCase()), this.missionData.missionZones[0].name.toLowerCase().trim());
        if (is) {
            this.custSurveyAlerts.zoneWithSameNameExistAlert().then((result) => {
                this.getExstingZone(this.missionData.missionZones[0].name.toLowerCase());
            }).catch(() => this.missionData.missionZones[0].name = undefined);
        }
    }
    /* Validations ends */

    /* Modal Triggers */
    updateMissionDateModal: NgbModalRef;
    isModal: boolean = false;
    openModal() {
        this.updateMissionDateModal = this.modalService.open(MissionDateChangeModalComponent);
        this.updateMissionDateModal.componentInstance.missionDataModal = this.missionData;
        this.updateMissionDateModal.componentInstance.maxDate = this.maxDate;
        this.updateMissionDateModal.result.then(data => {
            if (data == 'closed') this.router.navigate(['supervisor/missions']);
            if (data == 'SubmitClicked') { this.isModal = true; this.editMission(); };
        }).catch(err => console.log(err));
    }
    /* Modal Triggers */
    placeholderSearch() {
        $('.ngx-dropdown-button').click(function () {
            $(".search-container>label").html('<span class="nsdicon-search"></span> Enter min 3 characters');
            $(".search-container>label").css('font-size', "12px");
        });
    }

    ngOnDestroy() {
        this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
     }
     
  
    getMarketZone() {
        this.apiService.getMarketZone(this.user.userId).subscribe(res => {
            this.marketZone = res.data;
        })
    }

    classic = true;
    market:Boolean;
    marketid = null;
    buttonEnabled = false;
    name = false;
    description = false;
    marketZoneSelected = true;
    selectedMarketZoneValue = this.translate.instant('Select market zone');
    mapObject: any = [];
    marketUnchecked = false;
    onChecked(event, name) {
        // && this.marketid==null
        if (name === 'market') {
            if (event.target.checked) {
                this.classic = false;

                this.marketZoneSelected = false;
                this.market = true
                this.missionData.market = this.market;
                this.missionData.classic = this.classic;
            }
            if (!event.target.checked) {
                this.marketUnchecked = true;
                this.classic = true;
                this.mapObject = []
                this.market = false;
                this.missionData.market = this.market;
                this.missionData.classic = this.classic;
                this.marketZoneSelected = true;
                this.selectedMarketZoneValue = this.translate.instant('Select market zone');

                this.marketZoneSelected = true;
                //this.disableMapClick = true;
                if (this.getExistingCheck) {
                    this.disableMapClick = true;
                } else {
                    this.disableMapClick = false;
                }
                this.mapObject = [{ 'longitude': this.missionData.missionZones[0].longitude, 'latitude': this.missionData.missionZones[0].latitude, flag: false }, { 'longitude': '', 'latitude': '', flag: false }];
            }
        }
        if (name === 'classic') {
            if (event.target.checked) {
                this.marketUnchecked = true;
                this.marketid = null;
                this.marketZoneSelected = true;

                this.selectedMarketZoneValue = this.translate.instant('Select market zone');
                this.market = false;
                this.classic = true;
                this.missionData.market = this.market;
                this.missionData.classic = this.classic;
                //this.mapObject = [];
                if (this.getExistingCheck){
                    this.disableMapClick = true;
                }else{
                    this.disableMapClick = false;
                }
                this.mapObject = [{ 'longitude': this.missionData.missionZones[0].longitude, 'latitude': this.missionData.missionZones[0].latitude, flag: false }, { 'longitude': '', 'latitude': '', flag: false }];
            } else {
                this.classic = false;
                this.marketZoneSelected = false;
                this.market = true;
                this.missionData.market = this.market;
                this.missionData.classic = this.classic;
            }

        }
    }

    selectedMarketZone(id, name) {
        this.marketZoneSelected = true;
        this.marketid = id;
        this.selectedMarketZoneValue = name;
        this.apiService.getLocationDetails({ 'locationName': this.selectedMarketZoneValue, 'locationType': 2 }).subscribe(res => {
            //this.mapObject = [];
            let market = res.data;
            this.missionData.markets = [];
            this.missionData.markets.push({
                longitude: market.longitude,
                latitude: market.latitude
            });
            this.mapObject = [{ 'longitude': this.missionData.markets[0].longitude, 'latitude': this.missionData.markets[0].latitude, flag: true }];
        });
    }

    toggleFieldAgent(fa) {
        this.selectedAssignee = fa;
        //this.agentSelected = true;
        // let deleteIndex;
        // this.mission.assignments[0].fieldAgents.push(this.mission.assignments[0].selectedFieldAgent);

        // this.mission.assignments[0].selectedFieldAgent = fa;
        // let faLength = this.mission.assignments[0].fieldAgents.length;
        // this.mission.assignments[0].fieldAgents.forEach((fieldAgent, delI) => {
        //     if (fa.userId === fieldAgent.userId) {
        //         deleteIndex = delI;
        //     }
        //     faLength--;
        //     if (faLength === 0) {
        //         this.mission.assignments[0].fieldAgents.splice(deleteIndex, 1);
        //     }
        // });
    }
    calendarReady = false;
    getMissiondates() {
        const date = new Date(Date.now());
        const month = date.getMonth() + 1;
        localStorage.removeItem('busyDates');
        this.busyDates = []
        this.apiService.getShiftWiseUsedMissionDates(date.getFullYear() + '-' + month + '-' + date.getDate(), missionTypes.CUSTOMER_SURVEY_TYPE_ID, this.isMorning ? 1 : 2)
            .subscribe(res => {
                console.log("res=", res);

                let busyDatesLen = res.dateDto.length;
                res.dateDto.forEach(resdate => {
                    resdate.day = parseInt(resdate.day, 10);
                    resdate.month = parseInt(resdate.month, 10);
                    resdate.year = parseInt(resdate.year, 10);

                    this.busyDates.push(resdate);

                    busyDatesLen--;
                    if (busyDatesLen === 0) {
                        localStorage.setItem('busyDates', JSON.stringify(this.busyDates));

                        this.calendarReady = true;
                    }
                });
            }, err => {
                this.calendarReady = true;
                this.custUtils.translateMessageObject({
                    title: this.translate.instant('No Field agents available'),
                    text: this.translate.instant('Please change the mission date or  ask admin to add more field agents.'),
                    type: 'warning',
                    cancelBtnText: '',
                    confirmBtnText: 'OK',
                    outsideClick: false,
                    showCancelBtn: false
                }, message => {
                    this.custUtils.translateAndPop(message).then(() => {
                        this.optionsUnassigned = [];
                        this.selectedAssignee = {};
                    }).catch(() => {
                        this.selectedAssignee = {};
                        this.optionsUnassigned = [];

                    });
                });
            });
    }
    
    changeShiftId(id) {
        if (id === 1) {
            this.isMorning = true;
            //this.getUnassignedUsers(this.missionId, false, this.missionData.missionStartDate);
            //this.getMissiondates();
            
        } else {
            this.isMorning = false;
            //this.getUnassignedUsers(this.missionId, false, this.missionData.missionStartDate);
            //this.getMissiondates();
        }

        let dateE = JSON.parse(localStorage.getItem('date'));
        if (dateE == null) {
            this.getUnassignedUsers(this.missionId, false, this.missionData.missionStartDate);
        }else{
            let datePickerDateSelected = new Date(UTILS.getDateFormat(this.missionData.missionStartDate));
            let existingDate = new Date(UTILS.getDateFormat(dateE));
            if (datePickerDateSelected.getTime() == existingDate.getTime()) {
                this.getUnassignedUsers(this.missionId, true, this.missionData.missionStartDate);
            } else {
                this.getUnassignedUsers(this.missionId, false, this.missionData.missionStartDate);
            }
        }
    }

    isDisabledSubmit(){
        if (this.missionData.missionName && this.missionData.missionDescription &&
            this.missionData.missionZones[0].name && this.missionData.missionZones[0].address && 
            this.missionData.missionZones[0].adptId && (this.optionsUnassigned.length > 0) &&
            (this.missionData.classic || (this.missionData.market && this.marketid)) && this.nameExists == false){
            return false;
        } else {
            return true;
        }
    }
}