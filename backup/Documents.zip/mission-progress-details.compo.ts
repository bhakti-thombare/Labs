import {
  Component,
  OnInit,
  ViewChild,
  OnDestroy,
  Input,
  Output,
  EventEmitter,
  ElementRef
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Subscription } from 'rxjs';
import { forkJoin } from 'rxjs/observable/forkJoin';
import * as moment from 'moment';
import { each, isMatch } from 'underscore';

import { POSMpd } from '@app/supervisor/mission-details-m/mission-progress-details/mpdIndex';
import { ApiService } from '@app/services/apiServices/api.service';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { StorageService } from '@app/services/storage-service.service';
import { CONSTANTSVALUES } from '@app/constants/constant-values';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ReassignComponent } from './reassign/reassign.component';
import { EventService } from '@app/services/events/event.service';
import { InfoSheetButtonComponent } from '@app/shared/info-sheet-button/info-sheet-button.component';
import { PosMpdPhotosComponent } from '@app/shared/pos-mpd-photos/pos-mpd-photos.component'
import { LocateMapComponent } from '@app/shared/locate-map/locate-map.component';
import { ValidateFlagComponent } from '@app/shared/validate-flag/validate-flag.component';
import { MissionListAlertsService } from '@app/services/Alerts/mission-list-alerts.service';
import { isNull } from 'util';
import { DatePipe } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';
import { CustomerSurveyAlertsService } from '@services/Alerts/customer-survey-alerts.service';
import { PedestrainAlertsService } from '@app/services/Alerts/pedestrainAlerts/pedestrain-alerts.service';
import * as _ from 'lodash' ;
import { HttpClient } from '@angular/common/http';
import { GridOptions } from 'ag-grid-community';
import swal from 'sweetalert2';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

@Component({
  selector: 'app-mission-progress-details',
  templateUrl: './mission-progress-details.component.html',
  styleUrls: ['./mission-progress-details.component.css']
})
export class MissionProgressDetailsComponent implements OnInit, OnDestroy {
  
  @ViewChild('mapSection') mapSection: ElementRef;
  @Output() back = new EventEmitter();
  @Output() objectApprove = new EventEmitter();
  private gridOptions:GridOptions;
  disableApprove: boolean = true;
  disableReassign: boolean = true;
  showGreenTick: string;
  enableButton: string;
  showInfoSheet: boolean;
  infoDetails = {};
  quartierId: any;
  missionId: any;
  coordinateOnMap: { latitude: any; longitude: any };
  coordinateOnMap1;
  showMpd: boolean = true;
  showCheckPoint: boolean;
  private subscriptions: Subscription[] = [];
  private utilityFunctions = new UtilityFunctions();
  mpdData: any = [];
  missionName: any;
  public columnDefs: any = [];
  public rowData: POSMpd[];

  overlayNoRowsTemplate: any;
  rowData1=[];
  missionDuration: any;
  rejectedPOS: number;
  rejectedCheckPoints: number;
  mission_Status: any;

  campaignEndDate: any = {};
  today: Date = new Date();
  evaluateFlag: boolean=false;
  timeOfConnection: any;
  missionStartDate: any;
  missionEndDate: any;
  lastSync: any;
  coordinates: any;
  quartierDetails:any ={}
  mapLoader: boolean=false;
  array: any;
  map;
  obj1=[];
  currentPage: any=1;
  newPageFlag: boolean;
  paginationChanged: any;
  gid: any;
  gridApi: any;
  infosheetCalled: boolean=false;
  browserLang: string;
  savedState: '';
  visit: boolean=false;
  prm: boolean=false;
  constructor(
    private apiService: ApiService,
    private route: ActivatedRoute,
    private router: Router,
    private storageService: StorageService,
    public customerSurveyAlert: CustomerSurveyAlertsService,
    private modalService: NgbModal,
    public _event: EventService,
    public datePipe: DatePipe,
    private pedsAlerts: PedestrainAlertsService,
    public missionListAlertsService: MissionListAlertsService,
    public translate: TranslateService,
    public _http: HttpClient
  ) {
   
    this.gridOptions = <GridOptions>{
      onGridReady: (params: any) => {

        this.gridOptions.api.setSortModel(this.savedState);
        this.gridOptions.api.paginationGoToPage(this.gridApi.api.paginationProxy.currentPage);
        // this.gridOptions.api.sizeColumnsToFit();
      }
    };
  }

  ngOnInit() {
    //console.log("MPD INIT");
    this.overlayNoRowsTemplate =
      '<span style="padding: 10px;">No Data Available</span>';
    this._event.broadcast({ eventName: 'showLoader', data: '' });
    this.getPos();
  }

  getUTCDate(date) {
    if (!isNull(date)) {
      let d = new Date(date);
      let cd = new Date(
        Date.UTC(
          d.getFullYear(),
          d.getMonth(),
          d.getDate(),
          d.getHours(),
          d.getMinutes(),
          d.getSeconds(),
          d.getMilliseconds()
        )
      );
      if (cd.toString() != 'Invalid Date')
        return (
          this.datePipe.transform(cd, `HH:mm`) +
          ` ${cd.getHours() >= 12 ? 'PM' : 'AM'}`
        );
    } else return 'NA';
  }

agentId;
posData;
mapObj=[];
  getPos() {
    this.overlayNoRowsTemplate =
      '<span style="padding: 10px;">No Data Available</span>';

    const id = JSON.parse(this.route.snapshot.paramMap.get('id'));
    this.subscriptions.push(
      forkJoin([
        this.apiService.posMpdCards(id),
        this.apiService.getPosMpd(id)
      ]).subscribe(res => {
        console.log(res);
        if(res[0].data.evaluateFlag==true){
          this.evaluateFlag=true;
        }
        else
          this.evaluateFlag=false;
        if (res[0].responseMessage === 'Success') {
         
          this.missionId = res[0].data.missionId;
          this.quartierId = res[0].data.quartierId;
          this.subscriptions.push(
            this.apiService
              .getQuartierCordinates({ quartier: this.quartierId })
              .subscribe(
                res => {
                  setTimeout(() => {
                    this.coordinates = res.data.dtos ? res.data.dtos : [];  
                  }, 50);
                },
                err => {
                  this.pedsAlerts
                    .somethingWentWrong()
                    .then(() => {
                    })
                    .catch(() => {});
                }
              )
          );
        
          this.agentId=res[0].data.fieldAgentId;
          this.visit=res[0].data.visit;
          this.prm=res[0].data.prm;
          /** for Issue 946 - Start*/
          this.mission_Status = res[0].data.missionStatus == 'Re assigned'? 10 : res[0].data.missionStatus;
          this.posData=res[1].data
          /* Below CODE Previously: used for checkpoints.component.ts - ngOnInit{missionStatus} && used for reassign.component.ts - reassign{status} 
        if(this.mission_Status===9){
          this.storageService.setData('enableButton', true); 
        }
        /** for Issue 946 - End*/
          this.storageService.setData(
            'currentStatusId',
            JSON.stringify(this.mission_Status)
          );
          this.storageService.setData(
            'missionId&quartierId',
            JSON.stringify({
              missionId: this.missionId,
              quartierId: this.quartierId
            })
          );
          this.mpdData = res[0].data;
          this.mpdData.timeOfConnection? this.timeOfConnection=this.mpdData.timeOfConnection.split(' '):false;
          this.mpdData.missionStartDate? this.missionStartDate=this.mpdData.missionStartDate.split(' '):false;
          this.mpdData.missionEndDate?this.missionEndDate=this.mpdData.missionEndDate.split(' '):false;
          // this.lastSync=this.mpdData.lastSync.split(' ');
          this.storageService.setData(
            'fieldAgentId',
            this.mpdData.fieldAgentId
          );
          this.mpdData.missionStartDate = moment(
            this.mpdData.missionStartDate
          ).format(CONSTANTSVALUES.VALUES.LIST_DATE_FORMAT);
          this.mpdData.missionEndDate = moment(
            this.mpdData.missionEndDate
          ).format(CONSTANTSVALUES.VALUES.LIST_DATE_FORMAT);
          this.missionName = res[0].data.missionName;
          this._event.broadcast({ eventName: 'hideLoader', data: '' });

          this.missionDuration = this.mpdData.missionDuration;
          this.getPosRejectedCount(this.missionId);
        }
        this.browserLang = this.translate.defaultLang;  
        if (res[1].responseMessage === 'Success') {
          this.getQuartiers(res[0].data.quartierId);
          for (let element of res[1].data) {
            if (element.isNew === 'YES' || element.isUpdated === 'YES') {
              this.rowData1.push(element);   
              this.obj1.push({'pos_id':element.posId,
              'pos_latitude_wgs84':element.latitude,
              'pos_longitude_wgs84':element.longitude});
            (this.browserLang == 'fr')? element.posName = element.posNameFr ? element.posNameFr : 'N/A': 
            (this.browserLang == 'nl')? element.posName = element.posNameNl ? element.posNameNl : 'N/A' :
            (this.browserLang == 'en')? element.posName = element.posNameEn ? element.posNameEn : 'N/A' : 'N/A';
            }
         }
          this.rowData1=_.orderBy(this.rowData1,'startUpdateTime','asc');
          this.rowData=this.rowData1;
          this.rowData.forEach((ele,index)=>{
            ele['event_id']=index+1,
            ele['Image1']=this.translate.instant('Storefront'),
            ele['Image2']=this.translate.instant('Advert'),
            ele['Image3']=this.translate.instant('Building')
          })
          this.rowData=_.orderBy(this.rowData,'event_id','desc');
          console.log("this.rowdata=",this.rowData);
          
          /* for Issue 946 */
          //this.enableButton = JSON.parse(this.storageService.getData('enableButton'));
          this.checkForEnable();
          this._event.broadcast({ eventName: 'hideLoader', data: '' });
          this.getColumnDef();
        } else if (!res[1].data) {
          this.rowData = null;
          this.checkForEnable();
        }
      })
    );
  }
  getMapDetails() {
    this.mapLoader=false;
    this.quartierDetailsPos=this.obj1;
    this.quartierDetails.checkPoints='';
    this.quartierDetails.pos=JSON.stringify(this.quartierDetailsPos);
    console.log(this.quartierDetails)
  }
  
  obj;
  quartierDetailsCheckpoints: Array<any> = [];
  quartierDetailsPos: Array<any> = [];
  o;b;
  getQuartiers(quartierId) {
    // this.mapLoader=true;
    this.subscriptions.push(
      this.apiService.getQuartiers({ quartierId: quartierId }).subscribe(
        res => {
          // this.getMapDetails();
          this._http.get(res.data).subscribe(result => {
          setTimeout(() => {
          if (result) {
            this.obj=this.quartierDetails=result;
            this.coordinates = this.coordinates;
            let pos=JSON.parse(this.obj.pos);
          // this.rowData.forEach((res,index)=>{
            // for (var i = 1, len = pos.length; i < len; i++) {
            //  console.log(i, ' ',res.posId);
            //   if(pos[i].pos_id == res.posId){
            //   this.quartierDetailsPos.push(pos[i]);
            //   // this.quartierDetailsCheckpoints.push(checkpoint[i]);
            //     i=len;
            //   }
            // }
          // });
          // this.quartierDetails.checkPoints=JSON.stringify(this.quartierDetailsCheckpoints),
          // this.quartierDetails.pos=JSON.stringify(this.quartierDetailsPos);
          this.getMapDetails();
          } else this.quartierDetails = {};
          // this.mapLoader=false;
        
        }, 80);
      },
      err => {
        // this.isQuartierReceived = false;
        // this.transactionMsg = '';
        // this.quartier = null;
        this.mapLoader=false;
        this.pedsAlerts.somethingWentWrong();
      })
  },
  err => {
    // this.isQuartierReceived = false;
    // this.transactionMsg = '';
    // this.quartier = null;
    this.mapLoader=false;
    this.pedsAlerts.somethingWentWrong();
  }));
  }

  getPosRejectedCount(missionId) {
    this.subscriptions.push(
      this.apiService.getPosRejectedCount(missionId).subscribe(res => {
        //console.log(res.data.rejectedPos, res.data.rejectedPosCheckpoint);
        this.campaignEndDate = new Date(res.data.campaignEndDate);
        console.log('this.campaignEndDate', this.campaignEndDate);

        this.rejectedPOS = res.data.rejectedPos;
        this.rejectedCheckPoints = res.data.rejectedPosCheckpoint;
        this.checkForEnable();
      })
    );
  }

  checkForEnable() {
    /** Issue 979 Start  */
    //console.log("******************Check Scenerio *********** ");
    //console.log("mission_Status=", this.mission_Status);
    // console.log('this.rowData=', this.rowData);

    this.disableApprove = true; //  Approve - Disable
    //this.disableReassign = true;    //  Reassign - Disable
    this.disableReassign = false; //  Reassign - Enable

    let pos_NotValidated = null;
    let All_pos_Approved = null;

    let pos_Approved = 0;
    let posNotUpdated = null;
    let posUpdatedNotValidated = null;
    //let pos_Rejected = null;
    //let pos_Blank = null;

    if (this.mission_Status === 1 || this.mission_Status === 2) {
      // If mission state is Done or Inprogress
      this.enableButton = null; // Hide Both Buttons
    }
    if (this.mission_Status === 9) {
      // If mission state is Overdue
      this.enableButton = 'true'; // Show Both Buttons
      if (this.rowData) {
        for (let data of this.rowData) {
          if (data.validationFlag == null) {
            pos_NotValidated = true;
          }
          if (data.validationFlag == '1') {
            pos_Approved = pos_Approved + 1;
          }
          if (data['isUpdated'] == null) {
            posNotUpdated = true;
          }

          if (data['isUpdated'] == 'YES' && data.validationFlag == null) {
            posUpdatedNotValidated = true;
          }
        }
        if (this.rowData.length > 0 && this.rowData.length == pos_Approved) {
          All_pos_Approved = true;
        }
      }

      if (pos_NotValidated == true) {
        this.disableReassign = true; //  Reassign - Disable
        this.disableApprove = true; //  Approve - Disable
      }

      if (pos_NotValidated == null && All_pos_Approved == true) {
        this.disableApprove = false; //  Approve - Enable
        this.disableReassign = true; //  Reassign - Disable
      }
      if (pos_NotValidated == true && posNotUpdated == true) {
        this.disableReassign = false; //  Reassign - Enable
      }

      if (posUpdatedNotValidated == true) {
        this.disableReassign = true; //  Reassign - Disable
      }

      // console.log('All_pos_Approved', All_pos_Approved);
      // console.log('pos_NotValidated', pos_NotValidated);
      // console.log('pos_Approved', pos_Approved);
      // console.log('posNotUpdated', posNotUpdated);

      /** Issue 979 End  */
    }
  }

  private getColumnDef() {
    
    this.columnDefs = [
      {
        headerClass: "checkbox4",
        headerName: this.translate.instant('Event No.'),
        field: 'event_id',
        width: 102,
        sortable:true,
        sortingOrder: ['desc', 'asc'],
        unSortIcon: true
      },
      // {
      //   headerName: this.translate.instant('Date of update'),
      //   field: 'dateOfUpdate',
      //   width: 100,
      //   valueGetter: params =>
      //     params.data.dateOfUpdate
      //       ? moment(params.data.dateOfUpdate).format(
      //           CONSTANTSVALUES.VALUES.LIST_MPD_FORMAT
      //         )
      //       : ''
      // },
      {
        headerName: this.translate.instant('Start update time'),
        field: 'startUpdateTime',
        width: 100,
        sortable:true,
        sortingOrder: ['desc', 'asc'],
        unSortIcon: true,
        valueGetter: params =>
          params.data.startUpdateTime
            ? params.data.startUpdateTime.split(' ')[1]
            : ''
      },
      {
        headerClass: "checkbox",
        headerName: this.translate.instant('Duration'),
        field: 'duration',
        sortable:true,
        unSortIcon: true,
        sortingOrder: ['desc', 'asc'],
        width: 100,
        cellClass: "grid-cell-centered",
      },
      {
        headerClass: "checkbox5",
        headerName: this.translate.instant('POS Name'),
        field: 'posName',
        sortable:true,
        sortingOrder: ['desc', 'asc'],
        unSortIcon: true,
        width: 130,

      },
      {
        headerClass: "checkbox1",
        headerName: this.translate.instant('Address'),
        field: 'address',
        width: 167,
        sortable:true,
        sortingOrder: ['desc', 'asc'],
        unSortIcon: true,
        cellClass: ".grid-cell-centered-addr",
        comparator: this.dateComparator,
      },
      {
        headerName: this.translate.instant('Locate on map'),
        field: '',
        width: 80,
        cellRendererFramework: LocateMapComponent
      },
     
      {
        headerClass: "checkbox2",
        headerName: this.translate.instant('Situation'),
        field: 'situation',
        width: 170,
        sortable:true,
        sortingOrder: ['desc', 'asc'],
        unSortIcon: true,
        Class: ".grid-cell-centered-addr",
        valueGetter: params =>
          params.data.isNew
            ? this.translate.instant('New Point of Sale')
            : params.data.situation
            ? this.translate.instant(params.data.situation)
            : ''
      },
      {
        headerName: this.translate.instant('Info sheet link'),
        field: 'link',
        width: 70,
        cellRendererFramework: InfoSheetButtonComponent
      },
      {
        headerClass: "checkbox3",
        headerName: this.translate.instant('Photo'),
        class: "grid-cell-centered",
        width: 87,
        cellRendererFramework: PosMpdPhotosComponent

      },
      
      {
        headerName: this.translate.instant('Validation'),
        field: 'validationFlag',
        width: 88,
        sortable:true,
        sortingOrder: ['desc', 'asc'],
        unSortIcon: true,
        cellRendererFramework: ValidateFlagComponent
      }
    ];
  }

  
  dateComparator(valueA, valueB, nodeA, nodeB, isInverted) {
    
    let flag;
   
    if (valueA == valueB) {
      return 0;
    } else {
      let a = valueA.split(',');
      let b = valueB.split(',');
     var a1=parseFloat(a[1]); var b1=parseFloat(b[1]);
      if ((a[0].toLowerCase() == b[0].toLowerCase())) {
       if(a1 > b1){
         flag=1;
       }
       else flag=-1;
      }
      else if (a[0].trim().toLowerCase() > b[0].trim().toLowerCase()) {
        flag = 1;
      }
    else
      flag=-1;
    return flag;
  }
  }
  sortNullString(a, b) {
    a = a == '' ? ' ' : a; 
    b = b == '' ? ' ' : b;
    if (a === b) { return 0 }; 
    if (a < b) { return -1 }; 
    if (a > b) { return 1 }; 
};
  // valueGetter: params =>
  // params.data.isUpdated === 'YES' || params.data.isUpdated === 'NO' ? 'Question' : ''

  getToCheckpoint() {
    this.showCheckPoint = true;
    this.showMpd = false;
    this.showInfoSheet = false;
  }
 

  onCellClicked($event) {

    /** for Issue 915 - Change Language From EN-FR-NL start */
    if (
      $event.colDef.headerName === this.translate.instant('Locate on map') ||
      $event.colDef.headerName == 'Locate on map' ||
      $event.colDef.headerName == 'Localiser sur la carte' ||
      $event.colDef.headerName == 'Zoek op de Kaart'
    ) {
      this.coordinateOnMap = {
        latitude: parseFloat($event.data.longitude).toFixed(5),
        longitude: parseFloat($event.data.latitude).toFixed(5)
      };
      console.log(this.coordinateOnMap);
      console.log(this.quartierDetails.pos);
      this.mapSection.nativeElement.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest',
      });
    }
    if (
      $event.colDef.headerName === this.translate.instant('Info sheet link') ||
      $event.colDef.headerName == 'Info sheet link' ||
      $event.colDef.headerName == 'Lien fiche info' ||
      $event.colDef.headerName == 'Infoblad link'
    ) {
      this.infoDetails = {
        id: $event.data.id,
        posId: $event.data.posId,
        isUpdated: $event.data.isUpdated,
        visit: this.visit,
        prm: this.prm
      };
      this.showCheckPoint = false;
      this.showMpd = false;
      this.showInfoSheet = true;
    }
    /** for Issue 915 - Change Language From EN-FR-NL End */
    /*
    if ($event.colDef.headerName === this.translate.instant('Locate on map') ) {
      this.coordinateOnMap = ({ latitude: $event.data.latitude, longitude: $event.data.longitude });
      this.mapSection.nativeElement.scrollIntoView({ behavior: "smooth", block: "start", inline: "nearest" });
    }
    if ($event.colDef.headerName === this.translate.instant('Info sheet link')) {
      
      this.infoDetails = {
        id: $event.data.id,
        posId: $event.data.posId,
        isUpdated: $event.data.isUpdated
      }
      this.showCheckPoint = false;
      this.showMpd = false;
      this.showInfoSheet = true;    
    }
    */
  }

  flyTo(a: Array<number>) {
    if (this.map) {
      this.map.flyTo({
        center: a,
        zoom: 30,
        bearing: 0,
        curve: 1
      });    
    }
  }

  approve() {
    this._event.broadcast({ eventName: 'showLoader' });
    let supervisorId = this.storageService.getData('userId');
    let currentStatusId = this.storageService.getData('currentStatusId');
    const reqObj = {
      missionId: this.missionId,
      userId: this.mpdData.fieldAgentId,
      shiftId: null,
      iterations: null,
      supervisorId: parseInt(supervisorId),
      currentStatus: parseInt(currentStatusId)
    };
    this.subscriptions.push(
      this.apiService.approvePOSMission(reqObj).subscribe(res => {
        this._event.broadcast({ eventName: 'hideLoader' });
        this.missionListAlertsService.approveMpdAlert();
        this.router.navigate(['/supervisor/missions']);
      })
    );
  }

  navigateToReassign() {
    this.router.navigate(['/supervisor/missions/reassign']);
  }
  private modalRef;
  @ViewChild('myModal') myModal;

  openModal(){
    this.modalRef = this.modalService.open(this.myModal, {
        backdrop: true,
        keyboard: false,
    })
}
evaluation;
check(key){
  console.log("key=",key);
  this.evaluation=key; 
}
evaluationDone=false;
evaluateMission(){
  this.evaluationDone=true;
  this.modalRef.close();
  let bad,correct,perfect
  if(this.evaluation=='bad'){
    bad=true;
    correct=false;
    perfect=false;
  } else if(this.evaluation=='correct'){
    correct=true;
    bad=false;
    perfect=false;
  }else {
    perfect=true;
    correct=false;
    bad=false;
  }
  const reqBody={
    missionId:this.missionId,
    agentId:this.agentId,
    badlyDone:bad,
    correctlyDone:correct,
    perfectlyDone:perfect
  }
  this.apiService.posEvaluate(reqBody).subscribe((res)=>{
    console.log("success=",res);
    if(res.responseCode==200){
      this.evaluateFlag=true;
      this.missionListAlertsService.evaluateMpd();
    }
    
  })
}
// isValidStatusAvail() {
// //   console.log("this.posData",this.posData);
  
//   let data = this.posData;
//   if (data) {
//     for (let i = 0; i < data.length; i++) {
//       const element = data[i];
//       console.log("element=",element);
//       if(element.isUpdated !== null && element.validationFlag == null){
//         return true
//       }
//     }
//     }
//   }

  openAssignModal() {
    // this.router.navigate([`missions/details/${this.missionId}/2/reassign`])
    // swal(MESSAGECONSTANTS.ALERT_MESSAGES.CAMPAIGN_EXPIRED_TITLE, '', 'warning').then(data => {
    //   // this.location.back();
    // });

    return swal({
      title: this.translate.instant('The mission is within an overdue campaign. If you want to select a new assignment date, please first contact your Admin in order to expand campaign duration.'),
      // text: this.translate.instant('The mission is within an overdue campaign. If you want to select a new assignment date, please first contact your Admin in order to expand campaign duration.') + '?',
      type: 'warning', 
      // allowOutsideClick: false,
    
      confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_USE_EXISTING_ZONE),
      // showCancelButton: true,
    });
    
    // const reAssignData = {
    //   missionId: this.missionId,
    //   quartierId: this.quartierId,
    //   fieldAgentId: this.mpdData.fieldAgentId
    // };

    // if (this.today >= this.campaignEndDate) {
    //   // console.log('Today is Smaller Campaign EXP');
    //   this.customerSurveyAlert
    //     .campainIsExpireAlert()
    //     .then(rs => {})
    //     .catch(err => err);
    // } else {
    //   const modalRef = this.modalService.open(ReassignComponent);
    //   modalRef.componentInstance.data = reAssignData;
    // }
  }
 
  close(){
    this.modalRef.close();
  }

  closeInfoSheetandCheckPoint(command) {
    if (command === 'back') {
      this.getPosRejectedCount(this.missionId);
    }
    this.infosheetCalled=true;   
    this.showCheckPoint = false;
    this.showMpd = true;
    this.showInfoSheet = false;
  }

  updateData(command){

    this.mpdData.correctedPos=command.correctedPos;
    this.mpdData.invalidPos=command.invalidPos;
    this.mpdData.validatedPos= command.validatedPos;
    this.evaluateFlag=command.evaluateFlag;
    this.rowData.forEach(item => {
      if(item.posId === command.posId && command.validationFlag == '1'){
        item.validationFlag=command.validationFlag;
        item.posNameFr = command.posNameFr;
        item.posNameEn = command.posNameEn;
        item.posNameNl = command.posNameNl;
        item.address = command.address;
        item.validationFlag == '1'? item.validatedPos=true: item.invalidPos=true;
        (this.browserLang == 'fr')? item.posName = item.posNameFr : false; 
        (this.browserLang == 'nl')? item.posName = item.posNameNl :false;
        (this.browserLang == 'en')? item.posName = item.posNameEn :false;
      }
      else if(item.posId === command.posId && command.validationFlag !== '1'){
        item.validationFlag=command.validationFlag;
        item.validationFlag == '1'? item.validatedPos=true: item.invalidPos=true;
      }
    });
    this.infosheetCalled=true;
    // this.getPosRejectedCount(this.missionId);
    this.showCheckPoint = false;
    this.showMpd = true;
    this._event.broadcast({ eventName: 'hideLoader', data: '' });
    this.showInfoSheet = false;
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }

  postSort(e){
    if(e !== undefined){
    this.savedState = e.api.getSortModel();
    }
  }  

  onPaginationChanged(event) {
    if (event.newPage === true) {
      this.newPageFlag=true;
      this.gridApi=event;
      // this.postSort(event);
      (this.savedState.length !== 0)? this.gridOptions.api.setSortModel(this.savedState) : false;
      this.rowData;
      this.currentPage=event.api.paginationProxy.currentPage;
      this.currentPage=event.api.paginationGetCurrentPage();
      // this.storageService.setData(this.currentPage, this.agGrid.api.paginationGetCurrentPage() + '');
    }
  }

  ngOnDestroy() {
    //this.storageService.removeData('enableButton');
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }
 
  getUIDate(date) { return (date) ? this.datePipe.transform(date, 'dd/MM/yyyy') : 'NA'; };
  getUITime(date) { return (!isNull(date)) ? `${this.datePipe.transform(date, "HH:mm:ss")}` : 'NA'; };
  getIsNull(value) { return (!isNull(value) ? value : 'NA'); };
  // getUITime(date) { 
  //   let res= (date ? date.split(' '): 'NA');
  //   return res[1]; 
  // };

  isValidStatusAvail() {
    let flag= false;
    let shiftData = this.posData;
    if (shiftData) {
      for (let i = 0; i < shiftData.length; i++) {
        const element = shiftData[i];
        if (element.isUpdated == "YES") {
          if (isNull(element.validatedPos) && isNull(element.invalidPos)) {
            if(element.isNew =='YES'){
              flag = true;
            }
            else if(element.situation){
              flag = true;
            }
          }
        }
        else break;
      }
      if(flag == true) return true; 
      else return false;
    }
  }

}
