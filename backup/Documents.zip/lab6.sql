use pubs;
-- 1
select * from titles;
select * from publishers;

-- 2
-- SELECT titles.title_id, titles.title, publishers.pub_id, publishers.pub_name FROM titles, publishers 
-- WHERE titles.pub_id = publishers.pub_id ;
SELECT t.title, p.pub_name FROM titles t JOIN publishers p ON p.pub_id = t.pub_id;

-- 3
select * from titles;
select * from publishers;

SELECT titles.title_id, titles.ytd_sales, titles.title, SUM(titles.ytd_sales) "Total Sales", publishers.pub_id, publishers.pub_name
FROM titles, publishers 
WHERE titles.pub_id = publishers.pub_id group by publishers.pub_name;

SELECT t.ytd_sales, p.pub_name FROM titles t JOIN publishers p ON p.pub_id = t.pub_id GROUP BY p.pub_name;

-- 4 
select * from authors;
select * from publishers;
select p.pub_name, p.city, a.au_fname, a.au_lname, a.city
from publishers p, authors a where p.city = a.city;


-- 5 same as 4-not confirm
select p.pub_name, p.city, a.au_fname, a.au_lname, a.city
from publishers p, authors a where p.city = a.city;


SELECT a.au_lname, a.city, p.pub_name, p.city FROM publishers p LEFT JOIN authors a ON p.city = a.city;


-- 6 not confirm


SELECT DISTINCT t.pub_id, p.pub_name FROM publishers p
     JOIN titles t ON t.pub_id = p.pub_id
	WHERE type = 'business';



select * from titles;

-- 7 
SELECT t.title, CONCAT(a.au_fname, ' ', a.au_lname) "Author's Name"
     FROM titles t
     JOIN titleauthor ta ON ta.title_id = t.title_id
    JOIN authors a ON a.au_id  = ta.au_id;



-- 8.a -create emp table
create table Employees(emp_id varchar(10), ename varchar(40), dept_id varchar(20),
job varchar(35), mgr_id varchar(20), bsal decimal(10,4));
show tables;
desc Employees;

insert into Employees values(101,'Sameer',10,'President',NULL,50000);
select * from Employees;
insert into Employees values(102,'Srinivas',10,'VP',101,40000);
insert into Employees values(103,'Nanda',20,'VP',101,40000);
insert into Employees values(104,'Ram',30,'DGM',102,35000);
insert into Employees values(105,'Vivek',20,'PM',103,30000);
insert into Employees values(106,'Venkat',20,'Tech Lead',105,25000);

-- 8.b create departments
create table Departments(dept_id varchar(20), dname varchar(40),
location varchar(40));
select * from departments;
insert into Departments values(10,'Crop','Dallas');
insert into Departments values(20,'PW','Bangalore');
insert into Departments values(30,'SP','Pune');
insert into Departments values(40,'MS','Hyderabad');

-- 8.c create salgrade function
create table salgrades(grade varchar(20), min_sal decimal(10,4), max_sal decimal(10,4));
select * from salgrades;
desc salgrades;
insert into salgrades values('A',40001,50000);
insert into salgrades values('B',30001,40000);
insert into salgrades values('C',20001,30000);

-- 9
use pubs;
desc employees;
SELECT e.emp_id , e.ename , e.dept_id , d.dname FROM employees e 
JOIN departments d ON e.dept_id = d.dept_id;

SELECT e.ename, e.dept_id, d.dname
    FROM employees e
     JOIN departments d ON d.dept_id = e.dept_id;

-- 10
select * from employees;
select * from departments;
SELECT DISTINCT e.job, e.dept_id, d.location	FROM  employees e,  departments d
WHERE e.dept_id = d.dept_id AND e.dept_id = 30;
    
    
-- 11 not sure commission is not there
desc employees;
desc departments;

SELECT e.ename, d.dname, d.location, e.bsal
	FROM employees e, departments d
	WHERE e.dept_id = d.dept_id;
    
    
-- 12
select * from employees;
SELECT e.ename, d.dname FROM employees e, departments d 
WHERE e.dept_id = d.dept_id AND e.ename LIKE '%A%';

SELECT e.ename, d.dname
    FROM employees e
     JOIN departments d on d.dept_id = e.dept_id
    WHERE e.ename regexp '[S]';

-- 13
select * from employees;
SELECT 	e.ename, e.job, e.dept_id,d.dname, d.location FROM 	employees e JOIN departments d
ON 	(e.dept_id = d.dept_id) WHERE 	LOWER(d.location) = 'Dallas';

-- 14
select * from employees;
select * from departments;
-- SELECT	 e.ename "Employee", e.emp_id "Employee Number", e.mgr_id "Manager" FROM     employees e ;
SELECT e.ename "Employee", e.emp_id "Emp No", m.ename "Manager", m.emp_id "Manager No."
FROM employees e JOIN employees m on m.emp_id = e.mgr_id;



-- 15
SELECT	e.ename "Employee", e.emp_id "Emp No",e.mgr_id  FROM employees e where e.mgr_id IS NULL ;

-- 16 
DESC salgrades;
select * from salgrades;
SELECT e.ename, e.job, d.dname,
	e.bsal, s.grade
	FROM employees e, departments d, salgrades s
	WHERE e.dept_id = d.dept_id
	AND e.bsal BETWEEN s.min_sal AND s.max_sal;
    

 SELECT e.ename "Employee", e.job "Job", d.dname "Department", e.bsal "Salary",
 (SELECT s.grade FROM salgrades s WHERE e.bsal > s.min_sal AND e.bsal <= s.max_sal) "Grade"
    -> FROM employees e
    -> JOIN departments d ON e.dept_id = d.dept_id;

-- ==================1 to 16 same as handson5=====================================

-- 17
select * from publishers;
select * from titles;

select * from titles;

select pub_name  from publishers  
where exists (select * from titles where pub_id = publishers.pub_id and type = "business"); 

SELECT p.pub_id, p.pub_name
    FROM publishers p
     JOIN titles t ON p.pub_id = t.pub_id
     WHERE t.type = 'business';
     
     SELECT p.pub_id, p.pub_name
    FROM publishers p
     WHERE EXISTS (SELECT 1 FROM titles t
    WHERE t.type = 'business' AND t.pub_id = p.pub_id);

-- 18
select * from titles;
select pub_name from publishers  
where exists (select * from titles where pub_id = publishers.pub_id and type != "mod_cook"); 

SELECT p.pub_id, p.pub_name
     FROM publishers p
     JOIN titles t ON p.pub_id = t.pub_id
     WHERE t.type != 'mod_cook';
     
     SELECT p.pub_id, p.pub_name
     FROM publishers p
     WHERE EXISTS (SELECT 1 FROM titles t
    WHERE t.type != 'mod_cook' AND t.pub_id = p.pub_id);
     
-- 19 not sure
select title, type, AVG(ytd_sales) from titles 
where exists(select title = "The Busy Executive's Database Guide"); 

select title, type, AVG(ytd_sales) from titles 
where exists(select title = "Is Anger the Enemy?"); 

-- 20
SELECT 	 t.title, t.type, p.pub_name, p.pub_id  FROM 	titles t JOIN publishers p
ON 	(t.pub_id = p.pub_id) WHERE t.type= 'business';

SELECT p.pub_name FROM publishers p WHERE EXISTS (SELECT 1 FROM titles t 
WHERE t.type = 'business' AND t.pub_id = p.pub_id);

-- 21
select * from publishers;
SELECT 	 * from publishers where city="Paris";
SELECT p.pub_id, p.pub_name FROM publishers p WHERE p.city = 'Paris';

-- 22 not sure
select * from titles;
select title, advance, MIN(advance), MAX(advance), AVG(advance) from titles where exists
(select advance < AVG(advance) from titles);

SELECT t.title, t.advance
    FROM titles t
     WHERE t.advance > (SELECT AVG(t1.advance) FROM titles t1
    WHERE t1.type = 'business');


-- 23 not working
SELECT CONCAT(a.au_fname, ' ', a.au_lname) "Author Name"
    -> FROM authors a
    -> JOIN titleauthor ta ON ta.au_id = a.au_id
    -> JOIN titles t ON t.title_id = ta.title_id
    -> WHERE t.title = 'Net Etiquette';
    
-- 24 not working
SELECT CONCAT(a.au_fname, ' ', a.au_lname) "Author Name"
    FROM authors a
     JOIN titleauthor ta ON ta.au_id = a.au_id
     JOIN titles t ON t.title_id = ta.title_id
     WHERE t.type = 'business';

-- 25 not sure
select title, title_id, price, MIN(price), MAX(price), AVG(price) from titles where exists
(select price > MAX(price) from titles where pub_id = 0736);

SELECT t.title, t.title_id
     FROM titles t
     WHERE t.price > (SELECT MAX(t1.price) 
     FROM titles t1
     JOIN publishers p ON p.pub_id = t1.pub_id
     WHERE p.pub_id = 0736);


-- 26
select title, title_id, price, MIN(price), MAX(price), AVG(price) from titles where exists
(select price > MAX(price) from titles where pub_id = 0736);

select title, title_id, price, MIN(price), MAX(price), AVG(price) from titles where exists
(select price > MAX(price) from titles where pub_id = 1389);

select title, title_id, price, MIN(price), MAX(price), AVG(price) from titles where exists
(select price > MAX(price) from titles where pub_id = 9999);

 SELECT t.title, t.title_id FROM titles t WHERE t.price > (SELECT MIN(t1.price) 
FROM titles t1 JOIN publishers p ON p.pub_id = t1.pub_id WHERE p.pub_id = 1389);
 
 SELECT t.title, t.title_id FROM titles t 
 WHERE t.price > (SELECT MIN(t1.price)  FROM titles t1 JOIN publishers p 
 ON p.pub_id = t1.pub_id WHERE p.pub_id = 0736);
    
    
     SELECT t.title, t.title_id
     FROM titles t
     WHERE t.price > (SELECT MIN(t1.price) 
     FROM titles t1
     JOIN publishers p ON p.pub_id = t1.pub_id
     WHERE p.pub_id = 9999);

-- 27
SELECT DISTINCT p.pub_name, p.city, a.au_fname	FROM  publishers p,  authors a
WHERE p.city = a.city; 

SELECT p.pub_name FROM publishers p WHERE p.city = ANY(SELECT a.city  FROM authors a);

==================================

mysql> SELECT t.title, p.pub_name
    -> FROM titles t
    -> JOIN publishers p ON p.pub_id = t.pub_id;
+-----------------------------------------------------------------+----------------------+
| title                                                           | pub_name             |
+-----------------------------------------------------------------+----------------------+
| The Busy Executive's Database Guide                             | Algodata Infosystems |
| Cooking with Computers: Surreptitious Balance Sheets            | Algodata Infosystems |
| You Can Combat Computer Stress!                                 | New Moon Books       |
| Straight Talk About Computers                                   | Algodata Infosystems |
| Silicon Valley Gastronomic Treats                               | Binnet & Harley      |
| The Gourmet Microwave                                           | Binnet & Harley      |
| The Psychology of Computer Cooking                              | Binnet & Harley      |
| But Is It User Friendly?                                        | Algodata Infosystems |
| Secrets of Silicon Valley                                       | Algodata Infosystems |
| Net Etiquette                                                   | Algodata Infosystems |
| Computer Phobic AND Non-Phobic Individuals: Behavior Variations | Binnet & Harley      |
| Is Anger the Enemy?                                             | New Moon Books       |
| Life Without Fear                                               | New Moon Books       |
| Prolonged Data Deprivation: Four Case Studies                   | New Moon Books       |
| Emotional Security: A New Algorithm                             | New Moon Books       |
| Onions, Leeks, and Garlic: Cooking Secrets of the Mediterranean | Binnet & Harley      |
| Fifty Years in Buckingham Palace Kitchens                       | Binnet & Harley      |
| Sushi, Anyone?                                                  | Binnet & Harley      |
+-----------------------------------------------------------------+----------------------+
18 rows in set (0.00 sec)

mysql> SELECT t.ttd_sales, p.pub_name
    -> FROM titles t
    -> JOIN publishers p ON p.pub_id = t.pub_id
    -> GROUP BY p.pub_name;
+-----------+----------------------+
| ttd_sales | pub_name             |
+-----------+----------------------+
|      4095 | Algodata Infosystems |
|     18722 | New Moon Books       |
|      2032 | Binnet & Harley      |
+-----------+----------------------+
3 rows in set (0.00 sec)
mysql> SELECT a.au_lname, a.city, p.pub_name, p.city
    -> FROM publishers p
    -> JOIN authors a ON p.city = a.city;
+----------+----------+----------------------+----------+
| au_lname | city     | pub_name             | city     |
+----------+----------+----------------------+----------+
| Carson   | Berkeley | Algodata Infosystems | Berkeley |
| Bennet   | Berkeley | Algodata Infosystems | Berkeley |
+----------+----------+----------------------+----------+
2 rows in set (0.00 sec)

mysql> SELECT a.au_lname, a.city, p.pub_name, p.city
    -> FROM publishers p
    -> LEFT JOIN authors a ON p.city = a.city;
+----------+----------+-----------------------+------------+
| au_lname | city     | pub_name              | city       |
+----------+----------+-----------------------+------------+
| NULL     | NULL     | New Moon Books        | Boston     |
| NULL     | NULL     | Binnet & Harley       | Washington |
| Bennet   | Berkeley | Algodata Infosystems  | Berkeley   |
| Carson   | Berkeley | Algodata Infosystems  | Berkeley   |
| NULL     | NULL     | Five Lakes Publishing | Chicago    |
| NULL     | NULL     | Ramona Publishers     | Dallas     |
| NULL     | NULL     | GGG&G                 | Munchen    |
| NULL     | NULL     | Scootney Books        | Ner York   |
| NULL     | NULL     | Lucerne Publishing    | Paris      |
+----------+----------+-----------------------+------------+
9 rows in set (0.00 sec)

mysql> SELECT DISTINCT t.pub_id, p.pub_name
    -> FROM publishers p
    -> JOIN titles t ON t.pub_id = p.pub_id
    -> WHERE type = 'business';
+--------+----------------------+
| pub_id | pub_name             |
+--------+----------------------+
| 1389   | Algodata Infosystems |
| 0736   | New Moon Books       |
+--------+----------------------+
2 rows in set (0.00 sec)

mysql> SELECT t.title, CONCAT(a.au_fname, ' ', a.au_lname) "Author's Name"
    -> FROM titles t
    -> JOIN titleauthor ta ON ta.title_id = t.title_id
    -> JOIN authors a ON a.au_id  = ta.au_id;
+-----------------------------------------------------------------+-------------------------+
| title                                                           | Author's Name           |
+-----------------------------------------------------------------+-------------------------+
| The Busy Executive's Database Guide                             | Marjorie Green          |
| The Busy Executive's Database Guide                             | Abraham Bennet          |
| Cooking with Computers: Surreptitious Balance Sheets            | Michael O'Leary         |
| Cooking with Computers: Surreptitious Balance Sheets            | Stearns MacFeather      |
| You Can Combat Computer Stress!                                 | Marjorie Green          |
| Silicon Valley Gastronomic Treats                               | Innes del Castillo      |
| The Gourmet Microwave                                           | Michel DeFrance         |
| The Gourmet Microwave                                           | Anne Ringer             |
| But Is It User Friendly?                                        | Cheryl Carson           |
| Secrets of Silicon Valley                                       | Ann Dull                |
| Secrets of Silicon Valley                                       | Michel DeFrance         |
| Net Etiquette                                                   | Charlene Locksley       |
| Computer Phobic AND Non-Phobic Individuals: Behavior Variations | Stearns MacFeather      |
| Computer Phobic AND Non-Phobic Individuals: Behavior Variations | Livia Karsen            |
| Is Anger the Enemy?                                             | Anne Ringer             |
| Is Anger the Enemy?                                             | Albert Ringer           |
| Life Without Fear                                               | Albert Ringer           |
| Prolonged Data Deprivation: Four Case Studies                   | Johnson White           |
| Emotional Security: A New Algorithm                             | Charlene Locksley       |
| Onions, Leeks, and Garlic: Cooking Secrets of the Mediterranean | Sylvia Panteley         |
| Fifty Years in Buckingham Palace Kitchens                       | Reginald Blotchet-Halls |
| Sushi, Anyone?                                                  | Michael O'Leary         |
| Sushi, Anyone?                                                  | Burt Gringlesby         |
+-----------------------------------------------------------------+-------------------------+
23 rows in set (0.01 sec)

mysql> create table Employees(emp_id varchar(10), ename varchar(40), dept_id varchar(20),
    -> job varchar(35), mgr_id varchar(20), bsal decimal(10,4));
Query OK, 0 rows affected (0.04 sec)

mysql> INSERT INTO Employees VALUES(101, 'Sameer', 10, 'President', NULL, 50000);INSERT INTO Employees VALUES(102, 'Srinivas', 10, 'VP', 101, 40000);INSERT INTO Employees VALUES(103, 'Nanda', 20, 'VP', 101, 40000);INSERT INTO Employees VALUES(104, 'Ram', 30, 'DGM', 102, 35000);INSERT INTO Employees VALUES(105, 'Vivek', 20, 'PM', 103, 30000);INSERT INTO Employees VALUES(106, 'Venkat', 20, 'Tech Lead', 105, 25000);
Query OK, 1 row affected (0.01 sec)

Query OK, 1 row affected (0.00 sec)

Query OK, 1 row affected (0.00 sec)

Query OK, 1 row affected (0.00 sec)

Query OK, 1 row affected (0.00 sec)

Query OK, 1 row affected (0.00 sec)

mysql> CREATE TABLE Departments(dept_id VARCHAR(20), dname VARCHAR(40), location VARCHAR(40));
Query OK, 0 rows affected (0.02 sec)

mysql> INSERT INTO Departments VALUES(10, 'Crop', 'Dallas');INSERT INTO Departments VALUES(20, 'PW', 'Bangalore');INSERT INTO Departments VALUES(30, 'SP', 'Pune');INSERT INTO Departments VALUES(40, 'MS', 'Hyderabad');
Query OK, 1 row affected (0.01 sec)

Query OK, 1 row affected (0.00 sec)

Query OK, 1 row affected (0.00 sec)

Query OK, 1 row affected (0.00 sec)

mysql> CREATE TABLE salgrades(grade VARCHAR(20), min_sal DECIMAL(10,4), max_sal DECIMAL(10,4));
Query OK, 0 rows affected (0.03 sec)

mysql> INSERT INTO salgrades VALUES('A', 40001, 50000);INSERT INTO salgrades VALUES('B', 30001, 40000);INSERT INTO salgrades VALUES('C', 20001, 30000);
Query OK, 1 row affected (0.01 sec)

Query OK, 1 row affected (0.00 sec)

Query OK, 1 row affected (0.00 sec)

mysql> SELECT e.ename, e.dept_id, d.dname
    -> FROM employees e
    -> JOIN departments d ON d.dept_id = e.dept_id;
+----------+---------+-------+
| ename    | dept_id | dname |
+----------+---------+-------+
| Sameer   | 10      | Crop  |
| Srinivas | 10      | Crop  |
| Nanda    | 20      | PW    |
| Ram      | 30      | SP    |
| Vivek    | 20      | PW    |
| Venkat   | 20      | PW    |
+----------+---------+-------+
6 rows in set (0.00 sec)

mysql> SELECT DISTINCT e.job, d.location
    -> FROM employees e
    -> JOIN departments d on d.dept_id = e.dept_id
    -> WHERE d.dept_id = 30;
+------+----------+
| job  | location |
+------+----------+
| DGM  | Pune     |
+------+----------+
1 row in set (0.00 sec)

mysql> SELECT e.ename, d.dname
    -> FROM employees e
    -> JOIN departments d on d.dept_id = e.dept_id
    -> WHERE e.ename regexp '[A]';
+----------+-------+
| ename    | dname |
+----------+-------+
| Sameer   | Crop  |
| Srinivas | Crop  |
| Nanda    | PW    |
| Ram      | SP    |
| Venkat   | PW    |
+----------+-------+
5 rows in set (0.00 sec)

mysql> SELECT e.ename, e.job, e.dept_id, d.dname
    -> FROM employees e
    -> JOIN departments d on d.dept_id = e.dept_id
    -> WHERE d.location = 'dallas';
+----------+-----------+---------+-------+
| ename    | job       | dept_id | dname |
+----------+-----------+---------+-------+
| Sameer   | President | 10      | Crop  |
| Srinivas | VP        | 10      | Crop  |
+----------+-----------+---------+-------+
2 rows in set (0.00 sec)

mysql> SELECT e.ename "Employee", e.emp_id "Emp No", m.ename "Manager", m.emp_id "Manager No."
    -> FROM employees e
    -> JOIN employees m on m.emp_id = e.mgr_id;
+----------+--------+----------+-------------+
| Employee | Emp No | Manager  | Manager No. |
+----------+--------+----------+-------------+
| Nanda    | 103    | Sameer   | 101         |
| Srinivas | 102    | Sameer   | 101         |
| Ram      | 104    | Srinivas | 102         |
| Vivek    | 105    | Nanda    | 103         |
| Venkat   | 106    | Vivek    | 105         |
+----------+--------+----------+-------------+
5 rows in set (0.00 sec)

mysql> SELECT e.ename "Employee", e.emp_id "Emp No"
    -> FROM employees e
    -> WHERE e.mgr_id IS NULL;
+----------+--------+
| Employee | Emp No |
+----------+--------+
| Sameer   | 101    |
+----------+--------+
1 row in set (0.00 sec)

mysql> DESC salgrades
    -> ;
+---------+---------------+------+-----+---------+-------+
| Field   | Type          | Null | Key | Default | Extra |
+---------+---------------+------+-----+---------+-------+
| grade   | varchar(20)   | YES  |     | NULL    |       |
| min_sal | decimal(10,4) | YES  |     | NULL    |       |
| max_sal | decimal(10,4) | YES  |     | NULL    |       |
+---------+---------------+------+-----+---------+-------+
3 rows in set (0.00 sec)

mysql> SELECT e.ename "Employee", e.job "Job", d.dname "Department", e.bsal "Salary",
    -> (SELECT s.grade FROM salgrades s WHERE e.bsal > s.min_sal AND e.bsal <= s.max_sal) "Grade"
    -> FROM employees e
    -> JOIN departments d ON e.dept_id = d.dept_id;
+----------+-----------+------------+------------+-------+
| Employee | Job       | Department | Salary     | Grade |
+----------+-----------+------------+------------+-------+
| Sameer   | President | Crop       | 50000.0000 | A     |
| Srinivas | VP        | Crop       | 40000.0000 | B     |
| Nanda    | VP        | PW         | 40000.0000 | B     |
| Ram      | DGM       | SP         | 35000.0000 | B     |
| Vivek    | PM        | PW         | 30000.0000 | C     |
| Venkat   | Tech Lead | PW         | 25000.0000 | C     |
+----------+-----------+------------+------------+-------+
6 rows in set (0.00 sec)

mysql> SELECT p.pub_id, p.pub_name
    -> FROM publishers p
    -> JOIN titles t ON p.pub_id = t.pub_id
    -> WHERE t.type = 'business';
+--------+----------------------+
| pub_id | pub_name             |
+--------+----------------------+
| 1389   | Algodata Infosystems |
| 1389   | Algodata Infosystems |
| 0736   | New Moon Books       |
| 1389   | Algodata Infosystems |
+--------+----------------------+
4 rows in set (0.00 sec)

mysql> SELECT p.pub_id, p.pub_name
    -> FROM publishers p
    -> WHERE EXISTS (SELECT 1 FROM titles t
    -> WHERE t.type = 'business' AND t.pub_id = p.pub_id);
+--------+----------------------+
| pub_id | pub_name             |
+--------+----------------------+
| 1389   | Algodata Infosystems |
| 0736   | New Moon Books       |
+--------+----------------------+
2 rows in set (0.00 sec)

mysql> SELECT p.pub_id, p.pub_name
    -> FROM publishers p
    -> JOIN titles t ON p.pub_id = t.pub_id
    -> WHERE t.type != 'mod_cook';
+--------+----------------------+
| pub_id | pub_name             |
+--------+----------------------+
| 0736   | New Moon Books       |
| 0736   | New Moon Books       |
| 0736   | New Moon Books       |
| 0736   | New Moon Books       |
| 0736   | New Moon Books       |
| 0877   | Binnet & Harley      |
| 0877   | Binnet & Harley      |
| 0877   | Binnet & Harley      |
| 0877   | Binnet & Harley      |
| 0877   | Binnet & Harley      |
| 1389   | Algodata Infosystems |
| 1389   | Algodata Infosystems |
| 1389   | Algodata Infosystems |
| 1389   | Algodata Infosystems |
| 1389   | Algodata Infosystems |
| 1389   | Algodata Infosystems |
+--------+----------------------+
16 rows in set (0.03 sec)

mysql> SELECT p.pub_id, p.pub_name
    -> FROM publishers p
    -> WHERE EXISTS (SELECT 1 FROM titles t
    -> WHERE t.type != 'mod_cook' AND t.pub_id = p.pub_id);
+--------+----------------------+
| pub_id | pub_name             |
+--------+----------------------+
| 0736   | New Moon Books       |
| 0877   | Binnet & Harley      |
| 1389   | Algodata Infosystems |
+--------+----------------------+
3 rows in set (0.00 sec)

mysql> SELECT t.type, AVG(t.ttd_sales)
    -> FROM titles t
    -> WHERE t.type = ANY(SELECT t1.type FROM titles t1
    -> WHERE t1.title = 'The Busy Executive\'s Database Guide'
    -> OR t1.title = 'Is Anger the Enemy?')
    -> GROUP BY t.type;
+------------+------------------+
| type       | AVG(t.ttd_sales) |
+------------+------------------+
| business   |        7697.0000 |
| psychology |        1987.8000 |
+------------+------------------+
2 rows in set (0.00 sec)

mysql> SELECT p.pub_name
    -> FROM publishers p
    -> WHERE EXISTS (SELECT 1 FROM titles t
    -> WHERE t.type = 'business' AND t.pub_id = p.pub_id);
+----------------------+
| pub_name             |
+----------------------+
| Algodata Infosystems |
| New Moon Books       |
+----------------------+
2 rows in set (0.00 sec)


mysql> SELECT p.pub_id, p.pub_name
    -> FROM publishers p
    -> WHERE p.city = 'Paris';
+--------+--------------------+
| pub_id | pub_name           |
+--------+--------------------+
| 9999   | Lucerne Publishing |
+--------+--------------------+
1 row in set (0.00 sec)

mysql> SELECT t.title, t.advance
    -> FROM titles t
    -> WHERE t.advance > (SELECT AVG(t1.advance) FROM titles t1
    -> WHERE t1.type = 'business');
+-----------------------------------------------------------------+------------+
| title                                                           | advance    |
+-----------------------------------------------------------------+------------+
| You Can Combat Computer Stress!                                 | 10125.0000 |
| The Gourmet Microwave                                           | 15000.0000 |
| But Is It User Friendly?                                        |  7000.0000 |
| Secrets of Silicon Valley                                       |  8000.0000 |
| Computer Phobic AND Non-Phobic Individuals: Behavior Variations |  7000.0000 |
| Onions, Leeks, and Garlic: Cooking Secrets of the Mediterranean |  7000.0000 |
| Sushi, Anyone?                                                  |  8000.0000 |
+-----------------------------------------------------------------+------------+
7 rows in set (0.00 sec)

mysql> SELECT CONCAT(a.au_fname, ' ', a.au_lname) "Author Name"
    -> FROM authors a
    -> JOIN titleauthor ta ON ta.au_id = a.au_id
    -> JOIN titles t ON t.title_id = ta.title_id
    -> WHERE t.title = 'Net Etiquette';
+-------------------+
| Author Name       |
+-------------------+
| Charlene Locksley |
+-------------------+
1 row in set (0.00 sec)

mysql> SELECT CONCAT(a.au_fname, ' ', a.au_lname) "Author Name"
    -> FROM authors a
    -> JOIN titleauthor ta ON ta.au_id = a.au_id
    -> JOIN titles t ON t.title_id = ta.title_id
    -> WHERE t.type = 'business';
+--------------------+
| Author Name        |
+--------------------+
| Marjorie Green     |
| Abraham Bennet     |
| Michael O'Leary    |
| Stearns MacFeather |
| Marjorie Green     |
+--------------------+
5 rows in set (0.00 sec)

mysql> SELECT t.title, t.title_id
    -> FROM titles t
    -> WHERE t.price > (SELECT MAX(t1.price) 
    -> FROM titles t1
    -> JOIN publishers p ON p.pub_id = t1.pub_id
    -> WHERE p.pub_id = 0736);
+-----------------------------------------------------------------+----------+
| title                                                           | title_id |
+-----------------------------------------------------------------+----------+
| But Is It User Friendly?                                        | PC1035   |
| Secrets of Silicon Valley                                       | PC8888   |
| Computer Phobic AND Non-Phobic Individuals: Behavior Variations | PS1372   |
| Onions, Leeks, and Garlic: Cooking Secrets of the Mediterranean | TC3218   |
+-----------------------------------------------------------------+----------+
4 rows in set (0.00 sec)

mysql> SELECT t.title, t.title_id
    -> FROM titles t
    -> WHERE t.price > (SELECT MIN(t1.price) 
    -> FROM titles t
    -> JOIN publishers p ON p.pub_id = t1.pub_id
    -> ^C
mysql> ^C
mysql> ^C
mysql> SELECT t.title, t.title_id
    -> FROM titles t
    -> WHERE t.price > (SELECT MIN(t1.price) 
    -> FROM titles t1
    -> JOIN publishers p ON p.pub_id = t1.pub_id
    -> WHERE p.pub_id = 1389);
+-----------------------------------------------------------------+----------+
| title                                                           | title_id |
+-----------------------------------------------------------------+----------+
| The Busy Executive's Database Guide                             | BU1032   |
| Straight Talk About Computers                                   | BU7832   |
| Silicon Valley Gastronomic Treats                               | MC2222   |
| But Is It User Friendly?                                        | PC1035   |
| Secrets of Silicon Valley                                       | PC8888   |
| Computer Phobic AND Non-Phobic Individuals: Behavior Variations | PS1372   |
| Prolonged Data Deprivation: Four Case Studies                   | PS3333   |
| Onions, Leeks, and Garlic: Cooking Secrets of the Mediterranean | TC3218   |
| Sushi, Anyone?                                                  | TC7777   |
+-----------------------------------------------------------------+----------+
9 rows in set (0.00 sec)

mysql> SELECT t.title, t.title_id
    -> FROM titles t
    -> WHERE t.price > (SELECT MIN(t1.price) 
    -> FROM titles t1
    -> JOIN publishers p ON p.pub_id = t1.pub_id
    -> WHERE p.pub_id = 0736);
+-----------------------------------------------------------------+----------+
| title                                                           | title_id |
+-----------------------------------------------------------------+----------+
| The Busy Executive's Database Guide                             | BU1032   |
| Cooking with Computers: Surreptitious Balance Sheets            | BU1111   |
| Straight Talk About Computers                                   | BU7832   |
| Silicon Valley Gastronomic Treats                               | MC2222   |
| But Is It User Friendly?                                        | PC1035   |
| Secrets of Silicon Valley                                       | PC8888   |
| Computer Phobic AND Non-Phobic Individuals: Behavior Variations | PS1372   |
| Is Anger the Enemy?                                             | PS2091   |
| Life Without Fear                                               | PS2106   |
| Prolonged Data Deprivation: Four Case Studies                   | PS3333   |
| Emotional Security: A New Algorithm                             | PS7777   |
| Onions, Leeks, and Garlic: Cooking Secrets of the Mediterranean | TC3218   |
| Fifty Years in Buckingham Palace Kitchens                       | TC4203   |
| Sushi, Anyone?                                                  | TC7777   |
+-----------------------------------------------------------------+----------+
14 rows in set (0.00 sec)

mysql> SELECT t.title, t.title_id
    -> FROM titles t
    -> WHERE t.price > (SELECT MIN(t1.price) 
    -> FROM titles t1
    -> JOIN publishers p ON p.pub_id = t1.pub_id
    -> WHERE p.pub_id = 9999);
Empty set (0.00 sec)

mysql> SELECT p.pub_name
    -> FROM publishers p
    -> WHERE p.city = ANY(SELECT a.city 
    -> FROM authors a);
+----------------------+
| pub_name             |
+----------------------+
| Algodata Infosystems |
+----------------------+
1 row in set (0.00 sec)

mysql> \t
