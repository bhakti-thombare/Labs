import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedService } from './../../shared/shared.service';
import { ToastService } from '../../shared/toast.service';
import { EditableRow } from 'primeng/table';

@Component({
  selector: 'app-statutary-matrices',
  templateUrl: './statutary-matrices.component.html',
  styleUrls: ['./statutary-matrices.component.scss']
})
export class StatutaryMatricesComponent implements OnInit {
  selectedTabIndex = 0;
  hasFilteredData: any = {};

  billAmountMatrixData: any = [];
  totalBillAmountMatrix!: any;
  filterBillAmountMatrixColumField: any  = [
    { field: 'buCode', header: 'BU Code' },
  ];

  bonusMatrixData: any = [];
  totalBonusMatrix!: any;
  filterBonusMatrixColumField: any  = [
    { field: 'buCode', header: 'BU Code' },
  ];

  CESSMatrixData: any = [];
  totalCESSMatrix!: any;
  filterCESSMatrixColumField: any  = [
    { field: 'buCode', header: 'BU Code' },
  ];

  ESICMatrixData: any = [];
  totalESICMatrix!: any;
  filterESICMatrixColumField: any  = [
    { field: 'buCode', header: 'BU Code' },
  ];

  LeavesMatrixData: any = [];
  totalLeavesMatrix!: any;
  filterLeavesMatrixColumField: any  = [
    { field: 'buCode', header: 'BU Code' },
  ];

  PFMatrixData: any = [];
  totalPFMatrix!: any;
  filterPFMatrixColumField: any  = [
    { field: 'buCode', header: 'BU Code' },
  ];



  billAmountMatrixCols: any = [];
  bonusMatrixCols: any =[];
  CESSMatrixCols: any =[];
  ESICMatrixCols: any =[];
  LeavesMatrixCols: any =[];
  PFMatrixCols: any =[];

  pageNo: number = 0;
  pageSize: number = 5;

  billAmountForm: FormGroup;
  billAmountForm1: FormGroup;
  bonusForm: FormGroup;
  CESSForm:FormGroup;
  ESICForm:FormGroup;
  leavesForm:FormGroup;
  PFForm:FormGroup;
  loader: boolean = true;

  constructor(private _shared: SharedService, private fb: FormBuilder, private toast: ToastService) {
    this._shared.sendpageTitle('STATUTORY MATRICES');

    this.billAmountForm = this.fb.group({
      BUCode: ['',[Validators.required, Validators.maxLength(50)]],  
      Unit: ['', Validators.required],
      Function: ['', Validators.required],
      Department: ['', Validators.required],
      Section: ['', Validators.required],
      isActive: ['false'],
    })
    this.billAmountForm1 = this.fb.group({
      BUCode: ['',[Validators.required, Validators.maxLength(50)]],  
      Unit: ['', Validators.required],
      Function: ['', Validators.required],
      Department: ['', Validators.required],
      Section: ['', Validators.required],
      isActive: ['false'],
    })

    this.bonusForm = this.fb.group({
      BUCode: ['',[Validators.required, Validators.maxLength(18)]],  
      MinWorkingDays: ['', Validators.required],
      BonusRate: ['', Validators.required],
      BonusAmount: ['', Validators.required],
      ExGratiaRate: ['', Validators.required],
      ExGratiaAmount: ['', Validators.required],
    })

    this.CESSForm  = this.fb.group({
      BUCode: ['',[Validators.required, Validators.maxLength(18)]],  
      EmployeeCESSRate: ['', Validators.required],
      EmployerCESSRate: ['', Validators.required],
    })

    this.ESICForm = this.fb.group({
      BUCode: ['',[Validators.required, Validators.maxLength(18)]],  
      EmployeeESICRate: ['', Validators.required],
      EmployerESICRate: ['', Validators.required],
    })

    this.leavesForm = this.fb.group({
      BUCode: ['',[Validators.required, Validators.maxLength(18)]],  
      MinWorkingDays: ['', Validators.required],
      WorkingDaysPerLeave: ['', Validators.required],
    })

    this.PFForm = this.fb.group({
      BUCode: ['',[Validators.required, Validators.maxLength(18)]],  
      EmployeePFRate: ['', Validators.required],
      EmployerPFRate: ['', Validators.required],
      CapAmount: ['', Validators.required],
      IsMaxCap: ['false'],

    })
   }

  ngOnInit() {
    this.getUnitColumns();
    this.getBillAmountMatrixData(this.pageNo, this.pageSize);
    this.getBonusMatrixData(this.pageNo, this.pageSize);
    this.getCESSMatrixData(this.pageNo, this.pageSize);
    this.getESICMatrixData(this.pageNo, this.pageSize);
    this.getLeavesMatrixData(this.pageNo, this.pageSize);
    this.getPFMatrixData(this.pageNo, this.pageSize);
    
  }

  getUnitColumns() {
    this.billAmountMatrixCols = [
      
      { field: 'buCode', header: 'BU Code' },
      { field: 'Unit', header: 'Unit' },
      { field: 'Function', header: 'Function' },
      { field: 'Department', header: 'Department' },
      { field: 'Section', header: 'Section' },
      { field: 'isActive', header: 'Status' },
      { field: 'Action', header: 'Action' },
     
    ];

    this.bonusMatrixCols = [
      
      { field: 'buCode', header: 'BU Code' },
      { field: 'MinWorkingDays', header: 'Minimum Working Days' },
      { field: 'BonusRate', header: 'Bonus Rate' },
      { field: 'BonusAmount', header: 'Bonus Amount' },
      { field: 'ExGratiaRate', header: 'Ex Gratia Rate' },
      { field: 'ExGratiaAmount', header: 'Ex Gratia Amount' },
      { field: 'Action', header: 'Action' },
     
    ];

    this.CESSMatrixCols = [
      
      { field: 'buCode', header: 'BU Code' },
      { field: 'EmployeeCESSRate', header: 'Employee CESS Rate' },
      { field: 'EmployerCESSRate', header: 'Employer CESS Rate' },
      { field: 'Action', header: 'Action' },
     
    ];

    this.ESICMatrixCols = [
      { field: 'buCode', header: 'BU Code' },
      { field: 'EmployeeESICRate', header: 'Employee ESIC Rate' },
      { field: 'EmployerESICRate', header: 'Employer ESIC Rate' },
      { field: 'Action', header: 'Action' },
    ];

    this.LeavesMatrixCols = [
      { field: 'buCode', header: 'BU Code' },
      { field: 'MinWorkingDays', header: 'Minimum Working Days' },
      { field: 'WorkingDaysPerLeave', header: 'Working Days Per Leave' },
      { field: 'Action', header: 'Action' },
    ];

    this.PFMatrixCols = [
      { field: 'buCode', header: 'BU Code' },
      { field: 'EmployeePFRate', header: 'Employee PF Rate' },
      { field: 'EmployerPFRate', header: 'Employer PF Rate' },
      { field: 'CapAmount', header: 'Cap Amount' },
      { field: 'IsMaxCap', header: 'IsMaxCap' },
      { field: 'Action', header: 'Action' },
    ];
  }
  

  // add(){
  //   console.log(this.billAmountForm.value);
  //   this.billAmountMatrixData.push(
  //     this.billAmountForm1
    
  //   );
    
  // }
isUpdate = null;
  add(Entity:any){
    if(this.isUpdate != null){
      
    }else{
    const arr = new Array(Entity.BUCode)
    this.billAmountMatrixData.push(arr);
    }

  }

  // ******************************************************************Bill Amount Matrix Start******************************************************************
  getBillAmountMatrixData(pageNo: number, pageSize: number) {
    let obj = {
      pageNumber: pageNo,
      pageSize: pageSize,
      departmentCode: sessionStorage.getItem('departmentCode'),
      positionCode: sessionStorage.getItem('positionCode'),
      sectionCode: sessionStorage.getItem('sectionCode'),
      unit: sessionStorage.getItem('unit'),
      status: "Disputed"
    }

    this._shared.post('Invoice/GetBillApprovalInvoices', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.billAmountMatrixData = res.item2;
      this.totalBillAmountMatrix = res.item1;
    });
  }

  cloneRecordBillAmount:any ={};
  onRowEditInitBillAmount(data:any){
    this.cloneRecordBillAmount[data.roleId] = {...data};
  }
  onRowEditSaveBillAmount(data: any){
    // this.billAmountForm.value.roleId = data.roleId;
    this.billAmountForm.value.BUCode = data.BUCode;
    this.billAmountForm.value.Unit = data.Unit;
    this.billAmountForm.value.Function = data.Function;
    this.billAmountForm.value.Department = data.Department;
    this.billAmountForm.value.Section = data.Section;

    this.billAmountForm.value.isActive = data.isActive ? true : false,
    this.billAmountForm.value.modifiedBy = sessionStorage.getItem('username');
    this.billAmountForm.value.created = data.created;
    this.billAmountForm.value.createdBy = data.createdBy;
    // this._shared.put('Role/UpdateRole', this.billAmountForm.value, 'admin').subscribe(res => {
    //   this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
    //   this.getBillAmountMatrixData(0, 5);
    // });
  }

  onRowEditCancelBillAmount(data: any){
    this.getBillAmountMatrixData(0, 5);
  }

  onPageChangeBillAmount(event:any){
    if (Object.keys(this.hasFilteredData).length != 0) {
      this.hasFilteredData.pageNo = event.page;
      this.hasFilteredData.pageSize = event.rows;
      this.pageSize = event.rows;
      // this._shared.post('User/SearchUsers', this.hasFilteredData, 'admin').subscribe(res => {
      //   this.loader = false;
      //   this.vendorsData = res.item2;
      //   this.totalVendors = res.item1;
      // });
    } else {
      this.pageSize = event.rows;
      this.pageNo = event.page;
      this.getBillAmountMatrixData(event.page, event.rows);
    }
  }

  filterBillAmountData(evntData:any){
  
    
    evntData.pageSize = this.pageSize;
    // evntData.pageNo = this.pageNo;

    // this._shared.post('Invoice/SearchBillApprovalInvoices', formData, 'admin').subscribe(res => {
      this.loader = false;
      // this.billAmountMatrixData = res.item2;
      this.hasFilteredData = evntData;
    // });
  }

  refreshBillAmountData(event:any){
    if(event){
      this.getBillAmountMatrixData(this.pageNo, this.pageSize);
      this.hasFilteredData = {};
    }
  }

  tabChange(e: any) {
    // this.editFlag = true;
    // this.changeTitleAddViewEdit = 'Add';
    // this.vendorForm.reset();
    // this.vendorForm.patchValue({ 'isActive': true });
    let index = e.index;
    if (index == 0) {
      this.selectedTabIndex = 0;
      // this.getBillAmountMatrixData(this.pageNo, this.pageSize);
    }
  }
//******************************************************************Bill Amount Matrix End******************************************************************

// ******************************************************************Bonus Matrix Start******************************************************************
getBonusMatrixData(pageNo: number, pageSize: number) {
  let obj = {
    pageNumber: pageNo,
    pageSize: pageSize,
    departmentCode: sessionStorage.getItem('departmentCode'),
    positionCode: sessionStorage.getItem('positionCode'),
    sectionCode: sessionStorage.getItem('sectionCode'),
    unit: sessionStorage.getItem('unit'),
    status: "Disputed"
  }

  this._shared.post('Invoice/GetBillApprovalInvoices', obj, 'admin').subscribe(res => {
    this.loader = false;
    this.bonusMatrixData = res.item2;
    this.totalBonusMatrix = res.item1;
  });
}

cloneRecordBonus:any ={};
onRowEditInitBounsMatrix(data:any){
  this.cloneRecordBonus[data.roleId] = {...data};
}
onRowEditSaveBounsMatrix(data: any){
  // this.billAmountForm.value.roleId = data.roleId;
  this.bonusForm.value.BUCode = data.BUCode;
  this.bonusForm.value.MinWorkingDays = data.MinWorkingDays;
  this.bonusForm.value.BonusRate = data.BonusRate;
  this.bonusForm.value.BonusAmount = data.BonusAmount;
  this.bonusForm.value.ExGratiaRate = data.ExGratiaRate;
  this.bonusForm.value.ExGratiaAmount = data.ExGratiaAmount;

  // this.billAmountForm.value.isActive = data.isActive ? true : false,
  this.bonusForm.value.modifiedBy = sessionStorage.getItem('username');
  this.bonusForm.value.created = data.created;
  this.bonusForm.value.createdBy = data.createdBy;
  // this._shared.put('Role/UpdateRole', this.billAmountForm.value, 'admin').subscribe(res => {
  //   this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
  //   this.getBillAmountMatrixData(0, 5);
  // });
}

onRowEditCancelBounsMatrix(data: any){
  this.getBonusMatrixData(0, 5);
}

onPageChangeBonus(event:any){
  if (Object.keys(this.hasFilteredData).length != 0) {
    this.hasFilteredData.pageNo = event.page;
    this.hasFilteredData.pageSize = event.rows;
    this.pageSize = event.rows;
    // this._shared.post('User/SearchUsers', this.hasFilteredData, 'admin').subscribe(res => {
    //   this.loader = false;
    //   this.vendorsData = res.item2;
    //   this.totalVendors = res.item1;
    // });
  } else {
    this.pageSize = event.rows;
    this.pageNo = event.page;
    this.getBonusMatrixData(event.page, event.rows);
  }
}

filterBonusData(evntData:any){

  
  evntData.pageSize = this.pageSize;
  // evntData.pageNo = this.pageNo;

  // this._shared.post('Invoice/SearchBillApprovalInvoices', formData, 'admin').subscribe(res => {
    this.loader = false;
    // this.billAmountMatrixData = res.item2;
    this.hasFilteredData = evntData;
  // });
}

refreshBonusData(event:any){
  if(event){
    this.getBonusMatrixData(this.pageNo, this.pageSize);
    this.hasFilteredData = {};
  }
}

//*****************************************************************Bonus Matrix  End******************************************************************

// ******************************************************************CESS Matrix Start******************************************************************
getCESSMatrixData(pageNo: number, pageSize: number) {
  let obj = {
    pageNumber: pageNo,
    pageSize: pageSize,
    departmentCode: sessionStorage.getItem('departmentCode'),
    positionCode: sessionStorage.getItem('positionCode'),
    sectionCode: sessionStorage.getItem('sectionCode'),
    unit: sessionStorage.getItem('unit'),
    status: "Disputed"
  }

  this._shared.post('Invoice/GetBillApprovalInvoices', obj, 'admin').subscribe(res => {
    this.loader = false;
    this.CESSMatrixData = res.item2;
    this.totalCESSMatrix = res.item1;
  });
}

cloneRecordCESS:any ={};
onRowEditInitCESSMatrix(data:any){
  this.cloneRecordCESS[data.roleId] = {...data};
}
onRowEditSaveCESSMatrix(data: any){
  this.CESSForm.value.BUCode = data.BUCode;
  this.CESSForm.value.EmployeeCESSRate = data.EmployeeCESSRate;
  this.CESSForm.value.EmployerCESSRate = data.EmployerCESSRate;

  this.CESSForm.value.modifiedBy = sessionStorage.getItem('username');
  this.CESSForm.value.created = data.created;
  this.CESSForm.value.createdBy = data.createdBy;
  // this._shared.put('Role/UpdateRole', this.billAmountForm.value, 'admin').subscribe(res => {
  //   this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
  //   this.getBillAmountMatrixData(0, 5);
  // });
}

onRowEditCancelCESSMatrix(data: any){
  this.getCESSMatrixData(0, 5);
}

onPageChangeCESSMatrix(event:any){
  if (Object.keys(this.hasFilteredData).length != 0) {
    this.hasFilteredData.pageNo = event.page;
    this.hasFilteredData.pageSize = event.rows;
    this.pageSize = event.rows;
    // this._shared.post('User/SearchUsers', this.hasFilteredData, 'admin').subscribe(res => {
    //   this.loader = false;
    //   this.vendorsData = res.item2;
    //   this.totalVendors = res.item1;
    // });
  } else {
    this.pageSize = event.rows;
    this.pageNo = event.page;
    this.getCESSMatrixData(event.page, event.rows);
  }
}

filterCESSData(evntData:any){

  
  evntData.pageSize = this.pageSize;
  // evntData.pageNo = this.pageNo;

  // this._shared.post('Invoice/SearchBillApprovalInvoices', formData, 'admin').subscribe(res => {
    this.loader = false;
    // this.billAmountMatrixData = res.item2;
    this.hasFilteredData = evntData;
  // });
}

refreshCESSData(event:any){
  if(event){
    this.getCESSMatrixData(this.pageNo, this.pageSize);
    this.hasFilteredData = {};
  }
}

//*****************************************************************CESS Matrix  End******************************************************************

// ******************************************************************ESIC Matrix Start******************************************************************
getESICMatrixData(pageNo: number, pageSize: number) {
  let obj = {
    pageNumber: pageNo,
    pageSize: pageSize,
    departmentCode: sessionStorage.getItem('departmentCode'),
    positionCode: sessionStorage.getItem('positionCode'),
    sectionCode: sessionStorage.getItem('sectionCode'),
    unit: sessionStorage.getItem('unit'),
    status: "Disputed"
  }

  this._shared.post('Invoice/GetBillApprovalInvoices', obj, 'admin').subscribe(res => {
    this.loader = false;
    this.ESICMatrixData = res.item2;
    this.totalESICMatrix = res.item1;
  });
}

cloneRecordESIC:any ={};
onRowEditInitESICMatrix(data:any){
  this.cloneRecordESIC[data.roleId] = {...data};
}
onRowEditSaveESICMatrix(data: any){
  this.ESICForm.value.BUCode = data.BUCode;
  this.ESICForm.value.EmployeeESICRate = data.EmployeeESICRate;
  this.ESICForm.value.EmployerESICRate = data.EmployerESICRate;

  this.ESICForm.value.modifiedBy = sessionStorage.getItem('username');
  this.ESICForm.value.created = data.created;
  this.ESICForm.value.createdBy = data.createdBy;
  // this._shared.put('Role/UpdateRole', this.billAmountForm.value, 'admin').subscribe(res => {
  //   this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
  //   this.getBillAmountMatrixData(0, 5);
  // });
}

onRowEditCancelESICMatrix(data: any){
  this.getESICMatrixData(0, 5);
}

onPageChangeESICMatrix(event:any){
  if (Object.keys(this.hasFilteredData).length != 0) {
    this.hasFilteredData.pageNo = event.page;
    this.hasFilteredData.pageSize = event.rows;
    this.pageSize = event.rows;
    // this._shared.post('User/SearchUsers', this.hasFilteredData, 'admin').subscribe(res => {
    //   this.loader = false;
    //   this.vendorsData = res.item2;
    //   this.totalVendors = res.item1;
    // });
  } else {
    this.pageSize = event.rows;
    this.pageNo = event.page;
    this.getESICMatrixData(event.page, event.rows);
  }
}

filterESICData(evntData:any){

  evntData.pageSize = this.pageSize;
  // evntData.pageNo = this.pageNo;

  // this._shared.post('Invoice/SearchBillApprovalInvoices', formData, 'admin').subscribe(res => {
    this.loader = false;
    // this.billAmountMatrixData = res.item2;
    this.hasFilteredData = evntData;
  // });
}

refreshESICData(event:any){
  if(event){
    this.getESICMatrixData(this.pageNo, this.pageSize);
    this.hasFilteredData = {};
  }
}

//*****************************************************************ESIC Matrix  End******************************************************************

// ******************************************************************Leaves Matrix Start******************************************************************
getLeavesMatrixData(pageNo: number, pageSize: number) {
  let obj = {
    pageNumber: pageNo,
    pageSize: pageSize,
    departmentCode: sessionStorage.getItem('departmentCode'),
    positionCode: sessionStorage.getItem('positionCode'),
    sectionCode: sessionStorage.getItem('sectionCode'),
    unit: sessionStorage.getItem('unit'),
    status: "Disputed"
  }

  this._shared.post('Invoice/GetBillApprovalInvoices', obj, 'admin').subscribe(res => {
    this.loader = false;
    this.LeavesMatrixData = res.item2;
    this.totalLeavesMatrix = res.item1;
  });
}

cloneRecordLeaves:any ={};
onRowEditInitLeavesMatrix(data:any){
  this.cloneRecordLeaves[data.roleId] = {...data};
}
onRowEditSaveLeavesMatrix(data: any){
  this.leavesForm.value.BUCode = data.BUCode;
  this.leavesForm.value.MinWorkingDays = data.MinWorkingDays;
  this.leavesForm.value.WorkingDaysPerLeave = data.WorkingDaysPerLeave;

  this.leavesForm.value.modifiedBy = sessionStorage.getItem('username');
  this.leavesForm.value.created = data.created;
  this.leavesForm.value.createdBy = data.createdBy;
  // this._shared.put('Role/UpdateRole', this.billAmountForm.value, 'admin').subscribe(res => {
  //   this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
  //   this.getBillAmountMatrixData(0, 5);
  // });
}

onRowEditCancelLeavesMatrix(data: any){
  this.getLeavesMatrixData(0, 5);
}

onPageChangeLeavesMatrix(event:any){
  if (Object.keys(this.hasFilteredData).length != 0) {
    this.hasFilteredData.pageNo = event.page;
    this.hasFilteredData.pageSize = event.rows;
    this.pageSize = event.rows;
    // this._shared.post('User/SearchUsers', this.hasFilteredData, 'admin').subscribe(res => {
    //   this.loader = false;
    //   this.vendorsData = res.item2;
    //   this.totalVendors = res.item1;
    // });
  } else {
    this.pageSize = event.rows;
    this.pageNo = event.page;
    this.getLeavesMatrixData(event.page, event.rows);
  }
}

filterLeavesData(evntData:any){

  evntData.pageSize = this.pageSize;
  // evntData.pageNo = this.pageNo;

  // this._shared.post('Invoice/SearchBillApprovalInvoices', formData, 'admin').subscribe(res => {
    this.loader = false;
    // this.billAmountMatrixData = res.item2;
    this.hasFilteredData = evntData;
  // });
}

refreshLeavesData(event:any){
  if(event){
    this.getLeavesMatrixData(this.pageNo, this.pageSize);
    this.hasFilteredData = {};
  }
}

//*****************************************************************Leaves Matrix  End******************************************************************

// ******************************************************************PF Matrix Start******************************************************************
getPFMatrixData(pageNo: number, pageSize: number) {
  let obj = {
    pageNumber: pageNo,
    pageSize: pageSize,
    departmentCode: sessionStorage.getItem('departmentCode'),
    positionCode: sessionStorage.getItem('positionCode'),
    sectionCode: sessionStorage.getItem('sectionCode'),
    unit: sessionStorage.getItem('unit'),
    status: "Disputed"
  }

  this._shared.post('Invoice/GetBillApprovalInvoices', obj, 'admin').subscribe(res => {
    this.loader = false;
    this.PFMatrixData = res.item2;
    this.totalPFMatrix = res.item1;
  });
}

cloneRecordPF:any ={};
onRowEditInitPFData(data:any){
  this.cloneRecordPF[data.roleId] = {...data};
}
onRowEditSavePFData(data: any){
  this.PFForm.value.BUCode = data.BUCode;
  this.PFForm.value.EmployeePFRate = data.EmployeePFRate;
  this.PFForm.value.EmployerPFRate = data.EmployerPFRate;
  this.PFForm.value.CapAmount = data.CapAmount;

  this.PFForm.value.IsMaxCap = data.IsMaxCap ? true : false,
  this.PFForm.value.modifiedBy = sessionStorage.getItem('username');
  this.PFForm.value.created = data.created;
  this.PFForm.value.createdBy = data.createdBy;
  // this._shared.put('Role/UpdateRole', this.billAmountForm.value, 'admin').subscribe(res => {
  //   this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
  //   this.getBillAmountMatrixData(0, 5);
  // });
}

onRowEditCancelPFData(data: any){
  this.getPFMatrixData(0, 5);
}

onPageChangePFMatrix(event:any){
  if (Object.keys(this.hasFilteredData).length != 0) {
    this.hasFilteredData.pageNo = event.page;
    this.hasFilteredData.pageSize = event.rows;
    this.pageSize = event.rows;
    // this._shared.post('User/SearchUsers', this.hasFilteredData, 'admin').subscribe(res => {
    //   this.loader = false;
    //   this.vendorsData = res.item2;
    //   this.totalVendors = res.item1;
    // });
  } else {
    this.pageSize = event.rows;
    this.pageNo = event.page;
    this.getPFMatrixData(event.page, event.rows);
  }
}

filterPFData(evntData:any){

  
  evntData.pageSize = this.pageSize;
  // evntData.pageNo = this.pageNo;

  // this._shared.post('Invoice/SearchBillApprovalInvoices', formData, 'admin').subscribe(res => {
    this.loader = false;
    // this.billAmountMatrixData = res.item2;
    this.hasFilteredData = evntData;
  // });
}

refreshPFData(event:any){
  if(event){
    this.getPFMatrixData(this.pageNo, this.pageSize);
    this.hasFilteredData = {};
  }
}

//*****************************************************************PF Matrix  End******************************************************************

}




<app-loader></app-loader>

<p-tabView [(activeIndex)]="selectedTabIndex"  (onChange)="tabChange($event)" >
  <p-tabPanel  header="Bill Amount Matrix" [selected]="true">

    <div class="billWrapper shadow-sm">
      <div class="align-items-center d-flex mb-2 m-0 row">
        <div class="col-12 col-sm-6 ps-0 text-center text-sm-start"> 
          <span class="btn btn-outline-success"  (click)="add(this)">
            <i class="fa fa-plus"></i> Add Data
          </span>
        </div>
        <div class="col-12 col-sm-1 pe-2 text-end" style="font-size: 24px;">
        </div>

        <div class="col-12 col-sm-5 px-1">
          <app-filter (reload)="refreshBillAmountData($event)" (filter)="filterBillAmountData($event)" [dropdownFilterItems]="filterBillAmountMatrixColumField"> 
          </app-filter>
        </div>
      </div>

       <p-table [value]="billAmountMatrixData" editMode="row" dataKey="" [columns]="billAmountMatrixCols" [paginator]="false" [rows]="5" 
       [showCurrentPageReport]="true" currentPageReportTemplate="Total entries :
       {{totalBillAmountMatrix}}" [responsive]="true" [autoLayout]="true" [rowsPerPageOptions]="[5, 10,50, 100]" responsiveLayout="scroll">
        
        <ng-template pTemplate="header">
          <tr>
            <th class="tableHeader" *ngFor="let col of billAmountMatrixCols" [pSortableColumn]="col.field">
              {{ col.header }}
              <p-sortIcon *ngIf="col.header != 'Action'" [field]="col.field"></p-sortIcon>
            </th>
          </tr>
        </ng-template>

         <ng-template pTemplate="body" let-rowdata let-editing="editing" let-ri="rowIndex" let-columns="columns">
          <tr [pEditableRow]="rowdata">
           <!-- <td style="width: 5%;">
               <i placement="bottom" ngbTooltip="View Invoive" class="fa fa-eye cursor pe-3 cursor"
                (click)="viewInvoice(rowdata);"></i> 
                <i class="fa fa-edit cursor pe-3" (click)="edit(rowdata, 'edit')"></i> 
            </td>-->
            <!-- <td style="width: 15%;">{{ rowdata.tempInvoiceId }}</td> -->
            <td style="width: 15%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.BUCode" 
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.BUCode}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 15%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.Unit"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.Unit}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 15%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.Function"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.Function}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 15%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.Department"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.Department}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 15%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.Section"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.Section}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 15%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <label class="pe-2">Active</label>
                  <input type="checkbox" class="form-check-input" [(ngModel)]="rowdata.isActive"
                    [checked]="rowdata.isActive" />
                </ng-template>
                <ng-template pTemplate="output">
                  {{rowdata.isActive }}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 10%;">
              <button style="color: #343a40;" *ngIf="!editing" pButton pRipple
              type="button" pInitEditableRow icon="pi pi-pencil"
              (click)="onRowEditInitBillAmount(rowdata)" class="p-button-rounded p-button-text"></button>
            <button *ngIf="editing" pButton pRipple type="button" pSaveEditableRow icon="pi pi-check"
              (click)="onRowEditSaveBillAmount(rowdata)"
              class="p-button-rounded p-button-text p-button-success p-mr-2"></button>
            <button *ngIf="editing" pButton pRipple type="button" pCancelEditableRow icon="pi pi-times"
              (click)="onRowEditCancelBillAmount(rowdata)" class="p-button-rounded p-button-text p-button-danger"></button>
            </td>
            
            
          </tr>
        </ng-template>

        <ng-template pTemplate="emptymessage" let-columns>
          <tr>
            <td [attr.colspan]="columns.length+2">
              <div class="py-3 text-center">No records found</div>
            </td>
          </tr>
        </ng-template>
      </p-table> 

        <div style="position:relative;" class="align-items-center d-flex justify-content-between">
          <span class="ps-2 textColor">Showing : <strong class="textColor"
              >{{billAmountMatrixData?.length}}</strong> entries
          </span>
          <p-paginator *ngIf="billAmountMatrixData"
            [rows]="5" [totalRecords]="totalBillAmountMatrix"
          [rowsPerPageOptions]="[5, 10, 50, 100]" (onPageChange)="onPageChangeBillAmount($event)">
          </p-paginator>
          <span class="pe-2 textColor">Total records : 
            <strong class="textColor">{{totalBillAmountMatrix}}</strong>
          </span>
        </div>
  
    </div>
  </p-tabPanel>

  <p-tabPanel  header="Bonus Matrix">

    <div class="billWrapper shadow-sm">
      <div class="align-items-center d-flex mb-2 m-0 row">
        <div class="col-12 col-sm-6 ps-0 text-center text-sm-start"></div>
        <div class="col-12 col-sm-1 pe-2 text-end" style="font-size: 24px;">
        </div>

        <div class="col-12 col-sm-5 px-1">
          <app-filter (reload)="refreshBonusData($event)" (filter)="filterBonusData($event)" [dropdownFilterItems]="filterBonusMatrixColumField"> 
          </app-filter>
        </div>
      </div>

       <p-table [value]="bonusMatrixData" editMode="row" dataKey="" [columns]="bonusMatrixCols" [paginator]="false" [rows]="5"
       [showCurrentPageReport]="true" currentPageReportTemplate="Total entries :
       {{totalBonusMatrix}}" [responsive]="true" [autoLayout]="true" [rowsPerPageOptions]="[5, 10,50, 100]" responsiveLayout="scroll">
        
        <ng-template pTemplate="header">
          <tr>
            <th class="tableHeader" *ngFor="let col of bonusMatrixCols" [pSortableColumn]="col.field">
              {{ col.header }}
              <p-sortIcon *ngIf="col.header != 'Action'" [field]="col.field"></p-sortIcon>
            </th>
          </tr>
        </ng-template>

         <ng-template pTemplate="body" let-rowdata let-editing="editing" let-ri="rowIndex" let-columns="columns">
          <tr [pEditableRow]="rowdata">
            <td style="width: 15%;">
              <p-cellEditor> 
              <ng-template pTemplate="input">
                <input pInputText type="text"  [(ngModel)]="rowdata.BUCode"
                  [style]="{'width':'100%'}" />
                  <!-- </p-dropdown> -->
              </ng-template>
              <ng-template pTemplate="output">
              {{rowdata.BUCode}}
              </ng-template>
            </p-cellEditor>
          </td>
            <td style="width: 15%;">
            <p-cellEditor> 
              <ng-template pTemplate="input">
                <input pInputText type="text"  [(ngModel)]="rowdata.MinWorkingDays"
                  [style]="{'width':'100%'}" />
                  <!-- </p-dropdown> -->
              </ng-template>
              <ng-template pTemplate="output">
              {{rowdata.MinWorkingDays}}
              </ng-template>
            </p-cellEditor>
            </td>
            <td style="width: 15%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.BonusRate"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.BonusRate}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 15%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.BonusAmount"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.BonusAmount}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 15%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.ExGratiaRate"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.ExGratiaRate}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 15%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.ExGratiaAmount"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.ExGratiaAmount}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 10%;">
              <button style="color: #343a40;" *ngIf="!editing" pButton pRipple
              type="button" pInitEditableRow icon="pi pi-pencil"
              (click)="onRowEditInitBounsMatrix(rowdata)" class="p-button-rounded p-button-text"></button>
            <button *ngIf="editing" pButton pRipple type="button" pSaveEditableRow icon="pi pi-check"
              (click)="onRowEditSaveBounsMatrix(rowdata)"
              class="p-button-rounded p-button-text p-button-success p-mr-2"></button>
            <button *ngIf="editing" pButton pRipple type="button" pCancelEditableRow icon="pi pi-times"
              (click)="onRowEditCancelBounsMatrix(rowdata)" class="p-button-rounded p-button-text p-button-danger"></button>
            
            </td>
          </tr>
        </ng-template>

        <ng-template pTemplate="emptymessage" let-columns>
          <tr>
            <td [attr.colspan]="columns.length+2">
              <div class="py-3 text-center">No records found</div>
            </td>
          </tr>
        </ng-template>
      </p-table> 

        <div style="position:relative;" class="align-items-center d-flex justify-content-between">
          <span class="ps-2 textColor">Showing : <strong class="textColor"
              >{{bonusMatrixData?.length}}</strong> entries
          </span>
          <p-paginator *ngIf="bonusMatrixData"
            [rows]="5" [totalRecords]="totalBonusMatrix"
          [rowsPerPageOptions]="[5, 10, 50, 100]" (onPageChange)="onPageChangeBonus($event)">
          </p-paginator>
          <span class="pe-2 textColor">Total records : 
            <strong class="textColor">{{totalBonusMatrix}}</strong>
          </span>
        </div>
  
    </div>
  </p-tabPanel>

  <p-tabPanel  header="CESS Matrix">

    <div class="billWrapper shadow-sm">
      <div class="align-items-center d-flex mb-2 m-0 row">
        <div class="col-12 col-sm-6 ps-0 text-center text-sm-start"></div>
        <div class="col-12 col-sm-1 pe-2 text-end" style="font-size: 24px;">
        </div>

        <div class="col-12 col-sm-5 px-1">
          <app-filter (reload)="refreshCESSData($event)" (filter)="filterCESSData($event)" [dropdownFilterItems]="filterCESSMatrixColumField"> 
          </app-filter>
        </div>
      </div>

       <p-table [value]="CESSMatrixData" editMode="row" dataKey="" [columns]="CESSMatrixCols" [paginator]="false" [rows]="5"
       [showCurrentPageReport]="true" currentPageReportTemplate="Total entries :
       {{totalCESSMatrix}}" [responsive]="true" [autoLayout]="true" [rowsPerPageOptions]="[5, 10,50, 100]" responsiveLayout="scroll">
        
        <ng-template pTemplate="header">
          <tr>
            <th class="tableHeader" *ngFor="let col of CESSMatrixCols" [pSortableColumn]="col.field">
              {{ col.header }}
              <p-sortIcon *ngIf="col.header != 'Action'" [field]="col.field"></p-sortIcon>
            </th>
          </tr>
        </ng-template>

         <ng-template pTemplate="body" let-rowdata let-editing="editing" let-ri="rowIndex" let-columns="columns">
          <tr [pEditableRow]="rowdata">
            <td style="width: 25%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.BUCode"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.BUCode}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 25%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.EmployeeCESSRate"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.EmployeeCESSRate}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 25%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.EmployerCESSRate"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.EmployerCESSRate}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 25%;">
              <button style="color: #343a40;" *ngIf="!editing" pButton pRipple
              type="button" pInitEditableRow icon="pi pi-pencil"
              (click)="onRowEditInitCESSMatrix(rowdata)" class="p-button-rounded p-button-text"></button>
            <button *ngIf="editing" pButton pRipple type="button" pSaveEditableRow icon="pi pi-check"
              (click)="onRowEditSaveCESSMatrix(rowdata)"
              class="p-button-rounded p-button-text p-button-success p-mr-2"></button>
            <button *ngIf="editing" pButton pRipple type="button" pCancelEditableRow icon="pi pi-times"
              (click)="onRowEditCancelCESSMatrix(rowdata)" class="p-button-rounded p-button-text p-button-danger"></button>
            
            </td>
          </tr>
        </ng-template>

        <ng-template pTemplate="emptymessage" let-columns>
          <tr>
            <td [attr.colspan]="columns.length+2">
              <div class="py-3 text-center">No records found</div>
            </td>
          </tr>
        </ng-template>
      </p-table> 

        <div style="position:relative;" class="align-items-center d-flex justify-content-between">
          <span class="ps-2 textColor">Showing : <strong class="textColor"
              >{{CESSMatrixData?.length}}</strong> entries
          </span>
          <p-paginator *ngIf="CESSMatrixData"
            [rows]="5" [totalRecords]="totalCESSMatrix"
          [rowsPerPageOptions]="[5, 10, 50, 100]" (onPageChange)="onPageChangeCESSMatrix($event)">
          </p-paginator>
          <span class="pe-2 textColor">Total records : 
            <strong class="textColor">{{totalCESSMatrix}}</strong>
          </span>
        </div>
  
    </div>
  </p-tabPanel>

  <p-tabPanel  header="ESIC Matrix">

    <div class="billWrapper shadow-sm">
      <div class="align-items-center d-flex mb-2 m-0 row">
        <div class="col-12 col-sm-6 ps-0 text-center text-sm-start"></div>
        <div class="col-12 col-sm-1 pe-2 text-end" style="font-size: 24px;">
        </div>

        <div class="col-12 col-sm-5 px-1">
          <app-filter (reload)="refreshESICData($event)" (filter)="filterESICData($event)" [dropdownFilterItems]="filterESICMatrixColumField"> 
          </app-filter>
        </div>
      </div>

       <p-table [value]="ESICMatrixData" editMode="row" dataKey="" [columns]="ESICMatrixCols" [paginator]="false" [rows]="5"
       [showCurrentPageReport]="true" currentPageReportTemplate="Total entries :
       {{totalESICMatrix}}" [responsive]="true" [autoLayout]="true" [rowsPerPageOptions]="[5, 10,50, 100]" responsiveLayout="scroll">
        
        <ng-template pTemplate="header">
          <tr>
            <th class="tableHeader" *ngFor="let col of ESICMatrixCols" [pSortableColumn]="col.field">
              {{ col.header }}
              <p-sortIcon *ngIf="col.header != 'Action'" [field]="col.field"></p-sortIcon>
            </th>
          </tr>
        </ng-template>

         <ng-template pTemplate="body" let-rowdata  let-editing="editing" let-ri="rowIndex"  let-columns="columns">
          <tr [pEditableRow]="rowdata">
            <td style="width: 25%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.BUCode"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.BUCode}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 25%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.EmployeeESICRate"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.EmployeeESICRate}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 25%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.EmployerESICRate"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.EmployerESICRate}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 25%;">
              <button style="color: #343a40;" *ngIf="!editing" pButton pRipple
              type="button" pInitEditableRow icon="pi pi-pencil"
              (click)="onRowEditInitESICMatrix(rowdata)" class="p-button-rounded p-button-text"></button>
            <button *ngIf="editing" pButton pRipple type="button" pSaveEditableRow icon="pi pi-check"
              (click)="onRowEditSaveESICMatrix(rowdata)"
              class="p-button-rounded p-button-text p-button-success p-mr-2"></button>
            <button *ngIf="editing" pButton pRipple type="button" pCancelEditableRow icon="pi pi-times"
              (click)="onRowEditCancelESICMatrix(rowdata)" class="p-button-rounded p-button-text p-button-danger"></button>
            
            </td>
           
          </tr>
        </ng-template>

        <ng-template pTemplate="emptymessage" let-columns>
          <tr>
            <td [attr.colspan]="columns.length+2">
              <div class="py-3 text-center">No records found</div>
            </td>
          </tr>
        </ng-template>
      </p-table> 

        <div style="position:relative;" class="align-items-center d-flex justify-content-between">
          <span class="ps-2 textColor">Showing : <strong class="textColor"
              >{{ESICMatrixData?.length}}</strong> entries
          </span>
          <p-paginator *ngIf="ESICMatrixData"
            [rows]="5" [totalRecords]="totalESICMatrix"
          [rowsPerPageOptions]="[5, 10, 50, 100]" (onPageChange)="onPageChangeESICMatrix($event)">
          </p-paginator>
          <span class="pe-2 textColor">Total records : 
            <strong class="textColor">{{totalESICMatrix}}</strong>
          </span>
        </div>
  
    </div>
  </p-tabPanel>

  <p-tabPanel  header="Leaves Matrix">

    <div class="billWrapper shadow-sm">
      <div class="align-items-center d-flex mb-2 m-0 row">
        <div class="col-12 col-sm-6 ps-0 text-center text-sm-start"></div>
        <div class="col-12 col-sm-1 pe-2 text-end" style="font-size: 24px;">
        </div>

        <div class="col-12 col-sm-5 px-1">
          <app-filter (reload)="refreshLeavesData($event)" (filter)="filterLeavesData($event)" [dropdownFilterItems]="filterLeavesMatrixColumField"> 
          </app-filter>
        </div>
      </div>

       <p-table [value]="LeavesMatrixData" editMode="row" dataKey="" [columns]="LeavesMatrixCols" [paginator]="false" [rows]="5"
       [showCurrentPageReport]="true" currentPageReportTemplate="Total entries :
       {{totalLeavesMatrix}}" [responsive]="true" [autoLayout]="true" [rowsPerPageOptions]="[5, 10,50, 100]" responsiveLayout="scroll">
        
        <ng-template pTemplate="header">
          <tr>
            <th class="tableHeader" *ngFor="let col of LeavesMatrixCols" [pSortableColumn]="col.field">
              {{ col.header }}
              <p-sortIcon *ngIf="col.header != 'Action'" [field]="col.field"></p-sortIcon>
            </th>
          </tr>
        </ng-template>

         <ng-template pTemplate="body" let-rowdata let-editing="editing" let-ri="rowIndex" let-columns="columns">
          <tr [pEditableRow]="rowdata">
            <td style="width: 25%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.BUCode"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.BUCode}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 25%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.MinWorkingDays"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.MinWorkingDays}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 25%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.WorkingDaysPerLeave"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.WorkingDaysPerLeave}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 25%;">
              <button style="color: #343a40;" *ngIf="!editing" pButton pRipple
              type="button" pInitEditableRow icon="pi pi-pencil"
              (click)="onRowEditInitLeavesMatrix(rowdata)" class="p-button-rounded p-button-text"></button>
            <button *ngIf="editing" pButton pRipple type="button" pSaveEditableRow icon="pi pi-check"
              (click)="onRowEditSaveLeavesMatrix(rowdata)"
              class="p-button-rounded p-button-text p-button-success p-mr-2"></button>
            <button *ngIf="editing" pButton pRipple type="button" pCancelEditableRow icon="pi pi-times"
              (click)="onRowEditCancelLeavesMatrix(rowdata)" class="p-button-rounded p-button-text p-button-danger"></button>
            
            </td>
    
          </tr>
        </ng-template>

        <ng-template pTemplate="emptymessage" let-columns>
          <tr>
            <td [attr.colspan]="columns.length+2">
              <div class="py-3 text-center">No records found</div>
            </td>
          </tr>
        </ng-template>
      </p-table> 

        <div style="position:relative;" class="align-items-center d-flex justify-content-between">
          <span class="ps-2 textColor">Showing : <strong class="textColor"
              >{{LeavesMatrixData?.length}}</strong> entries
          </span>
          <p-paginator *ngIf="LeavesMatrixData"
            [rows]="5" [totalRecords]="totalLeavesMatrix"
          [rowsPerPageOptions]="[5, 10, 50, 100]" (onPageChange)="onPageChangeLeavesMatrix($event)">
          </p-paginator>
          <span class="pe-2 textColor">Total records : 
            <strong class="textColor">{{totalLeavesMatrix}}</strong>
          </span>
        </div>
  
    </div>
  </p-tabPanel>

  <p-tabPanel  header="PF Matrix">

    <div class="billWrapper shadow-sm">
      <div class="align-items-center d-flex mb-2 m-0 row">
        <div class="col-12 col-sm-6 ps-0 text-center text-sm-start"></div>
        <div class="col-12 col-sm-1 pe-2 text-end" style="font-size: 24px;">
        </div>

        <div class="col-12 col-sm-5 px-1">
          <app-filter (reload)="refreshPFData($event)" (filter)="filterPFData($event)" [dropdownFilterItems]="filterPFMatrixColumField"> 
          </app-filter>
        </div>
      </div>

       <p-table [value]="PFMatrixData" editMode="row" dataKey="" [columns]="PFMatrixCols" [paginator]="false" [rows]="5"
       [showCurrentPageReport]="true" currentPageReportTemplate="Total entries :
       {{totalPFMatrix}}" [responsive]="true" [autoLayout]="true" [rowsPerPageOptions]="[5, 10,50, 100]" responsiveLayout="scroll">
        
        <ng-template pTemplate="header">
          <tr>
            <th class="tableHeader" *ngFor="let col of PFMatrixCols" [pSortableColumn]="col.field">
              {{ col.header }}
              <p-sortIcon *ngIf="col.header != 'Action'" [field]="col.field"></p-sortIcon>
            </th>
          </tr>
        </ng-template>

         <ng-template pTemplate="body" let-rowdata let-editing="editing" let-ri="rowIndex" let-columns="columns">
          <tr [pEditableRow]="rowdata">
            <td style="width: 20%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.BUCode"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.BUCode}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 20%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.EmployeePFRate"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.EmployeePFRate}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 20%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.EmployerPFRate"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.EmployerPFRate}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 20%;">
              <p-cellEditor> 
                <ng-template pTemplate="input">
                  <input pInputText type="text"  [(ngModel)]="rowdata.CapAmount"
                    [style]="{'width':'100%'}" />
                    <!-- </p-dropdown> -->
                </ng-template>
                <ng-template pTemplate="output">
                {{rowdata.CapAmount}}
                </ng-template>
              </p-cellEditor>
            </td>
            <td style="width: 20%;">
              <p-cellEditor>
                <ng-template pTemplate="input">
                  <label class="pe-2">IsMaxCap</label>
                  <input type="checkbox" class="form-check-input" [(ngModel)]="rowdata.isActive"
                    [checked]="rowdata.isActive" />
                </ng-template>
                <ng-template pTemplate="output">
                  {{rowdata.isActive }}
                </ng-template>
              </p-cellEditor>
            </td>

            <td style="width: 10%;">
              <button style="color: #343a40;" *ngIf="!editing" pButton pRipple
              type="button" pInitEditableRow icon="pi pi-pencil"
              (click)="onRowEditInitPFData(rowdata)" class="p-button-rounded p-button-text"></button>
            <button *ngIf="editing" pButton pRipple type="button" pSaveEditableRow icon="pi pi-check"
              (click)="onRowEditSavePFData(rowdata)"
              class="p-button-rounded p-button-text p-button-success p-mr-2"></button>
            <button *ngIf="editing" pButton pRipple type="button" pCancelEditableRow icon="pi pi-times"
              (click)="onRowEditCancelPFData(rowdata)" class="p-button-rounded p-button-text p-button-danger"></button>
            </td>
           
          </tr>
        </ng-template>

        <ng-template pTemplate="emptymessage" let-columns>
          <tr>
            <td [attr.colspan]="columns.length+2">
              <div class="py-3 text-center">No records found</div>
            </td>
          </tr>
        </ng-template>
      </p-table> 

        <div style="position:relative;" class="align-items-center d-flex justify-content-between">
          <span class="ps-2 textColor">Showing : <strong class="textColor"
              >{{PFMatrixData?.length}}</strong> entries
          </span>
          <p-paginator *ngIf="PFMatrixData"
            [rows]="5" [totalRecords]="totalPFMatrix"
          [rowsPerPageOptions]="[5, 10, 50, 100]" (onPageChange)="onPageChangePFMatrix($event)">
          </p-paginator>
          <span class="pe-2 textColor">Total records : 
            <strong class="textColor">{{totalPFMatrix}}</strong>
          </span>
        </div>
  
    </div>
  </p-tabPanel>

  </p-tabView>
  