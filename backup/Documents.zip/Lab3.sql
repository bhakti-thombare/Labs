-- 1
USE pubs;
select * from publishers;
select * from authors;
select * from titleauthor;
select * from titles;

-- 2
select title,price from titles ORDER BY price DESC;

-- 3
select * from titles;
select title, pubdate from titles ORDER BY pubdate ASC;
select title, pubdate from titles ORDER BY pubdate DESC;

-- 4
SELECT title_id, price, ytd_sales, ytd_sales * 5 "Revised_Sales" FROM titles  ORDER BY  Revised_Sales  DESC;
SELECT title_id, price, ytd_sales, ytd_sales * 5 "Revised_Sales" FROM titles  ORDER BY  Revised_Sales  ASC;

-- 5
select * from titles;

SELECT title_id, price, ytd_sales, ytd_sales * 5 "Revised_Sales" FROM titles;
	-- by default its ascending and column 3 is ytd_sales
SELECT title_id, price, ytd_sales, ytd_sales * 5 "Revised_Sales" FROM titles ORDER BY 3;
SELECT title_id, price, ytd_sales, ytd_sales * 5 "Revised_Sales" FROM titles ORDER BY 3 DESC;

-- 6
select * from authors;
-- select au_id, au_fname, city, state from authors ORDER BY au_fname ASC;
select au_fname, city, state from authors ORDER BY au_fname ;
select au_fname, city, state from authors ORDER BY au_fname DESC;

-- 7
select au_fname, city, state from authors ORDER BY state ASC ,  city DESC ;

-- 8
select * from publishers;
-- select * , char_length(country) AS 'character length' from publishers where char_length(country) != 3;
SELECT pub_name, country FROM publishers  WHERE length(country) != 3;

-- 9
select * from titles;
SELECT ROUND(royalty, 2) FROM titles;
select title, royalty, price from titles;
select  title, royalty, price, ROUND(price,2) as Rounded_Number from titles;

-- 9.a,b
SELECT title_id, price, ytd_sales, royalty, ytd_sales * royalty/100 "Royalty Amount" FROM titles;
SELECT title_id, price, ytd_sales, royalty, Round(ytd_sales * royalty/100,2) "Royalty Amount" FROM titles;
SELECT round(ytd_sales*royalty/100, 2) "Royalty Amount" FROM titles;

-- 9.c 
select * from titles;
SELECT title, title_id, price, ytd_sales, royalty,  round(ytd_sales*royalty/100, 2) "Royalty Amount" FROM titles;

SELECT title, title_id, price, ytd_sales, royalty, Round(ytd_sales * royalty/100) "Royalty_Amount" 
FROM titles Having Royalty_Amount >= 1000;

-- 9.c 

-- 10
select * from titles;
-- select title, pubdate from titles where  pubdate  LIKE '____-06-__';
-- select title, pubdate from titles where  pubdate  LIKE '____-06-__' ORDER BY pubdate asc ;
SELECT title, pubdate ,monthname(pubdate) AS MonthOfTheYear FROM titles WHERE monthname(pubdate) = 'June';

-- 11.a
select * from titles;
-- select title, pubdate from titles where  pubdate  LIKE '1991-06-__' ORDER BY pubdate asc ;
select pubdate, title,
dayofweek(pubdate) AS DayOfTheWeek ,
monthname(pubdate) AS MonthOfTheYear  
from titles Having year(pubdate)=1991 AND month(pubdate) = 6 ;

select pubdate, title,
 year(pubdate) AS Year,
month(pubdate) AS month,
dayofweek(pubdate) AS DayOfTheWeek ,
monthname(pubdate) AS MonthOfTheYear  
from titles WHERE   year(pubdate)=1991 AND monthname(pubdate)='June';


-- 11.b 
select * from  titles;
 -- 1 is for sunday
select pubdate, title, 
dayofweek(pubdate) AS DayOfTheWeek ,
dayname(pubdate) AS NameOfDay,
monthname(pubdate) AS MonthOfTheYear  from titles 
where dayname(pubdate)='Sunday'  AND monthname(pubdate)='June';


-- 12.a
-- using dayname()
select title, pubdate, dayofweek(pubdate)AS DayOfTheWeek , dayname(pubdate) AS NameOfTheDay from titles;
 
 SELECT title, pubdate, dayname(pubdate) "day"  FROM titles;
 
-- 12.b
-- using CASE
select title, pubdate ,day(pubdate) as Day,  month(pubdate) AS month, year(pubdate) AS Year,
 dayofweek(pubdate)AS DayOfTheWeek ,
 CASE dayofweek(pubdate)
 when 1 Then 'Sunday'
  when 2 Then 'Monday'
   when 3 Then 'Tuesday'
    when 4 Then 'Wednesday'
     when 5 Then 'Thursday'
      when 6 Then 'Friday'
       when 7 Then 'Saturday'
       else 'unknown'
       end
 NameOfDay from titles;

-- 13 doubt
select title, DATE_SUB('2006-01-01', INTERVAL 15 YEAR) "15 Years Before" from titles;
select title, pubdate from titles WHERE pubdate  >= DATE_SUB('2000-01-01', INTERVAL 15 YEAR);
 SELECT title, pubdate  from titles WHERE (year(curdate()) - year(pubdate)) <= 15;

-- 14 not working

select* from titles;
SELECT title, pubdate, ADDDATE(pubdate,INTERVAL 30 MONTH) "Second Edition (Review Date)" from titles;


-- 15 
select * from titles;
select title_id, pubdate from titles where pubdate IS NULL ;
SELECT title_id,
CASE
when pubdate is NULL 
then 'No Publisher Date' 
else pubdate
end 
as pubdate from titles;

-- 16 
select * from titles;
select title, price from titles;
select title, price , 2 + price "New Price" from titles;

-- 17 
select price from titles;
select title, price from titles where price IS NULL;
 SELECT title, price, IFNULL(price, 0) + 2 "new price" from titles;
 
SELECT title, price,
CASE
when price is NULL 
then  2.0000
else price
end 
as NewPrice from titles;

 SELECT title, price, IFNULL(price,0) + 2 "new price" from titles;


-- 18 
-- SELECT title, price,CASE when price is NULL then  2.0000 else price end as NewPrice  from titles;
SELECT title, price, IFNULL(price, 0) + 2 "new price" from titles;
select title, price as 'CP',  IFNULL(price+2, 2) "new price" from titles;

-- 19 
select * from titles;
SELECT type, UCASE(type) from titles;
SELECT title_id,title,type, 
CASE substr(title_id, 1, 2) 
WHEN 'BU' THEN 'Business'
WHEN 'MC' THEN 'Modern Cooking'
WHEN 'PC' THEN 'Popular Computers'
WHEN 'PS' THEN 'Psychology'
WHEN 'TC' THEN 'Traditional Cooking'
END "type"
FROM titles;







