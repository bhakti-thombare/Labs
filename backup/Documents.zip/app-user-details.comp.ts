import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { SharedService } from './../../shared/shared.service';
import { ExcelService } from '../../shared/excel.service';
import * as JSPDF from 'jspdf';
import 'jspdf-autotable';
import { ToastService } from '../../shared/toast.service';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.scss']
})
export class UserDetailsComponent implements OnInit {
  cols: any = [];
  closeResult = '';
  UserDetailsForm: FormGroup;
  userData: any = [];
  submitted = false;
  pageNumber: number = 0;
  pageSize: number = 5;
  loader: boolean = true;
  totalUserDetailsCount!: any;
  filterColumField: any = [
    { field: 'name', header: 'Username' },
    { field: 'email', header: 'Email' },
    { field: 'userId', header: 'User Id' },
     { field: 'bucode', header: 'Business Unit' },
  ];
  subscription!: Subscription;
  editFlag = false;
  changeTitleAddViewEdit:string = 'Add';
  selectedTabIndex = 0;
  buUnitsDropdown: any = [];
  hasFilteredData: any = {};
  roleAssignForm: FormGroup;
  buAssignForm: FormGroup;
  roles!: any[];
  userRoleData: any = {};
  UnitMapping: any = {};
  functions!:any[];
  departments!:any[];
  sections!:any[];
  constructor(private modalService: NgbModal, private fb: FormBuilder,
    private _shared: SharedService, private excelService: ExcelService, private toast: ToastService) {
    this._shared.sendpageTitle('USER DETAILS');
    
    this.UserDetailsForm = this.fb.group({
      id: [''],
      userId: ['', [Validators.required,Validators.minLength(2),Validators.maxLength(120),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      firstName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(100),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      middleName: [''],
      lastName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(100),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      userSAPId: [''],
      email: ['', [Validators.required, Validators.email]],
      password: [''],
      phoneNumber: ['', [Validators.required, Validators.maxLength(12), Validators.pattern('^\\s*(?:\\+?(\\d{1,3}))?[-.(]*(\\d{3})[-.)]*(\\d{3})[-.)]*(\\d{4})(?: *(\\d+))?\\s*$')]],
      positionCode: ['', Validators.required],
      designationCode: [''],
      bUCode: ['', Validators.required],
      functionCode: [''],
      departmentCode: [''],
      sectionCode: [''],
      isAD: [''],
      mfaenabled: [''],
      isActive: ['true'],
    })

    this.roleAssignForm = this.fb.group({
      userId: ['', [Validators.required, Validators.maxLength(120)]],
      roleName: ['', [Validators.required]],
      isActive: ['false'],
    })

    this.buAssignForm = this.fb.group({
      userId: ['', [Validators.required, Validators.maxLength(120)]],
      buCode: ['', [Validators.required, Validators.maxLength(18)]],
      isActive: ['', Validators.required]
    })
  }

  ngOnInit() {
    this.getUserColumns();
    this.getUserDetailsData(this.pageNumber, this.pageSize);
    this.getBusinessUnitsData(0, 100);
    // this.getPositionsData();
    this.getroleDataFromAPI();
    // this.getFunction(0,100);
    this.getDepartment(0,100);
    this.getSection(0,100);
  }


  checkSpecialCharInUserId = true;
  avoidSpecialCharInUserId(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInUserId = false;
      return this.checkSpecialCharInUserId;
    } else {
      this.checkSpecialCharInUserId = true;
      return this.checkSpecialCharInUserId;
    }
  }

  checkSpecialCharInFname = true;
  avoidSpecialCharInFname(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInFname = false;
      return this.checkSpecialCharInFname;
    } else {
      this.checkSpecialCharInFname = true;
      return this.checkSpecialCharInFname;
    }
  }

  checkSpecialCharInLname = true;
  avoidSpecialCharInLname(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInLname = false;
      return this.checkSpecialCharInLname;
    } else {
      this.checkSpecialCharInLname = true;
      return this.checkSpecialCharInLname;
    }
  }

  checkSpecialCharInPhone = true;
  avoidSpecialCharInPhone(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInPhone = false;
      return this.checkSpecialCharInPhone;
    } else {
      this.checkSpecialCharInPhone = true;
      return this.checkSpecialCharInPhone;
    }
  }

  checkSpecialCharInSap = true;
  avoidSpecialCharInSap(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123)) {
      this.checkSpecialCharInSap = false;
      return this.checkSpecialCharInSap;
    } else {
      this.checkSpecialCharInSap = true;
      return this.checkSpecialCharInSap;
    }
  }


  getroleDataFromAPI() {
    this._shared.get('role/GetRoleList', 'admin').subscribe(res => {
      this.loader = false;
      this.roles = res;
    });
  }

  getFunction(pageNumber: number, pageSize: number){
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize
    };

    this._shared.post('Function/GetFunctions', obj ,'admin').subscribe(res => {
      this.loader = false;
      this.functions = res.item2;
    });
  }

  getDepartment(pageNumber: number, pageSize: number) {
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize,
      unit: sessionStorage.getItem('unit')
    };

    this._shared.post('Department/GetDepartments', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.departments = res.item2;
    });
  }

  getSection(pageNumber: number, pageSize: number) {
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize,
      unit: sessionStorage.getItem('unit')
    };

    this._shared.post('Section/GetSections', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.sections = res.item2;
    });
  }

  get formRoleControl() {
    return this.roleAssignForm.controls;
  }

  get formUnitControl() {
    return this.buAssignForm.controls;
  }

  get formControl() {
    return this.UserDetailsForm.controls;
  }

  getBusinessUnitsData(pageNumber: number, pageSize: number) {
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize
    }

    this._shared.post('businessunit/GetBusinessUnits', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.buUnitsDropdown = res.item2;
      //this.totalBU = res.item1;
    });
  }

  getUserDetailsData(pageNumber: number, pageSize: number) {
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize,
      unit: sessionStorage.getItem('unit')
    }

    this._shared.post('User/GetUsers', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.userData = res.item2;
      this.totalUserDetailsCount = res.item1;
    });
  }

  getErrorMessage() {
    if (this.UserDetailsForm.get('email')?.hasError('required')) {
      return 'Email is required';
    }

    return this.UserDetailsForm.get('email')?.hasError('email') ? 'Not a valid email' : '';
  }

  getUserColumns() {
    this.cols = [
      { field: 'Action', header: 'Action' },
      {field:'bucode', header: 'Business Unit'},
      { field: 'firstName', header: 'Username' },
      { field: 'userId', header: 'User ID' },
      { field: 'email', header: 'Email' },
      { field: 'phoneNumber', header: 'Phone No.' },
      { field: 'isActive', header: 'Status' },
    ];
  }

  open(content: any, flag:any) {
    if(flag == 'Add'){
      let obj = {
        userId: this.UserDetailsForm.value.userId,
        firstName: this.UserDetailsForm.value.firstName,
        middleName: this.UserDetailsForm.value.middleName,
        lastName: this.UserDetailsForm.value.lastName,
        userSAPId: this.UserDetailsForm.value.userSAPId,
        email: this.UserDetailsForm.value.email,
        password: this.UserDetailsForm.value.password,
        phoneNumber: this.UserDetailsForm.value.phoneNumber,
        positionCode: this.UserDetailsForm.value.positionCode,
        designationCode: this.UserDetailsForm.value.designationCode,
        bUCode: this.UserDetailsForm.value.bUCode,
        functionCode: this.UserDetailsForm.value.functionCode,
        departmentCode: this.UserDetailsForm.value.departmentCode,
        sectionCode: this.UserDetailsForm.value.sectionCode,
        isAD: this.UserDetailsForm.value.isAD ? true : false,
        mfaenabled: this.UserDetailsForm.value.mfaenabled ? true : false,
        isActive: this.UserDetailsForm.value.isActive ? true : false,
        createdBy: sessionStorage.getItem('username')
      }
      this._shared.post('User/CreateUser', obj, 'admin').subscribe(res => {
        this.toast.show("Records saved successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.getUserDetailsData(this.pageNumber, this.pageSize);
        this.selectedTabIndex = 0;
        this.UserDetailsForm.reset();
      });
    } else {
      this.UserDetailsForm.value.isActive = this.UserDetailsForm.value.isActive ? true : false,
      this.UserDetailsForm.value.isAD = this.UserDetailsForm.value.isAD ? true : false,
      this.UserDetailsForm.value.mfaenabled = this. UserDetailsForm.value.mfaenabled ? true : false,
      this.UserDetailsForm.value.modifiedBy = sessionStorage.getItem('username');
      this._shared.put('User/UpdateUser', this.UserDetailsForm.value, 'admin').subscribe(res => {
        this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.loader = false;
        this.getUserDetailsData(this.pageNumber, this.pageSize);
        this.selectedTabIndex = 0;
        this.changeTitleAddViewEdit = 'Add';
        //this.UserDetailsForm.reset();
      });
    }
  }

  roleAssign(data: any, status: any){
    this.selectedTabIndex = 2;
    this._shared.post('UserRolesMapping/GetUserRolesMappingsbyUserId', {StringID: data.userId}, 'admin').subscribe(res => {
     this.userRoleData = res[0];
     this.roleAssignForm.patchValue({
       userId: this.userRoleData != undefined ? this.userRoleData.userId  : data.userId,
       roleName: this.userRoleData != undefined ? this.userRoleData.roleName : "",
       isActive: this.userRoleData != undefined ? this.userRoleData.isActive : false
     })
    });
  }

  createNupdateRole(data:any) {
    if (this.userRoleData ==undefined){
      this.roleAssignForm.value.userId = this.roleAssignForm.value.userId;
      this.roleAssignForm.value.isActive = this.roleAssignForm.value.isActive ? true : false,
      this.roleAssignForm.value.createdBy = sessionStorage.getItem('username');
      this.roleAssignForm.value.modifiedBy = sessionStorage.getItem('username');
      this._shared.post('UserRolesMapping/CreateUserRolesMapping', this.roleAssignForm.value, 'admin').subscribe(res => {
        this.toast.show("Role assigned successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.roleAssignForm.reset();
        this.getUserDetailsData(this.pageNumber, this.pageSize);
        this.selectedTabIndex = 0;
      });
    }else {
      this.roleAssignForm.value.isActive = this.roleAssignForm.value.isActive ? true : false;
      this.roleAssignForm.value.modifiedBy = sessionStorage.getItem('username');
      this._shared.put('UserRolesMapping/UpdateUserRolesMapping', this.roleAssignForm.value, 'admin').subscribe(res => {
        this.toast.show("Role updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.userRoleData = {};
        this.getUserDetailsData(this.pageNumber, this.pageSize);
        this.selectedTabIndex = 0;
      });
    }
  }

  unitAssign(data: any, status: any) {
    this.selectedTabIndex = 3;
    this._shared.post('UsersBUMapping/GetUserBUMappingsbyUserId', { StringID: data.userId }, 'admin').subscribe(res => {
      this.UnitMapping = res[0];
      this.buAssignForm.patchValue({
        userId: this.UnitMapping != undefined ? this.UnitMapping.userId : data.userId,
        buCode: this.UnitMapping != undefined ? this.UnitMapping.bucode : "",
        isActive: this.UnitMapping != undefined ? this.UnitMapping.isActive : false
      })
    });
  }
  createNupdateUnit(data: any) {
    if (this.UnitMapping == undefined) {
      this.buAssignForm.value.isActive = this.buAssignForm.value.isActive ? true : false,
      this.buAssignForm.value.userId = this.buAssignForm.value.userId;
      this.buAssignForm.value.createdBy = sessionStorage.getItem('username');
      this.buAssignForm.value.modifiedBy = sessionStorage.getItem('username');
      this._shared.post('UsersBUMapping/CreateUserBUMapping', this.buAssignForm.value, 'admin').subscribe(res => {
        this.toast.show("Unit mapped created successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.buAssignForm.reset();
        this.getUserDetailsData(this.pageNumber, this.pageSize);
        this.selectedTabIndex = 0;
      });
    } else {
      this.buAssignForm.value.buid = data.buid;
      this.buAssignForm.value.isActive = this.buAssignForm.value.isActive ? true : false;
      this.buAssignForm.value.modifiedBy = sessionStorage.getItem('username');
      this._shared.put('UsersBUMapping/UpdateUserBUMapping', this.buAssignForm.value, 'admin').subscribe(res => {
        this.toast.show("Unit mapped updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.UnitMapping = {};
        this.getUserDetailsData(this.pageNumber, this.pageSize);
        this.selectedTabIndex = 0;
      });
    }
  }

  edit(data: any, status:any) {
    if(status == 'edit'){
      this.changeTitleAddViewEdit = 'Edit';
      this.selectedTabIndex = 1;
      this.editFlag = true;
      this.UserDetailsForm.value.id = data.id;
    }else if(status == 'view'){
      this.selectedTabIndex = 1;
      this.changeTitleAddViewEdit = 'View';
      this.editFlag = false;
    } else{
     
    }
    
    this.UserDetailsForm.patchValue({
      userId: data.userId,
      firstName: data.firstName,
      middleName: data.middleName,
      lastName: data.lastName,
      userSAPId: data.userSapid,
      email: data.email,
      password: data.password,
      phoneNumber: data.phoneNumber,
      positionCode: data.positionCode,
      designationCode: data.designationCode,
      bUCode: data.bucode,
      functionCode: data.functionCode,
      departmentCode: data.departmentCode,
      sectionCode: data.sectionCode,
      isAD: data.isAd,
      mfaenabled: data.mfaenabled,
      isActive: data.isActive,
      id: data.id
    })
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  filterData(evntData: any) {
    evntData.pageSize = this.pageSize;
    evntData.pageNumber = this.pageNumber;
    this._shared.post('User/SearchUsers', evntData, 'admin').subscribe(res => {
      this.loader = false;
      this.userData = res.item2;
      this.hasFilteredData = evntData;
      this.totalUserDetailsCount = res.item1;
    });
  }

  refresh(event: any) {
    if (event) {
      this.getUserDetailsData(this.pageNumber, this.pageSize);
      this.hasFilteredData={};
    }
  }

  onPageChange(event: any) {

    if (Object.keys(this.hasFilteredData).length !=0){
      this.hasFilteredData.pageNumber = event.page;
      this.hasFilteredData.pageSize = event.rows;
      this.pageSize = event.rows;
      this._shared.post('User/SearchUsers', this.hasFilteredData , 'admin').subscribe(res => {
        this.loader = false;
        this.userData = res.item2;
        this.totalUserDetailsCount = res.item1;
      });
    } else {
      this.pageSize = event.rows;
      this.pageNumber = event.page;
      this.getUserDetailsData(event.page, event.rows);
    }
  }

  tabChange(e:any){
    this.editFlag = true;
    this.changeTitleAddViewEdit = 'Add';
    this.UserDetailsForm.reset();
    this.roleAssignForm.reset();
    this.buAssignForm.reset();
    this.UserDetailsForm.patchValue({'isActive':true});
    let index = e.index;
    if(index ==0){
      this.selectedTabIndex = 0;
      this.getUserDetailsData(this.pageNumber, this.pageSize);
    }
  }

  exportAsXLSX() {
    if (this.userData.length > 0) {
      this.excelService.exportAsExcelFile(this.userData, 'sample');
    }
  }

  createPdf() {
    let head: any = [[]];
    let data: any = [[]];
    this.userData.forEach((res: any, index: any) => {
      if (index == 0) {
        for (let obj in res) {
          if (head[index].length <= 8) {
            head[0].push(obj);
            data[index].push(res[obj]);
          }
        }
      } else {
        data.push([])
        for (let obj in res) {
          if (data[index].length <= 8) {
            data[index].push(res[obj])
          }
        }
      }
    })

    let doc = new JSPDF.jsPDF("l", "in");

    doc.setFontSize(9);
    doc.text('', 11, 8);
    doc.setFontSize(9);
    doc.setTextColor(100);


    (doc as any).autoTable({
      head: head,
      body: data,
      theme: 'plain',
      didDrawCell: (data: any) => {
        console.log(data.column.index)
      }
    })

    // Open PDF document in new tab
    doc.output('dataurlnewwindow')

    // Download PDF document  
    doc.save('table.pdf');
  }

  ngOnDestroy() {
    //this.subscription.unsubscribe();
  }
}



