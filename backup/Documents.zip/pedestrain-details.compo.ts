// core
import { Component, OnInit, ViewChild } from '@angular/core';
import { DatePipe, Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

// 3rd party
import swal from 'sweetalert2';
import { NgbModal, ModalDismissReasons, NgbModalRef, NgbDateStruct, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';

// app
import { HttpService } from '@app/services/http-service';
import { TranslationService } from '@services/translation/translation.service';
import { EventService } from '@services/events/event.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';
import { CustomerSurveyAlertsService } from '@services/Alerts/customer-survey-alerts.service';
import { isNull } from 'util';
import * as _ from 'lodash';
import { MissionListAlertsService } from '@app/services/Alerts/mission-list-alerts.service';
import { ApiService } from '@app/services/apiServices/api.service';
import { forkJoin } from 'rxjs/observable/forkJoin';

import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-pedestrain-details',
  templateUrl: './pedestrain-details.component.html',
  styleUrls: ['./pedestrain-details.component.css']
})
export class PedestrainDetailsComponent implements OnInit {
  ngbModalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false
  };
  commentModalArr;

  today = new Date(Date.now());
  campaignEndDate: any = {};


  minDate = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };

  reassignModal: NgbModalRef;
  closeResult: string;
  iterationImage: string;
  noSyncDataMessage: boolean;
  circuits: Array<any>;
  swapCount: Array<any>;
  selectedCircuit = {};
  userReports: Array<any>;
  missionName: string;
  missionType = {
    id: null
  };
  numberOfBreaksAm;
  numberOfBreaksPm;
  totalBreakTimeAm;
  totalBreakTimePm;
  missionStartDate: any;
  missionId: number;
  busyDates = [];
  missionDate = {
    day: null,
    month: null,
    year: null
  };
  reportCards = [];
  dateSelected = false;
  userShifts = [];


  reassignReqObj = {
    missionId: null,
    oldUserId: null,
    newUserId: null,
    shiftId: null,
    iterations: null,
    newStartDate: undefined,
    newEndDate: undefined,
    supervisorId: null,
    currentStatus: undefined,
    currentStartDate: null
  };
  userShiftDto: any;
  fieldAgents = [];
  selectedFieldagent;
  user;

  slot1 = {};
  slot2 = {};
  slot3 = {};
  slot4 = {};
  evaluateFlag: boolean = false;
  swapFlag: boolean = false;
  number: number = 1;
  disableSwapButton: boolean = false;
  missionStartDateAm: any;
  missionEndDateAm: any;
  missionStartDatePm: any;
  missionEndDatePm: any;
  approveFlag: boolean = false;
  approveFlag1: boolean = false;
  report1;
  report;
  reqObj1: { missionId: any; userId: any; shiftId: any; iterations: any; supervisorId: any; currentStatus: any; };
  reqObj: { missionId: any; userId: any; shiftId: any; iterations: any; supervisorId: any; currentStatus: any; };
  lastSync: any;
  swap=[];


  constructor(public location: Location,
    public customerSurveyAlert: CustomerSurveyAlertsService,
    public modalService: NgbModal,
    public route: ActivatedRoute,
    public http: HttpService,
    public event: EventService,
    public router: Router,
    public datePipe: DatePipe,
    public apiService: ApiService,
    public missionListAlertsService: MissionListAlertsService,
    public translate: TranslationService,
    public translateS: TranslateService,) {
    this.user = JSON.parse(localStorage.getItem('user-data'));
    this.event.broadcast({ eventName: 'showLoader', data: {} });
    this.route.params.subscribe(params => {
      this.missionId = parseInt(params.id, 10);
      this.validateUser(() => {
        this.reportsInitializer();
      });
    });
  }

  validateUser(cb) {
    this.http.SecureGet('/mission/getMissionCreatedBy?missionId=' + this.missionId).subscribe(res => {
      if (this.user.userId === res.userId) {
        cb();
      } else {
        this.location.back();
      }
    }, err => {
      this.location.back();
    });
  }
  getUIDate(date) { return (date) ? this.datePipe.transform(date, 'dd/MM/yyyy') : 'NA'; };
  getUITime(date) { return (!isNull(date)) ? `${this.datePipe.transform(date, "HH:mm:ss")}` : 'NA'; };

  fieldagentstatus;
  timeOfConnection;
  missionStarttDate;
  missionEnddate;
  marketZone;
  missionCircuits;
  delayAm;
  delayPm;
  agentId;
  timeOfConnectionAm;
  timeOfConnectionPm;
  reportsInitializer() {
    this.http.SecureGet('/mission/missionProgressReport?missionId=' + this.missionId).subscribe(res => {
      if (res.missionProgressDto.userShiftDto.length === 0) {
        this.location.back();
      } else {
        if (res.missionProgressDto.evaluateFlag == true) {
          this.evaluateFlag = true;
        }
        else
          this.evaluateFlag = false;

        this.userShiftDto = res.missionProgressDto.userShiftDto;
        this.marketZone = res.missionProgressDto.marketZone
        this.missionCircuits = res.missionProgressDto.missionCircuits[0]
        this.delayAm = res.missionProgressDto.delayAm;
        this.delayPm = res.missionProgressDto.delayPm;
        this.timeOfConnectionAm = res.missionProgressDto.timeOfConnectionAm;
        this.timeOfConnectionPm = res.missionProgressDto.timeOfConnectionPm;
        this.missionStartDateAm = res.missionProgressDto.missionStartDateAm;
        this.missionEndDateAm = res.missionProgressDto.missionEndDateAm;
        this.missionStartDatePm = res.missionProgressDto.missionStartDatePm;
        this.missionEndDatePm = res.missionProgressDto.missionEndDatePm;
        const startDate = res.missionProgressDto.missionCampaign.campaignStartDate.split(' ')[0];
        const endDate = res.missionProgressDto.missionCampaign.campaignEndDate.split(' ')[0];
        localStorage.setItem('campaignStartDate', JSON.stringify({
          day: parseInt(startDate.split('-')[2]),
          month: parseInt(startDate.split('-')[1]),
          year: parseInt(startDate.split('-')[0])
        }));
        localStorage.setItem('campaignEndDate', JSON.stringify({
          day: parseInt(endDate.split('-')[2]),
          month: parseInt(endDate.split('-')[1]),
          year: parseInt(endDate.split('-')[0])
        }));

        this.fieldagentstatus = res.missionProgressDto.missionStatus ? res.missionProgressDto.missionStatus.statusName : ''
        this.timeOfConnection = res.missionProgressDto.timeOfConnection
        this.missionStarttDate = res.missionProgressDto.missionStartDate
        this.missionEnddate = res.missionProgressDto.missionEndDate

        this.missionName = res.missionProgressDto.missionName;
        this.missionType = res.missionProgressDto.missionType;
        this.numberOfBreaksAm = res.missionProgressDto.numberOfBreaksAm;
        this.numberOfBreaksPm = res.missionProgressDto.numberOfBreaksPm;
        this.totalBreakTimeAm = res.missionProgressDto.totalBreakTimeAm;
        this.totalBreakTimePm = res.missionProgressDto.totalBreakTimePm;
        this.missionStartDate = res.missionProgressDto.missionStartDate;
        let circuitLen = res.missionProgressDto.missionCircuits.length;
        this.circuits = [];
        res.missionProgressDto.missionCircuits.forEach(circuit => {
          this.circuits.push(circuit);

          circuitLen--;
          if (circuitLen === 0) {
            this.selectedCircuit = this.circuits[0];
            this.circuits.splice(0, 1);
          }
        });
        this.userShifts = res.missionProgressDto.userShiftDto;
        if (res.missionProgressDto.userReports.length === 0) {
          this.noSyncDataMessage = true;
          this.userShifts = res.missionProgressDto.userShiftDto;
          this.unavailableReportCardGenerator(() => {

            this.event.broadcast({ eventName: 'hideLoader', data: {} });
          });
        } else {

          this.noSyncDataMessage = false;
          this.userReports = res.missionProgressDto.userReports;
          this.reportGenerator();
        }
      }

      this.campaignEndDate = new Date(res.missionProgressDto.missionCampaign.campaignEndDate);
      console.log("campaignEndDate", this.campaignEndDate);

    }, err => {
      this.event.broadcast({ eventName: 'hideLoader', data: {} });
      this.router.navigate(['/supervisor/missions']);
    });
  }

  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6;
  }


  isDisabled(date: NgbDateStruct, current: { month: number }) {

    const now = new Date(Date.now());
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
    const sdate = new Date(date.year, date.month - 1, date.day);
    const userDateTime = localStorage.getItem('userMissionDate');

    const userDate = userDateTime.split(' ')[0];
    const userDateArray = userDate.split('-');
    const userYear = parseInt(userDateArray[0], 10);
    const userMonth = parseInt(userDateArray[1], 10);
    const userDay = parseInt(userDateArray[2], 10);
    const userDateTimeString = new Date(userYear, userMonth - 1, userDay);
    const day = userDateTimeString.getDay();
    const sday = sdate.getDay();

    if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate && sday === day) {
      console.log(day);
      console.log(sday);
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };

        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return true;
    }

  }

  ngOnInit() {
    console.log("this.reportCards", this.reportCards);
  }

  goBack() {
    this.location.back();
  }
  // can be isolated
  reportGenerator() {
    let userReportsLen = this.userReports.length;
    this.userReports.forEach(report => {

      this.loopCounter(report, () => {
        userReportsLen--;
        if (userReportsLen === 0) {
          console.log('All report cards are generated');
          this.unavailableReportCardGenerator(() => {
            const nullIndex = [];
            let reportLen = this.reportCards.length;
            this.reportCards.forEach((reportCard, ind) => {
              if (reportCard.fieldAgentStatus === undefined) {
                nullIndex.push(ind);
              }
              reportLen--;
              if (reportLen === 0) {
                let nullIndexLen = nullIndex.length;
                const nullCheck = nullIndex.length;
                if (nullCheck === 0) {
                  this.event.broadcast({ eventName: 'hideLoader', data: {} });
                } else {
                  nullIndex.forEach(nu => {
                    this.reportCards.splice(nu, 1);
                    nullIndexLen--;
                    if (nullIndexLen === 0) {
                      this.event.broadcast({ eventName: 'hideLoader', data: {} });
                    }
                  });
                }
              }
            });
          });
        }
      });
    });
    // this.reportCards.sort(function(a, b) {
    //   return a.iterationReports[0].shift - b.iterationReports[0].shift;
    // });
    // console.log("this.reportCards", this.reportCards);
  }

  unavailableReportCardGenerator(cb) {
    const checkLength = this.reportCards.length;
    let reportsLength = this.reportCards.length;
    const missingReports = [];
    const availableReports = [];

    if (checkLength === 0) {
      let userShiftLen = this.userShifts.length;
      this.userShifts.forEach((shiftObj, ind) => {
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
          'July', 'August', 'September', 'October', 'November', 'December'
        ];
        const date = shiftObj.startDate.split(' ')[0];
        const iterdate = date.split('-');
        const iterationDate = new Date(parseInt(iterdate[0], 10), parseInt(iterdate[1], 10) - 1, parseInt(iterdate[2], 10));
        const reportDate = iterationDate.getDate() + ' '
          + monthNames[iterationDate.getMonth()] + ' ' + iterationDate.getFullYear();
        let shiftTime;
        if (shiftObj.shift === 1) {
          if (shiftObj.iterations === 4) {
            shiftTime = '12:30 - 14:30';
          } else {
            shiftTime = '10:00 - 12:30';
          }
        } else {
          if (shiftObj.iterations === 4) {
            shiftTime = '14:30 - 16:30';
          } else {
            shiftTime = '16:30 - 19:00';
          }
        }
        missingReports.push({
          fieldAgent: {
            firstName: shiftObj.firstName,
            lastName: shiftObj.lastName,
            userId: shiftObj.id
          },
          reportActualDate: date,
          reportDate: reportDate,
          shiftTime: shiftTime,
          fieldAgentStatus: shiftObj.status,
          iterationReports: []
        });
        userShiftLen--;

        if (userShiftLen === 0) {
          this.nullIterationReportsAdder(missingReports, () => {
            cb();
          });
        }
      });
    } else {
      this.reportCards.forEach((card, cardInd) => {
        reportsLength--;
        let userShiftLen = this.userShifts.length;
        this.userShifts.forEach((shiftObj, ind) => {
          if (card.actualReport.userId === shiftObj.id) {
            let reportShift;
            let iteration;
            if (card.shiftTime.split(' - ')[0] === '10:00' && shiftObj.startDate.split(' ')[1] === '10:00:00') {
              reportShift = 1;
              iteration = 5;
            } else if (card.shiftTime.split(' - ')[0] === '12:30' && shiftObj.startDate.split(' ')[1] === '12:30:00') {
              reportShift = 1;
              iteration = 4;
            } else if (card.shiftTime.split(' - ')[0] === '14:30' && shiftObj.startDate.split(' ')[1] === '14:30:00') {
              reportShift = 2;
              iteration = 4;
            } else if (card.shiftTime.split(' - ')[0] === '16:30' && shiftObj.startDate.split(' ')[1] === '16:30:00') {
              reportShift = 2;
              iteration = 5;
            }
            if (iteration === shiftObj.iterations) {
              if (card.iterationReports.length !== 0) {
                availableReports.push(ind);
                card.fieldAgentStatus = shiftObj.status;
              }
            }
          }
          userShiftLen--;

          if (userShiftLen === 0) {
            if (reportsLength === 0) {
              for (let j = 0; j < this.userShifts.length; j++) {
                let found = -1;
                const availableReportFinder = (rep) => {
                  return rep === j;
                };
                found = availableReports.findIndex(availableReportFinder);
                if (found === -1) {
                  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                    'July', 'August', 'September', 'October', 'November', 'December'
                  ];
                  const date = this.userShifts[j].startDate.split(' ')[0];
                  const iterdate = date.split('-');
                  const iterationDate = new Date(parseInt(iterdate[0], 10), parseInt(iterdate[1], 10) - 1,
                    parseInt(iterdate[2], 10), 0, 0, 0, 0);
                  const reportDate = iterationDate.getDate() + ' '
                    + monthNames[iterationDate.getMonth()] + ' ' + iterationDate.getFullYear();
                  let shiftTime;
                  if (this.userShifts[j].shift === 1) {
                    if (this.userShifts[j].iterations === 4) {
                      shiftTime = '12:30 - 14:30';
                    } else {
                      shiftTime = '10:00 - 12:30';
                    }
                  } else {
                    if (this.userShifts[j].iterations === 4) {
                      shiftTime = '14:30 - 16:30';
                    } else {
                      shiftTime = '16:30 - 19:00';
                    }
                  }
                  missingReports.push({
                    fieldAgent: {
                      firstName: this.userShifts[j].firstName,
                      lastName: this.userShifts[j].lastName,
                      userId: this.userShifts[j].id
                    },
                    reportActualDate: date,
                    reportDate: reportDate,
                    shiftTime: shiftTime,
                    fieldAgentStatus: this.userShifts[j].status,
                    iterationReports: []
                  });
                }
                if (j === this.userShifts.length - 1) {
                  if (missingReports.length !== 0) {
                    this.nullIterationReportsAdder(missingReports, () => {
                      cb();
                    });
                  } else {
                    cb();
                  }
                }
              }
            }
          }
        });
      });
    }
    if (this.reportCards[0].iterationReports[0].shift == 2) {
      this.swap.push(this.reportCards[1]);
      this.swap.push(this.reportCards[0]);
      this.reportCards = this.swap;
    }
    console.log("this.reportCards", this.reportCards);
  }

  nullIterationReportsAdder(missionReports, cb) {
    let missionReportsLength = missionReports.length;
    missionReports.forEach(mr => {
      this.reportCards.push(mr);
      missionReportsLength--;
      if (missionReportsLength === 0) {
        cb();
      }
    });
  }

  loopCounter(report, cb) {
    const shift1iter5 = {
      fieldAgent: {
        firstName: report.firstName,
        lastName: report.lastName,
        userId: report.userId
      },
      reportDate: undefined,
      shiftTime: undefined,
      fieldAgentStatus: undefined,
      iterationReports: [],
      actualReport: report,
      reportActualDate: '',
      swapIds: [],
      lastSync: ''
    };
    const shift1iter4 = {
      fieldAgent: {
        firstName: report.firstName,
        lastName: report.lastName,
        userId: report.userId
      },
      reportDate: undefined,
      shiftTime: undefined,
      fieldAgentStatus: undefined,
      iterationReports: [],
      actualReport: report,
      reportActualDate: '',
      swapIds: [],
      lastSync: ''
    };
    const shift2iter4 = {
      fieldAgent: {
        firstName: report.firstName,
        lastName: report.lastName,
        userId: report.userId
      },
      reportDate: undefined,
      shiftTime: undefined,
      fieldAgentStatus: undefined,
      iterationReports: [],
      actualReport: report,
      reportActualDate: '',
      swapIds: [],
      lastSync: ''
    };
    const shift2iter5 = {
      fieldAgent: {
        firstName: report.firstName,
        lastName: report.lastName,
        userId: report.userId
      },
      reportDate: undefined,
      shiftTime: undefined,
      fieldAgentStatus: undefined,
      iterationReports: [],
      actualReport: report,
      reportActualDate: '',
      swapIds: [],
      lastSync: ''
    };
    let missionReportsLen = report.missionReports.length;
    const checkReportsLen = report.missionReports.length;
    if (checkReportsLen === 0) {
      cb();
    } else {
      report.missionReports.forEach(missionReport => {
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
          'July', 'August', 'September', 'October', 'November', 'December'
        ];
        /* const expectedDateTime = missionReport.ipadExpectedTime.split(' ');
        const expectedTime = expectedDateTime[1]; */
        const expectedDateTime = missionReport.slotTime.split(' ')[0] + ' ' + missionReport.ipadExpectedTime;
        const realDateTime = missionReport.realTime;

        const realTimeArray = realDateTime.split(' ')[1].split(':');
        const realDateArray = realDateTime.split(' ')[0].split('-');

        const expectedTimeArray = expectedDateTime.split(' ')[1].split(':');
        const expectedDateArray = expectedDateTime.split(' ')[0].split('-');

        const real = new Date(parseInt(realDateArray[0], 10),
          parseInt(realDateArray[1], 10), parseInt(realDateArray[2], 10), parseInt(realTimeArray[0], 10),
          parseInt(realTimeArray[1], 10), parseInt(realTimeArray[2], 10), 0);
        const expected = new Date(parseInt(expectedDateArray[0], 10), parseInt(expectedDateArray[1], 10),
          parseInt(expectedDateArray[2], 10), parseInt(expectedTimeArray[0], 10), parseInt(expectedTimeArray[1], 10), 0, 0);

        const diff = real.getTime() - expected.getTime();
        let diffHrs;
        if (diff < 0) {
          const pureNumber = Math.abs(diff);
          if (pureNumber > 3599999) {
            diffHrs = Math.floor((diff % 86400000) / 3600000) + 1;
          } else {
            diffHrs = 0;
          }
        } else {
          const pureNumber = Math.abs(diff);
          if (pureNumber > 3599999) {
            diffHrs = Math.floor((diff % 86400000) / 3600000);
          } else {
            diffHrs = 0;
          }
        }

        const diffMins = Math.floor(((diff % 86400000) % 3600000) / 60000);
        if (diffHrs < 0) {
          missionReport.lateTime = diffHrs + 'h ' + Math.abs(diffMins) + 'm';
        } else {
          if (diffHrs === 0) {
            missionReport.lateTime =(diffMins) + 'm';
          } else {
            missionReport.lateTime = diffHrs + 'h ' + Math.abs(diffMins) + 'm';
          }
        }

        missionReport.realTime = realTimeArray[0] + ':' + realTimeArray[1];

        missionReport.distance = Math.round(parseInt(missionReport.distance, 10) * 100) / 100;

        missionReport.expectedTime = expectedTimeArray[0] + ':' + expectedTimeArray[1];

        const slotTime = missionReport.slotTime.split(' ')[1];
        const slotTimeArray = slotTime.split(':');
        missionReport.slotTime = slotTimeArray[0] + ':' + slotTimeArray[1];
        if (missionReport.shift === 1) {
          if (missionReport.slotTime === '10:00') {
            shift1iter5.iterationReports.push(missionReport);
            shift1iter5.lastSync = missionReport.lastSynched;
            this.lastSync=missionReport.lastSynched.split(' ');
            shift1iter5.reportActualDate = expectedDateTime;
          } else {
            shift1iter4.iterationReports.push(missionReport);
            shift1iter4.lastSync = missionReport.lastSynched;
            this.lastSync=missionReport.lastSynched.split(' ');
            shift1iter4.reportActualDate = expectedDateTime;
          }
        } else if (missionReport.shift === 2) {
          if (missionReport.slotTime === '16:30' || missionReport.slotTime === '04:30') {
            missionReport.slotTime = '16:30';
            shift2iter5.iterationReports.push(missionReport);
            shift2iter5.lastSync = missionReport.lastSynched;
            this.lastSync=missionReport.lastSynched.split(' ');
            shift2iter5.reportActualDate = expectedDateTime;
          } else {
            missionReport.slotTime = '14:30';
            shift2iter4.iterationReports.push(missionReport);
            shift2iter4.lastSync = missionReport.lastSynched;
            this.lastSync=missionReport.lastSynched.split(' ');
            shift2iter4.reportActualDate = expectedDateTime;
          }
        }

        const comm = JSON.stringify(missionReport.comment);
        missionReport.comments = [];
        if (comm !== '{}') {
          for (const key in missionReport.comment) {
            if (!missionReport.comment.hasOwnProperty(key)) {
              continue;
            }
            const comment = {
              eventTitle: key,
              comments: []
            };

            const obj = missionReport.comment[key];
            let objLen = obj.length;
            obj.forEach(ob => {
              comment.comments.push(ob);
              objLen--;
              if (objLen === 0) {
                missionReport.comments.push(comment);
              }
            });
          }
        }

        missionReportsLen--;
        if (missionReportsLen === 0) {
          if (shift1iter5.iterationReports.length !== 0) {
            shift1iter5.shiftTime = '10:00 - 12:30';
            // shift1iter5.reportDate = reportDate;
            this.userShifts.forEach(us => {
              if (us.startDate.split(' ')[1] === '10:00:00') {
                const start = us.startDate.split(' ')[0];
                const startDateArray = start.split('-');
                const shiftStartDate = new Date(parseInt(startDateArray[0], 10), parseInt(startDateArray[1], 10) - 1,
                  parseInt(startDateArray[2], 10), 0, 0, 0, 0);
                shift1iter5.reportDate = shiftStartDate.getDate() + ' ' +
                  monthNames[shiftStartDate.getMonth()] + ' ' + shiftStartDate.getFullYear();
              }
            });
            this.reportCards.push(shift1iter5);
          }
          if (shift1iter4.iterationReports.length !== 0) {
            shift1iter4.shiftTime = '12:30 - 14:30';
            // shift1iter4.reportDate = reportDate;
            this.userShifts.forEach(us => {
              if (us.startDate.split(' ')[1] === '12:30:00') {
                const start = us.startDate.split(' ')[0];
                const startDateArray = start.split('-');
                const shiftStartDate = new Date(parseInt(startDateArray[0], 10), parseInt(startDateArray[1], 10) - 1,
                  parseInt(startDateArray[2], 10), 0, 0, 0, 0);
                shift1iter4.reportDate = shiftStartDate.getDate() + ' ' +
                  monthNames[shiftStartDate.getMonth()] + ' ' + shiftStartDate.getFullYear();
              }
            });
            this.reportCards.push(shift1iter4);
          }
          if (shift2iter4.iterationReports.length !== 0) {
            shift2iter4.shiftTime = '14:30 - 16:30';
            // shift2iter4.reportDate = reportDate;
            this.userShifts.forEach(us => {
              if (us.startDate.split(' ')[1] === '14:30:00') {
                const start = us.startDate.split(' ')[0];
                const startDateArray = start.split('-');
                const shiftStartDate = new Date(parseInt(startDateArray[0], 10), parseInt(startDateArray[1], 10) - 1,
                  parseInt(startDateArray[2], 10), 0, 0, 0, 0);
                shift2iter4.reportDate = shiftStartDate.getDate() + ' ' +
                  monthNames[shiftStartDate.getMonth()] + ' ' + shiftStartDate.getFullYear();
              }
            });
            this.reportCards.push(shift2iter4);
          }
          if (shift2iter5.iterationReports.length !== 0) {
            shift2iter5.shiftTime = '16:30 - 19:00';
            // shift2iter5.reportDate = reportDate;
            this.userShifts.forEach(us => {
              if (us.startDate.split(' ')[1] === '16:30:00') {
                const start = us.startDate.split(' ')[0];
                const startDateArray = start.split('-');
                const shiftStartDate = new Date(parseInt(startDateArray[0], 10), parseInt(startDateArray[1], 10) - 1,
                  parseInt(startDateArray[2], 10), 0, 0, 0, 0);
                shift2iter5.reportDate = shiftStartDate.getDate() + ' ' +
                  monthNames[shiftStartDate.getMonth()] + ' ' + shiftStartDate.getFullYear();
              }
            });
            this.reportCards.push(shift2iter5);
          }
          cb();
          /* this.iterationSort(() => {
            cb();
          }); */
        }
      });
    }
  }
  applySort(key, order) {
    console.log("key=", key, order);

    this.reportCards.forEach(report => {
      console.log("repo=", report);
      report.iterationReports = _.orderBy(report.iterationReports, key, order);
// console.log('hi',report.iterationReports);

    })

  }

  iterationSort(cb) {
    let reportsLen = this.reportCards.length;
    this.reportCards.forEach(report => {
      report.iterationReports.sort((a, b) => {
        return a.iteration - b.iteration;
      });
      reportsLen--;
      if (reportsLen === 0) {
        cb();
      }
    });
  }
  gotoLocation() {
    this.router.navigate(['/supervisor/edit-location/pf-zone/' + this.missionCircuits.circuitName + '/002' + '/' + this.missionCircuits.circuitId]);
  }
  gotoMarket() {
    this.router.navigate(['/supervisor/edit-location/market-zone/' + this.marketZone.shortName + '/002' + '/' + this.marketZone.id]);

  }
  modalRef;
  @ViewChild('myModal') myModal;
  openModal() {
    this.modalRef = this.modalService.open(this.myModal, {
      backdrop: true,
      keyboard: false,
    })
  }
  close() {
    this.modalRef.close();
  }
  evaluation;
  check(key) {
    console.log("key=", key);
    this.evaluation = key;
  }
  evaluationDone = false;
  evaluateMission() {
    this.evaluationDone = true;
    this.modalRef.close();
    let bad, correct, perfect
    if (this.evaluation == 'bad') {
      bad = true;
      correct = false;
      perfect = false;
    } else if (this.evaluation == 'correct') {
      correct = true;
      bad = false;
      perfect = false;
    } else {
      perfect = true;
      correct = false;
      bad = false;
    }
    const reqBody = {
      missionId: this.missionId,
      agentId: this.userShiftDto[0].id,
      badlyDone: bad,
      correctlyDone: correct,
      perfectlyDone: perfect
    }
    this.apiService.posEvaluate(reqBody).subscribe((res) => {
      console.log("success=", res);
      if (res.responseCode == 200) {
        this.evaluateFlag = true;
        this.missionListAlertsService.evaluateMpd();
      }

    })
  }


  openImageModal(image, modal) {
    console.log("image=", image, modal);

    this.iterationImage = image;
    this.modalService.open(modal, { size: 'lg' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  openCommentModal(modal, comments) {
    this.commentModalArr = comments;
    this.modalService.open(modal, { size: 'lg' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  reassignKar() {
    this.modalRef.close();
    this.router.navigate([`missions/details/${this.missionId}/3/pf/reassign`]);
  }

  @ViewChild('reassignModal1') reassignModal1;
  openReassignModal(modal, report) {
    // this.router.navigate([`missions/details/${this.missionId}/3/pf/reassign`]);
    // swal(MESSAGECONSTANTS.ALERT_MESSAGES.CAMPAIGN_EXPIRED_TITLE, '', 'warning').then(data => {
    //   // this.location.back();
    // });

    return swal({
      title: this.translateS.instant('The mission is within an overdue campaign. If you want to select a new assignment date, please first contact your Admin in order to expand campaign duration.'),
      // text: this.translate.instant('The mission is within an overdue campaign. If you want to select a new assignment date, please first contact your Admin in order to expand campaign duration.') + '?',
      type: 'warning', 
      // allowOutsideClick: false,
    
      confirmButtonText: this.translateS.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_USE_EXISTING_ZONE),
      // showCancelButton: true,
    });

    //   this.modalRef = this.modalService.open(this.reassignModal1, {
    //     backdrop: true,
    //     keyboard: false,
    // })


    // this.hideApproveButton=true;

    // console.log("modal",modal);

    // console.log("report",report);
    // // console.log("this.userShiftDto",this.userShiftDto);

    // console.log("today",this.today);
    // if(this.today>=this.campaignEndDate){

    //   this.customerSurveyAlert
    //     .campainIsExpireAlert()
    //     .then(rs => {})
    //     .catch(err => err);

    //   console.log("CAMPAIGN EXPIRED");
    // }else{
    //   let shift = null;
    // if(report.shiftTime == '10:00 - 12:30' || report.shiftTime == '12:30 - 14:30'){
    //   shift = 1;
    // }
    // if(report.shiftTime == '14:30 - 16:30' || report.shiftTime == '16:30 - 19:00'){
    //   shift = 2;
    // }
    // // console.log("shift",shift);
    // for(let user of this.userShiftDto){
    //   // console.log('loop:: user ',user);
    //   if(user.id == report.fieldAgent.userId && shift == user.shift){
    //     this.reassignReqObj.currentStartDate = user.startDate;
    //     break;        
    //   }
    // }
    // //console.log('this.reassignReqObj.currentStartDate',this.reassignReqObj.currentStartDate);

    // localStorage.setItem('userMissionDate', report.reportActualDate);
    // // this.reassignReqObj.currentStartDate = report.reportActualDate +":00"
    // // console.log("this.reassignReqObj.currentStartDate",this.reassignReqObj.currentStartDate);

    // this.reassignReqObj.currentStatus = report.fieldAgentStatus;
    // const date = new Date(Date.now());
    // this.selectedFieldagent = {
    //   firstName: undefined,
    //   lastName: undefined
    // };
    // this.fieldAgents = [];
    // this.dateSelected = false;
    // const month = date.getMonth() + 1;
    // localStorage.removeItem('busyDates');
    // this.event.broadcast({ eventName: 'showLoader', data: {} });




    // this.http.SecureGet('/ref/getMissionDates?currentDate=' + date.getFullYear() + '-' +
    //   + month + '-' + date.getDate()).subscribe(res => {
    //     let busyDatesLen = res.dateDto.length;
    //     res.dateDto.forEach(resdate => {
    //       resdate.day = parseInt(resdate.day, 10);
    //       resdate.month = parseInt(resdate.month, 10);
    //       resdate.year = parseInt(resdate.year, 10);
    //       this.busyDates.push(resdate);
    //       busyDatesLen--;
    //       if (busyDatesLen === 0) {
    //         this.reassignReqObj.missionId = this.missionId;
    //         this.reassignReqObj.oldUserId = report.fieldAgent.userId;
    //         if (report.shiftTime.split(' - ')[0] === '10:00') {
    //           this.reassignReqObj.iterations = 5;
    //           this.reassignReqObj.shiftId = 1;
    //         } else if (report.shiftTime.split(' - ')[0] === '12:30') {
    //           this.reassignReqObj.iterations = 4;
    //           this.reassignReqObj.shiftId = 1;
    //         } else if (report.shiftTime.split(' - ')[0] === '14:30') {
    //           this.reassignReqObj.iterations = 4;
    //           this.reassignReqObj.shiftId = 2;
    //         } else if (report.shiftTime.split(' - ')[0] === '16:30') {
    //           this.reassignReqObj.iterations = 5;
    //           this.reassignReqObj.shiftId = 2;
    //         }
    //         localStorage.setItem('busyDates', JSON.stringify(this.busyDates));
    //         this.event.broadcast({ eventName: 'hideLoader', data: {} });
    //         this.reassignModal = this.modalService.open(modal, this.ngbModalOptions);
    //         this.reassignModal.result.then((result) => {
    //           this.missionDate = {
    //             day: null,
    //             month: null,
    //             year: null
    //           };
    //           this.selectedFieldagent = {
    //             firstName: undefined,
    //             lastName: undefined
    //           };
    //           this.fieldAgents = [];
    //           this.dateSelected = false;
    //           this.closeResult = `Closed with: ${result}`;
    //         }, (reason) => {
    //           this.missionDate = {
    //             day: null,
    //             month: null,
    //             year: null
    //           };
    //           this.selectedFieldagent = {
    //             firstName: undefined,
    //             lastName: undefined
    //           };
    //           this.fieldAgents = [];
    //           this.dateSelected = false;
    //           this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    //         });
    //       }
    //     });
    //   }, err => {
    //     this.reassignReqObj.missionId = this.missionId;
    //     this.reassignReqObj.oldUserId = report.fieldAgent.userId;
    //     if (report.shiftTime.split(' - ')[0] === '10:00') {
    //       this.reassignReqObj.iterations = 5;
    //       this.reassignReqObj.shiftId = 1;
    //     } else if (report.shiftTime.split(' - ')[0] === '12:30') {
    //       this.reassignReqObj.iterations = 4;
    //       this.reassignReqObj.shiftId = 1;
    //     } else if (report.shiftTime.split(' - ')[0] === '14:30') {
    //       this.reassignReqObj.iterations = 4;
    //       this.reassignReqObj.shiftId = 2;
    //     } else if (report.shiftTime.split(' - ')[0] === '16:30') {
    //       this.reassignReqObj.iterations = 5;
    //       this.reassignReqObj.shiftId = 2;
    //     }
    //     this.event.broadcast({ eventName: 'hideLoader', data: {} });
    //     this.reassignModal = this.modalService.open(modal, this.ngbModalOptions);
    //     this.reassignModal.result.then((result) => {
    //       this.closeResult = `Closed with: ${result}`;
    //       this.missionDate = {
    //         day: null,
    //         month: null,
    //         year: null
    //       };
    //       this.selectedFieldagent = {
    //         firstName: undefined,
    //         lastName: undefined
    //       };
    //       this.fieldAgents = [];
    //       this.dateSelected = false;
    //     }, (reason) => {
    //       this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    //       this.missionDate = {
    //         day: null,
    //         month: null,
    //         year: null
    //       };
    //       this.selectedFieldagent = {
    //         firstName: undefined,
    //         lastName: undefined
    //       };
    //       this.fieldAgents = [];
    //       this.dateSelected = false;
    //     });
    //   });
    // }
  }

  swapLeftRight(reportIndex, iterationIndex, iteration) {
    iteration.swapCount ? iteration.swapCount += 1 : iteration.swapCount = this.number;
    if (iteration.swapCount % 2 == 0) {
      iteration.swapFlag = false;
    }
    else {
      iteration.swapFlag = true;
    }
    const iterationId = this.reportCards[reportIndex].iterationReports[iterationIndex].iterationId;
    const left = this.reportCards[reportIndex].iterationReports[iterationIndex].leftCount;
    const right = this.reportCards[reportIndex].iterationReports[iterationIndex].rightCount;
    this.reportCards[reportIndex].iterationReports[iterationIndex].leftCount = right;
    this.reportCards[reportIndex].iterationReports[iterationIndex].rightCount = left;
    if (!this.reportCards[reportIndex].swapIds.includes(iterationId)) {
      this.reportCards[reportIndex].swapIds.push(iterationId);
    }
  }

  submitReassignModal() {
    if (this.missionDate) {
      swal({
        title: MESSAGECONSTANTS.ALERT_MESSAGES.DO_YOU_WANT_TO_REASSIGN_MISSION,
        text: '',
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, reassign!',
        cancelButtonText: 'No, cancel!'
      }).then(() => {
        if (this.reassignReqObj.shiftId === 1) {
          if (this.reassignReqObj.iterations === 5) {
            this.reassignReqObj.newStartDate = this.missionDate.year + '-' + this.missionDate.month + '-' + this.missionDate.day
              + ' 10:00:00';

            this.reassignReqObj.newEndDate = this.missionDate.year + '-' + this.missionDate.month + '-' + this.missionDate.day
              + ' 12:30:00';
          } else {
            this.reassignReqObj.newStartDate = this.missionDate.year + '-' + this.missionDate.month + '-' + this.missionDate.day
              + ' 12:30:00';

            this.reassignReqObj.newEndDate = this.missionDate.year + '-' + this.missionDate.month + '-' + this.missionDate.day
              + ' 14:30:00';
          }
        } else {
          if (this.reassignReqObj.iterations === 5) {
            this.reassignReqObj.newStartDate = this.missionDate.year + '-' + this.missionDate.month + '-' + this.missionDate.day
              + ' 16:30:00';

            this.reassignReqObj.newEndDate = this.missionDate.year + '-' + this.missionDate.month + '-' + this.missionDate.day
              + ' 19:00:00';
          } else {
            this.reassignReqObj.newStartDate = this.missionDate.year + '-' + this.missionDate.month + '-' + this.missionDate.day
              + ' 14:30:00';

            this.reassignReqObj.newEndDate = this.missionDate.year + '-' + this.missionDate.month + '-' + this.missionDate.day
              + ' 16:30:00';
          }
        }
        this.reassignReqObj.newUserId = this.selectedFieldagent.userId;
        this.reassignReqObj.supervisorId = this.user.userId;

        this.event.broadcast({ eventName: 'showLoader', data: {} });
        this.http.SecurePost('/mission/reAssignMission', this.reassignReqObj).subscribe(res => {
          this.missionDate = {
            day: null,
            month: null,
            year: null
          };
          this.dateSelected = false;
          this.selectedFieldagent = {
            firstName: undefined,
            lastName: undefined
          };
          this.fieldAgents = [];
          this.reassignModal.close();
          this.event.broadcast({ eventName: 'hideLoader', data: {} });
          this.translate.translateMessageObject({
            title: 'Reassignment successful',
            text: '',
            outsideClick: false,
            cancelBtnText: '',
            showCancelBtn: false,
            confirmBtnText: 'OK',
            type: 'success'
          }, mes => {
            this.translate.translateAndPop(mes).then(() => {
              window.location.reload();
            }).catch(() => {
              window.location.reload();
            });
          });
        }, err => {
          this.event.broadcast({ eventName: 'hideLoader', data: {} });
          this.translate.translateMessageObject({
            title: 'Something went wrong',
            text: '',
            outsideClick: false,
            cancelBtnText: '',
            showCancelBtn: false,
            confirmBtnText: 'OK',
            type: 'warning'
          }, mes => {
            this.translate.translateAndPop(mes).then(() => {
            }).catch(() => {
            });
          });
          this.reassignModal.close();
        });
      }).catch(() => {
        this.missionDate = {
          day: null,
          month: null,
          year: null
        };
        this.dateSelected = false;
        this.selectedFieldagent = {
          firstName: undefined,
          lastName: undefined
        };
        this.fieldAgents = [];
        this.reassignModal.close();
      });
    } else {
      this.translate.translateMessageObject({
        title: 'Date is mandatory',
        text: '',
        outsideClick: false,
        cancelBtnText: '',
        showCancelBtn: false,
        confirmBtnText: 'OK',
        type: 'warning'
      }, mes => {
        this.translate.translateAndPop(mes).then(() => {
        }).catch(() => {
        });
      });
    }
  }

  changeLocalDate(date, e) {
    if (!e.target.classList.contains('text-lightgrey')) {
      const currTimestamp = Date.now();
      const now = new Date(currTimestamp);
      const currDate = now.getDate();
      const currMonth = now.getMonth() + 1;
      const currFullYear = now.getFullYear();
      const busyDates = JSON.parse(localStorage.getItem('busyDates'));
      if (date.year === currFullYear) {
        if (date.month === currMonth) {
          if (date.day < currDate) {
          } else if (busyDates !== null) {
            let found = -1;
            const dateFinder = (dateObj) => {
              return dateObj.day === date.day && dateObj.month === date.month && dateObj.year === date.year;
            };

            found = busyDates.findIndex(dateFinder);
            if (found !== -1) {
            } else {
              this.getFieldAgents(date);
            }
          } else if (busyDates === null) {
            this.getFieldAgents(date);
          }
        } else if (date.month < currMonth) {
        } else if (busyDates !== null) {
          let found = -1;
          const dateFinder = (dateObj) => {
            return dateObj.day === date.day && dateObj.month === date.month && dateObj.year === date.year;
          };

          found = busyDates.findIndex(dateFinder);
          if (found !== -1) {
          } else {
            this.getFieldAgents(date);
          }
        } else if (busyDates === null) {
          this.getFieldAgents(date);
        }
      } else if (date.year < currFullYear) {
      } else if (date.year > currFullYear) {
        let found = -1;
        const dateFinder = (dateObj) => {
          return dateObj.day === date.day && dateObj.month === date.month && dateObj.year === date.year;
        };

        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
        } else {
          this.getFieldAgents(date);
        }
      }
      localStorage.setItem('date', JSON.stringify(date));
    }
  }

  getFieldAgents(date) {
    this.selectedFieldagent = undefined;
    this.fieldAgents = [];
    this.dateSelected = false;
    this.event.broadcast({ eventName: 'showLoader', data: {} });
    this.http.SecurePost('/ref/getAllUnassignedUsers', {
      startDate: date.year + '-' + date.month + '-' + date.day,
      missionId: this.missionId,
      shift: this.reassignReqObj.shiftId,
      iterations: this.reassignReqObj.iterations
    }).subscribe(res => {
      let resLen = res.users.length;
      res.users.forEach(user => {
        this.fieldAgents.push(user);
        resLen--;
        if (resLen === 0) {
          this.event.broadcast({ eventName: 'hideLoader', data: {} });
          this.selectedFieldagent = this.fieldAgents[0];
          this.fieldAgents.splice(0, 1);
          this.dateSelected = true;
        }
      });
    }, err => {
    });
  }

  toggleFieldAgent(fieldAgent) {
    this.fieldAgents.push(this.selectedFieldagent);
    this.selectedFieldagent = fieldAgent;
    let deleteIndex = -1;
    let falen = this.fieldAgents.length;
    this.fieldAgents.forEach((fa, i) => {
      if (fa.userId === fieldAgent.userId) {
        deleteIndex = i;
      }
      falen--;
      if (falen === 0) {
        this.fieldAgents.splice(deleteIndex, 1);
      }
    });
  }

  approveReportCard() {
    this.event.broadcast({ eventName: 'showLoader', data: {} });
    let count = 0;
    this.report = this.reportCards[0];
    this.report1 = this.reportCards[1];
    if (this.report.hasOwnProperty('swapIds')) {
      if (this.report.swapIds.length === 0) {
        this.reqObj = {
          missionId: null,
          userId: null,
          shiftId: null,
          iterations: null,
          supervisorId: null,
          currentStatus: this.report.fieldAgentStatus
        };

        this.reqObj.supervisorId = this.user.userId;

        this.reqObj.missionId = this.missionId;
        this.reqObj.userId = this.report.fieldAgent.userId;
        if (this.report.shiftTime.split(' - ')[0] === '10:00') {
          this.reqObj.iterations = 5;
          this.reqObj.shiftId = 1;
        } else if (this.report.shiftTime.split(' - ')[0] === '12:30') {
          this.reqObj.iterations = 4;
          this.reqObj.shiftId = 1;
        } else if (this.report.shiftTime.split(' - ')[0] === '14:30') {
          this.reqObj.iterations = 4;
          this.reqObj.shiftId = 2;
        } else if (this.report.shiftTime.split(' - ')[0] === '16:30') {
          this.reqObj.iterations = 5;
          this.reqObj.shiftId = 2;
        }
        this.approveFlag = true;
      }
      else {
        this.http.SecurePost('/mission/swapMissionReportCounts', this.report.swapIds).subscribe(res => {
          this.reqObj = {
            missionId: null,
            userId: null,
            shiftId: null,
            iterations: null,
            supervisorId: null,
            currentStatus: this.report.fieldAgentStatus
          };

          this.reqObj.supervisorId = this.user.userId;

          this.reqObj.missionId = this.missionId;
          this.reqObj.userId = this.report.fieldAgent.userId;
          if (this.report.shiftTime.split(' - ')[0] === '10:00') {
            this.reqObj.iterations = 5;
            this.reqObj.shiftId = 1;
          } else if (this.report.shiftTime.split(' - ')[0] === '12:30') {
            this.reqObj.iterations = 4;
            this.reqObj.shiftId = 1;
          } else if (this.report.shiftTime.split(' - ')[0] === '14:30') {
            this.reqObj.iterations = 4;
            this.reqObj.shiftId = 2;
          } else if (this.report.shiftTime.split(' - ')[0] === '16:30') {
            this.reqObj.iterations = 5;
            this.reqObj.shiftId = 2;
          }
          this.approveFlag1 = true;
        }, err => {
          this.approveFlag1 = false;
          this.event.broadcast({ eventName: 'hideLoader', data: {} });
        });
      }
    }
    if (this.report1.hasOwnProperty('swapIds')) {
      if (this.report1.swapIds.length === 0) {
        this.reqObj1 = {
          missionId: null,
          userId: null,
          shiftId: null,
          iterations: null,
          supervisorId: null,
          currentStatus: this.report1.fieldAgentStatus
        };

        this.reqObj1.supervisorId = this.user.userId;

        this.reqObj1.missionId = this.missionId;
        this.reqObj1.userId = this.report1.fieldAgent.userId;
        if (this.report1.shiftTime.split(' - ')[0] === '10:00') {
          this.reqObj1.iterations = 5;
          this.reqObj1.shiftId = 1;
        } else if (this.report1.shiftTime.split(' - ')[0] === '12:30') {
          this.reqObj1.iterations = 4;
          this.reqObj1.shiftId = 1;
        } else if (this.report1.shiftTime.split(' - ')[0] === '14:30') {
          this.reqObj1.iterations = 4;
          this.reqObj1.shiftId = 2;
        } else if (this.report1.shiftTime.split(' - ')[0] === '16:30') {
          this.reqObj1.iterations = 5;
          this.reqObj1.shiftId = 2;
        }
        this.disableSwapButton = true;
        this.approveFlag = true;
      }
      else {
        this.http.SecurePost('/mission/swapMissionReportCounts', this.report1.swapIds).subscribe(res => {
          this.reqObj1 = {
            missionId: null,
            userId: null,
            shiftId: null,
            iterations: null,
            supervisorId: null,
            currentStatus: this.report1.fieldAgentStatus
          };

          this.reqObj1.supervisorId = this.user.userId;

          this.reqObj1.missionId = this.missionId;
          this.reqObj1.userId = this.report1.fieldAgent.userId;
          if (this.report.shiftTime.split(' - ')[0] === '10:00') {
            this.reqObj1.iterations = 5;
            this.reqObj1.shiftId = 1;
          } else if (this.report1.shiftTime.split(' - ')[0] === '12:30') {
            this.reqObj1.iterations = 4;
            this.reqObj1.shiftId = 1;
          } else if (this.report1.shiftTime.split(' - ')[0] === '14:30') {
            this.reqObj1.iterations = 4;
            this.reqObj1.shiftId = 2;
          } else if (this.report1.shiftTime.split(' - ')[0] === '16:30') {
            this.reqObj1.iterations = 5;
            this.reqObj1.shiftId = 2;
          }
          this.approveFlag1 = true;
          // APIcall
        }, err => {
          this.approveFlag1 = false;
          this.event.broadcast({ eventName: 'hideLoader', data: {} });
        });
      }
    }
    this.callApproveAPI(this.reqObj, this.reqObj1);
  }

  callApproveAPI(reqObj, reqObj1) {
    if (reqObj && reqObj1) {
      forkJoin([
        this.http.SecurePost('/mission/approveMission', reqObj),
        this.http.SecurePost('/mission/approveMission', reqObj1)
      ]).subscribe(res => {
        // setTimeout(() => {
        this.translate.translateMessageObject({
          title: 'Slot approved successfully',
          text: '',
          outsideClick: false,
          cancelBtnText: '',
          showCancelBtn: false,
          confirmBtnText: 'OK',
          type: 'success'
        }, mes => {
          this.translate.translateAndPop(mes).then(() => {
            if (this.approveFlag1) {
              this.event.broadcast({ eventName: 'hideLoader', data: {} });
              this.translate.translateMessageObject({
                title: 'Iteration pedestrian flow count swapped successfully',
                text: '',
                type: 'success',
                outsideClick: false,
                cancelBtnText: '',
                showCancelBtn: false,
                confirmBtnText: 'OK'
              }, message => {
                this.translate.translateAndPop(message).then(() => {
                  window.location.reload();
                }).catch(() => {
                  window.location.reload();
                })
              });
            }
            else {
              window.location.reload();
            }
          }).catch(() => {
            window.location.reload();
          });
        });

        // this.missionListAlertsService.aproveMpd();
        this.missionDate = {
          day: null,
          month: null,
          year: null
        };
        this.dateSelected = false;
        this.selectedFieldagent = {
          firstName: undefined,
          lastName: undefined
        };
        this.fieldAgents = [];       
        this.event.broadcast({ eventName: 'hideLoader', data: {} });
        // }, 200); 
      }, err => {
        this.event.broadcast({ eventName: 'hideLoader', data: {} });
        this.translate.translateMessageObject({
          title: 'Something went wrong',
          text: '',
          outsideClick: false,
          cancelBtnText: '',
          showCancelBtn: false,
          confirmBtnText: 'OK',
          type: 'error'
        }, mes => {
          this.translate.translateAndPop(mes).then(() => {
            window.location.reload();
          }).catch(() => {
            window.location.reload();
          });
        });
      });
    }
    else {
      reqObj1 ? reqObj = reqObj1 : reqObj;
      this.http.SecurePost('/mission/approveMission', reqObj)
        .subscribe(res => {
          this.disableSwapButton = true;
          this.missionDate = {
            day: null,
            month: null,
            year: null
          };
          this.dateSelected = false;
          this.selectedFieldagent = {
            firstName: undefined,
            lastName: undefined
          };
          this.fieldAgents = [];
          this.translate.translateMessageObject({
            title: 'Slot approved successfully',
            text: '',
            outsideClick: false,
            cancelBtnText: '',
            showCancelBtn: false,
            confirmBtnText: 'OK',
            type: 'success'
          }, mes => {
            this.translate.translateAndPop(mes).then(() => {
              window.location.reload();
            }).catch(() => {
              window.location.reload();
            });
          });
          window.location.reload();
          this.event.broadcast({ eventName: 'hideLoader', data: {} });

        }, err => {
          this.translate.translateMessageObject({
            title: 'Something went wrong',
            text: '',
            outsideClick: false,
            cancelBtnText: '',
            showCancelBtn: false,
            confirmBtnText: 'OK',
            type: 'error'
          }, mes => {
            this.translate.translateAndPop(mes).then(() => {
              window.location.reload();
            }).catch(() => {
              window.location.reload();
            });
          });
          this.event.broadcast({ eventName: 'hideLoader', data: {} });
        });
    }
  }

  checkStatus() {
    let flag;
    for (let report of this.reportCards) {
      if ((report.iterationReports.length != 0 && report.fieldAgentStatus == 'In Progress' || report.fieldAgentStatus == 'In review' || report.fieldAgentStatus == 'Give up') ||
        (report.iterationReports.length == 0 && report.fieldAgentStatus == 'Overdue')) {
        flag = true;
        break;
      }
      else {
        flag = false;
      }
    }
    if (flag == true) {
      return true
    }
    else
      return false;
  }
  checkStatus1() {
    let flag;
    for (let report of this.reportCards) {
      if (report.iterationReports.length != 0 && (report.fieldAgentStatus == 'In Progress' || report.fieldAgentStatus == 'In review') &&
        (report.fieldAgentStatus !== 'Overdue' && report.fieldAgentStatus !== 'Give up')) {
        flag = true;
        break;
      }
      else {
        flag = false;
      }
    }
    if (flag == true) {
      return true;
    }
    else
      return false;
  }

  checkStatus2() {
    let flag;
    for (let report of this.reportCards) {
      if (!(report.iterationReports.length == 0 && report.fieldAgentStatus == 'In Progress') && report.fieldAgentStatus != 'Done' && report.fieldAgentStatus != 'Re assigned') {
        flag = true;
        break;
      }
      else {
        flag = false;
      }

    }
    if (flag == true) {
      return true;
    }
    else
      return false;
  }
}
