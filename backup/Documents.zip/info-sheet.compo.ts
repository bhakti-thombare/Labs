import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ApiService } from '@app/services/apiServices/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import * as _ from 'lodash' ;
import {
  each,
  keys,
  isNull,
  map,
  values,
  isArray,
  filter,
  isString,
  isNumber
} from 'underscore';
import { EventService } from '@app/services/events/event.service';
import { Location } from '@angular/common';
import { StorageService } from '@app/services/storage-service.service';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { TranslateService } from '@ngx-translate/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ImagePopupComponent } from '@app/shared/image-popup/image-popup.component';
import { LowerCasePipe } from '@angular/common';

@Component({
  selector: 'app-info-sheet',
  templateUrl: './info-sheet.component.html',
  styleUrls: ['./info-sheet.component.css']
})
export class InfoSheetComponent implements OnInit {
  showApprove: boolean;
  showButton: boolean;
  ids: any;
  @Input() infoDetails: any = {};

  @Input() quartierId: any = {};
  @Input() missionId: any = {};

  @Output() back = new EventEmitter();
  @Output() objectApproveEvent = new EventEmitter();

  showInfo: boolean;
  private subscriptions: Subscription[] = [];
  private utilityFunctions = new UtilityFunctions();
  sellingOptions: any = ['Renting', 'Selling'];
  oldPos: any;
  newPos: any;
  // missionId: string;
  missionType: string;
  tanslatedTagsNew: string = '';
  tagsNew: string = '';
  tanslatedTagsOld: string = '';
  q1Selected: boolean = false;
  q2Selected: boolean = false;
  facadeAnswersUI: any;
  selectedQ2: string;
  selectedQ1: string;
  contectQ3Selected: boolean = false;
  contectQ4Selected: boolean = false;
  contectQ5Selected: boolean = false;
  contectQ6Selected: boolean = false;
  contectQ7Selected: boolean = false;
  selectedContextQ3: string;
  selectedContextQ4: string;
  selectedContextQ5: string;
  selectedContextQ6: string;
  selectedContextQ7: string;
  accessQ1Selected: boolean;
  selectedaccessQ1: string;
  accessQ2Selected: boolean;
  selectedaccessQ2: string;
  accessQ3Selected: boolean;
  selectedaccessQ3: string;
  accessQ4Selected: boolean;
  selectedaccessQ4: string;
  accessQ5Selected: boolean;
  selectedaccessQ5: string;
  accessQ6Selected: boolean;
  selectedaccessQ6: string;
  counterQ1Selected: boolean;
  selectedcounterQ1: string;
  counterQ2Selected: boolean;
  selectedcounterQ2: string;
  counterQ3Selected: boolean;
  selectedcounterQ3: string;
  counterQ4Selected: boolean;
  selectedcounterQ4: string;
  counterQ5Selected: boolean;
  selectedcounterQ5: string;
  counterQ6Selected: boolean;
  selectedcounterQ6: string;
  floorQ1Selected: boolean;
  selectedfloorQ1: string;
  floorQ2Selected: boolean;
  selectedfloorQ2: string;
  floorQ3Selected: boolean;
  selectedfloorQ3: string;
  floorQ4Selected: boolean;
  selectedfloorQ4: string;
  floorQ5Selected: boolean;
  selectedfloorQ5: string;
  contactQ1Selected: boolean;
  selectedcontactQ1: string;
  contactQ2Selected: boolean;
  selectedcontactQ2: string;
  contactQ3Selected: boolean;
  selectedcontactQ3: string;
  contactQ4Selected: boolean;
  selectedcontactQ4: string;
  contactQ5Selected: boolean;
  selectedcontactQ5: string;
  contactQ6Selected: boolean;
  selectedcontactQ6: string;
  paymentQ1Selected: boolean;
  selectedpaymentQ1: string;
  paymentQ2Selected: boolean;
  selectedpaymentQ2: string;
  paymentQ3Selected: boolean;
  selectedpaymentQ3: string;
  paymentQ4Selected: boolean;
  selectedpaymentQ4: string;
  paymentQ5Selected: boolean;
  selectedpaymentQ5: string;
  paymentQ6Selected: boolean;
  selectedpaymentQ6: string;
  historicQ1Selected: boolean;
  selectedhistoricQ1: string;
  historicQ2Selected: boolean;
  selectedhistoricQ2: string;
  historicQ3Selected: boolean;
  selectedhistoricQ3: string;
  historicQ4Selected: boolean;
  selectedhistoricQ4: string;
  historicQ5Selected: boolean;
  selectedhistoricQ5: string;
  historicQ6Selected: boolean;
  selectedhistoricQ6: string;
  tag: boolean;
  tagUpdated = [];
  tagUpdated1 = [];
  tagupdated: string;
  level2s: any = [];
  level1s = [];
  slectedtype1: any;
  leve31Selected: string;
  selectedLeve31: boolean = false;
  selectedLeve32: boolean = false;
  selectedLeve33: boolean = false;
  selectedLeve34: boolean = false;
  selectedLeve22: boolean = false;
  selectedLeve12: boolean = false;
  leve32Selected: string;
  leve33Selected: string;
  leve34Selected: string;
  selectedLeve21: boolean = false;
  leve21Selected: string;
  temp: { id: number; answer: any; lvl2ID: number; lvl1ID: number; }[];
  leve22Selected: string;
  level31: { id: number; answer: any; lvl2ID: number; lvl1ID: number; }[];
  level32: { id: number; answer: any; lvl2ID: number; lvl1ID: number; }[];
  level33: { id: number; answer: any; lvl2ID: number; lvl1ID: number; }[];
  level34: { id: number; answer: any; lvl2ID: number; lvl1ID: number; }[];
  level21: { id: number; answer: any; lvl1ID: number; }[];
  level22: { id: number; answer: any; lvl1ID: number; }[];
  level23: { id: number; answer: any; lvl1ID: number; }[];
  level24: { id: number; answer: any; lvl1ID: number; }[];
  level11: { id: number; answer: any; }[];
  level12: { id: number; answer: any; }[];
  level13: { id: number; answer: any; }[];
  level14: { id: number; answer: any; }[];
  selectedLeve23: boolean = false;
  leve23Selected: string;
  selectedLeve24: boolean = false;
  leve24Selected: string;
  selectedLeve13: boolean = false;
  leve13Selected: string;
  selectedLeve11: boolean;
  leve11Selected: string;
  leve12Selected: string;
  leve14Selected: string;
  selectedLeve14: boolean;
  dto: any;
  address: string;
  chain: any;
  name: any;
  address1: string;
  q2_no: any;
  q2_phoneNumber: any;
  q2_dontWantToDisclose: any;
  q3_dontWantToDisclose: any;
  q3_mail: any;
  q3_no: any;
  q4_dontWantToDisclose: any;
  q4_no: any;
  q4_website: any;
  tablemodified: boolean = false;
  updatedPosName: boolean = false;
  updatedChain: boolean = false;
  updatedAddress: boolean = false;
  updatedPhone: boolean = false;
  updatedMail: boolean = false;
  updatedWebsite: boolean = false;
  updatedPosType1: boolean = false;
  updatedPosType2: boolean = false;
  updatedPosType3: boolean = false;
  updatedPosType4: boolean = false;
  updatedTag: boolean = false;
  updated77: boolean = false;
  seven: any;
  twenty: any;
  updated24: boolean = false;
  contact: boolean;
  updatedContact: boolean = false;
  updatedHistoric: boolean = false;
  updatedHistoricQ6: boolean = false;
  updatedCell: boolean = false;
  updatedAdd: boolean = false;
  postyp1: any;
  postype2: any;
  postype3: any;
  postype4: any;
  cell: any;
  cell1: any;
  add: any;
  phn: any;
  mail: any;
  web: any;
  posD2DThuNoWorking: any;
  posD2DMoBreak: any;
  posD2DThuAppointment: any;
  posD2DFriShift1: any;
  posD2DFriBreak: any;
  posD2DFriAppointment: any;
  posD2DSatShift1: any;
  posD2DSatBreak: any;
  posD2DSatAppointment: any;
  posD2DSunShift1: any;
  posD2DSunBreak: any;
  posD2DThuShift1: any;
  posD2DWedBreak: any;
  posD2DWedAppointment: any;
  posD2DThuBreak: any;
  posD2DWedShift1: any;
  posD2DTuAppointment: any;
  posD2DTuBreak: any;
  posD2DMoShift1: any;
  posD2DMoAppointment: any;
  posD2DTuShift1: any;
  chainName: boolean = false;
  selectedName: string;
  hideTable: boolean;
  hideTable1: boolean;
  standardFlag: boolean;
  numberSelected: boolean;
  dateSelected: boolean=true;
  dateSelected1: boolean=true;
  dateSelected2: boolean=true;
  dateSelected3: boolean=true;
  dateSelected4: boolean=true;
  browserLang: string;
  shopSurface: any;
  totalSurface: any;
  rentingPrice: any;
  sellingPrice: any;
  adEmail: any;
  adPhone: any;
  adTypeName: boolean =false;
  selectedAdTypeName: string;
  adType: any;
  updatedAdType: boolean =false;
  visit: boolean =false;
  prm: boolean =false;
  rightPanelBlank: boolean =false;
  leftPanelBlank: boolean =false;

  constructor(
    private apiService: ApiService,
    public _event: EventService,
    private location: Location,
    private storageService: StorageService,
    private router: Router,
    private route: ActivatedRoute,
    public translate: TranslateService,
    private modalService: NgbModal
  ) { }

  Url: any;
  b: number;
  facadeAnswers = [];
  contextAnswers = [];
  accessAnswers = [];
  counterInteriorAnswers = [];
  floorsRestroomAnswers = [];
  contactAnswers = [];
  paymentAndSurface = [];
  historicAnswers = [];
  facadeQ1 = [{ 'id': 1, 'answer': 'Present and perfectly identifiable' },
  { 'id': 2, 'answer': 'Present but difficult to identify (hidden, presence of obsolete signs, etc.)' },
  { 'id': 3, 'answer': 'Absent' }];

  facadeQ2 = [{ 'id': 1, 'answer': 'Present and perfectly identifiable' },
  { 'id': 2, 'answer': 'Present but difficult to identify' },
  { 'id': 3, 'answer': 'Absent' }];

  // facadeQ3=[{'id':7,'answer':'Summary/Dilapidated'},
  //   {'id':8,'answer':'In good condition'},
  //   {'id':9,'answer':'Renovated/Modern'},
  //   {'id':10,'answer':'Non Pertinent/Non visible'}];

  contextQ3 = [{ 'id': 1, 'answer': this.translate.instant('Yes') }, { 'id': 2, 'answer': this.translate.instant('No') }, { 'id': 3, 'answer': this.translate.instant('Non relevant (gallery or else)') }];
  contextQ4 = [{ 'id': 1, 'answer': this.translate.instant('None (few or no inclination)') }, { 'id': 2, 'answer': this.translate.instant('Slope in the street direction') }, { 'id': 3, 'answer': this.translate.instant('Slope in the facade/border direction') }];
  contextQ5 = [{ 'id': 1, 'answer': this.translate.instant('In perfect condition') }, { 'id': 2, 'answer': this.translate.instant('In good condition (some small holes, loose pavers, etc.)') }, { 'id': 3, 'answer': this.translate.instant('In poor condition') }, { 'id': 4, 'answer': this.translate.instant('Under construction') }];
  contextQ6 = [{ 'id': 1, 'answer': this.translate.instant('Yes') }, { 'id': 2, 'answer': this.translate.instant('No') }];
  contextQ7 = [{ 'id': 1, 'answer': this.translate.instant('Narrow sidewalk/Driveway') }, { 'id': 2, 'answer': this.translate.instant('Sidewalk/Driveway under construction') }, { 'id': 3, 'answer': this.translate.instant('Presence of annoying elements (terrace, display, trash can, flowerpot, etc.)') }];

  accessQ1 = [{ 'id': 1, 'answer': this.translate.instant('Yes') }, { 'id': 2, 'answer': this.translate.instant('No') }];
  accessQ2 = [{ 'id': 1, 'answer': this.translate.instant('Yes') }, { 'id': 2, 'answer': this.translate.instant('No, it is in the building`s recess') }, { 'id': 3, 'answer': this.translate.instant('No, the store is inside a building (shopping center, gallery, etc.)') }];
  accessQ3 = [{ 'id': 1, 'answer': this.translate.instant('In ground level') }, { 'id': 2, 'answer': this.translate.instant('With a small ledge (2cm or less)') }, { 'id': 3, 'answer': this.translate.instant('With a step') }, { 'id': 4, 'answer': this.translate.instant('With more than one step') }];
  accessQ4 = [{ 'id': 1, 'answer': this.translate.instant('Yes, a permanent') }, { 'id': 2, 'answer': this.translate.instant('Yes, a removable') }, { 'id': 3, 'answer': this.translate.instant('No') }];
  accessQ5 = [{ 'id': 1, 'answer': this.translate.instant('Automatic') }, { 'id': 2, 'answer': this.translate.instant('Opening in both directions') }, { 'id': 3, 'answer': this.translate.instant('Inward opening') }, { 'id': 4, 'answer': this.translate.instant('Outward opening') }, { 'id': 5, 'answer': this.translate.instant('Not relevant (no door)') }];
  accessQ6 = [{ 'id': 1, 'answer': this.translate.instant('Yes') }, { 'id': 2, 'answer': this.translate.instant('No') }, { 'id': 3, 'answer': this.translate.instant('Not relevant (no door)') }];

  counterQ1 = [{ 'id': 1, 'answer': this.translate.instant('Yes') }, { 'id': 2, 'answer': this.translate.instant('No') }, { 'id': 3, 'answer': this.translate.instant('Not relevant (no counter)') }];
  counterQ2 = [{ 'id': 1, 'answer': this.translate.instant('Yes') }, { 'id': 2, 'answer': this.translate.instant('No') }, { 'id': 3, 'answer': this.translate.instant('Not relevant') }];


  floorQ1 = [{ 'id': 118, 'answer': this.translate.instant('Yes') }, { 'id': 119, 'answer': this.translate.instant('No') }];
  floorQ2 = [{ 'id': 1, 'answer': this.translate.instant('Stairs') }, { 'id': 2, 'answer': this.translate.instant('Escalator') }, { 'id': 3, 'answer': this.translate.instant('Elevator') }, { 'id': 4, 'answer': this.translate.instant('Ramp/Inclined plane') }, { 'id': 5, 'answer': this.translate.instant('Other') }];
  floorQ3 = [{ 'id': 1, 'answer': this.translate.instant('Yes') }, { 'id': 2, 'answer': this.translate.instant('No') }, { 'id': 3, 'answer': this.translate.instant('Non relevant') }];
  floorQ4 = [{ 'id': 1, 'answer': this.translate.instant('Ground level') }, { 'id': 2, 'answer': this.translate.instant('Escalator') }, { 'id': 3, 'answer': this.translate.instant('Elevator') }, { 'id': 4, 'answer': this.translate.instant('Ramp/Inclined plane') }, { 'id': 5, 'answer': this.translate.instant('Other') }];

  contactQ6 = [{ 'id': 1, 'answer': this.translate.instant('Mr.') }, { 'id': 2, 'answer': this.translate.instant('Ms.') }];

  paymentQ2 = [{ 'id': 1, 'answer': this.translate.instant('Yes - On our website') }, { 'id': 2, 'answer': this.translate.instant('Yes - On other(s) website(s)') }, { 'id': 3, 'answer': this.translate.instant('Yes - On our website and on other one(s)') }, { 'id': 4, 'answer': this.translate.instant('No') }, { 'id': 5, 'answer': this.translate.instant('Non relevant') }, { 'id': 6, 'answer': this.translate.instant(`I don't know/I don't want to disclose`) }];
  paymentQ3 = [{ 'id': 1, 'answer': this.translate.instant('Yes - By ourselves') }, { 'id': 2, 'answer': this.translate.instant('Yes - With one or more service providers') }, { 'id': 3, 'answer': this.translate.instant('Yes - By ourselves and one or more service providers') }, { 'id': 4, 'answer': this.translate.instant('No') }, { 'id': 5, 'answer': this.translate.instant('Non relevant') }, { 'id': 6, 'answer': this.translate.instant(`I don't know/I don't want to disclose`) }];
  paymentQ6 = [{ 'id': 1, 'answer': this.translate.instant('No') }, { 'id': 2, 'answer': this.translate.instant('Non relevant') }, { 'id': 3, 'answer': this.translate.instant(`I don't know/I don't want to disclose`) }];

  historicQ1 = [{ 'id': 1, 'answer': this.translate.instant('No, but it was already in the neighborhood') }, { 'id': 2, 'answer': this.translate.instant('No, it was in an other neighborhood before') }, { 'id': 3, 'answer': this.translate.instant(`I don't know/I don't want to disclose`) }];
  historicQ4 = [{ 'id': 1, 'answer': this.translate.instant('Renter') }, { 'id': 2, 'answer': this.translate.instant('Owner') }, { 'id': 3, 'answer': this.translate.instant(`I don't know/I don't want to disclose`) }];
  historicQ5 = [{ 'id': 164, 'answer': this.translate.instant('Independent') }, { 'id': 165, 'answer': this.translate.instant('Franchise') }, { 'id': 166, 'answer': this.translate.instant('Branchist') }, { 'id': 167, 'answer': this.translate.instant('Voluntary channel') }, { 'id': 168, 'answer': this.translate.instant('Cooperative') }, { 'id': 169, 'answer': this.translate.instant(`I don't know/I don't want to disclose`) }];
  historicQ6 = [{ 'id': 170, 'answer': this.translate.instant('Yes') }, { 'id': 171, 'answer': this.translate.instant('No') }, { 'id': 172, 'answer': this.translate.instant(`I don't know/I don't want to disclose`) }];

  chainNames = [{ 'answer': this.translate.instant('Select') },
  { 'answer': this.translate.instant('Oxfam - Magasin du monde') },
  { 'answer': this.translate.instant('Carrefour Express') },
  { 'answer': this.translate.instant('Louis Delhaize') },
  { 'answer': this.translate.instant('Louis Delhaize Mini') },
  { 'answer': this.translate.instant('Mini market') },
  { 'answer': this.translate.instant(`Origin'O`) },
  { 'answer': this.translate.instant('Proxy Delhaize') },
  { 'answer': this.translate.instant(`Shop'n go Delhaize`) },
  { 'answer': this.translate.instant('AD Delhaize') },
  { 'answer': this.translate.instant('Aldi') },
  { 'answer': this.translate.instant('Alvo') },
  { 'answer': this.translate.instant(`Bio C'Bon`) },
  { 'answer': this.translate.instant('Bio-Planet') },
  { 'answer': this.translate.instant('Carrefour Market') },
  { 'answer': this.translate.instant('Colruyt') },
  { 'answer': this.translate.instant('Delhaize') },
  { 'answer': this.translate.instant('Delitraiteur') },
  { 'answer': this.translate.instant('Lidl') },
  { 'answer': this.translate.instant('Match') },
  { 'answer': this.translate.instant('Okay') },
  { 'answer': this.translate.instant('Sequoia') },
  { 'answer': this.translate.instant('Smatch') },
  { 'answer': this.translate.instant('Carrefour') },
  { 'answer': this.translate.instant('Cora') },
  { 'answer': this.translate.instant('Picard') },
  { 'answer': this.translate.instant('White Night') },
  { 'answer': this.translate.instant('Body Sano') },
  { 'answer': this.translate.instant('Oil & Vinegar') },
  { 'answer': this.translate.instant('Upignac') },
  { 'answer': this.translate.instant('Au Croquant') },
  { 'answer': this.translate.instant('Les délices de mon moulin') },
  { 'answer': this.translate.instant('Paul') },
  { 'answer': this.translate.instant('Les Tartes de Françoise') },
  { 'answer': this.translate.instant(`Jack O'Shea`) },
  { 'answer': this.translate.instant('Fonteyne The Kitchen') },
  { 'answer': this.translate.instant('Corné Port Royal') },
  { 'answer': this.translate.instant('Darcis') },
  { 'answer': this.translate.instant('Galler') },
  { 'answer': this.translate.instant('Godiva') },
  { 'answer': this.translate.instant('Leonidas') },
  { 'answer': this.translate.instant('Mary') },
  { 'answer': this.translate.instant('Neuhaus') },
  { 'answer': this.translate.instant('Pierre Marcolini') },
  { 'answer': this.translate.instant('Valentino') },
  { 'answer': this.translate.instant('La Belgique Gourmande') },
  { 'answer': this.translate.instant('Maison Dandoy') },
  { 'answer': this.translate.instant('Sucx') },
  { 'answer': this.translate.instant('Le Palais des Thés') },
  { 'answer': this.translate.instant('Bibo vino') },
  { 'answer': this.translate.instant('Comptoir des Vins') },
  { 'answer': this.translate.instant('Les domaines qui montent') },
  { 'answer': this.translate.instant('Nicolas') },
  { 'answer': this.translate.instant('Night And Day') },
  { 'answer': this.translate.instant('Press Shop') },
  { 'answer': this.translate.instant('Relay') },
  { 'answer': this.translate.instant('Davidoff') },
  { 'answer': this.translate.instant('Alter Smoke') },
  { 'answer': this.translate.instant('La Vapotheque') },
  { 'answer': this.translate.instant('New Smoke Sensation') },
  { 'answer': this.translate.instant('Familia') },
  { 'answer': this.translate.instant('Lloyd Pharma') },
  { 'answer': this.translate.instant('Multipharma') },
  { 'answer': this.translate.instant('Santalis') },
  { 'answer': this.translate.instant('1001 Pattes') },
  { 'answer': this.translate.instant('7 For all mankind') },
  { 'answer': this.translate.instant('A.P.C.') },
  { 'answer': this.translate.instant('America today') },
  { 'answer': this.translate.instant('Bellerose') },
  { 'answer': this.translate.instant('C&A') },
  { 'answer': this.translate.instant('Calvin Klein Jeans') },
  { 'answer': this.translate.instant('Chanel') },
  { 'answer': this.translate.instant('Cool Cat') },
  { 'answer': this.translate.instant('COS') },
  { 'answer': this.translate.instant('Cyrillus') },
  { 'answer': this.translate.instant('Damart') },
  { 'answer': this.translate.instant('Desigual') },
  { 'answer': this.translate.instant('Diesel') },
  { 'answer': this.translate.instant('Dior') },
  { 'answer': this.translate.instant('Emporio Armani') },
  { 'answer': this.translate.instant('Episode') },
  { 'answer': this.translate.instant('Eric Bompard') },
  { 'answer': this.translate.instant('Esprit') },
  { 'answer': this.translate.instant('Essentiel') },
  { 'answer': this.translate.instant('Galeria Inno') },
  { 'answer': this.translate.instant('Gant') },
  { 'answer': this.translate.instant('Giorgio Armani') },
  { 'answer': this.translate.instant('G-Star Raw') },
  { 'answer': this.translate.instant('Gucci') },
  { 'answer': this.translate.instant('Guess') },
  { 'answer': this.translate.instant('H&M') },
  { 'answer': this.translate.instant('Hermès') },
  { 'answer': this.translate.instant('Hilfiger Denim') },
  { 'answer': this.translate.instant('Ikks') },
  { 'answer': this.translate.instant('JBC') },
  { 'answer': this.translate.instant('Jipex') },
  { 'answer': this.translate.instant('Karl Lagerfeld') },
  { 'answer': this.translate.instant('Kenzo') },
  { 'answer': this.translate.instant('Kiabi') },
  { 'answer': this.translate.instant('Lacoste') },
  { 'answer': this.translate.instant('Le Temps des Cerises') },
  { 'answer': this.translate.instant('Les Ateliers de la Maille') },
  { 'answer': this.translate.instant('Les Petits Riens') },
  { 'answer': this.translate.instant(`Levi's`) },
  { 'answer': this.translate.instant('M&S Mode') },
  { 'answer': this.translate.instant(`Marc O'polo`) },
  { 'answer': this.translate.instant('Massimo Dutti') },
  { 'answer': this.translate.instant('Mayerline') },
  { 'answer': this.translate.instant('Mexx') },
  { 'answer': this.translate.instant('Morgan') },
  { 'answer': this.translate.instant('Oxfam') },
  { 'answer': this.translate.instant('Oxfam Solidarité') },
  { 'answer': this.translate.instant('Oxfam Vintage') },
  { 'answer': this.translate.instant('Pimkie') },
  { 'answer': this.translate.instant('Poker Jeans Store') },
  { 'answer': this.translate.instant('Primark') },
  { 'answer': this.translate.instant('Promod') },
  { 'answer': this.translate.instant('Pull & Bear') },
  { 'answer': this.translate.instant('Ralph Lauren') },
  { 'answer': this.translate.instant('Replay') },
  { 'answer': this.translate.instant('River Woods') },
  { 'answer': this.translate.instant('Sandro') },
  { 'answer': this.translate.instant('Sonia Rykiel') },
  { 'answer': this.translate.instant('Springfield') },
  { 'answer': this.translate.instant('Superdry') },
  { 'answer': this.translate.instant('Terre Bleue') },
  { 'answer': this.translate.instant('Think twice') },
  { 'answer': this.translate.instant('Tiffanys') },
  { 'answer': this.translate.instant('Timberland') },
  { 'answer': this.translate.instant(`Tod's`) },
  { 'answer': this.translate.instant('Tommy Hilfiger') },
  { 'answer': this.translate.instant('United Colors of Benetton') },
  { 'answer': this.translate.instant('UNO de 50') },
  { 'answer': this.translate.instant('Urban Outfitters') },
  { 'answer': this.translate.instant('Versace') },
  { 'answer': this.translate.instant('WE') },
  { 'answer': this.translate.instant('Wibra') },
  { 'answer': this.translate.instant('Zadig & Voltaire') },
  { 'answer': this.translate.instant('Zara') },
  { 'answer': this.translate.instant('Zeeman') },
  { 'answer': this.translate.instant('1001 Pattes men') },
  { 'answer': this.translate.instant('Abercrombie and Fitch') },
  { 'answer': this.translate.instant('Brice') },
  { 'answer': this.translate.instant('Butch Tailors') },
  { 'answer': this.translate.instant('Celio') },
  { 'answer': this.translate.instant('Celio club') },
  { 'answer': this.translate.instant('Cricket & Co') },
  { 'answer': this.translate.instant('David Mayer Naman') },
  { 'answer': this.translate.instant('Dod Hommes') },
  { 'answer': this.translate.instant('Hugo Boss') },
  { 'answer': this.translate.instant('Ikks Men') },
  { 'answer': this.translate.instant('Jules') },
  { 'answer': this.translate.instant('Oxford Store') },
  { 'answer': this.translate.instant('Pellini') },
  { 'answer': this.translate.instant('Scabal') },
  { 'answer': this.translate.instant('Scotch & Soda') },
  { 'answer': this.translate.instant(`Steed and Barney's`) },
  { 'answer': this.translate.instant('Suitsupply') },
  { 'answer': this.translate.instant('The Kooples') },
  { 'answer': this.translate.instant('1001 Pattes Ladies') },
  { 'answer': this.translate.instant('American vintage') },
  { 'answer': this.translate.instant('Apostrophe') },
  { 'answer': this.translate.instant('Armand Thiery Femmes') },
  { 'answer': this.translate.instant('Ba & Sh') },
  { 'answer': this.translate.instant('BCBG Maxazria') },
  { 'answer': this.translate.instant('Bershka') },
  { 'answer': this.translate.instant('Camaïeu') },
  { 'answer': this.translate.instant('Caroline biss') },
  { 'answer': this.translate.instant('Caroll') },
  { 'answer': this.translate.instant('Cassis') },
  { 'answer': this.translate.instant('Cassis-Paprika') },
  { 'answer': this.translate.instant('Claudie Pierlot') },
  { 'answer': this.translate.instant('Comptoir des Cotonniers') },
  { 'answer': this.translate.instant('Diagonal') },
  { 'answer': this.translate.instant('Dod Femme') },
  { 'answer': this.translate.instant('Gerard Darel') },
  { 'answer': this.translate.instant('Ikks Women') },
  { 'answer': this.translate.instant('Jeff') },
  { 'answer': this.translate.instant(`Jus d'Orange`) },
  { 'answer': this.translate.instant('Karen Millen') },
  { 'answer': this.translate.instant('Les Bourgeoises') },
  { 'answer': this.translate.instant('Liu Jo') },
  { 'answer': this.translate.instant('Lola & Liza') },
  { 'answer': this.translate.instant('Maje') },
  { 'answer': this.translate.instant('Mango') },
  { 'answer': this.translate.instant('Marina Rinaldi') },
  { 'answer': this.translate.instant('Max & Co') },
  { 'answer': this.translate.instant('Max Mara') },
  { 'answer': this.translate.instant('Melvin') },
  { 'answer': this.translate.instant('Mer du Nord') },
  { 'answer': this.translate.instant('Michael Kors') },
  { 'answer': this.translate.instant('Naf Naf') },
  { 'answer': this.translate.instant('Naracamicie') },
  { 'answer': this.translate.instant('Natan') },
  { 'answer': this.translate.instant('New Look') },
  { 'answer': this.translate.instant('One step') },
  { 'answer': this.translate.instant('Paprika') },
  { 'answer': this.translate.instant('Patrizia Pepe') },
  { 'answer': this.translate.instant('Pinko') },
  { 'answer': this.translate.instant('Rue Blanche') },
  { 'answer': this.translate.instant('Sarah Pacini') },
  { 'answer': this.translate.instant('Street One') },
  { 'answer': this.translate.instant('Tara Jarmon') },
  { 'answer': this.translate.instant('Toscane') },
  { 'answer': this.translate.instant('Twin-Set') },
  { 'answer': this.translate.instant('Un Jour Ailleurs') },
  { 'answer': this.translate.instant('Un-Deux-Trois') },
  { 'answer': this.translate.instant('Weill') },
  { 'answer': this.translate.instant('Xandres') },
  { 'answer': this.translate.instant('Bonpoint') },
  { 'answer': this.translate.instant('C&A Kids') },
  { 'answer': this.translate.instant('Catimini') },
  { 'answer': this.translate.instant('Dod Junior') },
  { 'answer': this.translate.instant('Dod junior & Woman') },
  { 'answer': this.translate.instant('Du pareil au même') },
  { 'answer': this.translate.instant('Ikks Junior') },
  { 'answer': this.translate.instant('Jacadi') },
  { 'answer': this.translate.instant('La Compagnie des Petits') },
  { 'answer': this.translate.instant('Obaibi') },
  { 'answer': this.translate.instant('Okaïdi') },
  { 'answer': this.translate.instant('Orchestra') },
  { 'answer': this.translate.instant('Oxfam Kids') },
  { 'answer': this.translate.instant('Petit bateau') },
  { 'answer': this.translate.instant('Sergent Major') },
  { 'answer': this.translate.instant(`Tape à l'Oeil`) },
  { 'answer': this.translate.instant('Z') },
  { 'answer': this.translate.instant('Calzedonia') },
  { 'answer': this.translate.instant('Dim') },
  { 'answer': this.translate.instant('Eres') },
  { 'answer': this.translate.instant('Etam') },
  { 'answer': this.translate.instant('Etam Lingerie') },
  { 'answer': this.translate.instant('Hunkemöller') },
  { 'answer': this.translate.instant('Intimissimi') },
  { 'answer': this.translate.instant('Kiwi St Tropez') },
  { 'answer': this.translate.instant('Princesse Tam Tam') },
  { 'answer': this.translate.instant('Rouge Gorge') },
  { 'answer': this.translate.instant('Triumph') },
  { 'answer': this.translate.instant('Undiz') },
  { 'answer': this.translate.instant('Vilebrequin') },
  { 'answer': this.translate.instant('Wolford') },
  { 'answer': this.translate.instant(`Women'secret`) },
  { 'answer': this.translate.instant('The French Tailor') },
  { 'answer': this.translate.instant('Harry Wilson') },
  { 'answer': this.translate.instant('Baby kid') },
  { 'answer': this.translate.instant(`Noukie's`) },
  { 'answer': this.translate.instant('Théophile & Patachou') },
  { 'answer': this.translate.instant('Aigle') },
  { 'answer': this.translate.instant('Ambiorix') },
  { 'answer': this.translate.instant('Berghen') },
  { 'answer': this.translate.instant('Brantano') },
  { 'answer': this.translate.instant('Camper') },
  { 'answer': this.translate.instant('Crocs') },
  { 'answer': this.translate.instant('Eram') },
  { 'answer': this.translate.instant('Geox') },
  { 'answer': this.translate.instant('Hush Puppies') },
  { 'answer': this.translate.instant('J.M. Weston') },
  { 'answer': this.translate.instant('Jumex') },
  { 'answer': this.translate.instant('Ken') },
  { 'answer': this.translate.instant('Maniet') },
  { 'answer': this.translate.instant('Mano') },
  { 'answer': this.translate.instant('Mephisto') },
  { 'answer': this.translate.instant('Pronti') },
  { 'answer': this.translate.instant(`Sac d'Anvers`) },
  { 'answer': this.translate.instant('Sacha') },
  { 'answer': this.translate.instant('Salamander') },
  { 'answer': this.translate.instant('Scapa') },
  { 'answer': this.translate.instant('Shoe Discount') },
  { 'answer': this.translate.instant('Take-Off') },
  { 'answer': this.translate.instant('Tamaris') },
  { 'answer': this.translate.instant('Vans') },
  { 'answer': this.translate.instant('ZAZ') },
  { 'answer': this.translate.instant('Avance') },
  { 'answer': this.translate.instant('Be original') },
  { 'answer': this.translate.instant('Cecil') },
  { 'answer': this.translate.instant('Muller') },
  { 'answer': this.translate.instant('Torfs') },
  { 'answer': this.translate.instant('Maniet Junior') },
  { 'answer': this.translate.instant('Delvaux') },
  { 'answer': this.translate.instant('Furla') },
  { 'answer': this.translate.instant('Hästens') },
  { 'answer': this.translate.instant('Kipling') },
  { 'answer': this.translate.instant('Lancel') },
  { 'answer': this.translate.instant('Le Tanneur') },
  { 'answer': this.translate.instant('Longchamp') },
  { 'answer': this.translate.instant('Louis Vuitton') },
  { 'answer': this.translate.instant('O Bag') },
  { 'answer': this.translate.instant('Bijou Brigitte') },
  { 'answer': this.translate.instant('Burma') },
  { 'answer': this.translate.instant('Dinh Van') },
  { 'answer': this.translate.instant(`Histoire d'or`) },
  { 'answer': this.translate.instant('Ice Watch') },
  { 'answer': this.translate.instant('Montblanc') },
  { 'answer': this.translate.instant('Montres Services') },
  { 'answer': this.translate.instant('Pandora') },
  { 'answer': this.translate.instant('Swarovski') },
  { 'answer': this.translate.instant('Swatch') },
  { 'answer': this.translate.instant('Tiffany & Co') },
  { 'answer': this.translate.instant('Twice As Nice') },
  { 'answer': this.translate.instant('Venizi') },
  { 'answer': this.translate.instant(`Claire's`) },
  { 'answer': this.translate.instant('I am') },
  { 'answer': this.translate.instant('Six') },
  { 'answer': this.translate.instant('Noa Noa') },
  { 'answer': this.translate.instant('iu') },
  { 'answer': this.translate.instant(`L'occitane en Provence`) },
  { 'answer': this.translate.instant('Lush') },
  { 'answer': this.translate.instant('Mac') },
  { 'answer': this.translate.instant('Rituals') },
  { 'answer': this.translate.instant('The Body Shop') },
  { 'answer': this.translate.instant('Yves Rocher') },
  { 'answer': this.translate.instant('Annick Goutal') },
  { 'answer': this.translate.instant('Cosmeticary') },
  { 'answer': this.translate.instant('Cosmeticary - Bobbi Brown') },
  { 'answer': this.translate.instant('Di') },
  { 'answer': this.translate.instant('Flormar') },
  { 'answer': this.translate.instant('Ici Paris XL') },
  { 'answer': this.translate.instant('Instant Beauté') },
  { 'answer': this.translate.instant(`Kiehl's`) },
  { 'answer': this.translate.instant('Kruidvat') },
  { 'answer': this.translate.instant('Planet Parfum') },
  { 'answer': this.translate.instant('Réserve Naturelle') },
  { 'answer': this.translate.instant('Medi-Market') },
  { 'answer': this.translate.instant('Dame Nature') },
  { 'answer': this.translate.instant('Natur House') },
  { 'answer': this.translate.instant('Nutripharm') },
  { 'answer': this.translate.instant('Hairdis') },
  { 'answer': this.translate.instant('Pro Duo') },
  { 'answer': this.translate.instant('Alain Afflelou') },
  { 'answer': this.translate.instant('Grand Optical') },
  { 'answer': this.translate.instant('Hans Anders') },
  { 'answer': this.translate.instant('Krys') },
  { 'answer': this.translate.instant('Optical Center') },
  { 'answer': this.translate.instant('Pearle') },
  { 'answer': this.translate.instant('Amplifon') },
  { 'answer': this.translate.instant('Audicare.be') },
  { 'answer': this.translate.instant('Audio Nova') },
  { 'answer': this.translate.instant('Lapperre') },
  { 'answer': this.translate.instant('Veranneman') },
  { 'answer': this.translate.instant('Alphamed') },
  { 'answer': this.translate.instant('Cash Converters') },
  { 'answer': this.translate.instant('Club') },
  { 'answer': this.translate.instant('Fnac') },
  { 'answer': this.translate.instant('Belgique Loisirs') },
  { 'answer': this.translate.instant('Bibliopolis') },
  { 'answer': this.translate.instant('Nature & Découvertes') },
  { 'answer': this.translate.instant('Oxfam Bookshop') },
  { 'answer': this.translate.instant('Standaard Boekhandel') },
  { 'answer': this.translate.instant('Slumberland') },
  { 'answer': this.translate.instant('Smartoys') },
  { 'answer': this.translate.instant('Apple Store') },
  { 'answer': this.translate.instant('Samsung') },
  { 'answer': this.translate.instant('Portrait Studios') },
  { 'answer': this.translate.instant('Selexion Clix') },
  { 'answer': this.translate.instant('Easy-M') },
  { 'answer': this.translate.instant('Mister Genius') },
  { 'answer': this.translate.instant('Oxfam Informatique') },
  { 'answer': this.translate.instant('Prink') },
  { 'answer': this.translate.instant('Ava') },
  { 'answer': this.translate.instant('De Banier') },
  { 'answer': this.translate.instant('Schleiper') },
  { 'answer': this.translate.instant('Kitencre') },
  { 'answer': this.translate.instant('Veritas') },
  { 'answer': this.translate.instant('Key Music') },
  { 'answer': this.translate.instant('Decathlon') },
  { 'answer': this.translate.instant('Disport') },
  { 'answer': this.translate.instant('SportsDirect.com') },
  { 'answer': this.translate.instant('Foot Locker') },
  { 'answer': this.translate.instant('Nike Store') },
  { 'answer': this.translate.instant('AS Adventure') },
  { 'answer': this.translate.instant('Jogging Plus') },
  { 'answer': this.translate.instant('Repetto') },
  { 'answer': this.translate.instant('Tom&Co') },
  { 'answer': this.translate.instant('Bart Smit') },
  { 'answer': this.translate.instant('Broze') },
  { 'answer': this.translate.instant('Eurekakids') },
  { 'answer': this.translate.instant('Fox & Cie') },
  { 'answer': this.translate.instant('Intertoys') },
  { 'answer': this.translate.instant('La Grande Récré') },
  { 'answer': this.translate.instant('Maxi Toys') },
  { 'answer': this.translate.instant('Games WorkShop') },
  { 'answer': this.translate.instant('1€ Shop') },
  { 'answer': this.translate.instant('Flying Tiger') },
  { 'answer': this.translate.instant('H&M Home') },
  { 'answer': this.translate.instant('Zara Home') },
  { 'answer': this.translate.instant('Zig Zag') },
  { 'answer': this.translate.instant('Yellow Korner') },
  { 'answer': this.translate.instant('Monceau Fleurs') },
  { 'answer': this.translate.instant('Action') },
  { 'answer': this.translate.instant('Blokker') },
  { 'answer': this.translate.instant('Casa') },
  { 'answer': this.translate.instant('Dille & Kamille') },
  { 'answer': this.translate.instant('Hema') },
  { 'answer': this.translate.instant('Maisons du Monde') },
  { 'answer': this.translate.instant('Trafic') },
  { 'answer': this.translate.instant('Les secrets du Chef') },
  { 'answer': this.translate.instant('Tupperware') },
  { 'answer': this.translate.instant('Villeroy & Boch') },
  { 'answer': this.translate.instant('Hayoit') },
  { 'answer': this.translate.instant('Madura') },
  { 'answer': this.translate.instant('Yves Delorme') },
  { 'answer': this.translate.instant('Ikea') },
  { 'answer': this.translate.instant('Troc') },
  { 'answer': this.translate.instant('BoConcept') },
  { 'answer': this.translate.instant('Camber') },
  { 'answer': this.translate.instant('Cassina') },
  { 'answer': this.translate.instant(`Chateau d'Ax`) },
  { 'answer': this.translate.instant('Kvik') },
  { 'answer': this.translate.instant('Mobalpa') },
  { 'answer': this.translate.instant('Retif') },
  { 'answer': this.translate.instant('Tempo Doulou') },
  { 'answer': this.translate.instant('Buro Market City') },
  { 'answer': this.translate.instant('Eggo') },
  { 'answer': this.translate.instant('Ixina') },
  { 'answer': this.translate.instant('Facq') },
  { 'answer': this.translate.instant('Van Marcke') },
  { 'answer': this.translate.instant('Le Roi du Matelas') },
  { 'answer': this.translate.instant('Literie prestige') },
  { 'answer': this.translate.instant(`Plum'art`) },
  { 'answer': this.translate.instant('Heytens') },
  { 'answer': this.translate.instant('Mondial Textiles') },
  { 'answer': this.translate.instant('Brico') },
  { 'answer': this.translate.instant('Brico Plan-It') },
  { 'answer': this.translate.instant('Créa Home') },
  { 'answer': this.translate.instant('Brico City') },
  { 'answer': this.translate.instant('Gamma') },
  { 'answer': this.translate.instant('Handyman') },
  { 'answer': this.translate.instant('Carrelage du Marais') },
  { 'answer': this.translate.instant('Sigma Service Center') },
  { 'answer': this.translate.instant('Belisol') },
  { 'answer': this.translate.instant('Déco Reno') },
  { 'answer': this.translate.instant('Axess') },
  { 'answer': this.translate.instant('Belwatech') },
  { 'answer': this.translate.instant('Chrono Stock') },
  { 'answer': this.translate.instant('Electro Dépot') },
  { 'answer': this.translate.instant('Electro-Stock') },
  { 'answer': this.translate.instant('Krëfel') },
  { 'answer': this.translate.instant('Media Markt') },
  { 'answer': this.translate.instant('Nespresso') },
  { 'answer': this.translate.instant('Vanden Borre') },
  { 'answer': this.translate.instant('Bose') },
  { 'answer': this.translate.instant('Cebeo Light Studio') },
  { 'answer': this.translate.instant('BMW') },
  { 'answer': this.translate.instant('Citroën') },
  { 'answer': this.translate.instant(`D'Ieteren Car Centers`) },
  { 'answer': this.translate.instant('Fiat') },
  { 'answer': this.translate.instant('KIA Motors') },
  { 'answer': this.translate.instant('McLaren') },
  { 'answer': this.translate.instant('Mercedes-Benz') },
  { 'answer': this.translate.instant('Nearly New Car') },
  { 'answer': this.translate.instant('Peugeot') },
  { 'answer': this.translate.instant('Skoda') },
  { 'answer': this.translate.instant('Tesla') },
  { 'answer': this.translate.instant('Toyota') },
  { 'answer': this.translate.instant('CyCLO') },
  { 'answer': this.translate.instant('Avia') },
  { 'answer': this.translate.instant('Dats 24') },
  { 'answer': this.translate.instant('Esso') },
  { 'answer': this.translate.instant('Esso express') },
  { 'answer': this.translate.instant('Lukoil') },
  { 'answer': this.translate.instant('Octa +') },
  { 'answer': this.translate.instant('Q8') },
  { 'answer': this.translate.instant('Q8 easy') },
  { 'answer': this.translate.instant('Shell') },
  { 'answer': this.translate.instant('Shell Express') },
  { 'answer': this.translate.instant('Texaco') },
  { 'answer': this.translate.instant('Total') },
  { 'answer': this.translate.instant('API') },
  { 'answer': this.translate.instant('Auto 5') },
  { 'answer': this.translate.instant('Coyote') },
  { 'answer': this.translate.instant('Starbucks Coffee') },
  { 'answer': this.translate.instant('8 Tea5') },
  { 'answer': this.translate.instant('Kusmi Tea') },
  { 'answer': this.translate.instant('Belgaufra') },
  { 'answer': this.translate.instant('Australian') },
  { 'answer': this.translate.instant('Capoue') },
  { 'answer': this.translate.instant('Häagen-Dazs') },
  { 'answer': this.translate.instant('Delirium') },
  { 'answer': this.translate.instant('Bagelstein') },
  { 'answer': this.translate.instant('Deliway') },
  { 'answer': this.translate.instant('Panos') },
  { 'answer': this.translate.instant('Point Chaud') },
  { 'answer': this.translate.instant(`Pulp'`) },
  { 'answer': this.translate.instant('Boco') },
  { 'answer': this.translate.instant('Exki') },
  { 'answer': this.translate.instant('Guapa') },
  { 'answer': this.translate.instant('Le Pain quotidien') },
  { 'answer': this.translate.instant('The Foodmaker') },
  { 'answer': this.translate.instant(`Domino's pizza`) },
  { 'answer': this.translate.instant('Mamma Roma') },
  { 'answer': this.translate.instant('Coté Sushi') },
  { 'answer': this.translate.instant('Sushi Shop') },
  { 'answer': this.translate.instant('Hector Chicken') },
  { 'answer': this.translate.instant(`Mc Donald's`) },
  { 'answer': this.translate.instant('Pizza Hut') },
  { 'answer': this.translate.instant('Quick') },
  { 'answer': this.translate.instant('Subway') },
  { 'answer': this.translate.instant('Chez Léon') },
  { 'answer': this.translate.instant('Ellis') },
  { 'answer': this.translate.instant('Lunch Garden') },
  { 'answer': this.translate.instant('Bia Mara') },
  { 'answer': this.translate.instant(`Chi-Chi's`) },
  { 'answer': this.translate.instant('Hard rock café') },
  { 'answer': this.translate.instant('B-Aparthotels') },
  { 'answer': this.translate.instant('Hotel Eurostars') },
  { 'answer': this.translate.instant('Hôtel Windsor') },
  { 'answer': this.translate.instant('Ibis') },
  { 'answer': this.translate.instant('Mercure Hôtel') },
  { 'answer': this.translate.instant('NH Hotel') },
  { 'answer': this.translate.instant('Novotel') },
  { 'answer': this.translate.instant('Thon Hotel') },
  { 'answer': this.translate.instant('Thon Residence') },
  { 'answer': this.translate.instant('Best western') },
  { 'answer': this.translate.instant('Holiday Inn') },
  { 'answer': this.translate.instant('Hôtel Bedford') },
  { 'answer': this.translate.instant('9hotel') },
  { 'answer': this.translate.instant('Crowne Plaza') },
  { 'answer': this.translate.instant('Sofitel') },
  { 'answer': this.translate.instant('Kinepolis') },
  { 'answer': this.translate.instant('UGC') },
  { 'answer': this.translate.instant('Basic-Fit') },
  { 'answer': this.translate.instant('i-fitness') },
  { 'answer': this.translate.instant('Jims Fitness') },
  { 'answer': this.translate.instant('Life style fitness') },
  { 'answer': this.translate.instant('The Little Gym') },
  { 'answer': this.translate.instant('Golden Palace') },
  { 'answer': this.translate.instant('Napoléon Games') },
  { 'answer': this.translate.instant('Bet Center') },
  { 'answer': this.translate.instant('Efor Bet') },
  { 'answer': this.translate.instant('Ladbrokes') },
  { 'answer': this.translate.instant('Score') },
  { 'answer': this.translate.instant('Stanleybet') },
  { 'answer': this.translate.instant('Argenta') },
  { 'answer': this.translate.instant('Attijariwafa Bank') },
  { 'answer': this.translate.instant('Axa') },
  { 'answer': this.translate.instant('Banca Monte Paschi Belgio') },
  { 'answer': this.translate.instant('Bank J.Van Breda') },
  { 'answer': this.translate.instant('BBVA Banque') },
  { 'answer': this.translate.instant('Belfius') },
  { 'answer': this.translate.instant('Beobank') },
  { 'answer': this.translate.instant('BKCP Bank') },
  { 'answer': this.translate.instant('BNP Paribas Fortis') },
  { 'answer': this.translate.instant(`Caisse d'Epargne`) },
  { 'answer': this.translate.instant('CBC') },
  { 'answer': this.translate.instant('Credit 2000') },
  { 'answer': this.translate.instant('Crefibel') },
  { 'answer': this.translate.instant('Crélan Assurance') },
  { 'answer': this.translate.instant('Deutsche Bank') },
  { 'answer': this.translate.instant('Eurofinances') },
  { 'answer': this.translate.instant('Europabank') },
  { 'answer': this.translate.instant('Fintro') },
  { 'answer': this.translate.instant('ING') },
  { 'answer': this.translate.instant('KBC') },
  { 'answer': this.translate.instant('Nagelmackers') },
  { 'answer': this.translate.instant('Record') },
  { 'answer': this.translate.instant('AG Insurance') },
  { 'answer': this.translate.instant('Allianz') },
  { 'answer': this.translate.instant('Ethias') },
  { 'answer': this.translate.instant('Fédérale Assurance') },
  { 'answer': this.translate.instant('Generali') },
  { 'answer': this.translate.instant('P&V Assurances') },
  { 'answer': this.translate.instant('Partena') },
  { 'answer': this.translate.instant('Partners') },
  { 'answer': this.translate.instant('Touring') },
  { 'answer': this.translate.instant('Vivium') },
  { 'answer': this.translate.instant('Atena Money Transfert') },
  { 'answer': this.translate.instant('BT Money Transfers') },
  { 'answer': this.translate.instant('Moneygram') },
  { 'answer': this.translate.instant('Moneytrans') },
  { 'answer': this.translate.instant('Ria') },
  { 'answer': this.translate.instant('Travelex') },
  { 'answer': this.translate.instant('Western Union') },
  { 'answer': this.translate.instant('CGSLB') },
  { 'answer': this.translate.instant('CSC') },
  { 'answer': this.translate.instant('FGTB') },
  { 'answer': this.translate.instant('Mutualité Chrétienne') },
  { 'answer': this.translate.instant('Mutualité Libérale') },
  { 'answer': this.translate.instant('Mutualité libérale du Brabant') },
  { 'answer': this.translate.instant('Mutualité Socialiste') },
  { 'answer': this.translate.instant('Mutualité Socialiste du Brabant') },
  { 'answer': this.translate.instant('Partena Mut') },
  { 'answer': this.translate.instant('Symbio') },
  { 'answer': this.translate.instant('bpost') },
  { 'answer': this.translate.instant('Accent Jobs') },
  { 'answer': this.translate.instant('Adecco') },
  { 'answer': this.translate.instant('Adequat') },
  { 'answer': this.translate.instant('Asap') },
  { 'answer': this.translate.instant('Daoust Intérim') },
  { 'answer': this.translate.instant('Job match') },
  { 'answer': this.translate.instant('Manpower') },
  { 'answer': this.translate.instant('Mise en Place') },
  { 'answer': this.translate.instant('Randstad') },
  { 'answer': this.translate.instant('Start People') },
  { 'answer': this.translate.instant('T Interim') },
  { 'answer': this.translate.instant('Talentus') },
  { 'answer': this.translate.instant('Tempo Team') },
  { 'answer': this.translate.instant('Unique') },
  { 'answer': this.translate.instant('Vivaldis Interim') },
  { 'answer': this.translate.instant('Alpha Services') },
  { 'answer': this.translate.instant('Clixxs Home & Care Services') },
  { 'answer': this.translate.instant('Domestic services') },
  { 'answer': this.translate.instant('Eko services') },
  { 'answer': this.translate.instant('IL & C') },
  { 'answer': this.translate.instant('Maxi Clean') },
  { 'answer': this.translate.instant('Plus Home Services') },
  { 'answer': this.translate.instant('Barnes') },
  { 'answer': this.translate.instant('Ben Kouider Group') },
  { 'answer': this.translate.instant('Cap Sud') },
  { 'answer': this.translate.instant('Century 21') },
  { 'answer': this.translate.instant('Engels & Völkers') },
  { 'answer': this.translate.instant('Era') },
  { 'answer': this.translate.instant('Immotheker') },
  { 'answer': this.translate.instant(`Sotheby's International Realty`) },
  { 'answer': this.translate.instant('Air Wash') },
  { 'answer': this.translate.instant('All Automatic Wash') },
  { 'answer': this.translate.instant('Ipsomat') },
  { 'answer': this.translate.instant('Primus wash') },
  { 'answer': this.translate.instant('Quality Wash') },
  { 'answer': this.translate.instant('5 à sec') },
  { 'answer': this.translate.instant('Mister Minit') },
  { 'answer': this.translate.instant('Base Shop') },
  { 'answer': this.translate.instant('Huawei') },
  { 'answer': this.translate.instant('Orange') },
  { 'answer': this.translate.instant('Proximus center') },
  { 'answer': this.translate.instant('SFR') },
  { 'answer': this.translate.instant('Telenet') },
  { 'answer': this.translate.instant('VOO') },
  { 'answer': this.translate.instant('Carglass') },
  { 'answer': this.translate.instant('Midas') },
  { 'answer': this.translate.instant('Renault') },
  { 'answer': this.translate.instant('Speedy') },
  { 'answer': this.translate.instant('Avis') },
  { 'answer': this.translate.instant('Dockx Rental') },
  { 'answer': this.translate.instant('Europcar') },
  { 'answer': this.translate.instant('Hertz') },
  { 'answer': this.translate.instant('Sixt') },
  { 'answer': this.translate.instant('Auto-Ecole Bara') },
  { 'answer': this.translate.instant('Auto-Ecole Européenne') },
  { 'answer': this.translate.instant('Auto-Ecole Henry') },
  { 'answer': this.translate.instant('Multipermis') },
  { 'answer': this.translate.instant('Eurolines') },
  { 'answer': this.translate.instant('Dessange') },
  { 'answer': this.translate.instant('Franck Provost') },
  { 'answer': this.translate.instant('H&L Coiffure') },
  { 'answer': this.translate.instant('Jean-Claude Biguine') },
  { 'answer': this.translate.instant('Jean-Louis David') },
  { 'answer': this.translate.instant('Le Salon Vert') },
  { 'answer': this.translate.instant('Louis Garnier') },
  { 'answer': this.translate.instant('Olivier Dachkin') },
  { 'answer': this.translate.instant('Estheclinic') },
  { 'answer': this.translate.instant('Exotic sun') },
  { 'answer': this.translate.instant('Bongo') },
  { 'answer': this.translate.instant('BT Holidays') },
  { 'answer': this.translate.instant('Club Med') },
  { 'answer': this.translate.instant('Connections') },
  { 'answer': this.translate.instant('Gigatour') },
  { 'answer': this.translate.instant('Neckermann') },
  { 'answer': this.translate.instant('Services Voyages') },
  { 'answer': this.translate.instant('Stopover Travel') },
  { 'answer': this.translate.instant('Thomas Cook') },
  { 'answer': this.translate.instant('Tui') },
  { 'answer': this.translate.instant('TunisAir') },
  { 'answer': this.translate.instant('Espace video') },
  { 'answer': this.translate.instant('Image') },
  { 'answer': this.translate.instant('Pano Boutique') }];

  adTpes = [
    { 'answer': "For renting" },
    { 'answer': "For selling" },
    { 'answer': "For renting and/or selling" },
    { 'answer': "To hand over" },
    { 'answer': "Unknown" }
  ];

  tags = [{ 'id': 1, 'answer': this.translate.instant('ORGANIC') },
  { 'id': 2, 'answer': this.translate.instant('VEGAN') },
  { 'id': 3, 'answer': this.translate.instant('HALLAL') },
  { 'id': 4, 'answer': this.translate.instant('FAIR-TRADE') },
  { 'id': 5, 'answer': this.translate.instant('CIRCULAR ECONOMY') },
  { 'id': 6, 'answer': this.translate.instant('POP-UP') },
  { 'id': 7, 'answer': this.translate.instant('CONCEPT-STORE') },
  { 'id': 8, 'answer': this.translate.instant('SECOND HAND') },
  { 'id': 9, 'answer': this.translate.instant('DISCOUNT') },
  { 'id': 10, 'answer': this.translate.instant('ANTIQUARIAN') },
  { 'id': 11, 'answer': this.translate.instant('ON SITE') },
  { 'id': 12, 'answer': this.translate.instant('TO GO') },
  { 'id': 13, 'answer': this.translate.instant('ATM') },
  { 'id': 14, 'answer': this.translate.instant('SHOW-ROOM') },
  { 'id': 15, 'answer': this.translate.instant('CRAFT') }];

  level1 = [{ 'id': 1, 'answer': this.translate.instant('Day-to-day products') }, { 'id': 2, 'answer': this.translate.instant('Personal care products') }, { 'id': 3, 'answer': this.translate.instant('Leisure') }, { 'id': 4, 'answer': this.translate.instant('Household goods') }, { 'id': 5, 'answer': this.translate.instant('Transport') }, { 'id': 6, 'answer': this.translate.instant('Restauration and accomodation') }, { 'id': 7, 'answer': this.translate.instant('Outings and entertainment') }, { 'id': 8, 'answer': this.translate.instant('Services') }, { 'id': 9, 'answer': this.translate.instant('Empty Unit')}, { 'id': 10, 'answer': this.translate.instant('Empty cell') }];
  level2 = [{ 'id': 1, 'answer': this.translate.instant('General food products'), 'lvl1ID': 1 },
  { 'id': 2, 'answer': this.translate.instant('Speciality foods'), 'lvl1ID': 1 },
  { 'id': 3, 'answer': this.translate.instant('Drinks - Alcoholic beverages'), 'lvl1ID': 1 },
  { 'id': 4, 'answer': this.translate.instant('Non-food products'), 'lvl1ID': 1 },
  { 'id': 5, 'answer': this.translate.instant('Clothing'), 'lvl1ID': 2 },
  { 'id': 6, 'answer': this.translate.instant('Shoes'), 'lvl1ID': 2 },
  { 'id': 7, 'answer': this.translate.instant('Fashion accessories'), 'lvl1ID': 2 },
  { 'id': 8, 'answer': this.translate.instant('Personal care'), 'lvl1ID': 2 },
  { 'id': 9, 'answer': this.translate.instant('Medical items'), 'lvl1ID': 2 },
  { 'id': 10, 'answer': this.translate.instant('Workwear'), 'lvl1ID': 2 },
  { 'id': 11, 'answer': this.translate.instant('Cultural and multimedia leisure'), 'lvl1ID': 3 },
  { 'id': 12, 'answer': this.translate.instant('Creative and artistic hobbies'), 'lvl1ID': 3 },
  { 'id': 13, 'answer': this.translate.instant('Sporting pastimes'), 'lvl1ID': 3 },
  { 'id': 14, 'answer': this.translate.instant('Other leisure'), 'lvl1ID': 3 },
  { 'id': 15, 'answer': this.translate.instant('Decoration'), 'lvl1ID': 4 },
  { 'id': 16, 'answer': this.translate.instant('Homewares'), 'lvl1ID': 4 },
  { 'id': 17, 'answer': this.translate.instant('Furnishings'), 'lvl1ID': 4 },
  { 'id': 18, 'answer': this.translate.instant('DIY materials'), 'lvl1ID': 4 },
  { 'id': 19, 'answer': this.translate.instant('Electrical equipment'), 'lvl1ID': 4 },
  { 'id': 20, 'answer': this.translate.instant('Motor vehicles'), 'lvl1ID': 5 },
  { 'id': 21, 'answer': this.translate.instant('Sustainable transport'), 'lvl1ID': 5 },
  { 'id': 22, 'answer': this.translate.instant('Transport accessories'), 'lvl1ID': 5 },
  { 'id': 23, 'answer': this.translate.instant('Fast food - Sweet'), 'lvl1ID': 6 },
  { 'id': 24, 'answer': this.translate.instant('Fast food - Savoury'), 'lvl1ID': 6 },
  { 'id': 25, 'answer': this.translate.instant('Restaurant - Traditional cuisine'), 'lvl1ID': 6 },
  { 'id': 26, 'answer': this.translate.instant('Restaurant - World cuisine'), 'lvl1ID': 6 },
  { 'id': 27, 'answer': this.translate.instant('Accommodation - Hotel'), 'lvl1ID': 6 },
  { 'id': 28, 'answer': this.translate.instant('Other accommodation'), 'lvl1ID': 6 },
  { 'id': 29, 'answer': this.translate.instant('Nightlife'), 'lvl1ID': 7 },
  { 'id': 30, 'answer': this.translate.instant('Visitor attractions'), 'lvl1ID': 7 },
  { 'id': 31, 'answer': this.translate.instant('Performance & Sports'), 'lvl1ID': 7 },
  { 'id': 32, 'answer': this.translate.instant('Sporting activities'), 'lvl1ID': 7 },
  { 'id': 33, 'answer': this.translate.instant('Health and wellness'), 'lvl1ID': 7 },
  { 'id': 34, 'answer': this.translate.instant('Games of chance and gambling'), 'lvl1ID': 7 },
  { 'id': 35, 'answer': this.translate.instant('Other activities'), 'lvl1ID': 7 },
  { 'id': 36, 'answer': this.translate.instant('Financial and business services'), 'lvl1ID': 8 },
  { 'id': 37, 'answer': this.translate.instant('Personal goods services'), 'lvl1ID': 8 },
  { 'id': 38, 'answer': this.translate.instant('Household goods services'), 'lvl1ID': 8 },
  { 'id': 39, 'answer': this.translate.instant('Transport services'), 'lvl1ID': 8 },
  { 'id': 40, 'answer': this.translate.instant('Wellness services'), 'lvl1ID': 8 },
  { 'id': 41, 'answer': this.translate.instant('Leisure services'), 'lvl1ID': 8 },
  { 'id': 42, 'answer': this.translate.instant('Other services'), 'lvl1ID': 8 },
  { 'id': 43, 'answer': this.translate.instant('Empty Unit'), 'lvl1ID': 9 },
  { 'id': 44, 'answer': this.translate.instant('Empty cell'), 'lvl1ID': 10 }];

  level3 = [{ 'id': 1, 'answer': this.translate.instant('Grocery products'), 'lvl2ID': 1, 'lvl1ID': 1 },
  { 'id': 2, 'answer': this.translate.instant('Convenience store'), 'lvl2ID': 1, 'lvl1ID': 1 },
  { 'id': 3, 'answer': this.translate.instant('Supermarket'), 'lvl2ID': 1, 'lvl1ID': 1 },
  { 'id': 4, 'answer': this.translate.instant('Hypermarket'), 'lvl2ID': 1, 'lvl1ID': 1 },
  { 'id': 5, 'answer': this.translate.instant('Frozen produce'), 'lvl2ID': 1, 'lvl1ID': 1 },
  { 'id': 6, 'answer': this.translate.instant('Late night shop'), 'lvl2ID': 1, 'lvl1ID': 1 },
  { 'id': 7, 'answer': this.translate.instant('Health food'), 'lvl2ID': 1, 'lvl1ID': 1 },
  { 'id': 8, 'answer': this.translate.instant('Gourmet grocery- artisan products'), 'lvl2ID': 1, 'lvl1ID': 1 },
  { 'id': 9, 'answer': this.translate.instant('Grocery specialising in foreign foods'), 'lvl2ID': 1, 'lvl1ID': 1 },
  { 'id': 10, 'answer': this.translate.instant('Bakery'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 11, 'answer': this.translate.instant('Pâtisserie'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 12, 'answer': this.translate.instant('Butcher - Charcuterie'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 13, 'answer': this.translate.instant('Rôtisserie'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 14, 'answer': this.translate.instant('Delicatessen'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 15, 'answer': this.translate.instant('Fruit - Vegetables'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 16, 'answer': this.translate.instant('Dairy Products - Cheese Shop'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 17, 'answer': this.translate.instant('Fishmonger - Seafood'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 18, 'answer': this.translate.instant('Chocolate shop - Pralines'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 19, 'answer': this.translate.instant('Sweets - Confectionary'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 20, 'answer': this.translate.instant('Coffee'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 21, 'answer': this.translate.instant('Tea'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 22, 'answer': this.translate.instant('Spices'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 23, 'answer': this.translate.instant('Grains - Cereals'), 'lvl2ID': 2, 'lvl1ID': 1 },
  { 'id': 24, 'answer': this.translate.instant('Cash and carry drinks - Brewery'), 'lvl2ID': 3, 'lvl1ID': 1 },
  { 'id': 25, 'answer': this.translate.instant('Wines'), 'lvl2ID': 3, 'lvl1ID': 1 },
  { 'id': 26, 'answer': this.translate.instant('Beers'), 'lvl2ID': 3, 'lvl1ID': 1 },
  { 'id': 27, 'answer': this.translate.instant('Other alcoholic beverages (Rum, Whisky, Liqueurs, etc.)'), 'lvl2ID': 3, 'lvl1ID': 1 },
  { 'id': 28, 'answer': this.translate.instant('Newspapers - Magazines'), 'lvl2ID': 4, 'lvl1ID': 1 },
  { 'id': 29, 'answer': this.translate.instant('Cigarettes'), 'lvl2ID': 4, 'lvl1ID': 1 },
  { 'id': 30, 'answer': this.translate.instant('Cigars - Tobacco'), 'lvl2ID': 4, 'lvl1ID': 1 },
  { 'id': 31, 'answer': this.translate.instant('e-cigarettes'), 'lvl2ID': 4, 'lvl1ID': 1 },
  { 'id': 32, 'answer': this.translate.instant('Pharmacy'), 'lvl2ID': 4, 'lvl1ID': 1 },
  { 'id': 33, 'answer': this.translate.instant('Clothing - General'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 34, 'answer': this.translate.instant('Mens clothing'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 35, 'answer': this.translate.instant('Womens clothing'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 36, 'answer': this.translate.instant('Childrens clothing'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 37, 'answer': this.translate.instant('Babies clothing'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 38, 'answer': this.translate.instant('Jeans - Trousers'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 39, 'answer': this.translate.instant('Swimwear'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 40, 'answer': this.translate.instant('Lingerie - Underwear - Stockings'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 41, 'answer': this.translate.instant('Doeskin - Leather - Coats'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 42, 'answer': this.translate.instant('Fur'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 43, 'answer': this.translate.instant('Tailor - Suits'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 44, 'answer': this.translate.instant('Shirts'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 45, 'answer': this.translate.instant('Ceremonial Robes'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 46, 'answer': this.translate.instant('Future mums'), 'lvl2ID': 5, 'lvl1ID': 2 },
  { 'id': 47, 'answer': this.translate.instant('Shoes - General'), 'lvl2ID': 6, 'lvl1ID': 2 },
  { 'id': 48, 'answer': this.translate.instant('Men’s shoes'), 'lvl2ID': 6, 'lvl1ID': 2 },
  { 'id': 49, 'answer': this.translate.instant('Women’s shoes'), 'lvl2ID': 6, 'lvl1ID': 2 },
  { 'id': 50, 'answer': this.translate.instant('Children’s and babies’ shoes'), 'lvl2ID': 6, 'lvl1ID': 2 },
  { 'id': 51, 'answer': this.translate.instant('Fashion accessories - General'), 'lvl2ID': 7, 'lvl1ID': 2 },
  { 'id': 52, 'answer': this.translate.instant('Leather goods - Bags'), 'lvl2ID': 7, 'lvl1ID': 2 },
  { 'id': 53, 'answer': this.translate.instant('Jewellery shops'), 'lvl2ID': 7, 'lvl1ID': 2 },
  { 'id': 54, 'answer': this.translate.instant('Watches'), 'lvl2ID': 7, 'lvl1ID': 2 },
  { 'id': 55, 'answer': this.translate.instant('Jewellery'), 'lvl2ID': 7, 'lvl1ID': 2 },
  { 'id': 56, 'answer': this.translate.instant('Costume jewellery'), 'lvl2ID': 7, 'lvl1ID': 2 },
  { 'id': 57, 'answer': this.translate.instant('Hats'), 'lvl2ID': 7, 'lvl1ID': 2 },
  { 'id': 58, 'answer': this.translate.instant('Wigs'), 'lvl2ID': 7, 'lvl1ID': 2 },
  { 'id': 59, 'answer': this.translate.instant('Umbrellas - Gloves'), 'lvl2ID': 7, 'lvl1ID': 2 },
  { 'id': 60, 'answer': this.translate.instant('Luggage'), 'lvl2ID': 7, 'lvl1ID': 2 },
  { 'id': 61, 'answer': this.translate.instant('Other accessories'), 'lvl2ID': 7, 'lvl1ID': 2 },
  { 'id': 62, 'answer': this.translate.instant('Personal care - General'), 'lvl2ID': 8, 'lvl1ID': 2 },
  { 'id': 63, 'answer': this.translate.instant('Cosmetics'), 'lvl2ID': 8, 'lvl1ID': 2 },
  { 'id': 64, 'answer': this.translate.instant('Perfumes'), 'lvl2ID': 8, 'lvl1ID': 2 },
  { 'id': 65, 'answer': this.translate.instant('Health and beauty store'), 'lvl2ID': 8, 'lvl1ID': 2 },
  { 'id': 66, 'answer': this.translate.instant('Herbal remedies'), 'lvl2ID': 8, 'lvl1ID': 2 },
  { 'id': 67, 'answer': this.translate.instant('Haircare products'), 'lvl2ID': 8, 'lvl1ID': 2 },
  { 'id': 68, 'answer': this.translate.instant('Optician'), 'lvl2ID': 9, 'lvl1ID': 2 },
  { 'id': 69, 'answer': this.translate.instant('Hearing aids'), 'lvl2ID': 9, 'lvl1ID': 2 },
  { 'id': 70, 'answer': this.translate.instant('Orthopaedic equipment - Bandages - Prosthetic devices'), 'lvl2ID': 9, 'lvl1ID': 2 },
  { 'id': 71, 'answer': this.translate.instant('Workwear'), 'lvl2ID': 10, 'lvl1ID': 2 },
  { 'id': 72, 'answer': this.translate.instant('Cultural and multimedia leisure - General'), 'lvl2ID': 11, 'lvl1ID': 3 },
  { 'id': 73, 'answer': this.translate.instant('Book shop'), 'lvl2ID': 11, 'lvl1ID': 3 },
  { 'id': 74, 'answer': this.translate.instant('Comics'), 'lvl2ID': 11, 'lvl1ID': 3 },
  { 'id': 75, 'answer': this.translate.instant('Films'), 'lvl2ID': 11, 'lvl1ID': 3 },
  { 'id': 76, 'answer': this.translate.instant('Music'), 'lvl2ID': 11, 'lvl1ID': 3 },
  { 'id': 77, 'answer': this.translate.instant('Videogames'), 'lvl2ID': 11, 'lvl1ID': 3 },
  { 'id': 78, 'answer': this.translate.instant('Mobile phones'), 'lvl2ID': 11, 'lvl1ID': 3 },
  { 'id': 79, 'answer': this.translate.instant('Mobile phone accessories'), 'lvl2ID': 11, 'lvl1ID': 3 },
  { 'id': 80, 'answer': this.translate.instant('Photographic equipment'), 'lvl2ID': 11, 'lvl1ID': 3 },
  { 'id': 81, 'answer': this.translate.instant('IT equipment'), 'lvl2ID': 11, 'lvl1ID': 3 },
  { 'id': 82, 'answer': this.translate.instant('Multimedia devices (tablets, etc.)'), 'lvl2ID': 11, 'lvl1ID': 3 },
  { 'id': 83, 'answer': this.translate.instant('Creative and artistic hobbies- General'), 'lvl2ID': 12, 'lvl1ID': 3 },
  { 'id': 84, 'answer': this.translate.instant('Stationer - Office materials and accessories'), 'lvl2ID': 12, 'lvl1ID': 3 },
  { 'id': 85, 'answer': this.translate.instant('Artistic and Creative materials (Do it yourself)'), 'lvl2ID': 12, 'lvl1ID': 3 },
  { 'id': 86, 'answer': this.translate.instant('Card shop'), 'lvl2ID': 12, 'lvl1ID': 3 },
  { 'id': 87, 'answer': this.translate.instant('Haberdashery'), 'lvl2ID': 12, 'lvl1ID': 3 },
  { 'id': 88, 'answer': this.translate.instant('Sewing machines'), 'lvl2ID': 12, 'lvl1ID': 3 },
  { 'id': 89, 'answer': this.translate.instant('Wool'), 'lvl2ID': 12, 'lvl1ID': 3 },
  { 'id': 90, 'answer': this.translate.instant('Dressmaking fabrics'), 'lvl2ID': 12, 'lvl1ID': 3 },
  { 'id': 91, 'answer': this.translate.instant('Musical instruments and accessories'), 'lvl2ID': 12, 'lvl1ID': 3 },
  { 'id': 92, 'answer': this.translate.instant('DJ equipment'), 'lvl2ID': 12, 'lvl1ID': 3 },
  { 'id': 93, 'answer': this.translate.instant('Sports equipment and goods - General'), 'lvl2ID': 13, 'lvl1ID': 3 },
  { 'id': 94, 'answer': this.translate.instant('Vitamins and supplements'), 'lvl2ID': 13, 'lvl1ID': 3 },
  { 'id': 95, 'answer': this.translate.instant('Sportswear'), 'lvl2ID': 13, 'lvl1ID': 3 },
  { 'id': 96, 'answer': this.translate.instant('Hiking - Scouting - Camping'), 'lvl2ID': 13, 'lvl1ID': 3 },
  { 'id': 97, 'answer': this.translate.instant('Running'), 'lvl2ID': 13, 'lvl1ID': 3 },
  { 'id': 98, 'answer': this.translate.instant('Saddlery and horse riding'), 'lvl2ID': 13, 'lvl1ID': 3 },
  { 'id': 99, 'answer': this.translate.instant('Hunting - Firearms'), 'lvl2ID': 13, 'lvl1ID': 3 },
  { 'id': 100, 'answer': this.translate.instant('Fishing equipment'), 'lvl2ID': 13, 'lvl1ID': 3 },
  { 'id': 101, 'answer': this.translate.instant('Diving equipment'), 'lvl2ID': 13, 'lvl1ID': 3 },
  { 'id': 102, 'answer': this.translate.instant('Specialist equipment or goods for another sport'), 'lvl2ID': 13, 'lvl1ID': 3 },
  { 'id': 103, 'answer': this.translate.instant('Pet shop'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 104, 'answer': this.translate.instant('Pet food and accessories'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 105, 'answer': this.translate.instant('Toys'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 106, 'answer': this.translate.instant('Board games'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 107, 'answer': this.translate.instant('Model making'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 108, 'answer': this.translate.instant('Drones'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 109, 'answer': this.translate.instant('Collections (Stamps, coins, comic book figurines, etc.)'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 110, 'answer': this.translate.instant('Souvenirs - Gifts'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 111, 'answer': this.translate.instant('Carnival items - Jokes - Fancy dress'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 112, 'answer': this.translate.instant('Party decorations and accessories (baptism, wedding, etc.)'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 113, 'answer': this.translate.instant('Sex shop'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 114, 'answer': this.translate.instant('Religious goods'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 115, 'answer': this.translate.instant('Esoteric goods'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 116, 'answer': this.translate.instant('Other leisure'), 'lvl2ID': 14, 'lvl1ID': 3 },
  { 'id': 117, 'answer': this.translate.instant('Decoration - General'), 'lvl2ID': 15, 'lvl1ID': 4 },
  { 'id': 118, 'answer': this.translate.instant('Small decorative items - Ornaments'), 'lvl2ID': 15, 'lvl1ID': 4 },
  { 'id': 119, 'answer': this.translate.instant('Framer'), 'lvl2ID': 15, 'lvl1ID': 4 },
  { 'id': 120, 'answer': this.translate.instant('Art gallery (excluding photography)'), 'lvl2ID': 15, 'lvl1ID': 4 },
  { 'id': 121, 'answer': this.translate.instant('Photographic gallery'), 'lvl2ID': 15, 'lvl1ID': 4 },
  { 'id': 122, 'answer': this.translate.instant('Flowers - Decorative plants'), 'lvl2ID': 15, 'lvl1ID': 4 },
  { 'id': 123, 'answer': this.translate.instant('Artisan goldsmith, copper, wrought iron'), 'lvl2ID': 15, 'lvl1ID': 4 },
  { 'id': 124, 'answer': this.translate.instant('Artisan glassmaker, crystal, mirrors'), 'lvl2ID': 15, 'lvl1ID': 4 },
  { 'id': 125, 'answer': this.translate.instant('Artisan woodworker, cabinetmaker'), 'lvl2ID': 15, 'lvl1ID': 4 },
  { 'id': 126, 'answer': this.translate.instant('Homewares - General'), 'lvl2ID': 16, 'lvl1ID': 4 },
  { 'id': 127, 'answer': this.translate.instant('Drugstore - Cleaning products'), 'lvl2ID': 16, 'lvl1ID': 4 },
  { 'id': 128, 'answer': this.translate.instant('Kitchen utensils - Cutlery'), 'lvl2ID': 16, 'lvl1ID': 4 },
  { 'id': 129, 'answer': this.translate.instant('Crockery - Tableware'), 'lvl2ID': 16, 'lvl1ID': 4 },
  { 'id': 130, 'answer': this.translate.instant('Household textiles - Bedding'), 'lvl2ID': 16, 'lvl1ID': 4 },
  { 'id': 131, 'answer': this.translate.instant('Childrens items - Childcare goods'), 'lvl2ID': 16, 'lvl1ID': 4 },
  { 'id': 132, 'answer': this.translate.instant('Furnishings - General'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 133, 'answer': this.translate.instant('Household furniture - Contemporary'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 134, 'answer': this.translate.instant('Household furniture - Traditional'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 135, 'answer': this.translate.instant('Household furniture - Designer'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 136, 'answer': this.translate.instant('Office furniture'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 137, 'answer': this.translate.instant('Garden furniture'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 138, 'answer': this.translate.instant('Kitchens'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 139, 'answer': this.translate.instant('Bathrooms'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 140, 'answer': this.translate.instant('Beds - Mattresses'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 141, 'answer': this.translate.instant('Child and baby furniture'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 142, 'answer': this.translate.instant('Soft furnishings'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 143, 'answer': this.translate.instant('Rugs'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 144, 'answer': this.translate.instant('Swimming pool - Sauna'), 'lvl2ID': 17, 'lvl1ID': 4 },
  { 'id': 145, 'answer': this.translate.instant('Hardware and materials - General'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 146, 'answer': this.translate.instant('Hardware - Tools'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 147, 'answer': this.translate.instant('Building materials'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 148, 'answer': this.translate.instant('Paints - Wallpaper'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 149, 'answer': this.translate.instant('Floor tiles'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 150, 'answer': this.translate.instant('Parquet flooring'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 151, 'answer': this.translate.instant('Doors - Window frames - Shutters'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 152, 'answer': this.translate.instant('Verandah'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 153, 'answer': this.translate.instant('Plumbing and sanitation materials'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 154, 'answer': this.translate.instant('Electrical materials'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 155, 'answer': this.translate.instant('Heating - Air conditioning'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 156, 'answer': this.translate.instant('Fuels (coal, pellets, etc.)'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 157, 'answer': this.translate.instant('Gardening items - Garden centres'), 'lvl2ID': 18, 'lvl1ID': 4 },
  { 'id': 158, 'answer': this.translate.instant('Domestic appliances'), 'lvl2ID': 19, 'lvl1ID': 4 },
  { 'id': 159, 'answer': this.translate.instant('Television - Hifi'), 'lvl2ID': 19, 'lvl1ID': 4 },
  { 'id': 160, 'answer': this.translate.instant('Lighting'), 'lvl2ID': 19, 'lvl1ID': 4 },
  { 'id': 161, 'answer': this.translate.instant('Home automation and alarm systems'), 'lvl2ID': 19, 'lvl1ID': 4 },
  { 'id': 162, 'answer': this.translate.instant('Cars'), 'lvl2ID': 20, 'lvl1ID': 5 },
  { 'id': 163, 'answer': this.translate.instant('Motorbikes'), 'lvl2ID': 20, 'lvl1ID': 5 },
  { 'id': 164, 'answer': this.translate.instant('Boats'), 'lvl2ID': 20, 'lvl1ID': 5 },
  { 'id': 165, 'answer': this.translate.instant('Other motor vehicles'), 'lvl2ID': 20, 'lvl1ID': 5 },
  { 'id': 166, 'answer': this.translate.instant('Bikes - Electric bikes'), 'lvl2ID': 21, 'lvl1ID': 5 },
  { 'id': 167, 'answer': this.translate.instant('Scooters - Segways'), 'lvl2ID': 21, 'lvl1ID': 5 },
  { 'id': 168, 'answer': this.translate.instant('Skateboards - Roller skates'), 'lvl2ID': 21, 'lvl1ID': 5 },
  { 'id': 169, 'answer': this.translate.instant('Service stations (petrol, gas, etc.)'), 'lvl2ID': 22, 'lvl1ID': 5 },
  { 'id': 170, 'answer': this.translate.instant('Accessories for motor vehicles'), 'lvl2ID': 22, 'lvl1ID': 5 },
  { 'id': 171, 'answer': this.translate.instant('Spare parts for motor vehicles'), 'lvl2ID': 22, 'lvl1ID': 5 },
  { 'id': 172, 'answer': this.translate.instant('Bike accessories'), 'lvl2ID': 22, 'lvl1ID': 5 },
  { 'id': 173, 'answer': this.translate.instant('Tyres'), 'lvl2ID': 22, 'lvl1ID': 5 },
  { 'id': 174, 'answer': this.translate.instant('Caravans - Trailers'), 'lvl2ID': 22, 'lvl1ID': 5 },
  { 'id': 175, 'answer': this.translate.instant('Cafe - Expresso bar'), 'lvl2ID': 23, 'lvl1ID': 6 },
  { 'id': 176, 'answer': this.translate.instant('Juice bar'), 'lvl2ID': 23, 'lvl1ID': 6 },
  { 'id': 177, 'answer': this.translate.instant('Breakfast'), 'lvl2ID': 23, 'lvl1ID': 6 },
  { 'id': 178, 'answer': this.translate.instant('Tearoom'), 'lvl2ID': 23, 'lvl1ID': 6 },
  { 'id': 179, 'answer': this.translate.instant('Pâtisserie'), 'lvl2ID': 23, 'lvl1ID': 6 },
  { 'id': 180, 'answer': this.translate.instant('Crêpe shop'), 'lvl2ID': 23, 'lvl1ID': 6 },
  { 'id': 181, 'answer': this.translate.instant('Waffles'), 'lvl2ID': 23, 'lvl1ID': 6 },
  { 'id': 182, 'answer': this.translate.instant('Ice cream shop'), 'lvl2ID': 23, 'lvl1ID': 6 },
  { 'id': 183, 'answer': this.translate.instant('Cafe-bar (only drinks)'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 184, 'answer': this.translate.instant('Small restaurant'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 185, 'answer': this.translate.instant('Sandwich bar'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 186, 'answer': this.translate.instant('Chip shop'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 187, 'answer': this.translate.instant('Burger bar'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 188, 'answer': this.translate.instant('Kebab shop'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 189, 'answer': this.translate.instant('Fresh food - Salad-bar'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 190, 'answer': this.translate.instant('Canteen - Cafeteria - Food-court'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 191, 'answer': this.translate.instant('Pizzeria'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 192, 'answer': this.translate.instant('Tapas bar'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 193, 'answer': this.translate.instant('Sushi bar'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 194, 'answer': this.translate.instant('Fast Food'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 195, 'answer': this.translate.instant('Other fast food'), 'lvl2ID': 24, 'lvl1ID': 6 },
  { 'id': 196, 'answer': this.translate.instant('Traditional restaurant'), 'lvl2ID': 25, 'lvl1ID': 6 },
  { 'id': 197, 'answer': this.translate.instant('Brasserie'), 'lvl2ID': 25, 'lvl1ID': 6 },
  { 'id': 198, 'answer': this.translate.instant('Steakhouse'), 'lvl2ID': 25, 'lvl1ID': 6 },
  { 'id': 199, 'answer': this.translate.instant('BBQ - Grill'), 'lvl2ID': 25, 'lvl1ID': 6 },
  { 'id': 200, 'answer': this.translate.instant('Seafood'), 'lvl2ID': 25, 'lvl1ID': 6 },
  { 'id': 201, 'answer': this.translate.instant('Buffet restaurant'), 'lvl2ID': 25, 'lvl1ID': 6 },
  { 'id': 202, 'answer': this.translate.instant('Gourmet restaurant'), 'lvl2ID': 25, 'lvl1ID': 6 },
  { 'id': 203, 'answer': this.translate.instant('Molecular cuisine'), 'lvl2ID': 25, 'lvl1ID': 6 },
  { 'id': 204, 'answer': this.translate.instant('Restaurant - Mediterranean (Africa - Asia - Europe)'), 'lvl2ID': 26, 'lvl1ID': 6 },
  { 'id': 205, 'answer': this.translate.instant('Restaurant - Europe (Other)'), 'lvl2ID': 26, 'lvl1ID': 6 },
  { 'id': 206, 'answer': this.translate.instant('Restaurant - America (North)'), 'lvl2ID': 26, 'lvl1ID': 6 },
  { 'id': 207, 'answer': this.translate.instant('Restaurant - Africa (Other)'), 'lvl2ID': 26, 'lvl1ID': 6 },
  { 'id': 208, 'answer': this.translate.instant('Restaurant - Asia (Other)'), 'lvl2ID': 26, 'lvl1ID': 6 },
  { 'id': 209, 'answer': this.translate.instant('Restaurant - America (Other)'), 'lvl2ID': 26, 'lvl1ID': 6 },
  { 'id': 210, 'answer': this.translate.instant('Restaurant - Oceania'), 'lvl2ID': 26, 'lvl1ID': 6 },
  { 'id': 211, 'answer': this.translate.instant('Hotel - 1 star'), 'lvl2ID': 27, 'lvl1ID': 6 },
  { 'id': 212, 'answer': this.translate.instant('Hotel - 2 star'), 'lvl2ID': 27, 'lvl1ID': 6 },
  { 'id': 213, 'answer': this.translate.instant('Hotel - 3 star'), 'lvl2ID': 27, 'lvl1ID': 6 },
  { 'id': 214, 'answer': this.translate.instant('Hotel - 4 star'), 'lvl2ID': 27, 'lvl1ID': 6 },
  { 'id': 215, 'answer': this.translate.instant('Hotel - 5 star'), 'lvl2ID': 27, 'lvl1ID': 6 },
  { 'id': 216, 'answer': this.translate.instant('Guest house - Bed & Breakfast'), 'lvl2ID': 28, 'lvl1ID': 6 },
  { 'id': 217, 'answer': this.translate.instant('Youth hostel'), 'lvl2ID': 28, 'lvl1ID': 6 },
  { 'id': 218, 'answer': this.translate.instant('Motel'), 'lvl2ID': 28, 'lvl1ID': 6 },
  { 'id': 219, 'answer': this.translate.instant('Aparthotel'), 'lvl2ID': 28, 'lvl1ID': 6 },
  { 'id': 220, 'answer': this.translate.instant('Camp site'), 'lvl2ID': 28, 'lvl1ID': 6 },
  { 'id': 221, 'answer': this.translate.instant('Holiday camp'), 'lvl2ID': 28, 'lvl1ID': 6 },
  { 'id': 222, 'answer': this.translate.instant('Bar - Pub'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 223, 'answer': this.translate.instant('Cocktail bar'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 224, 'answer': this.translate.instant('Wine bar'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 225, 'answer': this.translate.instant('Bars selling spirits (whisky, rum, etc.)'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 226, 'answer': this.translate.instant('Karaoke bar'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 227, 'answer': this.translate.instant('Lounge Bar'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 228, 'answer': this.translate.instant('Shisha bar'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 229, 'answer': this.translate.instant('Sports Bar'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 230, 'answer': this.translate.instant('Nightclub'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 231, 'answer': this.translate.instant('Blues - Jazz club'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 232, 'answer': this.translate.instant('Salsa - Latino club'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 233, 'answer': this.translate.instant('Other club'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 234, 'answer': this.translate.instant('Private clubs'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 235, 'answer': this.translate.instant('Strip club'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 236, 'answer': this.translate.instant('Peepshow'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 237, 'answer': this.translate.instant('Window girl'), 'lvl2ID': 29, 'lvl1ID': 7 },
  { 'id': 238, 'answer': this.translate.instant('General interest museum'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 239, 'answer': this.translate.instant('Archaeology and history'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 240, 'answer': this.translate.instant('Ethnography and anthropology'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 241, 'answer': this.translate.instant('Art'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 242, 'answer': this.translate.instant('Natural history and natural sciences'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 243, 'answer': this.translate.instant('Science and technology'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 244, 'answer': this.translate.instant('Specialist museum'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 245, 'answer': this.translate.instant('Temporary exhibition space (conference centre, etc.)'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 246, 'answer': this.translate.instant('Zoo - Animal park'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 247, 'answer': this.translate.instant('Aquarium'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 248, 'answer': this.translate.instant('Botanical garden'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 249, 'answer': this.translate.instant('Buildings or sites to visit'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 250, 'answer': this.translate.instant('Guided tour agency (bus tours, boat tours, etc.)'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 251, 'answer': this.translate.instant('other tourist attraction'), 'lvl2ID': 30, 'lvl1ID': 7 },
  { 'id': 252, 'answer': this.translate.instant('Cinema'), 'lvl2ID': 31, 'lvl1ID': 7 },
  { 'id': 253, 'answer': this.translate.instant('Comedy club'), 'lvl2ID': 31, 'lvl1ID': 7 },
  { 'id': 254, 'answer': this.translate.instant('Concert venue'), 'lvl2ID': 31, 'lvl1ID': 7 },
  { 'id': 255, 'answer': this.translate.instant('Theatre'), 'lvl2ID': 31, 'lvl1ID': 7 },
  { 'id': 256, 'answer': this.translate.instant('Opera - Concert hall'), 'lvl2ID': 31, 'lvl1ID': 7 },
  { 'id': 257, 'answer': this.translate.instant('Cabaret'), 'lvl2ID': 31, 'lvl1ID': 7 },
  { 'id': 258, 'answer': this.translate.instant('Multipurpose events venue - Cultural centre'), 'lvl2ID': 31, 'lvl1ID': 7 },
  { 'id': 259, 'answer': this.translate.instant('Football stadium'), 'lvl2ID': 31, 'lvl1ID': 7 },
  { 'id': 260, 'answer': this.translate.instant('Basketball stadium'), 'lvl2ID': 31, 'lvl1ID': 7 },
  { 'id': 261, 'answer': this.translate.instant('Other infrastructure'), 'lvl2ID': 31, 'lvl1ID': 7 },
  { 'id': 262, 'answer': this.translate.instant('Multipurpose hall'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 263, 'answer': this.translate.instant('Fitness room - gym'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 264, 'answer': this.translate.instant('Squash court'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 265, 'answer': this.translate.instant('Five-a-side pitch'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 266, 'answer': this.translate.instant('Climbing centre'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 267, 'answer': this.translate.instant('Skating rink'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 268, 'answer': this.translate.instant('Swimming pool'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 269, 'answer': this.translate.instant('Horse riding'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 270, 'answer': this.translate.instant('Karting - Circuit'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 271, 'answer': this.translate.instant('Skate park'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 272, 'answer': this.translate.instant('Shooting gallery'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 273, 'answer': this.translate.instant('Fishery'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 274, 'answer': this.translate.instant('Other sporting facility'), 'lvl2ID': 32, 'lvl1ID': 7 },
  { 'id': 275, 'answer': this.translate.instant('Sauna'), 'lvl2ID': 33, 'lvl1ID': 7 },
  { 'id': 276, 'answer': this.translate.instant('Turkish baths'), 'lvl2ID': 33, 'lvl1ID': 7 },
  { 'id': 277, 'answer': this.translate.instant('Spa'), 'lvl2ID': 33, 'lvl1ID': 7 },
  { 'id': 278, 'answer': this.translate.instant('Massage'), 'lvl2ID': 33, 'lvl1ID': 7 },
  { 'id': 280, 'answer': this.translate.instant('Pool hall'), 'lvl2ID': 34, 'lvl1ID': 7 },
  { 'id': 281, 'answer': this.translate.instant('Bowling alley'), 'lvl2ID': 34, 'lvl1ID': 7 },
  { 'id': 282, 'answer': this.translate.instant('Casino'), 'lvl2ID': 34, 'lvl1ID': 7 },
  { 'id': 283, 'answer': this.translate.instant('Gambling'), 'lvl2ID': 34, 'lvl1ID': 7 },
  { 'id': 284, 'answer': this.translate.instant('Arcade - Lunapark'), 'lvl2ID': 34, 'lvl1ID': 7 },
  { 'id': 285, 'answer': this.translate.instant('e-sport bar'), 'lvl2ID': 34, 'lvl1ID': 7 },
  { 'id': 286, 'answer': this.translate.instant('Board games bar'), 'lvl2ID': 34, 'lvl1ID': 7 },
  { 'id': 287, 'answer': this.translate.instant('Theme park'), 'lvl2ID': 35, 'lvl1ID': 7 },
  { 'id': 288, 'answer': this.translate.instant('Water park'), 'lvl2ID': 35, 'lvl1ID': 7 },
  { 'id': 289, 'answer': this.translate.instant('Mini-golf'), 'lvl2ID': 35, 'lvl1ID': 7 },
  { 'id': 290, 'answer': this.translate.instant('Laser quest'), 'lvl2ID': 35, 'lvl1ID': 7 },
  { 'id': 291, 'answer': this.translate.instant('Paintballing'), 'lvl2ID': 35, 'lvl1ID': 7 },
  { 'id': 292, 'answer': this.translate.instant('Escape room'), 'lvl2ID': 35, 'lvl1ID': 7 },
  { 'id': 293, 'answer': this.translate.instant('Indoor playground'), 'lvl2ID': 35, 'lvl1ID': 7 },
  { 'id': 294, 'answer': this.translate.instant('Other activity'), 'lvl2ID': 35, 'lvl1ID': 7 },
  { 'id': 295, 'answer': this.translate.instant('Bank - Lender'), 'lvl2ID': 36, 'lvl1ID': 8 },
  { 'id': 296, 'answer': this.translate.instant('Insurance'), 'lvl2ID': 36, 'lvl1ID': 8 },
  { 'id': 297, 'answer': this.translate.instant('Money transfer'), 'lvl2ID': 36, 'lvl1ID': 8 },
  { 'id': 298, 'answer': this.translate.instant('Bureau de change'), 'lvl2ID': 36, 'lvl1ID': 8 },
  { 'id': 299, 'answer': this.translate.instant('Mutual fund'), 'lvl2ID': 36, 'lvl1ID': 8 },
  { 'id': 300, 'answer': this.translate.instant('Post office'), 'lvl2ID': 36, 'lvl1ID': 8 },
  { 'id': 301, 'answer': this.translate.instant('Union'), 'lvl2ID': 36, 'lvl1ID': 8 },
  { 'id': 302, 'answer': this.translate.instant('Temping agency'), 'lvl2ID': 36, 'lvl1ID': 8 },
  { 'id': 303, 'answer': this.translate.instant('Service voucher office'), 'lvl2ID': 36, 'lvl1ID': 8 },
  { 'id': 304, 'answer': this.translate.instant('Estate agent'), 'lvl2ID': 36, 'lvl1ID': 8 },
  { 'id': 305, 'answer': this.translate.instant('Launderette'), 'lvl2ID': 37, 'lvl1ID': 8 },
  { 'id': 306, 'answer': this.translate.instant('Dry cleaning'), 'lvl2ID': 37, 'lvl1ID': 8 },
  { 'id': 307, 'answer': this.translate.instant('Ironing centre'), 'lvl2ID': 37, 'lvl1ID': 8 },
  { 'id': 308, 'answer': this.translate.instant('Clothing repairs'), 'lvl2ID': 37, 'lvl1ID': 8 },
  { 'id': 309, 'answer': this.translate.instant('Cobbler'), 'lvl2ID': 37, 'lvl1ID': 8 },
  { 'id': 310, 'answer': this.translate.instant('Key cutting'), 'lvl2ID': 37, 'lvl1ID': 8 },
  { 'id': 311, 'answer': this.translate.instant('Clothing rental'), 'lvl2ID': 37, 'lvl1ID': 8 },
  { 'id': 312, 'answer': this.translate.instant('Telephone and Internet service provider'), 'lvl2ID': 38, 'lvl1ID': 8 },
  { 'id': 313, 'answer': this.translate.instant('Energy supplier'), 'lvl2ID': 38, 'lvl1ID': 8 },
  { 'id': 314, 'answer': this.translate.instant('Repairs to electrical/ multimedia goods'), 'lvl2ID': 38, 'lvl1ID': 8 },
  { 'id': 315, 'answer': this.translate.instant('Upholsterer - Interior designer - Restoration'), 'lvl2ID': 38, 'lvl1ID': 8 },
  { 'id': 316, 'answer': this.translate.instant('Tool hire'), 'lvl2ID': 38, 'lvl1ID': 8 },
  { 'id': 317, 'answer': this.translate.instant('Hire of household items'), 'lvl2ID': 38, 'lvl1ID': 8 },
  { 'id': 318, 'answer': this.translate.instant('Auctioneer'), 'lvl2ID': 38, 'lvl1ID': 8 },
  { 'id': 319, 'answer': this.translate.instant('Garage - Car maintenance'), 'lvl2ID': 39, 'lvl1ID': 8 },
  { 'id': 320, 'answer': this.translate.instant('Car hire'), 'lvl2ID': 39, 'lvl1ID': 8 },
  { 'id': 321, 'answer': this.translate.instant('Garage - Maintenance of other motor vehicles'), 'lvl2ID': 39, 'lvl1ID': 8 },
  { 'id': 322, 'answer': this.translate.instant('Hire of other motor vehicles'), 'lvl2ID': 39, 'lvl1ID': 8 },
  { 'id': 323, 'answer': this.translate.instant('Bike maintenance'), 'lvl2ID': 39, 'lvl1ID': 8 },
  { 'id': 324, 'answer': this.translate.instant('Bike hire'), 'lvl2ID': 39, 'lvl1ID': 8 },
  { 'id': 325, 'answer': this.translate.instant('Car wash'), 'lvl2ID': 39, 'lvl1ID': 8 },
  { 'id': 326, 'answer': this.translate.instant('Driving school'), 'lvl2ID': 39, 'lvl1ID': 8 },
  { 'id': 327, 'answer': this.translate.instant('Public transport ticket vendor'), 'lvl2ID': 39, 'lvl1ID': 8 },
  { 'id': 328, 'answer': this.translate.instant('Transport company'), 'lvl2ID': 39, 'lvl1ID': 8 },
  { 'id': 329, 'answer': this.translate.instant('Hairdresser'), 'lvl2ID': 40, 'lvl1ID': 8 },
  { 'id': 330, 'answer': this.translate.instant('Barber'), 'lvl2ID': 40, 'lvl1ID': 8 },
  { 'id': 331, 'answer': this.translate.instant('Tattoo parlour'), 'lvl2ID': 40, 'lvl1ID': 8 },
  { 'id': 332, 'answer': this.translate.instant('Piercing'), 'lvl2ID': 40, 'lvl1ID': 8 },
  { 'id': 333, 'answer': this.translate.instant('Nails - Manicure'), 'lvl2ID': 40, 'lvl1ID': 8 },
  { 'id': 334, 'answer': this.translate.instant('Beauty salon'), 'lvl2ID': 40, 'lvl1ID': 8 },
  { 'id': 335, 'answer': this.translate.instant('Tanning'), 'lvl2ID': 40, 'lvl1ID': 8 },
  { 'id': 337, 'answer': this.translate.instant('Travel agent'), 'lvl2ID': 41, 'lvl1ID': 8 },
  { 'id': 338, 'answer': this.translate.instant('Video rental'), 'lvl2ID': 41, 'lvl1ID': 8 },
  { 'id': 339, 'answer': this.translate.instant('Library'), 'lvl2ID': 41, 'lvl1ID': 8 },
  { 'id': 340, 'answer': this.translate.instant('Media library'), 'lvl2ID': 41, 'lvl1ID': 8 },
  { 'id': 341, 'answer': this.translate.instant('Toy library'), 'lvl2ID': 41, 'lvl1ID': 8 },
  { 'id': 342, 'answer': this.translate.instant('Tourist information'), 'lvl2ID': 41, 'lvl1ID': 8 },
  { 'id': 343, 'answer': this.translate.instant('Taster- Lessons (Cooking, alcohol, DIY, etc.)'), 'lvl2ID': 41, 'lvl1ID': 8 },
  { 'id': 344, 'answer': this.translate.instant('Photo studio'), 'lvl2ID': 41, 'lvl1ID': 8 },
  { 'id': 345, 'answer': this.translate.instant('Pet grooming'), 'lvl2ID': 41, 'lvl1ID': 8 },
  { 'id': 346, 'answer': this.translate.instant('Telephone booths - Cyber cafe'), 'lvl2ID': 42, 'lvl1ID': 8 },
  { 'id': 347, 'answer': this.translate.instant('Printshop - Photocopies'), 'lvl2ID': 42, 'lvl1ID': 8 },
  { 'id': 348, 'answer': this.translate.instant('Engraver - Printing on items'), 'lvl2ID': 42, 'lvl1ID': 8 },
  { 'id': 349, 'answer': this.translate.instant('Cups - Medals - Trophies'), 'lvl2ID': 42, 'lvl1ID': 8 },
  { 'id': 350, 'answer': this.translate.instant('Funeral parlour'), 'lvl2ID': 42, 'lvl1ID': 8 },
  { 'id': 351, 'answer': this.translate.instant('Funeral goods'), 'lvl2ID': 42, 'lvl1ID': 8 },
  { 'id': 352, 'answer': this.translate.instant('Clairvoyants'), 'lvl2ID': 42, 'lvl1ID': 8 },
  { 'id': 353, 'answer': this.translate.instant('Banqueting/event venue hire'), 'lvl2ID': 42, 'lvl1ID': 8 },
  { 'id': 354, 'answer': this.translate.instant('Various repairs (toys, etc.)'), 'lvl2ID': 42, 'lvl1ID': 8 },
  { 'id': 355, 'answer': this.translate.instant('Bookmaker'), 'lvl2ID': 34, 'lvl1ID': 8 },
  { 'id': 356, 'answer': this.translate.instant('Empty Unit'), 'lvl2ID': 43, 'lvl1ID': 9 },
  { 'id': 357, 'answer': this.translate.instant('Empty cell'), 'lvl2ID': 44, 'lvl1ID': 10 }];

  ngOnInit() {
    this.facadeAnswers = [
      { id: 1, value: this.translate.instant('Present and perfectly identifiable') },
      { id: 2, value: this.translate.instant('Present but difficult to identify (hidden, presence of obsolete signs, etc.)') },
      { id: 3, value: this.translate.instant('Absent') },
      { id: 4, value: this.translate.instant('Present and perfectly identifiable') },
      { id: 5, value: this.translate.instant('Present but difficult to identify') },
      { id: 6, value: this.translate.instant('Absent') },
      { id: 7, value: this.translate.instant('Basic/Decay') },
      { id: 8, value: this.translate.instant('In good condition') },
      { id: 9, value: this.translate.instant('Renovated/Modern') },
      { id: 10, value: this.translate.instant('Non Pertinent/Non visible') },
      { id: 11, value: this.translate.instant('Yes') },
      { id: 12, value: this.translate.instant('No') },
      { id: 13, value: this.translate.instant('Non relevant (gallery or else)') },
    ];
    this.contextAnswers = [
      { id: 1, value: this.translate.instant('Yes') },
      { id: 2, value: this.translate.instant('No') },
      { id: 3, value: this.translate.instant('Non relevant (gallery or else)') },
      { id: 4, value: this.translate.instant('Less than 3 places') },
      { id: 5, value: this.translate.instant('From 3 to 10 places') },
      { id: 6, value: this.translate.instant('From 11 to 25 places') },
      { id: 7, value: this.translate.instant('More than 25 places') },
      { id: 8, value: this.translate.instant('None (few or no inclination)') },
      { id: 9, value: this.translate.instant('Slope in the street direction') },
      { id: 10, value: this.translate.instant('Slope in the facade/edge direction') },
      { id: 11, value: this.translate.instant('In perfect condition') },
      { id: 12, value: this.translate.instant('In good condition (some small holes, loose pavers, etc.)') },
      { id: 13, value: this.translate.instant('In poor condition') },
      { id: 14, value: this.translate.instant('Under construction') },
      { id: 15, value: this.translate.instant('Narrow sidewalk/Driveway') },
      { id: 16, value: this.translate.instant('Sidewalk/Driveway under construction') },
      { id: 17, value: this.translate.instant('Presence of annoying elements (terrace, display, trash can, flowerpot, etc.)') }
    ]
    this.accessAnswers = [
      { id: 1, value: this.translate.instant('Yes') },
      { id: 2, value: this.translate.instant('No') },
      { id: 3, value: this.translate.instant('No, it is in the buildings recess') },
      { id: 4, value: this.translate.instant('No, the store is inside a building (shopping center, gallery, etc.)') },
      { id: 5, value: this.translate.instant('In ground level') },
      { id: 6, value: this.translate.instant('With a small ledge (2cm or less)') },
      { id: 7, value: this.translate.instant('With a step') },
      { id: 8, value: this.translate.instant('With more than one step') },
      { id: 9, value: this.translate.instant('Yes, a permanent') },
      { id: 10, value: this.translate.instant('Yes, a removable') },
      { id: 11, value: this.translate.instant('No') },

      { id: 12, value: this.translate.instant('Automatic') },
      { id: 13, value: this.translate.instant('Opening in both directions') },
      { id: 14, value: this.translate.instant('Inward opening') },
      { id: 15, value: this.translate.instant('Outward opening') },
      { id: 16, value: this.translate.instant('Not relevant (no door)') },
      { id: 17, value: this.translate.instant('Yes') },
      { id: 18, value: this.translate.instant('No') },
      { id: 19, value: this.translate.instant('Not relevant (no door)') },

    ]
    this.counterInteriorAnswers = [
      { id: 1, value: this.translate.instant('Yes') },
      { id: 2, value: this.translate.instant('No') },
      { id: 3, value: this.translate.instant('Not relevant') },
    ]
    this.floorsRestroomAnswers = [
      { id: 1, value: this.translate.instant('Yes') },
      { id: 2, value: this.translate.instant('No') },
      { id: 3, value: this.translate.instant('Not relevant') },
      { id: 4, value: this.translate.instant('Ground level') },
      { id: 5, value: this.translate.instant('Stairs') },
      { id: 6, value: this.translate.instant('Escalator') },
      { id: 7, value: this.translate.instant('Elevator') },
      { id: 8, value: this.translate.instant('Ramp/Inclined plane') },
      { id: 9, value: this.translate.instant('Other') },

    ]
    this.contactAnswers = [
      { id: 1, value: "Facebook" },
      { id: 2, value: "Instagram" },
      { id: 3, value: "You Tube" },
      { id: 4, value: "Twitter" },
      { id: 5, value: "LinkedIn" },
      { id: 6, value: this.translate.instant('Other') },
      { id: 7, value: this.translate.instant('No') },
      { id: 8, value: this.translate.instant(`I don't know/I don't want to disclose`) },
      { id: 9, value: this.translate.instant('Yes') },
      { id: 10, value: this.translate.instant('No') },
      { id: 11, value: this.translate.instant('Mr') },
      { id: 12, value: this.translate.instant('Ms') },]

    this.paymentAndSurface = [
      { id: 1, value: this.translate.instant('Cash') },
      { id: 2, value: this.translate.instant('Bank card') },
      { id: 3, value: this.translate.instant('Credit card') },
      { id: 4, value: this.translate.instant('Smartphone') },
      { id: 5, value: this.translate.instant('Gift-vouchers') },
      { id: 6, value: this.translate.instant('Meal vouchers') },
      { id: 7, value: this.translate.instant('Zinne or other local currency') },
      { id: 8, value: this.translate.instant('Other') },
      { id: 9, value: this.translate.instant(`I don't know/I don't want to disclose`) },
      { id: 10, value: this.translate.instant('Yes - On our website') },
      { id: 11, value: this.translate.instant('Yes - On other website(s)') },
      { id: 12, value: this.translate.instant('Yes - On our website and on other one(s)') },
      { id: 13, value: this.translate.instant('No') },
      { id: 14, value: this.translate.instant('Not relevant') },
      { id: 15, value: this.translate.instant(`I don't know/I don't want to disclose`) },
      { id: 16, value: this.translate.instant('Yes - By ourselves') },
      { id: 17, value: this.translate.instant('Yes - With one or more service providers') },
      { id: 18, value: this.translate.instant('Yes - By ourselves and one or more service providers') },
      { id: 19, value: this.translate.instant('No') },
      { id: 20, value: this.translate.instant('Not relevant') },
      { id: 21, value: this.translate.instant(`I don't know/I don't want to disclose`) },
      { id: 22, value: this.translate.instant('Same floor') },
      { id: 23, value: this.translate.instant('Basement') },
      { id: 24, value: this.translate.instant('Upstairs') },
      { id: 25, value: this.translate.instant('On another location') },
      { id: 26, value: this.translate.instant('Yes') },
      { id: 27, value: this.translate.instant('No') },
      { id: 28, value: this.translate.instant('Not relevant') },
      { id: 29, value: this.translate.instant(`I don't know/I don't want to disclose`) },
    ]
    this.historicAnswers = [
      { id: 1, value: this.translate.instant('Yes') },
      { id: 2, value: this.translate.instant('No, but it was already in the neighborhood') },
      { id: 3, value: this.translate.instant('No, it was in an other neighborhood before') },
      { id: 4, value: this.translate.instant(`I don't know/I don't want to disclose`) },
      { id: 5, value: this.translate.instant('Renter') },
      { id: 6, value: this.translate.instant('Owner') },
      { id: 7, value: this.translate.instant(`I don't know/I don't want to disclose`) },
      { id: 8, value: this.translate.instant('Independent') },
      { id: 9, value: this.translate.instant('Franchise') },
      { id: 10, value: this.translate.instant('Branche') },
      { id: 11, value: this.translate.instant('Voluntary channel') },
      { id: 12, value: this.translate.instant('Cooperative') },
      { id: 13, value: this.translate.instant(`I don't know/I don't want to disclose`) },
      { id: 14, value: this.translate.instant('Yes') },
      { id: 15, value: this.translate.instant('No') },
      { id: 16, value: this.translate.instant(`I don't know/I don't want to disclose`) },
    ]
    this.level11 = this.level1; this.level12 = this.level1; this.level13 = this.level1; this.level14 = this.level1;
    this.browserLang = this.translate.defaultLang;  
    this.visit = this.infoDetails.visit;
    this.prm= this.infoDetails.prm;    
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;   
  }

  ngOnChanges($event) {
    let changedVariables = keys($event);
    if (changedVariables.includes('infoDetails')) {
      this.getInfoSheet(this.infoDetails);
    }
  }

  getInfoSheet(data) {
    // this.ids = JSON.parse(this.storageService.getData('missionId&quartierId'));
    this._event.broadcast({ eventName: 'showLoader', data: '' });
    let reqObject = {
      id: this.infoDetails.id,
      posId: this.infoDetails.posId,
      missionId: this.missionId,
      quartierId: this.quartierId
      // missionId: this.ids.missionId,
      // quartierId: this.ids.quartierId
    };
    this.subscriptions.push(
      this.apiService.getInfoSheet(reqObject).subscribe(
        data => {
          this.dto = data.dto;
          this.oldPos = data.dto.oldPos;
          this.newPos = data.dto.newPos;
          this.q2_no = this.newPos.contact.q2_no ? this.newPos.contact.q2_no : null;
          this.q2_phoneNumber = this.newPos.contact.q2_phoneNumber ? this.newPos.contact.q2_phoneNumber : null;
          this.q2_dontWantToDisclose = this.newPos.contact.q2_dontWantToDisclose ? this.newPos.contact.q2_dontWantToDisclose : null;
          this.q3_dontWantToDisclose = this.newPos.contact.q3_dontWantToDisclose ? this.newPos.contact.q3_dontWantToDisclose : null
          this.q3_mail = this.newPos.contact.q3_mail ? this.newPos.contact.q3_mail : null;
          this.q3_no = this.newPos.contact.q3_no ? this.newPos.contact.q3_no : null;
          this.q4_dontWantToDisclose = this.newPos.contact.q4_dontWantToDisclose ? this.newPos.contact.q4_dontWantToDisclose : null;
          this.q4_no = this.newPos.contact.q4_no ? this.newPos.contact.q4_no : null;
          this.q4_website = this.newPos.contact.q4_website ? this.newPos.contact.q4_website : null;
          this.shopSurface = this.newPos.realEstatesAdShopSurface ? this.newPos.realEstatesAdShopSurface : null;
          this.totalSurface = this.newPos.realEstatesAdTotalSurface ? this.newPos.realEstatesAdTotalSurface : null;          
          this.rentingPrice = this.newPos.surRentingPrice ? this.newPos.surRentingPrice : null;          
          this.sellingPrice = this.newPos.surSellingPrice ? this.newPos.surSellingPrice : null;        
          this.adEmail = this.newPos.realEstatesAdEmail ? this.newPos.realEstatesAdEmail : null;        
          this.adPhone = this.newPos.realEstatesAdPhone ? this.newPos.realEstatesAdPhone : null;        
          this.newPos.isNew
          ? this.newPos.posChooseSituation=this.translate.instant('New Point of Sale')
          : this.newPos.posChooseSituation
          ? this.translate.instant(this.newPos.posChooseSituation)
          : '';
          this.getAddress();
          this.translateTags();
          this.checkSchedule();
          this.getLevels(this.newPos,this.oldPos);

          if(this.newPos.validationFlag !== null){
            this.dateSelected=false;
          }
          this.checkForButton();
          // this.getSchedule();
          this._event.broadcast({ eventName: 'hideLoader', data: '' });
        },
        err => {
          this._event.broadcast({ eventName: 'hideLoader', data: '' });
        }
      )
    );
  }

  getSchedule() {
    this.newPos.schedule.posD2DMoBreak === 'Not a Working Day' || this.newPos.schedule.posD2DMoBreak === 'N/A' ? this.newPos.schedule.posD2DMoBreak = null : false;
    this.newPos.schedule.posD2DThuAppointment === 'Not a Working Day' || this.newPos.schedule.posD2DThuAppointment === 'N/A' ? this.newPos.schedule.posD2DThuAppointment = null : false;
    this.newPos.schedule.posD2DFriShift1 === 'Not a Working Day' || this.newPos.schedule.posD2DFriShift1 === 'N/A' ? this.newPos.schedule.posD2DFriShift1 = null : false;
    this.newPos.schedule.posD2DFriBreak === 'Not a Working Day' || this.newPos.schedule.posD2DFriBreak === 'N/A' ? this.newPos.schedule.posD2DFriBreak = null : false;
    this.newPos.schedule.posD2DFriAppointment === 'Not a Working Day' || this.newPos.schedule.posD2DFriAppointment === 'N/A' ? this.newPos.schedule.posD2DFriAppointment = null : false;
    this.newPos.schedule.posD2DSatShift1 === 'Not a Working Day' || this.newPos.schedule.posD2DSatShift1 === 'N/A' ? this.newPos.schedule.posD2DSatShift1 = null : false;
    this.newPos.schedule.posD2DSatBreak === 'Not a Working Day' || this.newPos.schedule.posD2DSatBreak === 'N/A' ? this.newPos.schedule.posD2DSatBreak = null : false;
    this.newPos.schedule.posD2DSatAppointment === 'Not a Working Day' || this.newPos.schedule.posD2DSatAppointment === 'N/A' ? this.newPos.schedule.posD2DSatAppointment = null : false;
    this.newPos.schedule.posD2DSunShift1 === 'Not a Working Day' || this.newPos.schedule.posD2DSunShift1 === 'N/A' ? this.newPos.schedule.posD2DSunShift1 = null : false;
    this.newPos.schedule.posD2DSunBreak === 'Not a Working Day' || this.newPos.schedule.posD2DSunBreak === 'N/A' ? this.newPos.schedule.posD2DSunBreak = null : false;
    this.newPos.schedule.posD2DThuShift1 === 'Not a Working Day' || this.newPos.schedule.posD2DThuShift1 === 'N/A' ? this.newPos.schedule.posD2DThuShift1 = null : false;
    this.newPos.schedule.posD2DWedBreak === 'Not a Working Day' || this.newPos.schedule.posD2DWedBreak === 'N/A' ? this.newPos.schedule.posD2DWedBreak = null : false;
    this.newPos.schedule.posD2DWedAppointment === 'Not a Working Day' || this.newPos.schedule.posD2DWedAppointment === 'N/A' ? this.newPos.schedule.posD2DWedAppointment = null : false;
    this.newPos.schedule.posD2DThuBreak === 'Not a Working Day' || this.newPos.schedule.posD2DThuBreak === 'N/A' ? this.newPos.schedule.posD2DThuBreak = null : false;
    this.newPos.schedule.posD2DWedShift1 === 'Not a Working Day' || this.newPos.schedule.posD2DWedShift1 === 'N/A' ? this.newPos.schedule.posD2DWedShift1 = null : false;
    this.newPos.schedule.posD2DTuAppointment === 'Not a Working Day' || this.newPos.schedule.posD2DTuAppointment === 'N/A' ? this.newPos.schedule.posD2DTuAppointment = null : false;
    this.newPos.schedule.posD2DTuBreak === 'Not a Working Day' || this.newPos.schedule.posD2DTuBreak === 'N/A' ? this.newPos.schedule.posD2DTuBreak = null : false;
    this.newPos.schedule.posD2DMoShift1 === 'Not a Working Day' || this.newPos.schedule.posD2DMoShift1 === 'N/A' ? this.newPos.schedule.posD2DMoShift1 = null : false;
    this.newPos.schedule.posD2DMoBreak === 'Not a Working Day' || this.newPos.schedule.posD2DMoBreak === 'N/A' ? this.newPos.schedule.posD2DMoBreak = null : false;
    this.newPos.schedule.posD2DTuShift1 === 'Not a Working Day' || this.newPos.schedule.posD2DTuShift1 === 'N/A' ? this.newPos.schedule.posD2DTuShift1 = null : false;
    this.newPos.schedule.posD2DSunAppointment === 'Not a Working Day' || this.newPos.schedule.posD2DSunAppointment === 'N/A' ? this.newPos.schedule.posD2DSunAppointment = null : false;
    this.newPos.schedule.posD2DMoAppointment === 'Not a Working Day' || this.newPos.schedule.posD2DMoAppointment === 'N/A' ? this.newPos.schedule.posD2DMoAppointment = null : false;    
    this.newPos.schedule.posMoFriAppointment === 'Not a Working Day' || this.newPos.schedule.posMoFriAppointment === 'N/A' ? this.newPos.schedule.posMoFriAppointment = null : false;    
    this.newPos.schedule.posMoFriBreak === 'Not a Working Day' || this.newPos.schedule.posMoFriBreak === 'N/A' ? this.newPos.schedule.posMoFriBreak = null : false;    

  }
  
  checkSchedule() {
    this.newPos.schedule.isStandard === 'Yes' ? this.standardFlag = true : this.standardFlag = false;
    // this.newPos.schedule.posD2DThuNoWorking ? this.newPos.schedule.posD2DThuNoWorking : this.newPos.schedule.posD2DThuNoWorking = 'NA',
    this.newPos.schedule.posD2DMoBreak = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMoFriBreak
      ? this.newPos.schedule.posMoFriBreak : 'N/A') : (this.newPos.schedule.posD2DMoNoWorking) == 'Yes' ? 'Not a Working Day'
        : (this.newPos.schedule.posD2DMoBreak ? this.newPos.schedule.posD2DMoBreak : 'N/A')
    this.newPos.schedule.posD2DThuAppointment = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMoFriAppointment
      ? this.newPos.schedule.posMoFriAppointment : 'N/A') : (this.newPos.schedule.posD2DThuNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posD2DThuAppointment ? this.newPos.schedule.posD2DThuAppointment : 'N/A')
    this.newPos.schedule.posD2DFriShift1 = (this.newPos.schedule.isStandard) === 'Yes' ? ((this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMonFriShift1
      ? this.newPos.schedule.posMonFriShift1 : 'N/A')) : (this.newPos.schedule.posD2DFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posD2DFriShift1 ? this.newPos.schedule.posD2DFriShift1 : 'N/A')
    this.newPos.schedule.posD2DFriBreak = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMoFriBreak
      ? this.newPos.schedule.posMoFriBreak : 'N/A') : (this.newPos.schedule.posD2DFriNoWorking) == 'Yes' ? 'Not a Working Day'
        : (this.newPos.schedule.posD2DFriBreak ? this.newPos.schedule.posD2DFriBreak : 'N/A')
    this.newPos.schedule.posD2DFriAppointment = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMoFriAppointment
      ? this.newPos.schedule.posMoFriAppointment : 'N/A') : (this.newPos.schedule.posD2DFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posD2DFriAppointment ? this.newPos.schedule.posD2DFriAppointment : 'N/A')
    this.newPos.schedule.posD2DSatShift1 = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posSatNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posSatShift1
      ? this.newPos.schedule.posSatShift1 : 'N/A') : (this.newPos.schedule.posD2DSatNoWorking) == 'Yes' ? 'Not a Working Day'
        : (this.newPos.schedule.posD2DSatShift1 ? this.newPos.schedule.posD2DSatShift1 : 'N/A')
    this.newPos.schedule.posD2DSatBreak = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posSatNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posSatBreak
      ? this.newPos.schedule.posSatBreak : 'N/A') : (this.newPos.schedule.posD2DSatNoWorking) == 'Yes' ? 'Not a Working Day'
        : (this.newPos.schedule.posD2DSatBreak ? this.newPos.schedule.posD2DSatBreak : 'N/A')
    this.newPos.schedule.posD2DSatAppointment = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posSatNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posSatAppointment
      ? this.newPos.schedule.posSatAppointment : 'N/A') : (this.newPos.schedule.posD2DSatNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posD2DSatAppointment ? this.newPos.schedule.posD2DSatAppointment : 'N/A')
    this.newPos.schedule.posD2DSunShift1 = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posSunNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posSunShift1
      ? this.newPos.schedule.posSunShift1 : 'N/A') : (this.newPos.schedule.posD2DSunNoWorking) == 'Yes' ? 'Not a Working Day'
        : (this.newPos.schedule.posD2DSunShift1 ? this.newPos.schedule.posD2DSunShift1 : 'N/A')
    this.newPos.schedule.posD2DSunBreak = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posSunNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posSunBreak
      ? this.newPos.schedule.posSunBreak : 'N/A') : (this.newPos.schedule.posD2DSunNoWorking) == 'Yes' ? 'Not a Working Day'
        : (this.newPos.schedule.posD2DSunBreak ? this.newPos.schedule.posD2DSunBreak : 'N/A')
    this.newPos.schedule.posD2DThuShift1 = (this.newPos.schedule.isStandard) === 'Yes' ? ((this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMonFriShift1
      ? this.newPos.schedule.posMonFriShift1 : 'N/A')) : (this.newPos.schedule.posD2DThuNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posD2DThuShift1 ? this.newPos.schedule.posD2DThuShift1 : 'N/A')
    this.newPos.schedule.posD2DWedBreak = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMoFriBreak
      ? this.newPos.schedule.posMoFriBreak : 'N/A') : (this.newPos.schedule.posD2DWedNoWorking) === 'Yes' ? 'Not a Working Day'
        : (this.newPos.schedule.posD2DWedBreak ? this.newPos.schedule.posD2DWedBreak : 'N/A')
    this.newPos.schedule.posD2DWedAppointment = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMoFriAppointment
      ? this.newPos.schedule.posMoFriAppointment : 'N/A') : (this.newPos.schedule.posD2DWedNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posD2DWedAppointment ? this.newPos.schedule.posD2DWedAppointment : 'N/A');
    this.newPos.schedule.posD2DThuBreak = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMoFriBreak
      ? this.newPos.schedule.posMoFriBreak : 'N/A') : (this.newPos.schedule.posD2DThuNoWorking) == 'Yes' ? 'Not a Working Day'
        : (this.newPos.schedule.posD2DThuBreak ? this.newPos.schedule.posD2DThuBreak : 'N/A')
    this.newPos.schedule.posD2DWedShift1 = (this.newPos.schedule.isStandard) === 'Yes' ? ((this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMonFriShift1
      ? this.newPos.schedule.posMonFriShift1 : 'N/A')) : (this.newPos.schedule.posD2DWedNoWorking) === 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posD2DWedShift1 ? this.newPos.schedule.posD2DWedShift1 : 'N/A');
    this.newPos.schedule.posD2DTuAppointment = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMoFriAppointment
      ? this.newPos.schedule.posMoFriAppointment : 'N/A') : (this.newPos.schedule.posD2DTuNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posD2DTuAppointment ? this.newPos.schedule.posD2DTuAppointment : 'N/A')
    this.newPos.schedule.posD2DTuBreak = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMoFriBreak
      ? this.newPos.schedule.posMoFriBreak : 'N/A') : (this.newPos.schedule.posD2DTuNoWorking) == 'Yes' ? 'Not a Working Day'
        : (this.newPos.schedule.posD2DTuBreak ? this.newPos.schedule.posD2DTuBreak : 'N/A');
    this.newPos.schedule.posD2DMoShift1 = (this.newPos.schedule.isStandard) === 'Yes' ? ((this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMonFriShift1
      ? this.newPos.schedule.posMonFriShift1 : 'N/A')) : (this.newPos.schedule.posD2DMoNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posD2DMoShift1 ? this.newPos.schedule.posD2DMoShift1 : 'N/A')
    this.newPos.schedule.posD2DMoBreak ? this.newPos.schedule.posD2DMoBreak : this.newPos.schedule.posD2DMoBreak = 'NA',
      this.newPos.schedule.posD2DMoAppointment = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMoFriAppointment
        ? this.newPos.schedule.posMoFriAppointment : 'N/A') : (this.newPos.schedule.posD2DMoNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posD2DMoAppointment ? this.newPos.schedule.posD2DMoAppointment : 'N/A');
    this.newPos.schedule.posD2DTuShift1 = (this.newPos.schedule.isStandard) === 'Yes' ? ((this.newPos.schedule.posMoFriNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posMonFriShift1
      ? this.newPos.schedule.posMonFriShift1 : 'N/A')) : (this.newPos.schedule.posD2DTuNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posD2DTuShift1 ? this.newPos.schedule.posD2DTuShift1 : 'N/A')
    this.newPos.schedule.posD2DSunAppointment = (this.newPos.schedule.isStandard) === 'Yes' ? (this.newPos.schedule.posSunNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posSunAppointment
      ? this.newPos.schedule.posSunAppointment : 'N/A') : (this.newPos.schedule.posD2DSunNoWorking) == 'Yes' ? 'Not a Working Day' : (this.newPos.schedule.posD2DSunAppointment ? this.newPos.schedule.posD2DSunAppointment : 'N/A')

    //  if(this.newPos.schedule.isStandard == 'Yes'){
    //   if(this.newPos.schedule.posMoFriNoWorking === 'Yes'){
    //     this.newPos.schedule.posMoFriNoWorking='Not a Working Day';
    //   } 
    //   else {
    //     this.newPos.schedule.posD2DMoShift1=(this.newPos.schedule.posMonFriShift1)?this.newPos.schedule.posMonFriShift1:'NA';
    //     this.newPos.schedule.posMoFriBreak=(this.newPos.schedule.posMoFriBreak)?this.newPos.schedule.posMoFriBreak:'NA';
    //     this.newPos.schedule.posMoFriAppointment=(this.newPos.schedule.posMoFriAppointment)?this.newPos.schedule.posMoFriAppointment:'NA';
    //     this.newPos.schedule.posSatShift1=(this.newPos.schedule.posSatShift1)?this.newPos.schedule.posSatShift1:'NA';
    //     this.newPos.schedule.posSatBreak=(this.newPos.schedule.posSatBreak)?this.newPos.schedule.posSatBreak:'NA';
    //     this.newPos.schedule.posD2DSatAppointment=(this.newPos.schedule.posD2DSatAppointment)?this.newPos.schedule.posD2DSatAppointment:'NA';
    //     this.newPos.schedule.posSunShift1=(this.newPos.schedule.posSunShift1)?this.newPos.schedule.posSunShift1:'NA';
    //     this.newPos.schedule.posSunBreak=(this.newPos.schedule.posSunBreak)?this.newPos.schedule.posSunBreak:'NA';
    //     this.newPos.schedule.posD2DMoBreak=(this.newPos.schedule.posSunAppointment)?this.newPos.schedule.posSunAppointment:'NA';
    //   }
    // }
    // else if(this.newPos.schedule.posD2DMoNoWorking == 'Yes'){

    // }
    this.posD2DThuNoWorking = this.newPos.schedule.posD2DThuNoWorking;
    this.posD2DMoBreak = this.newPos.schedule.posD2DMoBreak
    this.posD2DThuAppointment = this.newPos.schedule.posD2DThuAppointment
    this.posD2DFriShift1 = this.newPos.schedule.posD2DFriShift1
    this.posD2DFriBreak = this.newPos.schedule.posD2DFriBreak
    this.posD2DFriAppointment = this.newPos.schedule.posD2DFriAppointment
    this.posD2DSatShift1 = this.newPos.schedule.posD2DSatShift1
    this.posD2DSatBreak = this.newPos.schedule.posD2DSatBreak
    this.posD2DSatAppointment = this.newPos.schedule.posD2DSatAppointment
    this.posD2DSunShift1 = this.newPos.schedule.posD2DSunShift1
    this.posD2DSunBreak = this.newPos.schedule.posD2DSunBreak
    this.posD2DThuShift1 = this.newPos.schedule.posD2DThuShift1
    this.posD2DWedBreak = this.newPos.schedule.posD2DWedBreak
    this.posD2DWedAppointment = this.newPos.schedule.posD2DWedAppointment
    this.posD2DThuBreak = this.newPos.schedule.posD2DThuBreak
    this.posD2DWedShift1 = this.newPos.schedule.posD2DWedShift1
    this.posD2DTuAppointment = this.newPos.schedule.posD2DTuAppointment
    this.posD2DTuBreak = this.newPos.schedule.posD2DTuBreak
    this.posD2DMoShift1 = this.newPos.schedule.posD2DMoShift1
    this.posD2DMoBreak = this.newPos.schedule.posD2DMoBreak
    this.posD2DMoAppointment = this.newPos.schedule.posD2DMoAppointment
    this.posD2DTuShift1 = this.newPos.schedule.posD2DTuShift1


  }

  getAddress() {
    this.address = `${this.newPos.streetNumber ? (this.newPos.streetNumber) : '-'}`;
    this.address1 = `${this.newPos.streetNumberSuffix ? (this.newPos.streetNumberSuffix) : ''}`;
    this.chain = this.newPos.posChainNameFr!==null ? this.newPos.posChainNameFr == '-' || this.newPos.posChainNameFr == 'N/A' ? this.translate.instant('Select') : this.newPos.posChainNameFr : this.translate.instant('Select');
    if (this.chain == this.translate.instant('Select')) {
      let index;
      for (let i = 0; i < this.chainNames.length; i++) {
        if (this.chainNames[i].answer == this.translate.instant('Select')) {
          index = i;
          break;
        }
      }
      this.chainNames.splice(index, 1);
    }
    this.adType= this.newPos.adType !== null ? this.newPos.adType : '-';
    (this.browserLang == 'fr')? this.name = this.newPos.posNameFr ? this.newPos.posNameFr : 'N/A': 
    (this.browserLang == 'nl')? this.name = this.newPos.posNameNl ? this.newPos.posNameNl : 'N/A' :
    (this.browserLang == 'en')? this.name = this.newPos.posNameEn ? this.newPos.posNameEn : 'N/A' : 'N/A';
    (this.browserLang == 'fr')? this.oldPos.posNameFr = this.oldPos.posNameFr ? this.oldPos.posNameFr : 'N/A': 
    (this.browserLang == 'nl')? this.oldPos.posNameFr = this.oldPos.posNameNl ? this.oldPos.posNameNl : 'N/A' :
    (this.browserLang == 'en')? this.oldPos.posNameFr = this.oldPos.posNameEn ? this.oldPos.posNameEn : 'N/A' : 'N/A';
    if(this.newPos.posNameEn == ('Destroyed local') || this.newPos.posNameEn == ('Non commercial activity') || this.newPos.posNameEn == ('Merged local') || this.newPos.posNameEn == ('Error')){
      this.rightPanelBlank=true;
      this.dateSelected=false;
    }
    if((this.newPos.isEmptyCell=='YES' && this.newPos.posChooseSituation==null) || this.newPos.isNew=='YES'){
      this.leftPanelBlank=true;
    }
    if(this.newPos.posChooseSituation == 'I cant see the shop and its information' || this.newPos.posChooseSituation == 'The space is under renovation'){
      this.dateSelected=false;
    }
    this.seven = this.newPos.schedule.days77;
    this.twenty = this.newPos.schedule.hours2424;
    this.postyp1 = this.newPos.posType1;
    this.postype2 = this.newPos.posType2
    this.postype3 = this.newPos.posType3;
    this.postype4 = this.newPos.posType4;
    this.cell = this.newPos.isEmptyCell;
    this.cell1 = this.oldPos.isEmptyCell;
    this.cell=='YES'? this.dateSelected=false:false;
    this.add = this.newPos.ads;
    this.phn = this.newPos.contact.q2_dontWantToDisclose;
    this.mail = this.newPos.contact.q3_dontWantToDisclose;
    this.web = this.newPos.contact.q4_dontWantToDisclose;
  }

  selectedAgent;
  selectAgentId;
  toggleTags(user) {
    this.tag = true;
    let flag;
    for (let element of this.tagUpdated) {
      if (element == `${user.answer}`) {
        this.tagupdated = this.translate.instant('Select');
        flag = true;
      }
    }
    if (flag !== true) {
      this.tagupdated = `${user.answer}`;
      this.tagUpdated.push(`${user.answer}`);
    }
    this.tagsNew = '';
    for (let tag of this.tagUpdated) {
      this.tagsNew =
        this.tagsNew + this.translate.instant(tag) + ', ';
    }
    this.tagsNew = this.tagsNew.slice(0, -2);
    if (this.newPos.posTaglineFr !== this.tagsNew) {
      this.updatedTag = true;
    }
    this.newPos.posTaglineFr = this.tagsNew;
    this.facadeAnswersUI = user.id
  }

  adrn=[];
  toggleChaniName(user) {
    this.chainName = true;
    this.selectedName = `${user.answer}`
    this.chain = this.selectedName;
    if (this.chain == this.translate.instant('Select')) {
      let index;
      for (let i = 0; i < this.chainNames.length; i++) {
        if (this.chainNames[i].answer == this.translate.instant('Select')) {
          index = i;
          break;
        }
      }
      this.chainNames.splice(index, 1);
      this.chain = null
    }
    else {
      this.chainNames.unshift({ 'answer': this.translate.instant('Select') });
    }
    this.adrn =_.uniqBy( this.chainNames,'answer');
    this.chainNames=this.adrn;
    let chain = this.newPos.posChainNameFr ? this.newPos.posChainNameFr : this.translate.instant('Select');
    this.chain !== chain ? this.updatedChain = true : false;
  }

  toggleFieldAgent(user, facadeQ) {

    if (facadeQ == 'facadeQ1') {
      this.q1Selected = true;
      this.selectedQ1 = `${user.answer}`
    }
    else if (facadeQ == 'facadeQ2') {
      this.q2Selected = true;
      this.selectedQ2 = `${user.answer}`
    }
    this.facadeAnswersUI = user.id
  }

  toggleContextAns(user, facadeQ) {

    if (facadeQ == 'contextQ3') {
      this.contectQ3Selected = true;
      this.selectedContextQ3 = `${user.answer}`
    }
    else if (facadeQ == 'contextQ4') {
      this.contectQ4Selected = true;
      this.selectedContextQ4 = `${user.answer}`
    }
    else if (facadeQ == 'contextQ5') {
      this.contectQ5Selected = true;
      this.selectedContextQ5 = `${user.answer}`
    }
    else if (facadeQ == 'contextQ6') {
      this.contectQ6Selected = true;
      this.selectedContextQ6 = `${user.answer}`
    }
    this.facadeAnswersUI = user.id
  }

  toggleAccessAns(user, facadeQ) {

    if (facadeQ == 'accessQ1') {
      this.accessQ1Selected = true;
      this.selectedaccessQ1 = `${user.answer}`
    }
    else if (facadeQ == 'accessQ2') {
      this.accessQ2Selected = true;
      this.selectedaccessQ2 = `${user.answer}`
    }
    else if (facadeQ == 'accessQ3') {
      this.accessQ3Selected = true;
      this.selectedaccessQ3 = `${user.answer}`
    }
    else if (facadeQ == 'accessQ4') {
      this.accessQ4Selected = true;
      this.selectedaccessQ4 = `${user.answer}`
    }
    else if (facadeQ == 'accessQ5') {
      this.accessQ5Selected = true;
      this.selectedaccessQ5 = `${user.answer}`
    }
    else if (facadeQ == 'accessQ6') {
      this.accessQ6Selected = true;
      this.selectedaccessQ6 = `${user.answer}`
    }

    this.facadeAnswersUI = user.id
  }

  toggleCounterAns(user, facadeQ) {

    if (facadeQ == 'counterQ1') {
      this.counterQ1Selected = true;
      this.selectedcounterQ1 = `${user.answer}`
    }
    else if (facadeQ == 'counterQ2') {
      this.counterQ2Selected = true;
      this.selectedcounterQ2 = `${user.answer}`
    }
    else if (facadeQ == 'counterQ3') {
      this.counterQ3Selected = true;
      this.selectedcounterQ3 = `${user.answer}`
    }
    else if (facadeQ == 'counterQ4') {
      this.counterQ4Selected = true;
      this.selectedcounterQ4 = `${user.answer}`
    }
    else if (facadeQ == 'counterQ5') {
      this.counterQ5Selected = true;
      this.selectedcounterQ5 = `${user.answer}`
    }
    else if (facadeQ == 'counterQ6') {
      this.counterQ6Selected = true;
      this.selectedcounterQ6 = `${user.answer}`
    }

    this.facadeAnswersUI = user.id
  }

  toggleFloorAns(user, facadeQ) {
    if (facadeQ == 'floorQ1') {
      this.floorQ1Selected = true;
      this.selectedfloorQ1 = `${user.answer}`
    }
    else if (facadeQ == 'floorQ2') {
      this.floorQ2Selected = true;
      this.selectedfloorQ2 = `${user.answer}`
    }
    else if (facadeQ == 'floorQ3') {
      this.floorQ3Selected = true;
      this.selectedfloorQ3 = `${user.answer}`
    }
    else if (facadeQ == 'floorQ4') {
      this.floorQ4Selected = true;
      this.selectedfloorQ4 = `${user.answer}`
    }
    else if (facadeQ == 'floorQ5') {
      this.floorQ5Selected = true;
      this.selectedfloorQ5 = `${user.answer}`
    }

    this.facadeAnswersUI = user.id
  }

  toggleContactAns(user, facadeQ) {

    if (facadeQ == 'contactQ1') {
      this.contactQ1Selected = true;
      this.selectedcontactQ1 = `${user.answer}`
      if (this.newPos.contact.q5 !== user.id) {
        this.updatedContact = true;
      }
      this.newPos.contact.q5 = `${user.id}`
    }
    else if (facadeQ == 'contactQ2') {
      this.contactQ2Selected = true;
      this.selectedcontactQ2 = `${user.answer}`
    }
    else if (facadeQ == 'contactQ3') {
      this.contactQ3Selected = true;
      this.selectedcontactQ3 = `${user.answer}`
    }
    else if (facadeQ == 'contactQ4') {
      this.contactQ4Selected = true;
      this.selectedcontactQ4 = `${user.answer}`
    }
    else if (facadeQ == 'contactQ5') {
      this.contactQ5Selected = true;
      this.selectedcontactQ5 = `${user.answer}`
    }
    else if (facadeQ == 'contactQ6') {
      this.contactQ6Selected = true;
      this.selectedcontactQ6 = `${user.answer}`
    }

    this.facadeAnswersUI = user.id
  }

  togglePaymentAns(user, facadeQ) {

    if (facadeQ == 'paymentQ1') {
      this.paymentQ1Selected = true;
      this.selectedpaymentQ1 = `${user.answer}`
    }
    else if (facadeQ == 'paymentQ2') {
      this.paymentQ2Selected = true;
      this.selectedpaymentQ2 = `${user.answer}`
    }
    else if (facadeQ == 'paymentQ3') {
      this.paymentQ3Selected = true;
      this.selectedpaymentQ3 = `${user.answer}`
    }
    else if (facadeQ == 'paymentQ4') {
      this.paymentQ4Selected = true;
      this.selectedpaymentQ4 = `${user.answer}`
    }
    else if (facadeQ == 'paymentQ5') {
      this.paymentQ5Selected = true;
      this.selectedpaymentQ5 = `${user.answer}`
    }
    else if (facadeQ == 'paymentQ6') {
      this.paymentQ6Selected = true;
      this.selectedpaymentQ6 = `${user.answer}`
    }

    this.facadeAnswersUI = user.id
  }

  togglehistoricAns(user, facadeQ) {

    if (facadeQ == 'historicQ1') {
      this.historicQ1Selected = true;
      this.selectedhistoricQ1 = `${user.answer}`
    }
    else if (facadeQ == 'historicQ2') {
      this.historicQ2Selected = true;
      this.selectedhistoricQ2 = `${user.answer}`
    }
    else if (facadeQ == 'historicQ3') {
      this.historicQ3Selected = true;
      this.selectedhistoricQ3 = `${user.answer}`
    }
    else if (facadeQ == 'historicQ4') {
      this.historicQ4Selected = true;
      this.selectedhistoricQ4 = `${user.answer}`
    }
    else if (facadeQ == 'historicQ5') {
      this.historicQ5Selected = true;
      if (this.newPos.historic.q5 !== user.id) {
        this.updatedHistoric = true;
      }
      this.selectedhistoricQ5 = `${user.answer}`
      this.newPos.historic.q5 = `${user.id}`
    }
    else if (facadeQ == 'historicQ6') {
      this.historicQ6Selected = true;
      this.selectedhistoricQ6 = `${user.answer}`
      if (this.newPos.historic.q6 !== user.id) {
        this.updatedHistoricQ6 = true;
      }
      this.newPos.historic.q6 = `${user.id}`
    }

    this.facadeAnswersUI = user.id
  }

  togglelevel(user, facadeQ) {
    if (facadeQ == 'postype31') {
      this.dateSelected=true;
      this.selectedLeve31 = true;
      this.leve31Selected = `${user.answer}`;

      if (this.postyp1 !== this.leve31Selected) {
        this.updatedPosType1 = true;
      }
      this.newPos.posType1 = this.leve31Selected;
      for (let lvl3 of this.level3) {
        if (this.translate.instant(this.leve31Selected) === lvl3.answer) {
          for (let lvl2 of this.level2) {
            if (lvl3.lvl2ID == lvl2.id) {
              this.level2s[2] = (lvl2.answer);
            }
          }
          for (let lvl1 of this.level1) {
            if (lvl3.lvl1ID == lvl1.id) {
              this.level1s[2] = (lvl1.answer);
            }
          }
        }
      }

    }
    if (facadeQ == 'postype32') {
      this.dateSelected1=true;
      this.selectedLeve32 = true;
      this.leve32Selected = `${user.answer}`;
      if (this.postype2 !== this.leve32Selected) {
        this.updatedPosType2 = true;
      }
      this.newPos.posType2 = this.leve32Selected;
      for (let lvl3 of this.level3) {
        if (this.translate.instant(this.leve32Selected) === lvl3.answer) {
          for (let lvl2 of this.level2) {
            if (lvl3.lvl2ID == lvl2.id) {
              this.level2s[0] = (lvl2.answer);
            }
          }
          for (let lvl1 of this.level1) {
            if (lvl3.lvl1ID == lvl1.id) {
              this.level1s[0] = (lvl1.answer);
            }
          }
        }
      }
    }
    if (facadeQ == 'postype33') {
      this.dateSelected2=true;
      this.selectedLeve33 = true;
      this.leve33Selected = `${user.answer}`;
      if (this.postype3 !== this.leve33Selected) {
        this.updatedPosType3 = true;
      }
      this.newPos.posType3 = this.leve33Selected;
      for (let lvl3 of this.level3) {
        if (this.translate.instant(this.leve33Selected) === lvl3.answer) {
          for (let lvl2 of this.level2) {
            if (lvl3.lvl2ID == lvl2.id) {
              this.level2s[1] = (lvl2.answer);
            }
          }
          for (let lvl1 of this.level1) {
            if (lvl3.lvl1ID == lvl1.id) {
              this.level1s[1] = (lvl1.answer);
            }
          }
        }
      }
    }
    if (facadeQ == 'postype34') {
      this.dateSelected3=true;
      this.selectedLeve34 = true;
      this.leve34Selected = `${user.answer}`;
      if (this.postype4 !== this.leve34Selected) {
        this.updatedPosType4 = true;
      }
      this.newPos.posType4 = this.leve34Selected;
      for (let lvl3 of this.level3) {
        if (this.translate.instant(this.leve34Selected) === lvl3.answer) {
          for (let lvl2 of this.level2) {
            if (lvl3.lvl2ID == lvl2.id) {
              this.level2s[3] = (lvl2.answer);
            }
          }
          for (let lvl1 of this.level1) {
            if (lvl3.lvl1ID == lvl1.id) {
              this.level1s[3] = (lvl1.answer);
            }
          }
        }
      }
    }
    if (facadeQ == 'postype21') {
      this.dateSelected=true;
      // this.level21 = this.level2;
      this.selectedLeve21 = true;
      this.leve21Selected = `${user.answer}`;
      for (let lvl2 of this.level2) {
        if (this.translate.instant(this.leve21Selected) === lvl2.answer) {
          this.level31 = [];
          for (let lvl3 of this.level3) {
            if (lvl3.lvl2ID == lvl2.id) {
              this.selectedLeve31 = false;
              this.newPos.posType1 = this.translate.instant('Select');
              this.level31.push(lvl3);
            }
          }
          if (this.postyp1 !== this.newPos.posType1) {
            this.updatedPosType1 = true;
          }
          for (let lvl1 of this.level1) {
            if (lvl2.lvl1ID == lvl1.id) {
              this.selectedLeve11 = false;
              this.level1s[2] = (lvl1.answer);
            }
          }
          // this.level31  =  this.level31.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
        }
      }
    }
    if (facadeQ == 'postype22') {
      this.dateSelected1=true;
      // this.level22 = this.level2;
      this.selectedLeve22 = true;
      this.leve22Selected = `${user.answer}`;
      for (let lvl2 of this.level2) {
        if (this.translate.instant(this.leve22Selected) === lvl2.answer) {
          this.level32 = [];
          for (let lvl3 of this.level3) {
            if (lvl3.lvl2ID == lvl2.id) {
              this.selectedLeve32 = false;
              this.newPos.posType2 = this.translate.instant('Select');
              this.level32.push(lvl3);
            }
          }
          if (this.postype2 !== this.newPos.posType2) {
            this.updatedPosType2 = true;
          }
          for (let lvl1 of this.level1) {
            if (lvl2.lvl1ID == lvl1.id) {
              this.selectedLeve12 = false;
              this.level1s[0] = (lvl1.answer);
            }
          }
          // this.level32  =  this.level32.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
        }
      }
    }
    if (facadeQ == 'postype23') {
      this.dateSelected2=true;
      // this.level23 = this.level2;
      this.selectedLeve23 = true;
      this.leve23Selected = `${user.answer}`;
      for (let lvl2 of this.level2) {

        if (this.translate.instant(this.leve23Selected) === lvl2.answer) {
          this.level33 = [];
          for (let lvl3 of this.level3) {
            if (lvl3.lvl2ID == lvl2.id) {
              this.selectedLeve33 = false;
              this.newPos.posType3 = this.translate.instant('Select');
              this.level33.push(lvl3);
            }
          }
          if (this.postype3 !== this.newPos.posType3) {
            this.updatedPosType3 = true;
          }
          for (let lvl1 of this.level1) {
            if (lvl2.lvl1ID == lvl1.id) {
              this.selectedLeve13 = false;
              this.level1s[1] = (lvl1.answer);
            }
          }
          // this.level33  =  this.level33.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
        }
      }
    }
    if (facadeQ == 'postype24') {
      this.dateSelected3=true;
      // this.level24 = this.level2;
      this.selectedLeve24 = true;
      this.leve24Selected = `${user.answer}`;
      for (let lvl2 of this.level2) {
        if (this.translate.instant(this.leve24Selected) === lvl2.answer) {
          this.level34 = [];
          for (let lvl3 of this.level3) {
            if (lvl3.lvl2ID == lvl2.id) {
              this.selectedLeve34 = false;
              this.newPos.posType4 = this.translate.instant('Select');
              this.level34.push(lvl3);
            }
          }
          if (this.postype4 !== this.newPos.posType4) {
            this.updatedPosType4 = true;
          }
          for (let lvl1 of this.level1) {
            if (lvl2.lvl1ID == lvl1.id) {
              this.selectedLeve14 = false;
              this.level1s[3] = (lvl1.answer);
            }
          }
          // this.level34  =  this.level34.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
        }
      }
    }
    if (facadeQ == 'postype11') {
      this.dateSelected=true;
      this.level11 = this.level1;
      // this.level11  =  this.level11.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
      this.selectedLeve11 = true;
      this.leve11Selected = `${user.answer}`;

      for (let lvl1 of this.level1) {
        if (this.translate.instant(this.leve11Selected) === lvl1.answer) {
          this.level31 = [];
          for (let lvl3 of this.level3) {
            if (lvl3.lvl1ID == lvl1.id) {
              this.selectedLeve31 = false;
              this.newPos.posType1 = this.translate.instant('Select');
              this.level31.push(lvl3);
            }
          }
          if (this.postyp1 !== this.newPos.posType1) {
            this.updatedPosType1 = true;
          }
          this.level21 = [];
          for (let lvl2 of this.level2) {
            if (lvl2.lvl1ID == lvl1.id) {
              this.selectedLeve21 = false;
              this.level2s[2] = this.translate.instant('Select');
              this.level21.push(lvl2);
            }
          }
          // this.level21  =  this.level21.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
          // this.level31  =  this.level31.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
        }
      }
    }
    if (facadeQ == 'postype12') {
      this.dateSelected1=true;
      this.level12 = this.level1;
      // this.level12  =  this.level12.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
      this.selectedLeve12 = true;
      this.leve12Selected = `${user.answer}`;

      for (let lvl1 of this.level1) {
        if (this.translate.instant(this.leve12Selected) === lvl1.answer) {
          this.level32 = [];
          for (let lvl3 of this.level3) {
            if (lvl3.lvl1ID == lvl1.id) {
              this.selectedLeve32 = false;
              this.newPos.posType2 = this.translate.instant('Select');
              this.level32.push(lvl3);
            }
          }
          if (this.postype2 !== this.newPos.posType2) {
            this.updatedPosType2 = true;
          }
          this.level22 = [];
          for (let lvl2 of this.level2) {
            if (lvl2.lvl1ID == lvl1.id) {
              this.selectedLeve22 = false;
              this.level2s[0] = this.translate.instant('Select');
              this.level22.push(lvl2);
            }
          }
          // this.level32  =  this.level32.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
          // this.level22  =  this.level22.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
        }
      }
    }
    if (facadeQ == 'postype13') {
      this.dateSelected2=true;
      this.level13 = this.level1;
      // this.level13  =  this.level13.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
      this.selectedLeve13 = true;
      this.leve13Selected = `${user.answer}`;

      for (let lvl1 of this.level1) {
        if (this.translate.instant(this.leve13Selected) === lvl1.answer) {
          this.level33 = [];
          for (let lvl3 of this.level3) {
            if (lvl3.lvl1ID == lvl1.id) {
              this.selectedLeve33 = false;
              this.newPos.posType3 = this.translate.instant('Select');
              this.level33.push(lvl3);
            }
          }
          if (this.postype3 !== this.newPos.posType3) {
            this.updatedPosType3 = true;
          }
          this.level23 = [];
          for (let lvl2 of this.level2) {
            if (lvl2.lvl1ID == lvl1.id) {
              this.selectedLeve23 = false;
              this.level2s[1] = this.translate.instant('Select');
              this.level23.push(lvl2);
            }
          }
          // this.level23  =  this.level23.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
          // this.level33  =  this.level33.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
        }
      }
    }
    if (facadeQ == 'postype14') {
      this.dateSelected3=true;
      this.level14 = this.level1;
      // this.level14  =  this.level14.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
      this.selectedLeve14 = true;
      this.leve14Selected = `${user.answer}`;
      for (let lvl1 of this.level1) {
        if (this.translate.instant(this.leve14Selected) === lvl1.answer) {
          this.level34 = [];
          for (let lvl3 of this.level3) {
            if (lvl3.lvl1ID == lvl1.id) {
              this.selectedLeve34 = false;
              this.newPos.posType4 = this.translate.instant('Select');
              this.level34.push(lvl3);
            }
          }
          if (this.postype4 !== this.newPos.posType4) {
            this.updatedPosType4 = true;
          }
          this.level24 = [];
          for (let lvl2 of this.level2) {
            if (lvl2.lvl1ID == lvl1.id) {
              this.selectedLeve24 = false;
              this.level2s[3] = this.translate.instant('Select');
              this.level24.push(lvl2);
            }
          }
          // this.level34  =  this.level34.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
          // this.level24  =  this.level24.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
        }
      }
    }
    this.facadeAnswersUI = user.id
  }
 
  translateTags() {
    ///...New POS Tags...///
    if (this.newPos.posTaglineFr) {
      let newTags = this.newPos.posTaglineFr.split(',');
      //console.log(newTags);
      const count = 0;
      for (let tag of newTags) {
        this.tanslatedTagsNew =
          this.tanslatedTagsNew + this.translate.instant(tag) + ', ';
        this.tagUpdated.push(this.translate.instant(tag));
      }
      this.tanslatedTagsNew = this.tanslatedTagsNew.slice(0, -2);
    }

    ///...Old POS Tags...///
    if (this.oldPos.posTaglineFr) {
      let oldTags = this.oldPos.posTaglineFr.split(',');
      //console.log(oldTags);
      for (let tag of oldTags) {
        this.tanslatedTagsOld =
          this.tanslatedTagsOld + this.translate.instant(tag) + ', ';
          this.tagUpdated1.push(this.translate.instant(tag));
      }
      this.tanslatedTagsOld = this.tanslatedTagsOld.slice(0, -2);
      //console.log(this.tanslatedTagsOld);
    }
  }

  oldPosType1 = [];
  oldPosType2 = [];
  oldPosType3 = [];
  oldPosType4 = [];
  getLevels(newPos,oldPos) {
    let level2s;
    this.level31 = []; this.level32 = []; this.level33 = []; this.level34 = [];
    this.level21 = []; this.level22 = []; this.level23 = []; this.level24 = [];
    if(this.name !==this.translate.instant('Empty cell') || this.name==this.translate.instant('Empty Unit')){
      this.level11.forEach((element, index) => {
      element.answer == this.translate.instant('Empty Unit')? this.level11.splice(index,1): false;
    });
    this.level11.forEach((element, index) => {
      element.answer == this.translate.instant('Empty cell')? this.level11.splice(index,1): false;
    });
    //level 2
    this.level12.forEach((element, index) => {
      element.answer == this.translate.instant('Empty Unit')? this.level12.splice(index,1): false ;
    });
    this.level12.forEach((element, index) => {
      element.answer == this.translate.instant('Empty cell')? this.level12.splice(index,1): false ;
    });
    //level 3 
    this.level13.forEach((element, index) => {
      element.answer == this.translate.instant('Empty Unit')? this.level13.splice(index,1): false;
    });
    this.level13.forEach((element, index) => {
      element.answer == this.translate.instant('Empty cell')? this.level13.splice(index,1): false;
    });
    //level4
    this.level14.forEach((element, index) => {
      element.answer == this.translate.instant('Empty Unit')? this.level14.splice(index,1): false;
    });
    this.level14.forEach((element, index) => {
      element.answer == this.translate.instant('Empty cell')? this.level14.splice(index,1): false;
    });
  }

    for (let lvl3 of this.level3) {
      if (newPos.posType1 && this.translate.instant(newPos.posType1) === lvl3.answer) {
        let postType1;
        
        for (let lvl1 of this.level1) {
          if (lvl3.lvl1ID == lvl1.id) {
            this.level1s['2'] = (lvl1.answer);
            postType1 = lvl1.id;
            break;
          }
        }
        for (let lvl2 of this.level2) {
          if (lvl3.lvl2ID == lvl2.id) {
            this.level2s['2'] = (lvl2.answer);
          }
          // (lvl2.lvl1ID == postType1) ? this.level21.push(lvl2) : false;
          var newArray = this.level2.filter(function (el) {
            return el.lvl1ID === lvl3.lvl1ID;
          });
          this.level21=newArray;
          // delete this.level21[this.level21.indexOf(this.translate.instant('Empty Unit'))];
          // delete this.level21[this.level21.indexOf(this.translate.instant('Empty cell'))];
        }
        // this.level21 = this.level21.filter(item => item.answer == this.translate.instant('Empty Unit') || item.answer == this.translate.instant('Empty cell'));
        var newArray1 = this.level3.filter(function (el) {
          return el.lvl2ID === lvl3.lvl2ID;
        });
        this.level31=newArray1;
        // delete this.level31[this.level31.indexOf(this.translate.instant('Empty Unit'))];
        // delete this.level31[this.level31.indexOf(this.translate.instant('Empty cell'))];
      }
      if (newPos.posType2 && this.translate.instant(newPos.posType2) === lvl3.answer) {
        let postType2;
        for (let lvl1 of this.level1) {
          if (lvl3.lvl1ID == lvl1.id) {
            this.level1s['0'] = (lvl1.answer);
            postType2 = lvl1.id;
            break;
          }
        }
        for (let lvl2 of this.level2) {
          if (lvl3.lvl2ID == lvl2.id) {
            this.level2s['0'] = (lvl2.answer);
          }
          // (lvl2.lvl1ID == postType2) ? this.level22.push(lvl2) : false;
          var newArray2 = this.level2.filter(function (el) {
            return el.lvl1ID === lvl3.lvl1ID;
          });
          this.level22 = newArray2;
          // delete this.level22[this.level22.indexOf(this.translate.instant('Empty Unit'))];
          // delete this.level22[this.level22.indexOf(this.translate.instant('Empty cell'))];
        }
        // this.level22  =  this.level22.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
        // (lvl3.lvl1ID == postType2) ? this.level32.push(lvl3) : false;
        var newArray3 = this.level3.filter(function (el) {
          return el.lvl2ID === lvl3.lvl2ID;
        });
        this.level32=newArray3;
        // delete this.level32[this.level32.indexOf(this.translate.instant('Empty Unit'))];
        // delete this.level32[this.level32.indexOf(this.translate.instant('Empty cell'))];
      }
      if (newPos.posType3 && this.translate.instant(newPos.posType3) === lvl3.answer) {
        let postType3;
        for (let lvl1 of this.level1) {
          if (lvl3.lvl1ID == lvl1.id) {
            this.level1s['1'] = (lvl1.answer);
            postType3 = lvl1.id;
            break;
          }
        }
        for (let lvl2 of this.level2) {
          if (lvl3.lvl2ID == lvl2.id) {
            this.level2s['1'] = (lvl2.answer);
          }
          // (lvl2.lvl1ID == postType3) ? this.level23.push(lvl2) : false;
          var newArray2 = this.level2.filter(function (el) {
            return el.lvl1ID === lvl3.lvl1ID;
          });
          this.level23 = newArray2;
          // delete this.level23[this.level23.indexOf(this.translate.instant('Empty Unit'))];
          // delete this.level23[this.level23.indexOf(this.translate.instant('Empty cell'))];
        }
        // this.level23  =  this.level23.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
        // (lvl3.lvl1ID == postType3) ? this.level33.push(lvl3) : false;
        var newArray3 = this.level3.filter(function (el) {
          return el.lvl2ID === lvl3.lvl2ID;
        });
        this.level33=newArray3;
        // delete this.level33[this.level33.indexOf(this.translate.instant('Empty Unit'))];
        // delete this.level33[this.level33.indexOf(this.translate.instant('Empty cell'))];
      }
      if (newPos.posType4 && this.translate.instant(newPos.posType4) === lvl3.answer) {
        let postType4;

        for (let lvl1 of this.level1) {
          if (lvl3.lvl1ID == lvl1.id) {
            this.level1s['3'] = (lvl1.answer);
            postType4 = lvl1.id;
            break;
          }
        }
        for (let lvl2 of this.level2) {
          if (lvl3.lvl2ID == lvl2.id) {
            this.level2s['3'] = (lvl2.answer);
          }
          // (lvl2.lvl1ID == postType4) ? this.level24.push(lvl2) : false;
          var newArray2 = this.level2.filter(function (el) {
            return el.lvl1ID === lvl3.lvl1ID;
          });
          this.level24 = newArray2;
          // delete this.level24[this.level24.indexOf(this.translate.instant('Empty Unit'))];
          // delete this.level24[this.level24.indexOf(this.translate.instant('Empty cell'))];
        }
        // this.level24  =  this.level24.filter(item => item.answer ==  this.translate.instant('Empty Unit') || item.answer ==  this.translate.instant('Empty cell'));
        // (lvl3.lvl1ID == postType4) ? this.level34.push(lvl3) : false;
        var newArray3 = this.level3.filter(function (el) {
          return el.lvl2ID === lvl3.lvl2ID;
        });
        this.level34=newArray3;
        // delete this.level34[this.level24.indexOf(this.translate.instant('Empty Unit'))];
        // delete this.level34[this.level24.indexOf(this.translate.instant('Empty cell'))];
      }
      if (oldPos.posType1 && this.translate.instant(oldPos.posType1) === lvl3.answer) {
        this.oldPosType1['3'] = (oldPos.posType1);
        for (let lvl1 of this.level1) {
          if (lvl3.lvl1ID == lvl1.id) {
            this.oldPosType1['1'] = (lvl1.answer);
            break;
          }
        }
        for (let lvl2 of this.level2) {
          if (lvl3.lvl2ID == lvl2.id) {
            this.oldPosType1['2'] = (lvl2.answer);
          }
          // (lvl2.lvl1ID == postType1) ? this.level21.push(lvl2) : false;
        }
      }
      if (oldPos.posType2 && this.translate.instant(oldPos.posType2) === lvl3.answer) {
        this.oldPosType2['3'] = (oldPos.posType2);
        for (let lvl1 of this.level1) {
          if (lvl3.lvl1ID == lvl1.id) {
            this.oldPosType2['1'] = (lvl1.answer);
            break;
          }
        }
        for (let lvl2 of this.level2) {
          if (lvl3.lvl2ID == lvl2.id) {
            this.oldPosType2['2'] = (lvl2.answer);
          }
          // (lvl2.lvl1ID == postType2) ? this.level22.push(lvl2) : false;
        }
      }
      if (oldPos.posType3 && this.translate.instant(oldPos.posType3) === lvl3.answer) {
        this.oldPosType3['3'] = (oldPos.posType3);
        for (let lvl1 of this.level1) {
          if (lvl3.lvl1ID == lvl1.id) {
            this.oldPosType3['1'] = (lvl1.answer);
            break;
          }
        }
        for (let lvl2 of this.level2) {
          if (lvl3.lvl2ID == lvl2.id) {
            this.oldPosType3['2'] = (lvl2.answer);
          }
          // (lvl2.lvl1ID == postType3) ? this.level23.push(lvl2) : false;
        }
      }
      if (oldPos.posType4 && this.translate.instant(oldPos.posType4) === lvl3.answer) {
        this.oldPosType4['3'] = (oldPos.posType4);
        for (let lvl1 of this.level1) {
          if (lvl3.lvl1ID == lvl1.id) {
            this.oldPosType4['1'] = (lvl1.answer);
            break;
          }
        }
        for (let lvl2 of this.level2) {
          if (lvl3.lvl2ID == lvl2.id) {
            this.oldPosType4['2'] = (lvl2.answer);
          }
          // (lvl2.lvl1ID == postType4) ? this.level24.push(lvl2) : false;
        }
      }
    }
  }

  checkForButton() {
    if (this.newPos.validationFlag === null && this.newPos.isUpdated === null) {
      this.showApprove = false;
    } else if (
      this.newPos.validationFlag === null &&
      this.newPos.isUpdated !== null
    ) {
      this.showApprove = true;
    }
  }

  checkUpdatedField() {

  }

  objectUpdate;
  infoSheetRejectApprove(status: number) {
    this._event.broadcast({ eventName: 'showLoader', data: {} });
    if (status === 1) {
      
      let jii = this.newPos.poiImage1 ? this.newPos.poiImage1.split('?') : this.newPos.poiImage1;
      let ji = this.newPos.poiImage2 ? this.newPos.poiImage2.split('?') : this.newPos.poiImage2;
      let ii = this.newPos.poiImage3 ? this.newPos.poiImage3.split('?') : this.newPos.poiImage3;
      let arr = jii ? this.newPos.poiImage1.substr(38, jii[0].length) : this.newPos.poiImage1;
      let poiImage2 = ji ? this.newPos.poiImage2.substr(38, ji[0].length) : this.newPos.poiImage2;
      let poiImage3 = ii ? this.newPos.poiImage3.substr(38, ii[0].length) : this.newPos.poiImage3;
      this.newPos.poiImage1 = arr;
      this.newPos.poiImage2 = poiImage2;
      this.newPos.poiImage3 = poiImage3;
      this.newPos.posChooseSituation == this.translate.instant('New Point of Sale')? this.newPos.posChooseSituation == null : false;
      // this.address1 = this.address.split(',');
      // this.newPos.streetNameFr = this.address1[0];
      this.newPos.streetNumber = this.address == '-' ||  this.address == ''? null : this.address;
      this.newPos.streetNumberSuffix = this.address1 == ''? null : this.address1;
      this.newPos.posChainNameFr = this.newPos.posChainNameFr==null?this.updatedChain? this.chain:null:this.chain;
      this.newPos.posChainNameNl = this.newPos.posChainNameFr==null?this.updatedChain? this.chain:null:this.chain;
      this.newPos.posChainNameEn = this.newPos.posChainNameFr==null?this.updatedChain? this.chain:null:this.chain;
      this.newPos.adType =this.updatedAdType ? this.adType : this.newPos.adType;
      // (this.browserLang == 'fr')?this.newPos.posNameFr = this.name:false;
      // (this.browserLang == 'nl')?this.newPos.posNameNl = this.name:false;
      // (this.browserLang == 'en')?this.newPos.posNameEn = this.name:false;
      this.newPos.posNameFr = this.name;
      this.newPos.posNameNl = this.name;
      this.newPos.posNameEn = this.name;
      this.tagsNew = '';
      for (let tag of this.tagUpdated) {
        this.tagsNew =
          this.tagsNew + this.translate.instant(tag) + ', ';
      }
      this.tagsNew = this.tagsNew.slice(0, -2);

      this.newPos.posTaglineFr = this.tagsNew;
      this.translateTags();
      let reqObject;
      if (this.validateUpdates()) {
        this.getSchedule();
        reqObject = {
          posId: this.newPos.id,
          missionId: this.missionId,
          // missionId: this.ids.missionId,
          status: status,
          newPos: this.newPos
        };
      }
      else {
        reqObject = {
          posId: this.newPos.id,
          missionId: this.missionId,
          // missionId: this.ids.missionId,
          status: status,
          newPos: null
        };
      }
      this.subscriptions.push(
        this.apiService.approveRejectInfoSheet(reqObject).subscribe(
          result => {
            if (result.responseCode == '200') {
              this.objectUpdate={
              correctedPos: result.data.correctedPos,
              evaluateFlag: result.data.evaluateFlag,
              invalidPos: result.data.invalidPos,
              validatedPos: result.data.validatedPos,
              validationFlag: result.data.validationFlag,
              posNameFr: result.data.posNameFr,
              posNameEn:result.data.posNameEn,
              posNameNl: result.data.posNameNl,
              address : result.data.address,
              posId:this.infoDetails.posId,
            }
              this.objectApproveEvent.emit(this.objectUpdate);
              // window.location.reload();
              // this.location.back();
            }
          },
          err => {
            err;
            this._event.broadcast({ eventName: 'hideLoader' });
          }
        )
      );
    }
    else {
      let reqObject = {
        posId: this.newPos.id,
        missionId: this.missionId,
        // missionId: this.ids.missionId,
        status: status
      };
      this.subscriptions.push(
        this.apiService.approveRejectInfoSheet(reqObject).subscribe(
          result => {
            if (result.responseCode == '200') {
              this.objectUpdate={
                correctedPos: result.data.correctedPos,
                evaluateFlag: result.data.evaluateFlag,
                invalidPos: result.data.invalidPos,
                validatedPos: result.data.validatedPos,
                validationFlag: result.data.validationFlag,
                posId:this.infoDetails.posId,
              }
                this.objectApproveEvent.emit(this.objectUpdate);
              // window.location.back();
              // this.location.back();
            }
          },
          err => {
            err;
            this._event.broadcast({ eventName: 'hideLoader' });
          }
        )
      );
    }
  }
  validateUpdates() {
    if (this.tablemodified || this.updatedPosName ||
      this.updatedChain ||
      this.updatedAddress ||
      this.updatedPhone ||
      this.updatedMail ||
      this.updatedWebsite ||
      this.updatedPosType1 ||
      this.updatedPosType2 ||
      this.updatedPosType3 ||
      this.updatedPosType4 ||
      this.updatedTag ||
      this.updated77 ||
      this.updated24 ||
      this.updatedContact ||
      this.updatedHistoric ||
      this.updatedHistoricQ6 ||
      this.updatedCell ||
      this.updatedAdd || (this.validateSchedule())) {
      return true;
    }
    else return false;
  }
  validateSchedule() {
    this.updateParams();
    if (this.posD2DMoBreak !== this.newPos.schedule.posD2DMoBreak ||
      this.posD2DThuAppointment !== this.newPos.schedule.posD2DThuAppointment ||
      this.posD2DFriShift1 !== this.newPos.schedule.posD2DFriShift1 ||
      this.posD2DFriBreak !== this.newPos.schedule.posD2DFriBreak ||
      this.posD2DFriAppointment !== this.newPos.schedule.posD2DFriAppointment ||
      this.posD2DSatShift1 !== this.newPos.schedule.posD2DSatShift1 ||
      this.posD2DSatBreak !== this.newPos.schedule.posD2DSatBreak ||
      this.posD2DSatAppointment !== this.newPos.schedule.posD2DSatAppointment ||
      this.posD2DSunShift1 !== this.newPos.schedule.posD2DSunShift1 ||
      this.posD2DSunBreak !== this.newPos.schedule.posD2DSunBreak ||
      this.posD2DThuShift1 !== this.newPos.schedule.posD2DThuShift1 ||
      this.posD2DWedBreak !== this.newPos.schedule.posD2DWedBreak ||
      this.posD2DWedAppointment !== this.newPos.schedule.posD2DWedAppointment ||
      this.posD2DThuBreak !== this.newPos.schedule.posD2DThuBreak ||
      this.posD2DWedShift1 !== this.newPos.schedule.posD2DWedShift1 ||
      this.posD2DTuAppointment !== this.newPos.schedule.posD2DTuAppointment ||
      this.posD2DTuBreak !== this.newPos.schedule.posD2DTuBreak ||
      this.posD2DMoShift1 !== this.newPos.schedule.posD2DMoShift1 ||
      this.posD2DMoBreak !== this.newPos.schedule.posD2DMoBreak ||
      this.posD2DMoAppointment !== this.newPos.schedule.posD2DMoAppointment ||
      this.posD2DTuShift1 !== this.newPos.schedule.posD2DTuShift1) {
      return true
    }
    else return false;
  }
  updateParams() {
    if (this.posD2DMoBreak !== this.newPos.schedule.posD2DMoBreak) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DMoBreak = null : this.newPos.schedule.posMoFriBreak = this.newPos.schedule.posD2DMoBreak : this.newPos.schedule.posD2DMoNoWorking == "Yes" ? this.newPos.schedule.posD2DMoBreak = null : false;
    }
    if (this.posD2DThuAppointment !== this.newPos.schedule.posD2DThuAppointment) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DThuAppointment = null : this.newPos.schedule.posMoFriAppointment = this.newPos.schedule.posD2DThuAppointment : this.newPos.schedule.posD2DThuNoWorking == "Yes" ? this.newPos.schedule.posD2DThuAppointment = null : false;
    }
    if (this.posD2DFriShift1 !== this.newPos.schedule.posD2DFriShift1) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DFriShift1 = null : this.newPos.schedule.posMonFriShift1 = this.newPos.schedule.posD2DFriShift1 : this.newPos.schedule.posD2DFriNoWorking == "Yes" ? this.newPos.schedule.posD2DFriShift1 = null : false;
    }
    if (this.posD2DFriBreak !== this.newPos.schedule.posD2DFriBreak) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DFriBreak = null : this.newPos.schedule.posMoFriBreak = this.newPos.schedule.posD2DFriBreak : this.newPos.schedule.posD2DFriNoWorking == "Yes" ? this.newPos.schedule.posD2DFriBreak = null : false;
    }
    if (this.posD2DFriAppointment !== this.newPos.schedule.posD2DFriAppointment) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DFriAppointment = null : this.newPos.schedule.posMoFriAppointment = this.newPos.schedule.posD2DFriAppointment : this.newPos.schedule.posD2DFriNoWorking == "Yes" ? this.newPos.schedule.posD2DFriAppointment = this.newPos.schedule.posD2DFriAppointment = null : false;
    }
    if (this.posD2DSatShift1 !== this.newPos.schedule.posD2DSatShift1) {
      this.standardFlag ? this.newPos.schedule.posSatNoWorking == "Yes" ? this.newPos.schedule.posD2DSatShift1 = null : this.newPos.schedule.posSatShift1 = this.newPos.schedule.posD2DSatShift1 : this.newPos.schedule.posD2DSatNoWorking == "Yes" ? this.newPos.schedule.posD2DSatShift1 = null : this.newPos.schedule.posD2DSatShift1 = this.newPos.schedule.posD2DSatShift1;
    }
    if (this.posD2DSatBreak !== this.newPos.schedule.posD2DSatBreak) {
      this.standardFlag ? this.newPos.schedule.posSatNoWorking == "Yes" ? this.newPos.schedule.posD2DSatBreak = null : this.newPos.schedule.posSatBreak = this.newPos.schedule.posD2DSatBreak : this.newPos.schedule.posD2DSatNoWorking == "Yes" ? this.newPos.schedule.posD2DSatBreak = null : this.newPos.schedule.posD2DSatBreak = this.newPos.schedule.posD2DSatBreak;
    }
    if (this.posD2DSatAppointment !== this.newPos.schedule.posD2DSatAppointment) {
      this.standardFlag ? this.newPos.schedule.posSatNoWorking == "Yes" ? this.newPos.schedule.posD2DSatAppointment = null : this.newPos.schedule.posSatAppointment = this.newPos.schedule.posD2DSatAppointment : this.newPos.schedule.posD2DSatNoWorking == "Yes" ? this.newPos.schedule.posD2DSatAppointment = null : this.newPos.schedule.posD2DSatAppointment = this.newPos.schedule.posD2DSatAppointment;
    }
    if (this.posD2DSunShift1 !== this.newPos.schedule.posD2DSunShift1) {
      this.standardFlag ? this.newPos.schedule.posSunNoWorking == "Yes" ? this.newPos.schedule.posD2DSunShift1 = null : this.newPos.schedule.posSunShift1 = this.newPos.schedule.posD2DSunShift1 : this.newPos.schedule.posD2DSunNoWorking == "Yes" ? this.newPos.schedule.posD2DSunShift1 = null : false;
    }
    if (this.posD2DSunBreak !== this.newPos.schedule.posD2DSunBreak) {
      this.standardFlag ? this.newPos.schedule.posSunNoWorking == "Yes" ? this.newPos.schedule.posD2DSunBreak = null : this.newPos.schedule.posSunBreak = this.newPos.schedule.posD2DSunBreak : this.newPos.schedule.posD2DSunNoWorking == "Yes" ? this.newPos.schedule.posD2DSunBreak = null : false;
    }
    if (this.posD2DThuShift1 !== this.newPos.schedule.posD2DThuShift1) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DThuShift1 = null : this.newPos.schedule.posMonFriShift1 = this.newPos.schedule.posD2DThuShift1 : this.newPos.schedule.posD2DThuNoWorking == "Yes" ? this.newPos.schedule.posD2DThuShift1 = null : false;
    }
    if (this.posD2DWedBreak !== this.newPos.schedule.posD2DWedBreak) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DWedBreak = null : this.newPos.schedule.posMoFriBreak = this.newPos.schedule.posD2DWedBreak : this.newPos.schedule.posD2DWedNoWorking == "Yes" ? this.newPos.schedule.posD2DWedBreak = null : false;
    }
    if (this.posD2DWedAppointment !== this.newPos.schedule.posD2DWedAppointment) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DWedAppointment = null : this.newPos.schedule.posMoFriAppointment = this.newPos.schedule.posD2DWedAppointment : this.newPos.schedule.posD2DWedNoWorking == "Yes" ? this.newPos.schedule.posD2DWedAppointment = null : false;
    }
    if (this.posD2DThuBreak !== this.newPos.schedule.posD2DThuBreak) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DThuBreak = null : this.newPos.schedule.posMoFriBreak = this.newPos.schedule.posD2DThuBreak : this.newPos.schedule.posD2DThuNoWorking == "Yes" ? this.newPos.schedule.posD2DThuBreak = null : false;
    }
    if (this.posD2DWedShift1 !== this.newPos.schedule.posD2DWedShift1) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DWedShift1 = null : this.newPos.schedule.posMonFriShift1 = this.newPos.schedule.posD2DWedShift1 : this.newPos.schedule.posD2DWedNoWorking == "Yes" ? this.newPos.schedule.posD2DWedShift1 = null : false;
    }
    if (this.posD2DTuAppointment !== this.newPos.schedule.posD2DTuAppointment) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DTuAppointment = null : this.newPos.schedule.posMoFriAppointment = this.newPos.schedule.posD2DTuAppointment : this.newPos.schedule.posD2DTuNoWorking == "Yes" ? this.newPos.schedule.posD2DTuAppointment = null : false;
    }
    if (this.posD2DTuBreak !== this.newPos.schedule.posD2DTuBreak) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DTuBreak = null : this.newPos.schedule.posMoFriBreak = this.newPos.schedule.posD2DTuBreak : this.newPos.schedule.posD2DTuNoWorking == "Yes" ? this.newPos.schedule.posD2DTuBreak = null : false;
    }
    if (this.posD2DMoShift1 !== this.newPos.schedule.posD2DMoShift1) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DMoShift1 = null : this.newPos.schedule.posMonFriShift1 = this.newPos.schedule.posD2DMoShift1 : this.newPos.schedule.posD2DMoNoWorking == "Yes" ? this.newPos.schedule.posD2DMoShift1 = null : false;
    }
    if (this.posD2DMoBreak !== this.newPos.schedule.posD2DMoBreak) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DMoBreak = null : this.newPos.schedule.posD2DMoBreak = this.newPos.schedule.posD2DMoShift1 : this.newPos.schedule.posD2DMoNoWorking == "Yes" ? this.newPos.schedule.posD2DMoBreak = null : false;
    }
    if (this.posD2DMoAppointment !== this.newPos.schedule.posD2DMoAppointment) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DMoAppointment = null : this.newPos.schedule.posMoFriAppointment = this.newPos.schedule.posD2DMoAppointment : this.newPos.schedule.posD2DMoNoWorking == "Yes" ? this.newPos.schedule.posD2DMoAppointment = null : false;
    }
    if (this.posD2DTuShift1 !== this.newPos.schedule.posD2DTuShift1) {
      this.standardFlag ? this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DTuShift1 = null : this.newPos.schedule.posMonFriShift1 = this.newPos.schedule.posD2DTuShift1 : this.newPos.schedule.posMoFriNoWorking == "Yes" ? this.newPos.schedule.posD2DTuShift1 = null : false;
    }
  }

  openImage(no) {
    let link: string = null;

    if (no === 1 && this.newPos.poiImage1) {
      link = this.newPos.poiImage1;
    } else if (no === 2 && this.newPos.poiImage2) {
      link = this.newPos.poiImage2;
    } else if (no === 3 && this.newPos.poiImage3) {
      link = this.newPos.poiImage3;
    }

    if (link) {
      const modalRef = this.modalService.open(ImagePopupComponent);
      modalRef.componentInstance.imgLink = link;
    }
  }

  goBack() {
    this.back.emit('back');
  }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }

  isEmptyCell(event) {

    console.log("event=", event);
    if ((this.newPos.isEmptyCell) === 'YES') {
      this.newPos.isEmptyCell = 'NO';
      this.hideTable = false;
    }
    else {
      this.newPos.isEmptyCell = 'YES';
      this.newPos.isEmptyCell.toLowerCase() == 'yes' ? this.hideTable = true : this.hideTable = false;
    }
    this.newPos.isEmptyCell !== this.cell ? this.updatedCell = true : false;
  }
  isAd(event) {
    let add = this.newPos.ads;
    console.log("event=", event);
    if ((this.newPos.ads) === 'YES') {
      this.newPos.ads = 'NO';
    }
    else {
      this.newPos.ads = 'YES';
    }
    this.newPos.ads !== this.add ? this.updatedAdd = true : false;
  }
  checked7(event) {
    this.newPos.schedule.days77.toLowerCase() === 'yes' ? this.newPos.schedule.days77 = 'No' : this.newPos.schedule.days77 = 'Yes';
    if (this.seven !== this.newPos.schedule.days77) {
      this.updated77 = true;
    }
  }
  checked24(event) {
    this.newPos.schedule.hours2424.toLowerCase() === 'yes' ? this.newPos.schedule.hours2424 = 'No' : this.newPos.schedule.hours2424 = 'Yes';
    if (this.twenty !== this.newPos.schedule.hours2424) {
      this.updated24 = true;
    }
  }

  disableTable() {
    if (this.newPos.isEmptyCell.toLowerCase() == 'yes') {
      this.hideTable = true;
      return true;
    }
    else if (this.newPos.schedule.days77.toLowerCase() == 'yes' && this.newPos.schedule.hours2424.toLowerCase() == 'yes') {
      this.hideTable = false;
      return true;
    }
    else return false;
  }
  shopPhn(event) {
    let phn = this.newPos.contact.q2_dontWantToDisclose;
    console.log("event=", event);
    if ((this.newPos.contact.q2_dontWantToDisclose) === 113) {
      this.newPos.contact.q2_no = 112;
      this.newPos.contact.q2_dontWantToDisclose = null;
    }
    else {
      this.newPos.contact.q2_no = null;
      this.newPos.contact.q2_dontWantToDisclose = 113;
    }
    if (this.newPos.contact.q2_dontWantToDisclose !== this.phn) {
      this.updatedPhone = true;
    }
  }
  shopMail(event) {
    let mail = this.newPos.contact.q3_dontWantToDisclose;
    console.log("event=", event);
    if ((this.newPos.contact.q3_dontWantToDisclose) === 115) {
      this.newPos.contact.q3_no = 114;
      this.newPos.contact.q3_dontWantToDisclose = null;
    }
    else {
      this.newPos.contact.q3_no = null;
      this.newPos.contact.q3_dontWantToDisclose = 115;
    }
    if (this.newPos.contact.q3_dontWantToDisclose !== this.mail) {
      this.updatedMail = true;
    }
  }
  shopUrl(event) {
    let web = this.newPos.contact.q4_dontWantToDisclose;
    console.log("event=", event);
    if ((this.newPos.contact.q4_dontWantToDisclose) === 117) {
      this.newPos.contact.q4_no = 116;
      this.newPos.contact.q4_dontWantToDisclose = null;
    }
    else {
      this.newPos.contact.q4_no = null;
      this.newPos.contact.q4_dontWantToDisclose = 117;
    }
    if (this.newPos.contact.q4_dontWantToDisclose !== this.web) {
      this.updatedWebsite = true;
    }
  }
  macAddressFormat(event, data) {
    // var macAddress = event.target.value.toUpperCase();

    if ((this.newPos.schedule.days77 === 'No' && this.newPos.schedule.hours2424 === 'No')) {
      if ((event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) {
        if (event.keyCode != 13) {

          var macAddr = event.target.value;
          var rash;

          var alphaNum = /^[A-Za-z0-9]+$/;
          if (macAddr.length == 5) {
            if (!macAddr.includes('-')) {
              event.target.value = macAddr + '-';
            }
          }
          if (macAddr.length < 5) {
            if (macAddr.includes(':')) {

              if (macAddr.length == 5) {
                // console.log('393', event.target.value);
                var parts = event.target.value.split(':');
                // console.log(parts);
                if (parts[1] > 59) {
                  parts[1] = 59;
                  event.target.value = parts[0] + ':' + parts[1];
                  // console.log('425', event.target.value);
                }
                if (parts[0] > 23) {
                  parts[0] = 23;
                  event.target.value = parts[0] + ':' + parts[1];
                  // console.log('425', event.target.value);
                }

              } else if (macAddr.length == 4) {
                // console.log('393', event.target.value);
                var parts = event.target.value.split(':');
                // console.log(parts);
                if (parts[1] > 5) {
                  parts[1] = 5;
                  event.target.value = parts[0] + ':' + parts[1];
                  // console.log('425', event.target.value);
                }
                if (parts[0] > 23) {
                  parts[0] = 23;
                  event.target.value = parts[0] + ':' + parts[1];
                  // console.log('425', event.target.value);
                }
                console.log('final', event.target.value);
              }
            }
            if (macAddr.length == 2 && alphaNum.test(macAddr)) {

              // macAddr = macAddr.replace(/(.{2})/g, "$1:").slice(0, -1);
              if (!macAddr.includes(':')) {
                macAddr = macAddr + ':';
              }
              event.target.value = macAddr;
              rash = event.target.value;
              console.log('389', event.target.value);
            }
            else if (macAddr.length == 2) {
              if (macAddr > 24) {
                event.target.value = 24;
                rash = event.target.value;
                console.log('395', event.target.value);
              }
              else
                if (macAddr > 12) {
                  var count = macAddr - 12;
                  event.target.value = 12 + count;
                  rash = event.target.value;
                  console.log(event.target.value);
                }

            }
            else if (!alphaNum.test(macAddr)) {
              console.log("only alpha-numeric allowed");
            }
          }
          else if (macAddr.length > 5) {
            alphaNum = /^[A-Za-z0-9]+$/;
            if (macAddr.includes(':')) {
              if (macAddr.length == 11) {
                // console.log('393', event.target.value);
                var parts = event.target.value.split('-');
                parts = parts[1].split(':');
                // console.log(parts);
                if (parts[1] > 59) {
                  parts[1] = 59;
                  event.target.value = parts[0] + ':' + parts[1];
                  // console.log('425', event.target.value);
                }
                if (parts[0] > 23) {
                  parts[0] = 23;
                  event.target.value = parts[0] + ':' + parts[1];
                  // console.log('425', event.target.value);
                }

              } else if (macAddr.length == 10) {
                // console.log('393', event.target.value);
                var parts = event.target.value.split('-');
                var parts1 = parts[1].split(':');
                // console.log(parts);
                if (parts1[1] > 5) {
                  parts1[1] = 5;
                  event.target.value = parts[0] + '-' + parts1[0] + ':' + parts1[1];
                  // console.log('425', event.target.value);
                }
                if (parts1[0] > 23) {
                  parts1[0] = 23;
                  event.target.value = parts[0] + '-' + parts1[0] + ':' + parts1[1];
                  // console.log('425', event.target.value);
                }
                console.log('final', event.target.value);
              }
            }
            if (macAddr.length == 8) {

              // macAddr = macAddr.replace(/(.{2})/g, "$1:").slice(0, -1);
              var parts = macAddr.split('-');

              if (parts[1] > 24) {
                macAddr = parts[0] + '-' + '23';
                rash = macAddr;
                console.log('395', event.target.value);
              }
              else if (parts[1] > 12) {
                var count = parts[1] - 12;
                parts[1] = 12 + count;
                rash = parts[0] + '-' + parts[1];
              }
              if (!(macAddr.split('-')[1].includes(':'))) {
                macAddr = macAddr + ':';
              }
              event.target.value = macAddr;
              rash = event.target.value;
              // console.log('389', event.target.value);
            }
            // else if (macAddr.length == 8) {
            //   var parts = macAddr.split('-');

            //   if (parts[1] > 24) {
            //    macAddr =parts[0] + '-' + '24';
            //     rash = macAddr;
            //     console.log('395', event.target.value);
            //   }
            //   else
            //     if (parts[1] > 12) {
            //       var count = parts[1] - 12;
            //       parts[1] = 12 + count;
            //       rash = parts[0] + '-' + parts[1];
            //       console.log(event.target.value);
            //     }
            // }
            else if (!alphaNum.test(macAddr)) {
              console.log("only alpha-numeric allowed");
            }
          }
        }
      }
      else {
        if (this.standardFlag) {
          event.target.value.toLowerCase() == 'not a working day' ? this.newPos.schedule.posMoFriNoWorking = 'Yes' : false;
          // event.target.value = null;
        } else {
          this.newPos.schedule.posD2DMoNoWorking = 'Yes';
        }
      }
    }
    else if (this.newPos.schedule.days77.toLowerCase() === 'yes') {
      if ((event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) {
        if (event.keyCode != 13) {

          var macAddr = event.target.value;
          var rash;

          var alphaNum = /^[A-Za-z0-9]+$/;
          if (macAddr.length == 5) {
            if (!macAddr.includes('-')) {
              event.target.value = macAddr + '-';
            }
          }
          if (macAddr.length < 5) {
            if (macAddr.includes(':')) {

              if (macAddr.length == 5) {
                // console.log('393', event.target.value);
                var parts = event.target.value.split(':');
                // console.log(parts);
                if (parts[1] > 59) {
                  parts[1] = 59;
                  event.target.value = parts[0] + ':' + parts[1];
                  // console.log('425', event.target.value);
                }
                if (parts[0] > 23) {
                  parts[0] = 23;
                  event.target.value = parts[0] + ':' + parts[1];
                  // console.log('425', event.target.value);
                }

              } else if (macAddr.length == 4) {
                // console.log('393', event.target.value);
                var parts = event.target.value.split(':');
                // console.log(parts);
                if (parts[1] > 5) {
                  parts[1] = 5;
                  event.target.value = parts[0] + ':' + parts[1];
                  // console.log('425', event.target.value);
                }
                if (parts[0] > 23) {
                  parts[0] = 23;
                  event.target.value = parts[0] + ':' + parts[1];
                  // console.log('425', event.target.value);
                }
                console.log('final', event.target.value);
              }
            }
            if (macAddr.length == 2 && alphaNum.test(macAddr)) {

              // macAddr = macAddr.replace(/(.{2})/g, "$1:").slice(0, -1);
              if (!macAddr.includes(':')) {
                macAddr = macAddr + ':';
              }
              event.target.value = macAddr;
              rash = event.target.value;
              console.log('389', event.target.value);
            }
            else if (macAddr.length == 2) {
              if (macAddr > 24) {
                event.target.value = 24;
                rash = event.target.value;
                console.log('395', event.target.value);
              }
              else
                if (macAddr > 12) {
                  var count = macAddr - 12;
                  event.target.value = 12 + count;
                  rash = event.target.value;
                  console.log(event.target.value);
                }

            }
            else if (!alphaNum.test(macAddr)) {
              console.log("only alpha-numeric allowed");
            }
          }
          else if (macAddr.length > 5) {
            alphaNum = /^[A-Za-z0-9]+$/;
            if (macAddr.includes(':')) {
              if (macAddr.length == 11) {
                // console.log('393', event.target.value);
                var parts = event.target.value.split('-');
                parts = parts[1].split(':');
                // console.log(parts);
                if (parts[1] > 59) {
                  parts[1] = 59;
                  event.target.value = parts[0] + ':' + parts[1];
                  // console.log('425', event.target.value);
                }
                if (parts[0] > 23) {
                  parts[0] = 23;
                  event.target.value = parts[0] + ':' + parts[1];
                  // console.log('425', event.target.value);
                }

              } else if (macAddr.length == 10) {
                // console.log('393', event.target.value);
                var parts = event.target.value.split('-');
                var parts1 = parts[1].split(':');
                // console.log(parts);
                if (parts1[1] > 5) {
                  parts1[1] = 5;
                  event.target.value = parts[0] + '-' + parts1[0] + ':' + parts1[1];
                  // console.log('425', event.target.value);
                }
                if (parts1[0] > 23) {
                  parts1[0] = 23;
                  event.target.value = parts[0] + '-' + parts1[0] + ':' + parts1[1];
                  // console.log('425', event.target.value);
                }
                console.log('final', event.target.value);
              }
            }
            if (macAddr.length == 8) {

              // macAddr = macAddr.replace(/(.{2})/g, "$1:").slice(0, -1);
              var parts = macAddr.split('-');

              if (parts[1] > 24) {
                macAddr = parts[0] + '-' + '23';
                rash = macAddr;
                console.log('395', event.target.value);
              }
              else if (parts[1] > 12) {
                var count = parts[1] - 12;
                parts[1] = 12 + count;
                rash = parts[0] + '-' + parts[1];
              }
              if (!macAddr.split('-')[1].includes(':')) {
                macAddr = macAddr + ':';
              }
              event.target.value = macAddr;
              rash = event.target.value;
              // console.log('389', event.target.value);
            }
            // else if (macAddr.length == 8) {
            //   var parts = macAddr.split('-');

            //   if (parts[1] > 24) {
            //    macAddr =parts[0] + '-' + '24';
            //     rash = macAddr;
            //     console.log('395', event.target.value);
            //   }
            //   else
            //     if (parts[1] > 12) {
            //       var count = parts[1] - 12;
            //       parts[1] = 12 + count;
            //       rash = parts[0] + '-' + parts[1];
            //       console.log(event.target.value);
            //     }
            // }
            else if (!alphaNum.test(macAddr)) {
              console.log("only alpha-numeric allowed");
            }
          }
        }
      }
      else {
        event.preventDefault();
        event.stopPropagation();
        return false;
      }
    } else {
      if (!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) {
        if (this.standardFlag) {
          event.target.value.toLowerCase() == 'not a working day' ? this.newPos.schedule.posMoFriNoWorking = 'Yes' : false;
          // event.target.value = null;
        } else {
          this.newPos.schedule.posD2DMoNoWorking = 'Yes';
        }
      }
      else {
        event.preventDefault();
        event.stopPropagation();
        return false;
      }
    }
  }

  doSomething(event, location) {
    if (event!==null && event.keyCode?!((event.keyCode > 64 && event.keyCode < 91) || (event.keyCode > 96 && event.keyCode < 123) || event.keyCode == 8 || event.keyCode == 32 || (event.keyCode >= 48 && event.keyCode <= 57)):false) {
      //event.preventDefault();
      //event.stopPropagation();
    }
    else {
      if (location == 1 && (this.name !== this.newPos.posNameFr || this.name !== this.newPos.posNameEn || this.name !== this.newPos.posNameNl)) {
        this.updatedPosName = true;
      }
      if (location == 3) {
        if (event!==null && event.keyCode?((event.keyCode > 64 && event.keyCode < 91) || (event.keyCode > 96 && event.keyCode < 123) || event.keyCode == 8 || event.keyCode == 32):false) {
          event.preventDefault();
          event.stopPropagation();
        }
        else{
        let address = `${this.newPos.streetNumber ? (this.newPos.streetNumber) : '-'}${this.newPos.streetNumber}`;
        let address1 = `${this.newPos.streetNumberSuffix ? (this.newPos.streetNumberSuffix) : ''}`;
        this.address !== address ? this.updatedAddress = true : false;
        this.address1 !== address1 ? this.updatedAddress = true : false;
        this.newPos.streetNumber = this.address == '' ? null : this.address;
        this.newPos.streetNumberSuffix = this.address1 == '' ? null : this.address1;
        }
      }
    }
    if (location == 4) {
      this.newPos.contact.q2_phoneNumber == null? this.newPos.contact.q2_phoneNumber = '' :false;
      this.newPos.contact.q2_phoneNumber !== this.q2_phoneNumber ? this.updatedPhone = true : false;
    }
    if (location == 5) {
      this.q3_mail !== this.newPos.contact.q3_mail ? this.updatedMail = true : false;
    }
    if (location == 6) {
      this.newPos.contact.q4_website !== this.q4_website ? this.updatedWebsite = true : false;
    }
  }

  macAddressFormat1(location, event) {
    if(location == 7){
      if(event!==null && event.keyCode?!(event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105):false){
        event.preventDefault();
        event.stopPropagation();
      }
      else this.newPos.realEstatesAdShopSurface !== this.shopSurface ? this.updatedWebsite = true : false;
    }
    if(location == 8){
      if (event!==null && event.keyCode?!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105):false) {
        event.preventDefault();
        event.stopPropagation();
      }
      else this.newPos.realEstatesAdTotalSurface !== this.totalSurface ? this.updatedWebsite = true : false;
    }
    if(location == 91){
      if (event!==null && event.keyCode?!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105):false) {
        event.preventDefault();
        event.stopPropagation();
      }
      else this.newPos.surRentingPrice !== this.rentingPrice ? this.updatedWebsite = true : false;
    }
    if(location == 92){
      if (event!==null && event.keyCode?!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105):false) {
        event.preventDefault();
        event.stopPropagation();
      }
      else this.newPos.surSellingPrice !== this.sellingPrice ? this.updatedWebsite = true : false;
    }
    if(location == 101){
      if (event!==null && event.keyCode?!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105):false) {
        event.preventDefault();
        event.stopPropagation();
      }
      else this.newPos.realEstatesAdEmail !== this.adEmail ? this.updatedWebsite = true : false;
    }
    if(location == 102){
      if (event!==null && event.keyCode?!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105):false) {
        event.preventDefault();
      event.stopPropagation();
      }
      else this.newPos.realEstatesAdPhone !== this.adPhone ? this.updatedWebsite = true : false;

    }
  }

  removeType(type){
    if(type ==1){
      this.updatedPosType1 =true;
      this.newPos.posType1=null;
      this.selectedLeve11 ? this.leve11Selected ='':false;
      !this.selectedLeve11?this.level1s[2] ='':false;
      this.selectedLeve21? this.leve21Selected ='':false;
      !this.selectedLeve21? this.level2s[2] ='':false;
      this.selectedLeve31? this.leve31Selected ='':false;
      !this.selectedLeve31? this.newPos.posType1 =null:false;
    }
    else if(type ==2){
      this.updatedPosType2= true;
      this.newPos.posType2=null;
      this.selectedLeve12 ? this.leve12Selected ='':false;
      !this.selectedLeve12?this.level1s[0] ='':false;
      this.selectedLeve22? this.leve22Selected ='':false;
      !this.selectedLeve22? this.level2s[0] ='':false;
      this.selectedLeve32? this.leve32Selected ='':false;
      !this.selectedLeve32? this.newPos.posType2 =null:false;
    }
    else if(type ==3){
      
      this.updatedPosType3=true;
      this.newPos.posType3=null;
      this.selectedLeve13 ? this.leve13Selected ='':false;
      !this.selectedLeve13?this.level1s[1] ='':false;
      this.selectedLeve22? this.leve23Selected ='':false;
      !this.selectedLeve22? this.level2s[1] ='':false;
      this.selectedLeve33? this.leve33Selected ='':false;
      !this.selectedLeve33? this.newPos.posType3 =null:false;
    }
    else if(type ==4){
      
      this.updatedPosType4 = true;
      this.newPos.posType4=null;
      this.selectedLeve14 ? this.leve14Selected ='':false;
      !this.selectedLeve14?this.level1s[3] ='':false;
      this.selectedLeve24? this.leve24Selected ='':false;
      !this.selectedLeve24? this.level2s[3] ='':false;
      this.selectedLeve34? this.leve34Selected ='':false;
      !this.selectedLeve34? this.newPos.posType4 =null:false;
    }
  }

  isdisabled() {
    // this.newPos.realEstatesAdPhone== '' || this.newPos.realEstatesAdShopSurface=='' || this.newPos.realEstatesAdTotalSurface == '' ||
    if (this.rightPanelBlank == true) {
      if ((this.newPos.streetNumber == null || this.name == '' || this.newPos.contact.q2_phoneNumber == '' || this.newPos.contact.q4_website == '')) {
        return true;
      }
      else return false;
    }
    else {
      if ((this.newPos.posType1 == null || this.newPos.posType1 == 'Select') && (this.newPos.posType2 == null || this.newPos.posType2 == 'Select') && (this.newPos.posType3 == null || this.newPos.posType3 == 'Select') && (this.newPos.posType4 == null || this.newPos.posType3 == 'Select') || (this.newPos.streetNumber == null || this.name == '' || this.newPos.contact.q2_phoneNumber == '' || this.newPos.contact.q4_website == '')) {
        return true;
      }
      else {
        return false;
      }
    }
  }
}