use pubs;
-- 1
CREATE TABLE MY_EMPLOYEE
(
ID
INT(4) PRIMARY KEY AUTO_INCREMENT,
LAST_NAME VARCHAR(25),
FIRST_NAME VARCHAR(25),
USERID VARCHAR(8),
SALARY
FLOAT(9,2)
);

-- 2 to 5
DESC MY_EMPLOYEE;
insert into MY_EMPLOYEE values(1,'Patel','Ralph','rpatel',795);
select * from  MY_EMPLOYEE;
insert into MY_EMPLOYEE values(2,'Dancs','Betty','bdancs',860);
insert into MY_EMPLOYEE values(3,'Biri','Ben','bbiri',1100);
insert into MY_EMPLOYEE values(4,'Newman','Chad','cnewman',750);
insert into MY_EMPLOYEE values(5,'Ropeburn','Audry','aropeburn',1550);

-- 6 not working
-- 7 not working
-- 8 not working
-- 9 not working

-- 10
SET AUTOCOMMIT = 0;
select * from  MY_EMPLOYEE;
UPDATE MY_EMPLOYEE SET LAST_NAME = 'Dexter' WHERE ID = 3;
ROLLBACK;

-- 11 and 12 not working
select * from MY_EMPLOYEE;
UPDATE MY_EMPLOYEE SET SALARY = 1000 WHERE SALARY < 900;

-- 13 14 15 not sure
delete from MY_EMPLOYEE where ID = 2;
select  * from MY_EMPLOYEE;

ROLLBACK;


-- 16 to 21 not working

=========================
mysql> \t
mysql> CREATE TABLE MY_EMPLOYEE
    -> ( 
    ->  ID INT(4) PRIMARY KEY AUTO_INCREMENT,
    -> LAST_NAME VARCHAR(25),
    -> FIRST_NAME VARCHAR(25),
    -> USERID VARCHAR(8),
    -> SALARY FLOAT (9,2)
    -> );
Query OK, 0 rows affected (0.02 sec)

mysql> DESC MY_EMPLOYEE;
+------------+-------------+------+-----+---------+----------------+
| Field      | Type        | Null | Key | Default | Extra          |
+------------+-------------+------+-----+---------+----------------+
| ID         | int(4)      | NO   | PRI | NULL    | auto_increment |
| LAST_NAME  | varchar(25) | YES  |     | NULL    |                |
| FIRST_NAME | varchar(25) | YES  |     | NULL    |                |
| USERID     | varchar(8)  | YES  |     | NULL    |                |
| SALARY     | float(9,2)  | YES  |     | NULL    |                |
+------------+-------------+------+-----+---------+----------------+
5 rows in set (0.02 sec)

mysql> INSERT INTO MY_EMPLOYEE VALUES (1,'PATEL','RALPH','RPATEL',795);
Query OK, 1 row affected (0.01 sec)

mysql> INSERT INTO MY_EMPLOYEE (LAST_NAME,FIRST_NAME,USERID,SALARY)VALUES ('DANC','BETTY','BDANC',860);
Query OK, 1 row affected (0.00 sec)


mysql> SELECT * FROM MY_EMPLOYEE;
+----+-----------+------------+--------+--------+
| ID | LAST_NAME | FIRST_NAME | USERID | SALARY |
+----+-----------+------------+--------+--------+
|  1 | PATEL     | RALPH      | RPATEL | 795.00 |
|  2 | DANC      | BETTY      | BDANC  | 860.00 |
+----+-----------+------------+--------+--------+
2 rows in set (0.00 sec)

mysql> \. C:\Users\mariya.hussain\Desktop\Mern_Training\DAY11\loadme.sql
Query OK, 1 row affected (0.00 sec)

Query OK, 1 row affected (0.00 sec)

Query OK, 1 row affected (0.00 sec)

mysql> SELECT* FROM MY_EMPLOYEE;
+----+-----------+------------+----------+---------+
| ID | LAST_NAME | FIRST_NAME | USERID   | SALARY  |
+----+-----------+------------+----------+---------+
|  1 | PATEL     | RALPH      | RPATEL   |  795.00 |
|  2 | DANC      | BETTY      | BDANC    |  860.00 |
|  3 | BIRI      | BEN        | BBIRI    | 1100.00 |
|  4 | NEWMAN    | CHAD       | CNEWMAN  |  750.00 |
|  5 | ROPEBURN  | AUDRY      | AROPEBUR | 1550.00 |
+----+-----------+------------+----------+---------+
5 rows in set (0.00 sec)

mysql> SET autocommit = 0;
Query OK, 0 rows affected (0.01 sec)

mysql> START TRANSACTION ;
Query OK, 0 rows affected (0.00 sec)

mysql> UPDATE MY_EMPLOYEE SET FIRST_NAME='DEXTER' WHERE ID=3;
Query OK, 1 row affected (0.00 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> UPDATE MY_EMPLOYEE SET SALARY=1000 WHERE SALARY<900;
Query OK, 3 rows affected (0.00 sec)
Rows matched: 3  Changed: 3  Warnings: 0

mysql> SELECT * FROM MY_EMPLOYEE;
+----+-----------+------------+----------+---------+
| ID | LAST_NAME | FIRST_NAME | USERID   | SALARY  |
+----+-----------+------------+----------+---------+
|  1 | PATEL     | RALPH      | RPATEL   | 1000.00 |
|  2 | DANC      | BETTY      | BDANC    | 1000.00 |
|  3 | BIRI      | DEXTER     | BBIRI    | 1100.00 |
|  4 | NEWMAN    | CHAD       | CNEWMAN  | 1000.00 |
|  5 | ROPEBURN  | AUDRY      | AROPEBUR | 1550.00 |
+----+-----------+------------+----------+---------+
5 rows in set (0.00 sec)

mysql> COMMIT;
Query OK, 0 rows affected (0.00 sec)
 mysql> \. C:\Users\mariya.hussain\Desktop\Mern_Training\DAY11\loadme.sql
ERROR 1062 (23000): Duplicate entry '3' for key 'PRIMARY'
ERROR 1062 (23000): Duplicate entry '4' for key 'PRIMARY'
ERROR 1062 (23000): Duplicate entry '5' for key 'PRIMARY'

Query OK, 1 row affected (0.00 sec)
mysql> 
mysql> select * from my_employee;
+----+-----------+------------+----------+---------+
| ID | LAST_NAME | FIRST_NAME | USERID   | SALARY  |
+----+-----------+------------+----------+---------+
|  1 | PATEL     | RALPH      | RPATEL   | 1000.00 |
|  2 | DANC      | BETTY      | BDANC    | 1000.00 |
|  3 | BIRI      | DEXTER     | BBIRI    | 1100.00 |
|  4 | NEWMAN    | CHAD       | CNEWMAN  | 1000.00 |
|  5 | ROPEBURN  | AUDRY      | AROPEBUR | 1550.00 |
|  6 | Hussain   | mariya     | mHussain | 4100.00 |
+----+-----------+------------+----------+---------+
6 rows in set (0.00 sec)

mysql> SAVEPOINT MYSAVPOINT1;
Query OK, 0 rows affected (0.00 sec)

mysql> DELETE FROM MY_EMPLOYEE;
Query OK, 6 rows affected (0.00 sec)

mysql> ROLLBACK TO SAVEPOINT MYSAVPOINT1;
Query OK, 0 rows affected (0.00 sec)

mysql> SELECT * FROM MY_EMPLOYEE;
+----+-----------+------------+----------+---------+
| ID | LAST_NAME | FIRST_NAME | USERID   | SALARY  |
+----+-----------+------------+----------+---------+
|  1 | PATEL     | RALPH      | RPATEL   | 1000.00 |
|  2 | DANC      | BETTY      | BDANC    | 1000.00 |
|  3 | BIRI      | DEXTER     | BBIRI    | 1100.00 |
|  4 | NEWMAN    | CHAD       | CNEWMAN  | 1000.00 |
|  5 | ROPEBURN  | AUDRY      | AROPEBUR | 1550.00 |
|  6 | Hussain   | mariya     | mHussain | 4100.00 |
+----+-----------+------------+----------+---------+
6 rows in set (0.00 sec)

