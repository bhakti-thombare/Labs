import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { BehaviorSubject,Subscription } from 'rxjs';
import { SharedService } from './../../shared/shared.service';
import { ExcelService } from '../../shared/excel.service';
import * as JSPDF from 'jspdf';
import 'jspdf-autotable';
import { ToastService } from '../../shared/toast.service';

@Component({
  selector: 'app-companies',
  templateUrl: './companies.component.html',
  styleUrls: ['./companies.component.scss']
})
export class CompaniesComponent implements OnInit {

  cols: any = [];
  closeResult = '';
  companyForm!: FormGroup;
  companyData: any = [];
  submitted = false;
  pageNumber: number = 0;
  pageSize: number = 5;
  loader: boolean = true;
  totalCompany!:any;
  
  businessVerticalForm:FormGroup;
  BVDropdown : any =[];
  BVDropdown1 : any =[];
  getUserDropdownData:any = [];
  selectedItems:any = [];
  dropdownSettings = {};
  roles!: any[];
  tableDrop1:any = [];
  countryDropdown:any =[];
  StateDropdown:any=[];
  cityDropdown:any =[];
  bvData:any ={};
  subscription!:Subscription;
  subscription1!:Subscription;
  editFlag = false;
  changeTitleAddViewEdit:string = 'Add';
  selectedTabIndex = 0;
  showBVScreen = true;
  compDropdown: any = [];
  hasFilteredData: any = {};
  country:any[] = [ ]
  state: any[] = [ ]
  city: any[] = [ ]
  disabledBVTab = true;
  dropdownSecSettings = {};
  dropdownStateSettings = {};
  dropdownCitySettings = {};

  filterColumField: any  = [
    { field: 'companyName', header: 'Company Name' },
    { field: 'companyCode', header: 'Company Code' },
  ];
 

  constructor(private modalService: NgbModal, private fb: FormBuilder, private _shared: SharedService, 
    private excelService: ExcelService, private toast: ToastService) {
    this.companyForm = this.fb.group({
      companyId: [''],
      companyCode: ['', [Validators.required, Validators.maxLength(18),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      companyName: ['', [Validators.required, Validators.minLength(2),Validators.maxLength(150),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      companyHead: ['', [Validators.required, Validators.maxLength(120)]],
      addressLine1: ['', [Validators.required, Validators.maxLength(150),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      addressLine2: [''],
      addressLine3: [''],
      city: ['', Validators.required],
      state: ['', Validators.required],
      country: ['', Validators.required],
      pinCode: ['', [Validators.required, Validators.maxLength(6),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      TANNumber: ['', [Validators.required, Validators.maxLength(10),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      TINNumber: ['', [Validators.required, Validators.maxLength(12),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      PANNumber: ['', [Validators.required, Validators.maxLength(10),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      GSTINNumber: ['', [Validators.required, Validators.maxLength(16),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      isActive: ['true'],
    })

    this.businessVerticalForm = this.fb.group({
      bvCode: ['', [Validators.required, Validators.minLength(2),Validators.maxLength(18),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]],
      companyCode: ['', [Validators.required, Validators.maxLength(18)]],
      bvName: ['', [Validators.required, Validators.minLength(2),Validators.maxLength(150),Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/) ]],
      bvHead: ['', [Validators.required, Validators.maxLength(120)]],
      isActive: ['false'],   
    })
  }

  ngOnInit() {
    
    // this.getCityDropdownList(0,100);
    this.getCompanyColumns();
    this.getCompanyData(this.pageNumber, this.pageSize);
    this.getHeadsDropdownList(0,100);
    this.getUserDropdownList();
    this.getCompDropdownList(0,100);
    // this.getBVDropdownList1(0,100);
    this.getCountryList(this.pageNumber, this.pageSize);

    this.dropdownSettings = {
      enableSearchFilter: true,
      addNewItemOnFilter: true,
      singleSelection: true, 
      text: "Select User Id",
      primaryKey: "id",
      labelKey: "userId",
      searchBy: ['userId']
    };
    this.dropdownSecSettings = {
      enableSearchFilter: true,
      addNewItemOnFilter: false,
      singleSelection: true,
      text: "Select Country",
      primaryKey: "countryCode",
      labelKey: "countryName",
      searchBy: ['countryName'],
      lazyLoading: true,
      classes: "myclass custom-class",
      //autoPosition: false
    };

    this.dropdownStateSettings={
      enableSearchFilter: true,
      addNewItemOnFilter: false,
      singleSelection: true,
      text: "Select State",
      primaryKey: "stateCode",
      labelKey: "stateName",
      searchBy: ['stateName'],
      lazyLoading: true,
      classes: "myclass custom-class",
    };
    this.dropdownCitySettings={
      enableSearchFilter: true,
      addNewItemOnFilter: false,
      singleSelection: true,
      text: "Select City",
      primaryKey: "cityCode",
      labelKey: "cityName",
      searchBy: ['cityName'],
      lazyLoading: true,
      classes: "myclass custom-class",
    };

  }

  avoidSpecialChar(event:any)
  {   
     var k;  
     k = event.charCode;  //         k = event.keyCode;  (Both can be used)
     return((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57)); 
  }

  checkSpecialCharInCode = true;
  avoidSpecialCharInCode(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      this.checkSpecialCharInCode = false;
      return this.checkSpecialCharInCode;
    } else {
      this.checkSpecialCharInCode = true;
      return this.checkSpecialCharInCode;
    }
  }

  checkSpecialCharInTan = true;
  checkSpecialCharInTan1 = true;
  avoidSpecialCharInTan(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (evt.target.value >= 0 && evt.target. value < 3 && (charCode > 47 && charCode <= 57)){
      this.checkSpecialCharInTan = false;
      return this.checkSpecialCharInTan;
    }

    else if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
     if(evt.target.value > 2){
      this.checkSpecialCharInTan1 = true;
      this.checkSpecialCharInTan = false;
      return this.checkSpecialCharInTan;
    } else {
      this.checkSpecialCharInTan = true;
      return this.checkSpecialCharInTan;
    }}
  }

  checkSpecialCharInTin = true;
  avoidSpecialCharInTin(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      this.checkSpecialCharInTin = false;
      return this.checkSpecialCharInTin;
    } else {
      this.checkSpecialCharInTin = true;
      return this.checkSpecialCharInTin;
    }
  }

  checkSpecialCharInPan = true;
  avoidSpecialCharInPan(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      this.checkSpecialCharInPan = false;
      return this.checkSpecialCharInPan;
    } else {
      this.checkSpecialCharInPan = true;
      return this.checkSpecialCharInPan;
    }
  }

  checkSpecialCharInGstin = true;
  avoidSpecialCharInGstin(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      this.checkSpecialCharInGstin = false;
      return this.checkSpecialCharInGstin;
    } else {
      this.checkSpecialCharInGstin = true;
      return this.checkSpecialCharInGstin;
    }
  }

  checkSpecialCharInBVCode = true;
  avoidSpecialCharInBVCode(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      this.checkSpecialCharInBVCode = false;
      return this.checkSpecialCharInBVCode;
    } else {
      this.checkSpecialCharInBVCode = true;
      return this.checkSpecialCharInBVCode;
    }
  }

  checkSpecialCharInBVName = true;
  avoidSpecialCharInBVName(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    // if (charCode > 31 && (charCode < 44 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      if (charCode > 31 && (charCode < 48|| charCode > 57 || charCode >= 47) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
    
    this.checkSpecialCharInBVName = false;
      return this.checkSpecialCharInBVName;
    } else {
      this.checkSpecialCharInBVName = true;
      return this.checkSpecialCharInBVName;
    }
  }

  checkSpecialCharInPin = true;
  avoidSpecialCharInPin(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) ) {
      this.checkSpecialCharInPin = false;
      return this.checkSpecialCharInPin;
    } else {
      this.checkSpecialCharInPin = true;
      return this.checkSpecialCharInPin;
    }
  }


  checkSpecialCharInName = true;
  avoidSpecialCharInName(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    // if (charCode > 31 && (charCode < 44 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      if (charCode > 32 && (charCode < 48 || charCode > 57 || charCode >= 47) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
    
    this.checkSpecialCharInName = false;
      return this.checkSpecialCharInName;
    } else {
      this.checkSpecialCharInName = true;
      return this.checkSpecialCharInName;
    }
  }

  checkSpecialCharInAddress1 = true;
  avoidSpecialCharInAddress1(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 32 && (charCode < 44 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      this.checkSpecialCharInAddress1 = false;
      return this.checkSpecialCharInAddress1;
    } else {
      this.checkSpecialCharInAddress1 = true;
      return this.checkSpecialCharInAddress1;
    }
  }

  checkSpecialCharInAddress2 = true;
  avoidSpecialCharInAddress2(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 32 && (charCode < 44 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      this.checkSpecialCharInAddress2 = false;
      return this.checkSpecialCharInAddress2;
    } else {
      this.checkSpecialCharInAddress2 = true;
      return this.checkSpecialCharInAddress2;
    }
  }

  checkSpecialCharInAddress3 = true;
  avoidSpecialCharInAddress3(evt: any) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 32 && (charCode < 44 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode >= 123)) {
      this.checkSpecialCharInAddress3 = false;
      return this.checkSpecialCharInAddress3;
    } else {
      this.checkSpecialCharInAddress3 = true;
      return this.checkSpecialCharInAddress3;
    }
  }


  get formControl() {
    return this.companyForm.controls;
  }

  get formBVControl() {
    return this.businessVerticalForm.controls;
  }

  ngAfterViewInit(){
    this._shared.sendpageTitle('COMPANIES');
  }

  getCompanyColumns() {
    this.cols = [
      { field: 'Action', header: 'Action' },
      { field: 'companyCode', header: 'Company Code' },
      { field: 'companyName', header: 'Company Name' },
      { field: 'companyHead', header: 'Company Head' },
      { field: 'isActive', header: 'Status' },

    ];
  }

  getCountryList(pageNumber:number, pageSize:number){
    let obj={
      pageNumber:pageNumber,
      pageSize:pageSize
    } 
    this._shared.post('Country/GetCountryList',obj,'admin').subscribe(res => {
      this.country = res;
    });
  }

  changeCountry(e:any, pageNumber:number, pageSize:number){
    let obj = {
      // pageNumber: pageNumber,
      // pageSize: pageSize,
      countryCode: this.companyForm.value.country[0]?.countryCode
    }
    this._shared.post('State/GetStateList',obj,'admin').subscribe(res => {
      // let state = res.filter((itm:any) => itm.countryCode == e.target.value);
      this.state = res;
    });
  }

  changeState(e: any) {
    let obj = {
      // pageNumber: pageNumber,
      // pageSize: pageSize,
      countryCode: this.companyForm.value.country[0]?.countryCode,
      stateCode: this.companyForm.value.state[0]?.stateCode
      
    }
    this._shared.post('City/GetCityList',obj, 'admin').subscribe(res => {
      // let city = res.filter((itm: any) => itm.stateCode == e.target.value);
      this.city = res;
    });
  }


  //create BV  by clicking on icon
  createBV(data: any, status: any){
    this.disabledBVTab = false;
    this.selectedTabIndex = 2;
    this._shared.post('BusinessVertical/GetBVbyId', {StringID: data.bvid}, 'admin').subscribe(res => {
      this.bvData = res[0];
      this.businessVerticalForm.patchValue({
        bvid: this.bvData != undefined ? this.bvData.bvid  : data.bvid,
        bvCode:this.bvData != undefined ? this.bvData.bvcode  : data.bvcode,
        companyCode:this.bvData != undefined ? this.bvData.companyCode  : data.companyCode,
        bvName:this.bvData != undefined ? this.bvData.bvname  : data.bvname,
        bvHead:this.bvData != undefined ? this.bvData.bvHead[0].userId  : data.bvHead,
        isActive: this.bvData != undefined ? this.bvData.isActive : false
      })
     });
  }

  createNupdateBV(data:any) {
    if (this.bvData ==undefined){
      this.businessVerticalForm.value.bvcode= this.businessVerticalForm.value.bvcode,
      this.businessVerticalForm.value.bvname= this.businessVerticalForm.value.bvname,
      this.businessVerticalForm.value.bvHead= this.businessVerticalForm.value.bvHead[0].userId,
      this.businessVerticalForm.value.isActive = this.businessVerticalForm.value.isActive ? true : false,
      this.businessVerticalForm.value.createdBy = sessionStorage.getItem('username');
      this.businessVerticalForm.value.modifiedBy = sessionStorage.getItem('username');
      this._shared.post('BusinessVertical/CreateBusinessVertical', this.businessVerticalForm.value, 'admin').subscribe(res => {
        this.toast.show("BV assigned successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.businessVerticalForm.reset();
        this.getCompanyData(this.pageNumber, this.pageSize);
        this.selectedTabIndex = 0;
      });
    }else {
      this.businessVerticalForm.value.isActive = this.businessVerticalForm.value.isActive ? true : false;
      this.businessVerticalForm.value.modifiedBy = sessionStorage.getItem('username');
      this._shared.put('BusinessVertical/UpdateBusinessVertical', this.businessVerticalForm.value, 'admin').subscribe(res => {
        this.toast.show("Role updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
        this.bvData = {};
        this.getCompanyData(this.pageNumber, this.pageSize);
        this.selectedTabIndex = 0;
      });
    }
  }

  //search data from dropdown
  onSearch(evt: any) {
    if (evt.target.value == ""){
      this.getCompDropdownList(0,100);
    } else {
      console.log(evt.target.value);
      this.getUserDropdownData= [];
      let obj = { "searchcriteria": "user", "value": `${evt.target.value}` }
      this._shared.post('User/GetUsersListByCriteria', obj, 'admin').subscribe(res => {
        this.loader = false;
        this.getUserDropdownData = res;
      });
    }
  }

  //BV Head Dropdown form field
  getUserDropdownList(){
    this._shared.post('User/GetUsersListByCriteria', {}, 'admin').subscribe(res => {
      this.loader = false;
      this.getUserDropdownData = res;

    });
  } 

  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  OnItemDeSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  onDeSelectAll(items: any) {
    console.log(items);
  }


  getCompDropdownList(pageNumber:number, pageSize:number){
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize
    }
    this._shared.post('Company/GetCompanies', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.BVDropdown = res.item2;
    });
  }

  //user heads dropdown list 
  getHeadsDropdownList(pageNumber:number, pageSize:number){
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize
    }
  
    this._shared.post('User/GetUsersListByCriteria', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.compDropdown = res;
    });
    
  }

  //show company data in table
  getCompanyData(pageNumber:number, pageSize:number){
    let obj = {
      pageNumber: pageNumber,
      pageSize: pageSize
    }
    this._shared.post('Company/GetCompanies', obj, 'admin').subscribe(res => {
      this.loader = false;
      this.companyData = res.item2;
      this.totalCompany = res.item1;
    });
  }


//save company data
  saveModal(content: any,flag:any) {
    if(flag == 'Add'){
      this.companyForm.value.isActive = this.companyForm.value.isActive ? true : false,
      this.companyForm.value.city =  this.companyForm.value.city,
      this.companyForm.value.stateCode =  this.companyForm.value.state[0]?.stateCode,
      this.companyForm.value.countryCode =  this.companyForm.value.country,
      this.companyForm.value.createdBy = sessionStorage.getItem('username');

      this._shared.post('Company/CreateCompany', this.companyForm.value ,'admin').subscribe(res=>{
      this.toast.show("Records saved successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      this.getCompanyData(this.pageNumber, this.pageSize);
      this.selectedTabIndex = 0;
      this.companyForm.reset();
    })
    }else{
    this.companyForm.value.city =  this.companyForm.value.city,
      this.companyForm.value.stateCode =  this.companyForm.value.state[0]?.stateCode,
      this.companyForm.value.countryCode = this.companyForm.value.country[0]?.countryCode,
      this.companyForm.value.modifiedBy = sessionStorage.getItem('username');
    this._shared.put('Company/UpdateCompany', this.companyForm.value, 'admin').subscribe(res => {
      this.toast.show("Records updated successfully", { classname: 'bg-success text-light', delay: 3000, autohide: true });
      this.loader = false;
      this.getCompanyData(this.pageNumber, this.pageSize);
      this.selectedTabIndex = 0;
      this.changeTitleAddViewEdit = 'Add';
    });
    }  
  }

  edit(data:any, status:any) {
    if(status == 'edit'){
      this.changeTitleAddViewEdit = 'Edit';
      this.selectedTabIndex = 1;
      this.editFlag = true;
      this.companyForm.value.companyId = data.companyId;
      
    }else if(status == 'view'){
      this.selectedTabIndex = 1;
      this.changeTitleAddViewEdit = 'View';
      this.editFlag = false;
    }else{}
      this.companyForm.patchValue({
        companyId:data.companyId,
        companyCode: data.companyCode ,
        companyName: data.companyName,
        companyHead: data.companyHead,
        addressLine1: data.addressLine1,
        addressLine2: data.addressLine2,
        addressLine3: data.addressLine3,
        city: data.cityId,
        state: data.stateId,
        country: data.countryId,
        pinCode: data.pinCode,
        TANNumber: data.tannumber,
        TINNumber: data.tinnumber,
        PANNumber: data.pannumber,
        GSTINNumber: data.gstinnumber,
        isActive: data.isActive,
        createdOn: data.created,  
        createdBy: data.createdBy,
        modifiedOn: data.modified,
        modifiedBy: data.modifiedBy,   
    })
  }


  //to filter table data
  filterData(event:any){
    event.pageSize = this.pageSize;
    event.pageNumber = this.pageNumber;
    console.log(event);
    this._shared.post('Company/SearchCompanies',event,'admin').subscribe(res=>{
      this.loader = false;
      this.companyData = res.item2;
      this.hasFilteredData = event;
      this.totalCompany = res.item1;
    });
  }

  //to clear search field
  refresh(event:any){
    if(event){
      this.getCompanyData(this.pageNumber, this.pageSize);
      this.hasFilteredData={};
    }
  }

  //pagination
  onPageChange(event:any){
    if (Object.keys(this.hasFilteredData).length !=0){
      this.hasFilteredData.pageNumber = event.page;
      this.hasFilteredData.pageSize = event.rows;
      this.pageSize = event.rows;
      this._shared.post('Company/SearchCompanies', this.hasFilteredData , 'admin').subscribe(res => {
        this.loader = false;
        this.companyData = res.item2;
        this.totalCompany = res.item1;
      });
    } else {
      this.pageSize = event.rows;
      this.pageNumber = event.page;
      this.getCompanyData(event.page, event.rows);
    }
  }

  //change tab value on click
  tabChange(e:any){
    this.editFlag = true;
    this.disabledBVTab = true;
    this.changeTitleAddViewEdit = 'Add';
    this.companyForm.reset();
    this.companyForm.patchValue({'isActive':true});
    let index = e.index;
    if(index ==0){
      this.selectedTabIndex = 0;
      this.getCompanyData(this.pageNumber, this.pageSize);
    }
  }

  //to create and download excel
  exportAsXLSX() {
    if (this.companyData.length > 0) {
      this.excelService.exportAsExcelFile(this.companyData, 'sample');
    }
  }

  //to create and download pdf
  createPdf() {
    // debugger;
    let head:any = [[]];
    let data:any = [[]];
    this.companyData.forEach((res:any, index:any) => {
      if (index == 0) {
        for (let obj in res) { 
          if(head[index].length<=8){
            head[0].push(obj);
            data[index].push(res[obj]); 
          }
        }
      } else {
        data.push([])
        for (let obj in res) {
          if (data[index].length <= 8) {
            data[index].push(res[obj])
          }
        }
      }
    })
  
    let doc = new JSPDF.jsPDF("l", "in"); 

    doc.setFontSize(9);
    doc.text('', 11, 8);
    doc.setFontSize(9);
    doc.setTextColor(100);


    (doc as any).autoTable({
      head: head,
      body: data,
      theme: 'plain',
      didDrawCell: (data:any) => {
        console.log(data.column.index)
      }
    })

    // Open PDF document in new tab
    doc.output('dataurlnewwindow')

    // Download PDF document  
    doc.save('table.pdf');
  }

  ngOnDestroy(){
 /*this.subscription.unsubscribe();
     this.subscription1.unsubscribe();*/
  }

}
