# Attrium v0.0.1

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.4.2.
Developed using requisites:-
    _                      _                 ____ _     ___
   / \   _ __   __ _ _   _| | __ _ _ __     / ___| |   |_ _|
  / ? \ | '_ \ / _` | | | | |/ _` | '__|   | |   | |    | |
 / ___ \| | | | (_| | |_| | | (_| | |      | |___| |___ | |
/_/   \_\_| |_|\__, |\__,_|_|\__,_|_|       \____|_____|___|
               |___/

Angular CLI: 1.6.3
Node: 8.9.4
OS: win32 x64
Angular: 4.4.6
... animations, common, compiler, compiler-cli, core, forms
... http, language-service, platform-browser
... platform-browser-dynamic, router, tsc-wrapped

@angular/cli: 1.6.3
@angular-devkit/build-optimizer: 0.0.36
@angular-devkit/core: 0.0.22
@angular-devkit/schematics: 0.0.42
@ngtools/json-schema: 1.1.0
@ngtools/webpack: 1.9.3
@schematics/angular: 0.1.11
@schematics/schematics: 0.0.11
typescript: 2.5.3
webpack: 3.10.0

1. Clone the latest repository from GitLab. For this you will rquire the access of the GitLab account.
2. Install NPM packages with `npm install` in the project folder.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod --aot false` flag for a production build. Use the `--environment=dev --target=development` for development build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).
Before running the tests make sure you are serving the app via `ng serve`.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).


## Deploying on server

Deployment server - 52.59.59.17

1. Run `ng build --environment=dev --target=development` to build the target files. The build artifacts will be stored in the `dist/` directory. For Prod Build run `ng build --prod --aot false`.
2. Zip dist folder for deployment.
3. Open GIT BASH in dist folder.
4. Enter the following commands:-
    a. scp -i key.pem `folder.zip` ubuntu@52.59.59.17:/var/tmp
	b. ssh -i key.pem ubuntu@52.59.59.17
	c. cd /var/www/html
	d. mkdir `server_folder_name`
	e. cd `server_folder_name`
	f. mv /var/tmp/`folder.zip` .
	g. unzip `folder.zip`

## Debugging

1. If any issues occur the messages will give you a brief idea.
2. If something goes wrong and no message occured then open inspector's console and find the red errors on the console.
3. The errors will be more precise and accurate with the line number that has bug.
4. It will become very easy to track the files with error and we can fix them accordingly.
5. After changes, follow the deployment procedure and deploy the new build to the server. Also push the latest changes to GitLab.