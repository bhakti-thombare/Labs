import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'onlyFewLetters'
})
export class OnlyFewLettersPipe implements PipeTransform {
  transform(value: any, args?: any): any {
    if (args > 0) {
      const str = value;
      const limit = parseInt(args, 10);
      if (str) {
        const desc = str.length > limit ? '...' : '';
        if (str === 'Pedestrian Flow Survey') {
          return 'Pedestrian Flow';
        } else {
          return str.substr(0, limit) + desc;
        }
      }
    } else {
      const str = value;
      const desc = str.length > 30 ? '...' : '';
      return str.substr(0, 30) + desc;
    }
  }
}
