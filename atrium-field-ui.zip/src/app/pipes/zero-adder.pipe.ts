import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'zeroAdder'
})
export class ZeroAdderPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    const year = value.split('-')[0];
    let month = value.split('-')[1];
    let day = value.split('-')[2];
    if (month.length === 1) {
      month = '0' + month;
    }
    if (day.length === 1) {
      day = '0' + day;
    }
    return year + '-' + month + '-' + day;
  }

}
