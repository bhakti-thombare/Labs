import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'removeTime'
})
export class RemoveTimePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    let str = value;
    return str.split(" ")[0];
  }

}
