import { NgModule } from '@angular/core';
import { OnlyFewLettersPipe } from '@app/pipes/only-few-letters.pipe';
import { RemoveTimePipe } from '@app/pipes/remove-time.pipe';
import { ZeroAdderPipe } from '@app/pipes/zero-adder.pipe';
import { FormatLastSyncPipe } from '@app/pipes/format-last-sync.pipe';

@NgModule({
    declarations: [OnlyFewLettersPipe, RemoveTimePipe, ZeroAdderPipe, FormatLastSyncPipe],
    exports: [OnlyFewLettersPipe, RemoveTimePipe, ZeroAdderPipe, FormatLastSyncPipe]
})

export class PipesModule {
    constructor() {
    }
}
