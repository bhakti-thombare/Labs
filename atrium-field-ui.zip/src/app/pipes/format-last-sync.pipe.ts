import { Pipe, PipeTransform } from '@angular/core';
import { LastSyncService } from '@services/pipe/last-sync.service';
@Pipe({
  name: 'formatLastSync'
})
export class FormatLastSyncPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (value === undefined || value === null) {
      return 'N/A';
    } else {
      let lastSyncService = new LastSyncService();
      return lastSyncService.calculateLocalDateString(value);
    }
  }

}
