import { Component, OnInit, Input } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { IAfterGuiAttachedParams } from 'ag-grid-community';
import {
  each, keys
} from "underscore";
import { StorageService } from '@app/services/storage-service.service';

@Component({
  selector: 'app-validate-flag',
  templateUrl: './validate-flag.component.html',
  styleUrls: ['./validate-flag.component.css']
})
export class ValidateFlagComponent implements OnInit, ICellRendererAngularComp {
  showRed: boolean;
  showGreenTick: boolean;
  ngOnInit() {
  }
  showQuestion: boolean;
  constructor(private storageService: StorageService) {}

  params: any;
  refresh(params: any): boolean {
    throw new Error("Method not implemented.");
  }
  afterGuiAttached?(params?: IAfterGuiAttachedParams): void {
    throw new Error("Method not implemented.");
  }
  agInit(params: any): void {
    this.params = params;
    if (this.params.data.isUpdated === 'YES' || this.params.data.isUpdated === 'NO') {
      this.showQuestion = true;
    }
    if (this.params.data.validationFlag == 1) { 
      this.showGreenTick = true;
      this.showQuestion = false
    }
    if (this.params.data.validationFlag == 0) { 
      this.showRed = true;
      this.showQuestion = false
    }
  }

}
