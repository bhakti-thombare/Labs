import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidateFlagComponent } from './validate-flag.component';

describe('ValidateFlagComponent', () => {
  let component: ValidateFlagComponent;
  let fixture: ComponentFixture<ValidateFlagComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValidateFlagComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidateFlagComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
