import {Component} from '@angular/core';
import {ICellRendererAngularComp} from 'ag-grid-angular';

@Component({
  selector: 'app-radio-button-selector',
  templateUrl: './radio-button-selector.component.html',
  styleUrls: ['./radio-button-selector.component.css']
})

export class RadioButtonSelectorComponent implements ICellRendererAngularComp {

    public name: any;
    public params: any;

    /**
     * @description Life cycle hook
     * @public
     * @memberof RadioButtonSelectorComponent
     */
    public agInit(params: any): void {
        this.params = params;
        this.name = params.colDef.headerName;
    }

    /**
     * @description refresh method of ICellRendererAngularComp interface
     * @public
     * @memberof RadioButtonSelectorComponent
     */
    public refresh(params): boolean {
      return true;
    }

    /**
     * @description on change of radio button selection
     * @public
     * @memberof RadioButtonSelectorComponent
     */
    public handleChange() {
      this.params.node.setSelected(!this.params.node.selected);
    }
}

