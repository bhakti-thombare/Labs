import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { IAfterGuiAttachedParams } from 'ag-grid-community';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pos-mpd-photos',
  templateUrl: './pos-mpd-photos.component.html',
  styleUrls: ['./pos-mpd-photos.component.css']
})
export class PosMpdPhotosComponent  implements ICellRendererAngularComp {

  refresh(params: any): boolean {
    throw new Error("Method not implemented.");
  }
  afterGuiAttached?(params?: IAfterGuiAttachedParams): void {
    throw new Error("Method not implemented.");
  }
  public params: any;

  constructor(private router: Router) { }
  agInit(params: any): void {
    // console.log("hello=",params);
    
    this.params = params;
  }
  public infoLink() {
    // this.params.context.componentParent.methodFromParent(`Row: ${this.params.node.rowIndex}, Col: ${this.params.colDef.headerName}`)
    // this.router.navigate(['/supervisor/missions/infoSheet']);
  }


}
