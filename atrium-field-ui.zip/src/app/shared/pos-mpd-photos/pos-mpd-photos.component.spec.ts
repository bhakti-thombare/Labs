import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PosMpdPhotosComponent } from './pos-mpd-photos.component';

describe('PosMpdPhotosComponent', () => {
  let component: PosMpdPhotosComponent;
  let fixture: ComponentFixture<PosMpdPhotosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PosMpdPhotosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PosMpdPhotosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
