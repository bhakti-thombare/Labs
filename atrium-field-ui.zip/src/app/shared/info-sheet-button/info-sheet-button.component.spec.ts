import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InfoSheetButtonComponent } from './info-sheet-button.component';

describe('InfoSheetButtonComponent', () => {
  let component: InfoSheetButtonComponent;
  let fixture: ComponentFixture<InfoSheetButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InfoSheetButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoSheetButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
