import { each } from 'underscore';
import { Subscription } from 'rxjs/Subscription';
export class UtilityFunctions {
  constructor() {
  }
  unSubscribeSubscriptions(subscriptions: Subscription[]) {
    each(subscriptions, (data) => {
      data.unsubscribe();
    });
  }
}


