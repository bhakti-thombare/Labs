import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

// import { AgGridModule } from "ag-grid-angular/main";
// import { LicenseManager } from 'ag-grid-enterprise';

// import { RadioButtonSelectorComponent } from './radio-button-selector/radio-button-selector.component';
// import { GridWrapperComponent } from './grid-wrapper/grid-wrapper.component';

// TODO: Add the key to constants
// LicenseManager.setLicenseKey('Evaluation_License_Valid_Until_1_August_2018__MTUzMzA3ODAwMDAwMA==8c0b423295f5960e7d0f3cbb4292e068');

@NgModule({
    declarations: [
    ],
    exports: [
    ],
    imports: [
        // AgGridModule.withComponents([RadioButtonSelectorComponent]),
    ],
    entryComponents: []
})
export class SharedModule { }
