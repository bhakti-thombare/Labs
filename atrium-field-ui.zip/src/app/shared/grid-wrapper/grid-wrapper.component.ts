
import { Component, OnInit, ViewChild, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';

import { AgGridNg2 } from 'ag-grid-angular';
import { StorageService } from '@app/services/storage-service.service';
/**
 *
 *
 * @export
 * @class GridWrapperComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-grid',
  templateUrl: './grid-wrapper.component.html',
  styleUrls: ['./grid-wrapper.component.css'],
  encapsulation: ViewEncapsulation.None,
  exportAs: 'gridTable'
})


export class GridWrapperComponent implements OnInit {

  /**
   * declares all the properties required by the grid
   *
   * @type {AgGridNg2}
   * @memberof GridWrapperComponent
   */
  // ToDO: Rename bottom grid to relevant name and its methods
  @ViewChild('bottomGrid') bottomGrid: AgGridNg2;
  @ViewChild('agGrid') agGrid: AgGridNg2;
  @Output() cellClicked = new EventEmitter();
  @Output() rowClicked = new EventEmitter();
  @Input('rowData') public rowData: Array<any> = [];
  @Input('columnDefs') public columnDefs: Array<any> = [];
  @Input('bottomColumnDefs') public bottomColumnDefs: Array<any> = [];
  @Input('enableSorting') public enableSorting: String = 'true';
  @Input('pagination') public pagination: Boolean = true;
  @Input('editType') public editType: String = '';
  @Input('suppressClickEdit') public suppressClickEdit: Boolean = false;
  @Input('singleClickEdit') public singleClickEdit: Boolean = false;
  @Input('showAlignedGrids') public showAlignedGrids: Boolean = false;
  @Input('showTopGrid') public showTopGrid: Boolean = true;
  @Input('headerHeight') public headerHeight: Number = 32;
  @Input('headerGridData') public headerGridData: Array<any> = [];
  @Input('rowSelection') public rowSelection: String = 'single';
  @Input('components') public components;
  @Input('enableRangeSelection') public enableRangeSelection: Boolean = false;
  @Input('frameworkComponents') public frameworkComponents = {};
  @Input('currentPage') currentPage;
  @Input('sortState') sortState;
  @Input() isColumnAlignmentRequired: Boolean = true;
  @Input('enableColResize') enableColResize = true;
  @Input('groupHeaderHeight') public groupHeaderHeight;
  @Output() cellValueChanged = new EventEmitter();
  @Output() columnResized = new EventEmitter();
  // default grid definations like comparator
  public defaultColDef;
  constructor(private storageService: StorageService) { }


  /**
   *@description defines comparator for proper sorting
   *
   * @memberof GridWrapperComponent
   */
  ngOnInit() {
    this.defaultColDef = {
      suppressMovable: true,
      comparator: function (a, b) {
        let nameA, nameB;
        if (typeof (a) === 'string' && typeof (b) === 'string') {
          a = a.toLowerCase();
          b = b.toLowerCase();
        }
        nameA = (a === null) ? '' : a;
        nameB = (b === null) ? '' : b;
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
        return 0;
      }
    };
  }

  /**
   *@description align the columns when the grid is shown
   *
   * @memberof GridWrapperComponent
   */
  onGridReady() {
    if (this.isColumnAlignmentRequired) {
      this.alignColumns();
    } else {
      this.agGrid.api.setHeaderHeight(65);
    }
    // ToDo -- use storage service instead of localstorage
    this.agGrid.api.paginationGoToPage(parseInt(this.storageService.getData(this.currentPage), 10));
    if (this.sortState !== undefined) {
      const sortState = JSON.parse(this.storageService.getData(this.sortState));
      this.agGrid.api.setSortModel(sortState);
    }

    // to set row height as per column data where autoHeight = true
    this.agGrid.api.resetRowHeights();
  }


  /**
   *@description called when sort order is changed, to remember the sort state when navigating between pages
   *
   * @memberof GridWrapperComponent
   */
  public onSortChange() {
    const sortState = this.agGrid.api.getSortModel();
    if (this.sortState !== undefined) {
      this.storageService.setData(this.sortState, JSON.stringify(sortState));
    }
  }

  /**
   *
   *@description this method is called when a cell is clicked on the grid,
   This emits an event to the respective component
   * @param {*} event
   * @memberof GridWrapperComponent
   */
  public onCellClicked(event: any) {
    this.cellClicked.emit(event);
    this.agGrid.api.resetRowHeights();
  }

  /**
   *
   * @description this method is used for storing current page number
   * @param {*} event
   * @memberof GridWrapperComponent
   */
  public onPaginationChanged(event) {
    if (event.newPage === true) {
      this.storageService.setData(this.currentPage, this.agGrid.api.paginationGetCurrentPage() + '');
    }
  }
  /**
   *@description this event is called when a row is clicked in the grid
   *
   * @param {*} event
   * @memberof GridWrapperComponent
   */
  public onRowClicked(event: any) {
    this.rowClicked.emit(event);
  }

  /**
   *@description called when a grid is to be refreshed
   *
   * @memberof GridWrapperComponent
   */
  public refresh() {
    this.agGrid.api.refreshCells();
  }

  /**
   *
   *@description a method to show row/cell as editable when a grid is displayed
   * this is used for the main grid which shows the data and not the grid which add the data to the parent grid
   * @param {number} rowIndex
   * @param {string} key
   * @memberof GridWrapperComponent
   */
  public onRowEdit(rowIndex: number, key: string) {
    // ToDo: do not use settimeout
    setTimeout(() => {
      this.agGrid.api.setFocusedCell(rowIndex, key);
      this.agGrid.api.startEditingCell({
        rowIndex: rowIndex,
        colKey: key
      });
    }, 0);
  }

  /**
   *@description called the grid editing needs to be stopped
   *
   * @param {boolean} flag
   * @memberof GridWrapperComponent
   */
  public stopEditing(flag: boolean) {
    this.agGrid.api.stopEditing(flag);
  }

  /**
   *@description  set the grid columns size to fit, this is called to adjust grid columns when the grid layout is changed
   *
   * @memberof GridWrapperComponent
   */
  alignColumns() {
    this.agGrid.api.sizeColumnsToFit();
    if (this.bottomGrid) {
      this.bottomGrid.api.sizeColumnsToFit();
    }
    if (this.agGrid) {
      this.agGrid.api.sizeColumnsToFit();
    }
  }

  /**
   *@description get the editable cells of the grid
   *
   * @returns
   * @memberof GridWrapperComponent
   */
  getEditingCells() {
    const cellDefs = this.agGrid.api.getEditingCells();
    return cellDefs.length;
  }

  /**
   *@description get the editable cells of the aligned grids which is used to add fields in the main field
   *
   * @param {string} key
   * @memberof GridWrapperComponent
   */
  bottomGridDefaultEditing(key: string) {
    if (this.bottomGrid) {
      this.bottomGrid.api.startEditingCell({
        rowIndex: 0,
        colKey: key
      });
    }
  }

  /**
   *@description add new row/ data in the grid
   *
   * @param {*} item
   * @param {string} key
   * @param {*} bottomGridData
   * @memberof GridWrapperComponent
   */
  addRowData(item: any, key: string, bottomGridData) {
    const that = this;
    that.agGrid.api.updateRowData({ add: [item] });
    if (bottomGridData) {
      that.bottomGrid.api.setRowData(bottomGridData);
    }
    // TODO: do not use settimeout
    setTimeout(function () {
      that.bottomGridDefaultEditing(key);
    }, 0);
  }

  /**
   *@description delete data/row from the grid
   *
   * @param {*} item
   * @memberof GridWrapperComponent
   */
  removeSelectedRow(item: any) {
    this.agGrid.api.updateRowData({ remove: [item] });
  }

  /**
   *@description stop the aligned grid editing which is used to add fields in the main field
   *
   * @memberof GridWrapperComponent
   */
  stopBottomGridEditing() {
    this.bottomGrid.api.stopEditing();
  }

  /**
   *@description emit emitter when a cell values changes, generally called when a grid dropdown value is changed.
   *
   * @param {*} event
   * @param {*} [gridType]
   * @memberof GridWrapperComponent
   */
  public onCellValueChanged(event, gridType?) {
    const obj = { event, gridType };
    this.cellValueChanged.emit(obj);
  }

  /**
   * @description called to adjust the width and height of the column according to the content
   *
   * @param {*} event
   * @memberof GridWrapperComponent
   */
  public onColumnResized(event) {
    if (event.finished) {
      this.agGrid.api.resetRowHeights();
    }
  }

  /**
   *@description get the column details of the aligned grid
   *
   * @param {String} colId
   * @returns
   * @memberof GridWrapperComponent
   */
  getBottomGridColumnDetails(colId: String) {
    const column = this.bottomGrid.columnApi.getColumn(colId);
    return column;
  }

  /**
   *@description range selection: get the selected ranges and update the values of the cell
   *
   * @param {string} value
   * @returns
   * @memberof GridWrapperComponent
   */
  public updateSelectedRange(value: string) {
    const rangeSelections = this.agGrid.api.getRangeSelections();
    if (!rangeSelections || rangeSelections.length === 0) {
      return;
    }
    const firstRange = rangeSelections[0];
    const startRow = Math.min(firstRange.start.rowIndex, firstRange.end.rowIndex);
    const endRow = Math.max(firstRange.start.rowIndex, firstRange.end.rowIndex);
    const api = this.agGrid;
    for (let rowIndex = startRow; rowIndex <= endRow; rowIndex++) {
      firstRange.columns.forEach(function (column) {
        const rowModel = api.api.getModel();
        const rowNode = rowModel.getRow(rowIndex);
        rowNode.setDataValue(column, value);
      });
    }
    this.agGrid.api.clearRangeSelection();
  }

  /**
   *@description get the selected rows(single/multiple)
   *
   * @memberof GridWrapperComponent
   */
  getSelectedRow() {
    this.agGrid.api.getSelectedRows();
  }
}

