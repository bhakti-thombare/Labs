import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldagentComponent } from './fieldagent.component';

describe('FieldagentComponent', () => {
  let component: FieldagentComponent;
  let fixture: ComponentFixture<FieldagentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FieldagentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldagentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
