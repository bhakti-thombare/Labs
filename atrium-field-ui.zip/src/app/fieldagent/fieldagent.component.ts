import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fieldagent',
  templateUrl: './fieldagent.component.html',
  styleUrls: ['./fieldagent.component.css']
})
export class FieldagentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
