import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { HttpService } from '@app/services/http-service';

@Component({
  selector: 'app-dashbaord',
  templateUrl: './dashbaord.component.html',
  styleUrls: ['./dashbaord.component.css']
})
export class DashbaordComponent implements OnInit {

  user;

  constructor(public router: Router, public http: HttpService) { }

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user-data'));
    if (this.user.isActive && this.user.resetProfile) {
      this.router.navigate(['/fieldagent/profile']);
    } else {

    }
  }

  logout() {
    this.http.SecureGet('/user/logout').subscribe(res => {
      localStorage.clear();
      sessionStorage.clear();
      this.router.navigate(['/login']);
    }, err => {
      localStorage.clear();
      sessionStorage.clear();
      this.router.navigate(['/login']);
    });
  }

}
