import { Routes } from '@angular/router';
import { ProfileComponent } from '@app/fieldagent/profile/profile.component';
import { DashbaordComponent } from '@app/fieldagent/dashbaord/dashbaord.component';

export const FieldagentRoutes: Routes = [
    /* Redirect to paths */
    {
        path: '',
        redirectTo: 'fieldagent/dashboard',
        pathMatch: 'full'
    },
    {
        path: 'fieldagent',
        redirectTo: 'fieldagent/dashboard',
        pathMatch: 'full'
    },
    {
        path: 'dashboard',
        redirectTo: 'fieldagent/dashboard',
        pathMatch: 'full'
    },
    {
        path: 'profile',
        redirectTo: 'fieldagent/profile',
        pathMatch: 'full'
    },
    /* Component Paths */
    {
        path: 'dashboard',
        component: DashbaordComponent
    },
    {
        path: 'profile',
        component: ProfileComponent
    }];
