// core imports
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// 3rd party imports
import { TranslateModule } from '@ngx-translate/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

// app imports
import { ProfileComponent } from '@app/fieldagent/profile/profile.component';
import { FieldagentRoutes } from '@app/fieldagent/fieldagent.routes';
import { DashbaordComponent } from '@app/fieldagent/dashbaord/dashbaord.component';
import { PipesModule } from '@pipes/pipes.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(FieldagentRoutes),
    NgbModule,
    PipesModule,
    TranslateModule,
    FormsModule
  ],
  declarations: [
    ProfileComponent,
    DashbaordComponent
  ]
})
export class FieldagentModule { }
