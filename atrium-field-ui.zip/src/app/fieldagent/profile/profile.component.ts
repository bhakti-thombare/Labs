// core imports
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';

// 3rd import
import swal from 'sweetalert2';

// app imports
import { ApiService } from '@services/apiServices/api.service';
import { SetCampaignDataService } from '@services/set-campaign-data/set-campaign-data.service';
import { EventService } from '@services/events/event.service';
import { LanguageInterface } from '@app/interfaces/interface';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit, AfterViewInit {

  constructor(
    public api: ApiService,
    public campDataService: SetCampaignDataService,
    public router: Router,
    public event: EventService) { }

  public language: LanguageInterface;
  public languages = [];

  public myForm = new FormGroup({
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    contact: new FormControl('', [Validators.required, Validators.pattern('^[1-9][0-9]{7,13}$')]),
    address: new FormControl('', Validators.required)
  });

  public user = JSON.parse(localStorage.getItem('user-data'));
  ngOnInit() {
    console.log('logged-in member', this.user);
    this.getLanguage(this.user.preferredLanguage ? this.user.preferredLanguage : 1);
    this.api.getRoles(this.user.roleId).subscribe(res => {
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
      localStorage.setItem('reloader', 'false');
      console.log(res);
      this.user.role = res.data[0].name;
    }, err => {
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
      localStorage.setItem('reloader', 'false');
      console.log(err);
    });
  }

  ngAfterViewInit() {
    if (window.innerWidth <= 992) {
      $('.wrap-textarea>textarea').css('width', '80%');
    }
    if (window.innerWidth >= 992) {
      $('.wrap-textarea>textarea').css('width', '83%');
    }
    if (window.innerWidth >= 1024) {
      $('.wrap-textarea>textarea').css('width', '83%');
    }
    if (window.innerWidth >= 1366) {
      $('.wrap-textarea>textarea').css('width', '85%');
    }
    if (window.innerWidth >= 1600) {
      $('.wrap-textarea>textarea').css('width', '90%');
    }
  }

  toggleLanguage(language) {
    this.languages.push(this.language);
    this.language = language;
    const languagefinder = (lang) => {
      return lang.id === language.id;
    };
    const delInd = this.languages.findIndex(languagefinder);
    this.languages.splice(delInd, 1);
  }

  submit(form) {
    if (form.valid) {
      console.log(form.value);
      const reqObj = {
        userId: this.user.userId,
        firstName: form.value.firstName,
        lastName: form.value.lastName,
        contactNumber: form.value.contact,
        resetPassword: false,
        resetProfile: false,
        address: form.value.address,
        preferredLanguage: this.language.id
      };
      this.updateProfile(reqObj);
    } else {
      swal(MESSAGECONSTANTS.ALERT_MESSAGES.ALL_FIELDS_ARE_MANDATORY, '', 'warning');
    }
  }

  getLanguage(id?: string) {
    this.api.getLanguages(id ? id : '').subscribe(res => {
      if (id) {
        this.language = res.data[0];
        this.getLanguage();
      } else {
        return this.languagesParser(res.data);
      }
    }, err => {
      return !id ? 3 : '';
    });
  }

  languagesParser(langArray) {
    langArray.forEach(lang => {
      if (this.language === lang.name) {
        return lang.id;
      }
      if (lang.id !== this.language.id) {
        this.languages.push(lang);
      }
    });
  }

  updateProfile(profile) {
    this.api.updateUser(profile).subscribe(res => {
      if (res.updatedData.resetProfile === false && this.user.resetProfile === true) {
        console.log('res', res);
        this.user.resetProfile = res.updatedData.resetProfile;
        this.user.preferredLanguage = res.updatedData.preferredLanguage;
        localStorage.removeItem('user-data');
        localStorage.setItem('user-data', JSON.stringify(this.user));
        console.log('local user data', JSON.parse(localStorage.getItem('user-data')));
        const data = this.campDataService.getCampaignData();
        console.log(data);
        this.rerouter(this.user.roleId);
      } else {
        localStorage.removeItem('user-data');
        this.user.preferredLanguage = res.updatedData.preferredLanguage;
        localStorage.setItem('user-data', JSON.stringify(this.user));
        console.log('local user data', JSON.parse(localStorage.getItem('user-data')));
        console.log('res', res);
        localStorage.setItem('on-load', 'true');
        swal(MESSAGECONSTANTS.ALERT_MESSAGES.ACCOUNT_UPDATED_SUCCESSFULLY, '', 'success').then(data => {
          if (this.user.roleId === 2) {
            this.router.navigate(['/supervisor']);
          } else if (this.user.roleId === 3) {
            this.router.navigate(['/fieldagent']);
          } else {
            this.router.navigate(['/admin']);
          }
          window.location.reload();
        });
      }
    }, err => {
      console.log('err', err);
    });
  }

  rerouter(role) {
    if (this.user.roleId === 2) {
      localStorage.setItem('on-load', 'true');
      swal(MESSAGECONSTANTS.ALERT_MESSAGES.ACCOUNT_UPDATED_SUCCESSFULLY, '', 'success').then(() => {
        this.router.navigate(['/supervisor']);
        window.location.reload();
      });
    } else if (this.user.roleId === 1) {
      localStorage.setItem('on-load', 'true');
      swal(MESSAGECONSTANTS.ALERT_MESSAGES.ACCOUNT_UPDATED_SUCCESSFULLY, '', 'success').then(() => {
        this.router.navigate(['/admin']);
        window.location.reload();
      });
    }
  }

}
