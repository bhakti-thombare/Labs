// core
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

// 3rd party
import 'rxjs/add/operator/map';
import swal from 'sweetalert2';

// app
import { HttpService } from '@app/services/http-service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

@Component({
  selector: 'app-verification',
  templateUrl: './verification.component.html',
  styleUrls: ['./verification.component.css']
})
export class VerificationComponent implements OnInit {
  passwordMismatchError: boolean;
  disableSubmit = false;
  private myForm: FormGroup;
  private user = {
    'password': '',
    'repeatPassword': ''
  };
  private email;
  constructor(public router: Router, public http: HttpService, private route: ActivatedRoute) {
    this.route.params.subscribe(params => {
      this.email = params.email;
    });
  }

  ngOnInit() {
    this.myForm = new FormGroup({
      'code': new FormControl('', Validators.required),
      'password': new FormControl('', [Validators.required, Validators.pattern('^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$')]),
      'repeatPassword': new FormControl('',
        [Validators.required, Validators.pattern('^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$')])
    });
  }

  verify(form) {
    console.log(form.valid);
    if (form.valid && form.value.password === form.value.repeatPassword) {
      this.disableSubmit = true;
      const req = {
        'verificationCode': form.value.code,
        'recoveryEmail': this.email,
        'newPassword': form.value.password
      };
      this.http.Post('/user/changePassword', req).subscribe(data => {
        swal(
          MESSAGECONSTANTS.ALERT_MESSAGES.PASSWORD_CHANGED_SUCCESSFULLY,
          '',
          'success'
        ).then(() => {
          this.router.navigate(['/login']);
        });
      }, err => {
        swal(
          MESSAGECONSTANTS.ALERT_MESSAGES.INVALID_CREDENTIALS,
          MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_TRY_AGAIN,
          'error'
        );
        this.disableSubmit = false;
      });
    } else {
      swal(
        MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_FILL_ALL_DETAILS_ENG, 
        MESSAGECONSTANTS.ALERT_MESSAGES.PASSWORD_SHOULD_MATCH , 'warning');
      this.disableSubmit = false;
    }
  }
  matchPasswords(event) {

    if (this.user.password === event.target.value && this.user.password.length === event.target.value.length) {
      this.passwordMismatchError = false;
    } else if (this.user.password !== event.target.value && this.user.password.length === event.target.value.length) {
      this.passwordMismatchError = true;
    }
  }

}
