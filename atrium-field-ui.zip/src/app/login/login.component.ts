// core imports
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

// 3rd party imports
import 'rxjs/add/operator/map';
import swal from 'sweetalert2';

// app imports
import { SetCampaignDataService } from '@services/set-campaign-data/set-campaign-data.service';
import { HttpService } from '@app/services/http-service';
import { ApiService } from '@services/apiServices/api.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';
import { StorageService } from '@app/services/storage-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  isIosDevice: boolean = false;
  user = new FormControl();
  disableSubmit = false;
  public myForm: FormGroup = new FormGroup({
    username: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  });
  constructor(public router: Router,
    public http: HttpService,
    public campDataService: SetCampaignDataService,
    public api: ApiService, private storageService: StorageService
  ) {
  }
  ngOnInit() {
    this.isIosDevice = this.getUserAgent();
    if (this.isIosDevice) this.router.navigate(['ota/index']);
  }
  getUserAgent() { return !!navigator.platform && /iPad/.test(navigator.platform); }
  login(form) {
    if (form.valid) {
      this.disableSubmit = true;
      this.api.login(form.value).subscribe(data => {
        sessionStorage.setItem('role', data.signInData.roleId);
        this.storageService.setUserData('userId', data.signInData.userId);
        if (data.signInData.isActive) {
          if (data.signInData.resetProfile) {
            if (parseInt(data.signInData.roleId, 10) === 2) {
              localStorage.setItem('user-data', JSON.stringify(data.signInData));
              this.router.navigate(['/supervisor/profile']);
            } else if (parseInt(data.signInData.roleId, 10) === 1) {
              localStorage.setItem('user-data', JSON.stringify(data.signInData));
              this.router.navigate(['/admin/profile']);
            } else {
              localStorage.setItem('user-data', JSON.stringify(data.signInData));
              this.router.navigate(['/fieldagent/profile']);
            }
          } else {
            if (parseInt(data.signInData.roleId, 10) === 3) {
              localStorage.setItem('user-data', JSON.stringify(data.signInData));
              this.router.navigate(['/fieldagent']);
            } else {
              localStorage.setItem('user-data', JSON.stringify(data.signInData));
              localStorage.setItem('on-load', 'true');
              const temp = this.campDataService.getCampaignData();
            }
          }
        } else {
          swal(
            MESSAGECONSTANTS.ALERT_MESSAGES.ACCOUNT_NOT_ACTIVE,
            MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_CONTACT_ADMIN_TO_ACTIVTE_UR_ACCOUNT,
            'warning'
          );
          this.disableSubmit = false;
        }
      }, err => {
        swal(
          MESSAGECONSTANTS.ALERT_MESSAGES.INVALID_CREDENTIALS,
          MESSAGECONSTANTS.ALERT_MESSAGES.INCORRECT_USERNAME_OR_PASSWORD,
          'error'
        );
        this.disableSubmit = false;
      });
    }
  }
  forgot() {
    this.router.navigate(['/forgot']);
  }
}
