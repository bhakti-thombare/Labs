import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { Http, HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
// import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DatePipe } from '@angular/common';
import { PreloadAllModules, RouterModule } from '@angular/router';
// import { DragDropModule } from '@angular/cdk/drag-drop';

import jQuery, * as $ from 'jquery';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TagInputModule } from 'ngx-chips';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxMapboxGLModule } from 'ngx-mapbox-gl';
import { Ng4FilesModule } from 'angular4-files-upload';
import { AgmCoreModule } from "@agm/core";
import { NgbModule,NgbTypeaheadModule } from '@ng-bootstrap/ng-bootstrap';
import { ChartsModule } from 'ng2-charts';
// import { AngularMultiSelectModule } from 'angular4-multiselect-dropdown/angular4-multiselect-dropdown';
import { PedestrainAlertsService } from '@services/Alerts/pedestrainAlerts/pedestrain-alerts.service';
import { MissionListAlertsService } from '@services/Alerts/mission-list-alerts.service';
import { CustomerSurveyAlertsService } from '@services/Alerts/customer-survey-alerts.service';
import { ServicesModule } from '@services/services.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { AppComponent } from '@app/app.component';
import { AppRoutes } from '@app/app.routes';
import { LoginComponent } from '@app/login/login.component';
import { ForgotComponent } from '@app/forgot/forgot.component';
import { AdminComponent } from '@app/admin/admin.component';
import { VerificationComponent } from '@app/verification/verification.component';
import { AdminModule } from '@app/admin/admin.module';
import { SupervisorComponent } from '@app/supervisor/supervisor.component';
import { SupervisorModule } from '@app/supervisor/supervisor.module';
import { VerificationMessageComponent } from '@app/verification-message/verification-message.component';
import { PipesModule } from '@app/pipes/pipes.module';
import { LoaderComponent } from '@app/loader/loader.component';
import { FieldagentModule } from '@app/fieldagent/fieldagent.module';
import { FieldagentComponent } from '@app/fieldagent/fieldagent.component';
import { CONFIG } from '@app/config';
import { OtaComponent } from '@app/ota/ota.component';
import { SharedModule } from '@app/shared';
import { StorageService } from '@app/services/storage-service.service';
// emitters
import { MenuLoadEvent, LoaderEvent } from './core/message-event';
import { Broadcaster } from './core/broadcaster';

window['jQuery'] = window['$'] = $;

export function HttpLoaderFactory(http: Http) {
  // for development
  // return new TranslateHttpLoader(http, '/start-angular/SB-Admin-BS4-Angular-4/master/dist/assets/i18n/', '.json');
  return new TranslateHttpLoader(http, '/assets/i18n/', '.json');
}
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ForgotComponent,
    //AdminComponent,
    //FieldagentComponent,
    VerificationComponent,
    VerificationMessageComponent,
    //SupervisorComponent,
    LoaderComponent,
    OtaComponent ],
  imports: [
    ServicesModule,
    // BrowserModule,
    // DragDropModule,
    FormsModule,
    ReactiveFormsModule,
    NgxChartsModule,
    PipesModule,
    HttpModule,
    Ng4FilesModule,
    PipesModule,
    //AdminModule,
    //SupervisorModule,
    //FieldagentModule,
    // AngularMultiSelectModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyCZVe-L8JKBxpndD6l5CgsRiPQ1LwjrfH0'
    }),
    // NgxMapboxGLModule.forRoot({
    //   accessToken: CONFIG.mapBoxAccessToken
    // }),
    HttpClientModule,
    NgbModule.forRoot(),
    ChartsModule,
    RouterModule.forRoot(AppRoutes, {
      preloadingStrategy: PreloadAllModules
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    }),
    TagInputModule,
    BrowserAnimationsModule,
    NgbTypeaheadModule,
    NgSelectModule,
    SharedModule],
  providers: [MenuLoadEvent, StorageService, LoaderEvent, Broadcaster, MissionListAlertsService, CustomerSurveyAlertsService,DatePipe,PedestrainAlertsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
