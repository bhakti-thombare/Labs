// core
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

// 3rd party
import 'rxjs/add/operator/map';

// app
import { HttpService } from '@app/services/http-service';
import { EventService } from '@services/events/event.service';
import { ApiService } from '@services/apiServices/api.service';
import { Subscription } from 'rxjs/Subscription';
import { isNull } from 'util';

@Component({
  selector: 'app-edit-location',
  templateUrl: './edit-location.component.html',
  styleUrls: ['./edit-location.component.css']
})
export class EditLocationComponent implements OnInit {

  locationLoader: boolean = false;
  locations: Array<any> = [];
  showEditLocationByType: any;

  private subscriptions: Subscription[] = [];

  constructor(public router: Router,
    public http: HttpService,
    private route: ActivatedRoute,
    public _event: EventService,
    public apiService: ApiService) { }

  ngOnInit() {
    this.route.params.subscribe(params => { this.getLocationByName(params.name); });
  }

  ngAfterViewInit() { }
  gotoCancel(event) {

    this.router.navigate([`/supervisor/location`]);
  }
  getLocationByName(name) {

    this.locationLoader = true;
    this.subscriptions.push(this.apiService.getLocations({ 'searchBy': 'locationName', name })
      .subscribe(res => {
        // this.locations = (!isNull(res.data)) ? res.data.content : [];
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        let locations = res.data.content[0];
        this.showEditLocationByType = locations.locationType;
      }, err => {
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.locationLoader = false;
      }));
  }

}
