import { Routes } from '@angular/router';

import { FormGuardService } from '@services/form-guard/form-guard.service';
import { PosPoiFlowComponent } from '@app/supervisor/create-survey/pos-poi-flow/pos-poi-flow.component';
import { DashboardComponent } from '@app/supervisor/dashboard/dashboard.component';
import { MissionsComponent } from '@app/supervisor/missions/missions.component';
import { CreateMissionComponent } from '@app/supervisor/create-mission/create-mission.component';
import { ProfileComponent } from '@app/supervisor/profile/profile.component';
import { MissionDetailsComponent } from '@app/supervisor/mission-details/mission-details.component';
import { EditMissionComponent } from '@app/supervisor/edit-mission/edit-mission.component';
import { EditLocationComponent } from '@app/supervisor/edit-location/edit-location.component';
import { CampaignsComponent } from '@app/supervisor/campaigns/campaigns.component';
import { ReassignComponent } from './mission-details-m/mission-progress-details/reassign/reassign.component';
import { CheckpointsComponent } from './mission-details-m/mission-progress-details/checkpoints/checkpoints.component';
import { InfoSheetComponent } from './mission-details-m/mission-progress-details/info-sheet/info-sheet.component';
import { CreateLocationComponent } from './create-location/create-location.component';
import { LocationComponent } from './location/location.component';
import { CsZoneComponent } from './create-location-survey/cs-zone/cs-zone.component';
import { PfCircuitComponent } from './create-location-survey/pf-circuit/pf-circuit.component';
import { StandsMarketComponent } from './create-location-survey/stands-market/stands-market.component';
import { EditCustomerSurveyComponent } from './edit-location-survey/edit-location-customer-survey/edit-location-customer-survey.component';
import { EditPedestrianFlowComponent } from './edit-location-survey/pedestrian-flow/pedestrian-flow.component';
import { EditMarketFlowComponent } from './edit-location-survey/market-flow/market-flow.component';
import { CalendarComponent } from './calendar/calendar.component';

import {ReassignPosComponent} from './mission-details-m/mission-progress-details/reassign/reassign-pos/reassign-pos.component';
import {SurveysModalComponent} from './mission-details-m/mdp-modals/surveys-modal/surveys-modal.component';
import {CsReassignComponent} from './mission-details-m/customer-survey-details/cs-reassign/cs-reassign.component';
import {StandReassignComponent} from './mission-details-stands/stand-reassign/stand-reassign.component';
import {PfReassignComponent} from './mission-details-m/pedestrain-details/pf-reassign/pf-reassign.component'
import { SupervisorComponent } from './supervisor.component';
import { SupervisorAuthGuardService } from '@app/services/supervisor-auth-guard/supervisor-auth-guard.service';
export const SupervisorRoutes: Routes = [
    {
        path: '',
        component: SupervisorComponent,
        canActivate: [SupervisorAuthGuardService],
        children:[
            {
                path: '',
                redirectTo:'calendar',
                component: CalendarComponent
            },
            {
                path: 'calendar',
                component: CalendarComponent
            },
            {
                path: 'dashboard',
                component: DashboardComponent
            },
            {
                path: 'campaigns',
                component: CampaignsComponent
            },
            {
                path: 'missions',
                component: MissionsComponent
            },
            {
                path: 'location',
                component: LocationComponent
            },
            {
                path: 'missions/details/:id/:missionTypeId',
                component: MissionDetailsComponent
            },
            {
                path: 'missions/details/:id/:missionTypeId/reassign',
                component: ReassignPosComponent
            },
            {
                path: 'missions/details/:id/:missionTypeId/cs/reassign',
                component: CsReassignComponent
            },
            {
                path: 'missions/details/:id/:missionTypeId/pf/reassign',
                component: PfReassignComponent
            },
            {
                path: 'missions/details/:id/:missionTypeId/stands/reassign',
                component: StandReassignComponent
            },
            {
                path: 'missions/edit/:id',
                component: EditMissionComponent
            },
            {
                path: 'location/edit/:name',
                component: EditLocationComponent
            },
            {
                path: 'missions/create',
                component: CreateMissionComponent
            },
            {
                path: 'location/createLocation',
                component: CreateLocationComponent
            },
            {
                path: 'location/cs-zone/:id',
                component: CsZoneComponent
            },
            {
                path: 'location/pf-zone/:id',
                component: PfCircuitComponent
            },
            {
                path: 'location/market-zone/:id',
                component: StandsMarketComponent
            },
            {
                path: 'edit-location/cs-zone/:name/:locationId/:elementId',
                component: EditCustomerSurveyComponent
            },
            {
                path: 'edit-location/pf-zone/:name/:locationId/:elementId',
                component: EditPedestrianFlowComponent
            },
            {
                path: 'edit-location/market-zone/:name/:locationId/:elementId',
                component: EditMarketFlowComponent
            },
            {
                path: 'newmissions',
                component: MissionsComponent//changed to old mission list component
            },
            {
                path: 'create-pos-poi',
                component: PosPoiFlowComponent
            },
            {
                path: 'supervisor/missions/reassign',
                component: ReassignComponent
            },
            {
                path: 'missions/details/:id/:missionTypeId/surveySheet',
                component: SurveysModalComponent
            },
            {
                path: 'supervisor/missions/checkpoint',
                component: CheckpointsComponent
            },
            {
                path: 'supervisor/missions/infoSheet',
                component: InfoSheetComponent
            },

            {
                path: 'profile',
                component: ProfileComponent,
                canDeactivate: [FormGuardService]
            }
        ],
    },
    
    /* Redirect to paths */
    /* {
        path: 'calendar',
        redirectTo: 'supervisor/calendar',
        pathMatch: 'full'
    },
    {
        path: 'supervisor',
        redirectTo: 'supervisor/calendar',
        pathMatch: 'full'
    },
    {
        path: 'campaigns',
        redirectTo: 'supervisor/campaigns',
        pathMatch: 'full'
    },
    {
        path: 'dashboard',
        redirectTo: 'supervisor/dashboard',
        pathMatch: 'full'
    },
    {
        path: 'missions',
        redirectTo: 'supervisor/missions',
        pathMatch: 'full'
    },
    {
        path: 'location',
        redirectTo: 'supervisor/location',
        pathMatch: 'full'
    },
    {
        path: 'edit-location',
        redirectTo: 'supervisor/edit-location',
        pathMatch: 'full'
    },
    {
        path: 'newmissions',
        redirectTo: 'supervisor/newmissions',
        pathMatch: 'full'
    },
    {
        path: 'missions/details/:id/:missionTypeId',
        redirectTo: 'supervisor/missions/details/:id/:missionTypeId',
        pathMatch: 'full'
    },
    {
        path: 'missions/create',
        redirectTo: 'supervisor/missions/create',
        pathMatch: 'full'
    },
    {
        path: 'location/createLocation',
        redirectTo: 'supervisor/location/createLocation',
        pathMatch: 'full'
    },
    {
        path: 'missions/edit/:id',
        redirectTo: 'supervisor/missions/edit/:id',
        pathMatch: 'full'
    },
    {
        path: 'profile',
        redirectTo: 'supervisor/profile',
        pathMatch: 'full'
    },
    {
        path: 'calendar',
        redirectTo: 'supervisor/calendar',
        pathMatch: 'full'
    },
    
     {   path: 'missions/details/:id/:missionTypeId/reassign',
        redirectTo: 'supervisor/missions/details/:id/:missionTypeId/reassign',
        pathMatch: 'full'
    },
    {
        path: 'missions/details/:id/:missionTypeId/cs/reassign',
        redirectTo: 'supervisor/missions/details/:id/:missionTypeId/cs/reassign',
        pathMatch: 'full'
    },
    {
        path: 'missions/details/:id/:missionTypeId/stands/reassign',
        redirectTo: 'supervisor/missions/details/:id/:missionTypeId/stands/reassign',
        pathMatch: 'full'
    },
    {
        path: 'missions/details/:id/:missionTypeId/pf/reassign',
        redirectTo: 'supervisor/missions/details/:id/:missionTypeId/pf/reassign',
        pathMatch: 'full'
    },
    {
        path: 'missions/details/:id/:missionTypeId/surveySheet',
        redirectTo: 'supervisor/missions/details/:id/:missionTypeId/surveySheet',
        pathMatch: 'full'
    }, */
 
    /* Component Paths */
    /* {
        path: 'dashboard',
        component: DashboardComponent
    },
    {
        path: 'campaigns',
        component: CampaignsComponent
    },
    {
        path: 'missions',
        component: MissionsComponent
    },
    {
        path: 'location',
        component: LocationComponent
    },
    {
        path: 'missions/details/:id/:missionTypeId',
        component: MissionDetailsComponent
    },
    {
        path: 'missions/details/:id/:missionTypeId/reassign',
        component: ReassignPosComponent
    },
    {
        path: 'missions/details/:id/:missionTypeId/cs/reassign',
        component: CsReassignComponent
    },
    {
        path: 'missions/details/:id/:missionTypeId/pf/reassign',
        component: PfReassignComponent
    },
    {
        path: 'missions/details/:id/:missionTypeId/stands/reassign',
        component: StandReassignComponent
    },
    {
        path: 'missions/edit/:id',
        component: EditMissionComponent
    },
    {
        path: 'location/edit/:name',
        component: EditLocationComponent
    },
    {
        path: 'missions/create',
        component: CreateMissionComponent
    },
    {
        path: 'location/createLocation',
        component: CreateLocationComponent
    },
    {
        path: 'location/cs-zone/:id',
        component: CsZoneComponent
    },
    {
        path: 'location/pf-zone/:id',
        component: PfCircuitComponent
    },
    {
        path: 'location/market-zone/:id',
        component: StandsMarketComponent
    },
    {
        path: 'edit-location/cs-zone/:name/:locationId/:elementId',
        component: EditCustomerSurveyComponent
    },
    {
        path: 'edit-location/pf-zone/:name/:locationId/:elementId',
        component: EditPedestrianFlowComponent
    },
    {
        path: 'edit-location/market-zone/:name/:locationId/:elementId',
        component: EditMarketFlowComponent
    },
    {
        path: 'newmissions',
        component: MissionsComponent//changed to old mission list component
    },
    {
        path: 'create-pos-poi',
        component: PosPoiFlowComponent
    },
    {
        path: 'supervisor/missions/reassign',
        component: ReassignComponent
    },
    {
        path: 'missions/details/:id/:missionTypeId/surveySheet',
        component: SurveysModalComponent
    },
    {
        path: 'supervisor/missions/checkpoint',
        component: CheckpointsComponent
    },
    {
        path: 'supervisor/missions/infoSheet',
        component: InfoSheetComponent
    },
    
    {
        path: 'profile',
        component: ProfileComponent,
        canDeactivate: [FormGuardService]
    },
    {
        path: 'calendar',
        component: CalendarComponent
    }, */    
];
