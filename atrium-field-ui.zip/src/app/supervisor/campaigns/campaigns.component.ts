// core imports
import { Component, OnInit, AfterViewInit } from '@angular/core';

// app imports
import { HttpService } from '@app/services/http-service';
import { EventService } from '@services/events/event.service';

@Component({
  selector: 'app-campaigns',
  templateUrl: './campaigns.component.html',
  styleUrls: ['./campaigns.component.css']
})
export class CampaignsComponent implements OnInit, AfterViewInit {
  id: number;
  campaigns: Array<Object> = [];
  showNullMessage: boolean;
  user = JSON.parse(localStorage.getItem('user-data'));
  noCamps = false;

  constructor(private http_: HttpService, private _event: EventService) {
    this._event.broadcast({ eventName: 'showLoader', data: '' });
  }

  ngOnInit() {
    this.http_.SecureGet('/ref/getAllCampaigns?assignedTo=' + this.user.userId).subscribe(
      (res) => {
        const respCamps = [];
        let campLen = res.data.campaigns.length;
        res.data.campaigns.forEach(campaign => {
          this.http_.SecureGet('/mission/getMissionCountsByCampaign?campaignId=' + campaign.campaignId).subscribe(response => {
            if (!campaign.campaignIsArchived) {
              campaign.counts = response.data;
              campaign.campaignNumberOfMissions = response.data.missionTotalCount;
              respCamps.push(campaign);
            }
            campLen--;
            if (campLen === 0) {
              this.loadCampaignData(respCamps);
            }
          }, err => {
          });
        });
      },
      (err) => {
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.noCamps = true;
      });
  }

  ngAfterViewInit() {
    this._event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'supervisorCampaignsLoaded') {
          setTimeout(() => {
            $('.progress-bar').css('height', '0.3rem');
          }, 100);
        }
      }
    });
  }

  loadCampaignData(campaigns) {
    this.campaigns = campaigns;
    if (campaigns.length === 0) {
      this.showNullMessage = true;
      this._event.broadcast({ eventName: 'hideLoader', data: '' });
    } else {
      this.addDates(campaigns);
      this.showNullMessage = false;
      this._event.broadcast({ eventName: 'hideLoader', data: '' });
      this._event.broadcast({ eventName: 'supervisorCampaignsLoaded', data: '' });
    }
  }

  addDates(campaigns) {
    campaigns.forEach(element => {
      /* element.campaignStartDate = '01-01-2018';
      element.campaignEndDate = '02-02-2018'; */
      if (element.campaignNumberOfMissionDone === 0) {
        element.percentage = 0;
      } else if (element.campaignNumberOfMissions === 0) {
        element.percentage = 0;
      } else {
        element.percentage = (element.campaignCompletedMissions / element.campaignNumberOfMissions) * 100;
      }
    });
    this.campaigns = campaigns;
  }


}
