import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

import { Subscription } from 'rxjs/Subscription';
import { map, findWhere, isUndefined } from 'underscore';
import {
  NgbActiveModal,
  ModalDismissReasons
} from '@ng-bootstrap/ng-bootstrap';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';

import { ApiService } from '@app/services/apiServices/api.service';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { TranslateService } from '@ngx-translate/core';
import { UTILS } from '@app/services/global-utility.service';
import { CustomerSurveyAlertsService } from '@app/services/Alerts/customer-survey-alerts.service';
import { Globals, missionTypes } from '@app/constants/constants';
import { StorageService } from '@app/services/storage-service.service';
import { EventService } from '@app/services/events/event.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reassign',
  templateUrl: './reassign.component.html',
  styleUrls: ['./reassign.component.css']
})
export class ReassignComponent implements OnInit {
  endDateObject: { day: number; month: number; year: number };
  startDateObject: { day: number; month: number; year: number };
  oldMissionDates: any[];
  fieldAgentID: string;
  @Output() back = new EventEmitter();
  rejectedData: any = [];
  selectedFieldAgent: any;
  missionId: any;
  missionDates: any[];
  days: number;
  step3Form: FormGroup;
  step1Form: FormGroup;
  private subscriptions: Subscription[] = [];
  private utilityFunctions = new UtilityFunctions();
  optionsSubtype: any = [];
  configAgents: any = {};
  optionsAgents: any = [];
  minDate: any = UTILS.minDate;
  today: Date = new Date();
  campEndDate: any = UTILS.minDate;
  // [maxDate]="maxDate"
  @Input() data;

  constructor(
    private apiService: ApiService,
    private translate: TranslateService,
    public custAlerts: CustomerSurveyAlertsService,
    private activeModal: NgbActiveModal,
    public fb: FormBuilder,
    private router: Router,
    private storageService: StorageService,
    private _event: EventService
  ) {}

  ngOnInit() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
    this.step3Form = this.fb.group({
      startDate: [null, Validators.compose([Validators.required])],
      endDate: [null, Validators.compose([Validators.required])],
      ddlAgents: [null]
    });

    // this.fieldAgentID = JSON.parse(this.storageService.getData('fieldAgentId'));
    // this.missionId = JSON.parse(
    //   this.storageService.getData('missionId&quartierId')
    // );
    this.fieldAgentID = this.data.fieldAgentId;
    this.missionId = this.data.missionId;
    this.configAgents = {
      displayKey: 'fullname',
      search: true,
      placeholder: this.translate.instant('Select agent'),
      multiple: false,
      notFoundText: this.translate.instant('No items found')
    };

    this.getRejectedPos();
    this.getUsedMissionDates(this.today);
  }

  getRejectedPos() {
    this.subscriptions.push(
      this.apiService.getPosRejectedCount(this.missionId).subscribe(result => {
        this.rejectedData = result.data;
        let startDate = new Date(this.rejectedData.missionStartDate);
        let endDate = new Date(this.rejectedData.missionEndDate);
        this.startDateObject = {
          day: startDate.getDate(),
          month: startDate.getMonth() + 1,
          year: startDate.getFullYear()
        };
        this.endDateObject = {
          day: endDate.getDate(),
          month: endDate.getMonth() + 1,
          year: endDate.getFullYear()
        };

        console.log('minDate', this.minDate);
        let campEndDT = UTILS.getDatePickerDateFormat(
          new Date(this.rejectedData.campaignEndDate)
        );
        if (campEndDT.year >= this.minDate.year) {
          if (campEndDT.month >= this.minDate.month) {
            if (campEndDT.day >= this.minDate.day) {
              this.campEndDate = UTILS.getDatePickerDateFormat(
                new Date(this.rejectedData.campaignEndDate)
              );
            }
          }
        }
        console.log('campEndDate', this.campEndDate);
        this.getOldDates();
      })
    );
  }

  getOldDates() {
    const startDate = new Date(UTILS.getDateFormat(this.startDateObject));
    const endDate = new Date(UTILS.getDateFormat(this.endDateObject));
    UTILS.getDatesArrayByDates(new Date(startDate), endDate).then(data => {
      this.oldMissionDates = data.dateArray;
    });
  }

  getEndDate(date: NgbDate, currentMonth) {
    const _date = new Date(UTILS.getDateFormat(date));
    const current = { month: currentMonth };
    const startDate = new Date(
      UTILS.getDateFormat(this.step3Form.value.startDate)
    );
    if (_date >= startDate) {
      if (!this.isDisabled2(date, current)) {
        this.step3Form.controls['endDate'].setValue(date);
        let startDate = UTILS.getDateFormat(
          this.step3Form.controls['startDate'].value
        );
        const endDate = new Date(UTILS.getDateFormat(date));
        UTILS.getDatesArrayByDates(new Date(startDate), endDate).then(data => {
          this.days = data.length;
          this.missionDates = data.dateArray;
        });
        this.getAllUnassignedUsersPos({
          startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
          endDate: UTILS.getDateFormatWithTime(endDate),
          iterations: null,
          shift: null,
          missionId: this.missionId
        });

        //console.log(this.step3Form.controls['ddlAgents'].value);
        this.step3Form.controls['ddlAgents'].setValue(null);
        //console.log(this.step3Form.controls['ddlAgents'].value);
      }
    }
  }

  // userAvailabilityStatus: string;
  // getEndDate(date: NgbDate, currentMonth) {
  //   const _date = new Date(UTILS.getDateFormat(date));
  //   const campaignStartDate = new Date(Globals.campaignStartDate);
  //   const campaignEndDate = new Date(Globals.campaignEndDate);
  //   const current = { month: currentMonth };
  //   if (campaignStartDate <= _date && campaignEndDate >= _date && !this.isDisabled(date, current)) {
  //     this.step3Form.controls['missionName'].setValue(this.missionName);
  //     let startDate = UTILS.getDateFormat(this.step3Form.controls['startDate'].value);
  //     const endDate = new Date(UTILS.getDateFormat(date));
  //     if (new Date(startDate) <= endDate) {
  //       UTILS.getDatesArrayByDates(new Date(startDate), endDate).then(data => {
  //         this.days = data.length; this.missionDates = data.dateArray;
  //       });
  //       if (this.assignments.userId) {
  //         this.subscriptions.push(this.checkPosUserAvailability({
  //           userId: this.assignments.userId,
  //           missionId: this.mission.missionId,
  //           startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
  //           endDate: UTILS.getDateFormatWithTime(endDate),
  //         }).subscribe(res => {
  //           this.userAvailabilityStatus = res;
  //           this.getAllUnassignedUsersPos({
  //             startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
  //             endDate: UTILS.getDateFormatWithTime(endDate),
  //             iterations: null, shift: null, missionId: this.mission.missionId
  //           });
  //         }));
  //       } else {
  //         this.getAllUnassignedUsersPos({
  //           startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
  //           endDate: UTILS.getDateFormatWithTime(endDate),
  //           iterations: null, shift: null, missionId: this.mission.missionId
  //         });
  //       }
  //     }
  //   }
  // }

  getFieldAgent($event) {
    this.selectedFieldAgent = $event;
    this.storageService.setData('fieldName', this.selectedFieldAgent.fullname);
  }

  getAllUnassignedUsersPos(reqBody) {
    this.subscriptions.push(
      this.apiService.getAllUnassignedUsersPos(reqBody).subscribe(
        res => {
          this.optionsAgents = [];
          this.optionsAgents = map(res.users, m =>
            UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` })
          );
        },
        err => {
          if (err.status === 400) {
            this.custAlerts.noAgentFound();
          }
        }
      )
    );
  }

  /* Datepicker related API's */
  getUsedMissionDates(date) {
    let currentDate = UTILS.getDatePickerDateFormat(date);
    this.subscriptions.push(
      this.apiService
        .getUsedMissionDates(
          UTILS.getDateFormatWithoutZero(currentDate),
          missionTypes.POS_POI_TYPE_ID
        )
        .subscribe(
          res => {
            Globals.BUSY_DATES = res.dateDto;
          },
          err => (Globals.BUSY_DATES = [])
        )
    );
  }

  /* Datepicker related methods */
  isDisabled(date: NgbDate, current: { month: number }) {
    const isDateFind = findWhere(
      Globals.BUSY_DATES,
      UTILS.getDatePickerIntFormat(date)
    );
    const currentDate = new Date(UTILS.getDateFormat(date));
    const day = currentDate.getDay();
    const isWeekend = day != 0 && day != 6;
    if (!isWeekend || !isUndefined(isDateFind)) return true;
    else return false;
  }

  isDisabled2(date: NgbDate, current: { month: number }) {
    const isDateFind = findWhere(
      Globals.BUSY_DATES,
      UTILS.getDatePickerIntFormat(date)
    );
    const currentDate = new Date(UTILS.getDateFormat(date));
    const day = currentDate.getDay();
    const isWeekend = day != 0 && day != 6;
    if (!isWeekend || !isUndefined(isDateFind)) return true;
    else return false;
  }

  reassign(form) {
    if (form.valid) {
      this._event.broadcast({ eventName: 'showLoader' });
      let userID = this.storageService.getData('userId');
      let status = this.storageService.getData('currentStatusId');
      //console.log("Current Mission Status :",status);
      const obj = {
        userId: parseInt(this.selectedFieldAgent.userId),
        oldUserId: this.data.fieldAgentId,
        missionId: this.missionId,
        campaignId: this.rejectedData.campaignId,
        status: 2,
        oldStatus: parseInt(status),
        createdBy: parseInt(userID),
        updatedBy: parseInt(userID),
        creationDate: null,
        lastUpdatedOn: null,
        supervisorId: parseInt(userID),
        missionDates: this.missionDates,
        oldMissionDates: this.oldMissionDates
      };
      /** Old Code.  Issue - 946
        const obj = {
        userId: parseInt(this.selectedFieldAgent.userId),
        oldUserId: this.data.fieldAgentId,
        missionId: this.missionId,
        campaignId: this.rejectedData.campaignId,
        status: parseInt(status),
        oldStatus: parseInt(status),
        createdBy: parseInt(userID),
        updatedBy: parseInt(userID),
        creationDate: null,
        lastUpdatedOn: null,
        supervisorId: parseInt(userID),
        missionDates: this.missionDates,
        oldMissionDates: this.oldMissionDates
      }
       */
      //console.log("Complete Object to Send via POST:: ",obj);

      this.subscriptions.push(
        this.apiService.reAssignPosMission(obj).subscribe(res => {
          if (res.responseCode === '200') {
            this.activeModal.dismiss('Reassigned');
            this.router.navigate(['/supervisor/missions']);
          }
        })
      );
    }
  }

  resetEnddate(date) {
    this.step3Form.controls['endDate'].setValue(null);
    this.optionsAgents = [];
    this.step3Form.controls['ddlAgents'].setValue(null);
  }

  ngOnDestroy() {
    this.storageService.removeData('fieldAgentId');
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }
}
