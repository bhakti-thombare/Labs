import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReassignPosComponent } from './reassign-pos.component';

describe('ReassignPosComponent', () => {
  let component: ReassignPosComponent;
  let fixture: ComponentFixture<ReassignPosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReassignPosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReassignPosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
