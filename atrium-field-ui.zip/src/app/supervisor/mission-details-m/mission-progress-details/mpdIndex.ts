export interface POSMpd {
    invalidPos: boolean;
    validatedPos: boolean;
    posNameNl: any;
    posNameEn: any;
    posNameFr: any; 
    id: number;
    posId: number;
    dateOfUpdate: string;
    startUpdateTime: string;
    endUpdateTime: string;
    address: string;
    posName: string;
    situation: string;
    latitude: string;
    longitude: string;
    validationFlag: string;
}
export interface POSCheckPoint {
    pkId?: null;
    id: number;
    x: string;
    y: string;
    pnNameFr: string;
    pnNameDu: string;
    pnNameEn?: null;
    muNatCod: number;
    muNameFr: string;
    muNameDu: string;
    muNameEn?: null;
    mdrc: number;
    nameFre1?: null;
    nod: string;
    nodNom: string;
    baroNom: string;
    checkpoint: number;
    insertedby: string;
    createdate: string;
    changedate: string;
    missionId: number;
    adptId: string;
    imageLink?: null;
    distance?: null;
    wgs84X?: null;
    wgs84Y?: null;
  }
  