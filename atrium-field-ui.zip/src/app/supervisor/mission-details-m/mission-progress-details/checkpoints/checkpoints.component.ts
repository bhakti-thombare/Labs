import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

import { Subscription } from 'rxjs/Subscription';
import * as moment from 'moment';

import { ApiService } from '@app/services/apiServices/api.service';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { StorageService } from '@app/services/storage-service.service';
import { POSCheckPoint } from '@app/supervisor/mission-details-m/mission-progress-details/mpdIndex';
import { CONSTANTSVALUES } from '@app/constants/constant-values';
import { EventService } from '@app/services/events/event.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ImagePopupComponent } from '@app/shared/image-popup/image-popup.component';
import { InfoSheetButtonComponent } from '@app/shared/info-sheet-button/info-sheet-button.component';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-checkpoints',
  templateUrl: './checkpoints.component.html',
  styleUrls: ['./checkpoints.component.css']
})
export class CheckpointsComponent implements OnInit {
  averageData: any = [];

  @Input() missionDuration: any = {};
  @Input() quartierId: any = {};
  @Input() missionId: any = {};

  @Output() back = new EventEmitter();

  private subscriptions: Subscription[] = [];
  private utilityFunctions = new UtilityFunctions();
  // checkPointIds: any;
  public rowData: POSCheckPoint[];
  public columnDefs: any[];
  public rowSelection;
  missionStatus: number;
  rowData1=[];
  constructor(
    private storageService: StorageService,
    private apiService: ApiService,
    public _event: EventService,
    private modalService: NgbModal,
    private translate: TranslateService
  ) {}

  ngOnInit() {
    this.missionStatus = parseInt(
      this.storageService.getData('currentStatusId')
    );
    // this.checkPointIds = JSON.parse(this.storageService.getData('missionId&quartierId'));
    this.getPosCheckpoints(
      this.missionId,
      this.quartierId,
      this.missionDuration
    );
  }

  getPosCheckpoints(missionId, quartierId, missionDuration) {
    this._event.broadcast({ eventName: 'showLoader', data: '' });
    this.subscriptions.push(
      this.apiService
        .getPosCheckpoints(missionId, quartierId, missionDuration)
        .subscribe(res => {
          if (res.responseMessage === 'Success') {
            this._event.broadcast({ eventName: 'hideLoader', data: '' });
            this.averageData = res.checkpointData;
            res.data.forEach(element => {
              if (element.showPosCheckpoint == 1) {
                this.rowData1.push(element);
                this.rowSelection = 'multiple';
                this.getColumnDef();
              }
              else {
                // this.rowData1 = null, 
                this.rowSelection = 'multiple';
                // this.columnDefs = null;
              }
            });
            this.rowData=this.rowData1;
          }
        })
    );
  }

  getColumnDef() {
    //moment(params.data.changedate).format(CONSTANTSVALUES.VALUES.LIST_TIME_FORMAT)
    this.columnDefs = [
      {
        headerName: this.translate.instant('Date'),
        field: 'changedate',
        width: 150,
        sortable: true,
        valueGetter: params =>
          params.data.changedate
            ? moment(params.data.changedate).format(
                CONSTANTSVALUES.VALUES.LIST_DATE_FORMAT
              )
            : 'NA'
      },
      {
        headerName: this.translate.instant('Time'),
        field: 'changedate',
        width: 150,
        valueGetter: params =>
          params.data.changedate ? params.data.changedate.split(' ')[1] : 'NA'
      },
      {
        headerName: this.translate.instant('Address'),
        field: 'address',
        width: 260
      },
      {
        headerName: this.translate.instant('Distance'),
        field: 'distance',
        width: 180,
        valueGetter: params =>
          params.data.distance ? params.data.distance : 'NA'
      },
      {
        headerName: this.translate.instant('Image link'),
        field: 'imageLink',
        width: 188,
        cellStyle: params =>
          params.data.imageLink
            ? { color: 'blue', 'text-decoration': 'underline' }
            : null,
        valueGetter: params =>
          params.data.imageLink ? this.translate.instant('Link') : 'NA'
      },
      {
        headerName: this.translate.instant('Check'),
        field: '',
        width: 180,
        cellRenderer: params => {
          if (params.data.isUpdated === null) {
            return '<input type="checkbox" disabled/>';
          } else if (params.data.isUpdated === 'YES') {
            if (params.data.validationFlag === 1) {
              if (this.missionStatus === 1)
                return '<input type="checkbox" id="checked" checked disabled/>';
              else return '<input type="checkbox" id="checked" checked/>';
            } else if (params.data.validationFlag === 0) {
              if (this.missionStatus === 1)
                return '<input type="checkbox" id="unchecked" disabled/>';
              else return '<input type="checkbox" id="unchecked"/>';
            }
          }
        }
      }
    ];
  }

  onCellClicked($event) {
    if ($event.colDef.headerName === this.translate.instant('Image link')) {
      if ($event.data.imageLink !== null) {
        //console.log($event.data.imageLink);

        const modalRef = this.modalService.open(ImagePopupComponent);
        modalRef.componentInstance.imgLink = $event.data.imageLink;
      }
    }

    //...Update CheckPoint Status...///
    if ($event.colDef.headerName === this.translate.instant('Check')) {
      //console.log($event);

      const reqObj = {
        id: $event.data.id,
        missionId: $event.data.missionId,
        status: null
      };

      if ($event.event.target.id == 'checked') {
        //console.log($event.event.target.id);
        this._event.broadcast({ eventName: 'showLoader' });
        reqObj.status = 0;
        this.subscriptions.push(
          this.apiService.updatePosCheckpointStatus(reqObj).subscribe(res => {
            $event.event.target.id = 'unchecked';
            this._event.broadcast({ eventName: 'hideLoader' });
          })
        );
      } else if ($event.event.target.id == 'unchecked') {
        //console.log($event.event.target.id);
        this._event.broadcast({ eventName: 'showLoader' });
        reqObj.status = 1;
        this.subscriptions.push(
          this.apiService.updatePosCheckpointStatus(reqObj).subscribe(res => {
            $event.event.target.id = 'checked';
            this._event.broadcast({ eventName: 'hideLoader' });
          })
        );
      }
    }
  }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }

  goBack() {
    this.back.emit('back');
  }
}
