import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PfReassignComponent } from './pf-reassign.component';

describe('PfReassignComponent', () => {
  let component: PfReassignComponent;
  let fixture: ComponentFixture<PfReassignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PfReassignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PfReassignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
