import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiConstants, Globals, missionTypes } from '@app/constants/constants';
import { CustomerSurveyAlertsService } from '@app/services/Alerts/customer-survey-alerts.service';
import { MissionListAlertsService } from '@app/services/Alerts/mission-list-alerts.service';
import { ApiService } from '@app/services/apiServices/api.service';
import { UTILS } from '@app/services/global-utility.service';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import * as mapboxCircle from 'mapbox-gl-circle';

import { EventService } from '@services/events/event.service';

import {
  each,
  map,
  isArray,
  filter,
  isEmpty,
  defaults,
  findWhere,
  isUndefined
} from 'underscore';
import { HttpService } from '@app/services/http-service';
@Component({
  selector: 'app-pf-reassign',
  templateUrl: './pf-reassign.component.html',
  styleUrls: ['./pf-reassign.component.css']
})
export class PfReassignComponent implements OnInit {
  xmlHttpUrl = ApiConstants.BASE_URL;
  map: mapboxCircle;
  myCircle1 = new mapboxCircle({ lat: 39.984, lng: -75.343 }, 150, {
    editable: false,
    maxRadius: 150,
    fillColor: 'purple'
  });
  private subscriptions: Subscription[] = [];
  today: Date = new Date();
  minDate: any;
  maxDate: any;
  lnglat= ['4.3517', '50.8503']
  checkpointMapGeoJSON=[
   { 'lnglat': [
    parseFloat(Number(50.87009279999999).toFixed(20)),
    parseFloat(Number(4.1783284).toFixed(20))
  ],
  'checkPointName':"mayuri",
  'isFalse':true
}
  ]
  circuitId: any;
  campaignEndDate: any;
  missionId;
  campaignFlag: boolean=false;
  enddayObj: { year: any; month: any; day: any; };
  dateSelected: boolean;
  startdayObj: { year: any; month: any; day: any; };
  startDate;
  checkpointName1=[];
  currentStartDate: any;
  currentEndDate: any;
  disableSubmit: boolean=false;
  constructor(private activatedRoute: ActivatedRoute,
    private apiService:ApiService,
    public event: EventService,
    public custAlerts: CustomerSurveyAlertsService,
    public router:Router,
    public _http: HttpService,
    public translate:TranslateService,
    public missionListAlertsService:MissionListAlertsService) { }
  missiondates;
  morning=true;
  agentSelected=false;
  step1Form:FormGroup;
  step2Form:FormGroup;
  step3Form:FormGroup;
  count: number=1;

  mission={
    userId:localStorage.getItem('userId'),
    classic:'',
    prm:'',
    visits:'',
    market:false,
    agent:{
     userId:''
    },
    checkpoints:[],
    missionCampaign:{
      campaignName:'',
      campaignId:''
    },
    missionMarketZoneList:[{
    shortName:'',
    latitude:'',
    longitude:'',
    id:''
    }],
    missionCircuits:[{
      circuitName:''
    }],
    missionId:'',
    missionStatus:{
      statusId:'',
      statusName:''
    },
    shift:{
      shiftId:''
    },
    // missionStartDate:'',
    missionType:{
      id:''
    },
    subType:1,
    numberOfPos:'',
    numberOfPosCheckpoints:'',
    supervisorId:'',
    missionEstimatedTime:'',
    missionStartDate : {
      year: null,
      month: null,
      day: null
    }
  }
  selectedMission: Array<any> = [];
  textControl = new FormControl();

submitMission(){
  console.log("mission values=",this.step1Form.value,localStorage.getItem('userId'));
  this.disableSubmit=true;
  const reqbody={
    circuitId:this.circuitId,
    newUserId:this.selectAgentId, //new assigned field agent
    oldUserId:this.mission.agent.userId, //previous agent id
    missionId:this.mission.missionId,
    campaignId:this.mission.missionCampaign.campaignId,
    currentStatus:this.mission.missionStatus.statusName,
    oldStatus:this.mission.missionStatus.statusId,
    createdBy:localStorage.getItem('userId'),
    updatedBy:localStorage.getItem('userId'),
    supervisorId:this.mission.supervisorId,
    shiftId:this.morning?1:2,
    oldShiftId:this.mission.shift.shiftId,
    newStartDate:`${this.startDate} 00:00:00`,
    newEndDate:`${this.startDate} 00:00:00`,
    currentStartDate:this.currentStartDate,
    // zoneId:this.mission.missionZones[0].id,
    locationTypeId:1,
    missionRequest:{
      missionTypeId:3,
      missionCreationDate:"",
      missionStartDate:`${this.startDate} 00:00:00`,
      missionEndDate:`${this.startDate} 00:00:00`,
      classic:this.mission.classic,
      visits:this.mission.visits,
      market:this.mission.market,
      prm:this.mission.prm,
      marketZone: this.mission.missionMarketZoneList !== null? this.mission.missionMarketZoneList[0].id:null,
      missionName:this.step1Form.value.missionName,
      missionDescription:this.step1Form.value.missionDescription,
      missionCampaignId:this.mission.missionCampaign.campaignId,
      missionCreatedById:localStorage.getItem('userId'),
      missionUpdatedById:localStorage.getItem('userId'),
      missionStatusId:10,
      missionEstimatedTime:610
    }
  }
  this.apiService.postCSReassignDetails(reqbody,this.missionId).subscribe((res)=>{
    console.log("success",res);
    if(res.responseCode==200){
      this.missionListAlertsService.reassignMission().then(() => {
        this.router.navigate(['/supervisor/missions'])

      });;

    }
    
  })

}



  getMission(id) {
    this.subscriptions.push(
      this.apiService.getAllMissions({ id: id }).subscribe(
        res => {
          console.log("getmission=",res.data.mission);
          
          this.selectedMission = [...res.data.missions];
          console.log('selected mission=',this.selectedMission);

          Globals.campaignStartDate =
            res.data.missions[0].missionCampaign.campaignStartDate;
          Globals.campaignEndDate =
            res.data.missions[0].missionCampaign.campaignEndDate;
          this.setMinMaxDate();
        },
        err => {
          console.log(err);
        }
      )
    );
  }
  setMinMaxDate() {
    const minDate_ = new Date(UTILS.getDateTimeFormat(UTILS.minDate));
    const campaignStartDate = new Date(Globals.campaignStartDate);
    if (minDate_ < campaignStartDate)
      this.minDate = UTILS.getDatePickerDateFormat(Globals.campaignStartDate);
    else this.minDate = UTILS.minDate;

    this.maxDate = UTILS.getDatePickerDateFormat(Globals.campaignEndDate);
    //console.log("minDate",this.minDate);
    //console.log("maxDate",this.maxDate);
  }

  ngAfterViewInit() {

    // $('app-pf-reassign').on('click', (e) => {
    //   setTimeout(() => {
    //     if (this.existingCircuitsCheck) {
    //       // console.log(e);
    //       // console.log($('#dontHideDD'));
    //       if (e.target.className === 'nav-link mission-dd open-dd' || e.target.id === 'openDD') {
    //         if (!e.target.parentNode.className.includes('show')) {
    //           this.parent2Toggle = this.circuitsDropdown.nativeElement;
    //           this.classAdder();
    //         } else if (e.target.parentNode.className.includes('show')) {
    //           this.parent2Toggle = this.circuitsDropdown.nativeElement;
    //           this.classRemover();
    //         }
    //       } else if (e.target.id === 'searchCircuitName' || e.target.id === 'dontHideDD1' || e.target.id === 'dontHideDD2' || e.target.id === 'dontHideDD3' || e.target.id === 'dontHideDD4') {

    //       } else {
    //         this.parent2Toggle = this.circuitsDropdown.nativeElement;
    //         this.classRemover();
    //       }
    //     }
    //   }, 100);
    // });

    // this.event.currentMessage.subscribe(message => {
    //   if (message && message.eventName !== 'default') {
    //     if (message.eventName === 'existing-circuit-dd-clicked') {
    //       setTimeout(() => {
    //         this.parent2Toggle = this.circuitsDropdown.nativeElement;
    //         this.rd.listen(this.circuitsDropdown.nativeElement, 'click', () => {
    //           if (this.parent2Toggle.parentNode.classList[1] === 'show') {
    //             this.classRemover();
    //           } else {
    //             this.classAdder();
    //           }
    //         });
    //       }, 500);
    //     }
    //   }
    // });

    this.event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'newAssignment') {
          $('.ng2-tag-input__text-input').css('display', 'none');
          $('.ng2-tag-input').css('border-bottom', '0');

          $('.click2Scroll').click(function () {
            $('.wrap-textarea').scrollTop($('.wrap-textarea')[0].scrollHeight);
          });
        } else if (message.eventName === 'existing-circuit-dropdown-clicked') {
          // document.getElementById('searchCircuitName').focus();
          $('#searchCircuitName').focus();
        }
      }
    });

    this.event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'mapLoaded') {
          $('.mapboxgl-canvas').css('width', '100%');
          $('.mapboxgl-canvas').css('height', '100%');
        }
      }
    });

  }


  getUsedMissionDates(date) {
    let currentDate = UTILS.getDatePickerDateFormat(date);
    this.subscriptions.push(
      this.apiService
        .getUsedMissionDates(
          UTILS.getDateFormatWithoutZero(currentDate),
          missionTypes.PEDESTRIAN_FLOW_SURVEY_TYPE_ID
        )
        .subscribe(
          res => {
            Globals.BUSY_DATES = res.dateDto;
          },
          err => (Globals.BUSY_DATES = [])
        )
    );
  }

  isDisabled(date: NgbDate, current: { month: number }) {
    const d = new Date(date.year, date.month - 1, date.day);
    if (localStorage.getItem('campaignFlag') === 'false') {

      return false
    } else {

      const now = new Date(Date.now());
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));

      const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
      const busyDates = JSON.parse(localStorage.getItem('busyDates'));
      const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
      const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
      const sdate = new Date(date.year, date.month - 1, date.day);

      if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
        if (busyDates !== null) {
          let found = -1;
          const dateFinder = (dateObj) => {
            const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));



            if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
              inDate.getDate() === sdate.getDate()) {
              return true;
            } else {
              return false;
            }
          };

          found = busyDates.findIndex(dateFinder);

          let available = !busyDates.findIndex(dateFinder)

          if (found !== -1) {
            return true

          } else {
            let market = JSON.parse(localStorage.getItem('missionStartDate'));
            market = JSON.parse(localStorage.getItem("missionStartDate"))
            
            if (d.getDay() === market.getDay()) {

              return true;

            }


          }
        } else {
          console.log("not busy=available");
          var market =(localStorage.getItem('missionStartDate'));
          market = (localStorage.getItem("missionStartDate"))
          
          console.log(market);
          var res=market.split('-');
          let year=parseInt(res[0]);
          let month= parseInt(res[1]);
          let date34=parseInt(res[2]);
          
          const d1 = month==0?new Date(year,11,date34):new Date(year,month-1,date34);
          var arr = [1, 2, 3, 4, 5, 6, 0];
          arr.forEach(i => {
            if ( arr[i] === d1.getDay()) { 
              arr.splice(i, 1); 
            }
          });
          
          if (d.getDay() === arr[0] || d.getDay() === arr[1] || d.getDay() === arr[2] || d.getDay() === arr[3] ||
          d.getDay() === arr[4] || d.getDay() === arr[5] || d.getDay() === arr[6] || d.getDay() === arr[7]) {
           
            return true;

          } else {
            return false;
          }

        }
      } else {
        return true;
      }
    }
  }

  convert(str) {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  step1details(){
    this.step1Form.setValue({
      'step1':{
        'camapaignName':this.mission.missionCampaign.campaignName,
        'missionType':'PF',
        'missionName':'',
        'classic':this.mission.classic,
        'market':this.mission.market,
        'missionDescription':'',
        'missionMarketName':this.mission.missionMarketZoneList!==null?  this.mission.missionMarketZoneList[0].shortName:''
      },
    
    })
  }

  step2details(){
  
    this.step2Form.setValue({
      'step2':{
        'missionName':"hi",
        'circuitName':this.mission.missionCircuits[0].circuitName,
        
      },
    
    })
  }

  step3details(){
  
    // this.step3Form.setValue({
    //   'step3':{
    //     // 'quartierName':this.mission.quartierDto.name,
    //       'POS':this.mission.numberOfPos,
    //       'checkpoints':this.mission.numberOfPosCheckpoints,
    //       'subType':this.mission.subType==5?this.translate.instant('Points of sale only'):this.translate.instant('Points of sale & Checkpoints')
        
    //   },
    
    // })
  }
 
  getDate(d1) {
    var g1 = new Date();
    let endDateCheck = JSON.parse(localStorage.getItem('campaignEndDate'));

    endDateCheck = new Date(`${endDateCheck.year}-${endDateCheck.month}-${endDateCheck.day}`)
    let startDateCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    startDateCheck = new Date(`${startDateCheck.year}-${startDateCheck.month}-${startDateCheck.day}`)

    // (YYYY-MM-DD) 
    var d = new Date();
    let dateToday = {
      month: '' + (d.getMonth() + 1),
      day: '' + d.getDate(),
      year: d.getFullYear()
    }

    if (dateToday.month.length < 2)
      dateToday.month = '0' + dateToday.month;
    if (dateToday.day.length < 2)
      dateToday.day = '0' + dateToday.day;
    var today = `${dateToday.year}-${dateToday.month}-${dateToday.day}`
    // var g2 = new Date(`${d1.year}-${d1.month}-${d1.day}`); 
    // console.log("d1.day=", d1.day, g1.getMonth(), this.minDate, this.minDate.day === d1.day);
    var GivenDate = new Date(`${d1.year}-${d1.month}-${d1.day}`);
    const month1 = String(d1.month).padStart(2, "0");
    const day1 = String(d1.day).padStart(2, "0");
    var todayDate = `${d1.year}-${month1}-${day1}`
    const now = new Date(Date.now());
    const CurrentDate = new Date(now.getFullYear(), now.getMonth(), now.getDate()); 
    if(new Date(this.campaignEndDate.substr(0,10))< CurrentDate){
      this.campaignFlag=false;
      localStorage.setItem('campaignFlag', 'false');
    } else {
      this.campaignFlag=true
      localStorage.setItem('campaignFlag', 'true');
      this.startdayObj={
        year:startDateCheck.getFullYear(),
        month:startDateCheck.getMonth()+1,
        day:startDateCheck.getDate()
        }
      localStorage.setItem('campaignStartDate', JSON.stringify(this.startdayObj));
    //  endDateCheck.split('-');
      this.enddayObj={
        year:endDateCheck.getFullYear(),
        month:endDateCheck.getMonth()+1,
        day:endDateCheck.getDate()
        }
      localStorage.setItem('campaignEndDate', JSON.stringify(this.enddayObj));
    }

    if (this.campaignFlag) {
      if ((!(GivenDate > endDateCheck) && !(GivenDate < startDateCheck)) || (GivenDate.getDate() == startDateCheck.getDate())) {
        if (GivenDate >= CurrentDate || (today === todayDate)) {


          // if (d1.day >= this.minDate.day ) {
          // this.dateSelected=true;
          this.dateSelected = true;
          this.mission.missionStartDate = {
            year: d1.year,
            month: d1.month,
            day: d1.day
          }
          console.log("mision startdate=", this.mission.missionStartDate);

          localStorage.setItem('date', JSON.stringify(d1));


          this.startDate = `${d1.year}-${d1.month}-${d1.day}`
          const endDate = '2020-10-12 ' + '23:59:00'
          const startDate = '2020-10-12 ' + '00:00:00'
          this._http.SecureGet('/ref/getDatesInRange?startDate=' + startDate + '&endDate=' + endDate).subscribe(res => {
            console.log("res field agents=", res);

          }, err => {
          });
          this.getAllUnassignedUsersPos({
            // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
            // endDate: UTILS.getDateFormatWithTime(endDate),
            startDate:`${d1.year}-${d1.month}-${d1.day}`,
            endDate:`${d1.year}-${d1.month}-${d1.day}`,
            iterations: 9,
            shift: this.morning?1:2,
            missionId: this.missionId
          });
        }
      }
    } else {
      if (GivenDate >= CurrentDate || (today === todayDate)) {


        // if (d1.day >= this.minDate.day ) {
        // this.dateSelected=true;
        this.dateSelected = true;
        this.mission.missionStartDate = {
          year: d1.year,
          month: d1.month,
          day: d1.day
        }
        console.log("mision startdate=", this.mission.missionStartDate);

        localStorage.setItem('date', JSON.stringify(d1));

        console.log("date selected...!!!");
        this.startDate = `${d1.year}-${d1.month}-${d1.day}`
        const endDate = '2020-10-12 ' + '23:59:00'
        const startDate = '2020-10-12 ' + '00:00:00'
        this._http.SecureGet('/ref/getDatesInRange?startDate=' + startDate + '&endDate=' + endDate).subscribe(res => {
          console.log("res field agents=", res);

        }, err => {
        });
        this.getAllUnassignedUsersPos({
          // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
          // endDate: UTILS.getDateFormatWithTime(endDate),
          startDate:`${d1.year}-${d1.month}-${d1.day}`,
            endDate:`${d1.year}-${d1.month}-${d1.day}`,
            iterations: 9,
            shift: this.morning?1:2,
            missionId: this.missionId
        });
      }
    }
  }


  selectedAgent;
  selectAgentId;
  toggleFieldAgent(user){
    this.agentSelected=true;
    this.selectedAgent=`${user.firstName} ${user.lastName}`
    this.selectAgentId=user.userId
  }
  optionsAgents=[]
  getAllUnassignedUsersPos(reqBody) {
    this.subscriptions.push(
      this.apiService.getAllUnassignedUsersPos(reqBody).subscribe(
        res => {
          this.optionsAgents = [];
          this.optionsAgents = map(res.users, m =>
            UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` })
          );
          console.log("res===",this.optionsAgents);
                 },
        err => {
          if (err.status === 400) {
            this.custAlerts.noAgentFound();
          }
        }
      )
    );
  }

  changeShiftId(id) {
    console.log("id=",id);
    
    if (id === 1) {
      this.morning = true;
    } else {
      this.morning = false;
    }
  }
 
  assignments;
  assignments2;
  checkpoints=[]
  getMissionDetails(id) {
    this.apiService.getReassignCSMissionDetails(id).subscribe(result => {
      console.log("result=", result);
      this.mission = result.data;
      result.data.shift?result.data.shift.shiftName=='PM'?this.morning=false:this.morning=true:this.morning=true;
      this.currentStartDate=result.data.missionStartDate;
      this.currentEndDate=result.data.missionEndDate;
      localStorage.setItem('missionStartDate', result.data.missionStartDate.substr(0,10));
      localStorage.setItem('missionEndDate', result.data.missionEndDate);
      this.campaignEndDate = result.data.missionCampaign.campaignEndDate;
      let startdate = result.data.missionCampaign.campaignStartDate;
      this.startdayObj = {
        year: startdate[0],
        month: startdate[1],
        day: startdate[2]
      }

      let endDateMission =this.campaignEndDate[0].split('-');  
      this.enddayObj={
      year:endDateMission[0],
      month:endDateMission[1],
      day:endDateMission[2]
      }

      this.circuitId=result.data.missionCircuits[0].circuitId;
      // this.lnglat=[result.data.missionCircuits[0].circuitLongitude,result.data.missionCircuits[0].circuitLatitude];
      this.checkpointMapGeoJSON=[];
      result.data.missionCircuits[0].circuitCheckpoints.sort(function(a, b) {
        return a.position - b.position;
      });
      result.data.missionCircuits[0].circuitCheckpoints.forEach(element => {
      this.populateExistingCheckpoints(element);
      console.log(this.mission.checkpoints);
        this.checkpointMapGeoJSON.push({ 'lnglat': [
          parseFloat(Number(element.checkpointLongitude).toFixed(20)),
          parseFloat(Number(element.checkpointLatitude).toFixed(20))
        ],
        'checkPointName':element.checkpointName,
        'isFalse':true}); 
        
      this.checkpointName1.push(element.checkpointName);
      });  
      if(this.mission.market == true){
      this.checkpointMapGeoJSON.push({ 'lnglat': [
        parseFloat(Number(result.data.missionMarketZoneList[0].longitude).toFixed(20)),
        parseFloat(Number(result.data.missionMarketZoneList[0].latitude).toFixed(20))
      ],
      'checkPointName':result.data.missionMarketZoneList[0].shortName,
      'isFalse':false});     
    }
      this.step1details();
      this.step2details();
    });
  }

  populateExistingCheckpoints(checkpoint) {
    this.mission.checkpoints = [];
    this._http.pullAdptIdDetails(checkpoint.adptId).subscribe(res => {
      this.count += 1;
      const response = res.data['Geographic Data'][0];
      const mapObj = {
        selected_adrn: response.adt_adrn,
        selected_street: response.adt_street,
        selected_postalcode: response.adt_postal_code,
        selected_commune: response.com_commune_name_fr,
        selected_region: response.reg_region_name_fr,
        selected_country: response.con_country_name_fr,
        id: checkpoint.checkpointId,
        position: this.count,
        data: {
          checkpointName: checkpoint.checkpointName,
          description: checkpoint.checkpointDescription,
          adptid: checkpoint.adptId,
          quartier: response.qub_quartier_name_fr,
          lnglat: [response.adt_longitude_wgs84,
          response.adt_latitude_wgs84]
        }
      };
      i += 1;
      setTimeout(() => {
      this.mission.checkpoints.push(mapObj);
      } ,200);
    }, err => {
      console.log('err', err);
    });
    let i = 0;
    // const existingCheckpointPopulator = (checkpoint) => {
    //   this._http.pullAdptIdDetails(checkpoint.adptId).subscribe(res => {
    //     this.count += 1;
    //     const response = res.data['Geographic Data'][0];
    //     const mapObj = {
    //       // selectedMission: this.mission.circuits[0].selectedMission,
    //       // selectedCircuit: this.mission.circuits[0].selectedExistingCircuit,
    //       selected_adrn: response.adt_adrn,
    //       selected_street: response.adt_street,
    //       selected_postalcode: response.adt_postal_code,
    //       selected_commune: response.com_commune_name_fr,
    //       selected_region: response.reg_region_name_fr,
    //       selected_country: response.con_country_name_fr,
    //       id: checkpoint.checkpointId,
    //       position: this.count,
    //       data: {
    //         checkpointName: checkpoint.checkpointName,
    //         description: checkpoint.checkpointDescription,
    //         adptid: checkpoint.adptId,
    //         quartier: response.qub_quartier_name_fr,
    //         lnglat: [response.adt_longitude_wgs84,
    //         response.adt_latitude_wgs84]
    //       }
    //     };
    //     i += 1;
    //     // console.log('2366',response);

    //     // this.existingCircuitsCheck = true;
    //     this.mission.checkpoints.push(mapObj);
       
    //   }, err => {
    //     console.log('err', err);
    //   });
    // };


    // let checklen = this.mission.missionCircuits[0].circuitCheckpoints.length;
    // this.mission.missionCircuits[0].circuitCheckpoints.forEach(checkpoint => {
    //   checkpoints.push(checkpoint);
    //   checklen--;
    //   if (checklen === 0) {
    //     updateCheckpointObjectCreator(0);
    //   }
    // });
  }


  nameExists=false;
  name=false;
  textControl1 = new FormControl();

  checkMissionName(){
    this.textControl.valueChanges.pipe(
      ).subscribe((res)=>{
        //  res=(res.toString()).trim();
        res=$.trim(res);
      this.step1Form.value.missionName=res;
      if(res!==''){
        this.apiService.getMissionName(res).subscribe((res)=>{
            this.name=true;
          this.nameExists=false;
      },(error)=>{
          this.nameExists=true;
          this.name=false;  
      })
      } else {
        this.name=false
      } 
      });
  }
  description=false;
  ngOnInit() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
    this.checkMissionName()
    this.textControl1.valueChanges.pipe(
    ).subscribe((res) => {
      // res=res.trim();
      res = $.trim(res);
      this.step1Form.value.missionDescription = res
      if (res !== '') {
        this.description = true
      } else {
        this.description = false
      }
      console.log("this.description=", this.description);

      if (this.name && this.description) {
        //  this.buttonEnabled=true;
      } else {
        //  this.buttonEnabled=false;
      }
    });
    this.step1Form = new FormGroup({
      'step1': new FormGroup({
        'camapaignName': new FormControl(null),
        'missionType': new FormControl(null),
        'missionName': new FormControl(null),
        'classic': new FormControl(null),
        'market': new FormControl(null),
        'missionDescription': new FormControl(null),
        'missionMarketName': new FormControl(null)
      }),
    });
    this.step2Form = new FormGroup({
      'step2': new FormGroup({
        'missionName': new FormControl(null),
        'circuitName': new FormControl(null),

      }),
    });
    // this.step3Form = new FormGroup({
    //   'step3': new FormGroup({
    //       'quartierName':new FormControl(null),
    //       'POS':new FormControl(null),
    //       'checkpoints':new FormControl(null),
    //       'subType':new FormControl(null)


    //   }),
    // });
    this.missionId = this.activatedRoute.snapshot.paramMap.get('id')
    this.getMission(this.missionId);

    this.getMissionDetails(this.missionId)
    this.getUsedMissionDates(this.today);



  }



}
