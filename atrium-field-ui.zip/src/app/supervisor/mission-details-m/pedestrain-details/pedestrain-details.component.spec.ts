import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PedestrainDetailsComponent } from './pedestrain-details.component';

describe('PedestrainDetailsComponent', () => {
  let component: PedestrainDetailsComponent;
  let fixture: ComponentFixture<PedestrainDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PedestrainDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PedestrainDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
