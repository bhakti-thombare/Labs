// core
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxMapboxGLModule } from 'ngx-mapbox-gl';


// 3rd party
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { TranslateModule } from '@ngx-translate/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AgGridModule } from 'ag-grid-angular';

// app
import { PipesModule } from '@pipes/pipes.module';
import { SurveysModalComponent } from '@app/supervisor/mission-details-m/mdp-modals/surveys-modal/surveys-modal.component';
import { CustomerSurveyDetailsComponent } from '@app/supervisor/mission-details-m/customer-survey-details/customer-survey-details.component';
import { CommentsModalsComponent } from '@app/supervisor/mission-details-m/mdp-modals/comments-modals/comments-modals.component';
import { ReassignModalsComponent } from '@app/supervisor/mission-details-m/mdp-modals/reassign-modals/reassign-modals.component';
import { PedestrainDetailsComponent } from '@app/supervisor/mission-details-m/pedestrain-details/pedestrain-details.component';
import { MissionProgressDetailsComponent } from './mission-progress-details/mission-progress-details.component';
import { CreateSurveyModule } from '../create-survey/create-survey.module';
import { ReassignComponent } from './mission-progress-details/reassign/reassign.component';
import { CheckpointsComponent } from './mission-progress-details/checkpoints/checkpoints.component';
import { StorageService } from '@app/services/storage-service.service';
import { InfoSheetComponent } from './mission-progress-details/info-sheet/info-sheet.component';
import { SharedModule } from '@app/shared';
import { DatePickerPopupComponent } from '@app/shared/date-picker-popup/date-picker-popup.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { InfoSheetButtonComponent } from '@app/shared/info-sheet-button/info-sheet-button.component';
import { LocateMapComponent } from '@app/shared/locate-map/locate-map.component';
import { ImagePopupComponent } from '@app/shared/image-popup/image-popup.component';
import { ValidateFlagComponent } from '@app/shared/validate-flag/validate-flag.component';
import { CsReassignComponent } from './customer-survey-details/cs-reassign/cs-reassign.component';
import { PfReassignComponent } from './pedestrain-details/pf-reassign/pf-reassign.component';
// import {CircleMapComponent} from '@app/supervisor/create-survey/createSurveyUtils/circle-map/circle-map.component'
import { CONFIG } from '@app/config';
import { TagInputModule } from 'ngx-chips';
import {PosMpdPhotosComponent} from '@app/shared/pos-mpd-photos/pos-mpd-photos.component'


@NgModule({
  imports: [
    CommonModule,
    PipesModule,
    TranslateModule,
    NgbModule,
    FormsModule,
    SelectDropDownModule,
    CreateSurveyModule,
    SharedModule,
    ReactiveFormsModule,
    NgSelectModule,
    TagInputModule,
    NgxMapboxGLModule.forRoot({
      accessToken: CONFIG.mapBoxAccessToken
  }),
  AgGridModule.withComponents([MissionProgressDetailsComponent]),
    AgGridModule.withComponents([InfoSheetButtonComponent, LocateMapComponent, ValidateFlagComponent,PosMpdPhotosComponent]),
  ],
  declarations: [ImagePopupComponent, PedestrainDetailsComponent, DatePickerPopupComponent, CustomerSurveyDetailsComponent, SurveysModalComponent, CommentsModalsComponent, ReassignModalsComponent, MissionProgressDetailsComponent, ReassignComponent, CheckpointsComponent, InfoSheetComponent, InfoSheetButtonComponent, LocateMapComponent, ValidateFlagComponent, CsReassignComponent, PfReassignComponent,PosMpdPhotosComponent],
  exports: [PedestrainDetailsComponent, CustomerSurveyDetailsComponent, MissionProgressDetailsComponent],
  entryComponents: [CommentsModalsComponent, SurveysModalComponent, ReassignModalsComponent, ReassignComponent, ImagePopupComponent],
  providers: [StorageService]
})
export class MissionDetailsMModule { }
