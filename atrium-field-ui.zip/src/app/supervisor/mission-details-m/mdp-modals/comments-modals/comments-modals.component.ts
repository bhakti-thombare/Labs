// core
import { Component, OnInit, OnDestroy } from '@angular/core';

// 3rd party
import { Subscription } from 'rxjs/Subscription';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

// app
import { CustomerSurveyAlertsService } from '@services/Alerts/customer-survey-alerts.service';
import { ApiService } from '@services/apiServices/api.service';
import { EventService } from '@services/events/event.service';
import { UtilityFunctions } from '@app/shared/utility-functions';

@Component({
  selector: 'app-comments-modals',
  templateUrl: './comments-modals.component.html',
  styleUrls: ['./comments-modals.component.css']
})
export class CommentsModalsComponent implements OnInit, OnDestroy {
  private utilityFunctions = new UtilityFunctions();  
  private subscriptions: Subscription[] = [];
  constructor(
    public modalService: NgbModal,
    public customerSurveyAlerts: CustomerSurveyAlertsService,
    public apiService: ApiService,
    public eventService: EventService,
    public activeModal: NgbActiveModal) { }
  commentData: any;
  details: any;
  ngOnInit() {

  }

  c(data) { this.activeModal.close(data); }

  updateUserSurvey(comment) {
    this.eventService.showLoader({});
    this.subscriptions.push(this.apiService.updateUserSurvey('', { 'userSurveyId': this.commentData.id, 'comment': comment })
      .subscribe(res => {
        if (res.responseCode == "200") { this.c(null); }
      }, err => {
        this.eventService.hideLoader({});
        this.customerSurveyAlerts.somethingWentWrongAlert().then(result => {
          this.eventService.broadcast({ eventName: 'showLoader', data: {} });
          this.c('crossClocked');
        });
      }));
  }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
 }
 

}
