import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommentsModalsComponent } from './comments-modals.component';

describe('CommentsModalsComponent', () => {
  let component: CommentsModalsComponent;
  let fixture: ComponentFixture<CommentsModalsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommentsModalsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommentsModalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
