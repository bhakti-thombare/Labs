// core
import { Component, OnInit, Input, Output , EventEmitter} from "@angular/core";
import { AfterViewInit } from '@angular/core/src/metadata/lifecycle_hooks';

// 3rd party
import { contains, without, values, sortBy } from "underscore";
import { NgbModal, NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";

// app
import { EventService } from '@services/events/event.service';
import { MissionProgressDetails } from "@app/constants/constants";
import { CustomerSurveyAlertsService } from "@services/Alerts/customer-survey-alerts.service";
import { ApiService } from "@services/apiServices/api.service";
@Component({
  selector: "app-surveys-modal",
  templateUrl: "./surveys-modal.component.html",
  styleUrls: ["./surveys-modal.component.css"]
})
export class SurveysModalComponent implements OnInit, AfterViewInit {
  @Input() questionAnsList: any;
  @Input() marketZone:any;
  @Output() closeSheet = new EventEmitter();
  constructor(
    public customerSurveyAlert: CustomerSurveyAlertsService,
    public apiSAervice: ApiService,
    // public activeModal: NgbActiveModal
  ) { }
  marketques1=[]
  marketques2=[]
  classicques1=[]
  classicques2=[]
  tagsMapping=[]
  ngOnInit() {
console.log("marketZone=",this.marketZone);
   this.tagsMapping=[
     {id:1,value:"Organic"},
     {id:2,value:"Vegan"},
     {id:3,value:"Fair trade"},
     {id:4,value:"Circular economy"},
     {id:5,value:"Artisan"}

   ]
    if(this.marketZone !== null){
      this.questionAnsList.marketQuestionList.forEach((element,index) => {
        if(element.questionNumber < 9){
          this.marketques1.push(element)
        } else {
          this.marketques2.push(element)
        }
      });
    }
   if(this.marketZone === null){
    this.questionAnsList.questionList.forEach((element,index) => {
      if(element.questionNumber < 9){
        this.classicques1.push(element)
      } else {
        this.classicques2.push(element)
      }
    });
   }
    console.log(this.classicques1,this.classicques2);
    
    console.log("this.marketques=",this.marketques1,this.marketques2);
    
   }

  ngAfterViewInit() { }

  closeSurveySheet() {
     this.closeSheet.emit("false")
  }
  typeOf(value) {
    return typeof value;
  }
  updateUserSurvey(status) {
  
    this.apiSAervice
      .updateUserSurvey("", { userSurveyId: this.questionAnsList.id, status: status }).subscribe(res => {
        // this.eventService.hideLoader({});
        this.closeSheet.emit("true")
      },
        err => {
          this.customerSurveyAlert.somethingWentWrongAlert();
        });
  }

  isMCQuestion(id) { return contains(MissionProgressDetails.MCQINDEX, id); }

  getAnswers(ans) {
    if(ans.option=='Yes'){
      ans.option='No lacking stand type';
      ans.optionId=null;
    }
    return without(values(ans), null);
  }

  getReversed(list: Array<any>) { return list.reverse(); }
  getSortedList(list: any) { return sortBy(list, 'optionId'); }
}
