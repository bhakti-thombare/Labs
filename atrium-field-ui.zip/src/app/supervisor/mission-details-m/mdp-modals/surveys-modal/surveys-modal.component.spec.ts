import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SurveysModalComponent } from './surveys-modal.component';

describe('SurveysModalComponent', () => {
  let component: SurveysModalComponent;
  let fixture: ComponentFixture<SurveysModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurveysModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurveysModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
