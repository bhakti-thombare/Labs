// core
import { Component, OnInit, OnDestroy } from '@angular/core';

// 3rd party
import {findWhere, map }from "underscore";
import { Subscription } from 'rxjs/Subscription';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

// app
import { Globals, missionTypes } from '@app/constants/constants';
import { ApiService } from '@services/apiServices/api.service';
import { CustomerSurveyAlertsService } from '@services/Alerts/customer-survey-alerts.service';
import { UTILS } from '@services/global-utility.service';
import { UtilityFunctions } from '@app/shared/utility-functions';
@Component({
  selector: 'app-reassign-modals',
  templateUrl: './reassign-modals.component.html',
  styleUrls: ['./reassign-modals.component.css']
})
export class ReassignModalsComponent implements OnInit, OnDestroy {
  private utilityFunctions = new UtilityFunctions();  
  private subscriptions: Subscription[] = []; 
  selectedAssignee: any = [];
  campaignEndDate: any;
  selectedDate: any;
  userData: any = JSON.parse(localStorage.getItem('user-data'));
  minDate: any;
  optionsUnassigned: Array<any> = [];
  maxDate: any;
  assignUserConfig = { displayKey: "fullname", search: true, placeholder: "Select field agent", multiple: false };
  missionId: any;
  details: any;
  constructor(
    public modalService: NgbModal,
    public activeModal: NgbActiveModal,
    public apiService: ApiService,
    public customerSurveyAlerts: CustomerSurveyAlertsService
  ) { }

  ngOnInit() {
    // this.minDate = UTILS.minDateReassign();//logic changed 
    this.minDate = UTILS.minDate;
    this.maxDate = UTILS.getDatePickerDateFormat(this.campaignEndDate);
    this.getUsedMissionDates(this.minDate);
  }
  closeModal(reason) {
    this.activeModal.close(reason);
  }

  getUnassignedUsers(date) {
    this.selectedDate = date;
    let obj = { missionId: this.missionId, startDate: UTILS.getDateFormat(date) };
    this.subscriptions.push(this.apiService.getUnassignedUsers(obj).subscribe(res => {
      this.optionsUnassigned = map(res.users, (m) => UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` }));
    }, err => {
      (!err.users) ? this.optionsUnassigned = [] : this.optionsUnassigned = map(err.users, (m) => UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` }));
    }));
  }

  getUsedMissionDates(date) {
    this.subscriptions.push(this.apiService.getUsedMissionDates(UTILS.getDateFormat(date), missionTypes.CUSTOMER_SURVEY_TYPE_ID)
      .subscribe(res => {
        Globals.BUSY_DATES = res.dateDto;
      }, err => Globals.BUSY_DATES = []));
  }

  isDisabled(date: NgbDate, current: { month: number }) { return (findWhere(Globals.BUSY_DATES, UTILS.getDatePickerIntFormat(date))) ? true : false; }

  disableReassignBtn: boolean = false;
  reAssignMission() {
    if (this.selectedAssignee.length > 0 && this.selectedDate) {
      this.disableReassignBtn = true;
      let reqBody = this.reAssignReqObj();
      this.subscriptions.push(this.apiService.reAssignMission('', reqBody)
        .subscribe(res => {
          if (res.responseCode == "200") { this.closeModal(null); }
        }, err => {
          this.customerSurveyAlerts.somethingWentWrongAlert().then(rs => this.closeModal(null));
        }));
    }
  }

  reAssignReqObj() {
    return {
      "missionId": this.missionId,
      "oldUserId": this.details.userDto.userId,
      "newUserId": this.selectedAssignee[0].userId,
      "shiftId": this.details.shift,
      "iterations": null,
      "currentStartDate": this.details.date,
      "newStartDate": (`${UTILS.getDateFormatWithoutZero(this.selectedDate)} ${(this.details.shift == 1) ? '08:45:00' : (this.details.shift == 2) ? '13:00:00' : '00:00:00'}`),
      "newEndDate": (`${UTILS.getDateFormatWithoutZero(this.selectedDate)} ${(this.details.shift == 1) ? '13:00:00' : (this.details.shift == 2) ? '17:15:00' : '00:00:00'}`),
      "supervisorId": this.userData.userId,
      "currentStatus": this.details.status
    };
  }
  selectionChanged($event) {
    if ($event.value.length != 0) {
      this.selectedAssignee = $event.value;
    } else this.selectedAssignee = [];
  }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
 }
 
  
}