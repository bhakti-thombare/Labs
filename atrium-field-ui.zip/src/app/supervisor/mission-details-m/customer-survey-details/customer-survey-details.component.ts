// core
import { Http } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';

// 3rd party
import {
  each,
  isMatch,
  isNull,
  isArray
} from "underscore";
import { Subscription } from 'rxjs/Subscription';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash' ;
// app
import { CustomerSurveyAlertsService } from '@services/Alerts/customer-survey-alerts.service';
import { UTILS } from '@services/global-utility.service';
import { ApiService } from '@services/apiServices/api.service';
import { HttpService } from '@app/services/http-service';
import { CommentsModalsComponent } from '@app/supervisor/mission-details-m/mdp-modals/comments-modals/comments-modals.component';
import { SurveysModalComponent } from '@app/supervisor/mission-details-m/mdp-modals/surveys-modal/surveys-modal.component';
import { EventService } from '@services/events/event.service';
import { ReassignModalsComponent } from '@app/supervisor/mission-details-m/mdp-modals/reassign-modals/reassign-modals.component';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { MissionListAlertsService } from '@app/services/Alerts/mission-list-alerts.service';
import swal from 'sweetalert2';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-customer-survey-details',
  templateUrl: './customer-survey-details.component.html',
  styleUrls: ['./customer-survey-details.component.css']
})
export class CustomerSurveyDetailsComponent implements OnInit {
  private utilityFunctions = new UtilityFunctions();
  private subscriptions: Subscription[] = [];
  @ViewChild("statusChangePopup") statusChangePopup: TemplateRef<any>;
  tableHeaders: any = ["Event No.", "Event Type", "Start time", "Duration", "Distance", "Distance difference", "Comment", "Survey", "Validation"];
  tableData: Array<any> = [];
  commentsModalRef: NgbModalRef;
  surveyModalRef: NgbModalRef;
  ressignModalRef: NgbModalRef;
  missionId: any;
  missionTypeId: any;
  missionName: any;
  missionDetails: Array<any> = [{ "userDto": {userId:''}, "zone": {} }];
  shiftTablesData: Array<any> = [];
  userData: any = JSON.parse(localStorage.getItem('user-data'));
  util: any;
  offset: any = 0;
  limit: any = 100;
  evaluateFlag: boolean=false;
  hideApproveButton: boolean=false;
  firstTimeSortThroughEvent = true;
  currentSortOrderApplied = '';
  carryValidationSortOrder = false;
  constructor(
    public httpService: HttpService,
    public route: ActivatedRoute,
    public http: Http,
    public customerSurveyAlert: CustomerSurveyAlertsService,
    public eventService: EventService,
    public apiService: ApiService,
    public datePipe: DatePipe,
    public ngbModalService: NgbModal,
    public router:Router,
    private modalService: NgbModal,
    public missionListAlertsService: MissionListAlertsService,
    public translate: TranslateService,) {
    route.params.subscribe(params => {
      this.missionId = params.id;
      this.missionTypeId = params.missionTypeId;
    });
  }
  ngOnInit() {
    this.util = UTILS;
    this.getSurveyMissionProgressReport();
  }

  getSurveyMissionProgressReport() {
    this.eventService.showLoader({});
    this.subscriptions.push(this.apiService.getSurveyMissionProgressReport({ 'missionId': this.missionId }).subscribe(res => {
      if (res.data) {
        this.missionDetails = res.data;
        this.missionName = this.missionDetails[0].missionName;
        this.itteratorForTablesData();
        this.missionDetails.forEach(element => {
          if(element.evaluateFlag==true){
            this.evaluateFlag=true;
          }
          else
            this.evaluateFlag=false;
        });
      }
      this.eventService.hideLoader({});
    }, err => {
      this.eventService.hideLoader({});
    }));
  }
  shiftTablesbeforeSort=[]
  numberOfValidSurvey;
  numberOfSurveyReports;
  numberOfSurveyInPercentage;
  dataId;
  getUserSurveyReport(data, index, status: any = false) {
    console.log("index=",index);
    this.shiftTablesData[index]=[]
    this.dataId=data.id
    this.numberOfValidSurvey=0;
    this.numberOfSurveyReports=0;
    this.subscriptions.push(this.apiService.getUserSurveyReport({ 'id': data.id, 'limit': this.limit, 'offset': this.offset })
      .subscribe(res => {
        this.eventService.hideLoader({});
        if (res.data) {
          (!isArray(this.shiftTablesData[index]) || status) ? this.shiftTablesData[index] = res.data : this.shiftTablesData[index] = this.shiftTablesData[index].concat(res.data);
          this.shiftTablesData[0].forEach((ele,index)=>{
            ele['eventNo']=index+1;
            ele.eventType=_.capitalize(ele.eventType)
           this.getDifference(ele);
            ele.comment=ele.comment==''?null:ele.comment
            if(ele.surveyStatus==='Valid'){
              this.numberOfValidSurvey=this.numberOfValidSurvey + 1;
            }
          })
        }
        this.shiftTablesbeforeSort=this.shiftTablesData;

        let yetToValidate = this.shiftTablesData[0].filter(res => res.surveyStatus == 'Yet to validate');
        let valid = this.shiftTablesData[0].filter(res => res.surveyStatus == 'Valid');
        let invalid = this.shiftTablesData[0].filter(res => res.surveyStatus == 'Invalid');
        let refusal = this.shiftTablesData[0].filter(res => res.eventType == 'Refusal');
        let incomplete = this.shiftTablesData[0].filter(res => res.surveyStatus == 'Incomplete');
        let concat = yetToValidate.concat(valid, invalid, refusal,incomplete);
        
        // this.shiftTablesData[0] = concat;
       
        this.numberOfSurveyReports=this.shiftTablesData[0].length
         this.numberOfSurveyInPercentage=(this.numberOfValidSurvey / (this.missionDetails[0].completedSurveys+this.missionDetails[0].stoppedSurveys))*100
         this.numberOfSurveyInPercentage=this.numberOfSurveyInPercentage.toFixed(2)
        console.log(this.shiftTablesData,this.numberOfSurveyReports);
        if(this.firstTimeSortThroughEvent){
          this.shiftTablesData[0]= _.orderBy(this.shiftTablesData[0],'eventNo','asc' );
          this.firstTimeSortThroughEvent = false;
        }
        // if(this.carryValidationSortOrder){
        //   this.applySort('surveyStatus',this.currentSortOrderApplied);
        // }
      }, err => { this.eventService.hideLoader({}); }));
  }
  getDifference(ele: any) {
    var difference;
    var minus=150;
    difference=ele.distanceDifference - minus;
    ele.eventType=='Refusal'?difference=ele.distanceDifference - minus:false;
    difference<0?ele.distanceDifference=0:ele.distanceDifference=difference;
  }

  loadMore(id, index) { this.eventService.showLoader({}); this.offset = this.limit + this.offset; this.getUserSurveyReport({ "id": id }, index); }

  itteratorForTablesData() {
    each(this.missionDetails, (md, index) => {
      if (!isNull(md.totalSurveys)) this.getUserSurveyReport(md, index); else this.shiftTablesData[index] = null;
    });
  }
  applySort(key,order){
    // this.currentSortOrderApplied = order;
    console.log("key=",key,order);
    if(key=='survey'){
      this.shiftTablesData[0].forEach((ele)=>{
       ele.surveySortStatus = ele.eventType =='Refusal'? 'b':'a';
      });
      // console.log(this.shiftTablesData);
      key='surveySortStatus';
    }
    //this.shiftTablesData=this.shiftTablesbeforeSort;
    //this.shiftTablesData[0]= _.orderBy(this.shiftTablesData[0],key,order );
    this.shiftTablesData = this.shiftTablesbeforeSort;
    if (order == 'asc' && key == 'surveyStatus'){
      let yetToValidate = this.shiftTablesData[0].filter(res => res.surveyStatus == 'Yet to validate');
      let valid = this.shiftTablesData[0].filter(res => res.surveyStatus == 'Valid');
      let invalid = this.shiftTablesData[0].filter(res => res.surveyStatus == 'Invalid');
      let refusal = this.shiftTablesData[0].filter(res => res.eventType == 'Refusal');
      let incomplete = this.shiftTablesData[0].filter(res => res.surveyStatus == 'Incomplete');
      let concat = yetToValidate.concat(valid,invalid,refusal,incomplete);
      this.shiftTablesData[0] = concat;
    } else if (order == 'desc' && key == 'surveyStatus'){
      let incomplete = this.shiftTablesData[0].filter(res => res.surveyStatus == 'Incomplete');
      let refusal = this.shiftTablesData[0].filter(res => res.eventType == 'Refusal');
      let invalid = this.shiftTablesData[0].filter(res => res.surveyStatus == 'Invalid');
      let valid = this.shiftTablesData[0].filter(res => res.surveyStatus == 'Valid');
      let yetToValidate = this.shiftTablesData[0].filter(res => res.surveyStatus == 'Yet to validate');
      let concat = incomplete.concat(refusal, invalid, valid, yetToValidate);
      this.shiftTablesData[0] = concat;
    } else{
      this.shiftTablesData[0]= _.orderBy(this.shiftTablesData[0],key,order );
    }
    
    //console.log(this.shiftTablesData[0]);
    

  }
  private modalRef;
  @ViewChild('myModal') myModal;
  openModal(){
    this.modalRef = this.modalService.open(this.myModal, {
        backdrop: true,
        keyboard: false,
    })
}
close(){
  this.modalRef.close();
}
evaluation;
check(key){
  console.log("key=",key);
  this.evaluation=key; 
}
evaluationDone=false;
evaluateMission(){
  this.evaluationDone=true;
  this.modalRef.close();
  let bad,correct,perfect
  if(this.evaluation=='bad'){
    bad=true;
    correct=false;
    perfect=false;
  } else if(this.evaluation=='correct'){
    correct=true;
    bad=false;
    perfect=false;
  }else {
    perfect=true;
    correct=false;
    bad=false;
  }
  const reqBody={
    missionId:this.missionId,
    agentId:this.missionDetails[0].userDto.userId,
    badlyDone:bad,
    correctlyDone:correct,
    perfectlyDone:perfect
  }
  this.apiService.posEvaluate(reqBody).subscribe((res)=>{
    console.log("success=",res);
    if(res.responseCode==200){
      this.evaluateFlag=true;
      this.missionListAlertsService.evaluateMpd();
    }
    
  })
}

  openCommentsModal(comment, index, details) {
    this.commentsModalRef = this.ngbModalService.open(CommentsModalsComponent, { size: "sm" });
    this.commentsModalRef.componentInstance.commentData = comment;
    this.commentsModalRef.componentInstance.details = details;
    this.commentsModalRef.result.then(rs => {
      if (rs != 'crossClocked') { this.getUserSurveyReport({ id: details.id }, index, true); }
    });
  }

  /**Open Ressign Modal start**/
  openReassignModal(reaasign) {
    // this.router.navigate([`missions/details/${this.missionId}/2/cs/reassign`])
    
    // swal(MESSAGECONSTANTS.ALERT_MESSAGES.CAMPAIGN_EXPIRED_TITLE, '', 'warning').then(data => {
    //   // this.location.back();
    // });
    this.hideApproveButton=true;

    let campaignEndDate=new Date(reaasign.campaignEndDate)
    var currentDate=new Date();
    // if(campaignEndDate >= currentDate){
    //   this.router.navigate([`supervisor/missions/details/${this.missionId}/2/cs/reassign`]) 
    // }
    if(campaignEndDate >= currentDate){
      this.router.navigate([`supervisor/missions/details/${this.missionId}/2/cs/reassign`]) 
    }
    else if(campaignEndDate.getDate() >= currentDate.getDate() && campaignEndDate.getMonth() >= currentDate.getMonth() && campaignEndDate.getFullYear() >= currentDate.getFullYear()){
      // if(campaignPrevEndDate >= currentDate){
        this.router.navigate([`supervisor/missions/details/${this.missionId}/2/cs/reassign`]) 
}
    else{
    return swal({
      title: this.translate.instant('The mission is within an overdue campaign. If you want to select a new assignment date, please first contact your Admin in order to expand campaign duration.'),
      // text: this.translate.instant('The mission is within an overdue campaign. If you want to select a new assignment date, please first contact your Admin in order to expand campaign duration.') + '?',
      type: 'warning', 
      // allowOutsideClick: false,
    
      confirmButtonText: this.translate.instant('OK'),
      // showCancelButton: true,
    });
    }
    // let reassignDate = new Date(UTILS.getDateTimeFormat(UTILS.minDate));
    // if (reassignDate.toDateString() == new Date(reaasign.campaignEndDate).toDateString()) {
    //   this.customerSurveyAlert.campainIsAboutExpireAlert().then(rs => { }).catch(err => err);
    // } else if (reassignDate > new Date(reaasign.campaignEndDate)) {
    //   this.customerSurveyAlert.campainIsExpireAlert().then(rs => { }).catch(err => err);
    // }
    // else {
    //   this.customerSurveyAlert.doYouWantReassign().then(() => {
    //     this.ressignModalRef = this.ngbModalService.open(ReassignModalsComponent);
    //     this.ressignModalRef.componentInstance.campaignEndDate = reaasign.campaignEndDate;
    //     this.ressignModalRef.componentInstance.missionId = this.missionId;
    //     this.ressignModalRef.componentInstance.details = reaasign;
    //     this.ressignModalRef.result.then(rs => {
    //       if (rs != 'crossClocked') { this.shiftTablesData = []; this.getSurveyMissionProgressReport(); }
    //     });
    //   }).catch(err => err);
    // }
  }
  /**Open Ressign Modal END**/
  gotoLocation(zone){
  console.log("name=",zone);
  
  this.router.navigate(['/supervisor/edit-location/cs-zone/' + zone.name + '/003' + '/' + zone.id]);

}
gotoLocationMarket(zone){
  console.log("name=",zone);

  this.router.navigate(['/supervisor/edit-location/market-zone/' + zone.shortName + '/002' + '/' + zone.id]);

}
questionList;
openSurveySheet=false;
  openSurveysModal(questionList, index, id) {
    console.log("questionlist=",questionList);
    this.openSurveySheet=true;
    this.questionList=questionList
    // this.surveyModalRef = this.ngbModalService.open(SurveysModalComponent, { size: "lg" });
    // this.surveyModalRef.componentInstance.questionAnsList = questionList;
    // this.surveyModalRef.result.then(rs => {
    //   if (rs != 'crossClocked') {
    //     this.getUserSurveyReport({ id: id }, index, true);
    //   }
    // }).catch(err => 
    //   console.log(err)
    // );
  }
  closeSheet(event){
    this.openSurveySheet=false;

    if(event==="true"){
      // this.carryValidationSortOrder = true;   
      this.shiftTablesData[0]= _.orderBy(this.shiftTablesData[0],'eventNo','asc' );
      this.getUserSurveyReport({id:this.dataId},0);
      return;
    }
    this.shiftTablesData[0]= _.orderBy(this.shiftTablesData[0],'eventNo','asc' );
  }
  approveMission(shiftData) {
    let reqBody = { "missionId": this.missionId, "userId": shiftData.userDto.userId, "shiftId": shiftData.shift, "iterations": null, "supervisorId": this.userData.userId, "currentStatus": shiftData.status };
    this.subscriptions.push(this.apiService.approveMission('', reqBody)
      .subscribe(res => {
        if (res.responseCode == "200") { 
          this.shiftTablesData = []; this.getSurveyMissionProgressReport(); 
          this.hideApproveButton=true;
        }
      }, err => { err; }));
  }

  isValidStatusAvail(indx) {
    let shiftData = this.shiftTablesData[indx];
    if (shiftData) {
      for (let i = 0; i < shiftData.length; i++) {
        const element = shiftData[i];
        if (isMatch(element, { surveyStatus: 'Yet to validate' })) {
          return true;
        } else if (shiftData.length == (i - 1) && isMatch(element, { surveyStatus: 'Yet to validate' })) {
          return false;
        }
      }
    }
  }

  /* Dynamic Pipes Starts*/
  getUIDate(date) { return (date) ? this.datePipe.transform(date, 'dd/MM/yyyy') : 'NA'; };
  getUITime(date) { return (!isNull(date)) ? `${this.datePipe.transform(date, "HH:mm:ss")}` : 'NA'; };
  getIsNull(value) { return (!isNull(value) ? value : 'NA'); };
  /* Dynamic Pipes Ends */

  getUTCDate(date) {
    if (!isNull(date)) {
      let d = new Date(date);
      let cd = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes(), d.getSeconds(), d.getMilliseconds()));
      if (cd.toString() != 'Invalid Date') {
        return this.datePipe.transform(cd, `HH:mm`) + ` ${(cd.getHours() >= 12) ? 'PM' : 'AM'}`;
      }
    } else {
      return 'NA';
    }
  }
  isLoader(totalRecords) { if (totalRecords > this.limit && totalRecords > (this.offset + this.limit)) return true; return false; }
  cssLoader(data, detailsStatus) { if (!data && detailsStatus.totalSurveys) return true; return false; }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }

}