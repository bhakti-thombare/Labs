import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Globals, missionTypes } from '@app/constants/constants';
import { CustomerSurveyAlertsService } from '@app/services/Alerts/customer-survey-alerts.service';
import { MissionListAlertsService } from '@app/services/Alerts/mission-list-alerts.service';
import { ApiService } from '@app/services/apiServices/api.service';
import { UTILS } from '@app/services/global-utility.service';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import {
  each,
  map,
  isArray,
  filter,
  isEmpty,
  defaults,
  findWhere,
  isUndefined
} from 'underscore';

@Component({
  selector: 'app-cs-reassign',
  templateUrl: './cs-reassign.component.html',
  styleUrls: ['./cs-reassign.component.css']
})
export class CsReassignComponent implements OnInit {

  private subscriptions: Subscription[] = [];
  today: Date = new Date();
  minDate: any;
  maxDate: any;
  disablesubmit: boolean=false;

  constructor(private activatedRoute: ActivatedRoute,
    private apiService:ApiService,
    public custAlerts: CustomerSurveyAlertsService,
    public router:Router,
    public translate:TranslateService,
    public missionListAlertsService:MissionListAlertsService) { }
  missiondates;
  morning=true;
  agentSelected=false;
  step1Form:FormGroup;
  step2Form:FormGroup;
  step3Form:FormGroup;

  mission={
    userId:localStorage.getItem('userId'),
    classic:'',
    prm:'',
    visits:'',
    market:'',
    agent:{
     userId:''
    },
    missionCampaign:{
      campaignName:'',
      campaignId:''
    },
    missionMarketZoneList:[{
    shortName:'',
    latitude:'',
    longitude:'',
    id:''
    }],
    missionZones:[{
      address:'',
      adptId:'',
      name:'',
      latitude:'',
      longitude:'',
      id:''
    }],
    missionId:'',
    missionStatus:{
      statusId:'',
      statusName:''
    },
    shift:{
      shiftId:''
    },
    missionStartDate:'',
    missionType:{
      id:''
    },
    subType:1,
    numberOfPos:'',
    numberOfPosCheckpoints:'',
    supervisorId:'',
    missionEstimatedTime:''
  }
  selectedMission: Array<any> = [];
  textControl = new FormControl();
  shiftStart;
  shiftEnd;
submitMission(){
  this.disablesubmit=true;
  console.log("mission values=",this.step1Form.value,localStorage.getItem('userId'));
  this.shiftStart=this.morning?"8:45:00":"13:00:00"
  this.shiftEnd=this.morning?"13:00:00":"17:15:00"
  const reqbody={
    newUserId:this.selectAgentId, //new assigned field agent
    oldUserId:this.mission.agent.userId, //previous agent id
    missionId:this.mission.missionId,
    campaignId:this.mission.missionCampaign.campaignId,
    currentStatus:this.mission.missionStatus.statusName,
    oldStatus:this.mission.missionStatus.statusId,
    createdBy:localStorage.getItem('userId'),
    updatedBy:localStorage.getItem('userId'),
    supervisorId:this.mission.supervisorId,
    shiftId:this.morning?1:2,
    oldShiftId:this.mission.shift.shiftId,
    iterations:null,
    newStartDate:`${this.missiondates} ${this.shiftStart}`,
    newEndDate:`${this.missiondates} ${this.shiftStart}`,
    currentStartDate:this.mission.missionStartDate,
    zoneId:this.mission.missionZones[0].id,
    locationTypeId:3,
    missionRequest:{
      missionTypeId:4,
      missionCreationDate:"",
      missionStartDate:`${this.missiondates} 00:00:00`,
      missionEndDate:`${this.missiondates} 00:00:00`,
      classic:this.mission.classic,
      visits:this.mission.visits,
      market:this.mission.market,
      prm:this.mission.prm,
      marketZone: this.mission.missionMarketZoneList !== null? this.mission.missionMarketZoneList[0].id:null,
      missionName:this.step1Form.value.missionName,
      missionDescription:this.step1Form.value.missionDescription,
      missionCampaignId:this.mission.missionCampaign.campaignId,
      missionCreatedById:localStorage.getItem('userId'),
      missionUpdatedById:localStorage.getItem('userId'),
      missionStatusId:10,
      missionEstimatedTime:610
    }
  }
  this.apiService.postCSReassignDetails(reqbody,this.missionId).subscribe((res)=>{
    console.log("success",res);
    if(res.responseCode==200){
      this.missionListAlertsService.reassignMission().then(() => {
        this.router.navigate(['/supervisor/missions'])

      });;

    }
    
  })

}



  getMission(id) {
    this.subscriptions.push(
      this.apiService.getAllMissions({ id: id }).subscribe(
        res => {
          console.log("getmission=",res.data.mission);
          
          this.selectedMission = [...res.data.missions];
          console.log('selected mission=',this.selectedMission);

          Globals.campaignStartDate =
            res.data.missions[0].missionCampaign.campaignStartDate;
          Globals.campaignEndDate =
            res.data.missions[0].missionCampaign.campaignEndDate;
          this.setMinMaxDate();
        },
        err => {
          console.log(err);
        }
      )
    );
  }
  setMinMaxDate() {
    const minDate_ = new Date(UTILS.getDateTimeFormat(UTILS.minDate));
    const campaignStartDate = new Date(Globals.campaignStartDate);
    if (minDate_ < campaignStartDate)
      this.minDate = UTILS.getDatePickerDateFormat(Globals.campaignStartDate);
    else this.minDate = UTILS.minDate;

    this.maxDate = UTILS.getDatePickerDateFormat(Globals.campaignEndDate);
    //console.log("minDate",this.minDate);
    //console.log("maxDate",this.maxDate);
  }
  getUsedMissionDates(date) {
    let currentDate = UTILS.getDatePickerDateFormat(date);
    this.subscriptions.push(
      this.apiService
        .getShiftWiseUsedMissionDates(
          UTILS.getDateFormatWithoutZero(currentDate),
          missionTypes.POS_POI_TYPE_ID,this.morning?1:2
        )
        .subscribe(
          res => {
            Globals.BUSY_DATES = res.dateDto;
          },
          err => (Globals.BUSY_DATES = [])
        )
    );
  }

  isDisabled(date: NgbDate, current: { month: number }) {
    const isDateFind = findWhere(
      Globals.BUSY_DATES,
      UTILS.getDatePickerIntFormat(date)
    );
    const currentDate = new Date(UTILS.getDateFormat(date));
    const day = currentDate.getDay();
    const isWeekend = day != 0 && day != 6;
    if (!isUndefined(isDateFind)) return true;
    else return false;
  }
  step1details(){
   

    this.step1Form.setValue({
      'step1':{
        'camapaignName':this.mission.missionCampaign.campaignName,
        'missionType':'CS',
        'missionName':'',
        'classic':this.mission.classic,
        'market':this.mission.market,
        'missionDescription':'',
        'missionMarketName':this.mission.missionMarketZoneList!==null?  this.mission.missionMarketZoneList[0].shortName:''
      },
    
    })
  }

  step2details(){
  
    this.step2Form.setValue({
      'step2':{
        'adptId':this.mission.missionZones[0].adptId,
        'address':this.mission.missionZones[0].address,
        'name':this.mission.missionZones[0].name
        
      },
    
    })
  }

  step3details(){
  
    // this.step3Form.setValue({
    //   'step3':{
    //     // 'quartierName':this.mission.quartierDto.name,
    //       'POS':this.mission.numberOfPos,
    //       'checkpoints':this.mission.numberOfPosCheckpoints,
    //       'subType':this.mission.subType==5?this.translate.instant('Points of sale only'):this.translate.instant('Points of sale & Checkpoints')
        
    //   },
    
    // })
  }
missionId;
startDate;
  getDate(date){
    const month=String(date.month).padStart(2, "0");
      const day=String(date.day).padStart(2, "0");
      this.missiondates=`${date.year}-${month}-${day}`
      console.log("mission dates=",this.missiondates);
      this.startDate=`${date.year}-${date.month}-${date.day}`
     this.assignUsers();

  }
  assignUsers(){
    this.getAllUnassignedUsersPos({
      // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
      // endDate: UTILS.getDateFormatWithTime(endDate),
      startDate:this.startDate,
      endDate:this.startDate,
      iterations: 9,
      shift: this.morning?1:2,
      missionId: this.missionId
    });
    
  }
  selectedAgent;
  selectAgentId;
  dateSelected=false;
  toggleFieldAgent(user){
    this.agentSelected=true;
    this.selectedAgent=`${user.firstName} ${user.lastName}`
    this.selectAgentId=user.userId
  }
  optionsAgents=[]
  getAllUnassignedUsersPos(reqBody) {
    this.subscriptions.push(
      this.apiService.getAllUnassignedUsersPos(reqBody).subscribe(
        res => {
          this.dateSelected=true;
          this.optionsAgents = [];
          this.optionsAgents = map(res.users, m =>
            UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` })
          );
          console.log("res===",this.optionsAgents);
                 },
        err => {
          if (err.status === 400) {
            this.dateSelected=false;
            this.custAlerts.noAgentFound();
          }
        }
      )
    );
  }

  changeShiftId(id) {
    console.log("id=",id);
    
    if (id === 1) {
      this.morning = true;
      this.getUsedMissionDates(this.today)
      if(this.startDate !== undefined){
        this.assignUsers()
      }
    } else {
      this.morning = false;
      this.getUsedMissionDates(this.today);
      if(this.startDate !== undefined){
        this.assignUsers()
      }
    }
  }
  mapObject=[];
  getMissionDetails(id){
    this.apiService.getReassignCSMissionDetails(id).subscribe(result => {
      console.log("result=",result);
      this.mission=result.data
      // this.mapObject=[{'latitude':50.84684682158198,'longitude':4.34628584859738}]
      if(this.mission.missionMarketZoneList !== null){
      this.mapObject.push({'latitude':this.mission.missionMarketZoneList[0].latitude,'longitude':this.mission.missionMarketZoneList[0].longitude,'flag':false,'step4':false})
      }
      this.mapObject.push({'latitude':this.mission.missionZones[0].latitude,'longitude':this.mission.missionZones[0].longitude,'flag':false,'step4':true})
      this.step1details();
      this.step2details();
      console.log("this.map=",this.mapObject);
      // this.mapObject=[this.mapObject,{'latitude':50.84684682158198,'longitude':4.34628584859738}]
      
// this.step2details();
// this.step3details();
// this.getQuartierDetails(this.mission.quartierDto)
      
    })
  }
//   getQuartierDetails(id){
// console.log("quartier id=",id);
// this.apiService.getQuartiers(id).subscribe((res)=>{
//   console.log("quartiers=",res);
  
// })

//   }
  nameExists=false;
  name=false;
  textControl1 = new FormControl();

  checkMissionName(){
    this.textControl.valueChanges.pipe(
      ).subscribe((res)=>{
        //  res=(res.toString()).trim();
        res=$.trim(res);
      this.step1Form.value.missionName=res;
      if(res!==''){
        this.apiService.getMissionName(res).subscribe((res)=>{
            this.name=true;
          this.nameExists=false;
      },(error)=>{
          this.nameExists=true;
          this.name=false;  
      })
      } else {
        this.name=false
      } 
      });
  }
  description=false;
  ngOnInit() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
   this.checkMissionName()
   this.textControl1.valueChanges.pipe(
    ).subscribe((res)=>{
      // res=res.trim();
      res=$.trim(res);
this.step1Form.value.missionDescription=res
         if(res !== ''){
           this.description=true
         } else {
           this.description=false
         }
         console.log("this.description=",this.description);
         
         if(this.name && this.description){
            //  this.buttonEnabled=true;
         } else {
          //  this.buttonEnabled=false;
         }
    });
    this.step1Form = new FormGroup({
      'step1': new FormGroup({
          'camapaignName':new FormControl(null),
          'missionType':new FormControl(null),
          'missionName':new FormControl(null),
          'classic':new FormControl(null),
          'market':new FormControl(null),
          'missionDescription':new FormControl(null),
          'missionMarketName':new FormControl(null)
      }),
    });
    this.step2Form = new FormGroup({
      'step2': new FormGroup({
        'adptId':new FormControl(null),
        'address':new FormControl(null),
        'name':new FormControl(null)

      }),
    });
    // this.step3Form = new FormGroup({
    //   'step3': new FormGroup({
    //       'quartierName':new FormControl(null),
    //       'POS':new FormControl(null),
    //       'checkpoints':new FormControl(null),
    //       'subType':new FormControl(null)


    //   }),
    // });
      this.missionId = this.activatedRoute.snapshot.paramMap.get('id')
      this.getMission(this.missionId);

this.getMissionDetails(this.missionId)
this.getUsedMissionDates(this.today);



  }


}
