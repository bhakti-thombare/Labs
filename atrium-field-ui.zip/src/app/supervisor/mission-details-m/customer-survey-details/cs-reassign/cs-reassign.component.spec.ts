import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CsReassignComponent } from './cs-reassign.component';

describe('CsReassignComponent', () => {
  let component: CsReassignComponent;
  let fixture: ComponentFixture<CsReassignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CsReassignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CsReassignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
