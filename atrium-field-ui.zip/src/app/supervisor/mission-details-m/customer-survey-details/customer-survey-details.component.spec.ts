import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerSurveyDetailsComponent } from './customer-survey-details.component';

describe('CustomerSurveyDetailsComponent', () => {
  let component: CustomerSurveyDetailsComponent;
  let fixture: ComponentFixture<CustomerSurveyDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerSurveyDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerSurveyDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
