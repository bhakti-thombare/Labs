import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditMarketFlowComponent } from './market-flow.component';

describe('MarketFlowComponent', () => {
  let component: EditMarketFlowComponent;
  let fixture: ComponentFixture<EditMarketFlowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditMarketFlowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditMarketFlowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
