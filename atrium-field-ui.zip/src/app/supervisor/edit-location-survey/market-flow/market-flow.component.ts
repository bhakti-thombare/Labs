import { Component, OnInit, ElementRef, Renderer2 } from '@angular/core';
import { ApiService } from '@app/services/apiServices/api.service';
import { EventService } from '@app/services/events/event.service';
import { HttpService } from '@app/services/http-service';
import { Location } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CreateSurveyUtilsService } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.service';
import { missionTypes, ApiConstants } from '@app/constants/constants';
import { Router, ActivatedRoute } from '@angular/router';
import { UTILS } from '@app/services/global-utility.service';
import { TranslateService } from '@ngx-translate/core';
import { PedestrainAlertsService } from '@app/services/Alerts/pedestrainAlerts/pedestrain-alerts.service';


declare var google: any;

@Component({
  selector: 'app-edit-location-market-flow',
  templateUrl: './market-flow.component.html',
  styleUrls: ['./market-flow.component.css']
})
export class EditMarketFlowComponent implements OnInit {
   today = new Date(Date.now());

  minDate = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };
  check=false;
  check1=false;
  check2=false;
  check3=false;
  check4=false;
 check5=false;
 check6=false;
 check7=false;

  minEndDate = {
    day: null,
    month: null,
    year: null
  };
   model: NgbDateStruct;
  createMissionForm: FormGroup = new FormGroup({
    missionStartDate: new FormControl('', Validators.required),
    missionEndDate: new FormControl('', Validators.required),
    estimatedTimeHourHour: new FormControl('', Validators.required),
    estimatedTimeHourMin: new FormControl('', Validators.required),
    check3: new FormControl('', Validators.required),
    missionDescription: new FormControl('')
  });
  marketLoaded: boolean;
  existingMarkets= [] ;
  existingMarketsFound: boolean;
  tempmissions: any;
  missions: any;
  missionsLoaded: boolean;
  marketNameDisabled: boolean;
  step2Completed: any;
  disableStep2: boolean;
  marketZoneId: any;
  market: any;
  datepickers = [];
  busyDates = [];

  user = JSON.parse(localStorage.getItem('user-data'));
  mapObject: any = {}
  mission = {
    selectedCampaign: {
      startDateObj: {},
      endDateObj: {}
    },
    markets: [],
    assignments: [],
    missionStartDate: '',
    missionEndDate: '',
    estimatedTimeHour: null,
    estimatedTimeMinutes: null,
    missionName: '',
    missionDescription: ''
  };
  calendarReady: boolean =false;
  missionTypesLoaded: boolean;
  missionTypes: any[];
  selectedMissionType: any;
  campaignsLoaded: boolean;
  campaigns: any;
  id: any;
  endDate: string;
  editZone=true;
  constructor(public http: HttpClient,
    public rd: Renderer2,
    public el: ElementRef,
    public router: Router,
    public route: ActivatedRoute,
    public event: EventService,
    public _http: HttpService,
    public custUtils: CreateSurveyUtilsService,
    public api: ApiService,
    public translate: TranslateService,
    public pedestrainAlertsService: PedestrainAlertsService,
    public location : Location) {
      this.event.broadcast({ eventName: 'showLoader', data: '' });
      this._http.pullCountry().subscribe(res => { }, err => { });
      const date = new Date(Date.now());
      const month = date.getMonth() + 1;
      localStorage.removeItem('busyDates');
      this.api.getUsedMissionDates(date.getFullYear() + '-' + month + '-' + date.getDate(), '4')
        .subscribe(res => {
          let busyDatesLen = res.dateDto.length;
          res.dateDto.forEach(resdate => {
            resdate.day = parseInt(resdate.day, 10);
            resdate.month = parseInt(resdate.month, 10);
            resdate.year = parseInt(resdate.year, 10);
            this.busyDates.push(resdate);
            busyDatesLen--;
            if (busyDatesLen === 0) {
              localStorage.setItem('busyDates', JSON.stringify(this.busyDates));
              this.calendarReady = true;
            }
          });
        }, err => {
          this.calendarReady = true;
        });
        this.route.params.subscribe(params => { 
          if(params.locationId==="002"){
            this.editZone=false;
      }
      this.getLocationDetails(params.name,params.locationId,params.elementId)
        this.locationId=params.locationId });
  }

  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6;
  }

  isDisabled(date: NgbDateStruct, current: { month: number }) {
    const now = new Date(Date.now());
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
    const sdate = new Date(date.year, date.month - 1, date.day);

    if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };

        // found = busyDates.findIndex(dateFinder);
        // if (found !== -1) {
        //   return true;
        // } else {
        //   return false;
        // }
      } else {
        return false;
      }
    } else {
      return true;
    }
    
  }

  //   getCampaigns() {
  //   this.campaignsLoaded = false;
  //   this.api.getUserCampaigns(this.user.userId).subscribe(res => {
  //     this.custUtils.campaignsInitializer(res.data.campaigns, response => {
  //       if (response.message === 'campaignExpired') {
  //         this.custUtils.translateMessageObject({
  //           title: 'Campaign expired.',
  //           text: 'Please contact admin for more campaigns.',
  //           type: 'warning',
  //           outsideClick: true,
  //           showCancelBtn: false,
  //           confirmBtnText: 'OK',
  //           cancelBtnText: ''
  //         }, (responseMessageObject) => {
  //           this.custUtils.translateAndPop(responseMessageObject).then(() => {
  //             this.location.back();
  //           }).catch(() => {
  //             this.location.back();
  //           });
  //         });
  //       } else if (response.message === 'success') {
  //         this.campaigns = response.campaigns;
  //         this.mission.selectedCampaign = this.campaigns[0];
          // localStorage.setItem('campaignStartDate', JSON.stringify(this.mission.selectedCampaign.startDateObj));
          // localStorage.setItem('campaignEndDate', JSON.stringify(this.mission.selectedCampaign.endDateObj));
  //         this.campaigns.splice(0, 1);
  //         this.campaignsLoaded = true;
  //       }
  //     });
  //   }, err => { });
  // }

  isEndDisabled(date: NgbDateStruct, current: { month: number }) {
    const localDate = JSON.parse(localStorage.getItem('date'));
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const minDate = new Date(localDate.year, localDate.month, localDate.day);
    const campaignStartDate = new Date(startCheck.year, startCheck.month, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month, endCheck.day);
    const sdate = new Date(date.year, date.month, date.day);

    if (sdate > minDate && sdate >= campaignStartDate && sdate <= campaignEndDate) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };

        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return true;
    }
    
  }
locationId;
  ngOnInit() {
   
    this.mission.markets = [];
    // this.route.params.subscribe(params => { this.getLocationDetails(params.name,params.locationId)
    // this.locationId=params.locationId });
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this.getMissionTypes();
  }

  getMissionTypes() {
    this.missionTypesLoaded = false;
    this.missionTypes = [];

    this.api.getMissionTypes().subscribe(res => {
      let typeLen = res.data.length;
      res.data.forEach(type => {
        if (type.id === 3 || type.id === 4) {
          this.missionTypes.push(type);
        }
        typeLen--;
        if (typeLen === 0) {
          if (this.missionTypes[0].id === 4) {
            this.selectedMissionType = this.missionTypes[0];
            this.missionTypes.splice(0, 1);
          } else {
            this.selectedMissionType = this.missionTypes[1];
            this.missionTypes.splice(1, 1);
          }
          this.missionTypesLoaded = true;
        }
      });
    }, err => {
      console.log('err', err);
    });
  }
  
  getLocationDetails(name,id,elementId){
console.log(id);
    this.api.getLocationDetails({'locationName':name,'locationType':2,'elementId':elementId})
    .subscribe(res => {
      let market= res.data;
      this.mission.markets.push({
      id: market.id,
      shortName: market.shortName,
      officialName:market.officialName,
      locationTypeId: 2,
      locationId:id,
      createdBy: this.user.userId,
      updatedBy: this.user.userId,
      adptId: market.adptId,
      latitude: market.latitude,
      startDate : market.startDate,
      endDate : market.endDate,
      longitude: market.longitude,
      address: market.address,
      expectedNumberOfStands: market.expectedNumberOfStands,
      numberOfSubscribedStands: market.numberOfSubscribedStands,
      numberOfUnSubscribedStands: market.numberOfUnSubscribedStands,
      managementAuthority: market.managementAuthority,
      scheduleMonOpen: this.replace(market.scheduleMonOpen),
      scheduleMonClose: this.replace(market.scheduleMonClose),
      scheduleTueOpen: this.replace(market.scheduleTueOpen),
      scheduleTueClose: this.replace(market.scheduleTueClose),
      scheduleWedOpen: this.replace(market.scheduleWedOpen),
      scheduleWedClose: this.replace(market.scheduleWedClose),
      scheduleThurOpen: this.replace(market.scheduleThurOpen),
      scheduleThurClose: this.replace(market.scheduleThurClose),
      scheduleFriOpen: this.replace(market.scheduleFriOpen),
      scheduleFriClose: this.replace(market.scheduleFriClose),
      scheduleSatOpen: this.replace(market.scheduleSatOpen),
      scheduleSatClose: this.replace(market.scheduleSatClose),
      scheduleSunOpen: this.replace(market.scheduleSunOpen),
      scheduleSunClose: this.replace(market.scheduleSunClose)
  });
  this.mission.missionEndDate=(market.endDate);
  this.mission.missionStartDate= (market.startDate);
  console.log(this.mission.markets[0]);
  this.mapObject = { latitude: this.mission.markets[0].latitude, longitude:  this.mission.markets[0].longitude }; 
    this.event.broadcast({ eventName: 'hideLoader', data: '' });
    }, err => {

    });   
   
  }

  replace(num) {
    if (num) {
      var res = num.split(':', 2);
      return res = res[0] + ':' + res[1];
    }
    else{
      return res = null;
    }
  }

  getLngLat(search, index, page) {
    const api = new google.maps.Geocoder;
    if (!(Array.isArray(search))) {
    search= search + ' Brussels';
    api.geocode({ address: search }, (result: any) => {
      if (result.length !== 0) {
        this.mission.markets[0].address = result[0].formatted_address;
        this.mission.markets[0].longitude = result[0].geometry.location.lng(); 
        this.mission.markets[0].latitude = result[0].geometry.location.lat();
        this.mapObject = { 'longitude': result[0].geometry.location.lng(), 'latitude': result[0].geometry.location.lat()};
      }else {
        this.pedestrainAlertsService.enterValidLocation();    // Issue 920 resolved
      }
    });
  }
  else{
    if (!this.step2Completed) {
      api.geocode({ latLng: { lat: search[1], lng: search[0] } }, result => {
        if (result) this.mission.markets[0].address = result[0].formatted_address;
      });
      this.mission.markets[0].longitude = search[0];
      this.mission.markets[0].latitude = search[1];
      this.mapObject = { 'longitude': search[0], 'latitude': search[1] };
      // this.mission.markets[0].name = undefined;
      // this.mission.markets[0].adptId = null;
      console.log('map changed');
     
      this.marketNameDisabled = false;
    }
  }
}

  instanceForCampaign(d1) {
    this.datepickers.push(d1);
  }

  saveAndOpen(form) {
    this.validateMarket(form, () => {
      this.createMarket(form);
    })
  }

  validateMarket(form,cb) {
    const market = this.mission.markets[0];
    if (market.existingMarketCheck) {
      cb();
    } else {
      console.log(this.endDate);
      if (this.mission.missionStartDate && this.mission.missionEndDate) {
        let startParts = this.mission.missionStartDate.split('/');
        let endParts = this.mission.missionEndDate.split('/');
        if (startParts[1] > endParts[1]) {
          this.custUtils.translateMessageObject({
            title: 'Enddate should be greater than Startdate',
            text: '',
            type: 'warning',
            cancelBtnText: '',
            confirmBtnText: 'OK',
            outsideClick: false,
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              console.log('hha');
            }).catch(() => {
              console.log('hha');
            });
          });
        }
        else if(startParts[1] == endParts[1]){
          if(startParts[0] > endParts[0]){
            this.custUtils.translateMessageObject({
              title: 'Enddate should be greater than Startdate',
              text: '',
              type: 'warning',
              cancelBtnText: '',
              confirmBtnText: 'OK',
              outsideClick: false,
              showCancelBtn: false
            }, message => {
              this.custUtils.translateAndPop(message).then(() => {
                console.log('hha');
              }).catch(() => {
                console.log('hha');
              });
            });
          }
          else{
            cb();
          }
        }else{
        cb();
        }
      } 
      else {
        this.custUtils.translateMessageObject({
          title: 'All fields are mandatory',
          text: '',
          type: 'warning',
          cancelBtnText: '',
          confirmBtnText: 'OK',
          outsideClick: false,
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
            console.log('hha');
          }).catch(() => {
            console.log('hha');
          });
        });
      }
    }
  }

  // changeLocalDate(date) {
  //   this.mission.missionEndDate = {
  //     month: null,
  //     day: null
  //   };
  //   // localStorage.setItem('date', JSON.stringify(date));
  //   this.minEndDate = date;
  // }
  
  keyDown(e){
    // charCode > 31 && (charCode < 48 || charCode > 57)
    if(!(e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105)){
      e.preventDefault();
      e.stopPropagation();
    }
  }

  keyUp(e){
    if(!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58) 
      || e.keyCode == 8)) {
        return false;
    }
  }

  keyUp1(e){
    if(!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58) 
      || e.keyCode == 8)) {
        return false;
    }
  }

  createMarket(formData) {

    this.disableStep2 = true;
    // const startDate = this.mission.missionStartDate.year + '-' +
    //     formData.value.startDateMission.month + '-' + formData.value.startDateMission.day;
    //   const endDate = formData.value.endDateMission.year + '-' +
    //     formData.value.endDateMission.month + '-' +
    //     formData.value.endDateMission.day;
    //   this.endDate=endDate;
    //   const now = Date.now();
    //   const creationDate = new Date(now);
    //   const nowYear = creationDate.getFullYear();
    //   const nowMonth = creationDate.getMonth() + 1;
    //   const nowDay = creationDate.getDate();
    //   const nowInReq = nowYear + '-' + nowMonth + '-' + nowDay;
    //   const estimatedTime = (parseInt('10', 10) * 60) + parseInt('10', 10);

    const market = this.mission.markets[0];

    const reqObj = {
      shortName: market.shortName,
      officialName:market.officialName,
      locationTypeId: 2,
      marketZoneId : market.id,
      locationId:this.locationId,
      createdBy: this.user.userId,
      updatedBy: this.user.userId,
      adptId: market.adptId,
      latitude: market.latitude,
      longitude: market.longitude,
      address: market.address,
      expectedNumberOfStands: market.expectedNumberOfStands,
      numberOfSubscribedStands: market.numberOfSubscribedStands,
      numberOfUnSubscribedStands: market.numberOfUnSubscribedStands,
      managementAuthority: market.managementAuthority,
      scheduleMonOpen: (market.scheduleMonOpen)?market.scheduleMonOpen+':00':null,
      scheduleMonClose: (market.scheduleMonClose)?market.scheduleMonClose+':00':null,
      scheduleTueOpen: (market.scheduleTueOpen)?market.scheduleTueOpen+':00':null,
      scheduleTueClose: (market.scheduleTueClose)?market.scheduleTueClose+':00':null,
      scheduleWedOpen: (market.scheduleWedOpen)?market.scheduleWedOpen+':00':null,
      scheduleWedClose: (market.scheduleWedClose)?market.scheduleWedClose+':00':null,
      scheduleThurOpen: (market.scheduleThurOpen)?market.scheduleThurOpen+':00':null,
      scheduleThurClose: (market.scheduleThurClose)?market.scheduleThurClose+':00':null,
      scheduleFriOpen: (market.scheduleFriOpen)?market.scheduleFriOpen+':00':null,
      scheduleFriClose: (market.scheduleFriClose)?market.scheduleFriClose+':00':null,
      scheduleSatOpen: ( market.scheduleSatOpen)?market.scheduleSatOpen+':00':null,
      scheduleSatClose: (market.scheduleSatClose)?market.scheduleSatClose+':00':null,
      scheduleSunOpen:( market.scheduleSunOpen)?market.scheduleSunOpen+':00':null,
      scheduleSunClose:(market.scheduleSunClose)?market.scheduleSunClose+':00':null,
      // creationDate: nowInReq.toString(),
      startDate: this.mission.missionStartDate,
      endDate: this.mission.missionEndDate
    };
    this.createAndMapMarketWithMission(reqObj);
  }
  createAndMapMarketWithMission(req) {
    let marketName = req.name;
    this.api.addMarket(req).subscribe(res => {
      this.marketZoneId = res.responseMessage.split('! ')[2];
      this.custUtils.translateMessageObject({
        title: this.translate.instant('Market zone updated successfully'),
        text: '',
        type: 'success',
        outsideClick: true,
        cancelBtnText: '',
        confirmBtnText: 'Ok',
        showCancelBtn: false
      }, message => {
        this.custUtils.translateAndPop(message).then(() => {
          this.step2Completed = true;
          this.router.navigate([`/supervisor/location`]);
        }).catch(() => {
          this.router.navigate([`/supervisor/location`]);
          this.step2Completed = true;
        });
      });
    }, err => {
      let response = JSON.parse(err._body);
      if (response.responseMessage === "undefined") {
        this.custUtils.translateMessageObject({
          title: 'Something went wrong!',
          text: 'Market zone not created please try again',
          type: 'error',
          outsideClick: true,
          cancelBtnText: '',
          confirmBtnText: 'Ok',
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
            this.disableStep2 = false;
          }).catch(() => {
            this.disableStep2 = false;
          });
        });
      } else {
        if (response.responseMessage.includes('Market with')) {
          let backEndString = response.responseMessage.split('Zone with ')[1];
          // let zoneName = backEndString.split(' already exists')[0];
          this.custUtils.translateMessageObject({
            title: 'Market with the same name already present',
            text: 'Please create market zone with unique name',
            type: 'error',
            outsideClick: false,
            cancelBtnText: '',
            confirmBtnText: 'Ok',
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.existingMarkets.forEach(extMarket => {
                if (extMarket.locationName.toLowerCase() === marketName.toLowerCase()) {
                  this.mapObject = { 'longitude': extMarket.longitude, 'latitude': extMarket.latitude };
                  this.market[0].selectedZone = extMarket;
                  this.market[0].existingMarketCheck = true;
                  this.event.broadcast({ eventName: 'existing-market-selected', data: extMarket.longitude + ',' + extMarket.latitude + ',' + 'map0' });

                }
              });
              this.disableStep2 = false;
            }).catch(() => {
              this.disableStep2 = false;
            });
          });
        } else {
          this.custUtils.translateMessageObject({
            title:'All fields are mandatory',
            text: 'Please click on an area on Map for the latitude and longitude',
            type: 'error',
            outsideClick: true,
            cancelBtnText: '',
            confirmBtnText: 'Ok',
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.disableStep2 = false;
            }).catch(() => {
              this.disableStep2 = false;
            });
          });
        }
      }
    });
  }
  gotoCancel(event){
   
    this.router.navigate([`/supervisor/location`]);
  }
  
  macAddressFormat(mac, event) {
    // var macAddress = event.target.value.toUpperCase();
    if (!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) {
      event.preventDefault();
      event.stopPropagation();
    }
    else {
      if (event.keyCode != 13) {

        var macAddr = event.target.value;
        var rash;

        var alphaNum = /^[A-Za-z0-9]+$/;
        if (macAddr.includes(':')) {
          if (macAddr.length == 5) {
            // console.log('393', event.target.value);
            var parts = event.target.value.split(':');
            // console.log(parts);
            if (parts[1] > 59) {
              parts[1] = 59;
              event.target.value = parts[0] + ':' + parts[1];
              // console.log('425', event.target.value);
            }
            if (parts[0] > 23) {
              parts[0] = 23;
              event.target.value = parts[0] + ':' + parts[1];
              // console.log('425', event.target.value);
            }

          } else if (macAddr.length == 4) {
            // console.log('393', event.target.value);
            var parts = event.target.value.split(':');
            // console.log(parts);
            if (parts[1] > 5) {
              parts[1] = 5;
              event.target.value = parts[0] + ':' + parts[1];
              // console.log('425', event.target.value);
            }
            if (parts[0] > 23) {
              parts[0] = 23;
              event.target.value = parts[0] + ':' + parts[1];
              // console.log('425', event.target.value);
            }
            console.log('final', event.target.value);
          }
        }
        if (macAddr.length == 2 && alphaNum.test(macAddr)) {

          // macAddr = macAddr.replace(/(.{2})/g, "$1:").slice(0, -1);
          macAddr = macAddr + ':';
          event.target.value = macAddr;
          rash = event.target.value;
          console.log('389', event.target.value);
        }
        else if (macAddr.length == 2) {
          if (macAddr > 24) {
            event.target.value = 24;
            rash = event.target.value;
            console.log('395', event.target.value);
          }
          else
            if (macAddr > 12) {
              var count = macAddr - 12;
              event.target.value = 12 + count;
              rash = event.target.value;
              console.log(event.target.value);
            }

        }
        else if (!alphaNum.test(macAddr)) {
          console.log("only alpha-numeric allowed");
        }
      }
    }
  }

  macAddressFormat1(mac, event) {
    if (!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) {
      event.preventDefault();
      event.stopPropagation();
    }
    else {
      var macAddr = event.target.value;
      var rash;
      if (event.keyCode != 13) {
        var alphaNum = /^[A-Za-z0-9]+$/;
        if (macAddr.includes('/')) {
          if (macAddr.length == 5) {
            var parts = event.target.value.split('/');
            if (parts[1] > 12) {
              parts[1] = 12;
              event.target.value = parts[0] + '/' + parts[1];
            }
            if (parts[0] > 31) {
              parts[0] = 31;
              event.target.value = parts[0] + '/' + parts[1];
            }
          } else if (macAddr.length == 4) {

            var parts = event.target.value.split('/');
            if (parts[1] > 5) {
              parts[1] = 5;
              event.target.value = parts[0] + '/' + parts[1];
            }
            if (parts[0] > 31) {
              parts[0] = 31;
              event.target.value = parts[0] + '/' + parts[1];
            }
            console.log('final', event.target.value);
          }
        }
        if (macAddr.length == 2 && alphaNum.test(macAddr)) {
          macAddr = macAddr + '/';
          event.target.value = macAddr;
          rash = event.target.value;
        }
        else if (macAddr.length == 2) {
          if (macAddr > 31) {
            event.target.value = 31;
            rash = event.target.value;
          }
        }
        else if (!alphaNum.test(macAddr)) {
          console.log("only alpha-numeric allowed");
        }
      }
    }
  }
 
monChecked(event){

   console.log("event=",event);
   if(event.target.checked){
     this.check=true;
   } else {
     console.log("false moi",this.mission);
     this.check=false;
     this.mission.markets[0].scheduleMonClose=null;
     this.mission.markets[0].scheduleMonOpen=null;
   }
   
 }
 tueChecked(event){
  console.log("event=",event);
  if(event.target.checked){
    this.check2=true;
  } else {
    this.check2=false;
    this.mission.markets[0].scheduleTueClose=null
     this.mission.markets[0].scheduleTueOpen=null
  }
  
}
wedChecked(event){
  console.log("event=",event);
  if(event.target.checked){
    this.check3=true;
  } else {
    this.check3=false;
    this.mission.markets[0].scheduleWedClose=null
     this.mission.markets[0].scheduleWedOpen=null
  }
  
}
thuChecked(event){
  console.log("event=",event);
  if(event.target.checked){
    this.check4=true;
  } else {
    this.check4=false;
    this.mission.markets[0].scheduleThurClose=null
     this.mission.markets[0].scheduleThurOpen=null
  }
  
}
friChecked(event){
  console.log("event=",event);
  if(event.target.checked){
    this.check5=true;
  } else {
    this.mission.markets[0].scheduleFriClose=null
     this.mission.markets[0].scheduleFriOpen=null
    this.check5=false;
  }
  
}
satChecked(event){
  console.log("event=",event);
  if(event.target.checked){
    this.check6=true;
  } else {
    this.mission.markets[0].scheduleSatClose=null
     this.mission.markets[0].scheduleSatOpen=null
    this.check6=false;
  }
  
}
sunChecked(event){
  console.log("event=",event);
  if(event.target.checked){
    this.check7=true;
  } else {
    this.mission.markets[0].scheduleSunClose=null
     this.mission.markets[0].scheduleSunOpen=null
    this.check7=false;
  }
  
}

  isDisable() {
    if ((this.mission.markets[0].managementAuthority && this.mission.markets[0].officialName
      && this.mission.markets[0].adptId && this.mission.markets[0].address
      && (this.mission.markets[0].expectedNumberOfStands && this.mission.markets[0].expectedNumberOfStands!=='0') && (this.mission.markets[0].numberOfSubscribedStands==0 || this.mission.markets[0].numberOfSubscribedStands )
      && (this.mission.markets[0].numberOfUnSubscribedStands  || this.mission.markets[0].numberOfUnSubscribedStands==0) && this.mission.missionStartDate
      && this.mission.missionEndDate )) {
      if(this.mission.markets[0].scheduleMonOpen != null && this.mission.markets[0].scheduleMonClose != null){
        this.check = true;
      }
      if(this.mission.markets[0].scheduleTueOpen != null && this.mission.markets[0].scheduleTueClose != null){
        this.check2 = true;
      }
      if(this.mission.markets[0].scheduleWedOpen != null && this.mission.markets[0].scheduleWedClose != null){
        this.check3 = true;
      }
      if(this.mission.markets[0].scheduleThurOpen != null && this.mission.markets[0].scheduleThurClose != null){
        this.check4 = true;
      }
      if(this.mission.markets[0].scheduleFriOpen != null && this.mission.markets[0].scheduleFriClose != null){
        this.check5 = true;
      }
      if(this.mission.markets[0].scheduleSatOpen != null && this.mission.markets[0].scheduleSatClose != null){
        this.check6 = true;
      }
      if(this.mission.markets[0].scheduleSunOpen != null && this.mission.markets[0].scheduleSunClose != null){
        this.check7 = true;
      }

      let list = [];
      if (this.check) {
        list.push('Monday');
      }
      if (this.check2) {
        list.push('Tuesday');
      }
      if (this.check3) {
        list.push('Wednesday');
      }
      if (this.check4) {
        list.push('Thursday');
      }
      if (this.check5) {
        list.push('Friday');
      }
      if (this.check6) {
        list.push('Saturday');
      }
      if (this.check7) {
        list.push('Sunday');
      }

      let boolean = list.every((res, index) => {
        if (res == 'Monday') {
          return this.mission.markets[0].scheduleMonOpen != "" && this.mission.markets[0].scheduleMonOpen != null && this.mission.markets[0].scheduleMonClose != "" && this.mission.markets[0].scheduleMonClose != null;
        }
        if (res == 'Tuesday') {
          return this.mission.markets[0].scheduleTueOpen != "" && this.mission.markets[0].scheduleTueOpen != null && this.mission.markets[0].scheduleTueClose != "" && this.mission.markets[0].scheduleTueClose != null;
        }
        if (res == 'Wednesday') {
          return this.mission.markets[0].scheduleWedOpen != "" && this.mission.markets[0].scheduleWedOpen != null && this.mission.markets[0].scheduleWedClose != "" && this.mission.markets[0].scheduleWedClose != null;
        }
        if (res == 'Thursday') {
          return this.mission.markets[0].scheduleThurOpen != "" && this.mission.markets[0].scheduleThurOpen != null && this.mission.markets[0].scheduleThurClose != "" && this.mission.markets[0].scheduleThurClose != null;
        }
        if (res == 'Friday') {
          return this.mission.markets[0].scheduleFriOpen != "" && this.mission.markets[0].scheduleFriOpen != null && this.mission.markets[0].scheduleFriClose != "" && this.mission.markets[0].scheduleFriClose != null;
        }
        if (res == 'Saturday') {
          return this.mission.markets[0].scheduleSatOpen != "" && this.mission.markets[0].scheduleSatOpen != null && this.mission.markets[0].scheduleSatClose != "" && this.mission.markets[0].scheduleSatClose != null;
        }
        if (res == 'Sunday') {
          return this.mission.markets[0].scheduleSunOpen != "" && this.mission.markets[0].scheduleSunOpen != null && this.mission.markets[0].scheduleSunClose != "" && this.mission.markets[0].scheduleSunClose != null;
        }
      });

      if (list.length > 0) {
        if (boolean == true) {
          return false;
        }
      }
      return true;
    } else {
      return true;
    }
  }

}
