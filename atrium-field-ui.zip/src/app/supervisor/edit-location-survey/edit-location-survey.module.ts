// core
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// 3rd party
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxMapboxGLModule } from 'ngx-mapbox-gl';
import { ChartsModule } from 'ng2-charts';
import { TagInputModule } from 'ngx-chips';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { TranslateModule } from '@ngx-translate/core';
import { Ng4FilesModule } from 'angular4-files-upload';
import { NgSelectModule } from '@ng-select/ng-select';

// app 
import { CONFIG } from '@app/config';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { EditCustomerSurveyComponent } from './edit-location-customer-survey/edit-location-customer-survey.component';
import { EditMarketFlowComponent } from './market-flow/market-flow.component';
import { EditPedestrianFlowComponent } from './pedestrian-flow/pedestrian-flow.component';
import { PipesModule } from '@app/pipes/pipes.module';
import { CreateLocationSurveyUtilsModule } from '../create-location-survey/create-location-survey-utils/create-location-survey-utils.module';
import { EditCircleMapComponent } from './edit-survey-utils/edit-circle-map/edit-circle-map.component';


@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    PipesModule,
    TranslateModule,
    NgxChartsModule,
    CreateLocationSurveyUtilsModule,
    TagInputModule,
    ChartsModule,
    Ng4FilesModule,
    FormsModule,
    ReactiveFormsModule,
    NgxMapboxGLModule.forRoot({
      accessToken: CONFIG.mapBoxAccessToken
    }),
    SelectDropDownModule,
    NgSelectModule
  ],
  exports: [EditCustomerSurveyComponent, EditMarketFlowComponent, EditPedestrianFlowComponent],
  declarations: [EditCustomerSurveyComponent, EditMarketFlowComponent, EditPedestrianFlowComponent, EditCircleMapComponent]
})
export class EditLocationSurveyModule { }
