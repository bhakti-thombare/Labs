import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCircleMapComponent } from './edit-circle-map.component';

describe('EditCircleMapComponent', () => {
  let component: EditCircleMapComponent;
  let fixture: ComponentFixture<EditCircleMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditCircleMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditCircleMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
