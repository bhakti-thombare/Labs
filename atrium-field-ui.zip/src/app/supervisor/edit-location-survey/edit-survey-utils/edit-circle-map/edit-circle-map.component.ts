// core
import { Component, OnInit, AfterViewInit, Output, EventEmitter, Input, OnChanges } from '@angular/core';

// 3rd party
import { isEmpty } from "underscore";
import * as mapBox from 'mapbox-gl';
import * as mapboxCircle from 'mapbox-gl-circle';

// app
import { DataConstants } from '@app/constants/constants';
import { EventService } from '@services/events/event.service';

declare function require(name: string);
Object.getOwnPropertyDescriptor(mapBox, "accessToken").set(DataConstants.MAPBOX_ACCESS_TOKEN);
@Component({
  selector: 'app-edit-circle-map',
  templateUrl: './edit-circle-map.component.html',
  styleUrls: ['./edit-circle-map.component.css']
})
export class EditCircleMapComponent implements OnInit,OnChanges {
 
  @Output() lngLat = new EventEmitter;
  @Input() disableClick: string;
  @Input() mapObject: any = {};
  firstAssigned: boolean = true;
  map;
  myCircle = new mapboxCircle({ lat: 39.984, lng: -75.343 }, 150, {
    editable: false,
    maxRadius: 150,
    fillColor: '#29AB87'
  });
  marker = new mapBox.Marker();

  constructor(public event: EventService) {
  }
  ngAfterViewInit() {
    // this.mapObject = { 'latitude': 50.84559909325273, 'longitude': 4.348614006026935 };
   this.mapInit();
    this.mapInitalizer();
    this.mapClickListner();
    this.firstAssigned = false;
  
  }

  ngOnInit() {
  }

  sendLatLng(lngLat) {
    this.lngLat.emit(lngLat);
  }
  /* !this.firstAssigned &&  */
  ngOnChanges() { try { if (!this.firstAssigned && !isEmpty(this.mapObject)) { this.mapInitalizer(); } } catch (error) 
  { console.log("Map Error"); } }
  mapInit() {
    this.map = new mapBox.Map({
      container: 'map',
      style: 'mapbox://styles/mapbox/streets-v8',
      center: [4.348614006026935,  50.84559909325273],
      zoom: 16
    });
    this.map.addControl(new mapBox.NavigationControl());
  }

  mapInitalizer() {
    console.log(this.mapObject);
      this.mapObject.latitude = parseFloat(this.mapObject.latitude).toFixed(14);
      this.mapObject.longitude = parseFloat(this.mapObject.longitude).toFixed(14);
      this.marker.setLngLat([parseFloat(this.mapObject.longitude), parseFloat(this.mapObject.latitude)]).addTo(this.map);
      this.map.flyTo({
        center: [parseFloat(this.mapObject.longitude), parseFloat(this.mapObject.latitude)],
        zoom: 16,
        bearing: 0,
        curve: 1
      });
      this.myCircle.setCenter({ lat: parseFloat(this.mapObject.latitude), lng: parseFloat(this.mapObject.longitude) }).setRadius(150).addTo(this.map);
  }
  mapClickListner() {
    this.map.on('click', (e) => {
      if (!this.disableClick) {
        try {
          this.marker.setLngLat([e.lngLat.lng, e.lngLat.lat]).addTo(this.map);
          this.sendLatLng([e.lngLat.lng, e.lngLat.lat]);
          this.myCircle.setCenter({ lat: e.lngLat.lat, lng: e.lngLat.lng }).setRadius(150).addTo(this.map);
          this.map.flyTo({
            center: [e.lngLat.lng, e.lngLat.lat],
            zoom: 16,
            bearing: 1,
            curve: 1
          });
        } catch (error) { console.log('Exception Handled'); }
      }
      console.log(e.lngLat.lng, e.lngLat.lat);
    });
  }

  mapResize() {
    this.map.on('load', (e) => {
      this.map.resize();
    });
  }
}