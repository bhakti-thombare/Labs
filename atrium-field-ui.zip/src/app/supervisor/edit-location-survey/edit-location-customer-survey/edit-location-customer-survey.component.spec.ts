import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCustomerSurveyComponent } from '@app/supervisor/edit-location-survey/edit-location-customer-survey/edit-location-customer-survey.component';

describe('EditCustomerSurveyComponent', () => {
  let component: EditCustomerSurveyComponent;
  let fixture: ComponentFixture<EditCustomerSurveyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditCustomerSurveyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditCustomerSurveyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
