import { Component, OnInit, Output, EventEmitter, ElementRef, ViewChild, Renderer2, Input } from '@angular/core';
import { ApiService } from '@app/services/apiServices/api.service';
import { EventService } from '@app/services/events/event.service';
import { HttpService } from '@app/services/http-service';
import { Location } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { ApiConstants } from '@app/constants/constants';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CreateSurveyUtilsService } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.service';
import { missionTypes, statuses } from '@app/constants/constants';
import {  Router, ActivatedRoute } from '@angular/router';


declare var google: any;

@Component({
  selector: 'app-edit-location-customer-survey',
  templateUrl: './edit-location-customer-survey.component.html',
  styleUrls: ['./edit-location-customer-survey.component.css']
})
export class EditCustomerSurveyComponent implements OnInit {
  
  @Input() survey:string;
  @Output() surveyChange = new EventEmitter();

  xmlHttpUrl = ApiConstants.BASE_URL;

  today = new Date(Date.now());
  model: NgbDateStruct;

  createMissionForm: FormGroup = new FormGroup({
    missionStartDate: new FormControl('', Validators.required),
    missionEndDate: new FormControl('', Validators.required),
    estimatedTimeHourHour: new FormControl('', Validators.required),
    estimatedTimeHourMin: new FormControl('', Validators.required),
    missionName: new FormControl('', Validators.required),
    missionDescription: new FormControl('')
  });

  zoneId;
  morning = true;

  user = JSON.parse(localStorage.getItem('user-data'));
  showSkipInStep1: boolean;
  step1: boolean;
  step2: boolean;
  loaderOn: boolean;
  step3: boolean;
  step4: boolean;
  step1Completed: boolean;
  step2Completed: boolean;
  step3Completed: boolean;
  step4Completed: boolean;
  hideStep1 = false;
  hideStep2 = true;
  hideStep3 = true;
  hideStep4 = true;
  hideStep5 = true;
  pageOpenAllowed: boolean;
  campaignsLoaded: boolean;
  assignmentsLoaded = false;
  existingZonesCheck = false;
  missionsLoaded = false;
  summaryLoaded = false;
  missionTypesLoaded: boolean;
  calendarReady = false;
  selectedMissionType: any;
  missionTypes: any;
  showNewAssignmentBtn = true;
  existingZonesFound = false;
  existingZones = [];
  disableStep1 = false;
  disableStep2 = false;
  disableStep3 = false;
  disableStep4 = false;
  zoneMissionFound = false;
  loadMapForExistingCircuit = false;
  disableMapClick = false;
  datepickers = [];
  fieldAgents = [];
  busyDates = [];
  summaryObj;
  

  prev: number;

  campaigns: [any];

  missions: any;
  tempmissions: any;

  zones: any;

  zoneLoaded = false;

  missionId: string;

  freeUsers = [];

  summary = {
    mission: {},
    zones: [],
    assignments: []
  };

  zoneMissionLoaded = false;
  parent2Toggle;
  mission = {
    selectedCampaign: {
      startDateObj: {},
      endDateObj: {}
    },
    zones: [],
    assignments: [],
    missionStartDate: {
      year: null,
      month: null,
      day: null
    },
    missionEndDate: {
      year: null,
      month: null,
      day: null
    },
    estimatedTimeHour: null,
    estimatedTimeMinutes: null,
    missionName: '',
    missionDescription: ''
  };

  zoneNameDisabled = true;

  rerender = false;

  constructor(public http: HttpClient,
    private route: ActivatedRoute,
    public rd: Renderer2,
    public el: ElementRef,
    public router: Router,
    public event: EventService,
    public _http: HttpService,
    private location: Location,
    public custUtils: CreateSurveyUtilsService,
    public api: ApiService) {
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this._http.pullCountry().subscribe(res => { }, err => { });
    const date = new Date(Date.now());
    const month = date.getMonth() + 1;
    localStorage.removeItem('busyDates');
  }

  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6;
  }

  isDisabled(date: NgbDateStruct, current: { month: number }) {
    const now = new Date(Date.now());
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
    const sdate = new Date(date.year, date.month - 1, date.day);

    if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };

        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  isEndDisabled(date: NgbDateStruct, current: { month: number }) {
    const localDate = JSON.parse(localStorage.getItem('date'));
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const minDate = new Date(localDate.year, localDate.month, localDate.day);
    const campaignStartDate = new Date(startCheck.year, startCheck.month, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month, endCheck.day);
    const sdate = new Date(date.year, date.month, date.day);

    if (sdate >= minDate && sdate >= campaignStartDate && sdate <= campaignEndDate) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };

        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return true;
    }
  }
  
  editZone=true;
  ngOnInit() {
    // this.route.params.subscribe(params => { this.getLocationByName(params.name); });
    this.mission.zones = [];
    this.step1 = true;
    this.prev = 1;
    this.route.params.subscribe(params => { console.log("params=",params);
    if(params.locationId==="003"){
          this.editZone=false;
    }
     this.getLocationDetails(params.name,params.locationId,params.elementId); });
    
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this.getCampaigns();
    this.getMissionTypes();
  }

  classRemover() {
    this.rd.removeClass(this.parent2Toggle.parentNode, 'show');
  }

  classAdder() {
    this.rd.addClass(this.parent2Toggle.parentNode, 'show');
  }

  getLocationDetails(name,id,elementId){

    this.api.getLocationDetails({'locationName':name,'locationType':3,'elementId':elementId})
    .subscribe(res => {
      console.log(name);
      let details= res.data;
      this.mission.zones.push({
        name: name,
        address: details.address,
        lat: details.latitude,
        lng: details.longitude,
        adptId: details.adptId,
        id: details.id,
        locationId: id
      });
      this.mapObject = { latitude: this.mission.zones[0].lat, longitude:  this.mission.zones[0].lng };
    this.event.broadcast({ eventName: 'hideLoader', data: '' });
    }, err => {

    }); 
   
  }

  getCampaigns() {
    this.campaignsLoaded = false;
    this.api.getUserCampaigns(this.user.userId).subscribe(res => {
      this.custUtils.campaignsInitializer(res.data.campaigns, response => {
        if (response.message === 'campaignExpired') {
          this.custUtils.translateMessageObject({
            title: 'Campaign expired.',
            text: 'Please contact admin for more campaigns.',
            type: 'warning',
            outsideClick: true,
            showCancelBtn: false,
            confirmBtnText: 'OK',
            cancelBtnText: ''
          }, (responseMessageObject) => {
            this.custUtils.translateAndPop(responseMessageObject).then(() => {
              this.location.back();
            }).catch(() => {
              this.location.back();
            });
          });
        } else if (response.message === 'success') {
          this.campaigns = response.campaigns;
          this.mission.selectedCampaign = this.campaigns[0];
          localStorage.setItem('campaignStartDate', JSON.stringify(this.mission.selectedCampaign.startDateObj));
          localStorage.setItem('campaignEndDate', JSON.stringify(this.mission.selectedCampaign.endDateObj));
          this.campaigns.splice(0, 1);
          this.campaignsLoaded = true;
        }
      });
    }, err => { });
  }

  getMissions(cb) {
    this.api.getMissionsCreatedByOfMissionType(this.user.userId, missionTypes.CUSTOMER_SURVEY_TYPE_ID).subscribe(res => {
      this.tempmissions = res.data.missions;
      this.custUtils.skipCalculator(res.data.missions, (missions, bool) => {
        this.missions = missions; // missions without zones
        this.missionsLoaded = true;
        if (bool) {
          this.showSkipInStep1 = true;
        } else {
          this.showSkipInStep1 = false;
        }
        cb();
      });
    }, err => {
      this.showSkipInStep1 = false;
      cb();
    });
  }

  getZones(cb) {
    this.api.getZones().subscribe(res => {
      let zonesLength = res.data.zones.length;
      if (res.data.zones.length !== 0) {
        res.data.zones.forEach(zone => {
          this.existingZones.push(zone);
          zonesLength--;
          if (zonesLength === 0) {
            if (this.existingZones.length !== 0) {
              this.existingZonesFound = true;
            }
            this.zoneObjectCreator(() => {
              cb();
            });
          }
        });
      }
    }, err => {
      this.existingZonesFound = false;
      this.zoneObjectCreator(() => {
        cb();
      });
    });
  }

  zoneObjectCreator(cb) {
    this.mission.zones = [];
    this.mission.zones.push({
      name: undefined,
      address: undefined,
      lat: null,
      lng: null,
      adptId: null,
      existingZonesCheck: false,
      existingZones: [],
      selectedZone: {},
      missions: [],
      selectedMission: {}
    });
    if (this.missions !== undefined) {
      if (this.missions.length === 0) {
        cb();
      } else {
        let noZoneMissionLength = this.missions.length;
        this.missions.forEach(mission => {
          this.mission.zones[0].missions.push(mission);
          noZoneMissionLength--;
          if (noZoneMissionLength === 0) {
            this.mission.zones[0].selectedMission = this.mission.zones[0].missions[0];
            this.zoneMissionLoaded = true;
            this.mission.zones[0].missions.splice(0, 1);
            cb();
          }
        });
      }
    } else {
      cb();
    }
  }

  toggleCheckBox(i, event) {
    if (event.target.checked !== this.mission.zones[i].existingZonesCheck) {
      this.mission.zones[i].existingZonesCheck = event.target.checked;
    }
    if (this.mission.zones[i].existingZonesCheck) {
      this.existingZonesCheck = true;
      this.existingZoneMapFiller(i);
      this.disableMapClick = true;
    } else {
      this.mapObject = { 'latitude': 50.84559909325273, 'longitude': 4.348614006026935 };
      this.existingZonesCheck = false;
      this.mission.zones[i].name = undefined;
      this.mission.zones[i].address = undefined;
      this.mission.zones[i].lat = null;
      this.mission.zones[i].lng = null;
      this.mission.zones[i].adptId = null;
      this.zoneNameDisabled = true;
      this.disableMapClick = false;
    }
  }
  mapObject: any = {}
  existingZoneMapFiller(i) {
    if (this.existingZones.length !== 0) {
      this.mission.zones[i].existingZones = [];
      let existingZoneLength = this.existingZones.length;
      this.existingZones.forEach(zone => {
        this.mission.zones[i].existingZones.push(zone);
        existingZoneLength--;
        if (existingZoneLength === 0) {
          this.mission.zones[i].selectedZone = this.mission.zones[i].existingZones[0];
          this.mission.zones[i].existingZones.splice(0, 1);
          this.mapObject = { 'longitude': this.mission.zones[i].selectedZone.longitude, 'latitude': this.mission.zones[i].selectedZone.latitude };
          // this.event.broadcast({ eventName: 'existing-zone-selected', data: this.mission.zones[i].selectedZone.longitude + ',' + this.mission.zones[i].selectedZone.latitude + ',' + 'map0' });
        }
      });
    }
  }

  getMissionTypes() {
    this.missionTypesLoaded = false;
    this.missionTypes = [];

    this.api.getMissionTypes().subscribe(res => {
      let typeLen = res.data.length;
      res.data.forEach(type => {
        if (type.id === 3 || type.id === 4) {
          this.missionTypes.push(type);
        }
        typeLen--;
        if (typeLen === 0) {
          if (this.missionTypes[0].id === 4) {
            this.selectedMissionType = this.missionTypes[0];
            this.missionTypes.splice(0, 1);
          } else {
            this.selectedMissionType = this.missionTypes[1];
            this.missionTypes.splice(1, 1);
          }
          this.missionTypesLoaded = true;
        }
      });
    }, err => {
      console.log('err', err);
    });
  }
  /**
   * Get address by Lat and long for create survey
   * 
   **/
  getLngLat(e) {
      const api = new google.maps.Geocoder;
    // this.mapObject = { 'longitude': e[0], 'latitude': e[1] }; 
    this.mission.zones[0].lng = e[0];
        this.mission.zones[0].lat = e[1];
        this.mission.zones[0].name = this.mission.zones[0].name;
        this.mission.zones[0].adptId = this.mission.zones[0].adptId;
        this.zoneNameDisabled = false;
        api.geocode({ latLng: { lat: e[1], lng: e[0] } },
            res => { if (res) this.mission.zones[0].address = res[0].formatted_address; }, err => err);
    }

  surveySelection(surveyId) {
    this.surveyChange.emit(surveyId);
  }

  instanceForCampaign(d1) {
    this.datepickers.push(d1);
  }

  toggleCampaign(camp) {
    this.datepickers.forEach(datePicker => {
      datePicker.close();
    });
    this.mission.missionStartDate = {
      year: null,
      month: null,
      day: null
    };
    this.mission.missionEndDate = {
      year: null,
      month: null,
      day: null
    };
    this.campaigns.push(this.mission.selectedCampaign);
    this.mission.selectedCampaign = camp;
    const campStart = camp.campaignStartDate.split(' ')[0];
    localStorage.setItem('campaignStartDate', JSON.stringify({
      day: parseInt(campStart.split('-')[2], 10),
      month: parseInt(campStart.split('-')[1], 10),
      year: parseInt(campStart.split('-')[0], 10)
    }));
    const campEnd = camp.campaignEndDate.split(' ')[0];
    localStorage.setItem('campaignEndDate', JSON.stringify({
      day: parseInt(campEnd.split('-')[2], 10),
      month: parseInt(campEnd.split('-')[1], 10),
      year: parseInt(campEnd.split('-')[0], 10)
    }));
    let removeIndex: number;
    this.campaigns.forEach((campaign, i) => {
      if (campaign === camp) {
        removeIndex = i;
      }
    });
    this.campaigns.splice(removeIndex, 1);
  }

  saveAndOpen() {
      this.validateZone(() => {
        this.createZone();
      })
  }

  validateMission(form, cb) {
    if (form.value.nameOfMission !== '' && form.value.startDateMission.day !== null) {
      cb();
    } else {
      this.custUtils.translateMessageObject({
        title: 'All fields are mandatory',
        text: 'Date and name of the mission are required.',
        type: 'error',
        outsideClick: true,
        showCancelBtn: false,
        confirmBtnText: 'OK',
        cancelBtnText: ''
      }, (responseMessageObject) => {
        this.custUtils.translateAndPop(responseMessageObject).then(() => {

        }).catch(() => {

        });
      });
    }
  }

  createMission(formData) {
    this.disableStep1 = true;
    if (!this.step1Completed) {
      const startDate = this.mission.missionStartDate.year + '-' +
        formData.value.startDateMission.month + '-' + formData.value.startDateMission.day + ' ' + '00:00:00';
      const endDate = formData.value.startDateMission.year + '-' +
        formData.value.startDateMission.month + '-' +
        formData.value.startDateMission.day + ' ' + '00:00:00';
      const now = Date.now();
      const creationDate = new Date(now);
      const nowYear = creationDate.getFullYear();
      const nowMonth = creationDate.getMonth() + 1;
      const nowDay = creationDate.getDate();
      const nowInReq = nowYear + '-' + nowMonth + '-' + nowDay + ' ' + '00:00:00';
      const estimatedTime = (parseInt('10', 10) * 60) + parseInt('10', 10);

      const reqObj = {
        missionName: formData.value.nameOfMission,
        missionDescription: formData.value.missionDesc,
        missionTypeId: this.selectedMissionType['id'],
        missionCreationDate: nowInReq.toString(),
        missionStartDate: startDate.toString(),
        missionEndDate: endDate.toString(),
        missionCampaignId: this.mission.selectedCampaign['campaignId'],
        missionCreatedById: this.user.userId,
        missionEstimatedTime: estimatedTime,
        missionStatusId: statuses.YETTOASSIGN
      };

      this._http.SecurePost('/mission/addMission', reqObj).subscribe(res => {
        this.missionId = res.responseMessage.split('! ')[1];
        this.custUtils.translateMessageObject({
          title: 'Mission created successfully',
          text: 'Please create zone for this mission',
          type: 'success',
          cancelBtnText: '',
          confirmBtnText: 'OK',
          outsideClick: false,
          showCancelBtn: false
        }, res => {
          this.custUtils.translateAndPop(res).then(() => {
            this.pageOpenAllowed = true;
            this.step1Completed = true;
            this.getMissions(() => {
              this.disableStep1 = false;
              this.open(2);
            });
          }).catch(() => {

          });
        });
      }, err => {
        console.log(err._body);
      });
    }
  }

  open(page) {
    if ((page === 2 && this.prev === 1 && this.pageOpenAllowed) || (page === 2 && this.step2)) {
      this.step2 = true;
      if (this.prev === 1 && !this.step2Completed) {
        if (this.mission.zones.length === 0) {
          this.zoneObjectCreator(() => {

          });
        } else {
          this.zoneObjectUpdater(() => {

          });
        }
      }
      this.prev = 2;
      this.hideStep1 = true;
      this.hideStep3 = true;
      this.hideStep4 = true;
      this.hideStep5 = true;
      this.hideStep2 = false;
      this.pageOpenAllowed = false;
      this.event.broadcast({ eventName: 'circle-map-loaded', data: '' });
    } else if ((page === 3 && this.prev === 2 && this.pageOpenAllowed) || (page === 3 && this.step3)) {
      this.step3 = true;
      if (this.prev === 2) {
        if (this.mission.assignments.length === 0) {
          this.assignmentObjectCreator();
        }
      }
      this.prev = 3;
      this.hideStep1 = true;
      this.hideStep3 = false;
      this.hideStep4 = true;
      this.hideStep5 = true;
      this.hideStep2 = true;
      this.pageOpenAllowed = false;
    } else if (page === 1 && this.step1 && this.pageOpenAllowed) {
      this.step1 = true;
      this.prev = 1;
      this.hideStep2 = true;
      this.hideStep3 = true;
      this.hideStep4 = true;
      this.hideStep5 = true;
      this.hideStep1 = false;
      this.pageOpenAllowed = false;
    } else if (page === 4 && this.prev === 3 && this.pageOpenAllowed) {
      this.step4 = true;
      if (this.prev === 3) {
        this.summaryCreator();
      }
      this.prev = 4;
      this.hideStep2 = true;
      this.hideStep3 = true;
      this.hideStep4 = false;
      this.hideStep1 = true;
      this.pageOpenAllowed = false;
    }
  }

  summaryCreator() {
    this.summaryLoaded = false;
    this.summaryObj = {
      mission: this.mission.zones[0].selectedMission,
      zone: this.mission.zones[0],
      assignment: this.mission.assignments[0],
    }
    console.log(this.summaryObj);
    setTimeout(() => {
      this.summaryLoaded = true;
      this.event.broadcast({ eventName: 'circle-map-loaded', data: '' });
    }, 500);
    setTimeout(() => {
      this.event.broadcast({ eventName: 'existing-zone-selected', data: this.summaryObj.zone.lng + ',' + this.summaryObj.zone.lat + ',' + 'map1' });
    }, 700);
  }

  zoneObjectUpdater(cb) {
    if (this.step1Completed) {
      this._http.SecureGet('/ref/getAllMissions?id=' + this.missionId).subscribe(res => {
        console.log(this.mission.zones);
        this.mission.zones.forEach(zone => {
          zone.selectedMission = res.data.missions[0];
          this.zoneMissionFound = true;
        });
      });
    }
  }

  validateZone(cb) {
    const zone = this.mission.zones[0];
    if (zone.existingZonesCheck) {
      cb();
    } else {
      console.log('Zone', zone);
      if (zone.name !== undefined && zone.name !== '' && zone.address !== undefined && zone.address !== '' && zone.adptId !== null && zone.adptId !== '' && zone.lat !== null && zone.lng !== null) {
        cb();
      } else {
        this.custUtils.translateMessageObject({
          title: 'All fields are mandatory',
          text: 'Please click on an area on Map for the latitude and longitude.',
          type: 'warning',
          cancelBtnText: '',
          confirmBtnText: 'OK',
          outsideClick: false,
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
            console.log('hha');
          }).catch(() => {
            console.log('hha');
          });
        });
      }
    }
  }

  createZone() {
    this.disableStep2 = true;
    const zone = this.mission.zones[0];
      const reqObj = {
        zoneId : zone.id,
        locationTypeId : 3,
        locationId: zone.locationId,
        zoneCreatedBy: this.user.userId,
        zoneUpdatedBy: this.user.userId,
        zoneAdptId: zone.adptId,
        zoneName: zone.name,
        zoneLatitude: zone.lat,
        zoneLongitutde: zone.lng,
        zoneAddress: zone.address
      };
      this.createAndMapZoneWithMission(reqObj);
  }

  gotoCancel(event){
   
    this.router.navigate([`/supervisor/location`]);
  }
  
  createAndMapZoneWithMission(req) {
    let zoneName = req.zoneName;
    this.api.createZone(req).subscribe(res => {
      this.zoneId = res.responseMessage.split('! ')[2];
      this.custUtils.translateMessageObject({
        title: 'Zone updated successfully',
        text: '',
        type: 'success',
        outsideClick: true,
        cancelBtnText: '',
        confirmBtnText: 'Ok',
        showCancelBtn: false
      }, message => {
        this.custUtils.translateAndPop(message).then(() => {
          this.pageOpenAllowed = true;
          this.step2Completed = true;
          this.disableStep3 = false;
          this.disableMapClick = true;
          this.router.navigate([`/supervisor/location`]);
        }).catch(() => {
          this.pageOpenAllowed = true;
          this.step2Completed = true;
          this.disableStep3 = false;
          this.disableMapClick = true;
        });
      });
    }, err => {
      let response = JSON.parse(err._body);
      if (response.responseMessage === undefined) {
        this.custUtils.translateMessageObject({
          title: 'Something went wrong',
          text: 'Zone not created please try again',
          type: 'error',
          outsideClick: true,
          cancelBtnText: '',
          confirmBtnText: 'Ok',
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
            this.disableStep2 = false;
          }).catch(() => {
            this.disableStep2 = false;
          });
        });
      }
    });
  }

  toggleExistingZone(zone, i, e) {
    this.mapObject = { 'longitude': zone.longitude, 'latitude': zone.latitude };
    this.mission.zones[i].existingZones.push(this.mission.zones[i].selectedZone);
    this.mission.zones[i].existingZones.splice(e, 1);
    this.mission.zones[i].selectedZone = zone;
    this.event.broadcast({ eventName: 'existing-zone-selected', data: this.mission.zones[i].selectedZone.longitude + ',' + this.mission.zones[i].selectedZone.latitude + ',' + 'map0' });
  }

  searchExistingZoneName(value, i) {
    if (!value) {
      this.mission.zones[i].existingZones = Object.assign([], this.existingZones).filter(item => {
        if (this.mission.zones[i].selectedZone.name !== item.name) {
          return item;
        }
      });
    } else {
      this.mission.zones[i].existingZones = Object.assign([], this.existingZones).filter(
        item => {
          if (this.mission.zones[i].selectedZone.name !== item.name) {
            return item.name.toLowerCase().indexOf(value.toLowerCase()) > -1;
          }
        }
      );
    }
  }

  changeShiftId(id) {
    if (id === 1) {
      this.morning = true;
    } else {
      this.morning = false;
    }
  }


  assignmentObjectCreator() {
    this.mission.assignments = [];
    this.api.getZone(this.zoneId).subscribe(res => {
      const obj = {
        selectedZone: res.data.zones[0],
        selectedFieldAgent: {},
        fieldAgents: [],
        tempFieldAgents: [],
        shiftTimings: [
          {
            first: '08:45',
            second: '13:00'
          },
          {
            first: '13:00',
            second: '17:15'
          }
        ]
      };
      this.assignmentFieldAgentsFiller(obj, (freeUsers) => {
        obj.fieldAgents = freeUsers;
        obj.tempFieldAgents = freeUsers;
        obj.selectedFieldAgent = obj.fieldAgents[0];
        obj.fieldAgents.splice(0, 1);
        this.mission.assignments.push(obj);
        this.assignmentsLoaded = true;
      });
    }, err => {

    });

  }

  assignmentFieldAgentsFiller(assignment, cb) {
    console.log('this.mission.zones[0].selectedMission.missionStartDate', this.mission.zones[0].selectedMission.missionStartDate);
    this.api.getUnassignedUsers({
      startDate: this.mission.zones[0].selectedMission.missionStartDate.split(' ')[0],
      missionId: this.mission.zones[0].selectedMission.missionId
    }).subscribe(res => {
      cb(res.users);
    }, err => {
      this.custUtils.translateMessageObject({
        title: 'No Field agents available',
        text: 'Please change the mission date or ask admin to add more field agents.',
        type: 'warning',
        cancelBtnText: '',
        confirmBtnText: 'OK',
        outsideClick: false,
        showCancelBtn: false
      }, message => {
        this.custUtils.translateAndPop(message).then(() => {
          this.location.back();
        }).catch(() => {
          this.location.back();
        });
      });
    });
  }

  checkAndOpen(page) { // on click of wizard this fuction decides if allow access can go to utils
    if ((page === 1 && this.step1) || (page === 2 && this.step2) ||
      (page === 3 && this.step3) || (page === 4 && this.step4)) {
      this.pageOpenAllowed = true;
    }
    if (page === 1 && this.step2) {
      if (!this.step2Completed && !this.step1Completed) {
        // this.pageOpenAllowed = true;
        // this.step1 = true;
      } else if (this.step2Completed && this.step1Completed) {
        this.pageOpenAllowed = true;
        this.step1 = true;
      } else if (this.step1Completed && !this.step2Completed) {
        this.pageOpenAllowed = true;
        this.step1 = true;
      } else {
        this.pageOpenAllowed = false;
        this.step1 = false;
      }
    } else if (page === 2 && this.step3) {

    } else if (page === 3) {
      if (this.step3Completed) {

      }
    }
    this.open(page);
  }

  toggleMission(mission, i) {
    console.log(mission, i);
    let deleteIndex;
    this.mission.zones[i].missions.push(this.mission.zones[i].selectedMission);
    let zoneMissionLength = this.mission.zones[i].missions.length;
    this.mission.zones[i].missions.forEach((miss, del) => {
      if (miss.missionId === mission.missionId) {
        deleteIndex = del;
      }
      zoneMissionLength--;
      if (zoneMissionLength === 0) {
        this.mission.zones[i].missions.splice(deleteIndex, 1);
        this.mission.zones[i].selectedMission = mission;
      }
    });
  }

  toggleFieldAgent(fa, i) {
    let deleteIndex;
    this.mission.assignments[0].fieldAgents.push(this.mission.assignments[0].selectedFieldAgent);
    this.mission.assignments[0].selectedFieldAgent = fa;
    let faLength = this.mission.assignments[0].fieldAgents.length;
    this.mission.assignments[0].fieldAgents.forEach((fieldAgent, delI) => {
      if (fa.userId === fieldAgent.userId) {
        deleteIndex = delI;
      }
      faLength--;
      if (faLength === 0) {
        this.mission.assignments[0].fieldAgents.splice(deleteIndex, 1);
      }
    });
  }

  validateAssignment(cb) {
    if (this.assignmentsLoaded) {
      cb();
    }
  }

  createAssignment() {
    this.disableStep3 = true;
    const requestAssignmentObject = {
      assignments: []
    };
    const sendAssignment = (i) => {
      const reqObj = {
        userId: this.mission.assignments[0].selectedFieldAgent.userId,
        campaignId: this.mission.zones[0].selectedMission.missionCampaign.campaignId,
        missionId: this.missionId ? this.missionId : this.mission.zones[0].selectedMission.missionId,
        zone: this.mission.assignments[0].selectedZone.id,
        createdBy: this.user.userId,
        updatedBy: this.user.userId,
        shiftId: i + 1,
        startDate: this.mission.zones[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + this.mission.assignments[0].shiftTimings[i].first + ':00',
        endDate: this.mission.zones[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + this.mission.assignments[0].shiftTimings[i].second + ':00',
      };
      reqObj.missionId = parseInt(reqObj.missionId, 10);
      requestAssignmentObject.assignments.push(reqObj);
      if (i >= 1) {
        this.api.assignCustomerSurvey(requestAssignmentObject).subscribe(res => {
          this.custUtils.translateMessageObject({
            title: 'Assignments created successfully',
            text: '',
            type: 'success',
            cancelBtnText: '',
            confirmBtnText: 'OK',
            outsideClick: false,
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.pageOpenAllowed = true;
              this.step3Completed = true;
              this.disableStep4 = false;
              this.open(4);
            }).catch(() => {
              this.pageOpenAllowed = true;
              this.step3Completed = true;
              this.disableStep4 = false;
              this.open(4);
            });
          });
        }, err => {
          this.custUtils.translateMessageObject({
            title: 'Assignments were not successful',
            text: 'Please try again',
            type: 'error',
            cancelBtnText: '',
            confirmBtnText: 'OK',
            outsideClick: false,
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.disableStep3 = false;
            }).catch(() => {
              this.disableStep3 = false;
            });
          });
        });
      } else {
        i++;
        sendAssignment(i);
      }
    };
    sendAssignment(0);
  }



}
