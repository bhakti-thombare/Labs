import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPedestrianFlowComponent } from './pedestrian-flow.component';

describe('PedestrianFlowComponent', () => {
  let component: EditPedestrianFlowComponent;
  let fixture: ComponentFixture<EditPedestrianFlowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditPedestrianFlowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPedestrianFlowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
