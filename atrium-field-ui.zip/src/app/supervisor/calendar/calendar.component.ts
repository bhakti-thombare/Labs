// import { loaderComponent } from '@app/loader/loader.component';
import { KmlLayerManager } from '@agm/core';
import {
  Component, ViewChild, OnInit, ElementRef, Renderer2, Input, Output, EventEmitter
} from '@angular/core';
import { statuses, Globals, missionTypes } from '@app/constants/constants';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '@app/services/apiServices/api.service';
import { ModalDismissReasons, NgbDateStruct, NgbInputDatepicker, NgbModal, NgbPopover, NgbPopoverConfig } from '@ng-bootstrap/ng-bootstrap';
import { exit } from 'process';
import { Subscription } from 'rxjs';
import { CreateSurveyUtilsService } from '../create-survey/createSurveyUtils/create-survey-utils.service';
import { Location } from '@angular/common';
import { EventService } from '@app/services/events/event.service';
import { StorageService } from '@app/services/storage-service.service';
import { UTILS } from '@app/services/global-utility.service';
import { map } from 'underscore';
import { CustomerSurveyAlertsService } from '@app/services/Alerts/customer-survey-alerts.service';
import { UnassignedUsersPos } from '@app/services/apiServices/reqBodies';
import { FormGroup } from '@angular/forms';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css']
})
export class CalendarComponent implements OnInit {

  @ViewChild("d3") input: NgbInputDatepicker;
  @ViewChild('surveySelectionModal') private surveySelectionModal;
  
  @ViewChild('myRangeInput') myRangeInput: ElementRef;
  today1: NgbDateStruct;
  getYear: any;
  current = new Date(Date.now());
  now = new Date(Date.now());
  date1 = new Date(2011, 2, 3);
  n: any;
  n1: any;
  private subscriptions: Subscription[] = [];
  agent = [];
  allAgents: Array<any> = [];
  reasonList: Array<any> = [];
  list = [
      { id: 1, name: 'Holidays' },
      { id: 2, name: 'Sickness' },
      { id: 3, name: 'Non Field mission' },
      { id: 4, name: 'Formation' },
      { id: 4, name: 'Other' }
  ];
  list1 = [
    { id: 1, name: 'Holidays' },
    { id: 2, name: 'Sickness' },
    { id: 3, name: 'Non Field mission' },
    { id: 4, name: 'Formation' },
    { id: 4, name: 'Other' }
];
  agents: Array<any> = [];
  agentInfo: Array<any> = [];
  weekInfo: Array<any> = [];
  startDate: any;
  endDate: any;
  first: any;
  last: any;
  firstday: Date;
  lastday: Date;
  calendarInfo1: Array<any> = [];
  today = this.current.getDate();
  missionTypeId: number;
  shift: any;
  day: any;
  leave: Array<any> = [];
  onLeave: boolean;
  totalagent: any;
  amCount: number = 0;
  pmCount: number = 0;
  totalAm: number;
  totalPm: number;
  dayCount: Array<any> = [];
  numberOfDays: Array<any> = [];
  loader: boolean = true;
  flag: boolean = false;
  count: any;
  currentMonthFlag = 1;

  p: any;
  clock: any;
  toolmissionType: any;
  toolmissionSubType: any;
  toolmissionName: any;
  toolcampaignName: any;
  toolsupervisor: any;
  getweekData: any = [];
  todayDateForhighLight: any = new Date();
  modal;
  closeResult: string;
  userID;
  campaignsLoaded: boolean;
  campaigns: any;
  //@ViewChild('') popup: NgbPopover;
  mission = {
    selectedCampaign: {
      startDateObj: {},
      endDateObj: {}
    },
    missionStartDate: {
      year: null,
      month: null,
      day: null
    },
    missionEndDate: {
      year: null,
      month: null,
      day: null
    },
    estimatedTimeHour: null,
    estimatedTimeMinutes: null,
    nextDay: []
  };
  missionTypes: any[];
  selectedMissionType: any;
  selectedShiftChange: any;
  currentUser: any = JSON.parse(localStorage.getItem('user-data'));
  addClick: boolean = true;
  removeClick: boolean = false;
  fieldName: string;
  selectedFieldAgent: any = null;
  optionsAgents: any = [];
  step3Form: FormGroup;
  configAgents: { displayKey: string; search: boolean; placeholder: any; multiple: boolean; };
  minDate: { year: number; month: number; day: number; };
  maxDate: { year: number; month: number; day: number; };
  fullDay: boolean = false;
  afternoon: boolean = false;
  useDate: any = undefined;
  useDate1: any = undefined;
  configReason: { displayKey: string; search: boolean; placeholder: any; multiple: boolean; };
  morning1: boolean = false;
  fullDay1: boolean = false;
  afternoon1: boolean = false;
  selectedReason: any = null;
  message: string;
  add: boolean = false;
  today2: NgbDateStruct;
  selectedAgent: any;
  selectedShift1: string="";
  selectedShift2: string="";
  leavesArray: any;
  isStartDate: any;
  minEndDateDisable: any;
  minEndDate: any;
  getUnavailableDateDate=[];
  disabledDates=[];
  isEndDate:any;
  flagok: boolean=false;
  message1: string=null;
  parsed: string;
  fromDate: any;
  toDate: any;
  remove: boolean=false;
  startDateclicked: boolean = false;
  endDateclicked: boolean = false;
  missionEndDate: any;
  data: any = null;

  constructor(
    public router: Router,
    public event: EventService,
    public apiService: ApiService,
    public modalService: NgbModal,
    public route: ActivatedRoute,
    public custAlerts: CustomerSurveyAlertsService,
    private location: Location,
    private storageService: StorageService,
    public custUtils: CreateSurveyUtilsService,
    private translate: TranslateService,
    private renderer: Renderer2
  ) {
    this.getYear = this.current.getFullYear();
    this.n = this.getMonthData(this.current.getMonth(), 0);
    // this.list = [
    //   { id: 1, name: this.translate.instant('Holidays') },
    //   { id: 2, name: this.translate.instant('Sickness') },
    //   { id: 3, name: this.translate.instant('Non Field mission') },
    //   { id: 4, name: this.translate.instant('Formation') },
    //   { id: 5, name: this.translate.instant('Other') },
    // ];
  }
  ngOnInit(): void {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
    localStorage.removeItem('selectedFieldAgent');
    this.configAgents = {
      displayKey: 'fullname',
      search: true,
      placeholder: this.translate.instant('Select agent'),
      multiple: false
    };
    this.configReason = {
      displayKey: this.translate.instant('name'),
      search: true,
      placeholder: this.translate.instant('Select reason'),
      multiple: false
    };
    let date = new Date();
    this.today1 = { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() };
    this.getCampaigns(this.currentUser.userId);
    this.getMissionTypes();
    this.todayDateForhighLight = this.convert(this.todayDateForhighLight);
    this.getUnavailableUser();
    this.getAllAgents();
    // this.getMissionType();
  }

  getCampaigns(id) {
    this.campaignsLoaded = false;
    this.apiService.getUserCampaigns(id).subscribe(res => {
      console.log(res.data.campaigns);
      this.custUtils.campaignsInitializer(res.data.campaigns, response => {
        if (response.message === 'campaignExpired') {
          this.custUtils.translateMessageObject({
            title: 'Campaign expired.',
            text: 'Please contact admin for more campaigns.',
            type: 'warning',
            outsideClick: true,
            showCancelBtn: false,
            confirmBtnText: 'OK',
            cancelBtnText: ''
          }, (responseMessageObject) => {
            this.custUtils.translateAndPop(responseMessageObject).then(() => {
              // this.location.back();
            }).catch(() => {
              // this.location.back();
            });
          });
        } else if (response.message === 'success') {
          this.campaigns = response.campaigns;
          this.mission.selectedCampaign = this.campaigns[0];
          localStorage.setItem('campaignStartDate', JSON.stringify(this.mission.selectedCampaign.startDateObj));
          localStorage.setItem('campaignEndDate', JSON.stringify(this.mission.selectedCampaign.endDateObj));
          this.campaigns.splice(0, 1);
          this.campaignsLoaded = true;
        }
      });
    }, err => { });
  }

  getMissionTypes() {
    this.missionTypes = [];
    this.apiService.getMissionTypes().subscribe(res => {
      let typeLen = res.data.length;
      res.data.forEach(type => {
        if (type.id === 3 || type.id === 4 || type.id === 2) {
          if (type.id === 3) {
            type.name = 'Pedestrian Flow';
            this.missionTypes.push(type);
          }
          else this.missionTypes.push(type);
        }
        typeLen--;
        if (typeLen === 0) {
          this.selectedMissionType = this.missionTypes[0];
          this.missionTypes.splice(0, 1);
          this.event.broadcast({ eventName: 'hideLoader', data: '' });
          // this.changeSurveyModal(this.surveySelectionModal);
        }
      });
    }, err => {
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
    });
  }

  disableSave(flag) {
    if(flag=='true'){
    if (this.selectedFieldAgent == null || (this.morning !== true &&
      this.afternoon !== true && this.fullDay !== true) || this.useDate == undefined || this.selectedReason == null || this.checkDates()) {
      return true;
    }
    return false;
  }
  else{
    if (this.selectedFieldAgent == null || this.useDate == undefined || this.missiondates == undefined || this.checkDates()) {
      return true;
    }
    return false;
  }
  }

  checkDates() {
    if (this.useDate !== undefined && this.missiondates !== undefined) {
      if (new Date(this.useDate) <= new Date(this.missiondates)) return false;
      else {
        this.message = 'Enddate should be greater than Startdate';
        return true;
      }
    }
  }
  gotoClose() {
    this.missionEndDate=undefined;
    this.missionStartDate=undefined;
    this.morning = false;
    this.afternoon = false;
    this.fullDay = false;
    this.morning1 = false;
    this.afternoon1 = false;
    this.fullDay1 = false;
    this.selectedReason = null;
    this.showDate= [];
    this.message1 = null;
    this.remove=false;
    this.useDate= undefined;
    this.selectedFieldAgent=null;
    this.missiondates =undefined
    this.modal.close();
    this.router.navigate([`/supervisor/calendar`]);
    //this.location.back();
  }

  openPopUp() {

  }

  getMonday(d) {
    d = new Date(d);
    var day = d.getDay(),
      diff = d.getDate() - day + (day == 0 ? -6 : 1); // adjust when day is sunday
    return new Date(d.setDate(diff));
  }

  getUnavailableUser() {
    this.subscriptions.push(this.apiService.getUnavailableUser({}).subscribe(res => {
      this.leave = res.data;
      console.log("Unavailability", this.leave);
      return this.leave;
    }, err =>{
      this.leave = [];
      return this.leave;
    }));
  }

  convert(str) {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  convert1(str) {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    return [day, mnth , date.getFullYear()].join("/");
  }

  calendarInfo;
  getCalendarInfo(firstday, lastday) {
    this.agents = [];
    this.agentInfo.forEach(element => {
      this.agents.push(
        { name: element.name, id: element.id }
      );
    });
    this.agentInfo = [];
    this.agentInfo = this.agents;

    this.loader = true;
    this.subscriptions.push(this.apiService.getCalendarInfo({ startDate: firstday, endDate: lastday }).subscribe(res => {
      this.loader = false;
      this.weekInfo = res.data.calendarInfo;
      this.totalagent = res.data.totalAgents;
      let hi; let first1;
      for (let index = 1; index <= 7; index++) {
        first1 = firstday;
        this.day = 'Day' + index;
        hi = this.weekInfo[first1];
        if (first1 && hi) {
          console.log(this.agentInfo);
          this.agentInfo.forEach((kay, index) => {
            if (hi[kay.id]) {
              kay.info = (hi[kay.id]);
              kay[this.day] = (hi[kay.id]);
            }
            else if (kay[this.day]) {
              delete kay[this.day];
            }
            if (kay[this.day]) {
              if (kay[this.day].length > 1) {
                if (kay[this.day][0].shift == 'AM' || kay[this.day][1].shift == 'AM') {
                  this.amCount += 1;
                  if (kay[this.day][0].missionType == "Pedestrian Flow Survey" || kay[this.day][1].missionType == "Pedestrian Flow Survey") {
                    this.pmCount += 1;
                  }
                }
                if (kay[this.day][0].shift == 'PM' || kay[this.day][1].shift == 'PM') {
                  this.pmCount += 1;
                  if (kay[this.day][0].missionType == "Pedestrian Flow Survey" || kay[this.day][1].missionType == "Pedestrian Flow Survey") {
                    this.amCount += 1;
                  }
                }
              }
              else {
                if (kay[this.day][0].shift == 'AM') {
                  this.amCount += 1;
                  if (kay[this.day][0].missionType == "Pedestrian Flow Survey") {
                    this.pmCount += 1;
                  }
                }
                else if (kay[this.day][0].shift == 'PM') {
                  this.pmCount += 1;
                  if (kay[this.day][0].missionType == "Pedestrian Flow Survey") {
                    this.amCount += 1;
                  }
                }
              }
            }
            if (this.leave[kay.id]) {
              this.leave[kay.id].forEach(res => {
                if (res.date == first1) {
                  if (kay[this.day]) {
                    this.onLeave = true;
                    //kay[this.day].onLeave = this.onLeave;
                    //kay[this.day].shiftAllocation = res.shift;
                    kay[this.day].push({ onLeave: this.onLeave, shiftAllocation: res.shift });
                  }
                  else {
                    this.onLeave = true;
                    kay[this.day] = [{ onLeave: this.onLeave, shiftAllocation: res.shift }];
                  }
                }
              });
            }
          });
        }
        else {
          this.agentInfo.forEach(res => {
            let id = res.id;
            if (this.leave[id]) {
              this.leave[id].forEach(lev => {
                if (lev.date == first1) {
                  this.onLeave = true;
                  res[this.day] = [{ onLeave: this.onLeave, shiftAllocation: lev.shift }];
                }
              });
            }
          });
        }
        this.dayCount[this.day] = ({ 'amCount': this.amCount, 'pmCount': this.pmCount });
        this.dayCount['totalagent'] = this.totalagent;
        this.amCount = 0;
        this.pmCount = 0;
        firstday = new Date(firstday);
        firstday = this.convert(new Date(firstday.setDate(firstday.getDate() - firstday.getDay() + index + 1)));
      }
      // console.log(this.agentInfo,this.dayCount);
    }, err => {
      for (let day in this.dayCount) {
        if (day == 'Day1' || day == 'Day2' || day == 'Day3' || day == 'Day4' || day == 'Day5' || day == 'Day6' || day == 'Day7') {
          this.dayCount[day].amCount = 0;
          this.dayCount[day].pmCount = 0;
        }
      }
      console.log(this.agentInfo);
      this.agents = [];
      //this.dayCount['totalagent'] =0;
      this.agentInfo.forEach(element => {
        this.agents.push(
          { name: element.name, id: element.id }
        );
      });
      console.log(this.agents);
      this.dayCount['totalagent'] = this.agents.length;
      this.agentInfo = [];
      this.agentInfo = this.agents;
      console.log(this.agentInfo);
      let first1;
      for (let index = 1; index <= 7; index++) {
        first1 = firstday;
        this.day = 'Day' + index;
        if (first1) {
          this.agentInfo.forEach(res => {
            let id = res.id;
            if (this.leave[id]) {
              this.leave[id].forEach(lev => {
                if (lev.date == first1) {
                  this.onLeave = true;
                  res[this.day] = [{ onLeave: this.onLeave, shiftAllocation: lev.shift }];
                  this.dayCount[this.day] = ({ 'amCount': 0, 'pmCount': 0 });
                }
              });
            }
          });
          console.log("My info", this.agentInfo);
        }
        firstday = new Date(firstday);
        firstday = this.convert(new Date(firstday.setDate(firstday.getDate() - firstday.getDay() + index + 1)));
      }

      this.loader = false;
    }));
  }

  getAllAgents() {
    this.agentInfo = [];
    this.agent = [];
    this.allAgents = [];
    this.subscriptions.push(this.apiService.getAgents({}).subscribe(res => {
      this.agentInfo = (res.data);
      this.agent = res.data;
      res.data.forEach(element => {
        this.allAgents.push(element.name);
      });
      this.reasonList = this.list;
      // this.getTranslation(this.list);
      var day = this.current.getDay(), diff = this.current.getDate() - day + (day == 0 ? -6 : 1);
      var monday = new Date(this.current.setDate(diff));
      this.first = this.convert(monday);
      var lastday = new Date(this.current.setDate(this.current.getDate() - this.current.getDay() + 7));
      this.last = this.convert(lastday);
      if (lastday > monday) {
        if (lastday.getMonth() != monday.getMonth()) {
          this.getMonthData(lastday > monday ? lastday.getMonth() : monday.getMonth(), 1);
        }
      }
      this.getWeekData(this.getMonday(new Date()).getDate(), 0);
      this.getCalendarInfo(this.first, this.last);
    }));
  }

  getMonthData(month1, flag) {
    let month = [];
    month[0] = "January";
    month[1] = "February";
    month[2] = "March";
    month[3] = "April";
    month[4] = "May";
    month[5] = "June";
    month[6] = "July";
    month[7] = "August";
    month[8] = "September";
    month[9] = "October";
    month[10] = "November";
    month[11] = "December";
    if (flag == 1) {

      this.n = month1 == 0 ? month[11].substring(0, 3) + '-' + month[month1].substring(0, 3) : month[month1 - 1].substring(0, 3) + '-' + month[month1].substring(0, 3);
    }
    else {
      this.n = month[month1];
    }
    this.count = month1;
    this.n1 = month[month1];
    return this.n;
  }

  getWeekData(today, flag) {
    var i;
    if (flag == 1) {
      this.getweekData = [];
      let lastDayOfWeek = this.first;
      this.highlightDatewithBlue(lastDayOfWeek, 'nocurrentMonth');
      let lastDayOfWeek1 = new Date(lastDayOfWeek);
      let lastday = new Date(this.first);
      this.numberOfDays.push(lastday.getDate());
      for (i = 1; i < 7; i++) {
        this.convert(new Date(lastday.setDate(lastday.getDate() - lastday.getDay() + i + 1)));

        today = lastday.getDate();

        this.highlightDatewithBlue(lastday, 'nocurrentMonth');
        this.numberOfDays.push(today);
      }
      // (this.current.getDate()> (new Date(this.first)).getDate() && this.current.getDate()<=(new Date(this.last)).getDate())?
      // true:
      //this.getweekData=[];
      this.getCalendarInfo(this.first, this.last);
    }
    else if (flag == 2) {
      this.getweekData = [];
      let lastDayOfWeek = this.first;
      this.highlightDatewithBlue(lastDayOfWeek, 'nocurrentMonth');
      let lastDayOfWeek1 = new Date(lastDayOfWeek);
      let lastday = new Date(this.first);
      this.numberOfDays.push(lastday.getDate());
      for (i = 1; i < 7; i++) {
        this.convert(new Date(lastday.setDate(lastday.getDate() - lastday.getDay() + i + 1)));
        today = lastday.getDate();
        this.highlightDatewithBlue(lastday, 'nocurrentMonth');
        this.numberOfDays.push(today);
      }
      // (this.current.getDate()> (new Date(this.first)).getDate() && this.current.getDate()<=(new Date(this.last)).getDate())?
      // true:
      //this.getweekData=[];
      this.getCalendarInfo(this.first, this.last);
    }
    else {
      this.getweekData = [];
      let daysArray = this.getDaysArray(this.first, this.last);
      daysArray.forEach(dt => {
        let d = this.convert(dt).split('-')[2];
        this.numberOfDays.push(d);
        this.highlightDatewithBlue(d, 'currentMonth');
      });

    }
  }

  getDaysArray(start, end) {
    var dArray = [];
    let eday = new Date(end);
    let sday: any = new Date(start);
    while (sday <= eday) {

      // Adding the date to array
      dArray.push(new Date(sday));

      // Increment the date by 1 day
      let d = new Date(sday);
      sday = d.setDate(d.getDate() + 1);
    }
    return dArray;
  };

  highlightDatewithBlue(today, currentMonth) {
    if (currentMonth == 'currentMonth') {
      let dt = new Date();
      this.getweekData.push(this.convert(dt.setDate(today)));
    } else {
      let dt = new Date(today);
      this.getweekData.push(this.convert(dt));
    }
  }

  getNextWeekDay(startDate, dayOfWeek) {
    var dayOffset = dayOfWeek > startDate.getDay()
      ? dayOfWeek - startDate.getDay()
      : dayOfWeek - startDate.getDay() + 7;

    startDate.setDate(startDate.getDate() + dayOffset);

    return startDate;
  }

  getNextMonth() {
    let lastDayOfWeek = this.first;
    let lastDayOfWeek1 = new Date(lastDayOfWeek);
    let current: any;
    let current1: any;
    this.numberOfDays = [];
    if (this.count == 11) {
      let weekNumber = this.getCurrentWeek(lastDayOfWeek1, 'Month');
      if (weekNumber == 6) {
        weekNumber = 5;
      }
      let mondays = this.getMondays(lastDayOfWeek1.setMonth(lastDayOfWeek1.getMonth() + 1));
      current = (new Date(mondays[weekNumber - 1]));
      current1 = (new Date(mondays[weekNumber - 1]));
      this.getYear = current.getFullYear();

      this.count = 0;
      this.reuse(current, current1);
      if (current.getFullYear() != current1.getFullYear()) {
        this.getYear = current.getFullYear() + "-" + current1.getFullYear();
      }
      if (current.getFullYear() == current1.getFullYear()) {
        this.getYear = current.getFullYear();
      }

      this.currentMonthFlag == 0 ? this.getMonthData((current1 > current ? current1.getMonth() : current.getMonth()), 0) : this.getMonthData((current1 > current ? current1.getMonth() : current.getMonth()), 1);
      this.getWeekData(current.getDate(), 1);
    } else {
      var weekNumber = this.getCurrentWeek(lastDayOfWeek1, 'Month'); //get weeknumber in current month
      console.log("WeekNumber Next Month", weekNumber);
      if (weekNumber == 6) {
        weekNumber = 5;
      }
      var mondays = this.getMondays(lastDayOfWeek1.setMonth(lastDayOfWeek1.getMonth() + 1)); //get all mondays in next month
      console.log("Get Monday Next month", mondays);
      if (mondays[weekNumber - 1] != undefined) {
        current = (new Date(mondays[weekNumber - 1]));
        current1 = (new Date(mondays[weekNumber - 1]));
      } else {
        /* increment in month + 1 when it comes to february   */
        var mondays = this.getMondays(lastDayOfWeek1.setMonth(lastDayOfWeek1.getMonth() + 1)); //get all mondays in next month   
        current = (new Date(mondays[weekNumber - 1]));
        current1 = (new Date(mondays[weekNumber - 1]));
      }
      this.reuse(current, current1);
      if (current.getFullYear() != current1.getFullYear()) {
        this.getYear = current.getFullYear() + "-" + current1.getFullYear();
      }
      if (current.getFullYear() == current1.getFullYear()) {
        this.getYear = current.getFullYear();
      }
      //this.count + 1
      this.currentMonthFlag == 0 ? this.getMonthData((current1 > current ? current1.getMonth() : current.getMonth()), 0) : this.getMonthData((current1 > current ? current1.getMonth() : current.getMonth()), 1);
      this.getWeekData(current.getDate(), 1);
    }
  }

  getMondays(date) {
    var d = new Date(date),
      month = d.getMonth(),
      mondays = [];

    d.setDate(1);

    // Get the first Monday in the month
    while (d.getDay() !== 1) {
      d.setDate(d.getDate() + 1);
    }

    // Get all the other Mondays in the month
    while (d.getMonth() === month) {
      mondays.push(new Date(d.getTime()));
      d.setDate(d.getDate() + 7);
    }

    if (mondays[0].getDate() == 1) {
      return mondays;
    }
    else {
      let firstWeek = (new Date(mondays[0]));
      mondays.unshift((new Date(firstWeek.setDate(firstWeek.getDate() - 7))));
      return mondays;
    }
  }

  getCurrentWeek(lastDayOfWeek1, flag) {
    var dayOfMonth = lastDayOfWeek1.getDay();
    var month = lastDayOfWeek1.getMonth();
    var year = lastDayOfWeek1.getFullYear();
    var checkDate = new Date(year, month, lastDayOfWeek1.getDate());
    var checkDateTime = checkDate.getTime();
    var currentWeek = 0;

    for (var i = 1; i < 32; i++) {
      var loopDate = new Date(year, month, i);

      if (loopDate.getDay() != 1 && (i == 1) && flag == 'Month') {
        currentWeek++;
      }

      if (loopDate.getDay() == dayOfMonth) {
        currentWeek++;
      }

      if (loopDate.getTime() == checkDateTime) {
        return currentWeek;
      }
    }
  }

  reuse(current, current1) {
    var lastDayOfWeek = new Date(current);
    lastDayOfWeek.setDate(current.getDate() + 6);
    if (lastDayOfWeek.getMonth() == current.getMonth()) {
      // current = new Date(this.now.getFullYear(),this.now.getMonth(), this.now.getDate());
      // current1 = new Date(this.now.getFullYear(),this.now.getMonth(), this.now.getDate());
      this.currentMonthFlag = 0;
    }
    else
      this.currentMonthFlag = 1;
    if (current.getDay() == 0) {
      this.first = this.convert(new Date(current.setDate(current.getDate() - 6)));
      this.last = this.convert(new Date(current1));
    }
    else if (current.getDay() == 1) {
      this.first = this.convert(new Date(current.setDate(current.getDate())));
      this.last = this.convert(new Date(current1.setDate(current1.getDate() + 6)));
    }
    else if (current.getDay() == 2) {
      this.first = this.convert(new Date(current.setDate(current.getDate() - 1)));
      this.last = this.convert(new Date(current1.setDate(current1.getDate() + 5)));
    }
    else if (current.getDay() == 3) {
      this.first = this.convert(new Date(current.setDate(current.getDate() - 2)));
      this.last = this.convert(new Date(current1.setDate(current1.getDate() + 4)));
    }
    else if (current.getDay() == 4) {
      this.first = this.convert(new Date(current.setDate(current.getDate() - 3)));
      this.last = this.convert(new Date(current1.setDate(current1.getDate() + 3)));
    }
    else if (current.getDay() == 5) {
      this.first = this.convert(new Date(current.setDate(current.getDate() - 4)));
      this.last = this.convert(new Date(current1.setDate(current1.getDate() + 2)));
    }
    else if (current.getDay() == 6) {
      this.first = this.convert(new Date(current.setDate(current.getDate() - 5)));
      this.last = this.convert(new Date(current1.setDate(current1.getDate() + 1)));
    }
  }

  getPreviousMonth() {
    let lastDayOfWeek = this.first;
    let lastDayOfWeek1 = new Date(lastDayOfWeek);
    this.numberOfDays = [];
    if (this.count == 0) {
      var weekNumber = this.getCurrentWeek(lastDayOfWeek1, 'Month');
      console.log("WeekNumber Previous Month", weekNumber);
      if (weekNumber == 6) {
        weekNumber = 5;
      }
      var mondays = this.getMondays(lastDayOfWeek1.setMonth(lastDayOfWeek1.getMonth() - 1));
      console.log("Get Monday Previous month", mondays);
      let current = (new Date(mondays[weekNumber - 1]));
      let current1 = (new Date(mondays[weekNumber - 1]));
      this.getYear = current.getFullYear();

      if (current.getFullYear() != current1.getFullYear()) {
        this.getYear = current.getFullYear() + "-" + current1.getFullYear();
      }
      if (current.getFullYear() == current1.getFullYear()) {
        this.getYear = current.getFullYear();
      }
      // let current = new Date(lastDayOfWeek1.getFullYear() , lastDayOfWeek1.getMonth() - 1, 1); 
      // let current1 = new Date(lastDayOfWeek1.getFullYear() , lastDayOfWeek1.getMonth() - 1, 1); 
      this.count = 0;
      this.reuse(current, current1);
      this.currentMonthFlag == 0 ? this.getMonthData((current1 > current ? current1.getMonth() : current.getMonth()), 0) : this.getMonthData((current1 > current ? current1.getMonth() : current.getMonth()), 1);
      this.getWeekData(current.getDate(), 1);
    } else {
      let weekNumber: any;
      if (lastDayOfWeek1.getMonth() == 2) {
        weekNumber = this.getCurrentWeek(lastDayOfWeek1, 'Month');
        var mondays = this.getMondays(lastDayOfWeek1.setMonth(lastDayOfWeek1.getMonth() - 2));
      } else {
        weekNumber = this.getCurrentWeek(lastDayOfWeek1, 'Month');
        var mondays = this.getMondays(lastDayOfWeek1.setMonth(lastDayOfWeek1.getMonth() - 1));
      }
      if (weekNumber == 6) {
        weekNumber = 5;
      }

      let current = (new Date(mondays[weekNumber - 1]));
      let current1 = (new Date(mondays[weekNumber - 1]));
      this.reuse(current, current1);

      if (current.getFullYear() != current1.getFullYear()) {
        this.getYear = current.getFullYear() + "-" + current1.getFullYear();
      }
      if (current.getFullYear() == current1.getFullYear()) {
        this.getYear = current.getFullYear();
      }
      //this.count - 1         
      this.currentMonthFlag == 0 ? this.getMonthData((current1 > current ? current1.getMonth() : current.getMonth()), 0) : this.getMonthData((current1 > current ? current1.getMonth() : current.getMonth()), 1);
      this.getWeekData(current.getDate(), 1);
    }
  }

  getPreviousWeek1() {
    this.numberOfDays = [];
    let firstDayOfWeek = this.first;
    let firstDayOfWeek1 = new Date(firstDayOfWeek);
    let lastday = new Date(this.first);
    let firstday = new Date(this.first);
    this.first = this.convert(new Date(lastday.setDate(lastday.getDate() - lastday.getDay() - 6)));
    this.last = this.convert(new Date(firstday.setDate(firstday.getDate() - firstday.getDay())));
    if ((lastday.getFullYear() == firstDayOfWeek1.getFullYear()) && lastday.getMonth() < firstDayOfWeek1.getMonth()) {
      //this.getMonthData(this.count,1);
      if (lastday.getMonth() != firstday.getMonth()) {
        this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 1);
      } else {
        this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 0);
      }
    }
    else if (lastday.getFullYear() > firstDayOfWeek1.getFullYear()) {
      if (this.count == 0) {
        this.getYear = lastday.getFullYear() - 1;
        this.count = 11;
        //this.getMonthData(this.count,1);
        if (lastday.getMonth() != firstday.getMonth()) {
          this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 1);
        } else {
          this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 0);
        }
      }
      else {
        if (lastday.getMonth() != firstday.getMonth()) {
          this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 1);
        } else {
          this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 0);
        }
        //this.getMonthData(this.count-1,1);
      }
    }
    else {
      this.getYear = lastday.getFullYear();
      if (lastday.getMonth() != firstday.getMonth()) {
        this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 1);
      } else {
        this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 0);
      }
    }
    this.getWeekData(lastday.getDate(), 2);
    if (firstday.getFullYear() != lastday.getFullYear()) {
      this.getYear = lastday.getFullYear() + "-" + firstday.getFullYear();
    }
    if (firstday.getFullYear() == lastday.getFullYear()) {
      this.getYear = firstday.getFullYear();
    }
  }

  getNextWeek1() {
    this.numberOfDays = [];
    let lastDayOfWeek = this.last;
    let lastDayOfWeek1 = new Date(lastDayOfWeek);
    let lastday = new Date(this.last);
    let firstday = new Date(this.last);
    this.last = this.convert(new Date(lastday.setDate(lastday.getDate() - lastday.getDay() + 7)));
    this.first = this.convert(new Date(firstday.setDate(firstday.getDate() - firstday.getDay() + 1)));

    if ((lastday.getFullYear() == lastDayOfWeek1.getFullYear()) && lastday.getMonth() > lastDayOfWeek1.getMonth()) {
      if (lastday.getMonth() != firstday.getMonth()) {
        this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 1);
      } else {
        this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 0);
      }
    }
    else if (lastday.getFullYear() > lastDayOfWeek1.getFullYear()) {
      if (this.count == 11) {
        this.getYear = lastDayOfWeek1.getFullYear() + 1;
        this.count = 0;
        if (lastday.getFullYear() != firstday.getFullYear()) {
          this.getYear = firstday.getFullYear() + "-" + lastday.getFullYear();
        }
        if (lastday.getFullYear() == firstday.getFullYear()) {
          this.getYear = firstday.getFullYear();
        }
        if (lastday.getMonth() != firstday.getMonth()) {
          this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 1);
        } else {
          this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 0);
        }

      }
      else {
        if (lastday.getMonth() != firstday.getMonth()) {
          this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 1);
        } else {
          this.getMonthData((lastday > firstday ? lastday.getMonth() : firstday.getMonth()), 0);
        }

      }
    }
    else {
      this.getMonthData(firstday.getMonth(), 0);
      if (lastday.getFullYear() != firstday.getFullYear()) {
        this.getYear = firstday.getFullYear() + "-" + lastday.getFullYear();
      }
      if (lastday.getFullYear() == firstday.getFullYear()) {
        this.getYear = firstday.getFullYear();
      }
    }
    console.log(this.first, this.last, firstday, lastday);
    this.getWeekData(lastDayOfWeek1.getDate(), 1);
  }

  open(pop, clock, data) {
    $('ngb-popover-window').remove();
    let item = data.filter(res => res.shift == clock)[0];
    this.toolmissionType = item.missionType;
    this.toolmissionSubType = item.missionSubType;
    this.toolmissionName = item.missionName;
    this.toolcampaignName = item.campaignName;
    this.toolsupervisor = item.supervisor;
    this.clock = clock;
    this.p = pop;
  }

  close() {
    this.p.close();
  }

  getNextYear() {
    let lastDayOfWeek = this.last;
    this.numberOfDays = [];
    let lastDayOfWeek1 = new Date(lastDayOfWeek);
    // let current = new Date(lastDayOfWeek1.getFullYear() + 1, 0, 1); 
    // let current1=new Date(lastDayOfWeek1.getFullYear() + 1, 0, 1); 
    var weekNumber = this.getCurrentWeek(lastDayOfWeek1, 'Year');
    console.log("WeekNumber Next year", weekNumber);
    lastDayOfWeek1.setFullYear(lastDayOfWeek1.getFullYear() + 1);
    var mondays = this.getMondays(lastDayOfWeek1.setMonth(lastDayOfWeek1.getMonth()));
    console.log("WeekNumber Next year", weekNumber);
    console.log("Get Monday Next year", mondays);
    let current = (new Date(mondays[weekNumber - 1]));
    let current1 = (new Date(mondays[weekNumber - 1]));
    this.getYear = current.getFullYear();
    this.reuse(current, current1);
    if (current.getFullYear() != current1.getFullYear()) {
      this.getYear = current.getFullYear() + "-" + current1.getFullYear();
    }
    if (current.getFullYear() == current1.getFullYear()) {
      this.getYear = current.getFullYear();
    }
    this.currentMonthFlag == 0 ? this.getMonthData(current.getMonth(), 0) : this.getMonthData(this.count, 1);
    this.getWeekData(current.getDate(), 2);
  }

  getPreviousYear() {
    let lastDayOfWeek = this.last;
    let lastDayOfWeek1 = new Date(lastDayOfWeek);
    this.numberOfDays = [];
    var weekNumber = this.getCurrentWeek(lastDayOfWeek1, 'Year');
    lastDayOfWeek1.setFullYear(lastDayOfWeek1.getFullYear() - 1);
    var mondays = this.getMondays(lastDayOfWeek1.setMonth(lastDayOfWeek1.getMonth()));
    console.log("WeekNumber Previous year", weekNumber);
    console.log("Get Monday Previous year", mondays);
    let current = (new Date(mondays[weekNumber - 1]));
    let current1 = (new Date(mondays[weekNumber - 1]));
    // let current = new Date(lastDayOfWeek1.getFullYear() - 1, 0, 1); 
    // let current1=new Date(lastDayOfWeek1.getFullYear() -1, 0, 1);  
    this.getYear = current.getFullYear();
    //this.count=0;
    //this.getMonthData(current.getMonth(),1);
    this.reuse(current, current1);
    if (current.getFullYear() != current1.getFullYear()) {
      this.getYear = current.getFullYear() + "-" + current1.getFullYear();
    }
    if (current.getFullYear() == current1.getFullYear()) {
      this.getYear = current.getFullYear();
    }
    this.currentMonthFlag == 0 ? this.getMonthData(this.count, 0) : this.getMonthData(this.count, 1);
    this.getWeekData(current.getDate(), 1);
  }

  changeSurveyModal(modal) {
    // keyboard: false, backdrop: 'static'
    this.modal = this.modalService.open(modal, { keyboard: false, backdrop: 'static' });
    this.modal.result.then((result) => {
      this.fieldName = this.storageService.getData('fieldName');
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return reason;
    }
  }


  onDateSelection(date: NgbDateStruct,event) {   
    this.parsed='';
     if (!this.fromDate && !this.toDate) {
       this.fromDate = date;
     } else if (this.fromDate && !this.toDate) {
       this.toDate = date;
 
       // this.model = `${this.fromDate.year} - ${this.toDate.year}`;
       // this.input.close();
     } else {
       this.toDate = null;
       this.fromDate = date;
     }
     console.log(this.fromDate,this.toDate);
     if (this.fromDate) {   
       this.parsed += (this.fromDate.day + '/' + this.fromDate.month + '/' + this.fromDate.year.toString().substr(2,2));
       event.stopPropagation();
       event.preventDefault();
     }
 
     if (this.toDate) {
       this.parsed.substr(0,8);
       this.parsed += '-' + this.toDate.day + '/' + this.toDate.month + '/' + this.toDate.year.toString().substr(2,2);
       // this.input.close();
     }
 
     this.renderer.setProperty(this.myRangeInput.nativeElement, 'value', this.parsed);
     if (this.fromDate && this.toDate) {
       this.input.close();
       
      
     }
     
   }
   
  gotoUn(flag) {
    if (flag === 'true') {
      this.addClick = true;
      this.removeClick = false;
      this.missionEndDate=undefined;
      this.missionStartDate=undefined;
      this.morning = false;
      this.afternoon = false;
      this.fullDay = false;
      this.morning1 = false;
      this.afternoon1 = false;
      this.fullDay1 = false;
      this.showDate= [];
      this.message1 = null;
      this.selectedFieldAgent=null;
      this.selectedReason = null;
      this.missiondates= undefined
      this.useDate =undefined
    }
    else {
      this.addClick = false;
      this.removeClick = true;
      this.missionEndDate=undefined;
      this.missionStartDate=undefined;
      this.morning = false;
      this.afternoon = false;
      this.fullDay = false;
      this.morning1 = false;
      this.afternoon1 = false;
      this.selectedFieldAgent=null;
      this.fullDay1 = false;
      this.showDate= [];
      this.message1 = null;
      this.selectedReason = null;
      this.missiondates= undefined
      this.useDate =undefined
    }
  }

  selectedFieldAgentValue = false;
  getFieldAgent($event) {
    this.disabledDates = [];
    this.showDate = [];
    this.fullDay1 = false;
    this.afternoon1 = false;
    this.morning1 = false;
    this.fullDay = false;
    this.afternoon = false;
    this.morning = false;
    this.missiondates = undefined
    this.useDate =undefined
    this.missionEndDate=undefined;
    this.missionStartDate=undefined;
    this.selectedFieldAgentValue = true;
    this.selectedFieldAgent = $event;
    this.selectedAgent = this.agent.find(o => o.name === this.selectedFieldAgent);

    if (this.selectedAgent !== null && this.selectedAgent !== undefined) {
      if (!this.addClick) {
        const current = this.convert(new Date(Date.now()));
        this.leavesArray = this.leave[this.selectedAgent.id];
        this.leavesArray !== undefined? this.setLeaves(this.leavesArray) :  this.message1="No dates available";
      }
      else {
        const current = this.convert(new Date(Date.now()));
        this.leavesArray = this.leave[this.selectedAgent.id];
        if(this.leavesArray !== undefined){this.leavesArray.forEach(element => {
          if (element.date >= current) {
            this.disabledDates.push({ year: Number(element.date.split('-')[0]), month: Number(element.date.split('-')[1]), day: Number(element.date.split('-')[2]), shift: element.shift });
          }
        });}
        this.apiService.getUnavailableDate(this.selectedAgent.id).subscribe(res => {
          let today = this.convert(new Date());
          res.data.forEach(element => {
            this.disabledDates.push({ year: Number(element.date.split('-')[0]), month: Number(element.date.split('-')[1]), day: Number(element.date.split('-')[2]), shift: this.getShift(element.shift) });
          });
          this.checkDisabliDates();
        }, err => {
          this.checkDisabliDates();
          this.getUnavailableDateDate = [];
          this.dates = [];
        });
      
      }
      this.storageService.setData('fieldName', this.selectedFieldAgent.fullname);
    }
  }

  getShift(shift: any) {
    if (shift == 1) return 'AM';
    else if (shift == 2) return 'PM';
    else return 'FD';
  }

  checkDisabliDates() {
      const now = new Date(Date.now());
      let today1 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
      const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
      const busyDates = JSON.parse(localStorage.getItem('busyDates'));
      const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
      const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);

      this.isDisabled = (date: NgbDate) => {
        const sdate = new Date(date.year, date.month - 1, date.day);
        if (sdate >= today1) {
          if (this.selectedShift1 !== "" && this.selectedShift1.toLowerCase() !== "fd") {
            if (this.disabledDates.find((x: any) => NgbDate.from(x).equals(date) && (x.shift.toLowerCase() == this.selectedShift1.toLowerCase() || x.shift.toLowerCase() == 'fd')))  return true
            else return false;
          }
          if(this.selectedShift1 !== "" && this.selectedShift1.toLowerCase() === "fd"){
            if (this.disabledDates.find((x: any) => NgbDate.from(x).equals(date) && (x.shift.toLowerCase() == this.selectedShift1.toLowerCase() || x.shift.toLowerCase() == 'pm' || x.shift.toLowerCase() == 'am')))  return true
            else return false;
          }
        }
        else return true;
      }
      this.isDisabled1= (date: NgbDate) => {
        const sdate = new Date(date.year, date.month - 1, date.day);
        const usedDate= new Date(this.useDate);
        const newUse=new Date(usedDate.getFullYear(),
        usedDate.getMonth(),
        usedDate.getDate());
        if (sdate >= newUse) {
          if (this.selectedShift2 !== "" && this.selectedShift2.toLowerCase() !== "fd") {
            if (this.disabledDates.find((x: any) => NgbDate.from(x).equals(date) && (x.shift.toLowerCase() == this.selectedShift2.toLowerCase() || x.shift.toLowerCase() == 'fd')))  return true
            else return false;
          }
          if(this.selectedShift2 !== "" && this.selectedShift2.toLowerCase() === "fd"){
            if (this.disabledDates.find((x: any) => NgbDate.from(x).equals(date) && (x.shift.toLowerCase() == this.selectedShift2.toLowerCase() || x.shift.toLowerCase() == 'pm' || x.shift.toLowerCase() == 'am')))  return true;
            else return false;
          }
        }
        else return true;
      }
      this.endDateclicked =false;
      this.startDateclicked =false;  
  }

  dates=[];
  diffrentDate=[];
  sameDate=[];
  showDate=[];
  setLeaves(leaves) {
    this.sameDate=[];
    this.dates=[];
    this.message1=null;
    const current = this.convert(new Date(Date.now()));
    leaves.forEach(element => {
      if (element.date >= current) {
        this.dates.push({date : new Date(element.date), shift : element.shift});
        this.sameDate.push({ year: Number(element.date.split('-')[0]), month: Number(element.date.split('-')[1]), day: Number(element.date.split('-')[2]), shift: element.shift });
      }
    });
  
    this.isDisabled2 = (date: NgbDate) => {
      if (this.sameDate.find((x: any) => NgbDate.from(x).equals(date)))  return false
      else return true;
    }

    this.isDisabled3 = (date: NgbDate) => {
      const sdate = new Date(date.year, date.month - 1, date.day);
      const usedDate = new Date(this.useDate);
      const newUse = new Date(usedDate.getFullYear(),
        usedDate.getMonth(),
        usedDate.getDate());
      if (sdate >= newUse) {
        if (this.sameDate.find((x: any) => NgbDate.from(x).equals(date))) return false
        else return true;
      }
      else return true;
    }

    if(this.dates.length>0){
      this.dates.sort(function (a, b) { return a.date.getTime() - b.date.getTime() });
      for (let item = 0; item < this.dates.length; item++) {
        this.flagok = false;
        if (!(item == this.dates.length - 1)) {
          const diff = this.getDifference(this.dates[item].date, this.dates[item + 1].date);
          if (diff > 1) {
            this.flagok = true;
            item == 0 ? this.showDate.push(this.convert1(this.dates[0].date) + '(' + this.dates[0].shift.toUpperCase() + ')') :
                this.showDate.push(this.convert1(this.dates[0].date) + '(' + this.dates[0].shift.toUpperCase() + ')' + '-' + this.convert1(this.dates[item].date) + '(' + this.dates[item].shift.toUpperCase() + ')');
             
            for (let k = 0; k <= item; k++) {
              this.dates.splice(0, 1);
            }
            item = -1;
          }
        }
        else{
          this.flagok = true;
         item !== 0 ? this.showDate.push(this.convert1(this.dates[0].date) + '(' + this.dates[0].shift.toUpperCase() + ')' + '-' + this.convert1(this.dates[this.dates.length - 1].date) + '(' + this.dates[this.dates.length - 1].shift.toUpperCase() + ')') : this.showDate.push(this.convert1(this.dates[0].date) + '(' + this.dates[0].shift.toUpperCase() + ')');
          this.dates.splice(item, 1);
        }
      }
      // (!this.flagok) ? item !== 0 ? this.showDate.push(this.convert(this.dates[0]) + '-' + this.convert(this.dates[this.dates.length - 1])) : this.showDate.push(this.convert(this.dates[0])) : false;
      (!this.flagok) ? this.showDate.push(this.convert1(this.dates[0].date) + '(' + this.dates[0].shift.toUpperCase() + ')' + '-' + this.convert1(this.dates[this.dates.length - 1].date) + '(' + this.dates[this.dates.length - 1].shift.toUpperCase() + ')') : false;
    }
    else{
      this.message1="No dates available";
    }
  }

  changeLocalDate(date) {
    this.mission.missionEndDate = {
      year: null,
      month: null,
      day: null
    };
    localStorage.setItem('date', JSON.stringify(date));
    this.minEndDate = date;
  }
  
  selectStartDate(dt){
    var startDate = new Date(this.mission.missionStartDate.year + '-' + this.mission.missionStartDate.month + '-' + this.mission.missionStartDate.day);
    this.isStartDate = {
      year: startDate.getFullYear(), month:
        startDate.getMonth()+1, day: startDate.getDate()
    };

    this.minEndDateDisable = {
      year: dt.year,
      month: dt.month,
      day: dt.day
    };
  }

  getReason($event) {
    if($event!==null){
      let data=this.list.find(o => o.id === $event.value);
      this.selectedReason = data.name;
    }
    else this.selectedReason = null;
  }

  ngOnDestroy() {
    this.storageService.removeData('fieldName');
  }

  morning = false;
  // startDate;
  dateSelected = false;
  missiondates;
  currentDate;
  // endDate;
  missionStartDate;
  selectedDate;
  missionDate
  campaignFlag
  getDate(d1) {
    const date = d1;
    this.currentDate = this.startDate;
    this.dateSelected = true;
    const months = String(date.month).padStart(2, "0");
    const days = String(date.day).padStart(2, "0");
    // this.missiondates = `${date.year}-${months}-${days}`
    this.startDate = `${d1.year}-${months}-${days} 00:00:00`

    var g1 = new Date();
    // (YYYY-MM-DD) 
    var CurrentDate = new Date()
    var d = new Date();
    // var d = new Date(CurrentDate),
    let dateToday = {
      month: '' + (d.getMonth() + 1),
      day: '' + d.getDate(),
      year: d.getFullYear()
    }

    if (dateToday.month.length < 2)
      dateToday.month = '0' + dateToday.month;
    if (dateToday.day.length < 2)
      dateToday.day = '0' + dateToday.day;
    var today = `${dateToday.year}-${dateToday.month}-${dateToday.day}`
    let endDateCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    let startDateCheck = JSON.parse(localStorage.getItem('campaignStartDate'));

    endDateCheck = new Date(`${endDateCheck.year}-${endDateCheck.month}-${endDateCheck.day}`)
    startDateCheck = new Date(`${startDateCheck.year}-${startDateCheck.month}-${startDateCheck.day}`)

    var GivenDate = new Date(`${d1.year}-${d1.month}-${d1.day}`);
    const month1 = String(d1.month).padStart(2, "0");
    const day1 = String(d1.day).padStart(2, "0");
    const month = String(d1.month).padStart(2, "0");
    const day = String(d1.day).padStart(2, "0");
    this.selectedDate = `${d1.year}-${month}-${day} 00:00:00`
    this.missionDate = `${d1.year}-${month}-${day}`

    var todayDate = `${d1.year}-${month1}-${day1}`
    this.useDate = todayDate;
    this.startDateclicked = true;
    if (this.disabledDates.find((x: any) => NgbDate.from(x).equals(date))) {
      return false;
    }
    else {
      if (GivenDate >= CurrentDate || (today === todayDate)) {
        this.dateSelected = true;
        this.missionStartDate = {
          year: d1.year,
          month: d1.month,
          day: d1.day
        }
        this.currentDate = this.startDate;
        // this.getAllUnassignedUsersPos({
        //   startDate: `${date.year}-${date.month}-${date.day}`,
        //   endDate: `${date.year}-${date.month}-${date.day}`,
        //   iterations: 9,
        //   shift: this.morning ? 1 : 2,
        //   missionId: this.missionId
        // });
      }
    }
  }

  getDate1(d1) {
    const date = d1;
    this.currentDate = this.startDate;
    this.dateSelected = true;
    const months = String(date.month).padStart(2, "0");
    const days = String(date.day).padStart(2, "0");
    // this.missiondates = `${date.year}-${months}-${days}`
    this.startDate = `${d1.year}-${months}-${days} 00:00:00`

    var g1 = new Date();
    // (YYYY-MM-DD) 
    var CurrentDate = new Date()
    var d = new Date();
    // var d = new Date(CurrentDate),
    let dateToday = {
      month: '' + (d.getMonth() + 1),
      day: '' + d.getDate(),
      year: d.getFullYear()
    }

    if (dateToday.month.length < 2)
      dateToday.month = '0' + dateToday.month;
    if (dateToday.day.length < 2)
      dateToday.day = '0' + dateToday.day;
    var today = `${dateToday.year}-${dateToday.month}-${dateToday.day}`
    let endDateCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    let startDateCheck = JSON.parse(localStorage.getItem('campaignStartDate'));

    endDateCheck = new Date(`${endDateCheck.year}-${endDateCheck.month}-${endDateCheck.day}`)
    startDateCheck = new Date(`${startDateCheck.year}-${startDateCheck.month}-${startDateCheck.day}`)

    var GivenDate = new Date(`${d1.year}-${d1.month}-${d1.day}`);
    const month1 = String(d1.month).padStart(2, "0");
    const day1 = String(d1.day).padStart(2, "0");
    const month = String(d1.month).padStart(2, "0");
    const day = String(d1.day).padStart(2, "0");
    this.selectedDate = `${d1.year}-${month}-${day} 00:00:00`
    this.missionDate = `${d1.year}-${month}-${day}`

    var todayDate = `${d1.year}-${month1}-${day1}`
    this.useDate = todayDate;
    this.startDateclicked = true;
    if (this.sameDate.find((x: any) => NgbDate.from(x).equals(date))) {
      if (GivenDate >= CurrentDate || (today === todayDate)) {
        this.dateSelected = true;
        this.missionStartDate = {
          year: d1.year,
          month: d1.month,
          day: d1.day
        }
        this.currentDate = this.startDate;
      }
      else{
        return false;
      }
    }
  }

  getEndDate(date: NgbDate, currentMonth) {
    if (this.selectedShift2 !== "" && this.selectedShift2.toLowerCase() !== "fd") {
      if (this.disabledDates.find((x: any) => NgbDate.from(x).equals(date) && (x.shift.toLowerCase() == this.selectedShift2.toLowerCase() || x.shift.toLowerCase() == 'fd'))) return false;
      else {
        this.dateSelected = true;
        const month = String(date.month).padStart(2, "0");
        const day = String(date.day).padStart(2, "0");
        this.missiondates = `${date.year}-${month}-${day}`
        this.useDate1 = this.missiondates;
        this.startDate = `${date.year}-${month}-${day} 00:00:00`;
        this.endDateclicked = true;
      }
    }
    if (this.selectedShift2 !== "" && this.selectedShift2.toLowerCase() === "fd") {
      if (this.disabledDates.find((x: any) => NgbDate.from(x).equals(date) && (x.shift.toLowerCase() == this.selectedShift2.toLowerCase() || x.shift.toLowerCase() == 'pm' || x.shift.toLowerCase() == 'am'))) return true;
      else {
        this.dateSelected = true;
        const month = String(date.month).padStart(2, "0");
        const day = String(date.day).padStart(2, "0");
        this.missiondates = `${date.year}-${month}-${day}`
        this.useDate1 = this.missiondates;
        this.startDate = `${date.year}-${month}-${day} 00:00:00`;
        this.endDateclicked = true;
      }
    }
  }

  getEndDate1(date: NgbDate, currentMonth) {
    if (this.sameDate.find((x: any) => NgbDate.from(x).equals(date))) { 
      this.dateSelected = true;
      const month = String(date.month).padStart(2, "0");
      const day = String(date.day).padStart(2, "0");
      this.missiondates = `${date.year}-${month}-${day}`
      this.useDate1 = this.missiondates;
      this.startDate = `${date.year}-${month}-${day} 00:00:00`;
      this.endDateclicked = true;
    }
    else {
     return false;
    }
  }

  days: number = 0;
  resetEnddate(date) {
    this.days = 0;
    this.step3Form.controls['endDate'].setValue(null);
    this.optionsAgents = [];
  }

  changeShiftId(id, event) {
    const now = new Date(Date.now());
    const CurrentDate = new Date(now.getFullYear(), now.getMonth(), now.getDate()); 
    if (event.target.checked) {
      if (id === 1) {
        this.morning = true;
        this.afternoon = false;
        this.fullDay = false;
        this.selectedShift1 = 'AM';
        this.useDate = undefined
        this.missionStartDate = undefined;
        this.missiondates = undefined;
        this.missionEndDate = undefined;
        this.afternoon1 = false;
        this.morning1 = false;
        this.fullDay1 = false;
        this.selectedShift2 = '';
        this.getUsedMissionDates(CurrentDate);
      } else if (id === 2) {
        this.afternoon = true;
        this.morning = false;
        this.fullDay = false;
        this.selectedShift1 = 'PM';
        this.useDate = undefined;
        this.missionStartDate = undefined;
        this.missiondates = undefined;
        this.missionEndDate = undefined;
        this.afternoon1 = false;
        this.morning1 = false;
        this.fullDay1 = false;
        this.selectedShift2 = '';
        this.getUsedMissionDates(CurrentDate);
      }
      else {
        this.fullDay = true;
        this.afternoon = false;
        this.morning = false;
        this.selectedShift1 = 'FD';
        this.afternoon1 = false;
        this.morning1 = false;
        this.fullDay1 = false;
        this.selectedShift2 = '';
        this.useDate = undefined;
        this.missionStartDate = undefined;
        this.missiondates = undefined;
        this.missionEndDate = undefined;
        this.getUsedMissionDates(CurrentDate);
      }
    } else {
      this.morning = false;
      this.afternoon = false;
      this.fullDay = false;
      this.selectedShift1 = '';
      this.useDate = undefined
      this.missionStartDate = undefined;
      this.missiondates = undefined;
      this.missionEndDate = undefined;
      this.afternoon1 = false;
      this.morning1 = false;
      this.fullDay1 = false;
      this.selectedShift2 = '';
    }
  }

  changeShiftId1(id, event) {
    const now = new Date(Date.now());
    const CurrentDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    if (event.target.checked) {
      if (id === 1) {
        this.morning1 = true;
        this.afternoon1 = false;
        this.fullDay1 = false;
        this.selectedShift2 = 'AM';
        this.missiondates = undefined;
        this.missionEndDate = undefined;
        this.getUsedMissionDates(CurrentDate);
      } else if (id === 2) {
        this.afternoon1 = true;
        this.morning1 = false;
        this.fullDay1 = false;
        this.selectedShift2 = 'PM';
        this.missiondates = undefined;
        this.missionEndDate = undefined;
        this.getUsedMissionDates(CurrentDate);
      }
      else {
        this.fullDay1 = true;
        this.afternoon1 = false;
        this.morning1 = false;
        this.selectedShift2 = 'FD';
        this.missiondates = undefined;
        this.missionEndDate = undefined;
        this.getUsedMissionDates(CurrentDate);
      }
    }
    else {
      this.fullDay1 = false;
      this.afternoon1 = false;
      this.morning1 = false;
      this.selectedShift2 = '';
      this.missiondates = undefined;
      this.missionEndDate = undefined;
    }
  }

  /* Datepicker related API's */
  getUsedMissionDates(date) {
    let currentDate = UTILS.getDatePickerDateFormat(date);
    Globals.BUSY_DATES = []

    this.subscriptions.push(
      this.apiService
        .getShiftWiseUsedMissionDates(
          UTILS.getDateFormatWithoutZero(currentDate),
          missionTypes.POS_POI_TYPE_ID, this.morning ? 1 : 2
        )
        .subscribe(
          res => {
            Globals.BUSY_DATES = res.dateDto;

          },
          err => (Globals.BUSY_DATES = [])
        )
    );
  }

  setMinMaxDate() {
    const minDate_ = new Date(UTILS.getDateTimeFormat(UTILS.minDate));
    const campaignStartDate = new Date(Globals.campaignStartDate);
    if (minDate_ < campaignStartDate)
      this.minDate = UTILS.getDatePickerDateFormat(Globals.campaignStartDate);
    else this.minDate = UTILS.minDate;

    this.maxDate = UTILS.getDatePickerDateFormat(Globals.campaignEndDate);
  }

  isDisabled(date: NgbDateStruct, current: { month: number }) {
    const now = new Date(Date.now());
    let today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate')); 
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));  
    const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
    const sdate = new Date(date.year, date.month - 1, date.day);

    if (sdate >= today) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };
        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
       }
      else return false;
    } else {
      return true;
    }
  }

  isDisabled1(date: NgbDateStruct, current: { month: number }) {
    const now = new Date(Date.now());
    let today = new Date(this.useDate);
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
    const sdate = new Date(date.year, date.month - 1, date.day);

    if (sdate >= today) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };
        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  isDisabled2(date: NgbDateStruct, current: { month: number }) {
    const now = new Date(Date.now());
    let today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
    const sdate = new Date(date.year, date.month - 1, date.day);

    if (sdate >= today) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };
        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  isDisabled3(date: NgbDateStruct, current: { month: number }) {
    const now = new Date(Date.now());
    let today = new Date(this.useDate);
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
    const sdate = new Date(date.year, date.month - 1, date.day);

    if (sdate >= today) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };
        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  _MS_PER_DAY = (1000 * 3600 * 24);
  addUnavailability() {
    this.add = true;
    let obj = {
      "agentId": this.selectedAgent.id,
      "unavailablility": [],
      "createdBy": this.currentUser.userId,
      "updatedBy":this.currentUser.userId,
      "reason" : (this.selectedReason),
    };
    this.getUnDates(obj);

    this.apiService.postUnavailableUser(obj).subscribe(res => {
          this.getUnavailableUser();
         setTimeout(() => {
          this.getCalendarInfo(this.first, this.last);   
         }, 30);
          this.missionEndDate=undefined;
      this.missionStartDate=undefined;
    this.selectedFieldAgent=null;
      this.morning = false;
      this.afternoon = false;
      this.fullDay = false;
      this.morning1 = false;
      this.afternoon1 = false;
      this.fullDay1 = false;
      this.selectedReason = null;
      this.add=false;
      this.showDate= [];
      this.message1 = null;
      this.useDate=undefined
      this.missiondates=undefined
          this.modal.close();

    });
  }   

  removeUnavailability() {
    this.remove = true;
    let obj = {
      "agentId": this.selectedAgent.id,
      "startDate": this.useDate,
      "endDate": this.missiondates
    };
    this.apiService.deleteUnavailableUser(obj).subscribe(res => {
      this.getUnavailableUser();
      setTimeout(() => {
        this.getCalendarInfo(this.first, this.last);
      }, 30);
      this.missionEndDate = undefined;
      this.missionStartDate = undefined;
      this.morning = false;
      this.afternoon = false;
      this.fullDay = false;
      this.morning1 = false;
      this.afternoon1 = false;
      this.fullDay1 = false;
      this.selectedReason = null;
      
    this.selectedFieldAgent=null;
      this.showDate= [];
      this.message1 = null;
      this.remove=false;
      this.useDate= undefined
      this.missiondates =undefined
      this.modal.close();
    });
  }

  isToday(date: NgbDateStruct) {
    let date1 = new Date();
    this.today2 = { year: date1.getFullYear(), month: date1.getMonth() + 1, day: date1.getDate() };
    if (!this.today2)
      return false;
    return date.year == this.today2.year &&
      date.month == this.today2.month &&
      date.day == this.today2.day
  }

  getUnDates(obj) {
    this.mission.nextDay= [];
    const a = new Date(this.useDate);
    const diff= this.getDifference(this.useDate,this.missiondates);
    this.mission.nextDay.push(this.useDate);
    for (let i = 1; i <= diff; i++) {
      let midDate = new Date(a.setDate(a.getDate() + 1));
      this.mission.nextDay.push(this.convert(midDate));
    }

    for (let j = 0; j < this.mission.nextDay.length; j++) {
      if (this.selectedShift1 !== "" && this.selectedShift1.toLowerCase() !== "fd") {
        this.disabledDates.forEach(x => {
          const day = this.convert(x.year + '-' + x.month + '-' + x.day)
          if (day == this.mission.nextDay[j] && (x.shift.toLowerCase() == this.selectedShift1.toLowerCase() || x.shift.toLowerCase() == 'fd')) {
            this.mission.nextDay.splice(j, 1);
          }
        });
      }
      if (this.selectedShift1 !== "" && this.selectedShift1.toLowerCase() === "fd") {
        this.disabledDates.forEach(x => {
          const day = this.convert(x.year + '-' + x.month + '-' + x.day)
          if (day == this.mission.nextDay[j] && (x.shift.toLowerCase() == 'pm' || x.shift.toLowerCase() == 'am')) {
            this.mission.nextDay.splice(j, 1);
          }
        });
      }
      if (this.selectedShift2 !== "" && this.selectedShift2.toLowerCase() !== "fd") {
        this.disabledDates.forEach(x => {
          const day = this.convert(x.year + '-' + x.month + '-' + x.day)
          if (day == this.mission.nextDay[j] && (x.shift.toLowerCase() == this.selectedShift2.toLowerCase() || x.shift.toLowerCase() == 'fd')) {
            this.mission.nextDay.splice(j, 1);
          }
        });
      }

      if (this.selectedShift2 !== "" && this.selectedShift2.toLowerCase() === "fd") {
        this.disabledDates.forEach(x => {
          const day = this.convert(x.year + '-' + x.month + '-' + x.day)
          if (day == this.mission.nextDay[j] && (x.shift.toLowerCase() == 'pm' || x.shift.toLowerCase() == 'am')) {
            this.mission.nextDay.splice(j, 1);
          }
        });
      }
    }

    for (let item = 0; item < this.mission.nextDay.length; item++) {
      if (item == 0) {
        if (this.selectedShift1.toLowerCase() !== "fd") {
          obj.unavailablility.push({ date: (this.mission.nextDay[item]), shift: this.selectedShift1 });
        }
        else {
          obj.unavailablility.push({ date: (this.mission.nextDay[item]), shift: 'AM' }, { date: (this.mission.nextDay[item]), shift: 'PM' });
        }
      }
      else if (item == this.mission.nextDay.length - 1) {
        if (this.selectedShift2.toLowerCase() !== "fd") {
          obj.unavailablility.push({ date: (this.mission.nextDay[item]), shift: this.selectedShift2 });
        }
        else {
          obj.unavailablility.push({ date: (this.mission.nextDay[item]), shift: 'AM' }, { date: (this.mission.nextDay[item]), shift: 'PM' });
        }
      }
      else {
        this.data= null;
        this.disabledDates.forEach(o => {
          const day = this.convert(o.year + '-' + o.month + '-' + o.day);
          day == this.mission.nextDay[item]? this.data = o: null;
        });
        if(this.data == null){
          obj.unavailablility.push({ date: (this.mission.nextDay[item]), shift: 'AM' }, { date: (this.mission.nextDay[item]), shift: 'PM' });
         }
         else{
           this.mission.nextDay.splice(item,1);
           item=item-1;
         }
      }
    }

  }
  
  getDifference(useDate: any, miss: any) {
    const a = new Date(useDate);
    const b = new Date(miss);
    const diff = (b.getTime() - a.getTime()) / this._MS_PER_DAY;
    return diff;
  }

  getLeaves() {
    var startDate = new Date(this.mission.missionStartDate.year + '-' + this.mission.missionStartDate.month + '-' + this.mission.missionStartDate.day);
    var endDate = new Date(this.mission.missionEndDate.year + '-' + this.mission.missionEndDate.month + '-' + this.mission.missionEndDate.day);
    this.isStartDate = {
      year: startDate.getFullYear(), month:
        startDate.getMonth()+1, day: startDate.getDate()
    };

    this.isEndDate = {
      year: endDate.getFullYear(), month:
        endDate.getMonth()+1, day: endDate.getDate()
    };
   
    let daysCount = this.getDaysArray(startDate, endDate);
    daysCount.splice(daysCount.length - 1, 1);
    if (this.mission.nextDay.length == 0){
      daysCount.forEach(itm => {
        let convertDate = this.convert(itm);
        if (this.disabledDates.length > 0){
          let getIndex = this.disabledDates.findIndex((dt: any) => (String((dt.year + "-" + (dt.month < 10 ? "0" + dt.month : dt.month) + "-" + (dt.day < 10 ? "0" + dt.day : dt.day))) == String(convertDate)));
          if(getIndex == -1){
            this.mission.nextDay.push({ date: itm, shift: '' });            
          }

        } else {
          this.mission.nextDay.push({ date: itm, shift: '' });                    
        }
      });
    } else {
      let allDateArray = [];
      if(this.disabledDates.length > 0){
        this.disabledDates.forEach(dt => {
          let disableDate = dt.year + '-' + dt.month + '-' + (dt.day < 10 ? "0" + dt.day : dt.day); 
          allDateArray.push(disableDate);
        })
      }
      this.mission.nextDay.forEach(itm=>{
        let existDate = this.convert(itm.date);
        allDateArray.push(existDate);         
      });
      daysCount.forEach(res => {
        let compareNewDate = this.convert(res);
        if (allDateArray.indexOf(compareNewDate) == -1) {
          this.mission.nextDay.push({ date: res, shift: '' });
        }       
      });
    }   
  }  
}