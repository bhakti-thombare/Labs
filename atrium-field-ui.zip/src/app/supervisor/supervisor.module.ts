// core
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule , ReactiveFormsModule} from '@angular/forms';

// 3rd party
import { NgbModalModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TagInputModule } from 'ngx-chips';
import { ChartsModule } from 'ng2-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxMapboxGLModule } from 'ngx-mapbox-gl';
import { Ng4FilesModule } from 'angular4-files-upload';
import { TranslateModule } from '@ngx-translate/core';
import { NgSelectModule } from '@ng-select/ng-select';


// app
import { CONFIG } from '@app/config';
import { PipesModule } from '@pipes/pipes.module';
import { SupervisorRoutes } from '@app/supervisor/supervisor.routes';
import { DashboardComponent } from '@app/supervisor/dashboard/dashboard.component';
import { MissionsComponent } from '@app/supervisor/missions/missions.component';
import { CreateMissionComponent } from '@app/supervisor/create-mission/create-mission.component';
import { ProfileComponent } from '@app/supervisor/profile/profile.component';
import { MissionDetailsComponent } from '@app/supervisor/mission-details/mission-details.component';
import { CampaignsComponent } from '@app/supervisor/campaigns/campaigns.component';
import { EditMissionComponent } from '@app/supervisor/edit-mission/edit-mission.component';
import { CreateSurveyModule } from '@app/supervisor/create-survey/create-survey.module';
import { CreateLocationSurveyModule } from '@app/supervisor/create-location-survey/create-location-survey.module';
import { EditLocationSurveyModule } from "@app/supervisor/edit-location-survey/edit-location-survey.module";
import { EditSurveyModule } from '@app/supervisor/edit-survey/edit-survey.module';
import { MissionDetailsMModule } from "@app/supervisor/mission-details-m/mission-details-m.module";
import { CreateLocationComponent } from "@app/supervisor/create-location/create-location.component";
import { LocationComponent } from './location/location.component';
import {AccordionModule} from 'primeng/primeng';
import {MultiSelectModule} from 'primeng/primeng';
import { EditLocationComponent } from './edit-location/edit-location.component';
import { NgbdDatepickerPopup } from './datepicker-popup';
import { NgbDateFRParserFormatter } from './ngb-date-fr-parser-formatter';
import {NgbDateAdapter, NgbUTCStringAdapter} from './ngb-UTC-string-adapter';
import {ReassignPosComponent} from './mission-details-m/mission-progress-details/reassign/reassign-pos/reassign-pos.component';

// import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import {
    NgbDateParserFormatter,
  } from "@ng-bootstrap/ng-bootstrap";
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { CalendarComponent } from './calendar/calendar.component';
import { MissionDetailsStandsComponent } from './mission-details-stands/mission-details-stands.component';
import { StandReassignComponent } from './mission-details-stands/stand-reassign/stand-reassign.component';
import { SupervisorComponent } from './supervisor.component';

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(SupervisorRoutes),
        NgbModule,
        EditSurveyModule,
        MissionDetailsMModule,
        PipesModule,
        TranslateModule,
        NgxChartsModule,
        TagInputModule,
        MultiSelectModule,
        AccordionModule,
        Ng4FilesModule,
        FormsModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        NgbModalModule.forRoot(),
        // BrowserModule,
        FormsModule,
        HttpModule,
        NgxMapboxGLModule.forRoot({
            accessToken: CONFIG.mapBoxAccessToken
        }),
        NgSelectModule,
        CreateSurveyModule,
        CreateLocationSurveyModule,
        EditLocationSurveyModule,
        CommonModule,
        FormsModule
    ],
    declarations: [
        DashboardComponent,
        MissionsComponent,
        NgbdDatepickerPopup,
        CreateMissionComponent,
        ProfileComponent,
        MissionDetailsComponent,
        CampaignsComponent,
        EditMissionComponent,
        LocationComponent,
        CreateLocationComponent,
        EditLocationComponent,
        CalendarComponent,
        ReassignPosComponent,
        MissionDetailsStandsComponent,
        StandReassignComponent,
        SupervisorComponent
    ], providers: [
        {
        provide: NgbDateParserFormatter,
          useClass: NgbDateFRParserFormatter
        },
        {
            provide: NgbDateAdapter,
            useClass: NgbUTCStringAdapter
        },
      ],
      bootstrap: [MissionsComponent]
})
export class SupervisorModule { }
