// core
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { DatePipe } from '@angular/common';
import { AfterViewInit, OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
// 3rd party
import { Subscription } from 'rxjs/Subscription';
import { contains, where, isNull } from "underscore";
import { Observable } from 'rxjs';
import { NgbCalendar, NgbDateParserFormatter, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { SelectItem } from 'primeng/primeng';
import * as _ from 'lodash' ;
// app
import { Globals, statuses, missionTypes, DataConstants } from '@app/constants/constants';
import { MissionDateChangeModalComponent } from '@app/supervisor/edit-survey/mission-date-change-modal/mission-date-change-modal.component';
import { MissionListAlertsService } from '@services/Alerts/mission-list-alerts.service';
import { UTILS } from '@services/global-utility.service';
import { ApiService } from '@services/apiServices/api.service';
import { EventService } from '@services/events/event.service';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { StorageService } from '@app/services/storage-service.service';
import { CreateSurveyUtilsService } from '../create-survey/createSurveyUtils/create-survey-utils.service';
import {CampaignSummaryService} from '@services/campaign-summary/campaign-summary.service'

import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { debounceTime } from 'rxjs/operators';
import { DatePickerPopupComponent } from '@app/shared/date-picker-popup/date-picker-popup.component';
import { NgbdDatepickerPopup } from '../datepicker-popup';
import { TranslateService } from '@ngx-translate/core';
import { stringify } from 'querystring';



@Component({
  selector: 'app-new-missions',
  templateUrl: './missions.component.html',
  styleUrls: ['./missions.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class MissionsComponent implements OnInit, AfterViewInit, OnDestroy {
  agents: Array<any>=[];
  sections: SelectItem[];
  ampm: SelectItem[];
  status: SelectItem[];
  missionTypes:SelectItem[];
  selectedCars1: string[] = [];
  selectedCars2: string[] = [];
  private utilityFunctions = new UtilityFunctions();
  private subscriptions: Subscription[] = [];
  changeMissionDateModalRef: NgbModalRef;
  currentUser: any = JSON.parse(localStorage.getItem('user-data'));
  isSearch: boolean = false;
  missionLoader: boolean = false;
  campaignLoader: boolean = false;
  searchKey: '';
  utils = UTILS;
  campaings: Array<any> = [];
  missions: Array<any> = [];
  missions1: Array<any> = [];
  missionsAll: Array<any> = [];
  pagination: Array<any> = [];
  ngbDate: any = { fromDate: null, toDate: null };
  selectedCampaign: any = { 'campaignName': '' };
  AmPm: string;
  size: number;
  private sortReverse: boolean = false;
  private isClicked: boolean = true;

  sortType: string = 'missionName';

  type: string = 'type';
  property: any;
  datepickers = [];
  hoveredDate: NgbDate | null = null;

  fromDate: NgbDate | null;
  toDate: NgbDate | null;
  requestBody = {
    agent: [],
    section: [],
    status:[],
    types:[],
    shifts:[]
  }
   classic;
   shift=[];
   market=null;
   visit=null
   prm=null;
   checkpoint=null;
  agent=[];
  mayuri={ 'id':'','name':'' };
  missionName: any='';
  flag: boolean;
  campaignQueryParam: any='';
  missionType=this.translate.instant('Mission Type')
  @ViewChild('missionDate') myRangeInput: NgbdDatepickerPopup;
  constructor(
    public router: Router,
    public translate: TranslateService,
    public _event: EventService,
    public modalService: NgbModal,
    public apiService: ApiService,
    public datePipe: DatePipe,
    public missionListAlertsService: MissionListAlertsService,
    private storageService: StorageService,
    public custUtils: CreateSurveyUtilsService,
    private campaign:CampaignSummaryService,
    private calendar: NgbCalendar, public formatter: NgbDateParserFormatter, public route: ActivatedRoute
  ) {
      
    // translate.setDefaultLang('en');          
    // let browserLang = translate.getBrowserLang();         
    // translate.use(browserLang.match(/en|fr|nl/) ? browserLang: 'en')     
    this.subscriptions.push(this.apiService.getAgents({}).subscribe(res => {
      
    // console.log('agent',res.data); 
       this.agent=(res.data);
       this.agent.forEach(element => {
        this.agents.push(
          { label:element.name , value: element.id }
        );
      });
      this.missionTypes = [
        { label: this.translate.instant('Customer Survey'), value: '4' },
        { label: this.translate.instant('Pedestrian Flow'), value: '3' },
        { label: this.translate.instant('POS Survey'), value: '2' },
        { label: this.translate.instant('Stands'), value: '7' },
      ];
      this.sections = [
            { label: this.translate.instant('Classic'), value: 1 },
            { label: this.translate.instant('Visit'), value: 2 },
            { label: this.translate.instant('Market'), value: 3 },
            { label: this.translate.instant('PRM'), value: 4 },
            { label: this.translate.instant('Checkpoint'), value: 5 },
    
          ];  
                  this.missionType=this.translate.instant('Mission Type')
                  this.status = [
                    { label: this.translate.instant('Done'), value: '1' },
                    { label: this.translate.instant('In Progress'), value: '2' },
                    { label: this.translate.instant('Yet to assign'), value: '3' },
                    { label: this.translate.instant('Pending'), value: '4' },
                    { label: this.translate.instant('Yet to start'), value: '6' },
                    { label: this.translate.instant('Overdue'), value: '9' },
                  ];

      // this.missionType=this.translate.instant('Mission Type')

    }));

    this.fromDate = calendar.getToday();
    this.toDate = calendar.getNext(calendar.getToday(), 'd', 10);
  }

  ngOnInit() {
    this.missionTypes=[]

    // this.utils = UTILS;
   
    this.searchKey = '';
    this.isSearch = false;
    this.missionName='';
    this.flag=true;
    this.requestBody.types=null;
    this.market=null;
    this.checkpoint=null;
    this.classic=null;
    this.visit=null;
    this.prm=null;
    this.requestBody.agent=null;
    this.requestBody.status=null;
    this.sortReverse = false;
    this.isClicked = true;
    this._event.broadcast({ eventName: 'showLoader', data: '' });
    this.storageService.removeData('missionId&quartierId')
    this.getAllCampaigns();
    // this.route.params.subscribe(params => {
    //   this.ngbDate = params.ngbDate;
    // });
    // if(this.translate.instant('Classic')=='Classique'){
    //   this.sections = [
    //     { label: 'Classique', value: 1 },
    //     { label: this.translate.instant('Visit'), value: 2 },
    //     { label: this.translate.instant('Market'), value: 3 },
    //     { label: this.translate.instant('PRM'), value: 4 },
    //     { label: this.translate.instant('Checkpoint'), value: 5 },

    //   ];
    // }
    // else if(this.translate.instant('Classic')=='Klassiek'){
    //   this.sections = [
    //     { label: 'Klassiek', value: 1 },
    //     { label: this.translate.instant('Visit'), value: 2 },
    //     { label: this.translate.instant('Market'), value: 3 },
    //     { label: this.translate.instant('PRM'), value: 4 },
    //     { label: this.translate.instant('Checkpoint'), value: 5 },

    //   ];
    // }
    // else{
    //   this.sections = [
    //     { label: 'Classic', value: 1 },
    //     { label: 'Visit', value: 2 },
    //     { label: 'Market', value: 3 },
    //     { label: 'PRM', value: 4 },
    //     { label: 'Checkpoint', value: 5 },

    //   ];
    // }
     
     
      this.ampm = [
        { label: 'AM', value: 'AM' },
        { label: 'PM', value: 'PM' }
      ];
  
    //   if(this.translate.instant('Done')=='Terminée'){
    //     this.status = [
    //       { label: 'Terminée', value: '1' },
    //       { label: this.translate.instant('In Progress'), value: '2' },
    //       { label: this.translate.instant('Yet to assign'), value: '3' },
    //       { label: this.translate.instant('Pending'), value: '4' },
    //       { label: this.translate.instant('Yet to start'), value: '6' },
    //       { label: this.translate.instant('Overdue'), value: '9' },
    //     ];
    
    //   }
    //   else if(this.translate.instant('Done')=='Klaar'){
    //   this.status = [
    //     { label: 'Klaar', value: '1' },
    //     { label: this.translate.instant('In Progress'), value: '2' },
    //     { label: this.translate.instant('Yet to assign'), value: '3' },
    //     { label: this.translate.instant('Pending'), value: '4' },
    //     { label: this.translate.instant('Yet to start'), value: '6' },
    //     { label: this.translate.instant('Overdue'), value: '9' },
    //   ];
    // }
    // else{
    //   this.status = [
    //     { label: 'Done', value: '1' },
    //     { label: ('In Progress'), value: '2' },
    //     { label:('Yet to assign'), value: '3' },
    //     { label: ('Pending'), value: '4' },
    //     { label: ('Yet to start'), value: '6' },
    //     { label: ('Overdue'), value: '9' },
    //   ];
    // }

    this.route.params.subscribe(params => {
      this.campaignQueryParam = params['campName'];
    });
  }

  ngAfterViewInit() { }

  /* API Requests */
  getAllMissions(size) {
    this.missionLoader = true;
    this.subscriptions.push(this.apiService.getRefMissions({ 'createdBy': this.currentUser.userId, 'sortBy': 'missionCreationDate,desc', 'size': size, 'campaignId': this.campaign.selectedCampaign? this.campaign.selectedCampaign.campaignId : 0 },
      {
        "missionType": [],
        "classic": null,
        "market": null,
        "prm": null,
        "visits": null,
        "agent": [],
        "shift" : [],
        "missionStatus": [],
        "missionStartDate": "",
        "missionEndDate": "",
        "checkpoint":null
      })
      // this.subscriptions.push(this.apiService.getRefMissions({'createdBy': 93,'sortBy':'missionName,asc','campaignId': 145})
      .subscribe(res => {
        // console.log('res',res.data.content);
        this.pagination = res.data;
        this.missionsAll = res.data.content;
        this.missions = (!isNull(res.data.content)) ? res.data.content : [];
        this.getSubTypes(this.missions);
        this.missions.forEach(element => {
          element.missionType.name=this.translate.instant(element.missionType.name)
          element.missionStatus.statusName=this.translate.instant(element.missionStatus.statusName)

          // element.AmPm = (!isNull(element.missionStartDate)) ? this.getAmPm(element.missionStartDate) : 'NA';
          element.missionStartDate = (!isNull(element.missionStartDate)) ? element.missionStartDate.slice(0, element.missionStartDate.indexOf(' ')) : 'NA';
          element.agent = (!isNull(element.agent)) ? (element.agent.firstName + " "+ element.agent.lastName) : 'NA';
          element.shift = (!isNull(element.shift)) ? (element.shift.shiftName) : 'NA';
        });
        // console.log('res', this.missions);
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.missionLoader = false;

      }, err => {
        this.missionsAll = [];
        this.missions = [];
        this.campaignLoader = false;
        this.missionLoader = false;
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        // this.getAllCampaigns();
      }));
  }

  getAmPm(dateStr) {
    const date = dateStr.split(' ')[0];
    const time = dateStr.split(' ')[1];
    const day = parseInt(date.split('-')[2], 10);
    const month = parseInt(date.split('-')[1], 10);
    const year = parseInt(date.split('-')[0], 10);
    let hour = parseInt(time.split(':')[0], 10);
    const minute = parseInt(time.split(':')[1], 10);
    const second = parseInt(time.split(':')[2], 10);
    let pm = false;
    const localDateString = new Date(Date.UTC(year, month - 1, day, hour, minute, second));
    const monthNames = DataConstants.MONTHS;
    pm = localDateString.getHours() >= 12 ? true : false;
    let hours = localDateString.getHours() % 12;
    hours = hours ? hours : 12;
    const amPM = pm ? 'PM' : 'AM';
    return amPM;
  }

  public subtypes: string[] = [
    'Classic',
    'Market',
    'Visit',
    'PRM'
  ];

  getSubTypes(missions) {
    missions.forEach(element => {
     
     if(element.market == true && element.classic == true){
        element.missionSubType = 'Classic/Market';
      }
      else if (element.classic == true && element.visits == true && element.prm == true) {
        element.missionSubType = 'Classic/PRM/Visits';
      }
      else if (element.classic == true && element.visits == true) {
        element.missionSubType = 'Classic/Visits';
      } else if (element.classic == true && element.prm == true) {
        element.missionSubType = 'Classic/PRM';
      }else if(element.prm == true){
        element.missionSubType = 'PRM';
      }else if(element.visits == true){
        element.missionSubType = 'Visits';
      }else if (element.classic == true) {
        element.missionSubType = 'Classic';
      }
      else if (element.market == true) {
        element.missionSubType = 'Market';
      }
      else {
        element.missionSubType = 'NA';
      }
    });
  }

  getAllCampaigns() {
    this.size = 10;
    this.subscriptions.push(this.apiService.getAllCampaigns({ 'assignedTo': this.currentUser.userId })
      .subscribe(res => {
        if (res) {
          this.campaings = res.data.campaigns;
          console.log(this.campaign);
          if (this.campaign.selectedCampaign) {
            if (this.campaignQueryParam != undefined) {
              let data = this.campaings.filter(res => res.campaignName == this.campaignQueryParam);
              this.selectedCampaign = data[0];
              this.campaign.selectedCampaign = this.selectedCampaign;
            } else{
              this.selectedCampaign = this.campaign.selectedCampaign;
            }
          }
          else {
            if (this.campaignQueryParam !=undefined) {
              let data = this.campaings.filter(res => res.campaignName == this.campaignQueryParam);
              this.selectedCampaign = data[0];
              this.campaign.selectedCampaign = this.selectedCampaign;
            } else {
              this.selectedCampaign = this.campaings[0];
              this.campaign.selectedCampaign = this.selectedCampaign;
            }
          }
          // console.log("this.campaign.selectedCampaign=",this.campaign.selectedCampaign);
          this.campaignLoader = false;
          // this.getMissionsByCampaignId(this.selectedCampaign.campaignId);
        }
        this.getAllMissions(this.size);
      }, err => {
        this.campaings = [];
        this.getAllMissions(this.size);
        // this._event.broadcast({ eventName: 'Loader', data: '' });
      }));
  }
  /* API Requests */

  /* setters */
  selectCampaign(campaign) {
    this.missionLoader = true;
    console.log("campaign=", campaign);
    const today = new Date()
    const campaignEndDate = new Date(campaign.campaignEndDate)
    if (!(campaignEndDate < today)) {
      console.log("here it is");
      this.campaign.selectedCampaign = campaign;
    }
    this.campaign.selectedCampaign=campaign;
    this.selectedCampaign = campaign;
    this.getAllMissions(10);
  }
  /* setters */

  /* getters */
  // invalidStatus: Array<any> = [3, 6]
  getDetails(mission) {
    this.storageService.setData('currentStatusId', mission.missionStatus.statusId);
    if (mission.missionStatus.statusId === 9 || mission.missionStatus.statusId === 2 || mission.missionStatus.statusId === 1 || mission.missionStatus.statusId === 25) {
      if (mission.missionStatus.statusId === 9) { this.storageService.setData('enableButton', 'true'); }
      if (mission.missionType.id === 3 || mission.missionType.id === 4) {
        this.subscriptions.push(this.apiService.getMissionProgressReport({ 'missionId': mission.missionId })
          .subscribe(res => {
            this.router.navigate(['/supervisor/missions/details/' + mission.missionId + '/' + mission.missionType.id]);
          }, err => {
            this.missionListAlertsService.noReportsGenerateAlert();
          }));
      } else if (mission.missionType.id === 2) {
        this.router.navigate(['/supervisor/missions/details/' + mission.missionId + '/' + mission.missionType.id]);
      }
    } else {
      if (mission.missionStatus.statusId === 3 || mission.missionStatus.statusId === 6) {
        this.missionListAlertsService.noReportsGenerateAlert();
      }
      // else if (mission.missionStatus.statusId === 6) { 
      //   console.log('disable');
      // }
    }
  }

  getMissionDates(currentDate, mission) {
    let missionType = mission.missionType.id;
    this.subscriptions.push(this.apiService.getUsedMissionDatesObject({ currentDate, missionType })
      .subscribe(res => {
        let DTO = res.dateDto;
        Globals.BUSY_DATES = DTO;
        let currDate = UTILS.getDatePickerDateFormat(new Date());
        let currentDString = { day: currDate.day.toString(), month: currDate.month.toString(), year: currDate.year.toString() };
        if (where(DTO, currentDString).length == 0) { this.gotoEdit(mission.missionId); }
        else { this.getMissionDateChangeModal(mission); }
      }, err => { this.gotoEdit(mission.missionId); }));
  }

  getMissionsByCampaignId(campaignId, missionId = undefined) {
    this.subscriptions.push(this.apiService.getMissionsByCampaignId({ missionId, campaignId })
      .subscribe(res => {
        this.missions = (!isNull(res.data)) ? res.data : [];
        // console.log(this.missions);
        this.missionLoader = false;
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
      }, err => {
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.missionLoader = false;
        this.missionsAll = [];
        this.missions = [];
      }));
  }

  getMissionDateChangeModal(mission) {
    this.changeMissionDateModalRef = this.modalService.open(MissionDateChangeModalComponent);
    this.changeMissionDateModalRef.componentInstance.missionId = mission.missionId;
    this.changeMissionDateModalRef.result.then((result) => {
      if (result != 'closed') { this.getAllCampaigns(); }
    }).catch((err) => { });
  }
  getCampainsDates(mission) {
    let campaignStartDate_ = new Date(mission.missionCampaign.campaignStartDate).getTime();
    let campaignEndDate_ = new Date(mission.missionCampaign.campaignEndDate).getTime();
    let missionDate_ = new Date(mission.missionStartDate).getTime();
    if(stringify(missionDate_) == 'NaN' && mission.missionStatus.statusId == statuses.YETTOASSIGN)
       return campaignStartDate_ <= missionDate_ && campaignEndDate_ >= missionDate_;
    else
       return true;
  }
  /* getters */
  /* Search and toggle the search input box */

  isCampaignExpired(mission){
    const today = new Date();
    const todaydate = new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate()
    );
    return mission.missionCampaign.campaignEndDate? (new Date(mission.missionCampaign.campaignEndDate)< todaydate)?false:true:true;
  }

  clearSearch() {
    this.requestBody.types=null;
    this.searchKey = '';
    this.isSearch = false;
    this.missionName='';
    this.flag=true;
    this.market=null;
    this.classic=null;
    this.visit=null;
    this.checkpoint=null;
    this.prm=null;
    this.shift=[];
    this.ngbDate.fromDate=null;
    this.ngbDate.toDate=null;
    this.requestBody.agent=null;
    this.requestBody.status=null;
    this.myRangeInput.clearDate();
    this.getAllMissions(10);
  }

  // formatter = (result: any) => result.missionName.toUpperCase();

  searchMissionsAndToggle(_searchKey, event) {
    // console.log('insdie search', _searchKey);
    this.missionName = 'missionName,' + _searchKey;
    if (_searchKey && event.keyCode === 13) {

      this.missionLoader = true;
      this.subscriptions.push(this.apiService.getRefMissions({ 'createdBy': this.currentUser.userId, 'sortBy': 'missionCreationDate,desc', 'size': 10, 'searchBy': this.missionName, campaignId: this.selectedCampaign.campaignId },
        {
          "missionType": this.requestBody.types? this.requestBody.types: [],
            "classic": this.classic? this.classic:null,
            "market": this.market? this.market:null,
            "prm": this.prm? this.prm :null,
            "visits": this.visit? this.visit :null,
            "agent": this.requestBody.agent? this.requestBody.agent:[],
            "checkpoint":this.checkpoint?true:null,
            "shift" : this.shift? this.shift:[],
            "missionStatus":this.requestBody.status? this.requestBody.status : [],
            "missionStartDate": (this.ngbDate.fromDate!==null)? this.ngbDate.fromDate.year+ '-'+this.ngbDate.fromDate.month+'-'+this.ngbDate.fromDate.day :'',
            "missionEndDate": (this.ngbDate.toDate!==null)? this.ngbDate.toDate.year + '-'+this.ngbDate.toDate.month+'-'+this.ngbDate.toDate.day:''
        }).subscribe(res => {
          this.pagination = res.data;
          this.missionsAll = res.data.content;
          this.missions = (!isNull(res.data)) ? res.data.content : [];
          this.getSubTypes(this.missions);
          this.missions.forEach(element => {
            element.missionType.name=this.translate.instant(element.missionType.name)
            element.missionStatus.statusName=this.translate.instant(element.missionStatus.statusName)
            // element.AmPm = (!isNull(element.missionStartDate)) ? this.getAmPm(element.missionStartDate) : 'NA';
            element.missionStartDate = (!isNull(element.missionStartDate)) ? element.missionStartDate.slice(0, element.missionStartDate.indexOf(' ')) : 'NA';
            element.agent = (!isNull(element.agent)) ? (element.agent.firstName + " "+ element.agent.lastName) : 'NA';
            element.shift = (!isNull(element.shift)) ? (element.shift.shiftName) : 'NA';
          });
          this.missionLoader = false;
          // console.log(this.missions);
        }, err => {
          this.missionsAll = [];
          this.missions = [];
          this.campaignLoader = false;
          this.missionLoader = false;
          this._event.broadcast({ eventName: 'hideLoader', data: '' });
          // this.getAllCampaigns();
        }));
    }
  }

  filterBySections(event, section) {
    if (event.length!==0 ) {
    var agent = [];
      event.forEach((element) => {
        agent.push(element);
        element='';
      });
      event.includes(5)?this.checkpoint=true:this.checkpoint=null
      if ((agent[0] == 1 && agent[1] == 3 && agent.length == 2)||(agent[1] == 1 && agent[0] == 3 && agent.length == 2)) {
        this.market = true; this.classic = true; this.visit=null; this.prm=null;
        // event.includes(5)?this.checkpoint=true:null
      }
      else if ((agent[0] == 1 && agent[1] == 4 && agent[2] == 2 && agent.length == 3) || (agent[0] == 2 && agent[1] == 4 && agent[2] == 1 && agent.length == 3) || (agent[0] == 1 && agent[1] == 2 && agent[2] == 4 && agent.length == 3)
      || (agent[0] == 4 && agent[1] == 2 && agent[2] == 1 && agent.length == 3) || (agent[0] == 2 && agent[1] == 1 && agent[2] == 4 && agent.length == 3) ||  (agent[0] == 4 && agent[1] == 1 && agent[2] == 2 && agent.length == 3) ) {
        this.classic = true; this.visit = true; this.prm = true;  this.market=null; 
        // event.includes(5)?this.checkpoint=true:null

      } 
      else if ((agent[0] == 1 && agent[1] == 2 && agent.length == 2) || (agent[1] == 1 && agent[0] == 2 && agent.length == 2)) {
        this.visit = true; this.classic = true;  this.market=null; this.prm=null;
        // event.includes(5)?this.checkpoint=true:null

      } else if ((agent[0] == 1 && agent[1] == 4 && agent.length == 2)|| (agent[1] == 1 && agent[0] == 4 && agent.length == 2)) {
        this.prm = true; this.classic = true;  this.visit=null; this.market=null;
        // event.includes(5)?this.checkpoint=true:null

      } else if (agent[0] == 1 && agent.length == 1) {
        console.log('classic');
        this.classic = true;  this.visit=null; this.prm=null; this.market=null;
        // event.includes(5)?this.checkpoint=true:null

      } else if (agent[0] == 3 && agent.length == 1) {
        // console.log('market', this.translate.instant(agent[0]));
        this.market = true;  this.visit=null; this.prm=null; this.classic=null;
        // event.includes(5)?this.checkpoint=true:null

      }

      else if (agent[0] == 2 && agent.length == 1) {
        this.visit = true; this.classic = null; this.prm = null; this.market = null;
        // event.includes(5)?this.checkpoint=true:null

      }
      else if (agent[0] == 4 && agent.length == 1) {
        this.visit = null; this.classic = null; this.prm = true; this.market = null;
        // event.includes(5)?this.checkpoint=true:null

      }
      else if (agent[0] == 4 && agent[1] == 2) {
        this.visit = true; this.classic = null; this.prm = true; this.market = null;
        // event.includes(5)?this.checkpoint=true:null

      }
      else if (agent[0] == 2 && agent[1] == 4) {
        this.visit = true; this.classic = null; this.prm = true; this.market = null;
        // event.includes(5)?this.checkpoint=true:null

      }
      else if (agent[1] == 2 && agent[0] == 4) {
        this.visit = true; this.classic = null; this.prm = true; this.market = null;
        // event.includes(5)?this.checkpoint=true:null

      }else if(event.includes(5) && event.includes(3)){
        this.custUtils.translateMessageObject({
          title: 'Please enter valid input',
          text: '',
          type: 'error',
          outsideClick: true,
          showCancelBtn: false,
          confirmBtnText: 'OK',
          cancelBtnText: ''
        }, (responseMessageObject) => {
          this.custUtils.translateAndPop(responseMessageObject).then(() => {

          }).catch(() => {

          });
        });
      }
      else if(event.includes(5)){
        event.includes(1)?this.classic=true:this.classic=null;
        event.includes(2)?this.visit=true:this.visit=null;
        event.includes(3)?this.market=true:this.market=null;
        event.includes(4)?this.prm=true:this.prm=null;

        this.checkpoint=true;
      } 
     
      // else if (agent[0] == 2 && agent.length == 1) {
       
      //   this.visit = true;  this.classic=null; this.prm=null; this.market=null;
      // } else if (agent[0] == 4 && agent.length == 1) {
       
      //   this.prm = true;  this.visit=null; this.classic=null; this.market=null;
      // }
      else {
            this.custUtils.translateMessageObject({
              title: 'Please enter valid input',
              text: '',
              type: 'error',
              outsideClick: true,
              showCancelBtn: false,
              confirmBtnText: 'OK',
              cancelBtnText: ''
            }, (responseMessageObject) => {
              this.custUtils.translateAndPop(responseMessageObject).then(() => {
    
              }).catch(() => {
    
              });
            });
      }
    }
    else{
      this.prm = null;  this.visit=null; this.classic=null; this.market=null;this.checkpoint=null;
    }
  }

  filterByAgents(event) {
    var agent = [];
    if (event.length !== 0) {
      event.forEach((element) => {
        agent.push(element);
      });
      this.requestBody.agent = agent;

      //   this.subscriptions.push(this.apiService.getRefMissions({ 'createdBy': this.currentUser.userId, 'sortBy': 'missionCreationDate,desc', 'size': 10, campaignId: this.selectedCampaign.campaignId },
      //   {
      //     "missionType": [],
      //     "classic": true,
      //     "market": null,
      //     "prm": true,
      //     "visits": true,
      //     "agent": this.requestBody.agent,
      //     "missionStatus": [],
      //     "missionStartDate": "",
      //     "missionEndDate": ""
      //   }).subscribe(res => {
      //     this.pagination = res.data;
      //     this.missionsAll = res.data.content;
      //     this.missions = (!isNull(res.data)) ? res.data.content.reverse() : [];
      //     this.getSubTypes(this.missions);
      //     this.missions.forEach(element => {
      //       element.AmPm = (!isNull(element.missionStartDate)) ? this.getAmPm(element.missionStartDate) : 'NA';
      //       element.missionStartDate = (!isNull(element.missionStartDate)) ? element.missionStartDate.slice(0, element.missionStartDate.indexOf(' ')) : 'NA';

      //     });
      //     this.missionLoader = false;
      //     console.log(this.missions);
      //   }, err => {
      //     this.missionsAll = [];
      //     this.missions = [];
      //     this.campaignLoader = false;
      //     this.missionLoader = false;
      //     this._event.broadcast({ eventName: 'hideLoader', data: '' });
      //     // this.getAllCampaigns();
      //   }));
    }
    else {
      this.requestBody.agent = null;
    }
  }

  filterByShifts(event) {
    var shift = [];
    if (event.length !== 0) {
      event.forEach((element) => {
        shift.push(element);
      });
    this.requestBody.shifts = shift;
    if((this.requestBody.shifts[0]=='AM' && this.requestBody.shifts[1]== 'PM')
    ||(this.requestBody.shifts[0]=='PM' && this.requestBody.shifts[1]== 'AM')){
      console.log('hi');
      this.shift[0] = 1;
      this.shift[1] = 2;
    }
    else if (this.requestBody.shifts[0] == 'AM') {
      console.log('AM');
      this.shift[0] = 1; 
    }
    else if (this.requestBody.shifts[0]== 'PM') {
      console.log('PM');
      this.shift[0] = 2; 
    }

    // var item=this.shift;
    // this.missions = this.missions.filter(o => {
    // for (var item of items) {
    //     var flag = false;
    //     for (var prop in o) {
    //       if (prop != '$$hashKey' && (o[prop] + '').toLowerCase().indexOf(item) != -1) {
    //         flag = true;
    //         break;
    //       }
    //     }
    //     if (!flag)
    //       return false;
    //   // }
    //   return true;
    // });
    }
  else {
    this.requestBody.shifts = null;
    this.shift=[];
  }
  }

  filterByStatus(event) {
    var status = [];
    var id = [];
    if (event.length !== 0) {
      event.forEach((element) => {
        status.push(element);
      });
      this.requestBody.status = status;
      // id=this.getStatusId(this.requestBody.status);
      // this.subscriptions.push(this.apiService.getRefMissions({ 'createdBy': this.currentUser.userId, 'sortBy': 'missionCreationDate,desc', 'size': 10, campaignId: this.selectedCampaign.campaignId },
      // {
      //   "missionType": [],
      //   "classic": true,
      //   "market": null,
      //   "prm": true,
      //   "visits": true,
      //   "agent": this.requestBody.agent,
      //   "missionStatus": this.requestBody.status,
      //   "missionStartDate": "",
      //   "missionEndDate": ""
      // }).subscribe(res => {
      //   this.pagination = res.data;
      //   this.missionsAll = res.data.content;
      //   this.missions = (!isNull(res.data)) ? res.data.content.reverse() : [];
      //   this.getSubTypes(this.missions);
      //   this.missions.forEach(element => {
      //     element.AmPm = (!isNull(element.missionStartDate)) ? this.getAmPm(element.missionStartDate) : 'NA';
      //     element.missionStartDate = (!isNull(element.missionStartDate)) ? element.missionStartDate.slice(0, element.missionStartDate.indexOf(' ')) : 'NA';

      //   });
      //   this.missionLoader = false;
      //   console.log(this.missions);
      // }, err => {
      //   this.missionsAll = [];
      //   this.missions = [];
      //   this.campaignLoader = false;
      //   this.missionLoader = false;
      //   this._event.broadcast({ eventName: 'hideLoader', data: '' });
      //   // this.getAllCampaigns();
      // }));
    }
    else {
      this.requestBody.status = null;
    }
  }

  filterByMissionType(event) {
    var type = [];
    if (event.length !== 0) {
      event.forEach((element) => {
        type.push(element);
      });
      this.requestBody.types = type;

      // this.subscriptions.push(this.apiService.getRefMissions({ 'createdBy': this.currentUser.userId, 'sortBy': 'missionCreationDate,desc', 'size': 10, campaignId: this.selectedCampaign.campaignId },
      // {
      //   "missionType": this.requestBody.types,
      //   "classic": true,
      //   "market": null,s
      //   "prm": true,
      //   "visits": true,
      //   "agent": this.requestBody.agent,
      //   "missionStatus": this.requestBody.status,
      //   "missionStartDate": "",
      //   "missionEndDate": ""
      // }).subscribe(res => {
      //   this.pagination = res.data;
      //   this.missionsAll = res.data.content;
      //   this.missions = (!isNull(res.data)) ? res.data.content.reverse() : [];
      //   this.getSubTypes(this.missions);
      //   this.missions.forEach(element => {
      //     element.AmPm = (!isNull(element.missionStartDate)) ? this.getAmPm(element.missionStartDate) : 'NA';
      //     element.missionStartDate = (!isNull(element.missionStartDate)) ? element.missionStartDate.slice(0, element.missionStartDate.indexOf(' ')) : 'NA';

      //   });
      //   this.missionLoader = false;
      //   console.log(this.missions);
      // }, err => {
      //   this.missionsAll = [];
      //   this.missions = [];
      //   this.campaignLoader = false;
      //   this.missionLoader = false;
      //   this._event.broadcast({ eventName: 'hideLoader', data: '' });
      //   // this.getAllCampaigns();
      // }));
    }
    else {
      this.requestBody.types = null;
    }

  }

  search = (_searchKey: Observable<string>) => {
    return _searchKey.
      debounceTime(100).
      distinctUntilChanged().
      map(term => term.length < 2 ? []
        : this.missions.filter(v => v.missionName.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10)
      )
  }
  /* Search and toggle the search input box */

  /* redirectors */
  editMission(mission, dateModal) {
    if (this.isCampaignExpired(mission)) {
      if (mission.missionStartDate == 'NA' && this.getCampainsDates(mission)) {
        this.gotoEdit(mission.missionId);
      } else {
        let isValid = this.isValidMissionDate(UTILS.getDatePickerDateFormat(mission.startDate));
        if (this.getCampainsDates(mission)) {
          if ((mission.missionStatus.statusId == statuses.YETTOASSIGN || mission.missionStatus.statusId == statuses.YETTOSTART || mission.missionStatus.statusId == statuses.REASSIGNED) && isValid) {
            this.getMissionDates(UTILS.getDateFormatWithoutZero(UTILS.getDatePickerDateFormat(mission.startDate)), mission);
          } else if ((mission.missionStatus.statusId == statuses.YETTOASSIGN || mission.missionStatus.statusId == statuses.YETTOSTART || mission.missionStatus.statusId == statuses.REASSIGNED) && !isValid) {
            this.getMissionDates(UTILS.getDateFormatWithoutZero(UTILS.getDatePickerDateFormat(new Date())), mission);
          }
        } else {
          if (mission.missionType.id == missionTypes.POS_POI_TYPE_ID && isNull(mission.startDate)) this.gotoEdit(mission.missionId);
          else this.missionListAlertsService.campainIsExpireAlert();
        }
      }
    }
    else this.missionListAlertsService.campainIsExpireAlert();
    // else {
    //   if (isNull(mission.startDate)) 
    //       this.gotoEdit(mission.missionId);
    //   else this.missionListAlertsService.campainIsExpireAlert();
    // }
  }
  gotoEdit(missionId) { this.router.navigate([`/supervisor/missions/edit/${missionId}`]); }
  /* redirectors */

  /* dynamic css */
  dropdownClicked($event) { }
  /* Validators */
  isValidMissionDate(d) {
    let currentDate_ = new Date(UTILS.getDateFormatWithoutZero(UTILS.getDatePickerDateFormat(new Date()))).getTime();
    let startDateMission = new Date(UTILS.getDateFormatWithoutZero(d)).getTime();
    return startDateMission > currentDate_;
  }
  /* Validators */
  /* Local Utility functions */
  getTransformedDate(d: string) {
    const d_ = (d) ? new Date(d.replace(/\s/g, "T")) : null;
    if (d_) return this.datePipe.transform(d_, 'yyyy-MM-dd');
    else return 'NA';
  }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }

  /* Search and toggle the search input box */
  sortOrders(property, event) {
    console.log("event=",event);
    this.property = event.target.id;
    this.sortType = this.property;
    this.sortReverse = !this.sortReverse;
    this.isClicked = !this.isClicked;
    this.missions=_.orderBy(this.missions,this.property,property );

    // this.missions.sort(this.dynamicSort(this.property));
  }

  sortOrders9(property, event) {
    console.log("event=",event);
    this.property = event.target.id;
    this.sortType = this.property;
    this.sortReverse = !this.sortReverse;
    this.isClicked = !this.isClicked;
    const evaluated = this.missions.filter(x =>x.isEvaluated === true &&  x.missionStatus.statusId == 1 
      || x.isEvaluated === true &&  x.missionStatus.statusId == 9 
      || x.isEvaluated === true &&  x.missionStatus.statusId == 2 );
      const toEvaluate = this.missions.filter(x =>x.isEvaluated === false &&  x.missionStatus.statusId == 2
        || x.isEvaluated === false &&  x.missionStatus.statusId == 9 );
        const notRequired = this.missions.filter(x =>x.isEvaluated === false &&  x.missionStatus.statusId == 6 
          || x.isEvaluated === false &&  x.missionStatus.statusId == 3 
          || x.isEvaluated === false &&  x.missionStatus.statusId == 10 );
      if(property === 'asc'){
       this.missions =  evaluated.concat(notRequired, toEvaluate);
      }
      else{
        this.missions =  toEvaluate.concat(notRequired, evaluated);
      }
    // this.missions.sort(this.dynamicSort(this.property));
  }

  sortOrders1(property, event) {
    console.log("missions=",this.missions);
    this.property = event.target.id;
    this.type = this.property;
    this.sortReverse = !this.sortReverse;
    this.isClicked = !this.isClicked;
    this.missions=_.orderBy(this.missions,'missionStatus.statusName',property );
  }
  sortOrders3(property, event) {
    this.property = event.target.id;
    this.type = this.property;
    this.sortReverse = !this.sortReverse;
    this.isClicked = !this.isClicked;
    this.missions.sort(this.dynamicSort3(this.property));
  }
  dynamicSort1(property) {
    let sortOrder = 1;

    if (this.sortReverse)
      sortOrder = -1;
    return function (a, b) {
      // console.log(property);
      let result = (a[property].statusName < b[property].statusName) ? -1 : (a[property].statusName > b[property].statusName) ? 1 : 0;

      return result * sortOrder;
    }
  }

  sortOrders2(property, event) {
    console.log("event=",property);
    console.log("missions=",this.missions);
    
    this.property = event.target.id;
    this.type = this.property;
    this.sortReverse = !this.sortReverse;
    this.isClicked = !this.isClicked;
    console.log("event=",event,this.property);

    // this.missions.sort(this.dynamicSort2(this.property));
    this.missions=_.orderBy(this.missions,'missionType.name',property );

  }

  dynamicSort2(property) {
    let sortOrder = 1;

    if (this.sortReverse)
      sortOrder = -1;
    return function (a, b) {
      // console.log(property);
      let result = (a[property].name < b[property].name) ? -1 : (a[property].name > b[property].name) ? 1 : 0;

      return result * sortOrder;
    }
  }

  dynamicSort3(property) {
    let sortOrder = 1;
    if (this.sortReverse)
      sortOrder = -1;
    return function (a, b) {
      console.log(a,b);
      let result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;

      return result * sortOrder;
    }
  }


  dynamicSort(property) {
    let sortOrder = -1;

    if (this.sortReverse) {
      sortOrder = 1;
    }
    return function (a, b) {
      console.log('a', a);
      let result = (a[property].toLowerCase() < b[property].toLowerCase()) ? -1 : (a[property].toLowerCase() > b[property].toLowerCase()) ? 1 : 0;

      let data = result * sortOrder;
      return data;
    }
  }

  viewMore(pagination) {
    // if(pagination.numberOfElements==10 && pagination.last==false){
    pagination.numberOfElements = 10 + pagination.numberOfElements;
    // }
    // this.getAllMissions(pagination.numberOfElements);
    if(this.missionName){
      this.missionLoader = true;
      this.subscriptions.push(this.apiService.getRefMissions({ 'createdBy': this.currentUser.userId, 'sortBy': 'missionCreationDate,desc', 'size': pagination.numberOfElements, 'searchBy': this.missionName, campaignId: this.selectedCampaign.campaignId },
        {
          "missionType": this.requestBody.types? this.requestBody.types: [],
          "classic": this.classic? this.classic:null,
          "market": this.market? this.market:null,
          "checkpoint":this.checkpoint?true:null,
          "prm": this.prm? this.prm :null,
          "visits": this.visit? this.visit :null,
          "shift" : this.shift? this.shift:[],
          "agent": this.requestBody.agent? this.requestBody.agent:[],
          "missionStatus":this.requestBody.status? this.requestBody.status : [],
          "missionStartDate":  (this.ngbDate!==null)? this.ngbDate.fromDate.year+ '-'+this.ngbDate.fromDate.month+'-'+this.ngbDate.fromDate.day :'',
          "missionEndDate":  (this.ngbDate!==null)? this.ngbDate.toDate.year + '-'+this.ngbDate.toDate.month+'-'+this.ngbDate.toDate.day:''    
        }).subscribe(res => {
          this.pagination = res.data;
          this.missionsAll = res.data.content;
          this.missions = (!isNull(res.data)) ? res.data.content : [];
          this.getSubTypes(this.missions);
          this.missions.forEach(element => {
            element.missionType.name=this.translate.instant(element.missionType.name)
            element.missionStatus.statusName=this.translate.instant(element.missionStatus.statusName)
            // element.AmPm = (!isNull(element.missionStartDate)) ? this.getAmPm(element.missionStartDate) : 'NA';
            element.missionStartDate = (!isNull(element.missionStartDate)) ? element.missionStartDate.slice(0, element.missionStartDate.indexOf(' ')) : 'NA';
            element.agent = (!isNull(element.agent)) ? (element.agent.firstName + " "+ element.agent.lastName) : 'NA';
            element.shift = (!isNull(element.shift)) ? (element.shift.shiftName) : 'NA';
          });
          this.missionLoader = false;
          // console.log(this.missions);
        }, err => {
          this.missionsAll = [];
          this.missions = [];
          this.campaignLoader = false;
          this.missionLoader = false;
          this._event.broadcast({ eventName: 'hideLoader', data: '' });
          // this.getAllCampaigns();
        }));
    
  }else{  
  this.subscriptions.push(this.apiService.getRefMissions({ 'createdBy': this.currentUser.userId, 'sortBy': 'missionCreationDate,desc', 'size': pagination.numberOfElements, campaignId: this.selectedCampaign.campaignId },
  {
    "missionType": this.requestBody.types? this.requestBody.types: [],
    "classic": this.classic? this.classic:null,
    "market": this.market? this.market:null,
    "checkpoint":this.checkpoint?true:null,
    "prm": this.prm? this.prm :null,
    "visits": this.visit? this.visit :null,
    "shift" : this.shift?this.shift:[],
    "agent": this.requestBody.agent? this.requestBody.agent:[],
    "missionStatus":this.requestBody.status? this.requestBody.status : [],
    "missionStartDate": (this.ngbDate.fromDate!==null)? this.ngbDate.fromDate.year+ '-'+this.ngbDate.fromDate.month+'-'+this.ngbDate.fromDate.day :'',
    "missionEndDate": (this.ngbDate.toDate!==null)? this.ngbDate.toDate.year + '-'+this.ngbDate.toDate.month+'-'+this.ngbDate.toDate.day:''
  }).subscribe(res => {
    this.pagination = res.data;
    this.missionsAll = res.data.content;
    this.missions = (!isNull(res.data)) ? res.data.content : [];
    this.getSubTypes(this.missions);
    this.missions.forEach(element => {
      element.missionType.name=this.translate.instant(element.missionType.name)
      element.missionStatus.statusName=this.translate.instant(element.missionStatus.statusName)
      // element.AmPm = (!isNull(element.missionStartDate)) ? this.getAmPm(element.missionStartDate) : 'NA';
      element.missionStartDate = (!isNull(element.missionStartDate)) ? element.missionStartDate.slice(0, element.missionStartDate.indexOf(' ')) : 'NA';
      element.agent = (!isNull(element.agent)) ? (element.agent.firstName + " "+ element.agent.lastName) : 'NA';
      element.shift = (!isNull(element.shift)) ? (element.shift.shiftName) : 'NA';
    });
    if(this.shift!==undefined){
      // console.log(this.shift);
    // this.filterByAm(this.shift);
    }
    this.missionLoader = false;
    // console.log(this.missions);
  }, err => {
    this.missionsAll = [];
    this.missions = [];
    this.campaignLoader = false;
    this.missionLoader = false;
    this._event.broadcast({ eventName: 'hideLoader', data: '' });
    // this.getAllCampaigns();
  }));
 }
  }

  deleteMission(id) {
    const req = {
      missionId: id,
    };
    this.custUtils.translateMessageObject({
      title: 'Delete Mission!',
      text: 'This mission will be removed from missions list. Are you sure you want to delete it?',
      type: 'warning',
      outsideClick: false,
      cancelBtnText: 'No',
      confirmBtnText: 'Yes',
      showCancelBtn: true
    }, message => {
      this.custUtils.translateAndPop(message).then(() => {
        this.gotoDelete(req);
      }).catch(() => {
        this.router.navigate([`/supervisor/mission`]);
        this.getAllMissions(10);
      });
    });
  }

  gotoDelete(req) {
    this.missionLoader = true;
    this.apiService.deleteMission(req).subscribe(res => {
      this.custUtils.translateMessageObject({
        title: 'Mission deleted successfully!',
        text: '',
        type: 'success',
        outsideClick: false,
        cancelBtnText: '',
        confirmBtnText: 'Ok',
        showCancelBtn: false
      }, message => {
        this.searchKey = '';
        this.isSearch = false;
        this.missionName='';
        this.flag=true;
        this.requestBody.types=null;
        this.market=null;
        this.classic=null;
        this.visit=null;
        this.prm=null;
        this.checkpoint=null;
        this.shift=[];
        this.requestBody.agent=null;
        this.requestBody.status=null;
        this.myRangeInput.clearDate();
        this.custUtils.translateAndPop(message).then(() => {
          this.router.navigate([`/supervisor/mission`]);
          this.getAllMissions(10);
        }).catch(() => {

        });
      });
    }, err => {
      this.custUtils.translateMessageObject({
        title: 'Something went wrong',
        text: 'Mission not deleted, please try again',
        type: 'error',
        outsideClick: true,
        cancelBtnText: '',
        confirmBtnText: 'Ok',
        showCancelBtn: false
      }, message => {
        this.custUtils.translateAndPop(message).then(() => {
          this.router.navigate([`/supervisor/mission`]);
          this.getAllMissions(10);
        }).catch(() => {
          this.router.navigate([`/supervisor/mission`]);
          this.getAllMissions(10);
        });
      });
    });
  }

  filterOrders() {
    if(this.missionName && this.missionName!=='missionName,'){
        this.missionLoader = true;
        this.subscriptions.push(this.apiService.getRefMissions({ 'createdBy': this.currentUser.userId, 'sortBy': 'missionCreationDate,desc', 'size': 10, 'searchBy': this.missionName, campaignId: this.selectedCampaign.campaignId },
          {
            "missionType": this.requestBody.types? this.requestBody.types: [],
            "classic": this.classic? this.classic:null,
            "market": this.market? this.market:null,
            "checkpoint":this.checkpoint==='true'?true:null,
            "prm": this.prm? this.prm :null,
            "visits": this.visit? this.visit :null,
            "agent": this.requestBody.agent? this.requestBody.agent:[],
            "shift" : this.shift? this.shift:[],
            "missionStatus":this.requestBody.status? this.requestBody.status : [],
            "missionStartDate": (this.ngbDate.fromDate!==null)? this.ngbDate.fromDate.year+ '-'+this.ngbDate.fromDate.month+'-'+this.ngbDate.fromDate.day :'',
            "missionEndDate": (this.ngbDate.toDate!==null)? this.ngbDate.toDate.year + '-'+this.ngbDate.toDate.month+'-'+this.ngbDate.toDate.day:''
          }).subscribe(res => {
            this.pagination = res.data;
            this.missionsAll = res.data.content;
            this.missions = (!isNull(res.data)) ? res.data.content : [];
            this.getSubTypes(this.missions);
            this.missions.forEach(element => {
              element.missionType.name=this.translate.instant(element.missionType.name)
              element.missionStatus.statusName=this.translate.instant(element.missionStatus.statusName)
              // element.AmPm = (!isNull(element.missionStartDate)) ? this.getAmPm(element.missionStartDate) : 'NA';
              element.missionStartDate = (!isNull(element.missionStartDate)) ? element.missionStartDate.slice(0, element.missionStartDate.indexOf(' ')) : 'NA';
              element.agent = (!isNull(element.agent)) ? (element.agent.firstName + " "+ element.agent.lastName) : 'NA';
              element.shift = (!isNull(element.shift)) ? (element.shift.shiftName) : 'NA';
            });
            this.missionLoader = false;
            // this.requestBody.types=null;
            // console.log(this.missions);
          }, err => {
            this.missionsAll = [];
            this.missions = [];
            this.campaignLoader = false;
            this.missionLoader = false;
            this._event.broadcast({ eventName: 'hideLoader', data: '' });
            // this.getAllCampaigns();
          }));
      
    }else{  
    this.subscriptions.push(this.apiService.getRefMissions({ 'createdBy': this.currentUser.userId, 'sortBy': 'missionCreationDate,desc', 'size': 10, campaignId: this.selectedCampaign.campaignId },
    {
      "missionType": this.requestBody.types? this.requestBody.types: [],
      "classic": this.classic? this.classic:null,
      "market": this.market? this.market:null,
      "prm": this.prm? this.prm :null,
      "visits": this.visit? this.visit :null,
      "checkpoint":this.checkpoint?true:null,      
      "agent": this.requestBody.agent? this.requestBody.agent:[],
      "shift" : this.shift? this.shift:[],
      "missionStatus":this.requestBody.status? this.requestBody.status : [],
      "missionStartDate": (this.ngbDate.fromDate!==null)? this.ngbDate.fromDate.year+ '-'+this.ngbDate.fromDate.month+'-'+this.ngbDate.fromDate.day :'',
      "missionEndDate": (this.ngbDate.toDate!==null)? this.ngbDate.toDate.year + '-'+this.ngbDate.toDate.month+'-'+this.ngbDate.toDate.day:''
    }).subscribe(res => {
      this.pagination = res.data;
      this.missionsAll = res.data.content;
      this.missions = (!isNull(res.data)) ? res.data.content : [];
      this.getSubTypes(this.missions);
      this.missions.forEach(element => {
        element.missionType.name=this.translate.instant(element.missionType.name)
        element.missionStatus.statusName=this.translate.instant(element.missionStatus.statusName)
        // element.AmPm = (!isNull(element.missionStartDate)) ? this.getAmPm(element.missionStartDate) : 'NA';
        element.missionStartDate = (!isNull(element.missionStartDate)) ? element.missionStartDate.slice(0, element.missionStartDate.indexOf(' ')) : 'NA';
        element.agent = (!isNull(element.agent)) ? (element.agent.firstName + " "+ element.agent.lastName) : 'NA';
        element.shift = (!isNull(element.shift)) ? (element.shift.shiftName) : 'NA';
      });
      this.missionLoader = false;
    }, err => {
      this.missionsAll = [];
      this.missions = [];
      this.campaignLoader = false;
      this.missionLoader = false;
      this._event.broadcast({ eventName: 'hideLoader', data: '' });
      // this.getAllCampaigns();
    }));
   }
  }
// filterByAm(e){
//    this.missions= this.missions.filter(v => v.shiftName.toLowerCase().indexOf(e.toLowerCase()) > -1).slice(0, 10);
// }
  onDateSelection(event) {
    this.ngbDate=event;
  }
}