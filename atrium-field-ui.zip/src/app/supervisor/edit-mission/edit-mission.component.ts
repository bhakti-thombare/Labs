// core
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

// 3rd party
import 'rxjs/add/operator/map';
import { Ng4FilesService } from 'angular4-files-upload';

// app
import { HttpService } from '@app/services/http-service';
import { EventService } from '@services/events/event.service';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '@services/apiServices/api.service';

@Component({
  selector: 'app-edit-mission',
  templateUrl: './edit-mission.component.html',
  styleUrls: ['./edit-mission.component.css']
})

/* @author : Pratik Bhuta : [Santosh More]
the functions are separated according to the following:-

A. Configuration - these run at the component load time.
B. Initializers
1. Getters
2. Togglers
3. Creators
4. DOM Manipulators
5. Fillers
6. Validators
7. Deletors
*/

export class EditMissionComponent implements OnInit, AfterViewInit {
  /* Variable declarations */
  showEditMissionById: any;
  showEditMissionByType: any;
  /* Constructor */
  constructor(public router: Router,
    public http: HttpService,
    private route: ActivatedRoute,
    public event: EventService,
    private ng4FilesService: Ng4FilesService,
    private _http: HttpClient,
    private utils: ApiService) { }
  ngOnInit() {
    this.route.params.subscribe(params => { this.getMission(params.id); });
  }
  ngAfterViewInit() { }

  /* Get Missions to check the type of mission to redirect respective edit page */
  getMission(id) {
    this.http.SecureGet('/ref/getAllMissions?id=' + id)
      .subscribe(res => {
        this.event.broadcast({ eventName: 'hideLoader', data: '' });
        let missions = res.data.missions[0];
        this.showEditMissionById = missions.missionType.id;
      }, err => { })
  }
}