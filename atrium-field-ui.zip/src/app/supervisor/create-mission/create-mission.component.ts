// core imports
import {
  Component, OnInit, ViewChild
} from '@angular/core';
import { Location, DatePipe } from '@angular/common';

// 3rd party
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

// app
import { ApiService } from '@services/apiServices/api.service';
import { EventService } from '@services/events/event.service';
/* @author : Pratik Bhuta
  the functions are separated according to the following:-
  1. Getters
  2. Togglers
  3. Creators
  4. DOM Flags Manipulators
  5. Fillers
  6. Validators
  7. Deletors
*/

@Component({
  selector: 'app-create-mission',
  templateUrl: './create-mission.component.html',
  styleUrls: ['./create-mission.component.css']
})
export class CreateMissionComponent implements OnInit {

  @ViewChild('surveySelectionModal') private surveySelectionModal;

  survey;
  missionTypesLoaded;
  missionTypes;
  selectedMissionType;
  modal;
  closeResult;

  constructor(
    public api: ApiService,
    public modalService: NgbModal,
    public location: Location,
    public event: EventService,
    ) {

  }

  ngOnInit() {
    this.getMissionTypes()
    this.event.broadcast({ eventName: 'showLoader', data: '' });
  }

  getMissionTypes() {
    this.missionTypesLoaded = false;
    this.missionTypes = [];
     
    this.api.getMissionTypes().subscribe(res => {
      let typeLen = res.data.length;
      res.data.forEach(type => {
        if (type.id === 3 || type.id === 4 || type.id === 2 || type.id ===7) {
          if (type.id === 3) {
            type.name = 'Pedestrian Flow';
            this.missionTypes.push(type);
          }
          else this.missionTypes.push(type);
        }
        typeLen--;
        if (typeLen === 0) {
          this.selectedMissionType = this.missionTypes[0];
          this.missionTypes.splice(0, 1);
          this.missionTypesLoaded = true;
          this.event.broadcast({ eventName: 'hideLoader', data: '' });
          this.changeSurveyModal(this.surveySelectionModal);
        }
      });
    }, err => {
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
    });
  }

  changeSurveyModal(modal) {
    this.modal = this.modalService.open(modal, { keyboard: false, backdrop: 'static' });
    this.modal.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  submitSurveyType() {
    this.toggleSurvey(this.selectedMissionType.id);
    this.modal.close();
  }

  toggleSurvey(e) {
    this.survey = e;
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return reason;
    }
  }

  toggleMissionType(missionType) {
    this.missionTypes.push(this.selectedMissionType);
    this.selectedMissionType = missionType;
    let deleteIndex = -1;
    let mtLen = this.missionTypes.length;

    this.missionTypes.forEach((mt, i) => {
      if (mt.id === missionType.id) {
        deleteIndex = i;
      }
      mtLen--;
      if (mtLen === 0) {
        if (deleteIndex !== -1) {
          this.missionTypes.splice(deleteIndex, 1);
        }
      }
    });
  }
  close() {
    this.modal.close();
    this.location.back();
  }
}
