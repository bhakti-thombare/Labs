import { Component, ViewChild, OnInit, ElementRef, Renderer2, Input, Output, EventEmitter } from '@angular/core';
import {
  NgbDatepicker,
  NgbInputDatepicker,
  NgbDateStruct,
  NgbCalendar,
  NgbDateParserFormatter, NgbDatepickerConfig
} from '@ng-bootstrap/ng-bootstrap';
import { NgModel } from "@angular/forms";

import { Subscription } from 'rxjs';
import { MissionsComponent } from './missions/missions.component';

const now = new Date();
const equals = (one: NgbDateStruct, two: NgbDateStruct) =>
  one && two && two.year === one.year && two.month === one.month && two.day === one.day;

const before = (one: NgbDateStruct, two: NgbDateStruct) =>
  !one || !two ? false : one.year === two.year ? one.month === two.month ? one.day === two.day
    ? false : one.day < two.day : one.month < two.month : one.year < two.year;

const after = (one: NgbDateStruct, two: NgbDateStruct) =>
  !one || !two ? false : one.year === two.year ? one.month === two.month ? one.day === two.day
    ? false : one.day > two.day : one.month > two.month : one.year > two.year;

@Component({
  selector: 'ngbd-datepicker-popup',
  templateUrl: './datepicker-popup.html',
  styles: [`./datepicker-popup.css`]
})

export class NgbdDatepickerPopup implements OnInit {
 
  @Output() dateSelected: EventEmitter<any>=new EventEmitter<any>();
  startDate: NgbDateStruct;
  maxDate: NgbDateStruct;
  current = new Date(Date.now());
  minDate = {
    year: this.current.getFullYear(),
    month: this.current.getMonth() + 1,
    day: this.current.getDate()
  };
  parsed = '';
  hoveredDate: NgbDateStruct;
  fromDate: any;
  toDate: any;
  model: any;
  today:NgbDateStruct;
  private _subscription: Subscription;
  private _selectSubscription: Subscription;
  @ViewChild("d") input: NgbInputDatepicker;
  @ViewChild(NgModel) datePick: NgModel;
  @ViewChild('myRangeInput') myRangeInput: ElementRef;

  isHovered = date => 
    this.fromDate && !this.toDate && this.hoveredDate && after(date, this.fromDate) && before(date, this.hoveredDate)
    isInside = date => after(date, this.fromDate) && before(date, this.toDate);
    isFrom = date => equals(date, this.fromDate);
    isTo = date => equals(date, this.toDate);
    constructor(element: ElementRef, private renderer: Renderer2, private _parserFormatter: NgbDateParserFormatter) {
    }

  ngOnInit() {
    this.startDate = { year: now.getFullYear(), month: now.getMonth() + 1, day: now.getDate() };
    this.maxDate = { year: now.getFullYear() + 1, month: now.getMonth() + 1, day: now.getDate() };
    let date = new Date();
    this.today = { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate()};
    // this.minDate = { year: now.getFullYear() - 1, month: now.getMonth() + 1, day: now.getDate() };
  }

  isToday(date:NgbDateStruct)
  {
      if (!this.today)
           return false;
      return date.year==this.today.year && 
             date.month==this.today.month && 
             date.day==this.today.day
  }
  
  keydown(e){
      e.preventDefault();
      e.stopPropagation();
  };

  onDateSelection(date: NgbDateStruct,event) {   
   this.parsed='';
    if (!this.fromDate && !this.toDate) {
      this.fromDate = date;
    } else if (this.fromDate && !this.toDate) {
      this.toDate = date;

      // this.model = `${this.fromDate.year} - ${this.toDate.year}`;
      // this.input.close();
    } else {
      this.toDate = null;
      this.fromDate = date;
    }
    console.log(this.fromDate,this.toDate);
    if (this.fromDate) {   
      this.parsed += (this.fromDate.day + '/' + this.fromDate.month + '/' + this.fromDate.year.toString().substr(2,2));
      event.stopPropagation();
      event.preventDefault();
    }

    if (this.toDate) {
      this.parsed.substr(0,8);
      this.parsed += '-' + this.toDate.day + '/' + this.toDate.month + '/' + this.toDate.year.toString().substr(2,2);
      // this.input.close();
    }

    this.renderer.setProperty(this.myRangeInput.nativeElement, 'value', this.parsed);
    if (this.fromDate && this.toDate) {
      this.input.close();
      this.dateSelected.emit({ fromDate: this.fromDate, toDate: this.toDate });
     
    }
    
  }

  clearDate(){
    this.fromDate=undefined;
    this.toDate=undefined;
    this.renderer.setProperty(this.myRangeInput.nativeElement, 'value', '');
  }

}
