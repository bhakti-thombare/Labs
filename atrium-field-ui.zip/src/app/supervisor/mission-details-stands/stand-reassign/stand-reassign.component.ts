import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Globals, missionTypes } from '@app/constants/constants';
import { CustomerSurveyAlertsService } from '@app/services/Alerts/customer-survey-alerts.service';
import { MissionListAlertsService } from '@app/services/Alerts/mission-list-alerts.service';
import { ApiService } from '@app/services/apiServices/api.service';
import { UTILS } from '@app/services/global-utility.service';
import { HttpService } from '@app/services/http-service';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { TranslateService } from '@ngx-translate/core';
import { stringify } from 'querystring';
import { Subscription } from 'rxjs';
import {
  each,
  map,
  isArray,
  filter,
  isEmpty,
  defaults,
  findWhere,
  isUndefined
} from 'underscore';
declare var google: any;
@Component({
  selector: 'app-stand-reassign',
  templateUrl: './stand-reassign.component.html',
  styleUrls: ['./stand-reassign.component.css']
})
export class StandReassignComponent implements OnInit {

  private subscriptions: Subscription[] = [];
  today: Date = new Date();
  minDate: any;
  maxDate: any;
  disablesubmit: boolean=false;
  currentStartDate: { year: any; month: any; day: any; };

  constructor(private activatedRoute: ActivatedRoute,
    private apiService:ApiService,
    public custAlerts: CustomerSurveyAlertsService,
    public router:Router,
    public _http: HttpService,
    public translate:TranslateService,
    public missionListAlertsService:MissionListAlertsService) { }
  missiondates;
  morning=true;
  agentSelected=false;
  step1Form:FormGroup;
  step2Form:FormGroup;
  step3Form:FormGroup;
  campaignEndDate: any;
  missionId;
  campaignFlag: boolean=false;
  enddayObj: { year: any; month: any; day: any; };
  dateSelected: boolean=false;
  startdayObj: { year: any; month: any; day: any; };
  startDate;

  mission={
    userId:localStorage.getItem('userId'),
    classic:'',
    prm:'',
    visits:'',
    market:'',
    agent:{
     userId:''
    },
    missionStartDate : {
      year: null,
      month: null,
      day: null
    },
    missionCampaign:{
      campaignName:'',
      campaignId:''
    },
    missionMarketZoneList:{
    shortName:'',
    latitude:'',
    longitude:'',
    id:'',
    scheduleFriClose:'',
      scheduleFriOpen:'',
      scheduleMonClose:'',
      scheduleMonOpen:'',
      scheduleSatClose:'',
      scheduleSatOpen:'',
      scheduleSunClose:'',
      scheduleSunOpen:'',
      scheduleThurClose:'',
      scheduleThurOpen:'',
      scheduleTueClose:'',
      scheduleTueOpen:'',
      scheduleWedClose:'',
      scheduleWedOpen:''

    },
    missionZones:[{
      address:'',
      adptId:'',
      officialName:'',
      latitude:'',
      longitude:'',
      id:'',
      managementAuthority:'',
      numberOfSubscribedStands:'',
      numberOfUnSubscribedStands:'',
      
    }],
    missionId:'',
    missionStatus:{
      statusId:'',
      statusName:''
    },
    shift:{
      shiftId:''
    },
    missionType:{
      id:''
    },
    subType:1,
    numberOfPos:'',
    numberOfPosCheckpoints:'',
    supervisorId:'',
    missionEstimatedTime:''
  }
  selectedMission: Array<any> = [];
  textControl = new FormControl();
shiftStart;
shiftEnd;
submitMission(){
  this.disablesubmit=true;
  console.log("mission values=",this.step1Form.value,localStorage.getItem('userId'));
  this.shiftStart=this.morning?"8:45:00":"13:00:00"
  this.shiftEnd=this.morning?"13:00:00":"17:15:00"
  const reqbody={
    newUserId:this.selectAgentId, //new assigned field agent
    oldUserId:this.mission.agent.userId, //previous agent id
    missionId:this.mission.missionId,
    campaignId:this.mission.missionCampaign.campaignId,
    currentStatus:this.mission.missionStatus.statusName,
    oldStatus:this.mission.missionStatus.statusId,
    createdBy:localStorage.getItem('userId'),
    updatedBy:localStorage.getItem('userId'),
    supervisorId:this.mission.supervisorId,
    shiftId:this.morning?1:2,
    oldShiftId:this.mission.shift.shiftId,
    newStartDate:`${this.startDate} ${this.shiftStart}`,
    newEndDate:`${this.startDate} ${this.shiftEnd}`,
    currentStartDate:this.currentStartDate,
    zoneId:null,
    locationTypeId:2,
    missionRequest:{
      missionTypeId:7,
      missionCreationDate:"",
      missionStartDate:`${this.startDate} 00:00:00`,
      missionEndDate:`${this.startDate} 00:00:00`,
      classic:this.mission.classic,
      visits:this.mission.visits,
      market:this.mission.market,
      prm:this.mission.prm,
      marketZone: this.mission.missionMarketZoneList !== null? this.mission.missionMarketZoneList[0].id:null,
      missionName:this.step1Form.value.missionName,
      missionDescription:this.step1Form.value.missionDescription,
      missionCampaignId:this.mission.missionCampaign.campaignId,
      missionCreatedById:localStorage.getItem('userId'),
      missionUpdatedById:localStorage.getItem('userId'),
      missionStatusId:10,
      missionEstimatedTime:610
    }
  }
  this.apiService.postCSReassignDetails(reqbody,this.missionId).subscribe((res)=>{
    console.log("success",res);
    if(res.responseCode==200){
      this.missionListAlertsService.reassignMission().then(() => {
        this.router.navigate(['/supervisor/missions'])

      });;


    }
    
  })

}



  getMission(id) {
    this.subscriptions.push(
      this.apiService.getAllMissions({ id: id }).subscribe(
        res => {
          console.log("getmission=",res.data.mission);
          
          this.selectedMission = [...res.data.missions];
          console.log('selected mission=',this.selectedMission);

          Globals.campaignStartDate =
            res.data.missions[0].missionCampaign.campaignStartDate;
          Globals.campaignEndDate =
            res.data.missions[0].missionCampaign.campaignEndDate;
          this.setMinMaxDate();
        },
        err => {
          console.log(err);
        }
      )
    );
  }
  setMinMaxDate() {
    const minDate_ = new Date(UTILS.getDateTimeFormat(UTILS.minDate));
    const campaignStartDate = new Date(Globals.campaignStartDate);
    if (minDate_ < campaignStartDate)
      this.minDate = UTILS.getDatePickerDateFormat(Globals.campaignStartDate);
    else this.minDate = UTILS.minDate;

    this.maxDate = UTILS.getDatePickerDateFormat(Globals.campaignEndDate);
    //console.log("minDate",this.minDate);
    //console.log("maxDate",this.maxDate);
  }
  getUsedMissionDates(date) {
    let currentDate = UTILS.getDatePickerDateFormat(date);
    this.subscriptions.push(
      this.apiService
        .getShiftWiseUsedMissionDates(
          UTILS.getDateFormatWithoutZero(currentDate),
          missionTypes.POS_POI_TYPE_ID, this.morning?1:2
        )
        .subscribe(
          res => {
            Globals.BUSY_DATES = res.dateDto;
          },
          err => (Globals.BUSY_DATES = [])
        )
    );
  }

  // isDisabled(date: NgbDate, current: { month: number }) {
  //   const d = new Date(date.year, date.month - 1, date.day);
  //   const isDateFind = findWhere(
  //     Globals.BUSY_DATES,
  //     UTILS.getDatePickerIntFormat(date)
  //   );
  //   const currentDate = new Date(UTILS.getDateFormat(date));
  //   const day = currentDate.getDay();
  //   let market = JSON.parse(localStorage.getItem('market Open'));
  //           market = JSON.parse(localStorage.getItem("market Open"))

  //   // const isWeekend = day != 0 && day != 6;
  //   if ( isUndefined(isDateFind)){
  //     if (d.getDay() === market[0] || d.getDay() === market[1] || d.getDay() === market[2] || d.getDay() === market[3] ||
  //             d.getDay() === market[4] || d.getDay() === market[5] || d.getDay() === market[6] || d.getDay() === market[7]) {
        
  //             return true;

  //           }
  //   } 
  //   else return false;
  // }
  isDisabled(date: NgbDate, current: { month: number }) {
    const d = new Date(date.year, date.month - 1, date.day);
       const now = new Date(Date.now());
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
      // localStorage.removeItem('busyDates');
      const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
      const busyDates = JSON.parse(localStorage.getItem('busyDates'));
      const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
      const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
      const sdate = new Date(date.year, date.month - 1, date.day);

      if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
        if (busyDates !== null) {
          let found = -1;
          const dateFinder = (dateObj) => {
            const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));



            if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
              inDate.getDate() === sdate.getDate()) {
              return true;
            } else {
              return false;
            }
          };

          found = busyDates.findIndex(dateFinder);

          let available = !busyDates.findIndex(dateFinder)

          if (found !== -1) {
            return true

          } else {
            let market = (localStorage.getItem('missionStartDate'));
            market = (localStorage.getItem("missionStartDate"))
            
            // if (d.getDay() === new Date(market).getDay()) {

            //   return true;

            // }
            var res=market.split('-');
            let year=parseInt(res[0]);
            let month= parseInt(res[1]);
            let date34=parseInt(res[2]);
            
            const d1 = month==0?new Date(year,11,date34):new Date(year,month-1,date34);
            var arr = [1, 2, 3, 4, 5, 6, 0];
            arr.forEach(i => {
              if ( arr[i] === d1.getDay()) { 
                arr.splice(i, 1); 
              }
            });
            
            if (d.getDay() === arr[0] || d.getDay() === arr[1] || d.getDay() === arr[2] || d.getDay() === arr[3] ||
            d.getDay() === arr[4] || d.getDay() === arr[5] || d.getDay() === arr[6] || d.getDay() === arr[7]) {
             
              return true;
  
            }

          }
        } else {
          console.log("not busy=available");
          var market =(localStorage.getItem('missionStartDate'));
          market = (localStorage.getItem("missionStartDate"))
          
          console.log(market);
          var res=market.split('-');
          let year=parseInt(res[0]);
          let month= parseInt(res[1]);
          let date34=parseInt(res[2]);
          
          const d1 = month==0?new Date(year,11,date34):new Date(year,month-1,date34);
          var arr = [1, 2, 3, 4, 5, 6, 0];
          arr.forEach(i => {
            if ( arr[i] === d1.getDay()) { 
              arr.splice(i, 1); 
            }
          });
          
          if (d.getDay() === arr[0] || d.getDay() === arr[1] || d.getDay() === arr[2] || d.getDay() === arr[3] ||
          d.getDay() === arr[4] || d.getDay() === arr[5] || d.getDay() === arr[6] || d.getDay() === arr[7]) {
           
            return true;

          } else {
            return false;
          }

        }
      } else {
        return true;
      }
    
  }
  step1details(){
   

    this.step1Form.setValue({
      'step1':{
        'camapaignName':this.mission.missionCampaign.campaignName,
        'missionType':'Stands',
        'missionName':'',
        'classic':this.mission.classic,
        'market':this.mission.market,
        'missionDescription':'',
        'missionMarketName':this.mission.missionMarketZoneList!==null?  this.mission.missionMarketZoneList[0].shortName:''
      },
    
    })
  }

  getLngLat(e) {
    const api = new google.maps.Geocoder;
 
      // this.mapObject = [e[0], e[1] ];
      // this.mission.markets[0].name = undefined;
      // this.mission.markets[0].adptId = null;
      console.log('map changed');
     
      // this.marketNameDisabled = false;
      api.geocode({ latLng: { lat: e[1], lng: e[0] } }, result => {
console.log('success');
      });
    
}

  step2details(){
  
    this.step2Form.setValue({
      'step2':{
        'shortName':this.mission.missionMarketZoneList[0].shortName,
        'marketName':this.mission.missionMarketZoneList[0].officialName,
        'address':this.mission.missionMarketZoneList[0].address,
        'adptId':this.mission.missionMarketZoneList[0].adptId,
        'startPeriod':this.mission.missionMarketZoneList[0].startDate,
        'endPeriod':this.mission.missionMarketZoneList[0].endDate,
        'expectedStands':this.mission.missionMarketZoneList[0].expectedNumberOfStands,
        'subscribedStands':this.mission.missionMarketZoneList[0].numberOfSubscribedStands,
        'unsubscribedStands':this.mission.missionMarketZoneList[0].numberOfUnSubscribedStands,
        'managementAuthority':this.mission.missionMarketZoneList[0].managementAuthority,
        
        // 'name':this.mission.missionMarketZoneList[0].name
        
      },
    
    })
  }

  step3details(){
  
    // this.step3Form.setValue({
    //   'step3':{
    //     // 'quartierName':this.mission.quartierDto.name,
    //       'POS':this.mission.numberOfPos,
    //       'checkpoints':this.mission.numberOfPosCheckpoints,
    //       'subType':this.mission.subType==5?this.translate.instant('Points of sale only'):this.translate.instant('Points of sale & Checkpoints')
        
    //   },
    
    // })
  }
// missionId
// startDate;
//   getDate(date){
//     const month=String(date.month).padStart(2, "0");
//       const day=String(date.day).padStart(2, "0");
//       this.missiondates=`${date.year}-${month}-${day}`
//       console.log("mission dates=",this.missiondates);
//       this.startDate=`${date.year}-${date.month}-${date.day}`
//       this.getUnassignedUsers()

//   }
getDate(d1) {
  var g1 = new Date();
  let endDateCheck = JSON.parse(localStorage.getItem('campaignEndDate'));

  endDateCheck = new Date(`${endDateCheck.year}-${endDateCheck.month}-${endDateCheck.day}`)
  let startDateCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
  startDateCheck = new Date(`${startDateCheck.year}-${startDateCheck.month}-${startDateCheck.day}`)

  // (YYYY-MM-DD) 
  var CurrentDate = new Date()
  var d = new Date();
  // var d = new Date(CurrentDate),
  let dateToday = {
    month: '' + (d.getMonth() + 1),
    day: '' + d.getDate(),
    year: d.getFullYear()
  }

  if (dateToday.month.length < 2)
    dateToday.month = '0' + dateToday.month;
  if (dateToday.day.length < 2)
    dateToday.day = '0' + dateToday.day;
  var today = `${dateToday.year}-${dateToday.month}-${dateToday.day}`


  // var g2 = new Date(`${d1.year}-${d1.month}-${d1.day}`); 
  console.log("d1.day=", d1.day, g1.getMonth(), this.minDate, this.minDate.day === d1.day);
  var GivenDate = new Date(`${d1.year}-${d1.month}-${d1.day}`);
  const month1 = String(d1.month).padStart(2, "0");
  const day1 = String(d1.day).padStart(2, "0");
  var todayDate = `${d1.year}-${month1}-${day1}`
  console.log("checkdate", startDateCheck);
  console.log((GivenDate > endDateCheck), (GivenDate < startDateCheck));

  if(new Date(this.campaignEndDate)< CurrentDate){
    this.campaignFlag=false;
    localStorage.setItem('campaignFlag', 'false');
  } else {
    this.campaignFlag=true
    localStorage.setItem('campaignFlag', 'true');
    this.startdayObj={
      year:startDateCheck.getFullYear(),
      month:startDateCheck.getMonth()+1,
      day:startDateCheck.getDate()
      }
    localStorage.setItem('campaignStartDate', JSON.stringify(this.startdayObj));
  //  endDateCheck.split('-');
    this.enddayObj={
      year:endDateCheck.getFullYear(),
      month:endDateCheck.getMonth()+1,
      day:endDateCheck.getDate()
      }
    localStorage.setItem('campaignEndDate', JSON.stringify(this.enddayObj));
  }

  if (this.campaignFlag) {
    if ((!(GivenDate > endDateCheck) && !(GivenDate < startDateCheck)) || (GivenDate.getDate() == startDateCheck.getDate())) {
      if (GivenDate >= CurrentDate || (today === todayDate)) {


        // if (d1.day >= this.minDate.day ) {
        // this.dateSelected=true;
        this.dateSelected = true;
        this.mission.missionStartDate = {
          year: d1.year,
          month: d1.month,
          day: d1.day
        }
        console.log("mision startdate=", this.mission.missionStartDate);

        localStorage.setItem('date', JSON.stringify(d1));


        this.startDate = `${d1.year}-${d1.month}-${d1.day}`
        const endDate = '2020-10-12 ' + '23:59:00'
        const startDate = '2020-10-12 ' + '00:00:00'
        this._http.SecureGet('/ref/getDatesInRange?startDate=' + startDate + '&endDate=' + endDate).subscribe(res => {
          console.log("res field agents=", res);

        }, err => {
        });
        this.getAllUnassignedUsersPos({
          // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
          // endDate: UTILS.getDateFormatWithTime(endDate),
          startDate:`${d1.year}-${d1.month}-${d1.day}`,
          endDate:`${d1.year}-${d1.month}-${d1.day}`,
          iterations: 9,
          shift: this.morning?1:2,
          missionId: this.missionId
        });
      }
    }
  } else {
    if (GivenDate >= CurrentDate || (today === todayDate)) {


      // if (d1.day >= this.minDate.day ) {
      // this.dateSelected=true;
      this.dateSelected = true;
      this.mission.missionStartDate = {
        year: d1.year,
        month: d1.month,
        day: d1.day
      }
      console.log("mision startdate=", this.mission.missionStartDate);

      localStorage.setItem('date', JSON.stringify(d1));

      console.log("date selected...!!!");
      this.startDate = `${d1.year}-${d1.month}-${d1.day}`
      const endDate = '2020-10-12 ' + '23:59:00'
      const startDate = '2020-10-12 ' + '00:00:00'
      this._http.SecureGet('/ref/getDatesInRange?startDate=' + startDate + '&endDate=' + endDate).subscribe(res => {
        console.log("res field agents=", res);

      }, err => {
      });
      this.getAllUnassignedUsersPos({
        // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
        // endDate: UTILS.getDateFormatWithTime(endDate),
        startDate:`${d1.year}-${d1.month}-${d1.day}`,
          endDate:`${d1.year}-${d1.month}-${d1.day}`,
          iterations: 9,
          shift: this.morning?1:2,
          missionId: this.missionId
      });
    }
  }
}
  getUnassignedUsers(){
    this.getAllUnassignedUsersPos({
      // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
      // endDate: UTILS.getDateFormatWithTime(endDate),
      startDate:this.startDate,
      endDate:this.startDate,
      iterations: 9,
      shift: this.morning?1:2,
      missionId: this.missionId
    });
    
  }
  selectedAgent;
  selectAgentId;
  // dateSelected=false;
  toggleFieldAgent(user){
    this.agentSelected=true;
    this.selectedAgent=`${user.firstName} ${user.lastName}`
    this.selectAgentId=user.userId
  }
  optionsAgents=[]
  getAllUnassignedUsersPos(reqBody) {
    this.subscriptions.push(
      this.apiService.getAllUnassignedUsersPos(reqBody).subscribe(
        res => {
          this.dateSelected=true
          this.optionsAgents = [];
          this.optionsAgents = map(res.users, m =>
            UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` })
          );
          console.log("res===",this.optionsAgents);
                 },
        err => {
          if (err.status === 400) {
            this.dateSelected=false
            this.custAlerts.noAgentFound();
          }
        }
      )
    );
  }

  changeShiftId(id) {
    console.log("id=",id);
    
    if (id === 1) {
      this.morning = true;
      this.getUsedMissionDates(this.today);
      if(this.startDate !== undefined){
        this.getUnassignedUsers()
      }
    } else {
      this.morning = false;
      this.getUsedMissionDates(this.today);
      if(this.startDate !== undefined){
        this.getUnassignedUsers()
      }
    }
  }
  mapObject=[];
  marketOpen=[]
  getMissionDetails(id){
    this.apiService.getReassignCSMissionDetails(id).subscribe(result => {
      console.log("result=",result);
      this.mission=result.data;
      let marketDay=new Date(result.data.missionStartDate);
      this.currentStartDate=this.mission.missionStartDate;
      localStorage.setItem('market Open',JSON.stringify(marketDay.getDay()));
      localStorage.setItem('missionStartDate', result.data.missionStartDate.substr(0,10));
      localStorage.setItem('missionEndDate', result.data.missionEndDate);
      this.startdayObj={
        year:new Date(result.data.missionCampaign.campaignStartDate).getFullYear(),
        month:new Date(result.data.missionCampaign.campaignStartDate).getMonth()+1,
        day:new Date(result.data.missionCampaign.campaignStartDate).getDate()
        }
      localStorage.setItem('campaignStartDate', JSON.stringify(this.startdayObj));
    //  endDateCheck.split('-');
      this.enddayObj={
        year:new Date(result.data.missionCampaign.campaignEndDate).getFullYear(),
        month:new Date(result.data.missionCampaign.campaignEndDate).getMonth()+1,
        day:new Date(result.data.missionCampaign.campaignEndDate).getDate()
        }
      localStorage.setItem('campaignEndDate', JSON.stringify(this.enddayObj));

      // this.campaignEndDate = result.data.missionCampaign.campaignEndDate;
      // let startdate = result.data.missionCampaign.campaignStartDate;
      // this.startdayObj = {
      //   year: startdate[0],
      //   month: startdate[1],
      //   day: startdate[2]
      // }

      // let endDateMission =this.campaignEndDate[0].split('-');  
      // this.enddayObj={
      // year:endDateMission[0],
      // month:endDateMission[1],
      // day:endDateMission[2]
      // }

      if(this.mission.missionMarketZoneList[0]){
        this.marketOpen=[]
        this.mission.missionMarketZoneList[0].scheduleMonOpen=this.mission.missionMarketZoneList[0].scheduleMonOpen ? this.mission.missionMarketZoneList[0].scheduleMonOpen.substring(0,5):''
        this.mission.missionMarketZoneList[0].scheduleTueOpen=this.mission.missionMarketZoneList[0].scheduleTueOpen ? this.mission.missionMarketZoneList[0].scheduleTueOpen.substring(0,5):''
        this.mission.missionMarketZoneList[0].scheduleWedOpen=this.mission.missionMarketZoneList[0].scheduleWedOpen ? this.mission.missionMarketZoneList[0].scheduleWedOpen.substring(0,5):''
        this.mission.missionMarketZoneList[0].scheduleThurOpen=this.mission.missionMarketZoneList[0].scheduleThurOpen ? this.mission.missionMarketZoneList[0].scheduleThurOpen.substring(0,5):''
        this.mission.missionMarketZoneList[0].scheduleFriOpen=this.mission.missionMarketZoneList[0].scheduleFriOpen ? this.mission.missionMarketZoneList[0].scheduleFriOpen.substring(0,5):''
        this.mission.missionMarketZoneList[0].scheduleSatOpen=this.mission.missionMarketZoneList[0].scheduleSatOpen ? this.mission.missionMarketZoneList[0].scheduleSatOpen.substring(0,5):''
        this.mission.missionMarketZoneList[0].scheduleSunOpen=this.mission.missionMarketZoneList[0].scheduleSunOpen ? this.mission.missionMarketZoneList[0].scheduleSunOpen.substring(0,5):''

        
        this.mission.missionMarketZoneList[0].scheduleMonClose=this.mission.missionMarketZoneList[0].scheduleMonClose ? this.mission.missionMarketZoneList[0].scheduleMonClose.substring(0,5):''
        this.mission.missionMarketZoneList[0].scheduleTueClose=this.mission.missionMarketZoneList[0].scheduleTueClose ? this.mission.missionMarketZoneList[0].scheduleTueClose.substring(0,5):''
        this.mission.missionMarketZoneList[0].scheduleWedClose=this.mission.missionMarketZoneList[0].scheduleWedClose ? this.mission.missionMarketZoneList[0].scheduleWedClose.substring(0,5):''
        this.mission.missionMarketZoneList[0].scheduleThurClose=this.mission.missionMarketZoneList[0].scheduleThurClose ? this.mission.missionMarketZoneList[0].scheduleThurClose.substring(0,5):''
        this.mission.missionMarketZoneList[0].scheduleFriClose=this.mission.missionMarketZoneList[0].scheduleFriClose ? this.mission.missionMarketZoneList[0].scheduleFriClose.substring(0,5):''
        this.mission.missionMarketZoneList[0].scheduleSatClose=this.mission.missionMarketZoneList[0].scheduleSatClose ? this.mission.missionMarketZoneList[0].scheduleSatClose.substring(0,5):''
        this.mission.missionMarketZoneList[0].scheduleSunClose=this.mission.missionMarketZoneList[0].scheduleSunClose ? this.mission.missionMarketZoneList[0].scheduleSunClose.substring(0,5):''

        if (this.mission.missionMarketZoneList[0].scheduleMonOpen === '') {
          this.marketOpen.push(1)
        }
        if (this.mission.missionMarketZoneList[0].scheduleTueOpen === '') {
          this.marketOpen.push(2)
        }
        if (this.mission.missionMarketZoneList[0].scheduleWedOpen === '') {
          this.marketOpen.push(3)
        }
        if (this.mission.missionMarketZoneList[0].scheduleThurOpen === '') {
          this.marketOpen.push(4)
        }
        if (this.mission.missionMarketZoneList[0].scheduleFriOpen === '') {
          this.marketOpen.push(5)
        }
        if (this.mission.missionMarketZoneList[0].scheduleSatOpen === '') {
          this.marketOpen.push(6)
        }
        if (this.mission.missionMarketZoneList[0].scheduleSunOpen === '') {
          this.marketOpen.push(0)
        }
        console.log("market open=", this.marketOpen);
    
        // localStorage.setItem('marketOpen', this.marketOpen.toString());
        localStorage.setItem("marketOpen", JSON.stringify(this.marketOpen));
    
      }
      // this.mapObject=[{'latitude':50.84684682158198,'longitude':4.34628584859738}]
      if(this.mission.missionMarketZoneList !== null){
        console.log("this.mission=",this.mission);
        
      this.mapObject.push({'latitude':this.mission.missionMarketZoneList[0].latitude,'longitude':this.mission.missionMarketZoneList[0].longitude,'flag':false})
      }
      // this.mapObject.push({'latitude':this.mission.missionZones.latitude,'longitude':this.mission.missionZones[0].longitude,'flag':false,'step4':true})
      this.step1details();
      this.step2details();
      console.log("this.map=",this.mapObject);
      // this.mapObject=[this.mapObject,{'latitude':50.84684682158198,'longitude':4.34628584859738}]
      
// this.step2details();
// this.step3details();
// this.getQuartierDetails(this.mission.quartierDto)
      
    })
  }
//   getQuartierDetails(id){
// console.log("quartier id=",id);
// this.apiService.getQuartiers(id).subscribe((res)=>{
//   console.log("quartiers=",res);
  
// })

//   }
  nameExists=false;
  name=false;
  textControl1 = new FormControl();

  checkMissionName(){
    this.textControl.valueChanges.pipe(
      ).subscribe((res)=>{
        //  res=(res.toString()).trim();
        res=$.trim(res);
      this.step1Form.value.missionName=res;
      if(res!==''){
        this.apiService.getMissionName(res).subscribe((res)=>{
            this.name=true;
          this.nameExists=false;
      },(error)=>{
          this.nameExists=true;
          this.name=false;  
      })
      } else {
        this.name=false
      } 
      });
  }
  description=false;
  ngOnInit() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
   this.checkMissionName()
   this.textControl1.valueChanges.pipe(
    ).subscribe((res)=>{
      // res=res.trim();
      res=$.trim(res);
this.step1Form.value.missionDescription=res
         if(res !== ''){
           this.description=true
         } else {
           this.description=false
         }
         console.log("this.description=",this.description);
         
         if(this.name && this.description){
            //  this.buttonEnabled=true;
         } else {
          //  this.buttonEnabled=false;
         }
    });
    this.step1Form = new FormGroup({
      'step1': new FormGroup({
          'camapaignName':new FormControl(null),
          'missionType':new FormControl(null),
          'missionName':new FormControl(null),
          'classic':new FormControl(null),
          'market':new FormControl(null),
          'missionDescription':new FormControl(null),
          'missionMarketName':new FormControl(null)
      }),
    });
    this.step2Form = new FormGroup({
      'step2': new FormGroup({
        'shortName':new FormControl(null),
        'marketName':new FormControl(null),
        'address':new FormControl(null),
        'adptId':new FormControl(null),
        'startPeriod':new FormControl(null),
        'endPeriod':new FormControl(null),
        'expectedStands':new FormControl(null),
        'subscribedStands':new FormControl(null),
        'unsubscribedStands':new FormControl(null),
        'managementAuthority':new FormControl(null)
        

      }),
    });
    // this.step3Form = new FormGroup({
    //   'step3': new FormGroup({
    //       'quartierName':new FormControl(null),
    //       'POS':new FormControl(null),
    //       'checkpoints':new FormControl(null),
    //       'subType':new FormControl(null)


    //   }),
    // });
      this.missionId = this.activatedRoute.snapshot.paramMap.get('id')
      this.getMission(this.missionId);

this.getMissionDetails(this.missionId)
this.getUsedMissionDates(this.today);



  }



}
