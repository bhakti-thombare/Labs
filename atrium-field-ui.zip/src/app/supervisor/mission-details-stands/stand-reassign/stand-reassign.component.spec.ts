import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StandReassignComponent } from './stand-reassign.component';

describe('StandReassignComponent', () => {
  let component: StandReassignComponent;
  let fixture: ComponentFixture<StandReassignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StandReassignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandReassignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
