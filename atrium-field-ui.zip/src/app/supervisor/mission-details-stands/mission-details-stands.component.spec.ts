import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MissionDetailsStandsComponent } from './mission-details-stands.component';

describe('MissionDetailsStandsComponent', () => {
  let component: MissionDetailsStandsComponent;
  let fixture: ComponentFixture<MissionDetailsStandsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MissionDetailsStandsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MissionDetailsStandsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
