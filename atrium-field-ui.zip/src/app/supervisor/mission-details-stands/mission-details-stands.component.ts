// core
import { Http } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';

// 3rd party
import {
  each,
  isMatch,
  isNull,
  isArray
} from "underscore";
import { Subscription } from 'rxjs/Subscription';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash' ;
// app
import { CustomerSurveyAlertsService } from '@services/Alerts/customer-survey-alerts.service';
import { UTILS } from '@services/global-utility.service';
import { ApiService } from '@services/apiServices/api.service';
import { HttpService } from '@app/services/http-service';
import { CommentsModalsComponent } from '@app/supervisor/mission-details-m/mdp-modals/comments-modals/comments-modals.component';
import { SurveysModalComponent } from '@app/supervisor/mission-details-m/mdp-modals/surveys-modal/surveys-modal.component';
import { EventService } from '@services/events/event.service';
import { ReassignModalsComponent } from '@app/supervisor/mission-details-m/mdp-modals/reassign-modals/reassign-modals.component';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { MissionListAlertsService } from '@app/services/Alerts/mission-list-alerts.service';
import swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-mission-details-stands',
  templateUrl: './mission-details-stands.component.html',
  styleUrls: ['./mission-details-stands.component.css']
})
export class MissionDetailsStandsComponent implements OnInit {

  private utilityFunctions = new UtilityFunctions();
  private subscriptions: Subscription[] = [];
  @ViewChild("statusChangePopup") statusChangePopup: TemplateRef<any>;
  tableHeaders: any = ["Event No.", "Event Type", "Start time", "Duration", "Distance", "Distance difference", "Comment", "Survey", "Validation"];
  tableData: Array<any> = [];
  commentsModalRef: NgbModalRef;
  surveyModalRef: NgbModalRef;
  ressignModalRef: NgbModalRef;
  missionId: any;
  missionTypeId: any;
  missionName: any;
  missionDetails: Array<any> = [];
  shiftTablesData: Array<any> = [];
  userData: any = JSON.parse(localStorage.getItem('user-data'));
  util: any;
  offset: any = 0;
  limit: any = 100;
  evaluateFlag: boolean=false;
  hideApproveButton: boolean=false;
  marketDay: Date;
  constructor(
    public httpService: HttpService,
    public route: ActivatedRoute,
    public http: Http,
    public customerSurveyAlert: CustomerSurveyAlertsService,
    public eventService: EventService,
    public apiService: ApiService,
    public datePipe: DatePipe,
    public ngbModalService: NgbModal,
    public router:Router,
    private modalService: NgbModal,
    public missionListAlertsService: MissionListAlertsService,
    public translate: TranslateService) {
    route.params.subscribe(params => {
      this.missionId = params.id;
      this.missionTypeId = params.missionTypeId;
    });
  }
  ngOnInit() {
    // this.util = UTILS;
    this.getSurveyMissionProgressReport();
  }
marketDays=[];
userId;

  getSurveyMissionProgressReport() {
    this.eventService.showLoader({});
    this.subscriptions.push(this.apiService.getstandsMissionMpd({ 'missionId': this.missionId }).subscribe(res => {
      if (res.data) {
        this.missionDetails = res.data;
        console.log(this.missionDetails);
        this.marketDay=new Date(res.data.date);
        console.log(res.data.date);
        
        var weekdays = new Array(7);
        weekdays[0] = "Sunday";
        weekdays[1] = "Monday";
        weekdays[2] = "Tuesday";
        weekdays[3] = "Wednesday";
        weekdays[4] = "Thursday";
        weekdays[5] = "Friday";
        weekdays[6] = "Saturday";
        this.marketDays.push(weekdays[this.marketDay.getDay()]);

        this.userId=res.data.fieldAgent.userId
        if(res.data.evaluateFlag==true){
          this.evaluateFlag=true;
        }
        else
          this.evaluateFlag=false;
        
        let element=this.missionDetails['marketZone']
       
        // element.scheduleMonOpen?this.marketDays.push('Monday'):''
        // element.scheduleTueOpen?this.marketDays.push('Tuesday'):''
        // element.scheduleWedOpen?this.marketDays.push('Wednesday'):''
        // element.scheduleThurOpen?this.marketDays.push('Thursday'):''
        // element.scheduleFriOpen?this.marketDays.push('Friday'):''
        // element.scheduleSatOpen?this.marketDays.push('Saturday'):''
        // element.scheduleSunOpen?this.marketDays.push('Sunday'):''
        // this.itteratorForTablesData();
        this.getUserSurveyReport(this.missionDetails,'index',false)
        console.log("marketdays=",this.marketDays);
        console.log(this.missionDetails);
        
      }
      this.eventService.hideLoader({});
    }, err => {
      this.eventService.hideLoader({});
    }));
  }
  shiftTablesbeforeSort=[]
  numberOfValidSurvey;
  numberOfSurveyReports;
  tableInfo;
  dataId;
  standsDetails=[];
  getUserSurveyReport(data, index, status: any = false) {
    this.dataId=data.id
    this.numberOfValidSurvey=0;
    this.numberOfSurveyReports=0;
    this.subscriptions.push(this.apiService.getstandsMissionInfo({ 'id': data.id })
      .subscribe(res => {
        this.eventService.hideLoader({});
        console.log("res=",res);
        
        if (res.data) {
         this.standsDetails=[];
         this.tableInfo=res.data;
         this.tableInfo.forEach(data => {
           const length=data.stands.length
           console.log("length=",length);
           
           data.stands.forEach((stands,index) => {
             console.log("stands=",stands);
             stands['standsGroupNo']=data.standsGroupNo

             if(index==0){
              stands['image1']=data.standGroupFirstImage
              stands['image']="image1"
             }
             if(index == length-1){
              stands['image2']=data.standGroupLastImage
              stands['image']="image2"

             }

             this.standsDetails.push(stands)

           });
         });
      console.log("standdetails=",this.standsDetails);
      
        }

    
      }, err => { this.eventService.hideLoader({}); }));
  }

  loadMore(id, index) { this.eventService.showLoader({}); this.offset = this.limit + this.offset; this.getUserSurveyReport({ "id": id }, index); }

  
  applySort(key,order){
    console.log("key=",key,order);
    console.log("tableinfo=",this.tableInfo);
      this.standsDetails= _.orderBy(this.standsDetails,key,order );

  
    
    

  }
 
  private modalRef;
  @ViewChild('myModal') myModal;
  openModal(){
    this.modalRef = this.modalService.open(this.myModal, {
        backdrop: true,
        keyboard: false,
    })
}
close(){
  this.modalRef.close();
}
evaluation;
check(key){
  console.log("key=",key);
  this.evaluation=key; 
}
evaluationDone=false;
evaluateMission(){
  this.evaluationDone=true;
  this.modalRef.close();
  let bad,correct,perfect
  if(this.evaluation=='bad'){
    bad=true;
    correct=false;
    perfect=false;
  } else if(this.evaluation=='correct'){
    correct=true;
    bad=false;
    perfect=false;
  }else {
    perfect=true;
    correct=false;
    bad=false;
  }
  const reqBody={
    missionId:this.missionId,
    agentId:this.userId,
    badlyDone:bad,
    correctlyDone:correct,
    perfectlyDone:perfect
  }
  this.apiService.posEvaluate(reqBody).subscribe((res)=>{
    console.log("success=",res);
    if(res.responseCode==200){
      this.evaluateFlag=true;
      this.missionListAlertsService.evaluateMpd();
    }
    
  })
}

  openCommentsModal(comment, index, details) {
    this.commentsModalRef = this.ngbModalService.open(CommentsModalsComponent, { size: "sm" });
    this.commentsModalRef.componentInstance.commentData = comment;
    this.commentsModalRef.componentInstance.details = details;
    this.commentsModalRef.result.then(rs => {
      if (rs != 'crossClocked') { this.getUserSurveyReport({ id: details.id }, index, true); }
    });
  }

  reassignKar(){
    this.modalRef.close();
    this.router.navigate([`supervisor/missions/details/${this.missionId}/7/stands/reassign`]);
  }
  
  /**Open Ressign Modal start**/
  @ViewChild ('reassignModal1') reassignModal1;
  openReassignModal(reaasign) {
    // this.modalRef = this.modalService.open(this.reassignModal1, {
    //   backdrop: true,
    //   keyboard: false
    // });

    let campaignEndDate=new Date(reaasign.campaignEndDate)
    let currentDate=new Date();
    // if(campaignEndDate >= currentDate){
    //   this.router.navigate([`supervisor/missions/details/${this.missionId}/7/stands/reassign`])
     
    // }
    if(campaignEndDate >= currentDate){
      this.router.navigate([`supervisor/missions/details/${this.missionId}/7/stands/reassign`])


    }
    else if(campaignEndDate.getDate() >= currentDate.getDate() && campaignEndDate.getMonth() >= currentDate.getMonth() && campaignEndDate.getFullYear() >= currentDate.getFullYear()){
    this.router.navigate([`supervisor/missions/details/${this.missionId}/7/stands/reassign`])

   
  }
    else{
    return swal({
      title: this.translate.instant('The mission is within an overdue campaign. If you want to select a new assignment date, please first contact your Admin in order to expand campaign duration.'),
      type: 'warning', 
    
      confirmButtonText: this.translate.instant('OK'),
    });
  }
  }
  /**Open Ressign Modal END**/
  gotoLocation(zone){
  console.log("name=",zone);
  
  this.router.navigate(['/supervisor/edit-location/market-zone/' + zone.shortName + '/002' + '/' + zone.id]);

}

questionList;
openSurveySheet=false;
  openSurveysModal(questionList, index, id) {
    console.log("questionlist=",questionList);
    this.openSurveySheet=true;
    this.questionList=questionList

  }
  closeSheet(event){
    if(event==="true"){
      this.openSurveySheet=false;
    }
    
  }
  approveMission(shiftData) {
    let reqBody = { "missionId": this.missionId, "userId": shiftData.fieldAgent.userId, "shiftId": shiftData.shift.shiftId, "iterations": null, "supervisorId": this.userData.userId, "currentStatus": shiftData.status };
    this.subscriptions.push(this.apiService.approveMission('', reqBody)
      .subscribe(res => {
        if (res.responseCode == "200") { 
          this.shiftTablesData = []; 
          this.getSurveyMissionProgressReport(); 
          this.hideApproveButton=true;
        }
      }, err => { err; }));
  }

  isValidStatusAvail(indx) {
    let shiftData = this.shiftTablesData[indx];
    if (shiftData) {
      for (let i = 0; i < shiftData.length; i++) {
        const element = shiftData[i];
        if (isMatch(element, { surveyStatus: 'Yet to validate' })) {
          return true;
        } else if (shiftData.length == (i - 1) && isMatch(element, { surveyStatus: 'Yet to validate' })) {
          return false;
        }
      }
    }
  }

  /* Dynamic Pipes Starts*/
  getUIDate(date) { return (date) ? this.datePipe.transform(date, 'dd/MM/yyyy') : 'NA'; };
  getUITime(date) { return (!isNull(date)) ? `${this.datePipe.transform(date, "HH:mm:ss")}` : 'NA'; };
  getIsNull(value) { return (!isNull(value) ? value : 'NA'); };
  /* Dynamic Pipes Ends */

  getUTCDate(date) {
    if (!isNull(date)) {
      let d = new Date(date);
      let cd = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes(), d.getSeconds(), d.getMilliseconds()));
      if (cd.toString() != 'Invalid Date') {
        return this.datePipe.transform(cd, `HH:mm`) + ` ${(cd.getHours() >= 12) ? 'PM' : 'AM'}`;
      }
    } else {
      return 'NA';
    }
  }
  isLoader(totalRecords) { if (totalRecords > this.limit && totalRecords > (this.offset + this.limit)) return true; return false; }
  // cssLoader(data, detailsStatus) { if (!data && detailsStatus.totalSurveys) return true; return false; }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }


}
