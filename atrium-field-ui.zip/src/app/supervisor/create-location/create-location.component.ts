// core imports
import {
  Component, OnInit, ViewChild
} from '@angular/core';
import { Location } from '@angular/common';

// 3rd party
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

// app
import { ApiService } from '@services/apiServices/api.service';
import { EventService } from '@services/events/event.service';
import { Router } from '@angular/router';
import { CreateSurveyUtilsService } from '../create-survey/createSurveyUtils/create-survey-utils.service';
import { MissionListAlertsService } from '@app/services/Alerts/mission-list-alerts.service';
import { StorageService } from '@app/services/storage-service.service';
import { Subscription, Observable } from 'rxjs';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { isNull } from 'util';
import { UTILS } from '@app/services/global-utility.service';

@Component({
  selector: 'app-create-location',
  templateUrl: './create-location.component.html',
  styleUrls: ['./create-location.component.css']
})
export class CreateLocationComponent {
  @ViewChild('surveySelectionModal') private surveySelectionModal;

  survey;
  missionTypesLoaded;
  missionTypes;
  selectedMissionType;
  modal;
  closeResult;
  checked;

  private subscriptions: Subscription[] = [];
  private utilityFunctions = new UtilityFunctions();
  private sortReverse: boolean = false;
  private isClicked: boolean = true;
  changeMissionDateModalRef: NgbModalRef;
  currentUser: any = JSON.parse(localStorage.getItem('user-data'));
  isSearch: boolean = false;
  isChecked: boolean = false;
  locationLoader: boolean = false;
  isShow: boolean= false;
  searchKey: any;
  sortType: string ='locationName';
  type: string ='quartierName';
  campaings: Array<any> = [];
  locationTypes: Array<any> = [];
  locations: Array<any> = [];
  locationsAll: Array<any> = [];
  selectedLocation: any = { 'name': '' };
  datePipe: any;
  filteredOrders: any [];
  checkpoint: any;
  id: string;
  isclicked: boolean=true;

  constructor(
    public api: ApiService,
    public modalService: NgbModal,
    public location: Location,
    public event: EventService,
    public router: Router,
    public _event: EventService,
    public apiService: ApiService,
    private storageService: StorageService,
    public missionListAlertsService: MissionListAlertsService,
    public custUtils: CreateSurveyUtilsService) {

  }

  ngOnInit() {
    this.getMissionTypes();
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this.sortReverse=false;
    this.isClicked=true;
    this._event.broadcast({ eventName: 'showLoader', data: '' });
    this.storageService.removeData('missionId&quartierId')
    this.getLocations();
  }

  getMissionTypes() {
    this.missionTypesLoaded = false;
    this.missionTypes = [];

    this.api.getMissionTypes().subscribe(res => {
      let typeLen = res.data.length;
      res.data.forEach(type => {
        if (type.id === 3 || type.id === 4 || type.id === 2) {
          if (type.id === 3) {
            type.name = 'Pedestrian Flow';
            this.missionTypes.push(type);
          }
          else this.missionTypes.push(type);
        }
        typeLen--;
        if (typeLen === 0) {
          this.selectedMissionType = this.missionTypes[0];
          this.missionTypes.splice(0, 1);
          this.missionTypesLoaded = true;
          this.event.broadcast({ eventName: 'hideLoader', data: '' });
          this.changeSurveyModal(this.surveySelectionModal);
        }
      });
    }, err => {
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
    });
  }

  changeSurveyModal(modal) {
    this.modal = this.modalService.open(modal, { keyboard: false, backdrop: false });
    this.modal.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return reason;
    }
  }

  submitSurveyType(selectedMissionType) {
    if(selectedMissionType==3){
    this.router.navigate([`/supervisor/location/cs-zone/${selectedMissionType}`]);
    this.modal.close();
    }
    else if(selectedMissionType==1){
      this.router.navigate([`/supervisor/location/pf-zone/${selectedMissionType}`]);
      this.modal.close();
    }
    else{
      this.router.navigate([`/supervisor/location/market-zone/${selectedMissionType}`]);
      this.modal.close();
    }
  }
  close(){
    this.modal.close();
    this.router.navigate([`/supervisor/location`]);
  }
  
  /* API Requests */
  getLocations() {
    this.locationLoader = true;
    this.subscriptions.push(this.apiService.getLocations({ 'sortBy': 'locationName,asc', 'size': 10 })
      .subscribe(res => {
        this.locationsAll = res.data.content;
        this.locations = (!isNull(res.data)) ? res.data.content : [];
        this.getLocationType();
        this.locationLoader = false;
        this.filteredOrders = this.locations;
        // this.('name',);
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
      }, err => {
        this.locationsAll = [];
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.locationLoader = false;
      }));
  }

  getLocationByName(locationName, searchBy = undefined) {

    this.locationLoader = true;
    this.subscriptions.push(this.apiService.getLocations({ searchBy, locationName, size: 10 })
      .subscribe(res => {
        this.locations = (!isNull(res.data)) ? res.data.content : [];
        this.locationLoader = false;
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
      }, err => {
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.locationLoader = false;
      }));
  }

  toggleDisplay(id) {
    console.log('filteredOrders',this.filteredOrders);
    this.filteredOrders.forEach((element)=>{
      element.flag=false;
      if(element.id==id){
        element.flag=true;
        this.isShow=!this.isShow;
      }

    });
    
    
  }

  getLocationType() {
    this.locationLoader = true;
    this.subscriptions.push(this.apiService.getLocationType({})
      .subscribe(res => {
        this.locationTypes = res.data;
        
        this.locationTypes.unshift({id:4 , name: "All" });      
        this.selectedLocation = this.locationTypes[0];
        this.locationLoader = false;
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
      }, err => {
        this.locationTypes=[];
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.locationLoader = false;
      }));

  }
  getLocationByType(filterBy, id) {
    this.locationLoader = true;
    id = 'locationType,' + id;
    this.subscriptions.push(this.apiService.getLocations({ filterBy: id, size: 10 })
      .subscribe(res => {        
        if(res.data.content.length!==0){
             
        this.locationsAll = res.data.content;
        this.filteredOrders = res.data.content;
        this.locations=res.data.content;
        this.locationLoader = false;
        this._event.broadcast({ eventName: 'hideLoader', data: '' })
        }else{
          
          this._event.broadcast({ eventName: 'hideLoader', data: '' });
          this.locationLoader = false;
          this.locations=[];
          }
      },err=>{
        
        
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.locationLoader = false;
        this.locations=[];
      })); 
  }

  selectLocationType(location) {
    this.locationLoader = true;
    this.selectedLocation = location;
    if (this.selectedLocation.name === 'All') {
      this.getLocations();
    }
    else {
      this.getLocationByType(undefined, this.selectedLocation.id);
    }
  }

  /* redirectors */
  editLocation(id,name,locationId) {
    this.custUtils.translateMessageObject({
      title: 'Edit Location!',
      text: 'This edited location will replace the old location for new missions. But it won’t affect all the missions that are already created. Are you sure you want to edit it?',
      type: 'warning',
      outsideClick: false,
      cancelBtnText: 'No',
      confirmBtnText: 'Yes',
      showCancelBtn: true
    }, message => {
      this.custUtils.translateAndPop(message).then(() => {
        this.gotoEdit(id,name,locationId);
      }).catch(() => {
        this.router.navigate([`/supervisor/location`]);
        this.getLocations();
      });
    });
  }

  gotoEdit(selectedId,name,locationId) {
    console.log('location id:',locationId);
    
    if (selectedId==3) {
      this.router.navigate(['/supervisor/edit-location/cs-zone/' + name + '/' +locationId]);
    }
    else if (selectedId ==1) {
      this.router.navigate(['/supervisor/edit-location/pf-zone/'+ name + '/' + locationId]);
    }
    else {
      console.log('inside',selectedId);
      this.router.navigate(['/supervisor/edit-location/market-zone/' + name + '/' + locationId]);
    }
}


deleteLocation(id) {
  const req = {
    locationId: id,
  };
  this.custUtils.translateMessageObject({
    title: 'Delete Location!',
    text: 'This location will be removed from location list and won’t be selectable for new missions. But it won’t affect all missions already created. Are you sure you want to delete it?',
    type: 'warning',
    outsideClick: false,
    cancelBtnText: 'No',
    confirmBtnText: 'Yes',
    showCancelBtn: true
  }, message => {
    this.custUtils.translateAndPop(message).then(() => {
      this.gotoDelete(req);
    }).catch(() => {
      this.router.navigate([`/supervisor/location`]);
      this.getLocations();
    });
  });
}

gotoDelete(req) {
  this.locationLoader = true;
  this.api.deleteLocation(req).subscribe(res => {
    this.custUtils.translateMessageObject({
      title: 'Location deleted successfully!',
      text: '',
      type: 'success',
      outsideClick: false,
      cancelBtnText: '',
      confirmBtnText: 'Ok',
      showCancelBtn: false
    }, message => {
      this.custUtils.translateAndPop(message).then(() => {
        this.router.navigate([`/supervisor/location`]);
        this.getLocations();
      }).catch(() => {

      });
    });
  }, err => {
    this.custUtils.translateMessageObject({
      title: 'Something went wrong',
      text: 'Location not deleted, please try again',
      type: 'error',
      outsideClick: true,
      cancelBtnText: '',
      confirmBtnText: 'Ok',
      showCancelBtn: false
    }, message => {
      this.custUtils.translateAndPop(message).then(() => {
        this.router.navigate([`/supervisor/location`]);
        this.getLocations();
      }).catch(() => {
        this.router.navigate([`/supervisor/location`]);
        this.getLocations();
      });
    });
  });
}

/* dynamic css */
dropdownClicked($event) { }
/* Validators */
isValidMissionDate(d) {
  let currentDate_ = new Date(UTILS.getDateFormatWithoutZero(UTILS.getDatePickerDateFormat(new Date()))).getTime();
  let startDateMission = new Date(UTILS.getDateFormatWithoutZero(d)).getTime();
  return startDateMission > currentDate_;
}
/* Validators */
/* Local Utility functions */
getTransformedDate(d: string) {
  const d_ = (d) ? new Date(d.replace(/\s/g, "T")) : null;
  if (d_) return this.datePipe.transform(d_, 'yyyy-MM-dd');
  else return 'NA';
}
/* getters */
/* Search and toggle the search input box */
  clearSearch() {
    this.searchKey = ''; 
    this.isSearch = false; 
    this.selectedLocation='';
    this.getLocations();
  }

  searchMissionsAndToggle(_isSearch, _searchKey) {

    if (!_isSearch && (this.searchKey == '' || _searchKey == undefined)) { this.isSearch = true; }
    if (_isSearch && _searchKey) {
      this.locationLoader = true;
      console.log("inside search",);
      this.getLocationByName(undefined, _searchKey.locationName);
    }
  }

  search = (_searchKey: Observable<string>) => {
    return _searchKey.
      debounceTime(100).
      distinctUntilChanged().
      map(term => term.length < 2 ? []
        : this.locationsAll.filter(v => v.locationName.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10)
      )
  }

  /* Search and toggle the search input box */
  sortOrders(property) {

    this.sortType = property;
    this.sortReverse = !this.sortReverse;
    this.isClicked = !this.isClicked;
    this.filteredOrders.sort(this.dynamicSort(property));
  }

  sortOrders1(property) {

    this.type = property;
    this.sortReverse = !this.sortReverse;
    this.isClicked = !this.isClicked;
    this.filteredOrders.sort(this.dynamicSort1(property));
  }

  
dynamicSort1(property) {
  let sortOrder = 1;

  if (this.sortReverse)
    sortOrder = -1;
  return function (a, b) {
    
    let result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;

    return result * sortOrder;
  }
}


dynamicSort(property) {
  let sortOrder = 1;

  if (this.sortReverse){
    sortOrder = -1;
  }
  return function (a, b) {
  
    let result = (a[property].toLowerCase() < b[property].toLowerCase()) ? -1 : (a[property].toLowerCase() > b[property].toLowerCase()) ? 1 : 0;
   
    let data=result * sortOrder;
    return data;
  }
}

  filterOrders(search: string,location) {
    // this.selectLocationType(location);
    var items = search.split(' ').filter(o => o).map(o => o.toLowerCase());
    this.filteredOrders = this.locationsAll.filter(o => {
      for (var item of items) {
        var flag = false;
        for (var prop in o) {
          if (prop != '$$hashKey' && (o[prop] + '').toLowerCase().indexOf(item) != -1) {
            flag = true;
            break;
          }
        }
        if (!flag)
          return false;
      }
      return true;

    });
    console.log('filteredOrders', this.filteredOrders);
    if (this.filteredOrders.length === 0) {
      if (location == 'Circuit') {
        location = 1;
      } else if (location == 'Market Zone') {
        location = 2;
      } else if (location == 'Survey Zone') {
        location = 3;
      }
      const locationName="locationName"+search;
      const locationType="locationType"+location;
      this.api.getLocations({ 'searchBy':locationName, 'filterBy': locationType }).subscribe(res => {
        if (res.responseMessage == 'success' && res.data) {
          this.filteredOrders = res.data;
        }
        else {
        }
      });
    }
  }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }
}