// core
import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

// 3rd party
import swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';

// app
import { OnlyFewLettersPipe } from '@pipes/only-few-letters.pipe';
import { InitialsService } from '@services/initials/initials.service';
import { CampaignSummaryService } from '@services/campaign-summary/campaign-summary.service';
import { EventService } from '@services/events/event.service';
import { HttpService } from '@app/services/http-service';
import { TranslationService } from '@services/translation/translation.service';

@Component({
  selector: 'app-supervisor',
  templateUrl: './supervisor.component.html',
  styleUrls: ['./supervisor.component.css'],
  providers: [OnlyFewLettersPipe]
})
export class SupervisorComponent implements OnInit {
  smallSideBar: boolean;
  initials;
  showSideBar = false;
  user;
  sessionObj;
  dontShowTopSide = false;
  showExtraMenuItems = false;
  pushRightClass = 'show-menu-modal';
  viewCalendar = "View Calendar";
  ViewCampaigns = "View Campaigns";
  viewMissions = "Missions";
  viewLocation = "Location Management";
  viewReport = "Report";

  constructor(
    public router: Router,
    public initialsSevice: InitialsService,
    public campData: CampaignSummaryService,
    public event: EventService,
    private translate: TranslateService,
    public translateService: TranslationService,
    public http: HttpService
  ) {
    this.router.events.subscribe(val => {
      if (val instanceof NavigationEnd && window.innerWidth <= 992) {
        this.showExtraMenuItems = true;
      } else if (val instanceof NavigationEnd && window.innerWidth >= 992) {
        this.showExtraMenuItems = false;
      }
    });
  }

  ngOnInit() {
    const localUserData = localStorage.getItem('user-data');
    this.user = JSON.parse(localUserData);
    // this.translate.setDefaultLang('en'); // remove this for activating translation
    /* Activate this for translation */

    this.user.preferredLanguage
      ? this.changeLanguage()
      : this.translate.setDefaultLang('en');
    /* Activate this for translation */

    this.sessionObj = JSON.parse(
      sessionStorage.getItem('percentageWithDegrees')
    );
    if (!localUserData) {
      this.router.navigate(['login']);
    } else {
      if (!this.sessionObj) {
        this.event.broadcast({ eventName: 'showLoader', data: '' });
        localStorage.setItem('reloader', 'true');
      }
    }
    // if (this.user.resetProfile && this.user.isActive) {
    //   this.dontShowTopSide = true;
    // }
    $('.nav-sidebar a').on('click', function() {
      $('.nav-sidebar')
        .find('.active')
        .removeClass('active');
      $(this)
        .parent()
        .addClass('active');
    });
    this.smallSideBar = false;
    if (this.user.firstName !== null && this.user.lastName !== null) {
      this.initials = this.initialsSevice.fetch(
        this.user.firstName,
        this.user.lastName
      );
      //this.router.navigate(['supervisor/calendar'])
    }
  }

  toggleSidebar() {
    const dom = document.querySelector('.toggler-icon');
    const mainCont = document.querySelector('.main-container');
    const sidebar = document.querySelector('.mini-sidebar');
    this.smallSideBar = true;
    mainCont.classList.toggle('ml-60');
    sidebar.classList.toggle('sidebar-toggler');
    dom.classList.toggle('change');
  }

  isToggled(): boolean {
    const dom = document.querySelector('body');
    return dom.classList.contains(this.pushRightClass);
  }

  toggleIconsBar() {
    if (this.smallSideBar) {
      this.smallSideBar = false;
    } else {
      this.smallSideBar = true;
    }
  }

  changeLanguage() {
    if (this.user.preferredLanguage === 3) {
      this.translate.setDefaultLang('en');
    } else if (this.user.preferredLanguage === 2) {
      this.translate.setDefaultLang('nl');
    } else {
      this.translate.setDefaultLang('fr');
    }
  }

  onLoggedout() {
    if (this.router.url === '/supervisor/profile') {
      this.translateService
        .getLanguageValue('Are you sure you want to log out')
        .subscribe(resTitle => {
          this.translateService
            .getLanguageValue('Yes, log out')
            .subscribe(resBtnMsg => {
              swal({
                title: `${resTitle} `,
                //title: `${resTitle} ?`,
                text: '',
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: `${resBtnMsg} !`
              })
                .then(success => {
                  this.http.SecureGet('/user/logout').subscribe(
                    res => {
                      localStorage.clear();
                      sessionStorage.clear();
                      window.location.reload();
                    },
                    err => {
                      localStorage.clear();
                      sessionStorage.clear();
                      window.location.reload();
                    }
                  );
                })
                .catch(() => {
                  console.log('Session still active');
                });
            });
        });
    } else {
      this.translateService
        .getLanguageValue('Are you sure you want to log out')
        .subscribe(resTitle => {
          this.translateService
            .getLanguageValue('Yes, log out')
            .subscribe(resBtnMsg => {
              swal({
                title: `${resTitle} `,
                //title: `${resTitle} ?`,
                text: '',
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: `${resBtnMsg} !`
              }).then(success => {
                this.http.SecureGet('/user/logout').subscribe(
                  res => {
                    localStorage.clear();
                    sessionStorage.clear();
                    this.router.navigate(['/login']);
                  },
                  err => {
                    localStorage.clear();
                    sessionStorage.clear();
                    this.router.navigate(['/login']);
                  }
                );
              });
            });
        });
    }
  }
  highlightIcon(flag){
    if (flag == 'View Calendar'){
      this.viewCalendar = 'Calendar';
      this.viewCalendar = this.translate.instant(this.viewCalendar);
    } else if (flag == 'View Campaigns'){
      this.ViewCampaigns = this.translate.instant(flag);
    } else if (flag == 'Missions'){
      this.viewMissions = this.translate.instant(flag);
    } else if (flag == 'Location Management') {
      this.viewLocation = this.translate.instant(flag);
    } else if (flag == 'Report') {
      this.viewReport = this.translate.instant(flag);
    }
  }
}
