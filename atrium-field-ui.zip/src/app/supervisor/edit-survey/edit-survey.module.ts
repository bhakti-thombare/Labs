import { NgSelectModule } from '@ng-select/ng-select';
// core
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

// 3rd party
import { TranslateModule } from '@ngx-translate/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxMapboxGLModule } from 'ngx-mapbox-gl';
import { Ng4FilesModule } from 'angular4-files-upload';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { TagInputModule } from 'ngx-chips';

// app
import { CreateSurveyModule } from '@app/supervisor/create-survey/create-survey.module';
import { CONFIG } from '@app/config';
import { EditMissionPedestrianComponent } from '@app/supervisor/edit-survey/edit-mission-pedestrian/edit-mission-pedestrian.component';
import { EditMissionCustomerSurveyComponent } from '@app/supervisor/edit-survey/edit-mission-customer-survey/edit-mission-customer-survey.component';
import { PipesModule } from '@pipes/pipes.module';
import { EditSurveyMapComponent } from '@app/supervisor/edit-survey/maps/edit-survey-map/edit-survey-map.component';
import { MissionDateChangeModalComponent } from '@app/supervisor/edit-survey/mission-date-change-modal/mission-date-change-modal.component';
import { EditMissionPosPoiComponent } from '@app/supervisor/edit-survey/edit-mission-pos-poi/edit-mission-pos-poi.component';
import { EditQuartierComponent } from '@app/supervisor/edit-survey/edit-mission-pos-poi/edit-quartier/edit-quartier.component';
import { EditPosAssignmentsComponent } from '@app/supervisor/edit-survey/edit-mission-pos-poi/edit-pos-assignments/edit-pos-assignments.component';
import { EditMissionStandsComponent } from './edit-mission-stands/edit-mission-stands.component';
@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
    NgbModule,
    PipesModule,
    FormsModule,
    ReactiveFormsModule,
    CreateSurveyModule,
    NgxMapboxGLModule.forRoot({
      accessToken: CONFIG.mapBoxAccessToken
    }),
    Ng4FilesModule,
    TagInputModule,
    SelectDropDownModule,
    NgSelectModule
  ],
  declarations: [EditMissionPedestrianComponent, EditMissionCustomerSurveyComponent, EditSurveyMapComponent, MissionDateChangeModalComponent, EditMissionPosPoiComponent, EditQuartierComponent, EditPosAssignmentsComponent, EditMissionStandsComponent],
  exports: [EditMissionStandsComponent,EditMissionPedestrianComponent, EditMissionCustomerSurveyComponent, MissionDateChangeModalComponent, EditMissionPosPoiComponent],
  entryComponents:[MissionDateChangeModalComponent]
})
export class EditSurveyModule { }
