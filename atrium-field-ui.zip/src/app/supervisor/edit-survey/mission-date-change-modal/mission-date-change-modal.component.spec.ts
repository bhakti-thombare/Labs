import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MissionDateChangeModalComponent } from './mission-date-change-modal.component';

describe('MissionDateChangeModalComponent', () => {
  let component: MissionDateChangeModalComponent;
  let fixture: ComponentFixture<MissionDateChangeModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MissionDateChangeModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MissionDateChangeModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
