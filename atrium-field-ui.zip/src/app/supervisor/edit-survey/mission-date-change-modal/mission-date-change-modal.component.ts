// core
import { Component, OnInit, OnDestroy } from '@angular/core';

// 3rd party
import {findWhere} from "underscore";
import { Subscription } from 'rxjs/Subscription';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';

// app
import { CustomerSurveyAlertsService } from '@services/Alerts/customer-survey-alerts.service';
import { ApiService } from '@services/apiServices/api.service';
import { UTILS } from '@services/global-utility.service';
import { Globals } from '@app/constants/constants';
import { UtilityFunctions } from '@app/shared/utility-functions';
@Component({
  selector: 'app-mission-date-change-modal',
  templateUrl: './mission-date-change-modal.component.html',
  styleUrls: ['./mission-date-change-modal.component.css']
})
export class MissionDateChangeModalComponent implements OnInit, OnDestroy {
  private utilityFunctions = new UtilityFunctions();  
  private subscriptions: Subscription[] = [];
  today: Date = new Date();
  maxDate: any;
  user = JSON.parse(localStorage.getItem('user-data'));
  missionDataModal: any = {
    missionId: "",
    updatedBy: this.user.userId,
    startDate: "",
    endDate: ""
  };
  missionId
  localUtilInstance: any;
  constructor(public modalService: NgbModal,
    public alertsService: CustomerSurveyAlertsService,
    public activeModal: NgbActiveModal, public apiService: ApiService) { this.localUtilInstance = UTILS; }

  ngOnInit() { }
  close(closeClickedBy) {
    if (closeClickedBy === 'CloseClicked') this.activeModal.close('closed');
    if (closeClickedBy === 'SubmitClicked') this.activeModal.close('SubmitClicked');
    if (closeClickedBy === 'CancelClicked') this.activeModal.close('closed');
  }
  getEndDate(d1) {
    this.missionDataModal.endDate = d1;
  }
  isDisabled(date: NgbDate, current: { month: number }) { return (findWhere(Globals.BUSY_DATES, UTILS.getDatePickerIntFormat(date))) ? true : false; }

  submitNewMissionDate() {
    this.missionDataModal.missionId = this.missionId;
    this.missionDataModal.startDate = UTILS.getDateFormat(this.missionDataModal.startDate);
    this.missionDataModal.endDate = UTILS.getDateFormat(this.missionDataModal.endDate);
    this.subscriptions.push(this.apiService.changeMissionDate(this.missionDataModal)
      .subscribe(res => {
        if (res.responseCode == "200") { this.activeModal.close(); }
      }, err => { this.alertsService.somethingWentWrongAlert().then(() => { this.activeModal.close(); }) }));
  }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
 }
 
}
