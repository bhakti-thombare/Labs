import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditMissionPosPoiComponent } from './edit-mission-pos-poi.component';

describe('EditMissionPosPoiComponent', () => {
  let component: EditMissionPosPoiComponent;
  let fixture: ComponentFixture<EditMissionPosPoiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditMissionPosPoiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditMissionPosPoiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
