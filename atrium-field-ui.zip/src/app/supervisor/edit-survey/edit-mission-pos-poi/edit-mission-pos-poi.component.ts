// core imports
import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

// 3rd party imports
import {
  each,
  map,
  isNull,
  isArray,
  filter,
  isEmpty,
  defaults,
  findWhere,
  isUndefined
} from 'underscore';
import { Subscription } from 'rxjs/Subscription';

// app imports
import { UtilityFunctions } from '@app/shared/utility-functions';
import { ApiService } from '@app/services/apiServices/api.service';
import { EventService } from '@app/services/events/event.service';
import { UnassignedUsersPos } from '@services/apiServices/reqBodies';
import { CustomerSurveyAlertsService } from '@app/services/Alerts/customer-survey-alerts.service';
import {
  UpdateMission,
  AssignFA2POS,
  MapPOS,
  MapCheckpoints
} from '@app/services/apiServices/reqBodies';
import { UTILS } from '@app/services/global-utility.service';
import { missionTypes, statuses, Globals } from '@app/constants/constants';
import { Step4Wizards } from '@app/model/pos-models';
import { TranslateService } from '@ngx-translate/core';
import { PedestrainAlertsService } from '@app/services/Alerts/pedestrainAlerts/pedestrain-alerts.service';
import { CampaignSummaryService } from '@app/services/campaign-summary/campaign-summary.service';
import { HttpService } from '@app/services/http-service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-edit-mission-pos-poi',
  templateUrl: './edit-mission-pos-poi.component.html',
  styleUrls: ['./edit-mission-pos-poi.component.css']
})
export class EditMissionPosPoiComponent implements OnInit {
  @Input() assignmentsEvent;
  @Input() mission: any = {};
  private utilityFunctions = new UtilityFunctions();
  private subscriptions: Subscription[] = [];
  missionId: number;
  step1Form: FormGroup;
  // byDefaultDisabled: Boolean = true;
  isQuartierValid: Boolean = true;
  // isAssignmentsValid: Boolean = false;
  // isMissionEditing: Boolean = false;
  //to reset the assignments in the assignments component
  isSubTypeChaged: Boolean = false;
  
  localUtilInstance: any;
  globals: any;
  maxDate: any;
  minDate: any;
  selectedMission: Array<any> = [];
  subType;
  missionName: string;
  quartier: any = null;
  quartierId;
  assignments: any;
  nameExists=false;
  name=false;
  description=false;
  classic: boolean = false;
  visits: boolean = false;
  pmr: boolean = false;
  selectedSubtype: any = null;
  isSkip: boolean = false;
  safari: boolean;
  transactionMsg: string;
  isQuartierReceived: boolean = false;
  isYetToAssignMissions: boolean = false;
  buttonEnabled=false; 
  isStepDone: Step4Wizards = {
    step1Completed: false,
    step2Completed: false,
    step3Completed: false,
    step4Completed: false
  };
  campaign: any = null;
  missionDates=[];
  coordinates: any = [];
  campaignOptions: Array<any> = [];
  unAssignedMissions: Array<any> = [];
  optionsQuartier: any = [];
  optionsAgents: any = [];
  optionsSubtype: any = [];
  options: any = [];
  unAssignedMission: any = {};
  campaingConfig: any = {};
  unAssignedMConf: any = {};
  config: any = {};
  configQuartier: any = {};
  configSubtype: any = {};
  configAgents: any = {};
  textControl = new FormControl();
  textControl1 = new FormControl();
  missionFromScratch: any = {};
  step3Form: FormGroup;
  userId: any; //This is for assigned users to mission
  userData: any = JSON.parse(localStorage.getItem('user-data'));
  missionStartDate: string;
  missionEndDate: string;
  checkpointFlag: string;
  quartierDetails: any = {};
  user: any = JSON.parse(localStorage.getItem('user-data'));
  quartierName: any;
  firstAttempt: Boolean = false;
  missionDescription: any;
  missions: any;
  isReassigned: boolean=false;
  today;
  hasQuartierDTO;

  isShift;
  constructor(
    public apiService: ApiService,
    public eventService: EventService,
    public http: HttpService,
    public _http: HttpClient,
    public router: Router,
    public fb: FormBuilder,
    private pedsAlerts: PedestrainAlertsService,
    private translate: TranslateService,
    public custAlerts: CustomerSurveyAlertsService,
    public activateRoute: ActivatedRoute,
    private CampaignSelected:CampaignSummaryService,
  ) {
    activateRoute.params.subscribe(params => {
      this.missionId = params.id;
      this.getAllMissions(this.missionId);
      this.getPosEditMissionPage();
    });
  }
  getAllMissions(missionId: number) {
    this.http.SecureGet('/ref/getAllMissions?id=' + missionId)
    .subscribe(res => {
      this.eventService.broadcast({ eventName: 'hideLoader', data: '' });
      this.missions = res.data.missions[0];
      if(this.missions.classic===true){
        this.classic=true;
        // this.mission.classic = true;
      }
      if(this.missions.prm===true){
        this.pmr = true;
        // this.mission.pmr = true;
      } 
      if(this.missions.visits===true) {
        this.visits = true;
        // this.mission.visits = true;
      }
      if(this.missions.missionStatus.statusId===10){
        this.isReassigned=true;
      }
      this.hasQuartierDTO = this.missions.quartierDto;

      if (this.missions.shift == null) {
        this.isShift = 'Morning';
      } else {
        if (this.missions.shift.shiftName == 'PM') {
          this.isShift = 'Afternoon';
        } else {
          this.isShift = 'Morning';
        }
      }
    }, err => { });
  }

  ngOnInit() {
    this.textControl1.valueChanges.pipe(
      ).subscribe((res)=>{
        // res=res.trim();
        res=$.trim(res);

           if(res !== ''){
             this.description=true
           } else {
             this.description=false
           }
           if(this.name && this.description){
               this.buttonEnabled=true;
           } else {
             this.buttonEnabled=false;
           }
      });
    this.textControl.valueChanges.pipe(
    ).subscribe((res)=>{
      //  res=(res.toString()).trim();
      res=$.trim(res)
      ;
      
      if(res !== ''){
        this.name=true
      } else {
        this.name=false
      }
      if(this.name && this.description){
        this.buttonEnabled=true;
    } else {
      this.buttonEnabled=false;
    }
    if(res!==''){
      this.apiService.getMissionName(res).subscribe((res)=>{
          this.nameExists = false;
        this.name = true;
    },(error)=>{
        this.name=false;
        this.nameExists=true;
    })
    }
      
    });
    this.campaingConfig = {
      displayKey: 'campaignName',
      search: true,
      placeholder: this.translate.instant('Select campaign'),
      multiple: false
    };
    this.unAssignedMConf = {
      displayKey: 'missionName',
      search: true,
      placeholder: this.translate.instant('Select Mission'),
      multiple: false,
      limitTo: 10
    };
    this.config = {
      displayKey: 'name',
      search: true,
      placeholder: this.translate.instant('Select capmpaign'),
      multiple: false,
      limitTo: 5
    };
    this.configQuartier = {
      displayKey: 'name',
      search: true,
      placeholder: this.translate.instant('Select quartier'),
      multiple: false,
      limitTo: 10
    };
    this.configSubtype = {
      displayKey: 'name',
      search: false,
      placeholder: this.translate.instant('Select Subtype'),
      multiple: false,
      notFoundText: this.translate.instant('No items found')
    };
    this.configAgents = {
      displayKey: 'fullname',
      search: true,
      placeholder: this.translate.instant('Select agent'),
      multiple: false
    };
    this.eventService.showLoader({});
    this.getAllCampaigns();
    this.step1Validation();
    // this.step3Validation();
    this.getAllPosMissions();
    this.userId = this.user.userId;
    
    this.localUtilInstance = UTILS;
    this.globals = Globals;
    
    
    // this.missionFromScratch = this.step1Form.value;
    // console.log('***this.userId::', this.userId);
  }
  compaignName;
  campaignData;
  campaignId;
  getAllCampaigns() {
    this.subscriptions.push(
      this.apiService
        .getAllCampaigns({ assignedTo: this.user.userId })
        .subscribe(
          res => {
            this.eventService.hideLoader({});

            //this.campaignOptions = res.data.campaigns;
            /** Start Code to get Valid Campaign in POS Creation Dropdown List (In Progress campaign only displayed By checking the End Date of the Campaign*/

            let tempCampList: any = [];
            const today = new Date(Date.now());
            const todayDate = new Date(
              today.getFullYear(),
              today.getMonth(),
              today.getDate()
            );
            //console.log("todayDate:::::",todayDate);
            res.data.campaigns.forEach(camp => {
              const campEndDay = parseInt(
                camp.campaignEndDate.split('-')[2].split(' ')[0],
                10
              );
              const campEndMonth = parseInt(
                camp.campaignEndDate.split('-')[1],
                10
              );
              const campEndYear = parseInt(
                camp.campaignEndDate.split('-')[0],
                10
              );
              const endDate = new Date(
                campEndYear,
                campEndMonth - 1,
                campEndDay,
                23,
                59,
                59,
                0
              );

              if (endDate >= todayDate) {
                //console.log("endDate::::====",endDate);
                tempCampList.push(camp);
              }
            });
            // this.campaignOptions = tempCampList;

            /* Start _1 :This is implemented by using Campaign Status as In-Progress
        let tempCampList: any = [];

        console.log("res",res.data.campaigns);
        res.data.campaigns.forEach(element => {
          if(element.campaignStatus.statusId == 2){
            //console.log("CAmpaign IN Prog:",element);
            tempCampList.push(element);
          }
        });
        //console.log(tempCampList);
        
        this.campaignOptions = tempCampList;
        /** End */
            // this.compaignName=res.data.campaigns[0].campaignName
            this.campaign=res.data.campaigns[0];
            this.campaignData=res.data.campaigns;
            const todaydate = new Date()

            if(this.CampaignSelected.selectedCampaign!==undefined){
              const campaignEndDate = new Date(this.CampaignSelected.selectedCampaign.campaignEndDate)
              if(!(campaignEndDate < today)){
                // this.compaignName=this.CampaignSelected.selectedCampaign.campaignName

              } else {
                this.campaignData.forEach((element,index)=>{
                  if(this.CampaignSelected.selectedCampaign.campaignId!==element.campaignId){
                    const campaignEndDate = new Date(element.campaignEndDate)
                    console.log("campaign undefined",campaignEndDate);
                    
                    if (!(campaignEndDate < today)){
                      // this.compaignName=element.campaignName
  
                    }
                  }
                })
              }
              this.campaignId=this.CampaignSelected.selectedCampaign.campaignId;
              this.campaignData.forEach((element,index)=>{
                if(this.CampaignSelected.selectedCampaign.campaignId!==element.campaignId){
                  const campaignEndDate = new Date(element.campaignEndDate)
                  
                  if (!(campaignEndDate < today)){
                    this.campaignOptions.push(element)

                  }
                }
              })
            } else {
              // this.compaignName=res.data.campaigns[0].campaignName
              this.campaignId=res.data.campaigns[0].campaignId;
              this.campaignData.forEach((element,index)=>{
                if(res.data.campaigns[0].campaignId!==element.campaignId){
                  const campaignEndDate = new Date(element.campaignEndDate)
                  console.log("campaign undefined",campaignEndDate);
                  
                  if (!(campaignEndDate < today)){
                  this.campaignOptions.push(element)
                }
              }
              })
            }
            
          
         
            

            
            // this.campaignOptions = res.data.campaigns; /** by Mohammad Shuaib */
          //  this.campaignOptions= this.campaignOptions.slice(1)
            
          },
          err => {
            this.eventService.hideLoader({});
          }
        )
    );
  }

  getExistingMissionaName($event) {
    this.unAssignedMission.missionName = $event;
    this.missionName = $event ? $event.missionName : null;
    this.missionId = $event ? $event.missionId : null;
  }

  step1Validation() {
    this.step1Form = this.fb.group({
      missionName: [
        {
          value: null,
          disabled: this.isStepDone.step1Completed
        },
        Validators.compose([
          Validators.required,
          Validators.maxLength(30),
          Validators.pattern('[a-zA-Z0-9_]+.*$')
        ])
      ],
      missionDescription: [
        { value: null, disabled: this.isStepDone.step1Completed },
        Validators.compose([Validators.maxLength(200)])
      ]
    });
  }

  getPosLength(data: any) {
    try {
      const _data = data.pos ? JSON.parse(data.pos) : [];
      if (isArray(_data)) return _data.length;
      else return 0;
    } catch (error) {
      console.log(error);
    }
  }

  onEditChange(changedValue) {
    // this.isQuartierValid = false;
    if (this.missionStartDate && this.missionEndDate !== null) {
      this.isQuartierValid = false;
    } else this.isQuartierValid = true;
  }

  /* Validations */
  step1FormValidation() {
    this.step1Form = this.fb.group({
      missionName: [
        null,
        Validators.compose([
          Validators.required,
          Validators.maxLength(30),
          Validators.pattern('[a-zA-Z0-9_]+.*$')
        ])
      ],
      missionDescription: [
        null,
        Validators.compose([Validators.maxLength(200)])
      ]
    });
  }
  getSubtype($event) {
    this.selectedSubtype = $event;
  }
  /* Validations */
  /* API CALL'S */
  getPosEditMissionPage() {
    this.subscriptions.push(
      this.apiService
        .getPosEditMissionPage({ missionId: this.missionId })
        .subscribe(
          res => {
            this.eventService.broadcast({ eventName: 'hideLoader', data: '' });
            this.mission = res.data.missionDto;
            this.missions.missionSubType=this.mission.missionSubType;
            this.missions.checkpointFlag=this.mission.checkpointFlag;
            this.missions.quartierDto=this.mission.quartierDto;
            this.mission=this.missions;
         
            this.checkpointFlag = res.data.missionDto.checkpointFlag;
            this.assignments = {
              userId: res.data.userId,
              userName: res.data.userName
            };
            this.compaignName=this.mission.missionCampaign.campaignName;
            this.missionDescription=this.mission.missionDescription;
            this.missionName = this.mission.missionName;
            // this.selectedMission = [...res.data.missionDto];
        

            Globals.campaignStartDate =
            res.data.missionDto.missionCampaign.campaignStartDate;
              let startdate:any
              let endDate
              startdate=res.data.missionDto.missionCampaign.campaignStartDate;
              endDate=res.data.missionDto.missionCampaign.campaignEndDate;
              startdate = startdate.split(' ');   
              startdate =startdate[0].split('-');   
          const startdayObj={
          year:startdate[0],
          month:startdate[1],
          day:startdate[2]
          }
          endDate = endDate.split(' ');   
          endDate =endDate[0].split('-');   
          const enddayObj={
          year:endDate[0],
          month:endDate[1],
          day:endDate[2]
          }
          
          localStorage.setItem('campaignStartDate', JSON.stringify(startdayObj));
          localStorage.setItem('campaignEndDate', JSON.stringify(enddayObj));
          
          if (res.data.missionDto.missionStartDate){
            const startdt = res.data.missionDto.missionStartDate.split(' ')[0].split('-');
            const startdtFormat = {
              year: startdt[0],
              month: startdt[1],
              day: startdt[2]
            }
            localStorage.setItem('date', JSON.stringify(startdtFormat));
            this.missionDates = [startdt.join('-')];
          }

            Globals.campaignEndDate =
            res.data.missionDto.missionCampaign.campaignEndDate;
            this.setMinMaxDate();
          },
          err => {
            console.log(err);
          }
        )
    );
  }

  userAvailabilityStatus: string;
  selectedAgents: any = null;
  getAllUnassignedUsersPos(
    reqBody: UnassignedUsersPos,
    userAvailabilityStatus: string = 'true'
  ) {
    this.subscriptions.push(
      this.apiService.getAllUnassignedUsersPos(reqBody).subscribe(
        res => {
          this.optionsAgents = [];
          this.optionsAgents = map(res.users, m =>
            UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` })
          );
          if (this.userAvailabilityStatus == 'true') {
            let user = filter(this.optionsAgents, opa => {
              return opa.userId == this.assignments.userId;
            });
            let isUserExist = {
              fullname: this.assignments.userName,
              userId: this.assignments.userId
            };
            if (isEmpty(user))
              this.optionsAgents = [...this.optionsAgents, isUserExist];
          } else {
            this.selectedAgents = filter(this.optionsAgents, opa => {
              return opa.userId == this.assignments.userId;
            })[0];
            // this.emitAssignmentsEvent();
          }
        },
        err => {
          if (err.status === 400) {
            this.custAlerts.noAgentFound();
          }
        }
      )
    );
  }

  // On the consitional basis this will call editMission or mapQuartier
  editMissionAndMapQuartier() {
    this.eventService.showLoader({});
    if (!isNull(this.mission.quartierDto) && (this.mission.checkpointFlag == "true")) {
      if (this.checkpointFlag == "false") {
        this.mapPosCheckpints();
      } else this.editMission();
    } else {
      this.mapQuartier();
    }
  }

  editMission() {
    // console.log('this.user.userId', this.user.userId);
    if (this.userId == null) {
      this.userId = this.assignments.userId;
    }
    // console.log('userId=====>', this.userId);
    // if (this.userId) {
    //   this.isMissionEditing = true;

this.mission.quartierDto.quartierId=this.mission.quartierDto.name.quartierId?this.mission.quartierDto.name.quartierId:this.mission.quartierDto.quartierId;
this.mission.quartierDto.version=this.mission.quartierDto.name.version?this.mission.quartierDto.name.version:this.mission.quartierDto.version;
this.mission.quartierDto.posCheckpointDto=this.mission.quartierDto.name.posCheckpointDto?this.mission.quartierDto.name.posCheckpointDto:this.mission.quartierDto.posCheckpointDto;
this.mission.quartierDto.name=this.mission.quartierDto.name.name?this.mission.quartierDto.name.name:this.mission.quartierDto.name;
// this.missionDates.push(this.missionStartDate.split(' ')[0]);

this.today=UTILS.getDateFormatWithTime(new Date());
    this.subscriptions.push(
      this.apiService
        .editMission(
          {
            mission: <UpdateMission>{
              ...UTILS.getUpdateMissionBody(),
              ...this.mission,
              missionCampaignId: this.mission.missionCampaign.campaignId,
              missionStatusId: this.mission.missionStatus.statusId,
              subType: this.mission.subType,
              missionUpdatedById: this.userData.userId,
              missionTypeId: missionTypes.POS_POI_TYPE_ID,
              missionStartDate: this.missionStartDate,
              missionEndDate: this.missionStartDate
            },
            posAssignments: <AssignFA2POS>{
              ...UTILS.getAssignmentsInitialization(),
              missionDates: this.missionDates,
              missionId: this.missionId,
              campaignId: this.mission.missionCampaign.campaignId,
              createdBy: this.userData.userId,
              updatedBy: this.userData.userId,
              status: this.mission.missionStatus.statusId,
              userId: this.userId,
              creationDate:this.today,
              lastUpdatedOn: this.mission.missionCreationDate,
              shift: this.isShift == "Morning" ? 1 : 2
            }
          },
          {}
        )
        .subscribe(
          res => {
            if (res.responseCode == '200') {
              this.eventService.hideLoader({});
              // if (_.isEmpty(this.quartierDetails)) {
              this.getMissionUpdatedSuccessAlert();
              // } else this.mapQuartier();
            }
          },
          err => {
            this.eventService.hideLoader({});
            this.custAlerts.somethingWentWrongAlert();
          }
        )
    );

    // } else {
    //   this.isMissionEditing = false;
    // }
  }

  mapQuartier() {
    if (this.quartierId) {
      this.subscriptions.push(
        this.apiService
          .mapQuartier(
            {},
            {
              mission: this.mission.missionId,
              quartier: this.quartierId,
              user: this.user.userId,
              creationDate: UTILS.getDateFormatWithTime(new Date()),
              updatedOn: UTILS.getDateFormatWithTime(new Date())
            }
          )
          .subscribe(
            res => {
              if (res.responseCode == '200') {
                this.mapPOS(); //Mapping pos
              }
            },
            err => {
              this.eventService.hideLoader({});
              this.custAlerts.somethingWentWrongAlert();
            }
          )
      );
    } else {
      this.isQuartierValid = true;
    }
  }
  updateMission(objectParam: UpdateMission) {
    this.subscriptions.push(
      this.apiService
        .updateMission(
          {
            ...objectParam
          },
          {}
        )
        .subscribe(
          res => {
            if (res.responseCode == '200') {
            }
          },
          err => {
            this.custAlerts.somethingWentWrongAlert();
          }
        )
    );
  }
  mapPOS() {
    let mapPOS: Array<MapPOS> = [];
    mapPOS = this.quartierDetails.pos
      ? JSON.parse(this.quartierDetails.pos)
      : [];
    this.updateJSONKeys(mapPOS).then(mapPOSRes => {
      this.subscriptions.push(
        this.apiService
          .mapPOS(
            {},
            {
              missionId: this.mission.missionId,
              posDtos: mapPOSRes,
              quartierName: this.quartierName,
              quartier: this.quartierId
            }
          )
          .subscribe(
            res => {
              if (res.responseCode == '200') {
                this.mapPosCheckpints();
              }
            },
            err => {
              this.eventService.hideLoader({});
              this.custAlerts.somethingWentWrongAlert();
            }
          )
      );
    });
  }
  mapPosCheckpints() {
    // if (!this.quartierName) {
    let checkPoints: Array<MapCheckpoints> = [];
    checkPoints = JSON.parse(this.quartierDetails.checkPoints);
    this.updateJSONKeys(checkPoints).then(mapCheckointsRes => {
      this.subscriptions.push(
        this.apiService
          .mapPosCheckpoints(
            {},
            {
              missionId: this.mission.missionId,
              dtos: mapCheckointsRes
            }
          )
          .subscribe(
            res => {
              if (res.responseCode == '200') {
                this.editMission();
              }
            },
            err => {
              this.eventService.hideLoader({});
              this.custAlerts.somethingWentWrongAlert();
            }
          )
      );
    });
    // }
  }
  /* API CALL'S */

  /* Events */
  getValidationEvents() {
    this.eventService.validationEditPOSEvent.subscribe(status => {
      // console.log(status);
      // this.isAllValid = status;
    });
  }
  getQuartiersData($event) {
    this.subType = $event.subType;
    this.quartierId = $event.quartierId;
    this.quartierName = $event.quartierName;
    this.isQuartierValid = $event.status;
    this.isSubTypeChaged = $event.isSubTypeChaged;
  }
  getAssignmentsEvent($event,mission) {
    // this.isAssignmentsValid = $event.status;
    // console.log('$event.userId', $event.userId);
    this.userId = $event.userId;
    // this.missionDates = $event.missionStartDate.split(' ')[0];
    this.missionDates = $event.missionDates;
    this.missionStartDate = $event.missionStartDate;
    // this.missionEndDate = $event.missionEndDate;
    if ($event.status == true && this.firstAttempt) {
      this.isQuartierValid = false;
    } else this.isQuartierValid = true;
    this.firstAttempt = true;

    if ($event.shift == 1){
      this.isShift = 'Morning';
    } else{
      this.isShift = 'Afternoon';
    }
  }
  getNewQaurtierData($event) {
    this.quartierDetails = $event.quartierDetails;
  }
  /* Events */

  /* Utilities */
  async updateJSONKeys(data: Array<any>) {
    return map(data, (item, index) => {
      return this.getRenamedObject(item);
    });
  }

  getRenamedObject(obj) {
    let newObj = {};
    each(obj, (value, key) => {
      newObj[UTILS.toCamelCase(key.split('_').join(' '))] = value;
    });
    return newObj;
  }

  getMissionUpdatedSuccessAlert() {
    this.custAlerts.missionDeatailsUpdateSuccessAlert().then(() => {
      this.router.navigate(['supervisor/missions']);
    });
  }
  /* Utilities */
  setMinMaxDate() {
    const minDate_ = new Date(UTILS.getDateTimeFormat(UTILS.minDate));
    const campaignStartDate = new Date(Globals.campaignStartDate);
    if (minDate_ < campaignStartDate)
      this.minDate = UTILS.getDatePickerDateFormat(Globals.campaignStartDate);
    else this.minDate = UTILS.minDate;

    this.maxDate = UTILS.getDatePickerDateFormat(Globals.campaignEndDate);
    
  }
 
  onChecked(event,id){
    if(event.target.checked){
         if(id==='classic'){
           this.classic=true;
           this.mission.classic = true;
         } else if(id==='pmr'){
           this.pmr=true;
           this.mission.prm = true;
         } else {
           this.visits=true;
           this.mission.visits = true;
         }
    }
    if(!event.target.checked){
      if(id==='classic'){
        this.classic=false;
      } else if(id==='pmr'){
        this.pmr=false;
        this.mission.prm = false;
      } else {
        this.visits=false;
        this.mission.visits=false;
      }

 }
    
  }
  getAllPosMissions() {
    this.subscriptions.push(
      this.apiService
        .getAllPosMissions({ statusId: statuses.YETTOASSIGN })
        .subscribe(
          res => {
            if (res) {
              this.unAssignedMissions = res.data.missions;
              this.isYetToAssignMissions = res.data.missions.length > 0;
              if (this.unAssignedMissions.length == 1) {
                this.missionId = this.unAssignedMissions[0].missionId;
                // this.missionName = this.unAssignedMissions[0].missionName;
              }
            }
          },
          err => {}
        )
    );
  }
  getAllQuartiers() {
    this.subscriptions.push(
      this.apiService.getAllQuartiers({}).subscribe(
        res => {
          this.optionsQuartier = res.data.quartiers;
        },
        err => {
          console.log(err);
        }
      )
    );
  }
  getOnlyQuartier($event) {
    if ($event) {
      this.coordinates = [];
      this.selectedSubtype = null;
      this.isQuartierReceived = true;
      this.transactionMsg = this.translate.instant(
        'Getting quartier boundary coordinates'
      );
      this.subscriptions.push(
        this.apiService
          .getQuartierCordinates({ quartier: this.quartier.quartierId })
          .subscribe(
            res => {
              this.coordinates = res.data.dtos ? res.data.dtos : [];
              this.transactionMsg = this.translate.instant(
                'Getting quartier details'
              );
              this.getQuartiers(this.quartier.quartierId);
            },
            err => {
              this.isQuartierReceived = false;
              this.transactionMsg = '';
              this.pedsAlerts
                .somethingWentWrong()
                .then(() => {
                  this.quartier = null;
                })
                .catch(() => {});
            }
          )
      );
    }
  }
  quartierDetailsCheckpoints: Array<any> = [];
  quartierDetails2;
  getQuartiers(quartierId) {
    this.subscriptions.push(
      this.apiService.getQuartiers({ quartierId: quartierId }).subscribe(
        res => {
          this._http.get(res.data).subscribe(result => {

          this.isQuartierReceived = false;
          if (result) {
            console.log("res=",result);
            
            this.quartierDetails = result;
            this.quartierDetails2=result;
            const _data = this.quartierDetails.checkPoints
              ? JSON.parse(this.quartierDetails.checkPoints)
              : [];
            this.quartierDetailsCheckpoints = _data;
            this.quartierDetails = {
              ...this.quartierDetails
            };
          } else this.quartierDetails = {};
          this.transactionMsg = '';
          this.setSubTypeOptions(this.quartierDetails);
        },
          err => {
            this.isQuartierReceived = false;
            this.transactionMsg = '';
            this.quartier = null;
            this.pedsAlerts.somethingWentWrong();
          })
      },
      err => {
        this.isQuartierReceived = false;
        this.transactionMsg = '';
        this.quartier = null;
        this.pedsAlerts.somethingWentWrong();
      }));
  }
  setSubTypeOptions(quartierDetails) {
    if (this.getCheckpointsLength(quartierDetails) > 0) {
      this.optionsSubtype = [];
      this.optionsSubtype = this.getTranslation(Globals.MISSION_SUBTYPES_BOTH);
    } else {
      this.optionsSubtype = [];
      this.optionsSubtype = this.getTranslation(
        Globals.MISSION_SUBTYPES_STOERS
      );
      this.selectedSubtype = this.getTranslation(
        Globals.MISSION_SUBTYPES_STOERS
      )[0];
    }
  }
  getTranslation(obj: Array<any> = []) {
    let newObj = [];
    each(obj, (o, i) => {
      newObj.push({ ...o, name: this.translate.instant(o.name.toString()) });
    });
    return newObj;
  }

  getCheckpointsLength(data: any) {
    try {
      const _data = data.checkPoints ? JSON.parse(data.checkPoints) : [];
      if (isArray(_data)) return filter(_data, d => d.checkpoint == 1).length;
      else return 0;
    } catch (error) {
      console.log(error);
    }
  }

  isDisableSubmit(){
    if (this.mission.missionName && this.mission.missionDescription && this.missionDates && this.userId && this.isShift){
      return false;
    } else{
      return true;
    }
  }
}
