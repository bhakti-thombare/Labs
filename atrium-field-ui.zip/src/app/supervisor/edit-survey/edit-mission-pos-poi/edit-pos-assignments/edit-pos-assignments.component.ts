// core
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  AfterViewInit,
  OnChanges,
  OnDestroy
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

// 3rd party
import { filter, map, findWhere, isUndefined, keys, isEmpty } from 'underscore';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { Subscription } from 'rxjs/Subscription';

// app
import { POSUserAvailability } from '@services/apiServices/reqBodies';
import { Globals, missionTypes } from '@app/constants/constants';
import { UTILS } from '@services/global-utility.service';
import { ApiService } from '@services/apiServices/api.service';
import { UnassignedUsersPos } from '@services/apiServices/reqBodies';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { CustomerSurveyAlertsService } from '@app/services/Alerts/customer-survey-alerts.service';
import { EventService } from '@app/services/events/event.service';
import { HttpService } from '@app/services/http-service';
import { CreateSurveyUtilsService } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.service';

@Component({
  selector: 'app-edit-pos-assignments',
  templateUrl: './edit-pos-assignments.component.html',
  styleUrls: ['./edit-pos-assignments.component.css']
})
export class EditPosAssignmentsComponent
  implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  private utilityFunctions = new UtilityFunctions();
  private subscriptions: Subscription[] = [];
  optionsAgents: any = [];
  selectedAgents: any = null;
  step3Form: FormGroup;
  missionName;
  days: number = 0;
  missionDates;
  missionId;
  today: Date = new Date();
  minDate: any = {};
  maxDate: any = {};
  configAgents: any = {};
  isSubTypeChagedLocal: boolean = false;
  @Input() mission: any = {};
  @Input() isSubTypeChaged: boolean = false;
  @Input() assignments: any = {};
  @Output() assignmentsEvent: EventEmitter<any> = new EventEmitter<any>();

  isShift;

  constructor(
    public fb: FormBuilder,
    public apiService: ApiService,
    public custAlerts: CustomerSurveyAlertsService,
    public translate: TranslateService,
    public eventService: EventService,
    public http: HttpService,
    public custUtils: CreateSurveyUtilsService,
  ) {}

  ngOnInit() {
    // this.getAllMissions(this.mission.missionId);
    this.selectedAgents = this.assignments.userName;
    this.missionName = this.mission.missionName;
    this.minDate = UTILS.minDate;
    this.configAgents = {
      displayKey: 'fullname',
      search: true,
      placeholder: this.selectedAgents
        ? this.translate.instant(this.selectedAgents)
        : this.translate.instant('Select agent'),
      //placeholder: this.translate.instant(this.selectedAgents),
      multiple: false
    };

    this.step3Validation();
    this.setMissionDates();
    this.getUsedMissionDates(this.today);
    this.setMinMaxDate();

    if (this.mission.shift == null) {
      this.isShift = 'Morning';
    } else {
      if (this.mission.shift.shiftName == 'PM') {
        this.isShift = 'Afternoon';
      } else {
        this.isShift = 'Morning';
      }
    }
    if (this.mission.agent == null){
      this.optionsAgents = [];
    } else{
      let agent = [this.mission.agent];
      this.optionsAgents = map(agent, m =>
        UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` })
      );
    }
    if (this.mission.missionStartDate){
      // let date = new Date(this.mission.missionStartDate.split(' ')[0]);
      // this.step3Form.get('startDate').patchValue(date);
      this.step3Form.controls['startDate'].setValue(
        UTILS.getDatePickerDateFormat(this.mission.missionStartDate)
      );
    }
  }
  ngAfterViewInit() {
    let search = this.translate.instant('Search');
    $('.ngx-dorpdown-container').on('click', function() {
      $('.search-container > label').html(
        '<span _ngcontent-c8="" class="nsdicon-search"></span> ' + search
      );
    });
    $('.ngx-dorpdown-container > .ngx-dropdown-button').on('click', () => {
      $('.ngx-dorpdown-container > .ngx-dropdown-list-container').css(
        'position',
        'relative'
      );
    });
  }
  // getAllMissions(missionId: number) {
  //   this.http.SecureGet('/ref/getAllMissions?id=' + missionId)
  //   .subscribe(res => {
  //     this.eventService.broadcast({ eventName: 'hideLoader', data: '' });
  //     let missions = res.data.missions[0];
     
  //   }, err => { });
    
  // }

  ngOnChanges($event) {
    let changedVariables = keys($event);
    if (changedVariables.includes('isSubTypeChaged')) {
      if (this.isSubTypeChaged) {
        this.isSubTypeChagedLocal = this.isSubTypeChaged;
        this.resetForm();
      }
    }
  }
  /* Validation */
  step3Validation() {
    this.step3Form = this.fb.group({
      missionName: [null, Validators.compose([Validators.required])],
      startDate: [null, Validators.compose([Validators.required])],
      endDate: [null, Validators.compose([Validators.required])],
      fieldAgent: [null]
    });
  }
  emitAssignmentsEvent() {
    let status = null,
      userId = null;
    let missionStartDate;
    let missionEndDate;
    let shift = 1;
    //console.log('selectedAgents', this.selectedAgents);
    this.isShift == 'Morning' ? shift = 1 : shift = 2; 

    if (!isEmpty(this.selectedAgents)) {
      status = true;
    } else {
      status = false;
    }
    if (!isEmpty(this.selectedAgents)) {
      userId = this.selectedAgents.userId;
    } else {
      userId = null;
    }
    if (this.step3Form.value.startDate)
      missionStartDate = UTILS.getDateTimeFormat(
        this.step3Form.value.startDate
      );
    if (this.step3Form.value.endDate)
      missionEndDate = UTILS.getDateTimeFormat(this.step3Form.value.endDate);

    //let missionDates = this.missionDates ? this.missionDates : null;
    let missionDates = missionStartDate != undefined ? [missionStartDate.split(' ')[0]] : null;
    this.assignmentsEvent.emit({
      status,
      userId,
      missionDates,
      missionStartDate,
      missionEndDate,
      shift
    });
  }
  /* Validation */
  /* Datepicker related methods */
  isDisabled(date: NgbDate, current: { month: number }) {
    const isDateFind = findWhere(
      Globals.BUSY_DATES,
      UTILS.getDatePickerIntFormat(date)
    );
    const currentDate = new Date(UTILS.getDateFormat(date));
    const day = currentDate.getDay();
    const isWeekend = day != 0 && day != 6;
    if (!isWeekend || !isUndefined(isDateFind)) return true;
    else return false;
  }

  /* Datepicker related methods */
  /* Events */
  userAvailabilityStatus: string;
  // getEndDate(date: NgbDate, currentMonth) {
  //   const _date = new Date(UTILS.getDateFormat(date));
  //   const campaignStartDate = new Date(Globals.campaignStartDate);
  //   const campaignEndDate = new Date(Globals.campaignEndDate);
  //   const current = { month: currentMonth };
  //   if (
  //     campaignStartDate <= _date &&
  //     campaignEndDate >= _date &&
  //     !this.isDisabled(date, current)
  //   ) {
  //     this.step3Form.controls['missionName'].setValue(this.missionName);
  //     let startDate = UTILS.getDateFormat(
  //       this.step3Form.controls['startDate'].value
  //     );
  //     const endDate = new Date(UTILS.getDateFormat(date));
  //     if (new Date(startDate) <= endDate) {
  //       UTILS.getDatesArrayByDates(new Date(startDate), endDate).then(data => {
  //         this.days = data.length;
  //         this.missionDates = data.dateArray;
  //       });
  //       if (this.assignments.userId) {
  //         this.subscriptions.push(
  //           this.checkPosUserAvailability({
  //             userId: this.assignments.userId,
  //             missionId: this.mission.missionId,
  //             startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
  //             endDate: UTILS.getDateFormatWithTime(endDate)
  //           }).subscribe(res => {
  //             this.userAvailabilityStatus = res;
  //             this.getAllUnassignedUsersPos({
  //               startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
  //               endDate: UTILS.getDateFormatWithTime(endDate),
  //               iterations: null,
  //               shift: null,
  //               missionId: this.mission.missionId
  //             });
  //           })
  //         );
  //       } else {
  //         this.getAllUnassignedUsersPos({
  //           startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
  //           endDate: UTILS.getDateFormatWithTime(endDate),
  //           iterations: null,
  //           shift: null,
  //           missionId: this.mission.missionId
  //         });
  //       }
  //     }
  //   }
  // }

  setMissionDates() {
    if (this.assignments.userId && this.mission.missionStartDate) {
      // debugger
      this.step3Form.controls['startDate'].setValue(
        UTILS.getDatePickerDateFormat(this.mission.missionStartDate)
      );
      this.step3Form.controls['endDate'].setValue(
        UTILS.getDatePickerDateFormat(this.mission.missionEndDate)
      );
      const startDate = new Date(this.mission.missionStartDate);
      const endDate = new Date(this.mission.missionEndDate);
      // Issue 981 Fixed
      // UTILS.getDatesArrayByDates(startDate, endDate).then(data => {
      UTILS.getDatesArrayByDates(new Date(startDate), endDate).then(data => {
        this.days = data.length;
        this.missionDates = data.dateArray;
      });

      // this.getAllUnassignedUsersPos({
      //   startDate: UTILS.getDateFormatWithTime(startDate),
      //   endDate: UTILS.getDateFormatWithTime(endDate),
      //   iterations: null,
      //   shift: null,
      //   missionId: this.mission.missionId
      // });
    } else {
      this.emitAssignmentsEvent();
      // this.step3Form.controls['startDate'].setValue(null);
      // this.step3Form.controls['endDate'].setValue(null);
    }
  }

  resetSelectedAgents() {
    this.selectedAgents = [];
  }
  //Reset end date
  resetEnddate(date, currentMonth) {
    this.days = 0;
    this.step3Form.controls['endDate'].setValue(null);
  }
  getFieldAgent($event) {
    this.emitAssignmentsEvent();
  }
  resetForm() {
    let status = false;
    //this.assignmentsEvent.emit({ status });
    this.days = 0;
    //this.selectedAgents = null;
    //this.optionsAgents = [];
    //this.step3Form.controls['endDate'].setValue({});
    if (this.isSubTypeChagedLocal) {
      this.isSubTypeChagedLocal = false;
      //this.step3Form.controls['startDate'].setValue(null);
    }
  }
  /* Events */

  /* API Calls */
  getAllUnassignedUsersPos(
    reqBody: UnassignedUsersPos,
    status,
    userAvailabilityStatus: string = 'true'
  ) {
    this.subscriptions.push(
      this.apiService.getAllUnassignedUsersPos(reqBody).subscribe(
        res => {
          this.optionsAgents = [];
          this.optionsAgents = map(res.users, m =>
            UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` })
          );
          if(status){
            if (this.mission.agent != null){
              let agent = this.optionsAgents.filter(res => res.userId == this.mission.agent.userId);
              if(agent.length ==0 ){
                this.optionsAgents.splice(0, 0, this.mission.agent);
              }
            }
          }
          this.selectedAgents = this.optionsAgents[0];
          this.emitAssignmentsEvent();

          // this.optionsAgents = [];
          // this.optionsAgents = map(res.users, m =>
          //   UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` })
          // );
          // if (this.userAvailabilityStatus == 'true') {
          //   let user = filter(this.optionsAgents, opa => {
          //     return opa.userId == this.assignments.userId;
          //   });
          //   let isUserExist = {
          //     fullname: this.assignments.userName,
          //     userId: this.assignments.userId
          //   };
          //   if (isEmpty(user))
          //     this.optionsAgents = [...this.optionsAgents, isUserExist];
          // } else {
          //   this.selectedAgents = filter(this.optionsAgents, opa => {
          //     return opa.userId == this.assignments.userId;
          //   })[0];
          //   this.emitAssignmentsEvent();
          // }
        },
        err => {
          if(status){
            const shiftId = this.isShift == "Morning" ? 1 : 2;
            if (this.mission.shift.shiftId == shiftId){
              this.optionsAgents = [this.mission.agent]
              this.selectedAgents = this.optionsAgents[0];
            } else{
              this.custUtils.translateMessageObject({
                title: this.translate.instant('No Field agents available'),
                text: this.translate.instant('Please change the mission date or  ask admin to add more field agents.'),
                type: 'warning',
                cancelBtnText: '',
                confirmBtnText: 'OK',
                outsideClick: false,
                showCancelBtn: false
              }, message => {
                this.custUtils.translateAndPop(message).then(() => {
                  this.optionsAgents = [];
                  this.selectedAgents = {};
                }).catch(() => {
                  this.optionsAgents = [];
                  this.selectedAgents = {};
                });
              });
            }
          } else{
            this.custUtils.translateMessageObject({
              title: this.translate.instant('No Field agents available'),
              text: this.translate.instant('Please change the mission date or  ask admin to add more field agents.'),
              type: 'warning',
              cancelBtnText: '',
              confirmBtnText: 'OK',
              outsideClick: false,
              showCancelBtn: false
            }, message => {
              this.custUtils.translateAndPop(message).then(() => {
                this.optionsAgents = [];
                this.selectedAgents = {};
              }).catch(() => {
                this.optionsAgents = [];
                this.selectedAgents = {};
              });
            });
          }
          this.emitAssignmentsEvent();

          // if (err.status === 400) {
          //   this.custAlerts.noAgentFound();
          // }
        }
      )
    );
  }
  /* Datepicker related API's */
  getUsedMissionDates(date) {
    let currentDate = UTILS.getDatePickerDateFormat(date);
    this.subscriptions.push(
      this.apiService
        .getUsedMissionDates(
          UTILS.getDateFormatWithoutZero(currentDate),
          missionTypes.POS_POI_TYPE_ID
        )
        .subscribe(
          res => {
            Globals.BUSY_DATES = res.dateDto;
          },
          err => (Globals.BUSY_DATES = [])
        )
    );
  }
  /* Datepicker related API's */

  checkPosUserAvailability(req: POSUserAvailability) {
    return this.apiService
      .checkPosUserAvailability(req)
      .map(res => res.responseMessage);
  }
  /* API Calls */

  /* Utilities */
  setMinMaxDate() {
    Globals.campaignStartDate = this.mission.missionCampaign.campaignStartDate;
    Globals.campaignEndDate = this.mission.missionCampaign.campaignEndDate;
    const minDate_ = new Date(UTILS.getDateTimeFormat(UTILS.minDate));
    const campaignStartDate = new Date(Globals.campaignStartDate);
    if (minDate_ < campaignStartDate)
      this.minDate = UTILS.getDatePickerDateFormat(Globals.campaignStartDate);
    else this.minDate = UTILS.minDate;
    this.maxDate = UTILS.getDatePickerDateFormat(Globals.campaignEndDate);
  }
  d1Close(d1) {
    if (!isUndefined(d1)) d1.close();
  }
  d2Close(d2) {
    d2.close();
  }

  EndDate(d1) {
    if(localStorage.getItem('date') !== null){
      let dateE = JSON.parse(localStorage.getItem('date'));
      let datePickerDateSelected = new Date(UTILS.getDateFormat(d1));
      let existingDate = new Date(UTILS.getDateFormat(dateE));
      if (datePickerDateSelected.getTime() == existingDate.getTime()) {
        this.getAllUnassignedUsersPos({
          startDate: d1.year + '-' + d1.month + '-' + d1.day, //UTILS.getDateFormatWithTime(startDate),
          endDate: d1.year + '-' + d1.month + '-' + d1.day, //UTILS.getDateFormatWithTime(endDate),
          iterations: 9,
          shift: this.isShift == 'Morning' ? 1 : 2,
          missionId: this.mission.missionId,
        }, true
        );
        //this.getUnassignedUsers(this.mission.missionId, true, d1)
      } else {
        this.getAllUnassignedUsersPos({
          startDate: d1.year + '-' + d1.month + '-' + d1.day, //UTILS.getDateFormatWithTime(startDate),
          endDate: d1.year + '-' + d1.month + '-' + d1.day, //UTILS.getDateFormatWithTime(endDate),
          iterations: 9,
          shift: this.isShift == 'Morning' ? 1 : 2,
          missionId: this.mission.missionId,
        }, false);
        //this.getUnassignedUsers(this.mission.missionId, false, d1)
      }
    }
    else{
      this.getAllUnassignedUsersPos({
        startDate: d1.year + '-' + d1.month + '-' + d1.day, //UTILS.getDateFormatWithTime(startDate),
        endDate: d1.year + '-' + d1.month + '-' + d1.day, //UTILS.getDateFormatWithTime(endDate),
        iterations: 9,
        shift: this.isShift == 'Morning' ? 1 : 2,
        missionId: this.mission.missionId,
      }, false);
    }
    

   
  }

  changeShiftId(id) {
    let d1 = this.step3Form.get('startDate').value;
    if (id == 1) {
      this.isShift = 'Morning';
    } else {
      this.isShift = 'Afternoon';
    }

    let dateE = JSON.parse(localStorage.getItem('date'));
    let datePickerDateSelected = new Date(UTILS.getDateFormat(d1));
    let existingDate = new Date(UTILS.getDateFormat(dateE));
    if (datePickerDateSelected.getTime() == existingDate.getTime()) {
      this.getAllUnassignedUsersPos({
        startDate: d1.year + '-' + d1.month + '-' + d1.day, //UTILS.getDateFormatWithTime(startDate),
        endDate: d1.year + '-' + d1.month + '-' + d1.day, //UTILS.getDateFormatWithTime(endDate),
        iterations: 9,
        shift: this.isShift == 'Morning' ? 1 : 2,
        missionId: this.mission.missionId
      }, true);
    
    } else {
      this.getAllUnassignedUsersPos({
        startDate: d1.year + '-' + d1.month + '-' + d1.day, //UTILS.getDateFormatWithTime(startDate),
        endDate: d1.year + '-' + d1.month + '-' + d1.day, //UTILS.getDateFormatWithTime(endDate),
        iterations: 9,
        shift: this.isShift == 'Morning' ? 1 : 2,
        missionId: this.mission.missionId
      }, false);
    }
  }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }
}
