import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPosAssignmentsComponent } from './edit-pos-assignments.component';

describe('EditPosAssignmentsComponent', () => {
  let component: EditPosAssignmentsComponent;
  let fixture: ComponentFixture<EditPosAssignmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditPosAssignmentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPosAssignmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
