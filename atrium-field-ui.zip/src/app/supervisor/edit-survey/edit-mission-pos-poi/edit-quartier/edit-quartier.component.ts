// core imports
import {
  Component,
  OnInit,
  Input,
  AfterViewInit,
  Output,
  EventEmitter
} from '@angular/core';

// 3rd party
import { each, map, isArray, filter, isNull, isEmpty } from 'underscore';
import { Subscription } from 'rxjs/Subscription';
import { TranslateService } from '@ngx-translate/core';

// app imports
import { Globals } from '@app/constants/constants';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { ApiService } from '@app/services/apiServices/api.service';
import { PedestrainAlertsService } from '@app/services/Alerts/pedestrainAlerts/pedestrain-alerts.service';
import { EventService } from '@app/services/events/event.service';
import { UTILS } from '@app/services/global-utility.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-edit-quartier',
  templateUrl: './edit-quartier.component.html',
  styleUrls: ['./edit-quartier.component.css']
})
export class EditQuartierComponent implements OnInit, AfterViewInit {
  private utilityFunctions = new UtilityFunctions();
  private subscriptions: Subscription[] = [];
  @Input() mission: any = {};
  @Input() isReassigned: boolean;
  @Input() subType: string;
  @Input() quartierName: string;
  @Input() getQuartierDTO: any;
  @Input() numberOfPOS: number = 0;
  @Input() numberOfCheckpoints: number = 0;
  @Input() quartierDetails: any = {};
  @Input() coordinates: Array<any> = [];
  @Output() getQuartiersData: EventEmitter<any> = new EventEmitter<any>();
  @Output() getNewQaurtierData: EventEmitter<any> = new EventEmitter<any>();
  configQuartier: any = {};
  optionsQuartier: any = [];
  configSubtype: any = {};
  configSubtypeBoth: any = {};
  optionsSubtype: any = [];
  optionsSubtypeBoth: any = [];
  selectedQuartier: any = null;
  selectedSubtype: any = null;
  isQuartierReceived: boolean = false;
  disableDropdown: boolean = false;
  user: any = JSON.parse(localStorage.getItem('user-data'));
  missionName:any;
  quartier: any = null;
  obj={
    'name': this.translate.instant('Select quartier'),
    'posCheckpointDto':[],
    'quartierId':0,
    'version':0,
  };
 
  constructor(
    public apiService: ApiService,
    public pedsAlerts: PedestrainAlertsService,
    public translate: TranslateService,
    public eventService: EventService,
    public _http: HttpClient,
  ) {}

  ngOnInit() {
    // this.optionsSubtypeBoth = this.getTranslation([{ name: 'Stores only', id: 5 }, { name: 'Stores & Checkpoints', id: 6 }]);
    // this.optionsSubtype = this.getTranslation([{ name: 'Stores only', id: 5 }]);
    this.getOnlyQuartier({}, 1);
    this.configQuartier = {
      displayKey: 'name',
      search: true,
      placeholder: this.translate.instant('Select quartier'),
      multiple: false,
      limitTo: 10
    };
    this.configSubtype = {
      displayKey: 'name',
      search: false,
      placeholder: this.translate.instant('Select Subtype'),
      multiple: false,
      notFoundText: this.translate.instant('No items found')
    };
    this.configSubtypeBoth = {
      displayKey: 'name',
      search: false,
      placeholder: this.translate.instant('Select Subtype'),
      multiple: false
    };
    // if (!this.mission.quartierDto) 
       this.getAllQuartiers();
    if (this.mission.quartierDto) {
      if (!isNull(this.mission.subType)) {
        this.selectedSubtype = {
          name: this.mission.subType==5?this.translate.instant('Points of sale only'):this.translate.instant('Points of sale & Checkpoints'),
          id: this.mission.subType
        };
      }
      this.getQuartiersData.emit({
        subType: this.mission.missionSubType.id,
        status: true,
        quartierId: this.mission.quartierDto.quartierId
      });
    } else {
      this.getQuartiersData.emit({
        subType: null,
        status: false,
        quartierId: null
      });
    }

    this.missionName = this.mission.missionName;

    if(this.mission.quartierDto == null && this.getQuartierDTO == null){
      this.disableDropdown = false;
    }else{
      this.disableDropdown = true;
    }
  }
  ngAfterViewInit() {
    //this.borderTheSelectDropdown();
  }
  /* Dynamic css */
  borderTheSelectDropdown() {
    $('.ngx-dorpdown-container').css('border', '1px solid lightgray');
    $('.ngx-dropdown-button').css('border-bottom', 'none !important');
  }
  /* Dynamic css */

  /* API Calls */
  getAllQuartiers() {
    this.subscriptions.push(
      this.apiService.getAllQuartiers({}).subscribe(
        res => {
          this.optionsQuartier = res.data.quartiers;
          if (this.mission.quartierDto == null){
            this.mission.quartierDto = this.obj;
            // this.getOnlyQuartier1(this.mission.quartierDto); 
          }
        },
        err => {
          console.log(err);
        }
      )
    );
  }
  /* API Calls */

  /* Events */
  getPosLength(data: any) {
    try {
      const _data = data.pos ? JSON.parse(data.pos) : [];
      if (isArray(_data)){
        this.mission.numberOfPos = _data.length;
        return _data.length;
      }  else{
        this.mission.numberOfPos = 0;
        return 0;
      } 
    } catch (error) {
      console.log(error);
    }
  }

  getCheckpointsLength(data: any) {
    const _data = data.checkPoints ? JSON.parse(data.checkPoints) : [];
    if (isArray(_data)){
      let countCheckpoints = filter(_data, d => d.checkpoint == 1).length;
      this.mission.numberOfPosCheckpoints = countCheckpoints;
      return countCheckpoints;
    } else{
      this.mission.numberOfPosCheckpoints = 0;
      return 0;
    }
  }
  checkPointsLength: number = 0;
  setSubTypeOptions(quartierDetails) {
    this.checkPointsLength = this.getCheckpointsLength(quartierDetails);
    if (this.getCheckpointsLength(quartierDetails) > 0) {
      this.optionsSubtype = this.getTranslation([
        { name: 'Points of sale only', id: 5 },
        { name: 'Points of sale & Checkpoints', id: 6 }
      ]);
    }
    if (this.checkPointsLength == 0) {
      this.selectedSubtype = this.getTranslation([
        { name: 'Points of sale only', id: 5 }
      ])[0];
      this.optionsSubtype = this.getTranslation([
        { name: 'Points of sale only', id: 5 }
      ]);
    }
    //emits event to parent view
    let subType;
    if (this.selectedSubtype) {
      subType = this.selectedSubtype.id;
    }
    let status;
    if (this.mission.quartierDto) status = true;
    else if (this.quartierId && this.selectedSubtype) status = true;
    else status = false;
    this.getQuartiersData.emit({
      subType,
      status,
      quartierId: this.quartierId
    });
    this.borderTheSelectDropdown();
  }

  transactionMsg;
  quartierId;
  getOnlyQuartier($event, from) {
    this.selectedSubtype = null;
    this.optionsSubtype = [];
    if (this.mission.quartierDto || !isEmpty(this.selectedQuartier)) {
      this.quartierId = this.mission.quartierDto
        ? this.mission.quartierDto.quartierId
        : this.selectedQuartier.quartierId;
      this.transactionMsg = 'Getting quartier boundary coordinates';
      this.subscriptions.push(
        this.apiService
          .getQuartierCordinates({ quartier: this.quartierId })
          .subscribe(
            res => {
              this.coordinates = res.data.dtos ? res.data.dtos : [];
              this.transactionMsg = 'Getting quartier details';
              this.getQuartiers(this.quartierId, from);
            },
            err => {
              this.isQuartierReceived = false;
              this.transactionMsg = '';
              this.pedsAlerts.somethingWentWrong();
            }
          )
      );
    }
  }

  getOnlyQuartier1($event) {
    if ($event) {
      this.coordinates = [];
      this.selectedSubtype = null;
      this.isQuartierReceived = true;
      this.transactionMsg = this.translate.instant(
        'Getting quartier boundary coordinates'
      );
      this.mission.quartierDto=$event;
      this.subscriptions.push(
        this.apiService
          .getQuartierCordinates({ quartier: $event.quartierId })
          .subscribe(
            res => {
              this.coordinates = res.data.dtos ? res.data.dtos : [];
              this.transactionMsg = this.translate.instant(
                'Getting quartier details'
              );
              this.getQuartiers1($event.quartierId);
            },
            err => {
              this.isQuartierReceived = false;
              this.transactionMsg = '';
              this.pedsAlerts
                .somethingWentWrong()
                .then(() => {
                  this.quartier = null;
                })
                .catch(() => {});
            }
          )
      );
    }
  }

  quartierDetailsCheckpoints: Array<any> = [];
  quartierDetails2;
  getQuartiers1(quartierId) {
    // this.quartierDetails = {};
    this.subscriptions.push(
      this.apiService.getQuartiers({ quartierId: quartierId }).subscribe(
        res => {
          this._http.get(res.data).subscribe(result => {
          if (result) {
            console.log("res=",result);
            
            this.quartierDetails = result;
            this.quartierDetails2=result;
            const _data = this.quartierDetails.checkPoints
              ? JSON.parse(this.quartierDetails.checkPoints)
              : [];
            this.quartierDetailsCheckpoints = _data;
            this.quartierDetails = {
              ...this.quartierDetails
            };
            this.isQuartierReceived = false;
          } else this.quartierDetails = {};
          this.transactionMsg = '';
          this.setSubTypeOptions(this.quartierDetails);
        },
        err => {
          this.isQuartierReceived = false;
          this.transactionMsg = '';
          this.quartier = null;
          this.pedsAlerts.somethingWentWrong();
        })
    },
    err => {
      this.isQuartierReceived = false;
      this.transactionMsg = '';
      this.quartier = null;
      this.pedsAlerts.somethingWentWrong();
    }));
  }


  getQuartiers(quartierId, from) {
    this.subscriptions.push(
      this.apiService.getQuartiers({ quartierId: quartierId }).subscribe(
        res => {
          this._http.get(res.data).subscribe(result => {
          this.isQuartierReceived = true;
          if (result) {
            this.quartierDetails = result;
            const _data = this.quartierDetails.checkPoints
              ? JSON.parse(this.quartierDetails.checkPoints)
              : [];
            this.quartierDetails = {
              ...this.quartierDetails
            };
          }
          if (res.errorMessage) {
            this.quartierDetails = { checkPoints: [], pos: '[]' };
          }
          if (from == 2)
            this.getNewQaurtierData.emit({
              quartierDetails: this.quartierDetails
            });
            this.isQuartierReceived = false;
          this.transactionMsg = '';
          this.setSubTypeOptions(this.quartierDetails);
        },
        err => {
          this.isQuartierReceived = false;
          this.transactionMsg = '';
          this.quartier = null;
          this.pedsAlerts.somethingWentWrong();
        })
    },
    err => {
      this.isQuartierReceived = false;
      this.transactionMsg = '';
      this.quartier = null;
      this.pedsAlerts.somethingWentWrong();
    }));
  }

  emitValidationEvent(status: boolean = false) {
    this.eventService.validationEditPOSEvent.emit(status);
  }
  getSubtype($event) {
    if (!isEmpty($event)) {
      this.mission.subType = $event.id;
      // if (
      //   this.mission.checkpointFlag == 'false' &&
      //   this.selectedSubtype.id == 6
      // )
      if (this.mission.checkpointFlag == 'false'){
        this.getNewQaurtierData.emit({ quartierDetails: this.quartierDetails });
      }
    }
    this.emitEvent();
  }

  emitEvent() {
    let status;
    if (this.mission.quartierDto) status = true;
    else if (this.quartierId && !isEmpty(this.selectedSubtype)) status = true;
    else status = false;
    this.getQuartiersData.emit({
      subType: !isEmpty(this.selectedSubtype) ? this.selectedSubtype.id : null,
      status: status,
      quartierId: this.mission.quartierDto
        ? this.mission.quartierDto.quartierId
        : this.selectedQuartier.quartierId,
      quartierName: this.mission.quartierDto
        ? this.mission.quartierDto.name
        : this.selectedQuartier.name,
      isSubTypeChaged: Math.random()
    });
  }
  /* Events */

  /* Utility */
  async updateJSONKeys(data: Array<any>) {
    return map(data, (item, index) => {
      return this.getRenamedObject(item);
    });
  }

  getRenamedObject(obj) {
    let newObj = {};
    each(obj, (value, key) => {
      newObj[UTILS.toCamelCase(key.split('_').join(' '))] = value;
    });
    return newObj;
  }

  getTranslation(obj: Array<any> = []) {
    let newObj = [];
    each(obj, (o, i) => {
      newObj.push({ ...o, name: this.translate.instant(o.name.toString()) });
    });
    return newObj;
  }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }
}
