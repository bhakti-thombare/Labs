import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditMissionStandsComponent } from './edit-mission-stands.component';

describe('EditMissionStandsComponent', () => {
  let component: EditMissionStandsComponent;
  let fixture: ComponentFixture<EditMissionStandsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditMissionStandsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditMissionStandsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
