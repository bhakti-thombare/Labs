import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { Globals, ApiConstants, missionTypes, statuses } from '@app/constants/constants';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '@app/services/apiServices/api.service';
import { CampaignSummaryService } from '@app/services/campaign-summary/campaign-summary.service';
import { EventService } from '@app/services/events/event.service';
import { GlobalUtility } from '@app/services/global-utility.service';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { CreateSurveyUtilsService } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.service';
import { NgbDateStruct, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import {
  each,
  map,
  isArray,
  filter,
  isEmpty,
  defaults,
  findWhere,
  isUndefined
} from 'underscore';
import { UTILS } from '@app/services/global-utility.service';
import { HttpService } from '@app/services/http-service';
import { CustomerSurveyAlertsService } from '@app/services/Alerts/customer-survey-alerts.service';
import { isNull } from 'util';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { PedestrainAlertsService } from '@app/services/Alerts/pedestrainAlerts/pedestrain-alerts.service';
declare var google: any;

@Component({
  selector: 'app-edit-mission-stands',
  templateUrl: './edit-mission-stands.component.html',
  styleUrls: ['./edit-mission-stands.component.css']
})
export class EditMissionStandsComponent implements OnInit {
  private utilityFunctions = new UtilityFunctions();
  private subscriptions: Subscription[] = [];
  @ViewChild('zonesDropdown') zonesDropdown: ElementRef;
  xmlHttpUrl = ApiConstants.BASE_URL;
  mapObject: any = []

  today = new Date(Date.now());
  currentDate = new Date(Date.now());
  minDate = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };

  minEndDate = {
    day: null,
    month: null,
    year: null
  };
  campaignEndDate: any;
  campaignFlag: boolean=false;
  enddayObj: { year: any; month: any; day: any; };
  dateSelected: boolean=false;
  startdayObj: { year: any; month: any; day: any; };
  startDate;
  model: NgbDateStruct;

  agentSelected=false;
  createMissionForm: FormGroup = new FormGroup({
    missionStartDate: new FormControl('', Validators.required),
    missionEndDate: new FormControl('', Validators.required),
    estimatedTimeHourHour: new FormControl('', Validators.required),
    estimatedTimeHourMin: new FormControl('', Validators.required),
    missionName: new FormControl('', Validators.required),
    missionDescription: new FormControl('')
  });

  missionId: any;
  mission = {
    selectedCampaign: {
      campaignEndDate: '',
      campaignStartDate: '',
      startDateObj: {},
      endDateObj: {}
    },
    markets: [],
    markets1: [],
    selectedMarket: [],
    assignments: [],
    missionStartDate: {
      year: null,
      month: null,
      day: null
    },
    missionEndDate: {
      year: null,
      month: null,
      day: null
    },
    missionEndDate1: '',
    missionStartDate1: '',
    estimatedTimeHour: null,
    estimatedTimeMinutes: null,
    missionName: '',
    missionDescription: ''
  };
  morning = false;

  user = JSON.parse(localStorage.getItem('user-data'));
  showSkipInStep1: boolean;
  step1: boolean;
  step2: boolean;
  loaderOn: boolean;
  step3: boolean;
  step4: boolean;
  step1Completed = false;
  step2Completed: boolean;
  step3Completed: boolean;
  step4Completed: boolean;
  hideStep1 = false;
  hideStep2 = true;
  hideStep3 = true;
  hideStep4 = true;
  hideStep5 = true;
  marketOpen = [];
  pageOpenAllowed: boolean;
  campaignsLoaded: boolean;
  assignmentsLoaded = false;
  existingZonesCheck = false;
  missionsLoaded = false;
  summaryLoaded = false;
  missionTypesLoaded: boolean;
  calendarReady = false;
  selectedMissionType: any;
  missionTypes: any;
  showNewAssignmentBtn = true;
  existingMarketsFound = false;
  existingZones = [];
  disableStep1 = false;
  disableStep2 = false;
  disableStep3 = false;
  disableStep4 = false;
  zoneMissionFound = false;
  loadMapForExistingCircuit = false;
  disableMapClick = false;
  datepickers = [];
  fieldAgents = [];
  marketMissionLoaded = false;
  parent2Toggle;
  busyDates = [];
  summaryObj;
  shifts = [
    {
      shiftName: 'Morning',
      timeRange: '8:45 - 13:00',
      startTime: '8:45',
      endTime: '13:00'
    },
    {
      shiftName: 'Afternoon',
      timeRange: '13:00 - 17:15',
      startTime: '13:00',
      endTime: '17:15'
    }
  ];
  prev: number;

  campaigns = [];

  missions: any;
  tempmissions: any;
  missionDetails: any;
  zones: any;
  zoneNameDisabled = true;

  rerender = false;
  marketLoaded = false;
  existingZonesFound: boolean = false;
  marketNameDisabled: boolean;
  assignmnts: any[];
  endDate: string;

  textControl = new FormControl();
  textControl1 = new FormControl();
  nameExists = false;
  oldDate;
  statusId: any;
  usedExisting: boolean;
  useExisting: boolean=true;
  d1: Date;
  first: boolean;
  count: number;
  missionName: any;
  shortName: any;
  missionData: any = {
    missionCampaign: {},
    missionType: {},
    missionZones: [{}],
};
  agent: any;
  agentId: any;
  shift: boolean;
  flag1: boolean =true;
  constructor(public _event: EventService,
    public rd: Renderer2,
    public router: Router,
    private location: Location,
    public route: ActivatedRoute,
    public apiService: ApiService,
    public gobalUTL: GlobalUtility,
    public _http: HttpService,
    public modalService: NgbModal,
    private campaign: CampaignSummaryService,
    public custUtils: CreateSurveyUtilsService,
    public custAlerts: CustomerSurveyAlertsService,
    public pedestrainAlertsService: PedestrainAlertsService,
    public translate: TranslateService) {
    route.params.subscribe(params => {
      this.missionId = params.id;
    });
  }

  isDataValid() {
    let zoneData = this.mission.markets[0];
    if (((zoneData.address || zoneData.selectedZone.address) && (zoneData.address != "" || zoneData.selectedZone.address != "")) &&
        ((zoneData.adptId || zoneData.selectedZone.adptId) && (zoneData.adptId != "" || zoneData.selectedZone.adptId != "")) &&
        ((zoneData.shortName || zoneData.selectedZone.shortName) && (zoneData.shortName != "" || zoneData.selectedZone.shortName != "")) &&
        // (!isUndefined(this.defaultUsrDataAssToZone.userId && this.defaultUsrDataAssToZone.userId != "")) &&
        ((zoneData.missionDescription) && zoneData.missionDescription != "") &&
        ((zoneData.missionName) && zoneData.missionName != "")) return true;
    else return false;
}


isOnMapClicked: boolean = false;
getEditMissionRequestBody() {

  return {
    "mission": {
      "missionId": this.missionId,
      "missionDescription": this.mission.markets[0].missionDescription,
      "missionStartDate": `${(this.startDate)} 00:00:00`,
      "missionEndDate": `${(this.startDate)} 00:00:00`,
      "missionName": this.mission.markets[0].missionName,
      "missionStatusId":this.missionDetails[0].missionStatus.statusId,
      "missionTypeId": 7,
      "missionUpdatedById": this.user.userId,
      "missionCampaignId": this.missionDetails[0].missionCampaign.campaignId,
      "classic": false,
      "market": false,
      "marketZone": this.mission.markets[0].existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].id:this.mission.markets[0].selectedZone.id:null,
      "prm": false,
      "visits": false
    },
      "circuits": [],
      "checkpoints": [],
      "assignments": [{
          "campaignId": this.missionDetails[0].missionCampaign.campaignId,
          "userId": this.selectAgentId?this.selectAgentId:this.agentId,
          "missionId": this.missionId,
          "circuitId": null,
          "checkpointId": null,
          "shiftId": this.morning?1:2,
          "startDate": `${(this.startDate)} 08:45:00`,
          "endDate": `${(this.startDate)} 13:00:00`,
          "iterations": null,
          "createdBy": this.user.userId,
          "updatedBy": this.user.userId,
          "status": 6,
          "zone": null,
          "marketZone": this.mission.markets[0].existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].id:this.mission.markets[0].selectedZone.id:null
      }],
      "marketZone": {
        "missionId": this.missionId,
        "marketZoneId": this.mission.markets[0].existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].id:this.mission.markets[0].selectedZone.id:null, //null if creating new market or actual market zone id when using existing market zone
        "shortName": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].shortName:this.mission.markets[0].selectedZone.shortName:this.mission.markets[0].shortName,
        "officialName": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].officialName:this.mission.markets[0].selectedZone.officialName:this.mission.markets[0].officialName,
        "description": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].missionDescription:this.mission.markets[0].selectedZone.missionDescription:this.mission.markets[0].missionDescription,
        "latitude": this.mapObject[0].latitude,
        "longitude": this.mapObject[0].longitude,
        "startDate": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].startDate:this.mission.markets[0].selectedZone.startDate:this.mission.markets[0].startDate,
        "endDate": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].endDate:this.mission.markets[0].selectedZone.endDate:this.mission.markets[0].endDate,
        "adptId":this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].adptId:this.mission.markets[0].selectedZone.adptId:this.mission.markets[0].adptId,
        "address":this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].address:this.mission.markets[0].selectedZone.address:this.mission.markets[0].address,
        "expectedNumberOfStands":this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].expectedNumberOfStands:this.mission.markets[0].selectedZone.expectedNumberOfStands:this.mission.markets[0].expectedNumberOfStands,
        "numberOfSubscribedStands": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].numberOfSubscribedStands:this.mission.markets[0].selectedZone.numberOfSubscribedStands:this.mission.markets[0].numberOfSubscribedStands,
        "numberOfUnSubscribedStands": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].numberOfUnSubscribedStands:this.mission.markets[0].selectedZone.numberOfUnSubscribedStands:this.mission.markets[0].numberOfUnSubscribedStands,
        "managementAuthority": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].managementAuthority:this.mission.markets[0].selectedZone.managementAuthority:this.mission.markets[0].managementAuthority,
        "createdBy": this.user.userId,
        "updatedBy": this.user.userId,
        "scheduleMonOpen": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleMonOpen?this.missionDetails[0].missionMarketZoneList[0].scheduleMonOpen+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleMonOpen:this.mission.markets[0].selectedZone.scheduleMonOpen?this.mission.markets[0].selectedZone.scheduleMonOpen + ':00': null:this.mission.markets[0].scheduleMonOpen?this.mission.markets[0].scheduleMonOpen + ':00': null,
        "scheduleMonClose": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleMonClose?this.missionDetails[0].missionMarketZoneList[0].scheduleMonClose+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleMonClose:this.mission.markets[0].selectedZone.scheduleMonClose?this.mission.markets[0].selectedZone.scheduleMonClose?this.mission.markets[0].selectedZone.scheduleMonClose+ ':00':this.mission.markets[0].selectedZone.scheduleMonClose: null:this.mission.markets[0].scheduleMonClose?this.mission.markets[0].scheduleMonClose+ ':00': null,
        "scheduleTueOpen": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleTueOpen?this.missionDetails[0].missionMarketZoneList[0].scheduleTueOpen+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleTueOpen:this.mission.markets[0].selectedZone.scheduleTueOpen?this.mission.markets[0].selectedZone.scheduleTueOpen+ ':00': null:this.mission.markets[0].scheduleTueOpen?this.mission.markets[0].scheduleTueOpen+ ':00': null,
        "scheduleTueClose": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleTueClose?this.missionDetails[0].missionMarketZoneList[0].scheduleTueClose+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleTueClose:this.mission.markets[0].selectedZone.scheduleTueClose?this.mission.markets[0].selectedZone.scheduleTueClose+ ':00': null:this.mission.markets[0].scheduleTueClose?this.mission.markets[0].scheduleTueClose+ ':00': null,
        "scheduleWedOpen": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleWedOpen?this.missionDetails[0].missionMarketZoneList[0].scheduleWedOpen+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleWedOpen:this.mission.markets[0].selectedZone.scheduleWedOpen?this.mission.markets[0].selectedZone.scheduleWedOpen+ ':00': null:this.mission.markets[0].scheduleWedOpen?this.mission.markets[0].scheduleWedOpen+ ':00': null,
        "scheduleWedClose": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleWedClose?this.missionDetails[0].missionMarketZoneList[0].scheduleWedClose+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleWedClose:this.mission.markets[0].selectedZone.scheduleWedClose?this.mission.markets[0].selectedZone.scheduleWedClose+ ':00': null:this.mission.markets[0].scheduleWedClose?this.mission.markets[0].scheduleWedClose+ ':00': null,
        "scheduleThurOpen": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleThurOpen?this.missionDetails[0].missionMarketZoneList[0].scheduleThurOpen+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleThurOpen:this.mission.markets[0].selectedZone.scheduleThurOpen?this.mission.markets[0].selectedZone.scheduleThurOpen+ ':00': null:this.mission.markets[0].scheduleThurOpen?this.mission.markets[0].scheduleThurOpen+ ':00': null,
        "scheduleThurClose":this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleThurClose?this.missionDetails[0].missionMarketZoneList[0].scheduleThurClose+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleThurClose:this.mission.markets[0].selectedZone.scheduleThurClose?this.mission.markets[0].selectedZone.scheduleThurClose+ ':00': null:this.mission.markets[0].scheduleThurClose?this.mission.markets[0].scheduleThurClose+ ':00': null,
        "scheduleFriOpen": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleFriOpen?this.missionDetails[0].missionMarketZoneList[0].scheduleFriOpen+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleFriOpen:this.mission.markets[0].selectedZone.scheduleFriOpen?this.mission.markets[0].selectedZone.scheduleFriOpen+ ':00': null:this.mission.markets[0].scheduleFriOpen?this.mission.markets[0].scheduleFriOpen+ ':00': null,
        "scheduleFriClose": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleFriClose?this.missionDetails[0].missionMarketZoneList[0].scheduleFriClose+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleFriClose:this.mission.markets[0].selectedZone.scheduleFriClose?this.mission.markets[0].selectedZone.scheduleFriClose+ ':00': null:this.mission.markets[0].scheduleFriClose?this.mission.markets[0].scheduleFriClose+ ':00': null,
        "scheduleSatOpen":this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleSatOpen?this.missionDetails[0].missionMarketZoneList[0].scheduleSatOpen+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleSatOpen:this.mission.markets[0].selectedZone.scheduleSatOpen?this.mission.markets[0].selectedZone.scheduleSatOpen+ ':00': null:this.mission.markets[0].scheduleSatOpen?this.mission.markets[0].scheduleSatOpen+ ':00': null,
        "scheduleSatClose": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleSatClose?this.missionDetails[0].missionMarketZoneList[0].scheduleSatClose+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleSatClose:this.mission.markets[0].selectedZone.scheduleSatClose?this.mission.markets[0].selectedZone.scheduleSatClose+ ':00': null:this.mission.markets[0].scheduleSatClose?this.mission.markets[0].scheduleSatClose+ ':00': null,
        "scheduleSunOpen": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleSunOpen?this.missionDetails[0].missionMarketZoneList[0].scheduleSunOpen+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleSunOpen:this.mission.markets[0].selectedZone.scheduleSunOpen?this.mission.markets[0].selectedZone.scheduleSunOpen+ ':00': null:this.mission.markets[0].scheduleSunOpen?this.mission.markets[0].scheduleSunOpen+ ':00': null,
        "scheduleSunClose": this.existingZonesCheck?this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].scheduleSunOpen?this.missionDetails[0].missionMarketZoneList[0].scheduleSunClose+ ':00':this.missionDetails[0].missionMarketZoneList[0].scheduleSunClose:this.mission.markets[0].selectedZone.scheduleSunClose?this.mission.markets[0].selectedZone.scheduleSunClose+ ':00': null:this.mission.markets[0].scheduleSunClose?this.mission.markets[0].scheduleSunClose+ ':00': null,
        "locationTypeId": 2
      }
  }
}

    /* Post Methods Starts */
    isModal: boolean = false;
    editMission() {
      if (this.isDataValid() || this.isModal) {
          this._event.broadcast({ eventName: 'showLoader', data: {} })
         
          this.subscriptions.push(this.apiService.editMission(this.getEditMissionRequestBody(), '')
              .subscribe(res => {
                  if (res.responseCode == 200) {
                      this._event.broadcast({ eventName: 'hideLoader', data: {} });
                      this.custAlerts.missionDeatailsUpdateSuccessAlert()
                          .then(() => { this.router.navigate(['supervisor/missions']); });
                  }
              }, err => {
                let response = JSON.parse(err._body);
                if (response.responseMessage === "undefined") {
                  this.custUtils.translateMessageObject({
                    title: 'Something went wrong!',
                    text: 'Market zone not created please try again',
                    type: 'error',
                    outsideClick: true,
                    cancelBtnText: '',
                    confirmBtnText: 'Ok',
                    showCancelBtn: false
                  }, message => {
                    this.custUtils.translateAndPop(message).then(() => {
                      this.disableStep2 = false;
                    }).catch(() => {
                      this.disableStep2 = false;
                    });
                  });
                } else {
                  this._event.broadcast({ eventName: 'hideLoader', data: {} });
                  if (response.responseMessage.includes('Market Zone already exists!')) {
                    let backEndString = response.responseMessage.split('Zone with ')[1];
                    // let zoneName = backEndString.split(' already exists')[0];
                    this.custUtils.translateMessageObject({
                      title: 'Market with the same name already present',
                      text: 'Please create market zone with unique name',
                      type: 'error',
                      outsideClick: false,
                      cancelBtnText: '',
                    confirmBtnText: 'Ok',
                    showCancelBtn: false
                    }, message => {
                      this.custUtils.translateAndPop(message).then(() => {
              
                      }).catch(() => {
                      });
                    });
                  } else {
                    this.custUtils.translateMessageObject({
                      title: 'All fields are mandatory',
                      text: 'Please click on an area on Map for the latitude and longitude',
                      type: 'error',
                      outsideClick: true,
                      cancelBtnText: '',
                      confirmBtnText: 'Ok',
                      showCancelBtn: false
                    }, message => {
                      this.custUtils.translateAndPop(message).then(() => {
                        this.disableStep2 = false;
                      }).catch(() => {
                        this.disableStep2 = false;
                      });
                    });
                  }
                }
              }));
              
              
              // err => {
              //   this._event.broadcast({ eventName: 'hideLoader', data: {} });
              //     this.custAlerts.somethingWentWrongWhileUpdateAlert().then(() => { });
              // }));
      }
  }

  name = false;
  description = false;
  buttonEnabled = false;
  ngOnInit() {
    this.textControl1.valueChanges.pipe(
    ).subscribe((res) => {
      res = res.trim()
      if (res !== '') {
        this.description = true
      } else {
        this.description = false
      }
      //  console.log("this.name1=",this.name,this.description);

      if (this.name && this.description) {
        this.buttonEnabled = true;
      } else {
        this.buttonEnabled = false;
      }
    });

    this.textControl.valueChanges.pipe(
    ).subscribe((res) => {
      res = res.trim()
      if (res !== '') {
        this.name = true
      } else {
        this.name = false
      }
      console.log("this.name1=", this.name, this.description);

      if (this.name && this.description) {
        this.buttonEnabled = true;
      } else {
        this.buttonEnabled = false;
      }
      if (res !== '') {

        // console.log("res=",res)
        this.apiService.getMissionName(res).subscribe((res) => {
          this.name = true;
          this.nameExists = false;
        }, (error) => {
          this.name = false;
          if(this.count==1){
            this.nameExists = false;
            this.count+=1;
          }
          else {
           if(this.missionName==res){
            this.nameExists = false;
           }
          else this.nameExists = true;            
          }
        })
      }
    });

    this.mission.markets = [];
    this._event.broadcast({ eventName: 'showLoader', data: '' });
    this.getCampaigns();
    this.getMissions(() => {
      this.getMarketZone(() => {
        this.marketLoaded = true;
      });
    this.getMissionDetails();
      this._event.broadcast({ eventName: 'hideLoader', data: '' });
    });
    this.getMissionTypes();
    // this.summaryCreator();
    $('.mapboxgl-canvas').css('width', '100%');
    $('.mapboxgl-canvas').css('height', '100%');
  }

  getCampaigns() {
    this.campaignsLoaded = false;
    this.apiService.getUserCampaigns(this.user.userId).subscribe(res => {
      console.log("comapaigns==", res);

      this.custUtils.campaignsInitializer(res.data.campaigns, response => {
        if (response.message === 'campaignExpired') {
          this.custUtils.translateMessageObject({
            title: 'Campaign expired.',
            text: 'Please contact admin for more campaigns.',
            type: 'warning',
            outsideClick: true,
            showCancelBtn: false,
            confirmBtnText: 'OK',
            cancelBtnText: ''
          }, (responseMessageObject) => {
            this.custUtils.translateAndPop(responseMessageObject).then(() => {
              this.location.back();
            }).catch(() => {
              this.location.back();
            });
          });
        } else if (response.message === 'success') {

          const data = res.data;
          const today = new Date()
          if (this.campaign.selectedCampaign === undefined) {
            // this.mission.selectedCampaign=data.campaigns[1];
            data.campaigns.forEach(element => {
              if (element.campaignId !== this.mission.selectedCampaign['campaignId']) {

                data.campaigns.forEach(element => {
                  const campaignEndDate = new Date(element.campaignEndDate)

                  if (!(campaignEndDate < today)) {

                    this.mission.selectedCampaign = element;

                  }
                })

                const campaignEndDate = new Date(element.campaignEndDate)


                if (!(campaignEndDate < today))
                  this.campaigns.push(element)
              }
            });

          } else {


            let campaignEndDate = new Date(this.campaign.selectedCampaign.campaignEndDate)
            if (campaignEndDate < today) {

              data.campaigns.forEach(element => {
                console.log("element=", element);

                console.log(campaignEndDate, today);

                if (campaignEndDate < today) {
                  console.log("in if");

                  this.mission.selectedCampaign = element;

                }
              })
            } else {
              console.log("in else");

              this.mission.selectedCampaign = this.campaign.selectedCampaign
            }



            data.campaigns.forEach(element => {
              if (element.campaignId !== this.mission.selectedCampaign['campaignId']) {
                campaignEndDate = new Date(element.campaignEndDate)

                if (!(campaignEndDate < today)) {
                  this.campaigns.push(element)

                }
              }
            });
          }
          this.campaignsLoaded = true;
        }
      });
    }, err => { });
  }

  getMissions(cb) {
    this.apiService.getMissionsCreatedByOfMissionType(this.user.userId, missionTypes.STANDS_SURVEY_TYPE_ID).subscribe(res => {
      this.missionData = res.data.missions;
      this.tempmissions = res.data.missions;
      this.custUtils.skipCalculator(res.data.missions, (missions, bool) => {
        this.missions = missions; // missions without zones
        this.missionsLoaded = true;
        // this.apiService.getMissions()
        // if (bool) {
        this.showSkipInStep1 = true;
        // } else {
        //   this.showSkipInStep1 = false;
        // }
        cb();
      });
    }, err => {
      this.showSkipInStep1 = false;
      cb();
    });
  }

  getZoneInfo(temp) {
    if (this.existingZones.length !== 0) {
          let market = temp[0].missionMarketZoneList[0];
          this.shortName=market.shortName;
          this.mission.markets.push({
            id: market.id,
            shortName: market.shortName,
            officialName: market.officialName,
            locationTypeId: 2,
            locationId: market.id,
            createdBy: this.user.userId,
            updatedBy: this.user.userId,
            adptId: market.adptId,
            latitude: market.latitude,
            startDate: market.startDate,
            endDate: market.endDate,
            longitude: market.longitude,
            address: market.address,
            expectedNumberOfStands: market.expectedNumberOfStands,
            numberOfSubscribedStands: market.numberOfSubscribedStands,
            numberOfUnSubscribedStands: market.numberOfUnSubscribedStands,
            managementAuthority: market.managementAuthority,
            scheduleMonOpen: this.replace(market.scheduleMonOpen),
            scheduleMonClose: this.replace(market.scheduleMonClose),
            scheduleTueOpen: this.replace(market.scheduleTueOpen),
            scheduleTueClose: this.replace(market.scheduleTueClose),
            scheduleWedOpen: this.replace(market.scheduleWedOpen),
            scheduleWedClose: this.replace(market.scheduleWedClose),
            scheduleThurOpen: this.replace(market.scheduleThurOpen),
            scheduleThurClose: this.replace(market.scheduleThurClose),
            scheduleFriOpen: this.replace(market.scheduleFriOpen),
            scheduleFriClose: this.replace(market.scheduleFriClose),
            scheduleSatOpen: this.replace(market.scheduleSatOpen),
            scheduleSatClose: this.replace(market.scheduleSatClose),
            scheduleSunOpen: this.replace(market.scheduleSunOpen),
            scheduleSunClose: this.replace(market.scheduleSunClose),
            fieldAgent: '',
            missionName: this.missionDetails[0].missionName,
            missionDescription: this.missionDetails[0].missionDescription,
            campaignName: this.missionDetails[0].missionCampaign.campaignName,
            selectedMission: {},
            existingZonesCheck: true
          });
          this.getSchedule(this.mission.markets[0]);
          // this.oldDate=this.missionDetails[0].agent?this.missionDetails[0].agent :'Select date';
          this.missionDetails[0].shift ? this.missionDetails[0].shift.shiftId == 1 ? this.morning = true : this.morning = false : this.morning = true;
          this.shift=this.morning;
          this.mission.markets[0].fieldAgent = this.missionDetails[0].agent ? `${this.missionDetails[0].agent.firstName}${' '}${this.missionDetails[0].agent.lastName}` : this.translate.instant('Select agent'),
          this.agent=this.mission.markets[0].fieldAgent;
          this.agentId=this.missionDetails[0].agent?this.missionDetails[0].agent.userId:null;
          this.selectAgentId=null;
          this.mission.missionEndDate = (market.endDate);
          this.mission.missionStartDate = (market.startDate);
          this.mission.missionEndDate1 = (this.mission.markets[0].endDate);
          this.mission.missionStartDate1 = (this.mission.markets[0].startDate);
          this.mission.markets[0].selectedMission = this.mission.markets1[0].selectedMission
          this.startDate = this.missionDetails[0].missionStartDate ? this.missionDetails[0].missionStartDate.split(' ')[0] : this.translate.instant('Select date');
          this.endDate = market.endDate;
          this.mission.markets[0].selectedZone = this.mission.markets[0];
          this.mapObject = [{ latitude: this.mission.markets[0].latitude, longitude: this.mission.markets[0].longitude }];
          this.validateMarket();
          this.d1=new Date(this.startDate);
          this.selectedDate = {
            year: this.d1.getFullYear(),
            month: this.d1.getMonth()+1,
            day: this.d1.getDate()
          }
             
      this.mission.markets[0].existingZones = [];
      let existingZoneLength = this.existingZones.length;
      this.existingZones.forEach(zone => {
        this.mission.markets[0].existingZones.push(zone);
                
          // this.mission.markets[0].selectedZone = this.mission.markets[0].existingZones[0];
      });
    }
    if (this.missionDetails[0].missionStartDate) {
      let d1 = new Date(this.missionDetails[0].missionStartDate.split(' ')[0]);
      if (this.missionDetails[0].agent == null) {
        this.getAllUnassignedUsersPos({
          startDate: `${d1.getFullYear()}-${d1.getMonth() + 1}-${d1.getDate()}`,
          endDate: `${d1.getFullYear()}-${d1.getMonth() + 1}-${d1.getDate()}`,
          iterations: 9,
          shift: this.morning ? 1 : 2,
          missionId: this.missionId
        }, 0);
      }
      else {
        this.getAllUnassignedUsersPos({
          startDate: `${d1.getFullYear()}-${d1.getMonth() + 1}-${d1.getDate()}`,
          endDate: `${d1.getFullYear()}-${d1.getMonth() + 1}-${d1.getDate()}`,
          iterations: 9,
          shift: this.morning ? 1 : 2,
          missionId: this.missionId
        }, 1);
      }
    }
  }
  getSchedule(market) {
    market.scheduleMonOpen?this.check=true:this.check=false,
    market.scheduleMonClose?this.check=true:this.check=false,
    market.scheduleTueOpen?this.check2=true:this.check2=false,
    market.scheduleTueClose?this.check2=true:this.check2=false,
    market.scheduleWedOpen?this.check3=true:this.check3=false,
    market.scheduleWedClose?this.check3=true:this.check3=false,
    market.scheduleThurOpen?this.check4=true:this.check4=false,
    market.scheduleThurClose?this.check4=true:this.check4=false,
    market.scheduleFriOpen?this.check5=true:this.check5=false,
    market.scheduleFriClose?this.check5=true:this.check5=false,
    market.scheduleSatOpen?this.check6=true:this.check6=false,
    market.scheduleSatClose?this.check6=true:this.check6=false,
    market.scheduleSunOpen?this.check7=true:this.check7=false,
    market.scheduleSunClose?this.check7=true:this.check7=false
  }
  getZoneInfo1(temp) {
    this.mission.markets.push({
      id: null,
      shortName: undefined,
      officialName: undefined,
      locationTypeId: 2,
      createdBy: this.user.userId,
      updatedBy: this.user.userId,
      adptId: null,
      latitude: null,
      startDate: undefined,
      endDate: undefined,
      longitude: null,
      address: undefined,
      expectedNumberOfStands: null,
      numberOfSubscribedStands: null,
      numberOfUnSubscribedStands: null,
      managementAuthority: undefined,
      scheduleMonOpen: null,
      scheduleMonClose: null,
      scheduleTueOpen: null,
      scheduleTueClose: null,
      scheduleWedOpen: null,
      scheduleWedClose: null,
      scheduleThurOpen: null,
      scheduleThurClose: null,
      scheduleFriOpen: null,
      scheduleFriClose: null,
      scheduleSatOpen: null,
      scheduleSatClose: null,
      scheduleSunOpen: null,
      scheduleSunClose: null,
      existingZones: [],
      selectedZone: {},
      missions: [],
      selectedMission: {},
      fieldAgent:'',
      missionName:this.missionDetails[0].missionName,
      missionDescription:this.missionDetails[0].missionDescription,
      campaignName: this.missionDetails[0].missionCampaign.campaignName,
      existingZonesCheck:false
    });
    this.missionDetails[0].shift?this.missionDetails[0].shift.shiftId==1?this.morning=true:this.morning=false:this.morning=true;
    this.mission.markets[0].fieldAgent=this.missionDetails[0].agent?`${this.missionDetails[0].agent.firstName}${' '}${this.missionDetails[0].agent.lastName}` :this.translate.instant('Select agent'),
    this.agent=this.mission.markets[0].fieldAgent;
    this.mission.markets[0].selectedZone = this.mission.markets[0];
    this.mission.missionEndDate1 = (this.mission.markets[0].endDate);
    this.mission.missionStartDate1 = (this.mission.markets[0].startDate);
    this.mission.markets[0].selectedMission=this.mission.markets1[0].selectedMission;
    this.startDate=this.missionDetails[0].missionStartDate?this.missionDetails[0].missionStartDate:this.translate.instant('Select date');
    // this.endDate=market.endDate;
    this.mapObject = [];
    // '4.3517', '50.8503'
    if(this.missionDetails[0].missionStartDate){
      let d1=new Date(this.missionDetails[0].missionStartDate.split(' ')[0]);
      this.getAllUnassignedUsersPos({
        startDate:`${d1.getFullYear()}-${d1.getMonth()+1}-${d1.getDate()}`,
          endDate:`${d1.getFullYear()}-${d1.getMonth()+1}-${d1.getDate()}`,
          iterations: 9,
          shift: this.morning?1:2,
          missionId: this.missionId
      },1);
    }
  }

  isReassigned=false;
  getMissionDetails() {
    this._http.SecureGet('/ref/getAllMissions?id=' + this.missionId).subscribe(res => {
      setTimeout(() => {
        this.missionDetails = res.data.missions;
        this.missionName=this.missionDetails[0].missionName;
        this.count=1;
        if(this.missionDetails[0].missionStatus.statusId==10){
          this.isReassigned=true;
          this.nameExists=false;
        }
        if (this.missionDetails[0].missionMarketZoneList) {

          this.existingZonesCheck = true;
          this.getZoneInfo(this.missionDetails);
          this.disableMapClick = true;
        }
        else{
          this.getZoneInfo1(this.missionDetails); 
        }
        this.useExisting =this.missionDetails[0].missionMarketZoneList?true:false;
       
        
        let marketDay=new Date(this.missionDetails[0].missionStartDate);
        // localStorage.setItem('market Open',JSON.stringify(marketDay.getDay()));
        this.missionDetails[0].missionStartDate?localStorage.setItem('missionStartDate', this.missionDetails[0].missionStartDate.substr(0,10)):'false';
        this.missionDetails[0].missionEndDate?localStorage.setItem('missionEndDate', this.missionDetails[0].missionEndDate):'false';
        this.startdayObj={
          year:new Date(this.missionDetails[0].missionCampaign.campaignStartDate).getFullYear(),
          month:new Date(this.missionDetails[0].missionCampaign.campaignStartDate).getMonth()+1,
          day:new Date(this.missionDetails[0].missionCampaign.campaignStartDate).getDate()
          }
        localStorage.setItem('campaignStartDate', JSON.stringify(this.startdayObj));
      //  endDateCheck.split('-');
        this.enddayObj={
          year:new Date(this.missionDetails[0].missionCampaign.campaignEndDate).getFullYear(),
          month:new Date(this.missionDetails[0].missionCampaign.campaignEndDate).getMonth()+1,
          day:new Date(this.missionDetails[0].missionCampaign.campaignEndDate).getDate()
          }
        localStorage.setItem('campaignEndDate', JSON.stringify(this.enddayObj));
      }, 50);
      
     
    });
  }
  
  optionsExistingZones: Array<any> = [];
  marketZone;
  getMarketZone(cb) {
    this.apiService.getMarketZone(this.user.userId).subscribe(res => {
      this.optionsExistingZones = [...res.data];
      this.marketZone = res.data;
      let marketsLength = res.data.length;
      if (marketsLength !== 0) {
        this.marketZone.forEach(zone => {
          this.existingZones.push(zone);
          marketsLength--;
          if (marketsLength === 0) {
            if (this.existingZones.length !== 0) {
              this.existingMarketsFound = true;
            }
            this.zoneObjectCreator(() => {
              cb();
            });
          }
        });
      }
    }, err => {
      this.existingMarketsFound = false;
      this.zoneObjectCreator(() => {
        cb();
      });
    });
  }


  zoneObjectCreator(cb) {
    this.mission.markets1.push({
      id: null,
      shortName: undefined,
      officialName: undefined,
      locationTypeId: 2,
      createdBy: this.user.userId,
      updatedBy: this.user.userId,
      adptId: null,
      latitude: null,
      startDate: undefined,
      endDate: undefined,
      longitude: null,
      address: undefined,
      expectedNumberOfStands: null,
      numberOfSubscribedStands: null,
      numberOfUnSubscribedStands: null,
      managementAuthority: undefined,
      scheduleMonOpen: null,
      scheduleMonClose: null,
      scheduleTueOpen: null,
      scheduleTueClose: null,
      scheduleWedOpen: null,
      scheduleWedClose: null,
      scheduleThurOpen: null,
      scheduleThurClose: null,
      scheduleFriOpen: null,
      scheduleFriClose: null,
      scheduleSatOpen: null,
      scheduleSatClose: null,
      scheduleSunOpen: null,
      scheduleSunClose: null,
      existingZonesCheck: false,
      existingZones: [],
      selectedZone: {},
      missions: [],
      selectedMission: {}
    });
    if (this.missions !== undefined) {
      if (this.missions.length === 0) {
        cb();
      } else {
        let noZoneMissionLength = this.missions.length;
        this.missions.forEach(mission => {
          this.mission.markets1[0].missions.push(mission);
          noZoneMissionLength--;
          if (noZoneMissionLength === 0) {
            this.mission.markets1[0].selectedMission = this.mission.markets1[0].missions[0];
            this.marketMissionLoaded = true;
            this.mission.markets1[0].missions.splice(0, 1);
            cb();
          }
        });
      }
    } else {
      cb();
    }
  }

  getMissionTypes() {
    this.missionTypesLoaded = false;
    this.missionTypes = [];

    this.apiService.getMissionTypes().subscribe(res => {
      let typeLen = res.data.length;
      res.data.forEach(type => {
        if (type.id === 3 || type.id === 4) {
          this.missionTypes.push(type);
        }
        typeLen--;
        if (typeLen === 0) {
          if (this.missionTypes[0].id === 4) {
            this.selectedMissionType = this.missionTypes[0];
            this.missionTypes.splice(0, 1);
          } else {
            this.selectedMissionType = this.missionTypes[1];
            this.missionTypes.splice(1, 1);
          }
          this.missionTypesLoaded = true;
        }
      });
    }, err => {
      console.log('err', err);
    });
  }

  gotoCancel(event) {

    this.router.navigate([`/supervisor/missions`]);
  }
  mapobj2 = []

  getLngLat(search, index, page) {
    this.flag1 = false;
    const api = new google.maps.Geocoder;
    if (!(Array.isArray(search))) {
      search = search + ' Brussels';
      if (!this.step2Completed) {
        api.geocode({ address: search }, (result: any) => {
          if (result.length !== 0) {
            this.mission.markets[0].address = result[0].formatted_address;
            this.mission.markets[0].longitude = result[0].geometry.location.lng();
            this.mission.markets[0].latitude = result[0].geometry.location.lat();
            this.mapObject = [{ 'longitude': result[0].geometry.location.lng(), 'latitude': result[0].geometry.location.lat(), flag: false }, { 'longitude': '', 'latitude': '', flag: false }]
            // console.log("in getlng lat==", this.mapObject);
            this.mapobj2 = this.mapObject;
            this.flag1 = true;
          }else {
            this.pedestrainAlertsService.enterValidLocation();    // Issue 920 resolved
          }
        });
        this.marketNameDisabled = false;
      }
    }
    else{
      if (!this.step2Completed) {
        this.mission.markets[0].longitude = search[0];
        this.mission.markets[0].latitude = search[1];
        this.mapObject = [{ 'longitude': search[0], 'latitude': search[1], flag: false }, { 'longitude': '', 'latitude': '', flag: false }]
        this.mapobj2 = this.mapObject
        // this.mission.markets[0].name = undefined;
        // this.mission.markets[0].adptId = null;
        this.marketNameDisabled = false;
        api.geocode({ latLng: { lat: search[1], lng: search[0] } }, result => {
          if (result) this.mission.markets[0].address = result[0].formatted_address;
        });
        this.flag1 = true;
      }
    }
  }

  getExistingZonesDropdownStyle(val) {
    if (val) {
      console.log('970');
      return { 'margin-top': '40px', 'margin-bottom': '190px' };
    } else {
      // console.log('973');
      return { 'margin-top': '30px', 'margin-bottom': '10px' };
    }
  }

  validateShortname(market){
    if(this.shortName===market.shortName){
      this.missionDetails[0].shift ? this.missionDetails[0].shift.shiftId == 1 ? this.morning = true : this.morning = false : this.morning = true;
      this.mission.markets[0].fieldAgent = this.missionDetails[0].agent ? `${this.missionDetails[0].agent.firstName}${' '}${this.missionDetails[0].agent.lastName}` : this.translate.instant('Select agent'),
      this.startDate = this.missionDetails[0].missionStartDate ? this.missionDetails[0].missionStartDate.split(' ')[0] : this.translate.instant('Select date');
      this.d1=new Date(this.startDate);
      this.selectedDate = {
        year: this.d1.getFullYear(),
        month: this.d1.getMonth()+1,
        day: this.d1.getDate()
      }
    }
    else{
      this.selectedDate = {};
      this.selectedAgent=this.translate.instant('Select agent');
      this.mission.markets[0].fieldAgent=this.translate.instant('Select agent');
      this.morning = true;
    }
  }

  toggleExistingZone(market, i, e) {
   
    this.usedExisting = true;
    console.log('market', market, 'mission', this.mission.markets);
    this.apiService.getLocationDetails({ 'locationName': market.name, 'locationType': 2 }).subscribe(res => {
      let market = res.data;
      this.mission.selectedMarket.push({
        id: market.id,
        shortName: market.shortName,
        officialName: market.officialName,
        locationTypeId: 2,
        // locationId:id,
        createdBy: this.user.userId,
        updatedBy: this.user.userId,
        adptId: market.adptId,
        latitude: market.latitude,
        startDate: market.startDate,
        endDate: market.endDate,
        longitude: market.longitude,
        address: market.address,
        expectedNumberOfStands: market.expectedNumberOfStands,
        numberOfSubscribedStands: market.numberOfSubscribedStands,
        numberOfUnSubscribedStands: market.numberOfUnSubscribedStands,
        managementAuthority: market.managementAuthority,
        scheduleMonOpen: this.replace(market.scheduleMonOpen),
        scheduleMonClose: this.replace(market.scheduleMonClose),
        scheduleTueOpen: this.replace(market.scheduleTueOpen),
        scheduleTueClose: this.replace(market.scheduleTueClose),
        scheduleWedOpen: this.replace(market.scheduleWedOpen),
        scheduleWedClose: this.replace(market.scheduleWedClose),
        scheduleThurOpen: this.replace(market.scheduleThurOpen),
        scheduleThurClose: this.replace(market.scheduleThurClose),
        scheduleFriOpen: this.replace(market.scheduleFriOpen),
        scheduleFriClose: this.replace(market.scheduleFriClose),
        scheduleSatOpen: this.replace(market.scheduleSatOpen),
        scheduleSatClose: this.replace(market.scheduleSatClose),
        scheduleSunOpen: this.replace(market.scheduleSunOpen),
        scheduleSunClose: this.replace(market.scheduleSunClose)
      });
      this.mission.markets[i].selectedZone = this.mission.selectedMarket[this.mission.selectedMarket.length - 1];
      this.getSchedule(this.mission.markets[i].selectedZone);
      this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].id=this.mission.markets[i].selectedZone.id:false;
      this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0]=this.mission.markets[i].selectedZone:false;
      this.mission.markets[0].existingZonesCheck=true;
      // console.log(this.mission);

      this.mission.missionEndDate = UTILS.getDatePickerDateFormat(this.mission.markets[i].selectedZone.endDate);
      this.mission.missionStartDate = UTILS.getDatePickerDateFormat(this.mission.markets[i].selectedZone.startDate);
      this.mapObject = [{ 'longitude': res.data.longitude, 'latitude': res.data.latitude, flag: false }];
      this.mission.markets[i].existingZones.push(this.mission.markets[i].selectedZone);
      //this.mission.markets[i].existingZones.splice(e, 1);
      // this.mission.markets[i].selectedZone = market;
      this.validateShortname(this.mission.markets[i].selectedZone);
      this.validateMarket();
      this._event.broadcast({ eventName: 'existing-zone-selected', data: this.mission.markets[i].selectedZone.longitude + ',' + this.mission.markets[i].selectedZone.latitude + ',' + 'map0' });
      this.usedExisting = false;
      this.useExisting=false;
   
    });
  }

  isThereExistingZones: boolean;
  getExstingZone(zoneName) {
    this.subscriptions.push(this.apiService.getAllZones('')
        .subscribe(res => {
            let data = filter(res.data.zones, (z) => { return z.name.toLowerCase() == zoneName });
            this.missionData.missionZones = data;
            if (!isEmpty(this.missionData.missionZones)) { this.isOnMapClicked = false; };
        }, err => { this.isThereExistingZones = false; }));
}

  existingDropdownToggled(value, i) {
    // let is = UTILS.isNameExistList(map(this.optionsExistingZones, (z) => z.name.toLowerCase()), this.mission.markets[i].selectedZone.shortName.toLowerCase().trim());
    // if (is) {
    //   return optionsExistingZones;   }).catch(() => this.missionData.missionZones[0].name = undefined);
    // }
   
    if (!value) {
      this.mission.markets[i].existingZones = Object.assign([], this.existingZones).filter(item => {
        console.log('this.existingZones', this.existingZones);
        if (this.mission.markets[i].selectedZone.shortName !== item.shortName) {
          return item;
        }
      });
    }
  }

  check = false;
  check1 = false;
  check2 = false;
  check3 = false;
  check4 = false;
  check5 = false;
  check6 = false;
  check7 = false;

  monChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check = true;
    localStorage.setItem('market Open','true');
    } else {
      console.log("false moi", this.mission);
      this.check = false;
      this.mission.markets[0].scheduleMonClose = "";
      this.mission.markets[0].scheduleMonOpen = "";
    }
  }

  tueChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check2 = true;
    localStorage.setItem('market Open','true');
    } else {
      this.check2 = false;
      this.mission.markets[0].scheduleTueClose = ""
      this.mission.markets[0].scheduleTueOpen = ""
    }
    
  }
  wedChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check3 = true;
      localStorage.setItem('market Open','true');
    } else {
      this.check3 = false;
      this.mission.markets[0].scheduleWedClose = ""
      this.mission.markets[0].scheduleWedOpen = ""
    }
    
  }
  thuChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check4 = true;
      localStorage.setItem('market Open','true');
    } else {
      this.check4 = false;
      this.mission.markets[0].scheduleThurClose = ""
      this.mission.markets[0].scheduleThurOpen = ""
    }
    
  }
  friChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check5 = true;
      localStorage.setItem('market Open','true');
    } else {
      this.mission.markets[0].scheduleFriClose = ""
      this.mission.markets[0].scheduleFriOpen = ""
      this.check5 = false;
    }
    
  }
  satChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check6 = true;
      localStorage.setItem('market Open','true');
    } else {
      this.mission.markets[0].scheduleSatClose = ""
      this.mission.markets[0].scheduleSatOpen = ""
      this.check6 = false;
    }
    
  }
  sunChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check7 = true;
      localStorage.setItem('market Open','true');
    } else {
      this.mission.markets[0].scheduleSunClose = ""
      this.mission.markets[0].scheduleSunOpen = ""
      this.check7 = false;
    }

  }

  existingZoneMapFiller(i) {
    if (this.existingZones.length !== 0) {
      this.mission.markets[i].existingZones = [];
      let existingZoneLength = this.existingZones.length;
      this.existingZones.forEach(zone => {
        this.mission.markets[i].existingZones.push(zone);
        existingZoneLength--;
        if (existingZoneLength === 0) {
          this.mission.markets[i].selectedZone = this.mission.markets[i].existingZones[0];

          this.apiService.getLocationDetails({ 'locationName': this.mission.markets[i].selectedZone.name, 'locationType': 2 })
            .subscribe(res => {
              let market = res.data;
              console.log(market);
              this.mission.selectedMarket = [];
              this.mission.selectedMarket.push({
                id: market.id,
                shortName: market.shortName,
                officialName: market.officialName,
                locationTypeId: 2,
                // locationId:id,
                createdBy: this.user.userId,
                updatedBy: this.user.userId,
                adptId: market.adptId,
                latitude: market.latitude,
                startDate: market.startDate,
                endDate: market.endDate,
                longitude: market.longitude,
                address: market.address,
                expectedNumberOfStands: market.expectedNumberOfStands,
                numberOfSubscribedStands: market.numberOfSubscribedStands,
                numberOfUnSubscribedStands: market.numberOfUnSubscribedStands,
                managementAuthority: market.managementAuthority,
                scheduleMonOpen: this.replace(market.scheduleMonOpen),
                scheduleMonClose: this.replace(market.scheduleMonClose),
                scheduleTueOpen: this.replace(market.scheduleTueOpen),
                scheduleTueClose: this.replace(market.scheduleTueClose),
                scheduleWedOpen: this.replace(market.scheduleWedOpen),
                scheduleWedClose: this.replace(market.scheduleWedClose),
                scheduleThurOpen: this.replace(market.scheduleThurOpen),
                scheduleThurClose: this.replace(market.scheduleThurClose),
                scheduleFriOpen: this.replace(market.scheduleFriOpen),
                scheduleFriClose: this.replace(market.scheduleFriClose),
                scheduleSatOpen: this.replace(market.scheduleSatOpen),
                scheduleSatClose: this.replace(market.scheduleSatClose),
                scheduleSunOpen: this.replace(market.scheduleSunOpen),
                scheduleSunClose: this.replace(market.scheduleSunClose)
              });
              this.mission.markets[i].selectedZone = this.mission.selectedMarket[0];
              this.getSchedule(this.mission.markets[i].selectedZone);
              this.mission.markets[0].existingZonesCheck=true;
              this.validateShortname(this.mission.markets[i].selectedZone);
              this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0].id=this.mission.markets[i].selectedZone.id:false;
              this.missionDetails[0].missionMarketZoneList?this.missionDetails[0].missionMarketZoneList[0]=this.mission.markets[i].selectedZone:false;
              console.log(this.mission.selectedMarket[0], 'selectedZone', this.mission.markets[i].selectedZone);
              this.mission.missionEndDate1 = (this.mission.markets[i].selectedZone.endDate);
              this.mission.missionStartDate1 = (this.mission.markets[i].selectedZone.startDate);
              this.mapObject = [{ 'longitude': this.mission.markets[i].selectedZone.longitude, 'latitude': this.mission.markets[i].selectedZone.latitude, flag: false }]
              this.mapobj2 = this.mapObject;
              this.mission.markets[i].existingZones.splice(0, 1);
              this.validateMarket();
            });
        }
      });
    }
  }

  replace(num) {
    console.log('num', num);
    if (num) {
      var res = num.split(':', 2);
      res = res[0] + ':' + res[1]
      console.log('res', res);
      return res;
    }
    else {
      console.log('res', res);
      return res = null;
    }

  }

  toggleCheckBox(i, event) {
    if (event.target.checked) {
      this.usedExisting = true;
      this.selectedDate = {
        year: '',
        month: '',
        day: ''
      }
      this.selectedAgent = this.translate.instant('Select agent');
      this.mission.markets[0].fieldAgent = this.translate.instant('Select agent');
      this.morning = true;
    } else {
      if (this.missionDetails[0].missionMarketZoneList) {
        this.selectedDate = {
          year: '',
          month: '',
          day: ''
        }
        this.selectedAgent = this.translate.instant('Select agent');
        this.mission.markets[0].fieldAgent = this.translate.instant('Select agent');
        this.morning = true;
      }
      this.usedExisting = false;
      this.useExisting=false;
    }
   
    if (event.target.checked !== this.mission.markets[i].existingZonesCheck) {
      this.mission.markets[i].existingZonesCheck = event.target.checked
    }
    if (this.mission.markets[i].existingZonesCheck) {
      this.existingZonesCheck = true;
      this.existingZoneMapFiller(i);
    
      this.disableMapClick = true;
    } else {
      this.mapObject = [{ 'latitude': 50.84559909325273, 'longitude': 4.348614006026935, flag: false }];

      this.existingZonesCheck = false;
      // console.log('536',this.mission);
      localStorage.setItem('market Open','false');
      this.mission.markets[i].shortName = undefined;
      this.mission.markets[i].officialName = undefined;
      this.mission.markets[i].address = undefined;
      this.mission.markets[i].latitude = null;
      this.mission.markets[i].longitude = null;
      this.mission.markets[i].adptId = null;
      this.mission.missionEndDate1=null;
      this.mission.missionStartDate1=null;
      this.mission.markets[i].expectedNumberOfStands = null;
      this.mission.markets[i].numberOfSubscribedStands = null;
      this.mission.markets[i].numberOfUnSubscribedStands = null;
      this.mission.markets[i].managementAuthority = null;
      this.mission.markets[i].scheduleMonOpen = null;
      this.mission.markets[i].scheduleMonClose = null;
      this.mission.markets[i].scheduleTueOpen = null;
      this.mission.markets[i].scheduleTueClose = null;
      this.mission.markets[i].scheduleWedOpen = null;
      this.mission.markets[i].scheduleWedClose = null;
      this.mission.markets[i].scheduleThurOpen = null;
      this.mission.markets[i].scheduleThurClose = null;
      this.mission.markets[i].scheduleFriOpen = null;
      this.mission.markets[i].scheduleFriClose = null;
      this.mission.markets[i].scheduleSatOpen = null;
      this.mission.markets[i].scheduleSatClose = null;
      this.mission.markets[i].scheduleSunOpen = null;
      this.mission.markets[i].scheduleSunClose = null;
      this.mission.markets[i].selectedZone.endDate=null;
      this.mission.markets[i].selectedZone.startDate=null;
      this.mission.markets[i].endDate=null;
      this.mission.markets[i].startDate=null;
      this.mission.markets[i].selectedZone.scheduleWedClose=null;
      this.zoneNameDisabled = true;
      this.disableMapClick = false;
      this.check = false;
      this.check1 = false;
      this.check2 = false;
      this.check3 = false;
      this.check4 = false;
      this.check5 = false;
      this.check6 = false;
      this.check7 = false;
    }
  }

  validateMarket() {
    this.marketOpen = []
    var market
    if (this.usedExisting) {
      market = this.mission.markets[0].selectedZone

    } else {
      market = this.mission.markets[0];
    }
    console.log('market', market);

    if (market.scheduleMonOpen === null) {
      this.marketOpen.push(1)
    }
    if (market.scheduleTueOpen === null) {
      this.marketOpen.push(2)
    }
    if (market.scheduleWedOpen === null) {
      this.marketOpen.push(3)
    }
    if (market.scheduleThurOpen === null) {
      this.marketOpen.push(4)
    }
    if (market.scheduleFriOpen === null) {
      this.marketOpen.push(5)
    }
    if (market.scheduleSatOpen === null) {
      this.marketOpen.push(6)
    }
    if (market.scheduleSunOpen === null) {
      this.marketOpen.push(0)
    }
    console.log("market open=", this.marketOpen);
    // localStorage.setItem('marketOpen', this.marketOpen.toString());
    localStorage.setItem("marketOpen", JSON.stringify(this.marketOpen));
    console.log('market.existingMarketCheck');
    if (this.existingZonesCheck) {
      // cb();
    } else {
      console.log(this.mission);
      if (this.mission.missionStartDate1 && this.mission.missionEndDate1) {
        let startParts = this.mission.missionStartDate1.split('/');
        let endParts = this.mission.missionEndDate1.split('/');
        if (startParts[1] > endParts[1]) {
          this.custUtils.translateMessageObject({
            title: 'Enddate should be greater than Startdate',
            text: '',
            type: 'warning',
            cancelBtnText: '',
            confirmBtnText: 'OK',
            outsideClick: false,
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              console.log('hha');
            }).catch(() => {
              console.log('hha');
            });
          });
        }
        else if(startParts[1] == endParts[1]){
          if(startParts[0] > endParts[0]){
            this.custUtils.translateMessageObject({
              title: 'Enddate should be greater than Startdate',
              text: '',
              type: 'warning',
              cancelBtnText: '',
              confirmBtnText: 'OK',
              outsideClick: false,
              showCancelBtn: false
            }, message => {
              this.custUtils.translateAndPop(message).then(() => {
                console.log('hha');
              }).catch(() => {
                console.log('hha');
              });
            });
          }
          else{
            // cb();    
          }
        }
        else{
        // cb();
        }
      } 
      else {
        this.custUtils.translateMessageObject({
          title: 'All fields are mandatory',
          text: '',
          type: 'warning',
          cancelBtnText: '',
          confirmBtnText: 'OK',
          outsideClick: false,
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
            console.log('hha');
          }).catch(() => {
            console.log('hha');
          });
        });
      }
    }
  }

  validateMarket1() {
    this.marketOpen = []
    var market
    if (this.usedExisting) {
      market = this.mission.markets[0].selectedZone

    } else {
      market = this.mission.markets[0];
    }
    console.log('market', market);

    if (market.scheduleMonOpen === null || market.scheduleMonOpen === "") {
      this.marketOpen.push(1)
    }
    if (market.scheduleTueOpen === null || market.scheduleTueOpen === "") {
      this.marketOpen.push(2)
    }
    if (market.scheduleWedOpen === null || market.scheduleWedOpen === "") {
      this.marketOpen.push(3)
    }
    if (market.scheduleThurOpen === null || market.scheduleThurOpen === "") {
      this.marketOpen.push(4)
    }
    if (market.scheduleFriOpen === null || market.scheduleFriOpen === "") {
      this.marketOpen.push(5)
    }
    if (market.scheduleSatOpen === null || market.scheduleSatOpen === "") {
      this.marketOpen.push(6)
    }
    if (market.scheduleSunOpen === null || market.scheduleSunOpen === "") {
      this.marketOpen.push(0)
    }
    console.log("market open=", this.marketOpen);
    // localStorage.setItem('marketOpen', this.marketOpen.toString());
    localStorage.setItem("marketOpen", JSON.stringify(this.marketOpen));
    console.log('market.existingMarketCheck');
  }


  isDisabled(date: NgbDateStruct, current: { month: number }) {
    // console.log("market open=",this.marketOpen);
    // this.marketOpen=[1,2]
    const d = new Date(date.year, date.month - 1, date.day);
    if (localStorage.getItem('campaignFlag') === 'false') {

      return false
    } else {

      const now = new Date(Date.now());
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));

      const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
      const busyDates = JSON.parse(localStorage.getItem('busyDates'));
      const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
      const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
      const sdate = new Date(date.year, date.month - 1, date.day);

      if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
        if (busyDates !== null) {
          let found = -1;
          const dateFinder = (dateObj) => {
            const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));



            if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
              inDate.getDate() === sdate.getDate()) {
              return true;
            } else {
              return false;
            }
          };

          found = busyDates.findIndex(dateFinder);

          let available = !busyDates.findIndex(dateFinder)

          if (found !== -1) {
            return true

          } else {
            let market = JSON.parse(localStorage.getItem('marketOpen'));
            market = JSON.parse(localStorage.getItem("marketOpen"))

            if (d.getDay() === market[0] || d.getDay() === market[1] || d.getDay() === market[2] || d.getDay() === market[3] ||
              d.getDay() === market[4] || d.getDay() === market[5] || d.getDay() === market[6] || d.getDay() === market[7]) {

              return true;

            }


          }
        } else {
          console.log("not busy=available");
          let market = JSON.parse(localStorage.getItem('marketOpen'));
          market = JSON.parse(localStorage.getItem("marketOpen"))

          if (d.getDay() === market[0] || d.getDay() === market[1] || d.getDay() === market[2] || d.getDay() === market[3] ||
            d.getDay() === market[4] || d.getDay() === market[5] || d.getDay() === market[6] || d.getDay() === market[7]) {

            return true;

          } else {
            return false;
          }

        }
      } else {
        return true;
      }
    }
  }
  
  isDisable() {
      if ((this.mission.markets[0].managementAuthority || this.mission.markets[0].selectedZone.managementAuthority) && (this.mission.markets[0].officialName || this.mission.markets[0].selectedZone.officialName) && (this.mission.markets[0].missionDescription || this.mission.markets[0].selectedZone.missionDescription)
        && (this.mission.markets[0].adptId || this.mission.markets[0].selectedZone.adptId) && (this.mission.markets[0].address || this.mission.markets[0].selectedZone.address) && (this.mission.markets[0].missionName || this.mission.markets[0].selectedZone.shortName)
        && ((this.mission.markets[0].expectedNumberOfStands || this.mission.markets[0].selectedZone.expectedNumberOfStands) && (this.mission.markets[0].expectedNumberOfStands !== '0' || this.mission.markets[0].selectedZone.expectedNumberOfStands !== '0')) && ((this.mission.markets[0].numberOfSubscribedStands == 0 || this.mission.markets[0].selectedZone.numberOfSubscribedStands == 0 )|| (this.mission.markets[0].numberOfSubscribedStands || this.mission.markets[0].selectedZone.numberOfSubscribedStands))
        && ((this.mission.markets[0].numberOfUnSubscribedStands || this.mission.markets[0].numberOfUnSubscribedStands == 0)|| (this.mission.markets[0].selectedZone.numberOfUnSubscribedStands || this.mission.markets[0].selectedZone.numberOfUnSubscribedStands == 0)) && (this.mission.markets[0].startDate || this.mission.markets[0].selectedZone.startDate)
        && (this.mission.markets[0].endDate || this.mission.markets[0].selectedZone.endDate) 
        && (this.mission.markets[0].missionDescription) && (this.mission.markets[0].missionName && !this.nameExists) && this.selectedDate && (this.mission.markets[0].fieldAgent && this.mission.markets[0].fieldAgent!==this.translate.instant('Select agent'))) {
        let list = [];
        if (this.check) {
          list.push('Monday');
        }
        if (this.check2) {
          list.push('Tuesday');
        }
        if (this.check3) {
          list.push('Wednesday');
        }
        if (this.check4) {
          list.push('Thursday');
        }
        if (this.check5) {
          list.push('Friday');
        }
        if (this.check6) {
          list.push('Saturday');
        }
        if (this.check7) {
          list.push('Sunday');
        }
  
        let boolean = list.every((res, index) => {
          if (res == 'Monday') {
            return (this.mission.markets[0].scheduleMonOpen != "" && this.mission.markets[0].scheduleMonOpen != null && this.mission.markets[0].scheduleMonClose != "" && this.mission.markets[0].scheduleMonClose != null) || (this.mission.markets[0].selectedZone.scheduleMonOpen != "" && this.mission.markets[0].selectedZone.scheduleMonOpen != null && this.mission.markets[0].selectedZone.scheduleMonClose != "" && this.mission.markets[0].selectedZone.scheduleMonClose != null);
          }
          if (res == 'Tuesday') {
            return (this.mission.markets[0].scheduleTueOpen != "" && this.mission.markets[0].scheduleTueOpen != null && this.mission.markets[0].scheduleTueClose != "" && this.mission.markets[0].scheduleTueClose != null) || (this.mission.markets[0].selectedZone.scheduleTueOpen != "" && this.mission.markets[0].selectedZone.scheduleTueOpen != null && this.mission.markets[0].selectedZone.scheduleTueClose != "" && this.mission.markets[0].selectedZone.scheduleTueClose != null);
          }
          if (res == 'Wednesday') {
            return (this.mission.markets[0].scheduleWedOpen != "" && this.mission.markets[0].scheduleWedOpen != null && this.mission.markets[0].scheduleWedClose != "" && this.mission.markets[0].scheduleWedClose != null) || (this.mission.markets[0].selectedZone.scheduleWedOpen != "" && this.mission.markets[0].selectedZone.scheduleWedOpen != null && this.mission.markets[0].selectedZone.scheduleWedClose != "" && this.mission.markets[0].selectedZone.scheduleWedClose != null);
          }
          if (res == 'Thursday') {
            return (this.mission.markets[0].scheduleThurOpen != "" && this.mission.markets[0].scheduleThurOpen != null && this.mission.markets[0].scheduleThurClose != "" && this.mission.markets[0].scheduleThurClose != null) || (this.mission.markets[0].selectedZone.scheduleThurOpen != "" && this.mission.markets[0].selectedZone.scheduleThurOpen != null && this.mission.markets[0].selectedZone.scheduleThurClose != "" && this.mission.markets[0].selectedZone.scheduleThurClose != null);
          }
          if (res == 'Friday') {
            return (this.mission.markets[0].scheduleFriOpen != "" && this.mission.markets[0].scheduleFriOpen != null && this.mission.markets[0].scheduleFriClose != "" && this.mission.markets[0].scheduleFriClose != null) || (this.mission.markets[0].selectedZone.scheduleFriOpen != "" && this.mission.markets[0].selectedZone.scheduleFriOpen != null && this.mission.markets[0].selectedZone.scheduleFriClose != "" && this.mission.markets[0].selectedZone.scheduleFriClose != null);
          }
          if (res == 'Saturday') {
            return (this.mission.markets[0].scheduleSatOpen != "" && this.mission.markets[0].scheduleSatOpen != null && this.mission.markets[0].scheduleSatClose != "" && this.mission.markets[0].scheduleSatClose != null) || (this.mission.markets[0].selectedZone.scheduleSatOpen != "" && this.mission.markets[0].selectedZone.scheduleSatOpen != null && this.mission.markets[0].selectedZone.scheduleSatClose != "" && this.mission.markets[0].selectedZone.scheduleSatClose != null);
          }
          if (res == 'Sunday') {
            return (this.mission.markets[0].scheduleSunOpen != "" && this.mission.markets[0].scheduleSunOpen != null && this.mission.markets[0].scheduleSunClose != "" && this.mission.markets[0].scheduleSunClose != null) || (this.mission.markets[0].selectedZone.scheduleSunOpen != "" && this.mission.markets[0].selectedZone.scheduleSunOpen != null && this.mission.markets[0].selectedZone.scheduleSunClose != "" && this.mission.markets[0].selectedZone.scheduleSunClose != null);
          }
        });
  
        if (list.length > 0) {
          if (boolean == true) {
            return false;
          }
          return true;
        }
        return true;
      } else {
        return true;
      }  
  }

  isDisabled2(date: NgbDate, current: { month: number }) {
    const d = new Date(date.year, date.month - 1, date.day);
       const now = new Date(Date.now());
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
      localStorage.removeItem('busyDates');
      const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
      const busyDates = JSON.parse(localStorage.getItem('busyDates'));
      const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
      const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
      const sdate = new Date(date.year, date.month - 1, date.day);

      if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
        if (busyDates !== null) {
          let found = -1;
          const dateFinder = (dateObj) => {
            const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));



            if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
              inDate.getDate() === sdate.getDate()) {
              return true;
            } else {
              return false;
            }
          };

          found = busyDates.findIndex(dateFinder);

          let available = !busyDates.findIndex(dateFinder)

          if (found !== -1) {
            return true

          } else {
            let market = (localStorage.getItem('missionStartDate'));
            market = (localStorage.getItem("missionStartDate"))
            
            // if (d.getDay() === new Date(market).getDay()) {

            //   return true;

            // }
            var res=market.split('-');
            let year=parseInt(res[0]);
            let month= parseInt(res[1]);
            let date34=parseInt(res[2]);
            
            const d1 = month==0?new Date(year,11,date34):new Date(year,month-1,date34);
            var arr = [1, 2, 3, 4, 5, 6, 0];
            arr.forEach(i => {
              if ( arr[i] === d1.getDay()) { 
                arr.splice(i, 1); 
              }
            });
            
            if (d.getDay() === arr[0] || d.getDay() === arr[1] || d.getDay() === arr[2] || d.getDay() === arr[3] ||
            d.getDay() === arr[4] || d.getDay() === arr[5] || d.getDay() === arr[6] || d.getDay() === arr[7]) {
             
              return true;  
            }

          }
        } else {
          console.log("not busy=available");
          var market =(localStorage.getItem('missionStartDate'));
          market = (localStorage.getItem("missionStartDate"))
          
          console.log(market);
          var res=market.split('-');
          let year=parseInt(res[0]);
          let month= parseInt(res[1]);
          let date34=parseInt(res[2]);
          
          const d1 = month==0?new Date(year,11,date34):new Date(year,month-1,date34);
          var arr = [1, 2, 3, 4, 5, 6, 0];
          arr.forEach(i => {
            if ( arr[i] === d1.getDay()) { 
              arr.splice(i, 1); 
            }
          });
          
          if (d.getDay() === arr[0] || d.getDay() === arr[1] || d.getDay() === arr[2] || d.getDay() === arr[3] ||
          d.getDay() === arr[4] || d.getDay() === arr[5] || d.getDay() === arr[6] || d.getDay() === arr[7]) {
           
            return true;

          } else {
            return false;
          }

        }
      } else {
        return true;
      }
    
  }

  isDisabled1(date: NgbDateStruct, current: { month: number }) {
    const d = new Date(date.year, date.month - 1, date.day);
    if (localStorage.getItem('campaignFlag') === 'false') {

      return false
    } else {

      const now = new Date(Date.now());
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
      const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
      const busyDates = JSON.parse(localStorage.getItem('busyDates'));
      const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
      const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
      const sdate = new Date(date.year, date.month - 1, date.day);

      if (localStorage.getItem('market Open') === 'true') {
     
        if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
          if (busyDates !== null) {
            let found = -1;
            const dateFinder = (dateObj) => {
              const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
  
  
  
              if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
                inDate.getDate() === sdate.getDate()) {
                return true;
              } else {
                return false;
              }
            };
  
            found = busyDates.findIndex(dateFinder);
  
            let available = !busyDates.findIndex(dateFinder)
  
            if (found !== -1) {
              return true
  
            } else {
              let market = JSON.parse(localStorage.getItem('marketOpen'));
              market = JSON.parse(localStorage.getItem("marketOpen"))
  
              if (d.getDay() === market[0] || d.getDay() === market[1] || d.getDay() === market[2] || d.getDay() === market[3] ||
                d.getDay() === market[4] || d.getDay() === market[5] || d.getDay() === market[6] || d.getDay() === market[7]) {
  
                return true;
  
              }
  
  
            }
          } else {
            console.log("not busy=available");
            let market = JSON.parse(localStorage.getItem('marketOpen'));
            market = JSON.parse(localStorage.getItem("marketOpen"))
  
            if (d.getDay() === market[0] || d.getDay() === market[1] || d.getDay() === market[2] || d.getDay() === market[3] ||
              d.getDay() === market[4] || d.getDay() === market[5] || d.getDay() === market[6] || d.getDay() === market[7]) {
  
              return true;
  
            } else {
              return false;
            }
  
          }
        } else {
          return true;
        }
      }
      else {
        if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
          if (busyDates !== null) {
            let found = -1;
            const dateFinder = (dateObj) => {
              const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
              if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
                inDate.getDate() === sdate.getDate()) {
                return true;
              } else {
                return false;
              }
            };

            // found = busyDates.findIndex(dateFinder);
            // if (found !== -1) {
            //   return true;
            // } else {
            //   return false;
            // }
          } else {
            return false;
          }
        } else {
          return true;
        }
      }
    }
  }

  selectedDate;
  selectedDateStep3;
  endDates;
  missionDate;
  getDate(d1) {
    var g1 = new Date();
    let endDateCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
  
    endDateCheck = new Date(`${endDateCheck.year}-${endDateCheck.month}-${endDateCheck.day}`)
    let startDateCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    startDateCheck = new Date(`${startDateCheck.year}-${startDateCheck.month}-${startDateCheck.day}`)
  
    // (YYYY-MM-DD) 
    var CurrentDate = new Date()
    var d = new Date();
    // var d = new Date(CurrentDate),
    let dateToday = {
      month: '' + (d.getMonth() + 1),
      day: '' + d.getDate(),
      year: d.getFullYear()
    }
  
    if (dateToday.month.length < 2)
      dateToday.month = '0' + dateToday.month;
    if (dateToday.day.length < 2)
      dateToday.day = '0' + dateToday.day;
    var today = `${dateToday.year}-${dateToday.month}-${dateToday.day}`
  
  
    // var g2 = new Date(`${d1.year}-${d1.month}-${d1.day}`); 
    console.log("d1.day=", d1.day, g1.getMonth(), this.minDate, this.minDate.day === d1.day);
    var GivenDate = new Date(`${d1.year}-${d1.month}-${d1.day}`);
    const month1 = String(d1.month).padStart(2, "0");
    const day1 = String(d1.day).padStart(2, "0");
    var todayDate = `${d1.year}-${month1}-${day1}`
    console.log("checkdate", startDateCheck);
    console.log((GivenDate > endDateCheck), (GivenDate < startDateCheck));
  
    if(new Date(this.campaignEndDate)< CurrentDate){
      this.campaignFlag=false;
      localStorage.setItem('campaignFlag', 'false');
    } else {
      this.campaignFlag=true
      localStorage.setItem('campaignFlag', 'true');
      this.startdayObj={
        year:startDateCheck.getFullYear(),
        month:startDateCheck.getMonth()+1,
        day:startDateCheck.getDate()
        }
      localStorage.setItem('campaignStartDate', JSON.stringify(this.startdayObj));
    //  endDateCheck.split('-');
      this.enddayObj={
        year:endDateCheck.getFullYear(),
        month:endDateCheck.getMonth()+1,
        day:endDateCheck.getDate()
        }
      localStorage.setItem('campaignEndDate', JSON.stringify(this.enddayObj));
    }
  
    if (this.campaignFlag) {
      if ((!(GivenDate > endDateCheck) && !(GivenDate < startDateCheck)) || (GivenDate.getDate() == startDateCheck.getDate())) {
        if (GivenDate >= CurrentDate || (today === todayDate)) {
  
  
          // if (d1.day >= this.minDate.day ) {
          // this.dateSelected=true;
          this.dateSelected = true;
          this.mission.missionStartDate = {
            year: d1.year,
            month: d1.month,
            day: d1.day
          }
          console.log("mision startdate=", this.mission.missionStartDate);
  
          localStorage.setItem('date', JSON.stringify(d1));
  
  
          this.startDate = `${d1.year}-${d1.month}-${d1.day}`
          const endDate = '2020-10-12 ' + '23:59:00'
          const startDate = '2020-10-12 ' + '00:00:00'
          this._http.SecureGet('/ref/getDatesInRange?startDate=' + startDate + '&endDate=' + endDate).subscribe(res => {
            console.log("res field agents=", res);
  
          }, err => {
          });
          let bye=new Date(this.startDate);
          let hi=new Date(localStorage.getItem('missionEndDate'));
          
          if( bye.getDate()===hi.getDate() && this.shift==this.morning){
            this.getAllUnassignedUsersPos({
              startDate: `${d1.year}-${d1.month}-${d1.day}`,
              endDate: `${d1.year}-${d1.month}-${d1.day}`,
              iterations: 9,
              shift: this.morning ? 1 : 2,
              missionId: this.missionId
            }, 2);
            this.mission.markets[0].fieldAgent= this.agent;
           this.agentId=this.agentId;
           this.selectAgentId=null;
          }
          else {
            this.getAllUnassignedUsersPos({
              startDate: `${d1.year}-${d1.month}-${d1.day}`,
              endDate: `${d1.year}-${d1.month}-${d1.day}`,
              iterations: 9,
              shift: this.morning ? 1 : 2,
              missionId: this.missionId
            }, 0);
          }
        }
      }
    } else {
      if (GivenDate >= CurrentDate || (today === todayDate)) {
  
  
        // if (d1.day >= this.minDate.day ) {
        // this.dateSelected=true;
        this.dateSelected = true;
        this.mission.missionStartDate = {
          year: d1.year,
          month: d1.month,
          day: d1.day
        }
        console.log("mision startdate=", this.mission.missionStartDate);
  
        localStorage.setItem('date', JSON.stringify(d1));
  
        console.log("date selected...!!!");
        this.startDate = `${d1.year}-${d1.month}-${d1.day}`
        const endDate = '2020-10-12 ' + '23:59:00'
        const startDate = '2020-10-12 ' + '00:00:00'
        this._http.SecureGet('/ref/getDatesInRange?startDate=' + startDate + '&endDate=' + endDate).subscribe(res => {
          console.log("res field agents=", res);
  
        }, err => {
        });
        let bye=new Date(d1);
        let hi=new Date(localStorage.getItem('missionStartDate'));
        if( bye.getDate()===hi.getDate() && this.shift==this.morning){
          this.getAllUnassignedUsersPos({
            startDate: `${d1.year}-${d1.month}-${d1.day}`,
            endDate: `${d1.year}-${d1.month}-${d1.day}`,
            iterations: 9,
            shift: this.morning ? 1 : 2,
            missionId: this.missionId
          }, 2);
          this.mission.markets[0].fieldAgent =this.agent;
          this.agentId=this.agentId;
          this.selectAgentId=null;
          // this.selectedAgent =this.agent;
        }
        else {
          this.getAllUnassignedUsersPos({
            // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
            // endDate: UTILS.getDateFormatWithTime(endDate),
            startDate: `${d1.year}-${d1.month}-${d1.day}`,
            endDate: `${d1.year}-${d1.month}-${d1.day}`,
            iterations: 9,
            shift: this.morning ? 1 : 2,
            missionId: this.missionId
          }, 0);
        }
      }
    }
  }
    getUnassignedUsers(){
      this.getAllUnassignedUsersPos({
        // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
        // endDate: UTILS.getDateFormatWithTime(endDate),
        startDate:this.startDate,
        endDate:this.startDate,
        iterations: 9,
        shift: this.morning?1:2,
        missionId: this.missionId
      },0);
      
    }

    toggleFieldAgent(user){
      this.agentSelected=true;
      this.selectedAgent=`${user.firstName} ${user.lastName}`
      this.selectAgentId=user.userId
      this.mission.markets[0].fieldAgent=this.selectedAgent;
    }

  validateAssignment(cb) {
    if (this.assignmentsLoaded) {
      cb();
    }
  }

 
  selectedAgent;
  selectAgentId;
  // dateSelected=false;
  optionsAgents = []
  getAllUnassignedUsersPos(reqBody,location) {
    this.subscriptions.push(
      this.apiService.getAllUnassignedUsersPos(reqBody).subscribe(
        res => {
          this.dateSelected = true
          this.optionsAgents = [];         
          this.optionsAgents = map(res.users, m =>
            UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` })
          );
          (location==1 || location==2)?this.optionsAgents.push(this.missionDetails[0].agent):false;
          console.log("res===", this.optionsAgents);
          this.mission.markets[0].fieldAgent= location!==1 && location!==2?`${res.users[0].firstName}${' '}${res.users[0].lastName}`:this.agent;
          this.agentId=location!==1 && location!==2?res.users[0].userId:this.agentId;
          this.selectAgentId=null;
        },
        err => {
          if (err.status === 400) {
            this.dateSelected = false
            this.mission.markets[0].fieldAgent= (location!==1 && location!==2)?this.translate.instant('Select agent'):this.agent;
            // this.selectedAgent= this.translate.instant('Select agent');
            this.agentId=(location!==1 && location!==2)?null:this.agentId;
            this.agentSelected = false
            location!==2 && location!==1?this.custAlerts.noAgentFound():false;
          }
        }
      )
    );
  }

  changeShiftId(id) {
    console.log("id=", id);

    if (id === 1) {
      this.morning = true;
      this.getUsedMissionDates(this.today);
      if (this.startDate !== undefined) {
        // this.getUnassignedUsers()
        let bye = new Date(this.startDate);
        let hi = new Date(localStorage.getItem('missionEndDate'));
        if (bye.getDate() === hi.getDate() && this.shift==true) {
          this.getAllUnassignedUsersPos({
            startDate: this.startDate,
            endDate: this.startDate,
            iterations: 9,
            shift: this.morning ? 1 : 2,
            missionId: this.missionId
          }, 1);
          this.mission.markets[0].fieldAgent = this.agent;
          this.agentId = this.agentId;
          this.selectAgentId = null;
        }
        else {
          this.getAllUnassignedUsersPos({
            // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
            // endDate: UTILS.getDateFormatWithTime(endDate),
            startDate: this.startDate,
            endDate: this.startDate,
            iterations: 9,
            shift: this.morning ? 1 : 2,
            missionId: this.missionId
          }, 0);
        }
      }
    } else {
      this.morning = false;
      this.getUsedMissionDates(this.today);
      if (this.startDate !== undefined) {
        // this.getUnassignedUsers()
        let bye = new Date(this.startDate);
        let hi = new Date(localStorage.getItem('missionEndDate'));
        if (bye.getDate() === hi.getDate() &&  this.shift==false) {
          this.getAllUnassignedUsersPos({
            startDate: this.startDate,
            endDate: this.startDate,
            iterations: 9,
            shift: this.morning ? 1 : 2,
            missionId: this.missionId
          }, 1);
          this.mission.markets[0].fieldAgent = this.agent;
          this.agentId = this.agentId;
          this.selectAgentId = null;
        }
        else {
          this.getAllUnassignedUsersPos({
            // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
            // endDate: UTILS.getDateFormatWithTime(endDate),
            startDate: this.startDate,
            endDate: this.startDate,
            iterations: 9,
            shift: this.morning ? 1 : 2,
            missionId: this.missionId
          }, 0);
        }
      }
    }
  }

  getUsedMissionDates(date) {
    let currentDate = UTILS.getDatePickerDateFormat(date);
    this.subscriptions.push(
      this.apiService
        .getShiftWiseUsedMissionDates(
          UTILS.getDateFormatWithoutZero(currentDate),
          missionTypes.POS_POI_TYPE_ID, this.morning ? 1 : 2
        )
        .subscribe(
          res => {
            Globals.BUSY_DATES = res.dateDto;
          },
          err => (Globals.BUSY_DATES = [])
        )
    );
  }

  assignmentFieldAgentsFiller(assignment, cb) {
    // console.log('this.mission.markets[0].selectedMission.missionStartDate', this.mission.markets[0].selectedMission.missionStartDate);
    this.apiService.getUnassignedUsers({
      // startDate: this.mission.markets[0].selectedMission.missionStartDate.split(' ')[0],
      startDate: this.dateSelected ? this.selectedDateStep3 : this.currentDate,
      missionId: this.mission.markets[0].selectedMission.missionId,
      shift: this.morning ? 1 : 2
    }).subscribe(res => {
      cb(res.users);

    }, err => {
      this.custUtils.translateMessageObject({
        title: this.translate.instant('No Field agents available'),
        text: this.translate.instant('Please change the mission date or  ask admin to add more field agents.'),
        type: 'warning',
        cancelBtnText: '',
        confirmBtnText: 'OK',
        outsideClick: false,
        showCancelBtn: false
      }, message => {
        this.custUtils.translateAndPop(message).then(() => {
          this.mission.assignments = this.assignmnts
          this.dateSelected = false;
          assignment.fieldAgents = [];
          this.mission.markets[0].fieldAgent= this.translate.instant('Select agent');
          this.agentSelected = false
          // this.location.back();
        }).catch(() => {
          this.mission.assignments = this.assignmnts
          this.dateSelected = false;
          this.mission.markets[0].fieldAgent= this.translate.instant('Select agent');
          assignment.fieldAgents = [];
          this.agentSelected = false
          // this.location.back();
        });
      });
    });
  }

  summaryCreator() {
    this.summaryLoaded = false;
    this.summaryObj = {
      mission: this.mission.markets[0].selectedMission,
      zone: this.mission.markets[0],
      assignment: this.mission.assignments[0],
    }
    console.log(this.summaryObj);

    setTimeout(() => {
      this.summaryLoaded = true;
      this._event.broadcast({ eventName: 'circle-map-loaded', data: '' });
    }, 500);
    setTimeout(() => {
      console.log('hi', this.summaryObj.zone.selectedZone.latitude);
      // this.getLngLat();
      // this.mapObject= [{'longitude': this.summaryObj.zone.selectedZone.longitude, 'latitude': this.summaryObj.zone.selectedZone.latitude,flag:false }];     
      this._event.broadcast({ eventName: 'existing-zone-selected', data: this.summaryObj.zone.selectedZone.latitude + ',' + this.summaryObj.zone.selectedZone.longitude + ',' + 'map1' });
    }, 700);
  }
  ngAfterViewInit() {
    $('app-edit-mission-stands').on('click', (e) => {
      setTimeout(() => {
        if (this.existingZonesCheck) {
          if (e.target.className === 'nav-link mission-dd open-dd' || e.target.id === 'openDD') {
            if (!e.target.parentNode.className.includes('show')) {
              this.parent2Toggle = this.zonesDropdown.nativeElement;
              this.classAdder();
            } else if (e.target.parentNode.className.includes('show')) {
              this.parent2Toggle = this.zonesDropdown.nativeElement;
              this.classRemover();
            }
          } else if (e.target.id === 'searchZoneName' || e.target.id === 'dontHideDD1' || e.target.id === 'dontHideDD2' || e.target.id === 'dontHideDD3' || e.target.id === 'dontHideDD4') {

          } else {
            this.parent2Toggle = this.zonesDropdown.nativeElement;
            this.classRemover();
          }
        }
      }, 100);
    });
  }
  classRemover() {
    this.rd.removeClass(this.parent2Toggle.parentNode, 'show');
  }

  classAdder() {
    this.rd.addClass(this.parent2Toggle.parentNode, 'show');
  }
  keyDown(e){
    // charCode > 31 && (charCode < 48 || charCode > 57)
    if(!(e.keyCode >= 47 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105)){
      e.preventDefault();
      e.stopPropagation();
    }
  }

  keyUp(e){
    if(!((e.keyCode > 95 && e.keyCode < 106) || (e.keyCode > 47 && e.keyCode < 58) 
      || e.keyCode == 8)) {
        return false;
    }
  }
  
  keyUp1(e){
    if(!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58) 
      || e.keyCode == 8)) {
        return false;
    }
  }

  macAddressFormat1(mac, event) {
    // var macAddress = event.target.value.toUpperCase();
    if(!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)){
      event.preventDefault();
      event.stopPropagation();
    }
    else{
    if (event.keyCode != 13) {

      var macAddr = event.target.value;
      var rash;

      var alphaNum = /^[A-Za-z0-9]+$/;
      if (macAddr.includes('/')) {
        if (macAddr.length == 5) {
          // console.log('393', event.target.value);
          var parts = event.target.value.split('/');
          // console.log(parts);
          if (parts[1] > 12) {
            parts[1] = 12;
            event.target.value = parts[0] + '/' + parts[1];
            // console.log('425', event.target.value);
          }
          if (parts[0] > 31) {
            parts[0] = 31;
            event.target.value = parts[0] + '/' + parts[1];
            // console.log('425', event.target.value);
          }

        } else if (macAddr.length == 4) {
          // console.log('393', event.target.value);
          var parts = event.target.value.split('/');
          // console.log(parts);
          if (parts[1] > 5) {
            parts[1] = 5;
            event.target.value = parts[0] + '/' + parts[1];
            // console.log('425', event.target.value);
          }
          if (parts[0] > 31) {
            parts[0] = 31;
            event.target.value = parts[0] + '/' + parts[1];
            // console.log('425', event.target.value);
          }
          console.log('final', event.target.value);
        }
      }
      if (macAddr.length == 2 && alphaNum.test(macAddr)) {

        // macAddr = macAddr.replace(/(.{2})/g, "$1:").slice(0, -1);
        macAddr = macAddr + '/';
        event.target.value = macAddr;
        rash = event.target.value;
        
      }
      else if (macAddr.length == 2) {
        if (macAddr > 31) {
          event.target.value = 31;
          rash = event.target.value;
          console.log('395', event.target.value);
        }
      }
      else if (!alphaNum.test(macAddr)) {
        console.log("only alpha-numeric allowed");
      }
    }
  }
  }

  macAddressFormat(mac, event) {
    // var macAddress = event.target.value.toUpperCase();
    if (!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) {
      event.preventDefault();
      event.stopPropagation();
    }
    else {
      if (event.keyCode != 13) {

        var macAddr = event.target.value;
        var rash;

        var alphaNum = /^[A-Za-z0-9]+$/;
        if (macAddr.includes(':')) {
          if (macAddr.length == 5) {
            // console.log('393', event.target.value);
            var parts = event.target.value.split(':');
            // console.log(parts);
            if (parts[1] > 59) {
              parts[1] = 59;
              event.target.value = parts[0] + ':' + parts[1];
              // console.log('425', event.target.value);
            }
            if (parts[0] > 23) {
              parts[0] = 23;
              event.target.value = parts[0] + ':' + parts[1];
              // console.log('425', event.target.value);
            }
            console.log('final', event.target.value);
          } else if (macAddr.length == 4) {
            // console.log('393', event.target.value);
            var parts = event.target.value.split(':');
            // console.log(parts);
            if (parts[1] > 5) {
              parts[1] = 5;
              event.target.value = parts[0] + ':' + parts[1];
              // console.log('425', event.target.value);
            }
            if (parts[0] > 24) {
              parts[0] = 24;
              event.target.value = parts[0] + ':' + parts[1];
              // console.log('425', event.target.value);
            }
            console.log('final', event.target.value);
          }
        }
        if (macAddr.length == 2 && alphaNum.test(macAddr)) {

          // macAddr = macAddr.replace(/(.{2})/g, "$1:").slice(0, -1);
          macAddr = macAddr + ':';
          event.target.value = macAddr;
          rash = event.target.value;
          console.log('389', event.target.value);
        }
        else if (macAddr.length == 2) {
          if (macAddr > 24) {
            event.target.value = 24;
            rash = event.target.value;
            console.log('395', event.target.value);
          }
          else
            if (macAddr > 12) {
              var count = macAddr - 12;
              event.target.value = 12 + count;
              rash = event.target.value;
              console.log(event.target.value);
            }

        }
        else if (!alphaNum.test(macAddr)) {
          console.log("only alpha-numeric allowed");
        }
      }
    this.validateMarket1();
    }
  }

  searchExistingZoneName(value, i) {
    if (!value) {
      console.log('this.existingZones', this.existingZones, 'selectedone', this.mission.markets[i].selectedZon);
      this.mission.markets[i].existingZones = Object.assign([], this.existingZones).filter(item => {
        if (this.mission.markets[i].selectedZone.name !== item.name) {
          return item;
        }
      });
    } else {
      this.mission.markets[i].existingZones = Object.assign([], this.existingZones).filter(
        item => {
          if (this.mission.markets[i].selectedZone.shortName !== item.name) {
            console.log('shortname', this.mission.markets[i], item.name);
            return item.name.toLowerCase().indexOf(value.toLowerCase()) > -1;
          }
        }
      );
    }
  }
}
