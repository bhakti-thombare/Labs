import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditMissionCustomerSurveyComponent } from './edit-mission-customer-survey.component';

describe('EditMissionCustomerSurveyComponent', () => {
  let component: EditMissionCustomerSurveyComponent;
  let fixture: ComponentFixture<EditMissionCustomerSurveyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditMissionCustomerSurveyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditMissionCustomerSurveyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
