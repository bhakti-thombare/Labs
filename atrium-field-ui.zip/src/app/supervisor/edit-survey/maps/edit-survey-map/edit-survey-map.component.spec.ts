import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditSurveyMapComponent } from './edit-survey-map.component';

describe('EditSurveyMapComponent', () => {
  let component: EditSurveyMapComponent;
  let fixture: ComponentFixture<EditSurveyMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditSurveyMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditSurveyMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
