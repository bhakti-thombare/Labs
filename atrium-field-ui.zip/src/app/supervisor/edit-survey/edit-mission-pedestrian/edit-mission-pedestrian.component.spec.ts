import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditMissionPedestrianComponent } from './edit-mission-pedestrian.component';

describe('EditMissionPedestrianComponent', () => {
  let component: EditMissionPedestrianComponent;
  let fixture: ComponentFixture<EditMissionPedestrianComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditMissionPedestrianComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditMissionPedestrianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
