import { FormControl } from '@angular/forms';
// core 
import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';

// 3rd party
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import swal from 'sweetalert2';
import { Ng4FilesStatus, Ng4FilesSelected, Ng4FilesService, Ng4FilesConfig } from 'angular4-files-upload';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { isNull, filter } from "underscore";

// app
import { HttpService } from '@app/services/http-service';
import { EventService } from '@services/events/event.service';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '@services/apiServices/api.service';
import { PedestrainAlertsService } from '@services/Alerts/pedestrainAlerts/pedestrain-alerts.service';
import { CheckpointDaoInterface } from '@app/interfaces/interface';
import { ApiConstants } from '@app/constants/constants';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';
import { TranslateService } from '@ngx-translate/core';
import { CreateSurveyUtilsService } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.service';
import { UTILS, GlobalUtility } from '@services/global-utility.service';

declare var google: any;
@Component({
  selector: 'app-edit-mission-pedestrian',
  templateUrl: './edit-mission-pedestrian.component.html',
  styleUrls: ['./edit-mission-pedestrian.component.css']
})

/* @author : Pratik Bhuta
the functions are separated according to the following:-

A. Configuration - these run at the component load time.
B. Initializers
1. Getters
2. Togglers
3. Creators
4. DOM Manipulators
5. Fillers
6. Validators
7. Deletors
*/

export class EditMissionPedestrianComponent implements OnInit, AfterViewInit {

  ogMission = {};
  user;
  circuitIds = [];
  startDate;
  checkpointIds = [];
  missionId = null;
  xmlHttpUrl = ApiConstants.BASE_URL;
  dateChanged = false;
  mission = {
    missionName: '',
    campaignName: '',
    campaignId: null,
    taskType: '',
    taskTypeId: null,
    startDate: {
      year: null,
      month: null,
      day: null
    },
    endDate: {
      year: null,
      month: null,
      day: null
    },
    estimatedTime: '',
    missionDescription: '',
    missionId: null,
    circuits: [],
    checkpoints: [],
    assignments: [],
    fieldAgents: []
  };
  circuitNameDisabled = true;
  existingCircuitsCheck = false;

  circuitPresent = false;
  checkpointsFound = false;
  fillEditMissionFlag = false;

  loadMapForExistingCircuit = false;

  checkpointMap;

  checkpointIndexes = [];

  database = [];

  poppedData = [];

  checkpointMapGeoJSON = {
    'type': 'FeatureCollection',
    'features': [],
  };

  userCheckpoints;

  calendarReady = false;
  submitdisabled = false;
  showAddNewCircuit = true;
  newCircuit = false;
  addNewCheckpoint = false;
  existingCircuitsFound = false;
  showAddNewCheckpoint = false;
  today = new Date(Date.now());

  minDate = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };

  minEndDate = {
    day: null,
    month: null,
    year: null
  };

  busyDates = [];
  existingCircuits = [];
  noCheckpointCircuits = [];

  allUsers = [];

  model: NgbDateStruct;

  public selectedFiles;
  formatter = (result: string) => result.toUpperCase();
  availableFieldAgentsFound = false;

  private testConfig: Ng4FilesConfig = {
    acceptExtensions: ['jpeg', 'jpg', 'png'],
    maxFilesCount: 1,
    maxFileSize: 20000000,
    totalFilesSize: 20000000
  };
  @ViewChild('d1') d1: any;
  marketZone;
  isReassigned = false;
  enableDropsown: boolean=false;
  datepickers = [];
  hideImage: boolean=false;
  constructor(public location: Location,
    public router: Router,
    public http: HttpService,
    private route: ActivatedRoute,
    public event: EventService,
    private ng4FilesService: Ng4FilesService,
    private _http: HttpClient,
    private utils: ApiService,    
    public translate: TranslateService,
    public custUtils: CreateSurveyUtilsService,
    public pedestrainAlertsService: PedestrainAlertsService) {
    localStorage.removeItem('busyDates');
    const date = new Date();
    const month = date.getMonth() + 1;
    this.http.SecureGet('/ref/getMissionDates?currentDate=' + date.getFullYear() + '-' +
      + month + '-' + date.getDate() + '&missionType=3').subscribe(res => {
        let busyDatesLen = res.dateDto.length;
        res.dateDto.forEach(resdate => {
          resdate.day = parseInt(resdate.day, 10);
          resdate.month = parseInt(resdate.month, 10);
          resdate.year = parseInt(resdate.year, 10);
          this.busyDates.push(resdate);
          busyDatesLen--;
          if (busyDatesLen === 0) {
            localStorage.setItem('busyDates', JSON.stringify(this.busyDates));
            this.calendarReady = true;
          }
        });
      }, err => {
        this.calendarReady = true;
      });
    this.user = JSON.parse(localStorage.getItem('user-data'));
    this.ng4FilesService.addConfig(this.testConfig, 'my-image-config');
    this.route.params.subscribe(params => {
      this.event.broadcast({ eventName: 'showLoader', data: '' });
      this.missionId = params.id;
      this.http.pullCountry().subscribe(res => {
        this.validateUser(() => {
          this.getExistingCicuits(() => {
            this.componentInitializer();
          });
        });
      }, err => {
        this.validateUser(() => {
          this.getExistingCicuits(() => {
            this.componentInitializer();
          });
        });
      });
    });
  }

  validateUser(cb) {
    this.http.SecureGet('/mission/getMissionCreatedBy?missionId=' + this.missionId).subscribe(res => {
      if (this.user.userId === res.userId) {
        cb();
      } else {
        this.location.back();
      }
    }, err => {
      this.location.back();
    });
  }

  getExistingCicuits(cb) {
    this.http.SecureGet('/ref/getAllCircuits?withCheckpoints=true').subscribe(res => {
      let existingCircuitsLength = res.data.circuits.length;
      res.data.circuits.forEach(circuit => {
        this.existingCircuits.push(circuit);
        existingCircuitsLength--;
        if (existingCircuitsLength === 0) {
          this.existingCircuitsFound = true;
          this.http.SecureGet('/ref/getAllCircuits?withCheckpoints=false').subscribe(resNo => {
            if (resNo.data.circuits.length !== null) {
              let noLen = resNo.data.circuits.length;
              resNo.data.circuits.forEach(circuit => {
                this.noCheckpointCircuits.push(circuit);
                noLen--;
                if (noLen === 0) {
                  cb();
                }
              });
            } else {
              cb();
            }
          }, err => {
            cb();
          });
        }
      });
    }, err => {
      this.existingCircuitsFound = false;
      this.http.SecureGet('/ref/getAllCircuits?withCheckpoints=false').subscribe(resNo => {
        if (resNo.data.circuits.length !== null) {
          let noLen = resNo.data.circuits.length;
          resNo.data.circuits.forEach(circuit => {
            this.noCheckpointCircuits.push(circuit);
            noLen--;
            if (noLen === 0) {
              cb();
            }
          });
        } else {
          cb();
        }
      }, err => {
        cb();
      });
    });

  }

  getExistingCircuitsDropdownStyle(val) {
    if (val) {
      return { 'margin-top': '40px', 'margin-bottom': '190px' };
    } else {
      return { 'margin-top': '190px', 'margin-bottom': '40px' };
    }
  }

  componentInitializer() {
    this.getMission(this.missionId, () => {
      this.getAllFieldAgents(() => {
        if (this.mission.checkpoints.length !== 0) {
          this.getUserMissionDetails((flag) => {
            if (flag) {
              this.assignmentInitializer(() => {
              });
            } else {
              this.assignmentFiller('noAssignment', () => { });
            }
          });
        }

        if (this.mission.circuits.length > 0 && this.checkpointsFound){
          this.mission.circuits[0].existingCircuitsCheck = true;
          this.isCheckedExisting = true;
        }

        if (this.mission.circuits[0].existingCircuitsCheck && this.mission.checkpoints.length !== 0) {
              this.mission.circuits[0].ogImage = true;
              this.mission.circuits[0].existingCircuitsCheck = true;
              //this.checkpointsFound = false;
              this.circuitPresent = false;
              this.mission.checkpoints = [];
              this.mission.assignments = [];
              this.existingCircuitsCheckpoitFiller(0);
              this.mission.circuits[0].selectedExistingCircuit.circuitName = this.mission.circuits[0].circuitName;
         
        } else if (this.mission.circuits[0].existingCircuitsCheck && this.mission.checkpoints.length === 0) {
          this.mission.circuits[0].ogImage = true;
          this.mission.circuits[0].existingCircuitsCheck = true;
          this.fillEditMissionFlag = true;
          this.existingCircuitsCheckpoitFiller(0);
        } else {
          this.mission.circuits[0].ogImage = false;
          this.circuitNameDisabled = true;
          this.mission.circuits[0].existingCircuitsCheck = false;
          this.checkpointsFound = false;
          this.circuitPresent = false;
          this.mission.checkpoints = [];
          this.mission.assignments = [];
          this.mission.circuits[0].circuitName = '';
          
          // this.mission.circuits[0].map.flyTo({
          //    center: [this.mission.circuits[0].circuitLongitude, this.mission.circuits[0].circuitLatitude],
          //    zoom: 9,
          //    bearing: 0,
          //    curve: 1
          //  });
          //  setTimeout(() => {
          //  }, 200);
          this.mission.assignments.forEach(assignment => {
            assignment.geojson.features = [];
          });
          this.checkpointMapGeoJSON.features = [];

          this.existingCircuitsCheck = false;

          if (this.market){
            let ogMission: any = this.ogMission;
            if (ogMission.missionMarketZoneList.length > 0) {
              const feature = {
                'type': 'Feature',
                'geometry': { 'type': 'Point', 'coordinates': [ogMission.missionMarketZoneList[0].longitude, ogMission.missionMarketZoneList[0].latitude] },
                'lnglat': [ogMission.missionMarketZoneList[0].longitude, ogMission.missionMarketZoneList[0].latitude],
                'checkpointName': ogMission.missionMarketZoneList[0].officialName,
                'marketSelected': true
              };
              this.mission.circuits[0].checkpointsGeoJson['features'].push(feature);
              this.checkpointMapGeoJSON.features.push(feature);
            }
        }

        }
      });
    });
  }
  textControl = new FormControl();
  nameExists = false;
  count: number;
  missionName: any;
  ngOnInit() {
    this.getMarketZone();

    this.textControl.valueChanges.pipe(
    ).subscribe((res) => {
      res = res.trim()
      if (res !== '') {
        this.name = true
      } else {
        this.name = false
      }
      console.log("this.name1=", this.name, this.description);

      if (this.name && this.description) {
        this.buttonEnabled = true;
      } else {
        this.buttonEnabled = false;
      }
      if (res !== '') {

        // console.log("res=",res)
        this.utils.getMissionName(res).subscribe((res) => {
          this.name = true;
          this.nameExists = false;
        }, (error) => {
          this.name = false;
          if (this.count == 1) {
            this.nameExists = false;
            this.count += 1;
          }
          else {
            if (this.missionName == res) {
              this.nameExists = false;
            }
            else this.nameExists = true;
          }
        })
      }
    });
  }

  ngAfterViewInit() {
    this.event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'newAssignment') {
          setTimeout(() => {
            $('.ng2-tag-input__text-input').css('display', 'none');
            $('.ng2-tag-input').css('border-bottom', '0');

            $('.click2Scroll').click(function () {
              $('.wrap-textarea').scrollTop($('.wrap-textarea')[0].scrollHeight);
            });
          }, 100);
        }
      }
    });

  }

  /* Configurators
    1. changeLocalDate(date)
    2. isWeekend(date: NgbDateStruct)
    3. isDisabled(date: NgbDateStruct, current: { month: number })
    4. isEndDisabled(date: NgbDateStruct, current: { month: number })
    5. filesSelect(selectedFiles: Ng4FilesSelected, i)
    6. onMapLoad(map, i, element)
  */

  changeLocalDate(date, e) {
    console.log('event', e);
    if (!e.target.classList.contains('text-lightgrey')) {
      const now = new Date(Date.now());
      const today = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
      const busyDates = JSON.parse(localStorage.getItem('busyDates'));
      const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
      const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
      const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
      const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
      const sdate = new Date(date.year, date.month - 1, date.day);
      if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
        if (busyDates !== null) {
          let found = -1;
          const dateFinder = (dateObj) => {
            const inDate = new Date(dateObj.year, dateObj.month, dateObj.day);
            return inDate === sdate;
          };

          found = busyDates.findIndex(dateFinder);
          if (found !== -1) {
          } else {
            this.pedestrainAlertsService.changingDateRemoveAssignments()
              .then(() => {
                if (this.startDate.day === date.day && this.startDate.month === date.month && this.startDate.year === date.year) {
                  this.dateChanged = false;
                } else {
                  this.dateChanged = true;
                }
                this.changeMissionDate();
                this.startDate = this.mission.startDate;
                this.mission.endDate = this.mission.taskTypeId === 3 ? this.mission.startDate : {
                  year: null,
                  month: null,
                  day: null
                };
              })
              .catch(() => {
                this.mission.startDate = this.startDate;
                this.mission.endDate = this.mission.taskTypeId === 3 ? this.mission.startDate : {
                  year: null,
                  month: null,
                  day: null
                };
              });
          }
        } else {
          this.pedestrainAlertsService.changingDateRemoveAssignments()
            .then(() => {
              if (this.startDate.day === date.day && this.startDate.month === date.month && this.startDate.year === date.year) {
                this.dateChanged = false;
              } else {
                this.dateChanged = true;
              }
              this.changeMissionDate();
              this.startDate = this.mission.startDate;
              this.mission.endDate = this.mission.taskTypeId === 3 ? this.mission.startDate : {
                year: null,
                month: null,
                day: null
              };
            })
            .catch(() => {
              this.mission.startDate = this.startDate;
              this.mission.endDate = this.mission.taskTypeId === 3 ? this.mission.startDate : {
                year: null,
                month: null,
                day: null
              };
            });
        }
      }
    }
  }

  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6;
  }

  isDisabled(date: NgbDateStruct, current: { month: number }) {
    const d = new Date(date.year, date.month - 1, date.day);
    const now = new Date(Date.now());
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
    const sdate = new Date(date.year, date.month - 1, date.day);

    if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };

        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  isReassignedDisabled(date: NgbDateStruct, current: { month: number }) {
    const d = new Date(date.year, date.month - 1, date.day);
    const now = new Date(Date.now());
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
    const sdate = new Date(date.year, date.month - 1, date.day);

    if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };

        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        //return false;
          console.log("not busy=available");
          var market = (localStorage.getItem('missionStartDate'));
          market = (localStorage.getItem("missionStartDate"))

          console.log(market);
          var res = market.split('-');
          let year = parseInt(res[0]);
          let month = parseInt(res[1]);
          let date34 = parseInt(res[2]);

          const d1 = month == 0 ? new Date(year, 11, date34) : new Date(year, month - 1, date34);
          var arr = [1, 2, 3, 4, 5, 6, 0];
          arr.forEach(i => {
            if (arr[i] === d1.getDay()) {
              arr.splice(i, 1);
            }
          });

          if (d.getDay() === arr[0] || d.getDay() === arr[1] || d.getDay() === arr[2] || d.getDay() === arr[3] ||
            d.getDay() === arr[4] || d.getDay() === arr[5] || d.getDay() === arr[6] || d.getDay() === arr[7]) {

            return true;

          } else {
            return false;
          }
        
      }
    } else {
      return true;
    }
  }

  isEndDisabled(date: NgbDateStruct, current: { month: number }) {
    const localDate = JSON.parse(localStorage.getItem('date'));
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const now = new Date(Date.now());
    const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const missionStartDate = new Date(localDate.year, localDate.month - 1, localDate.day);
    const sdate = new Date(date.year, date.month, date.day, 0, 0, 0);
    if (sdate >= missionStartDate && sdate >= today && sdate >= campaignStartDate && sdate <= campaignEndDate) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };

        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  public filesSelect(selectedFiles: Ng4FilesSelected, i): void {
    if (selectedFiles.status !== Ng4FilesStatus.STATUS_SUCCESS) {
      this.selectedFiles = selectedFiles.status;
      if (this.selectedFiles === 2) {
        this.pedestrainAlertsService.fileSizeShouldNotMT20MB();
      } else if (this.selectedFiles === 4) {
        this.pedestrainAlertsService.fileExtensionAlert();
      }
      return;
    }

    if (selectedFiles.files && selectedFiles.files[0]) {
      this.mission.circuits[i].ogImage = false;
      const reader = new FileReader();
      setTimeout(() => {
        reader.onload = (e: any) => {
          const str = '#img' + i;
          this.mission.circuits[i].image = selectedFiles.files[0];
          $(str).attr('src', e.target.result);
        };
        reader.readAsDataURL(selectedFiles.files[0]);
      }, 100);
    }

    this.selectedFiles = Array.from(selectedFiles.files).map(file => file.name);
  }

  onMapLoad(map, i, element) {
    if (element === 'circuit') {
      this.mission.circuits[i].map = map;
    } else if (element === 'checkpoint') {
      this.checkpointMap = map;
      // this.mission.checkpoints[i].map = map;
    }
  }

  /* Initializer
    1. initializeRequestObject()
  */

  initializeRequestObject(cb) {
    let checklen = this.mission.checkpoints.length;
    const circuits = [];
    let circlen = this.mission.circuits.length;
    this.mission.circuits.forEach(circuit => {
      circuits.push(circuit);
      circlen--;
      if (circlen === 0) {
        this.mission.checkpoints.forEach((checkpoint, checki) => {
          checkpoint.circuits = [];
          checkpoint.selectedCircuit = {};
          let cLen = circuits.length;
          circuits.forEach(cir => {
            checkpoint.circuits.push(cir);
            cLen--;
            if (cLen === 0) {
              const indexFinder = (c) => {
                return checkpoint.circuitId === c.circuitId;
              };
              const ind = checkpoint.circuits.findIndex(indexFinder);
              checkpoint.selectedCircuit = checkpoint.circuits[ind];
              checkpoint.circuits.splice(ind, 1);
              checklen--;
              if (checklen === 0) {
                if (!this.showAddNewCircuit) { /* this check is for the mission type == pedestrian */
                  if (this.mission.checkpoints.length < 3) {
                    this.showAddNewCheckpoint = true;
                  } else {
                    this.showAddNewCheckpoint = false;
                  }
                } else {
                  this.showAddNewCheckpoint = true;
                }
                this.event.broadcast({ eventName: 'hideLoader', data: '' });
                cb();
              }
            }
          });
        });
      }
    });
  }

  /* Getters
    1. getMission(id, cb)
    2. getUserMissionDetails(cb)
    3. getAllFieldAgents(cb)
    4. getLatLong(search, index, element)
    5. reverseGeocoder(circuitName, i)
    6. refreshGeoJSON(cb)
    7. getDataFromDatabase(signal)
    8. existingCircuitsFiller(circuit, cb)
    9. getFieldAgents
    10. 
  */
  isCheckedExisting = false;
  isShift;
  selectedFieldAgent;
  fieldAgents = [];
  taged;
  getMission(id, cb) {
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this.mission.missionId = parseInt(id, 10);
    this.http.SecureGet('/ref/getAllMissions?id=' + id).subscribe(res => {
      if (res.data.missions[0].missionType.id === 3) {
        this.showAddNewCircuit = false;
      }
      this.missionName = res.data.missions[0].missionName;
      this.count = 1;

      this.ogMission = res.data.missions[0];
      this.classic = res.data.missions[0].classic;
      this.market = res.data.missions[0].market;
      if (res.data.missions[0].agent == null){
        this.selectedFieldAgent = {};
        this.fieldAgents = [];
      } else{
        this.selectedFieldAgent = res.data.missions[0].agent;
        this.fieldAgents = [res.data.missions[0].agent];
      }
      if (res.data.missions[0].missionStatus.statusId == 10){
        this.isReassigned = true;
      }
      if (res.data.missions[0].missionStartDate){
        let strtDate = res.data.missions[0].missionStartDate.split(' ')[0];
        localStorage.setItem('missionStartDate', strtDate);
        localStorage.setItem('missionEndDate', strtDate);
      }

      if (res.data.missions[0].missionCircuits.length > 0){
        this.taged = res.data.missions[0].missionCircuits[0].circuitCheckpoints.map(res => res.checkpointName);
      }
      if (res.data.missions[0].shift == null){
        this.isShift = 'Morning';
      } else {
        if (res.data.missions[0].shift.shiftName == 'PM'){
          this.isShift = 'Afternoon';
        } else{
          this.isShift = 'Morning';
        }
      }

      if (res.data.missions[0].missionMarketZoneList !=null){
        // if (res.data.missions[0].missionMarketZoneList.length > 0){
          
        // }
        this.marketid = res.data.missions[0].missionMarketZoneList[0].id;
        this.selectedMarketZoneValue = res.data.missions[0].missionMarketZoneList[0].officialName;
      } else{
         this.isCheckedExisting = false;
      }

      this.mission.campaignName = res.data.missions[0].missionCampaign.campaignName;
      const campaignStartDate = res.data.missions[0].missionCampaign.campaignStartDate.split(' ')[0];
      const startDate = {
        day: parseInt(campaignStartDate.split('-')[2], 10),
        month: parseInt(campaignStartDate.split('-')[1], 10),
        year: parseInt(campaignStartDate.split('-')[0], 10)
      };
      const campaignEndDate = res.data.missions[0].missionCampaign.campaignEndDate.split(' ')[0];
      const endDate = {
        day: parseInt(campaignEndDate.split('-')[2], 10),
        month: parseInt(campaignEndDate.split('-')[1], 10),
        year: parseInt(campaignEndDate.split('-')[0], 10)
      };
      localStorage.setItem('campaignStartDate', JSON.stringify(startDate));
      localStorage.setItem('campaignEndDate', JSON.stringify(endDate));
      this.mission.campaignId = res.data.missions[0].missionCampaign.campaignId;
      this.mission.missionName = res.data.missions[0].missionName;
      this.mission.taskType = res.data.missions[0].missionType.name;
      this.mission.taskTypeId = res.data.missions[0].missionType.id;
      if (res.data.missions[0].missionStartDate !=null){
        const startdate = res.data.missions[0].missionStartDate.split(' ')[0].split('-');
        const enddate = this.mission.taskTypeId === 3 ? startdate : res.data.missions[0].missionEndDate.split(' ')[0].split('-');
        this.mission.startDate = {
          day: parseInt(startdate[2], 10),
          month: parseInt(startdate[1], 10),
          year: parseInt(startdate[0], 10),
        };
        this.startDate = {
          day: parseInt(startdate[2], 10),
          month: parseInt(startdate[1], 10),
          year: parseInt(startdate[0], 10),
        };
        this.mission.endDate = {
          day: parseInt(enddate[2], 10),
          month: parseInt(enddate[1], 10),
          year: parseInt(enddate[0], 10),
        };
        localStorage.setItem('date', JSON.stringify(this.mission.startDate));
        this.mission.estimatedTime = res.data.missions[0].missionEstimatedTime;
      }
      this.mission.missionDescription = res.data.missions[0].missionDescription;
      this.calendarReady = true;
      let circuitLength = res.data.missions[0].missionCircuits.length;
      if (circuitLength === 0) {
        const circuit = {
          circuitName: undefined,
          circuitLongitude: 4.3517,
          circuitLatitude: 50.8503,
          ogImage: false,
          existingCircuitsCheck: false,
          existingCircuits: [],
          tempExistingCircuits: [],
          existingCircuitSearch: undefined,
          selectedExistingCircuit: {},
          checkpointsGeoJson: {
            'type': 'FeatureCollection',
            'features': []
          }
        };
        this.newCircuit = true;
        this.existingCircuitsFiller(circuit, (cir) => {
          this.mission.circuits.push(cir);
          cb();
          this.event.broadcast({ eventName: 'hideLoader', data: '' });
        });        
      } else {
        this.circuitPresent = false;
        res.data.missions[0].missionCircuits.forEach(circuit => {
          this.circuitPresent = true;
          console.log('circuit', circuit);
          let checkpointsLength = circuit.circuitCheckpoints.length;
          circuit.ogImage = true;
          circuit.existingCircuitsCheck = false;
          circuit.existingCircuits = [];
          circuit.tempExistingCircuits = [];
          circuit.existingCircuitSearch = undefined;
          circuit.selectedExistingCircuit = {};
          circuit.checkpointsGeoJson = {
            'type': 'FeatureCollection',
            'features': []
          };
          this.existingCircuitsFiller(circuit, (cir) => {
            this.mission.circuits.push(cir);
            this.mission.circuits[0].selectedExistingCircuit = circuit;
          });
          circuitLength--;
          if (checkpointsLength === 3) {
            this.checkpointsFound = true;
          }
          if (checkpointsLength !== 0) {
            circuit.circuitCheckpoints.forEach(checkpoint => {
              checkpoint.checkpointDescription = checkpoint.checkpointDescription === 'undefined' ? '' : checkpoint.checkpointDescription;
              checkpoint.circuitId = circuit.circuitId;

              checkpoint.selected_adrn = {
                adt_adrn: ''
              };
              checkpoint.adrns = [],
                checkpoint.selected_street = {
                  adt_street: ''
                };
              checkpoint.streets = [];
              checkpoint.selected_postalcode = {
                adt_postal_code: ''
              };
              checkpoint.postalcodes = [];
              checkpoint.selected_commune = {
                com_commune_name_fr: ''
              };
              checkpoint.communes = [];
              checkpoint.selected_region = {
                reg_region_name_fr: ''
              };
              checkpoint.regions = [];
              checkpoint.selected_country = {
                con_country_name_fr: ''
              };
              checkpoint.coutries = [];
              checkpoint.adptid_valid = true;
              checkpoint.dontKnowAdptId = true;
              checkpoint.countryLoaded = false;
              checkpoint.regionLoaded = false;
              checkpoint.communeLoaded = false;
              checkpoint.postalCodeLoaded = false;
              checkpoint.streetLoaded = false;
              checkpoint.adrnLoaded = false;
              checkpoint.data = {
                checkpointName: '',
                search: '',
                address: '',
                description: '',
                checkpointNameDisabled: false,
                adptid: checkpoint.adptId,
                quartier: undefined,
                lnglat: []
              };
              this.mission.checkpoints.push(checkpoint);
              const databaseObj: CheckpointDaoInterface = {
                id: checkpoint.checkpointId,
                checkpointName: checkpoint.checkpointName,
                index: this.mission.checkpoints.length - 1
              };
              this.database.push(databaseObj);
              this.fillPullApiFields(this.mission.checkpoints.length - 1, () => {
              }, checkpoint.adptId);
              checkpointsLength--;
              if (circuitLength === 0 && checkpointsLength === 0) {
                this.initializeRequestObject(() => {
                  cb();
                });
              }
            });
          } else {
            if (circuitLength === 0) {
              this.createCheckpoint();
              this.showAddNewCheckpoint = true;
              cb();
              this.event.broadcast({ eventName: 'hideLoader', data: '' });
            }
          }
        });
        //this.existingCircuitsCheckpoitFiller(circuitLength);
      }
    }, err => {
      this.location.back();
    });
  }

  existingCircuitsFiller(circuit, cb) {
    let extCirLen = this.existingCircuits.length;
    if (this.existingCircuits.length !== 0) {
      this.existingCircuits.forEach(extCir => {
        circuit.existingCircuits.push(extCir);
        circuit.tempExistingCircuits.push(extCir);
        extCirLen--;
        if (extCirLen === 0) {
          circuit.selectedExistingCircuit = circuit.existingCircuits[0];
          circuit.existingCircuits.splice(0, 1);
          cb(circuit);
        }
      });
    } else {
      cb(circuit);
    }
  }

  getUserMissionDetails(cb) {
    this.http.SecureGet('/mission/getUserMissionDetails?missionId=' + this.mission.missionId).subscribe(res => {
      this.userCheckpoints = res.data.userCircuits;
      cb(true);
    }, err => {
      cb(false);
    });
  }

  getAllFieldAgents(cb) {
    const month = this.today.getMonth() + 1;
    const today = this.today.getFullYear() + '-' + month + '-' + this.today.getDate();
    this.http.SecurePost('/ref/getAllUnassignedUsers', {
      startDate: this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day,
      missionId: this.mission.missionId
    }).subscribe(resFA => {
      const availableUsers = [];
      let userslen = resFA.users.length;
      resFA.users.forEach(user => {
        availableUsers.push(user);
        userslen--;
        if (userslen === 0) {
          this.availableFieldAgentsFound = true;
          if (this.dateChanged === true) {
            let availLen = availableUsers.length;
            availableUsers.forEach(ava => {
              this.mission.fieldAgents.push(ava);
              availLen--;
              if (availLen === 0) {
                cb();
              }
            });
          } else {
            this.getFieldAgents(() => {
              cb();
            }, availableUsers);
          }
        }
      });
    }, err => {
      this.getFieldAgents(() => {
        cb();
      });
    });
  }

  getFieldAgents(cb, availableUsers?) {
    this.http.SecureGet('/ref/getAllUsers?roleId=3').subscribe(res => {
      let resUersLen = res.data.users.length;
      res.data.users.forEach(user => {
        if (user.isActive && !user.resetPassword) {
          this.allUsers.push(user);
        }
        resUersLen--;
        if (resUersLen === 0) {
          if (availableUsers) {
            let availableUsersLength = availableUsers.length;
            availableUsers.forEach(availuser => {
              this.mission.fieldAgents.push(availuser);
              availableUsersLength--;
              if (availableUsersLength === 0) {
                cb();
              }
            });
          } else {
            cb();
          }
        }
      });
    }, err => {
    });
  }

  getLatLong(search, index, element) {
    const api = new google.maps.Geocoder;
    // this._http.get('https://maps.googleapis.com/maps/api/geocode/json?address=' + search).subscribe((data: any) => {
    api.geocode({ "address": search }, data => {
      if (data.length !== 0) {
        if (element === 'circuit') {
          if (this.circuitPresent && this.checkpointsFound) {
            this.pedestrainAlertsService.changeExistingCirtcuitandRemoveCheckpoints()
              .then(() => {
                const found = Object.assign([], this.mission.circuits[index].tempExistingCircuits).filter((extCir) => {
                  const c1 = extCir.circuitName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                  const c2 = search.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                  return c1.toLowerCase() === c2.toLowerCase();
                });
                if (found.length !== 0) {
                  this.pedestrainAlertsService.circuitExistWithSameName(search)
                    .then(() => {
                      this.circuitPresent = false;
                      let deleteIndex;
                      this.checkpointsFound = false;
                      let extCirLen = this.mission.circuits[index].existingCircuits.length;
                      const extCirLen2 = this.mission.circuits[index].existingCircuits.length;
                      let foundCircuit = {};
                      if (extCirLen2 === 0) {
                        this.existingCircuitsCheckpoitFiller(index);
                      } else {
                        const c3 = this.mission.circuits[index].selectedExistingCircuit.circuitName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                        const c4 = search.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                        if (c3.toLowerCase() === c4.toLowerCase()) {
                          this.existingCircuitsCheckpoitFiller(index);
                        } else {
                          this.mission.circuits[index].existingCircuits.forEach((extCir, i) => {
                            const c7 = extCir.circuitName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                            const c8 = search.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                            if (c7.toLowerCase() === c8.toLowerCase()) {
                              deleteIndex = i;
                              foundCircuit = extCir;
                            }
                            extCirLen--;
                            if (extCirLen === 0) {
                              this.mission.circuits[index].existingCircuits.push(this.mission.circuits[index].selectedExistingCircuit);
                              this.mission.circuits[index].selectedExistingCircuit = foundCircuit;
                              this.mission.circuits[index].ogImage = true;
                              this.mission.circuits[index].existingCircuits.splice(deleteIndex, 1);
                              this.existingCircuitsCheckpoitFiller(index);
                            }
                          });
                        }
                      }
                    }).catch(() => { });
                } else {
                  if (this.mission.circuits[index].circuitId !== null && this.mission.circuits[index].circuitId !== undefined) {
                    this.pedestrainAlertsService.removeCheckPointsAssociatedwithCircuit()
                      .then(() => {
                        this.checkpointsFound = false;
                        this.checkpointRemover(() => {
                          this.circuitPresent = false;
                          this.mission.circuits[index].ogImage = false;
                          this.mission.circuits[index].image = null;
                          this.mission.circuits[index].circuitId = null;
                          this.newCircuit = true;
                          const prevName = this.mission.circuits[index].circuitName;
                          this.mission.circuits[index].circuitName = search;
                          this.circuitNameDisabled = false;
                          this.mission.circuits[index].circuitLongitude = data[0].geometry.location.lng();
                          this.mission.circuits[index].circuitLatitude = data[0].geometry.location.lat();
                          // this.mission.circuits[index].map.flyTo({
                          //   center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                          //   zoom: 9,
                          //   bearing: 0,
                          //   curve: 1
                          // });
                          if (this.mission.checkpoints.length === 0) {
                            this.addNewCheckpoint = true;
                            this.showAddNewCheckpoint = true;
                            this.createCheckpoint();
                          } else {
                            if (prevName === undefined) {
                              this.add2CheckpointsCircuitArray(index);
                            } else {
                              this.circuitUpdater(search, prevName);
                            }
                          }
                        });
                      })
                      .catch(() => {
                        this.circuitPresent = false;
                        this.checkpointsFound = false;
                        const prevName = this.mission.circuits[index].circuitName;
                        this.mission.circuits[index].circuitName = search;
                        this.circuitNameDisabled = false;
                        this.mission.circuits[index].circuitLongitude = data[0].geometry.location.lng();
                        this.mission.circuits[index].circuitLatitude = data[0].geometry.location.lat();
                        // this.mission.circuits[index].map.flyTo({
                        //   center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                        //   zoom: 9,
                        //   bearing: 0,
                        //   curve: 1
                        // });
                        if (this.mission.checkpoints.length === 0) {
                          this.addNewCheckpoint = true;
                          this.showAddNewCheckpoint = true;
                          this.createCheckpoint();
                        } else {
                          if (prevName === undefined) {
                            this.add2CheckpointsCircuitArray(index);
                          } else {
                            this.circuitUpdater(search, prevName);
                          }
                        }
                      });
                  } else {
                    const prevName = this.mission.circuits[index].circuitName;
                    this.mission.circuits[index].circuitName = search;
                    this.circuitNameDisabled = false;
                    this.mission.circuits[index].circuitLongitude = data[0].geometry.location.lng();
                    this.mission.circuits[index].circuitLatitude = data[0].geometry.location.lat();
                    // this.mission.circuits[index].map.flyTo({
                    //   center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                    //   zoom: 9,
                    //   bearing: 0,
                    //   curve: 1
                    // });
                    if (this.mission.checkpoints.length === 0) {
                      this.addNewCheckpoint = true;
                      this.showAddNewCheckpoint = true;
                      this.createCheckpoint();
                    } else {
                      if (prevName === undefined) {
                        this.add2CheckpointsCircuitArray(index);
                      } else {
                        this.circuitUpdater(search, prevName);
                      }
                    }
                  }
                }

              })
              .catch(() => { });
          } else {
            const found = Object.assign([], this.mission.circuits[index].tempExistingCircuits).filter((extCir) => {
              const c1 = extCir.circuitName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
              const c2 = search.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
              return c1.toLowerCase() === c2.toLowerCase();
            });
            if (found.length !== 0) {
              this.pedestrainAlertsService.circuitExistWithSameName(search)
                .then(() => {
                  let deleteIndex;
                  this.circuitPresent = false;
                  let extCirLen = this.mission.circuits[index].existingCircuits.length;
                  const extCirLen2 = this.mission.circuits[index].existingCircuits.length;
                  let foundCircuit = {};
                  if (extCirLen2 === 0) {
                    this.existingCircuitsCheckpoitFiller(index);
                  } else {
                    const c3 = this.mission.circuits[index].selectedExistingCircuit.circuitName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                    const c4 = search.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                    if (c3.toLowerCase() === c4.toLowerCase()) {
                      this.mission.circuits[index].ogImage = true;
                      this.existingCircuitsCheckpoitFiller(index);
                    } else {
                      this.mission.circuits[index].existingCircuits.forEach((extCir, i) => {
                        const c7 = extCir.circuitName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                        const c8 = search.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                        if (c7.toLowerCase() === c8.toLowerCase()) {
                          deleteIndex = i;
                          foundCircuit = extCir;
                        }
                        extCirLen--;
                        if (extCirLen === 0) {
                          this.mission.circuits[index].existingCircuits.push(this.mission.circuits[index].selectedExistingCircuit);
                          this.mission.circuits[index].selectedExistingCircuit = foundCircuit;
                          this.mission.circuits[index].ogImage = true;
                          this.mission.circuits[index].existingCircuits.splice(deleteIndex, 1);
                          this.existingCircuitsCheckpoitFiller(index);
                        }
                      });
                    }
                  }

                }).catch(() => { });
            } else {
              if (this.mission.circuits[index].circuitId !== null && this.mission.circuits[index].circuitId !== undefined) {
                // this.pedestrainAlertsService.removeCheckPointsAssociatedwithCircuit()
                //   .then(() => {
                //     this.checkpointRemover(() => {
                //       this.mission.circuits[index].ogImage = false;
                //       this.mission.circuits[index].image = null;
                //       this.mission.circuits[index].circuitId = null;
                //       this.newCircuit = true;
                //       const prevName = this.mission.circuits[index].circuitName;
                //       this.mission.circuits[index].circuitName = search;
                //       this.circuitNameDisabled = false;
                //       this.mission.circuits[index].circuitLongitude = data[0].geometry.location.lng();
                //       this.mission.circuits[index].circuitLatitude = data[0].geometry.location.lat();
                //       // this.mission.circuits[index].map.flyTo({
                //       //   center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                //       //   zoom: 9,
                //       //   bearing: 0,
                //       //   curve: 1
                //       // });
                //       if (this.mission.checkpoints.length === 0) {
                //         this.addNewCheckpoint = true;
                //         this.showAddNewCheckpoint = true;
                //         this.createCheckpoint();
                //       } else {
                //         if (prevName === undefined) {
                //           this.add2CheckpointsCircuitArray(index);
                //         } else {
                //           this.circuitUpdater(search, prevName);
                //         }
                //       }
                //     });
                //   })
                //   .catch(() => {
                //     const prevName = this.mission.circuits[index].circuitName;
                //     this.mission.circuits[index].circuitName = search;
                //     this.circuitNameDisabled = false;
                //     this.mission.circuits[index].circuitLongitude = data[0].geometry.location.lng();
                //     this.mission.circuits[index].circuitLatitude = data[0].geometry.location.lat();
                //     // this.mission.circuits[index].map.flyTo({
                //     //   center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                //     //   zoom: 9,
                //     //   bearing: 0,
                //     //   curve: 1
                //     // });
                //     if (this.mission.checkpoints.length === 0) {
                //       this.addNewCheckpoint = true;
                //       this.showAddNewCheckpoint = true;
                //       this.createCheckpoint();
                //     } else {
                //       if (prevName === undefined) {
                //         this.add2CheckpointsCircuitArray(index);
                //       } else {
                //         this.circuitUpdater(search, prevName);
                //       }
                //     }
                //   });

                const prevName = this.mission.circuits[index].circuitName;
                this.mission.circuits[index].circuitName = search;
                this.circuitNameDisabled = false;
                this.mission.circuits[index].circuitLongitude = data[0].geometry.location.lng();
                this.mission.circuits[index].circuitLatitude = data[0].geometry.location.lat();
                // this.mission.circuits[index].map.flyTo({
                //   center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                //   zoom: 9,
                //   bearing: 0,
                //   curve: 1
                // });
                if (this.mission.checkpoints.length === 0) {
                  this.addNewCheckpoint = true;
                  this.showAddNewCheckpoint = true;
                  this.createCheckpoint();
                } else {
                  if (prevName === undefined) {
                    this.add2CheckpointsCircuitArray(index);
                  } else {
                    this.circuitUpdater(search, prevName);
                  }
                }

              } else {
                const prevName = this.mission.circuits[index].circuitName;
                this.circuitNameDisabled = false;
                this.mission.circuits[index].circuitName = search;
                this.mission.circuits[index].circuitLongitude = data[0].geometry.location.lng();
                this.mission.circuits[index].circuitLatitude = data[0].geometry.location.lat();
                // this.mission.circuits[index].map.flyTo({
                //   center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                //   zoom: 9,
                //   bearing: 0,
                //   curve: 1
                // });
                if (this.mission.checkpoints.length === 0) {
                  this.addNewCheckpoint = true;
                  this.showAddNewCheckpoint = true;
                  this.createCheckpoint();
                } else {
                  if (prevName === undefined) {
                    this.add2CheckpointsCircuitArray(index);
                  } else {
                    this.circuitUpdater(search, prevName);
                  }
                }
              }
            }
          }
        } else if (element === 'checkpoint') {
          if (this.mission.checkpoints[index].checkpointId !== null && this.mission.checkpoints[index].checkpointId !== undefined) {
            this.pedestrainAlertsService.doChangeCircuit()
              .then(() => {
                this.checkpointRemover(() => {
                  this.circuitRestarter(() => {
                    this.pedestrainAlertsService.checkPontDeleteAlert();
                  });
                });
              })
              .catch(() => {
                const prevName = this.mission.checkpoints[index].checkpointName;
                this.mission.checkpoints[index].checkpointLongitude = data[0].geometry.location.lng();
                this.mission.checkpoints[index].checkpointLatitude = data[0].geometry.location.lat();
                this.mission.checkpoints[index].checkpointAddress = data[0].formatted_address;
                this.mission.checkpoints[index].checkpointName = search;
                // this.mission.checkpoints[index].map.flyTo({
                //   center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                //   zoom: 9,
                //   bearing: 0,
                //   curve: 1
                // });
                this.updateDatabase('index', index, search);
                if (this.mission.assignments.length === 0) {
                  this.addNewCheckpoint = true;
                  this.showAddNewCheckpoint = true;
                  this.assignmentFiller('noAssignment', () => { });
                } else {
                  this.assignmentUpdater(index, prevName);
                }
              });
          } else {
            const prevName = this.mission.checkpoints[index].checkpointName;
            this.mission.checkpoints[index].checkpointLongitude = data[0].geometry.location.lng();
            this.mission.checkpoints[index].checkpointLatitude = data[0].geometry.location.lat();
            this.mission.checkpoints[index].checkpointAddress = data[0].formatted_address;
            this.mission.checkpoints[index].checkpointName = search;
            // this.mission.checkpoints[index].map.flyTo({
            //   center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
            //   zoom: 9,
            //   bearing: 0,
            //   curve: 1
            // });
            this.updateDatabase('index', index, search);
            if (this.mission.assignments.length === 0) {
              if (this.mission.checkpoints.length < 3) {
                this.addNewCheckpoint = true;
                this.showAddNewCheckpoint = true;
                this.assignmentFiller('noAssignment', () => { });
              } else {
                this.assignmentFiller('noAssignment', () => { });
              }
            } else {
              this.assignmentUpdater(index, prevName);
            }
          }
        }
      } else {
        this.pedestrainAlertsService.googleDailylimitAlert();
      }
    }, error => {

    });
  }

  reverseGeocoder(name, i, signal) {
    const api = new google.maps.Geocoder;
    if (signal === 'circuit') {
      api.geocode({ latLng: { lat: this.mission.circuits[i].circuitLatitude, lng: this.mission.circuits[i].circuitLongitude } },
        data => {
          // this._http.get('https://maps.googleapis.com/maps/api/geocode/json?latlng=' +
          //   this.mission.circuits[i].circuitLatitude + ',' +
          //   this.mission.circuits[i].circuitLongitude).subscribe((data: any) => {
          if (data.length !== 0) {
            this.mission.circuits[i].circuitName = data[0].formatted_address;
            this.changeCircuitName(data[0].formatted_address, this.mission.circuits[i].circuitId);
          }
        }, err => {
          this.reverseGeocoder(name, i, signal);
        });
    } else if (signal === 'checkpoint') {
      this.changeCheckpointName(this.mission.checkpoints[i].data.checkpointName, this.mission.checkpoints[i].checkpointId, i);
    }
  }

  refreshGeoJSON(cb) {
    this.mission.assignments.forEach(assignment => {
      assignment.geojson.features = [];

      this.mission.checkpoints.forEach(checkpoint => {
        const feature = {
          type: 'Feature',
          properties: {
            message: 'Foo',
            iconSize: [60, 60]
          },
          geometry: {
            type: 'Point',
            coordinates: [checkpoint.checkpointLongitude, checkpoint.checkpointLatitude]
          }
        };
        assignment.geojson.features.push(feature);
      });
    });
  }

  getDataFromDatabase(signal) {

  }

  /* Togglers
    1. toggleCountry(country, i)
    2. toggleRegion(region, i)
    3. toggleCommune(commune, i)
    4. togglePostalCode(postalCode, i)
    5. toggleStreet(street, i)
    6. toggleAdrn(adrn, i)
    7. toggleFieldAgent(fieldAgent, i)
    8. toggleShift(shift, i)
    9. toggleCheckpoint(checkpoint, i)
    10. existingDropdownToggled(value, i)
    11. toggleCheckBox(i, e)
    12. toggleDontknowAdptIdCheckbox(i)
    13. toggleExistingCircuit(circuit, circuitIndex, event)
  */
 instanceForCampaign(d1) {
  this.datepickers.push(d1);
}

  toggleExistingCircuit(circuit, circuitIndex, event) {
    this.enableDropsown=false;
    this.hideImage=false;
    let flag;
    this.mission.circuits[circuitIndex].existingCircuits.forEach((ad, index) => {
      if (ad.circuitName === 'Select') {
        this.mission.circuits[circuitIndex].existingCircuits.splice(index, 1);        
      }
    });
    this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitName==this.translate.instant('Select')?false:this.mission.circuits[circuitIndex].existingCircuits.push(this.mission.circuits[circuitIndex].selectedExistingCircuit);
    this.mission.circuits[circuitIndex].selectedExistingCircuit = circuit;
    this.taged = circuit.circuitCheckpoints.map(res => res.checkpointName);
    let deleteIndex;
    let eclen = this.mission.circuits[circuitIndex].existingCircuits.length;
    this.mission.circuits[circuitIndex].existingCircuits.forEach((ec, delI) => {
      if (ec.circuitId === circuit.circuitId) {
        deleteIndex = delI;
      }
      eclen--;
      if (eclen === 0) {
        this.mission.circuits[circuitIndex].existingCircuits.splice(deleteIndex, 1);
        this.mission.circuits[circuitIndex].checkpointsGeoJson.features = [];
        let checkLens = this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints.length;
        this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints.forEach(extCheck => {
          const feature = {
            'type': 'Feature',
            'geometry': { 'type': 'Point', 'coordinates': [extCheck.checkpointLongitude, extCheck.checkpointLatitude] },
            'lnglat': [extCheck.checkpointLongitude, extCheck.checkpointLatitude],
            'checkpointName': extCheck.checkpointName,
          };
          this.mission.circuits[circuitIndex].checkpointsGeoJson['features'].push(feature);
          checkLens--;
          if (checkLens === 0) {
            this.mission.circuits[circuitIndex].ogImage = true;
            let ogMission: any = this.ogMission;
            if (ogMission.missionMarketZoneList != null && this.market) {
              if (ogMission.missionMarketZoneList.length > 0) {
                const feature = {
                  'type': 'Feature',
                  'geometry': { 'type': 'Point', 'coordinates': [ogMission.missionMarketZoneList[0].longitude, ogMission.missionMarketZoneList[0].latitude] },
                  'lnglat': [ogMission.missionMarketZoneList[0].longitude, ogMission.missionMarketZoneList[0].latitude],
                  'checkpointName': ogMission.missionMarketZoneList[0].officialName,
                  'marketSelected': true
                };
                this.mission.circuits[0].checkpointsGeoJson['features'].push(feature);
              }
            } else {
              if (this.market) {
                const feature = {
                  'type': 'Feature',
                  'geometry': { 'type': 'Point', 'coordinates': [this.selectedMarketObject.longitude, this.selectedMarketObject.latitude] },
                  'lnglat': [this.selectedMarketObject.longitude, this.selectedMarketObject.latitude],
                  'checkpointName': this.selectedMarketObject.officialName,
                  'marketSelected': true
                };
                this.mission.circuits[0].checkpointsGeoJson['features'].push(feature);
              }
            }
            
            this.populateExistingCheckpoints();
            // this.mission.circuits[circuitIndex].map.flyTo({
            //   center: [this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints[0].checkpointLongitude,
            //   this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints[0].checkpointLatitude],
            //   zoom: 9,
            //   bearing: 0,
            //   curve: 1
            // });
          }
        });
      }
    });
  }

  toggleDontknowAdptIdCheckbox(i) {
    this.mission.checkpoints[i].countryLoaded = false;
    this.mission.checkpoints[i].regionLoaded = false;
    this.mission.checkpoints[i].communeLoaded = false;
    this.mission.checkpoints[i].postalCodeLoaded = false;
    this.mission.checkpoints[i].streetLoaded = false;
    this.mission.checkpoints[i].adrnLoaded = false;
    this.mission.checkpoints[i].adptid_valid = false;
    this.mission.checkpoints[i].data.adptid = null;
    this.mission.checkpoints[i].data.quartier = undefined;
    if (!this.mission.checkpoints[i].dontKnowAdptId) {
      this.fillPullApiFields(i, () => {

      });
    } else {
      if (this.checkpointMapGeoJSON.features.length < i) {
        this.checkpointMapGeoJSON.features.push({
          'type': 'Feature',
          'geometry': {
            'type': 'Point',
            'coordinates': [
              this.mission.checkpoints[i].selectedCircuit.circuitLongitude,
              this.mission.checkpoints[i].selectedCircuit.circuitLatitude
            ]
          },
          'lnglat': [
            parseFloat(Number(this.mission.checkpoints[i].selectedCircuit.circuitLongitude).toFixed(20)),
            parseFloat(Number(this.mission.checkpoints[i].selectedCircuit.circuitLatitude).toFixed(20))
          ]
        });
      } else {
        if(this.market){
          if (i==3){
            this.checkpointMapGeoJSON.features.splice((i - 1), 1);
          } else{
            this.checkpointMapGeoJSON.features.splice((i+1),1);
          }
        } else{
          if (this.checkpointMapGeoJSON.features.length==0){
            this.checkpointMapGeoJSON.features = [];
          } else{
            this.checkpointMapGeoJSON.features.splice(i,1);
          }
          // this.checkpointMapGeoJSON.features[i] = {
          //   'type': 'Feature',
          //   'geometry': {
          //     'type': 'Point',
          //     'coordinates': [
          //       this.mission.checkpoints[i].selectedCircuit.circuitLongitude,
          //       this.mission.checkpoints[i].selectedCircuit.circuitLatitude
          //     ]
          //   },
          //   'lnglat': [
          //     parseFloat(Number(this.mission.checkpoints[i].selectedCircuit.circuitLongitude).toFixed(20)),
          //     parseFloat(Number(this.mission.checkpoints[i].selectedCircuit.circuitLatitude).toFixed(20))
          //   ]
          // };
        }
      }
      console.log(this.checkpointMapGeoJSON);
    }
  }

  toggleCountry(country, i) {
    if (i === 0 && this.mission.checkpoints.length > 1) {
      this.pedestrainAlertsService.removeOtherCheckpoints()
        .then(() => {
          this.mission.checkpoints.splice(i + 1);
          this.checkpointMapGeoJSON.features.splice(i + 1);
          this.mission.checkpoints[i].countries.push(this.mission.checkpoints[i].selected_country);
          this.mission.checkpoints[i].regionLoaded = false;
          this.mission.checkpoints[i].communeLoaded = false;
          this.mission.checkpoints[i].postalCodeLoaded = false;
          this.mission.checkpoints[i].streetLoaded = false;
          this.mission.checkpoints[i].adrnLoaded = false;
          this.mission.checkpoints[i].adrnLoaded = false;
          this.mission.checkpoints[i].selected_country = country;
          let deleteIndex = -1;
          let countryLen = this.mission.checkpoints[i].countries.length;
          this.mission.checkpoints[i].countries.forEach((con, index) => {
            if (con.con_id === country.con_id) {
              deleteIndex = index;
            }
            countryLen--;
            if (countryLen === 0) {
              this.mission.checkpoints[i].countries.splice(deleteIndex, 1);
              this.getRegions(i, () => {
                this.getCommunes(i, () => {
                  this.getPostalCodes(i, () => {
                    this.getStreets(i, () => {
                      this.getAdrns(i, () => {
                        this.getAdptId(i, () => {
                        });
                      });
                    });
                  });
                });
              });
            }
          });
        })
        .catch(() => {

        });
    } else {
      this.mission.checkpoints[i].countries.push(this.mission.checkpoints[i].selected_country);
      this.mission.checkpoints[i].regionLoaded = false;
      this.mission.checkpoints[i].communeLoaded = false;
      this.mission.checkpoints[i].postalCodeLoaded = false;
      this.mission.checkpoints[i].streetLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].selected_country = country;
      let deleteIndex = -1;
      let countryLen = this.mission.checkpoints[i].countries.length;
      this.mission.checkpoints[i].countries.forEach((con, index) => {
        if (con.con_id === country.con_id) {
          deleteIndex = index;
        }
        countryLen--;
        if (countryLen === 0) {
          this.mission.checkpoints[i].countries.splice(deleteIndex, 1);
          this.getRegions(i, () => {
            this.getCommunes(i, () => {
              this.getPostalCodes(i, () => {
                this.getStreets(i, () => {
                  this.getAdrns(i, () => {
                    this.getAdptId(i, () => {
                    });
                  });
                });
              });
            });
          });
        }
      });
    }
  }

  toggleRegion(region, i) {
    if (i === 0 && this.mission.checkpoints.length > 1) {
      this.pedestrainAlertsService.removeOtherCheckpoints()
        .then(() => {
          this.mission.checkpoints.splice(i + 1);
          this.checkpointMapGeoJSON.features.splice(i + 1);
          this.mission.checkpoints[i].communeLoaded = false;
          this.mission.checkpoints[i].postalCodeLoaded = false;
          this.mission.checkpoints[i].streetLoaded = false;
          this.mission.checkpoints[i].adrnLoaded = false;
          this.mission.checkpoints[i].adrnLoaded = false;
          this.mission.checkpoints[i].regions.push(this.mission.checkpoints[i].selected_region);
          this.mission.checkpoints[i].selected_region = region;
          let deleteIndex = -1;
          let regionLen = this.mission.checkpoints[i].regions.length;
          this.mission.checkpoints[i].regions.forEach((reg, index) => {
            if (reg.reg_id === region.reg_id) {
              deleteIndex = index;
            }
            regionLen--;
            if (regionLen === 0) {
              this.mission.checkpoints[i].regions.splice(deleteIndex, 1);
              this.getCommunes(i, () => {
                this.getPostalCodes(i, () => {
                  this.getStreets(i, () => {
                    this.getAdrns(i, () => {
                      this.getAdptId(i, () => {
                      });
                    });
                  });
                });
              });

            }
          });
        })
        .catch(() => { });
    } else {
      this.mission.checkpoints[i].communeLoaded = false;
      this.mission.checkpoints[i].postalCodeLoaded = false;
      this.mission.checkpoints[i].streetLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].regions.push(this.mission.checkpoints[i].selected_region);
      this.mission.checkpoints[i].selected_region = region;
      let deleteIndex = -1;
      let regionLen = this.mission.checkpoints[i].regions.length;
      this.mission.checkpoints[i].regions.forEach((reg, index) => {
        if (reg.reg_id === region.reg_id) {
          deleteIndex = index;
        }
        regionLen--;
        if (regionLen === 0) {
          this.mission.checkpoints[i].regions.splice(deleteIndex, 1);
          this.getCommunes(i, () => {
            this.getPostalCodes(i, () => {
              this.getStreets(i, () => {
                this.getAdrns(i, () => {
                  this.getAdptId(i, () => {
                  });
                });
              });
            });
          });

        }
      })
    }

  }

  toggleCommune(commune, i) {

    if (i === 0 && this.mission.checkpoints.length > 1) {
      this.pedestrainAlertsService.removeOtherCheckpoints()
        .then(() => {
          this.mission.checkpoints.splice(i + 1);
          this.checkpointMapGeoJSON.features.splice(i + 1);
          this.mission.checkpoints[i].postalCodeLoaded = false;
          this.mission.checkpoints[i].streetLoaded = false;
          this.mission.checkpoints[i].adrnLoaded = false;
          this.mission.checkpoints[i].adrnLoaded = false;
          this.mission.checkpoints[i].communes.push(this.mission.checkpoints[i].selected_commune);
          this.mission.checkpoints[i].selected_commune = commune;
          let deleteIndex = -1;
          let communeLen = this.mission.checkpoints[i].communes.length;
          this.mission.checkpoints[i].communes.forEach((com, index) => {
            if (com.com_id === commune.com_id) {
              deleteIndex = index;
            }
            communeLen--;
            if (communeLen === 0) {
              this.mission.checkpoints[i].communes.splice(deleteIndex, 1);

              this.getPostalCodes(i, () => {
                this.getStreets(i, () => {
                  this.getAdrns(i, () => {
                    this.getAdptId(i, () => {
                    });
                  });
                });
              });

            }
          });
        }).catch(() => { });
    } else {
      this.mission.checkpoints[i].postalCodeLoaded = false;
      this.mission.checkpoints[i].streetLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].communes.push(this.mission.checkpoints[i].selected_commune);
      this.mission.checkpoints[i].selected_commune = commune;
      let deleteIndex = -1;
      let communeLen = this.mission.checkpoints[i].communes.length;
      this.mission.checkpoints[i].communes.forEach((com, index) => {
        if (com.com_id === commune.com_id) {
          deleteIndex = index;
        }
        communeLen--;
        if (communeLen === 0) {
          this.mission.checkpoints[i].communes.splice(deleteIndex, 1);

          this.getPostalCodes(i, () => {
            this.getStreets(i, () => {
              this.getAdrns(i, () => {
                this.getAdptId(i, () => {
                });
              });
            });
          });

        }
      });
    }
  }

  togglePostalCode(postalCode, i) {

    if (i === 0 && this.mission.checkpoints.length > 1) {
      this.pedestrainAlertsService.removeOtherCheckpoints()
        .then(() => {
          this.mission.checkpoints.splice(i + 1);
          this.checkpointMapGeoJSON.features.splice(i + 1);
          this.mission.checkpoints[i].streetLoaded = false;
          this.mission.checkpoints[i].adrnLoaded = false;
          this.mission.checkpoints[i].adrnLoaded = false;
          this.mission.checkpoints[i].postalcodes.push(this.mission.checkpoints[i].selected_postalcode);
          this.mission.checkpoints[i].selected_postalcode = postalCode;
          let deleteIndex = -1;
          let postalCodeLen = this.mission.checkpoints[i].postalcodes.length;
          this.mission.checkpoints[i].postalcodes.forEach((pos, index) => {
            if (pos.adt_postal_code === postalCode.adt_postal_code) {
              deleteIndex = index;
            }
            postalCodeLen--;
            if (postalCodeLen === 0) {
              this.mission.checkpoints[i].postalcodes.splice(deleteIndex, 1);

              this.getStreets(i, () => {
                this.getAdrns(i, () => {
                  this.getAdptId(i, () => {
                  });
                });
              });

            }
          });
        })
        .catch(() => { });
    } else {
      this.mission.checkpoints[i].streetLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].postalcodes.push(this.mission.checkpoints[i].selected_postalcode);
      this.mission.checkpoints[i].selected_postalcode = postalCode;
      let deleteIndex = -1;
      let postalCodeLen = this.mission.checkpoints[i].postalcodes.length;
      this.mission.checkpoints[i].postalcodes.forEach((pos, index) => {
        if (pos.adt_postal_code === postalCode.adt_postal_code) {
          deleteIndex = index;
        }
        postalCodeLen--;
        if (postalCodeLen === 0) {
          this.mission.checkpoints[i].postalcodes.splice(deleteIndex, 1);

          this.getStreets(i, () => {
            this.getAdrns(i, () => {
              this.getAdptId(i, () => {
              });
            });
          });

        }
      });
    }
  }

  toggleStreet(street, i) {
    this.mission.checkpoints[i].adrnLoaded = false;
    this.mission.checkpoints[i].adrnLoaded = false;
    this.mission.checkpoints[i].streets.push(this.mission.checkpoints[i].selected_street);
    this.mission.checkpoints[i].selected_street = street;
    let deleteIndex = -1;
    let streetLen = this.mission.checkpoints[i].streets.length;
    this.mission.checkpoints[i].streets.forEach((str, index) => {
      if (str.adt_street === street.adt_street) {
        deleteIndex = index;
      }
      streetLen--;
      if (streetLen === 0) {
        this.mission.checkpoints[i].streets.splice(deleteIndex, 1);
        this.getAdrns(i, () => {
          this.getAdptId(i, () => {
          });
        });
      }
    });
  }

  toggleAdrn(adrn, i) {
    this.mission.checkpoints[i].adrns.push(this.mission.checkpoints[i].selected_adrn);
    this.mission.checkpoints[i].selected_adrn = adrn;
    let deleteIndex = -1;
    let adrnLen = this.mission.checkpoints[i].adrns.length;
    this.mission.checkpoints[i].adrns.forEach((ad, index) => {
      if (ad.adt_adrn === adrn.adt_adrn) {
        deleteIndex = index;
      }
      adrnLen--;
      if (adrnLen === 0) {
        this.mission.checkpoints[i].adrns.splice(deleteIndex, 1);
        this.getAdptId(i, () => {
        });
      }
    });
  }

  toggleFieldAgent(fieldAgent, i) {
    this.selectedFieldAgent = fieldAgent;
    // let assLen = this.mission.assignments.length;
    // const fieldAgentIndexFinder = (agent) => {
    //   return agent.userId === fieldAgent.userId;
    // };
    // const deleteIndexArray = [];
    // this.mission.assignments.forEach((assignment, ind) => {
    //   assignment.fieldAgents.push(this.mission.assignments[i].selectedFieldAgent);
    //   if (ind !== i) {
    //     deleteIndexArray.push(assignment.fieldAgents.findIndex(fieldAgentIndexFinder));
    //   }
    //   assLen--;
    //   if (assLen === 0) {
    //     let deleteIndexArrayLen = deleteIndexArray.length;
    //     deleteIndexArray.forEach(index => {
    //       this.mission.assignments.forEach((assign, assI) => {
    //         if (assI !== i) {
    //           assign.fieldAgents.splice(index, 1);
    //         }
    //       });
    //       deleteIndexArrayLen--;
    //       if (deleteIndexArrayLen === 0) {
    //         const removeIndex = this.mission.assignments[i].fieldAgents.findIndex(fieldAgentIndexFinder);
    //         this.mission.assignments[i].fieldAgents.splice(removeIndex, 1);
    //         this.mission.assignments[i].selectedFieldAgent = fieldAgent;
    //       }
    //     });
    //   }
    // });
  }

  toggleShift(shift, i) {
    this.mission.assignments[i].shifts.push(this.mission.assignments[i].selectedShift);
    this.mission.assignments[i].selectedShift = shift;
    let len = this.mission.assignments[i].shifts.length;
    let deleteIndex = -1;
    this.mission.assignments[i].shifts.forEach((s, ind) => {
      if (shift === s) {
        deleteIndex = ind;
      }
      len--;
      if (len === 0) {
        this.mission.assignments[i].shifts.splice(deleteIndex, 1);
      }
    });
  }

  toggleCheckpoint(checkpoint, i) {
    let deleteIndex = -1;
    let checklen = this.mission.assignments[i].checkpoints.length;
    this.mission.assignments[i].checkpoints.forEach((check, ci) => {
      if (check.chechpointId === checkpoint.checkpointId) {
        deleteIndex = ci;
      }
      checklen--;
      if (checklen === 0) {
        this.mission.assignments[i].checkpoints.push(this.mission.assignments[i].selectedCheckpoint);
        this.mission.assignments[i].selectedCheckpoint = checkpoint;
        this.mission.assignments[i].checkpoints.splice(deleteIndex, 1);
      }
    });
  }

  existingDropdownToggled(value, i) {
    if (!value) {
      this.mission.circuits[i].existingCircuits = Object.assign([], this.mission.circuits[i].tempExistingCircuits).filter(item => {
        if (this.mission.circuits[i].selectedExistingCircuit.circuitName !== item.circuitName) {
          return item;
        }
      });
    }
  }

  toggleCheckBox(i, e) {
    if (e.target.checked !== this.mission.circuits[i].existingCircuitsCheck) {
      this.mission.circuits[i].existingCircuitsCheck = e.target.checked;
      this.isCheckedExisting = false;
      this.mission.circuits[0].selectedExistingCircuit.circuitName =this.translate.instant('Select');
    }
    if (this.mission.circuits[i].existingCircuitsCheck && this.mission.checkpoints.length !== 0) {
      this.hideImage=false;
      this.pedestrainAlertsService.inCaseChangesDeleted()
        .then(() => {
          this.mission.circuits[i].ogImage = true;
          this.mission.circuits[i].existingCircuitsCheck = true;
          this.checkpointsFound = false;
          this.circuitPresent = false;
          this.mission.checkpoints = [];
          this.mission.assignments = [];
          this.existingCircuitsCheckpoitFiller(i);
        })
        .catch(() => {
          this.mission.circuits[i].existingCircuitsCheck = false;
          this.mission.circuits[i].ogImage = true;
        });
    } else if (this.mission.circuits[i].existingCircuitsCheck && this.mission.checkpoints.length === 0) {
      this.hideImage=true;
      this.mission.circuits[i].ogImage = true;
      this.mission.circuits[i].existingCircuitsCheck = true;
      if (this.mission.circuits[0].circuitCheckpoints){
        if (this.mission.circuits[0].circuitCheckpoints.length==0){
          this.mission.circuits[i].circuitName = this.noCheckpointCircuits.filter(res => res.circuitId == this.mission.circuits[0].circuitId)[0].circuitName;
        }else{
          this.mission.circuits[i].circuitName = this.mission.circuits[0].tempExistingCircuits.filter(res => res.circuitId == this.mission.circuits[0].circuitId)[0].circuitName;
          this.mission.circuits[0].selectedExistingCircuit.circuitName =this.translate.instant('Select');
        }
      }
      this.fillEditMissionFlag = true;
      this.checkpointMapGeoJSON.features = [];
      this.existingCircuitsCheckpoitFiller1(i);
    } else {
      this.hideImage=false;
      this.mission.circuits[i].ogImage = false;
      this.circuitNameDisabled = true;
      this.mission.circuits[i].existingCircuitsCheck = false;
      this.checkpointsFound = false;
      this.circuitPresent = false;
      this.mission.checkpoints = [];
      this.taged = [];
      this.mission.assignments = [];
      this.mission.circuits[i].circuitName = '';

      this.mission.assignments.forEach(assignment => {
        assignment.geojson.features = [];
      });

      if (this.mission.circuits[i].existingCircuitsCheck == false && this.market){
        let list = this.checkpointMapGeoJSON.features.filter(res=> res.marketSelected ==true);
        this.checkpointMapGeoJSON.features = list;
       }else {
        this.checkpointMapGeoJSON.features = [];
      }

      this.existingCircuitsCheck = false;

      // this.mission.circuits[i].map.flyTo({
      //   center: [this.mission.circuits[i].circuitLongitude, this.mission.circuits[i].circuitLatitude],
      //   zoom: 9,
      //   bearing: 0,
      //   curve: 1
      // });
      // setTimeout(() => {
      // }, 200);
      
    }
  }
  
  existingCircuitsCheckpoitFiller1(i) {
    this.mission.circuits[i].checkpointsGeoJson.features = [];
    let checkLens = this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.length;
    this.mission.circuits[0].selectedExistingCircuit.circuitName =this.translate.instant('Select');
    if (this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.length !== 0) {
      this.mission.circuits[i].existingCircuitsCheck = true;
      this.existingCircuitsCheck = true;
    }

    if (this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.length > 0){
      this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.forEach(extCheck => {
        const feature = {
          'type': 'Feature',
          'geometry': { 'type': 'Point', 'coordinates': [extCheck.checkpointLongitude, extCheck.checkpointLatitude] },
          'lnglat': [extCheck.checkpointLongitude, extCheck.checkpointLatitude],
          'checkpointName': extCheck.checkpointName
        };
        // this.mission.circuits[i].checkpointsGeoJson['features'].push(feature);
        // this.checkpointMapGeoJSON.features.push(feature);
        checkLens--;
        if (checkLens === 0) {
          let ogMission:any = this.ogMission;
          if (ogMission.missionMarketZoneList !=null && this.market){
            if (ogMission.missionMarketZoneList.length > 0) {
              const feature = {
                'type': 'Feature',
                'geometry': { 'type': 'Point', 'coordinates': [ogMission.missionMarketZoneList[0].longitude, ogMission.missionMarketZoneList[0].latitude] },
                'lnglat': [ogMission.missionMarketZoneList[0].longitude, ogMission.missionMarketZoneList[0].latitude],
                'checkpointName': ogMission.missionMarketZoneList[0].officialName,
                'marketSelected': true
              };
              // this.mission.circuits[0].checkpointsGeoJson['features'].push(feature);
              // this.checkpointMapGeoJSON.features.push(feature);
            }
          } else {
            if (this.market) {
              const feature = {
                'type': 'Feature',
                'geometry': { 'type': 'Point', 'coordinates': [this.selectedMarketObject.longitude, this.selectedMarketObject.latitude] },
                'lnglat': [this.selectedMarketObject.longitude, this.selectedMarketObject.latitude],
                'checkpointName': this.selectedMarketObject.officialName,
                'marketSelected': true
              };
              // this.mission.circuits[0].checkpointsGeoJson['features'].push(feature);
            }
          }
          // this.populateExistingCheckpoints();
          // this.mission.circuits[i].existingCircuitsCheck = true;
          // this.existingCircuitsCheck = true;
          // console.log(this.mission.circuits);
          // this.mission.circuits[i].map.flyTo({
          //   center: [this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints[0].checkpointLongitude,
          //   this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints[0].checkpointLatitude],
          //   zoom: 9,
          //   bearing: 0,
          //   curve: 1
          // });
          // setTimeout(() => {
          // }, 200);
  
        }
      });
    } else{
      const feature = {
        'type': 'Feature',
        'geometry': { 'type': 'Point', 'coordinates': [this.mission.circuits[0].circuitLongitude, this.mission.circuits[0].circuitLatitude] },
        'lnglat': [this.mission.circuits[0].circuitLongitude, this.mission.circuits[0].circuitLatitude],
        'checkpointName': this.mission.circuits[0].circuitName
      };
      // this.mission.circuits[0].checkpointsGeoJson['features'].push(feature);
    }
    this.enableDropsown=true;
  }

  /* Creators
   1. circuitCreator()
   2. createCheckpoint()
   3. assignmentInitializer(cb)
   4. processUserCheckpoints(uc, fa, assignment, cb)
   5. processFieldAgentsArray(uc, fa, assignment, cb)
   6. missionFieldAgentsArrayUpdater(cb)
   7. assignmentFiller(signal, cb)
   8. databaseRefresh(indexArr?)
   9. assignmentUpdater(ind, prevName)
 */

  circuitCreator() {
    const circuit = {
      circuitName: undefined,
      circuitLongitude: 4.4699,
      circuitLatitude: 50.5039,
      ogImage: false,
      existingCircuitsCheck: false,
      existingCircuits: [],
      tempExistingCircuits: [],
      existingCircuitSearch: undefined,
      selectedExistingCircuit: {},
      checkpointsGeoJson: {
        'type': 'FeatureCollection',
        'features': []
      }
    };
    this.existingCircuitsFiller(circuit, cir => {
      this.mission.circuits.push(cir);
    });
  }

  existingCircuitsCheckpoitFiller(i) {
    this.mission.circuits[i].checkpointsGeoJson.features = [];
    let checkLens = this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.length;
    // this.mission.circuits[0].selectedExistingCircuit.circuitName =this.translate.instant('Select');
    if (this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.length !== 0) {
      this.mission.circuits[i].existingCircuitsCheck = true;
      this.existingCircuitsCheck = true;
    }

    if (this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.length > 0){
      this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.forEach(extCheck => {
        const feature = {
          'type': 'Feature',
          'geometry': { 'type': 'Point', 'coordinates': [extCheck.checkpointLongitude, extCheck.checkpointLatitude] },
          'lnglat': [extCheck.checkpointLongitude, extCheck.checkpointLatitude],
          'checkpointName': extCheck.checkpointName
        };
        this.mission.circuits[i].checkpointsGeoJson['features'].push(feature);
        this.checkpointMapGeoJSON.features.push(feature);
        checkLens--;
        if (checkLens === 0) {
          let ogMission:any = this.ogMission;
          if (ogMission.missionMarketZoneList !=null && this.market){
            if (ogMission.missionMarketZoneList.length > 0) {
              const feature = {
                'type': 'Feature',
                'geometry': { 'type': 'Point', 'coordinates': [ogMission.missionMarketZoneList[0].longitude, ogMission.missionMarketZoneList[0].latitude] },
                'lnglat': [ogMission.missionMarketZoneList[0].longitude, ogMission.missionMarketZoneList[0].latitude],
                'checkpointName': ogMission.missionMarketZoneList[0].officialName,
                'marketSelected': true
              };
              this.mission.circuits[0].checkpointsGeoJson['features'].push(feature);
              this.checkpointMapGeoJSON.features.push(feature);
            }
          } else {
            if (this.market) {
              const feature = {
                'type': 'Feature',
                'geometry': { 'type': 'Point', 'coordinates': [this.selectedMarketObject.longitude, this.selectedMarketObject.latitude] },
                'lnglat': [this.selectedMarketObject.longitude, this.selectedMarketObject.latitude],
                'checkpointName': this.selectedMarketObject.officialName,
                'marketSelected': true
              };
              this.mission.circuits[0].checkpointsGeoJson['features'].push(feature);
            }
          }
          this.populateExistingCheckpoints();
          this.mission.circuits[i].existingCircuitsCheck = true;
          this.existingCircuitsCheck = true;
          console.log(this.mission.circuits);
          this.mission.circuits[i].map.flyTo({
            center: [this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints[0].checkpointLongitude,
            this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints[0].checkpointLatitude],
            zoom: 9,
            bearing: 0,
            curve: 1
          });
          setTimeout(() => {
          }, 200);
  
        }
      });
    } else{
      const feature = {
        'type': 'Feature',
        'geometry': { 'type': 'Point', 'coordinates': [this.mission.circuits[0].circuitLongitude, this.mission.circuits[0].circuitLatitude] },
        'lnglat': [this.mission.circuits[0].circuitLongitude, this.mission.circuits[0].circuitLatitude],
        'checkpointName': this.mission.circuits[0].circuitName
      };
      this.mission.circuits[0].checkpointsGeoJson['features'].push(feature);
    }
    // this.enableDropsown=true;
  }


  createCheckpoint() {
    if (!this.showAddNewCircuit) {
      if (this.mission.checkpoints.length === 0 && this.addNewCheckpoint) {
        const checkpoint = {
          streetSearchBucket: [],
          selectedCircuit: this.mission.circuits[0],
          circuits: [],
          checkpointName: undefined,
          checkpointAddress: undefined,
          checkpointDescription: undefined,
          checkpointLongitude: this.mission.circuits[0].circuitLongitude,
          checkpointLatitude: this.mission.circuits[0].circuitLatitude,
          selected_adrn: {
            adt_adrn: ''
          },
          adrns: [],
          selected_street: {
            adt_street: ''
          },
          streets: [],
          selected_postalcode: {
            adt_postal_code: ''
          },
          postalcodes: [],
          selected_commune: {
            com_commune_name_fr: ''
          },
          communes: [],
          selected_region: {
            reg_region_name_fr: ''
          },
          regions: [],
          selected_country: {
            con_country_name_fr: ''
          },
          coutries: [],
          adptid_valid: true,
          dontKnowAdptId: true,
          countryLoaded: false,
          regionLoaded: false,
          communeLoaded: false,
          postalCodeLoaded: false,
          streetLoaded: false,
          adrnLoaded: false,
          data: {
            address: '',
            description: '',
            checkpointNameDisabled: false,
            adptid: null,
            quartier: undefined,
            lnglat: []
          }
        };
        this.mission.checkpoints.push(checkpoint);
        const databaseObj: CheckpointDaoInterface = {
          index: this.mission.checkpoints.length - 1
        };
        this.database.push(databaseObj);
        this.fillPullApiFields(this.mission.checkpoints.length - 1, () => {

        });
      } else {
        const checkpoint = {
          streetSearchBucket: [],
          selectedCircuit: this.mission.circuits[0],
          circuits: [],
          checkpointName: undefined,
          checkpointAddress: undefined,
          checkpointDescription: undefined,
          checkpointLongitude: this.mission.circuits[0].circuitLongitude,
          checkpointLatitude: this.mission.circuits[0].circuitLatitude,
          selected_adrn: {
            adt_adrn: ''
          },
          adrns: [],
          selected_street: {
            adt_street: ''
          },
          streets: [],
          selected_postalcode: {
            adt_postal_code: ''
          },
          postalcodes: [],
          selected_commune: {
            com_commune_name_fr: ''
          },
          communes: [],
          selected_region: {
            reg_region_name_fr: ''
          },
          regions: [],
          selected_country: {
            con_country_name_fr: ''
          },
          coutries: [],
          adptid_valid: true,
          dontKnowAdptId: true,
          countryLoaded: false,
          regionLoaded: false,
          communeLoaded: false,
          postalCodeLoaded: false,
          streetLoaded: false,
          adrnLoaded: false,
          data: {
            address: '',
            description: '',
            checkpointNameDisabled: false,
            adptid: null,
            quartier: undefined,
            lnglat: []
          }
        };
        this.mission.checkpoints.push(checkpoint);

        this.fillPullApiFields(this.mission.checkpoints.length - 1, () => {

        });
        const checkpointDaoFinder = (dao) => {
          return dao.index === -1;
        };

        const daoIndex = this.database.findIndex(checkpointDaoFinder);
        if (daoIndex !== -1) {
          this.database[daoIndex].index = this.mission.checkpoints.length - 1;
        } else {
          const databaseObj: CheckpointDaoInterface = {
            index: this.mission.checkpoints.length - 1
          };
          this.database.push(databaseObj);
        }
        const indexCheckerArray = [];
        let databaseLength = this.database.length;
        this.database.forEach((dao, dIndex) => {
          if (dao.index === this.mission.checkpoints.length - 1) {
            indexCheckerArray.push(dIndex);
          }
          databaseLength--;
          if (databaseLength === 0) {
            if (indexCheckerArray.length > 1) {
              this.databaseRefresh(indexCheckerArray);
            }
          }
        });
        if (this.mission.checkpoints.length === 3) {
          this.showAddNewCheckpoint = false;
          this.taged = [];
          const obj = this.mission.checkpoints.filter(res => res.checkpointName);
          obj.forEach(itm => this.taged.push(itm.checkpointName));
        }
      }
    } else {
      if (this.mission.checkpoints.length === 0 && this.addNewCheckpoint) {
        const checkpoint = {
          streetSearchBucket: [],
          selectedCircuit: this.mission.circuits[0],
          circuits: [],
          checkpointName: undefined,
          checkpointAddress: undefined,
          checkpointDescription: undefined,
          checkpointLongitude: this.mission.circuits[0].circuitLongitude,
          checkpointLatitude: this.mission.circuits[0].circuitLatitude,
          selected_adrn: {
            adt_adrn: ''
          },
          adrns: [],
          selected_street: {
            adt_street: ''
          },
          streets: [],
          selected_postalcode: {
            adt_postal_code: ''
          },
          postalcodes: [],
          selected_commune: {
            com_commune_name_fr: ''
          },
          communes: [],
          selected_region: {
            reg_region_name_fr: ''
          },
          regions: [],
          selected_country: {
            con_country_name_fr: ''
          },
          coutries: [],
          adptid_valid: true,
          dontKnowAdptId: true,
          countryLoaded: false,
          regionLoaded: false,
          communeLoaded: false,
          postalCodeLoaded: false,
          streetLoaded: false,
          adrnLoaded: false,
          data: {
            address: '',
            description: '',
            checkpointNameDisabled: false,
            adptid: null,
            quartier: undefined,
            lnglat: []
          }
        };
        let len = this.mission.circuits.length;
        this.mission.circuits.forEach((circuit, i) => {
          if (i !== 0) {
            checkpoint.circuits.push(circuit);
          }
          len--;
          if (len === 0) {
            this.mission.checkpoints.push(checkpoint);
            this.fillPullApiFields(this.mission.checkpoints.length - 1, () => {

            });
            const databaseObj: CheckpointDaoInterface = {
              index: this.mission.checkpoints.length - 1
            };
            this.database.push(databaseObj);
          }
        });
      } else {
        const checkpoint = {
          streetSearchBucket: [],
          selectedCircuit: this.mission.circuits[0],
          circuits: [],
          checkpointName: undefined,
          checkpointAddress: undefined,
          checkpointDescription: undefined,
          checkpointLongitude: this.mission.circuits[0].circuitLongitude,
          checkpointLatitude: this.mission.circuits[0].circuitLatitude,
          selected_adrn: {
            adt_adrn: ''
          },
          adrns: [],
          selected_street: {
            adt_street: ''
          },
          streets: [],
          selected_postalcode: {
            adt_postal_code: ''
          },
          postalcodes: [],
          selected_commune: {
            com_commune_name_fr: ''
          },
          communes: [],
          selected_region: {
            reg_region_name_fr: ''
          },
          regions: [],
          selected_country: {
            con_country_name_fr: ''
          },
          coutries: [],
          adptid_valid: true,
          dontKnowAdptId: true,
          countryLoaded: false,
          regionLoaded: false,
          communeLoaded: false,
          postalCodeLoaded: false,
          streetLoaded: false,
          adrnLoaded: false,
          data: {
            address: '',
            description: '',
            checkpointNameDisabled: false,
            adptid: null,
            quartier: undefined,
            lnglat: []
          }
        };
        let len = this.mission.circuits.length;
        this.mission.circuits.forEach((circuit, i) => {
          if (i !== 0) {
            checkpoint.circuits.push(circuit);
          }
          len--;
          if (len === 0) {
            this.mission.checkpoints.push(checkpoint);
            this.fillPullApiFields(this.mission.checkpoints.length - 1, () => {

            });
            const databaseObj: CheckpointDaoInterface = {
              index: this.mission.checkpoints.length - 1
            };
            this.database.push(databaseObj);
          }
        });
      }
    }
  }

  assignmentFiller(signal, cb) {
    const assignment = {
      tempFieldAgents: [],
      fieldAgents: [],
      selectedFieldAgent: undefined,
      checkpoints: [],
      tempCheckpoints: [],
      selectedCheckpoint: {
        checkpointName: undefined
      },
      selectedCheckpoints: [],
      shifts: [],
      tempShifts: [{
        shiftName: 'Morning',
        timeRange: '10:00 - 12:30',
        startTime: '10:00',
        endTime: '12:30'
      },
      {
        shiftName: 'Morning',
        timeRange: '12:30 - 14:30',
        startTime: '12:30',
        endTime: '14:30'
      },
      {
        shiftName: 'Afternoon',
        timeRange: '14:30 - 16:30',
        startTime: '14:30',
        endTime: '16:30'
      },
      {
        shiftName: 'Afternoon',
        timeRange: '16:30 - 19:00',
        startTime: '16:30',
        endTime: '19:00'
      }],
      shiftTime: 'Morning',
      selectedShift: {},
      selectedShifts: [],
      geojson: {
        type: 'FeatureCollection',
        features: []
      },
      iterations: 0
    };

    if (signal === 'noAssignment') {
      let assignmentAvailable = false;
      if (this.mission.assignments.length !== 0) {
        assignmentAvailable = true;
      }

      this.missionFieldAgentsArrayUpdater(() => {
        if (this.mission.fieldAgents.length <= 1) {
          // this.pedestrainAlertsService.agentsNotFree()
          //   .then(() => {
          //     this.location.back();
          //   })
          //   .catch(() => {
          //     this.location.back();
          //   });
        } else {
          let falen = this.mission.fieldAgents.length;
          this.mission.fieldAgents.forEach(fieldAgent => {
            if (!assignmentAvailable) {
              assignment.fieldAgents.push(fieldAgent);
            } else {
              if (fieldAgent.userId !== this.mission.assignments[0].selectedFieldAgent.userId) {
                assignment.fieldAgents.push(fieldAgent);
              }
            }
            assignment.tempFieldAgents.push(fieldAgent);
            falen--;
            if (falen === 0) {
              assignment.selectedFieldAgent = assignment.fieldAgents[0];
              assignment.fieldAgents.splice(0, 1);
              if (assignmentAvailable) {
                let delIndex = -1;
                let m0faLen = this.mission.assignments[0].fieldAgents.length;
                this.mission.assignments[0].fieldAgents.forEach((fa, ind) => {
                  if (fa.userId === assignment.selectedFieldAgent.userId) {
                    delIndex = ind;
                  }
                  m0faLen--;
                  if (m0faLen === 0) {
                    this.mission.assignments[0].fieldAgents.splice(delIndex, 1);
                  }
                });
              }

              let checklen = this.mission.checkpoints.length;
              this.mission.checkpoints.forEach(checkpoint => {
                if (checkpoint.data.checkpointName !== undefined && checkpoint.data.checkpointName !== '') {
                  checkpoint.checkpointName = checkpoint.data.checkpointName;
                }
                if (checkpoint.checkpointName !== undefined) {
                  if (checkpoint.data.lnglat.length !== 0) {
                    checkpoint.checkpointLongitude = checkpoint.data.lnglat[0];
                    checkpoint.checkpointLatitude = checkpoint.data.lnglat[1];
                  }
                  const feature = {
                    type: 'Feature',
                    properties: {
                      message: 'Foo',
                      iconSize: [60, 60]
                    },
                    geometry: {
                      type: 'Point',
                      coordinates: [checkpoint.checkpointLongitude, checkpoint.checkpointLatitude]
                    }
                  };
                  assignment.checkpoints.push(checkpoint);
                  assignment.tempCheckpoints.push(checkpoint);
                  assignment.geojson.features.push(feature);

                }
                checklen--;
                if (checklen === 0) {
                  assignment.selectedCheckpoint = assignment.checkpoints[0];
                  assignment.checkpoints.splice(0, 1);
                  let shlen = assignment.tempShifts.length;
                  assignment.tempShifts.forEach(shift => {
                    if (assignment.shiftTime === shift.shiftName) {
                      assignment.shifts.push(shift);
                    }
                    shlen--;
                    if (shlen === 0) {
                      assignment.selectedShift = assignment.shifts[0];
                      assignment.shifts.splice(0, 1);
                      if (!this.showAddNewCircuit) {
                        if (assignment.selectedCheckpoint !== undefined) {
                          assignment.selectedCheckpoints.push(assignment.selectedCheckpoint.checkpointName);
                          assignment.selectedCheckpoint = {
                            checkpointName: 'No more checkpoints'
                          };
                          if (assignment.checkpoints.length !== 0) {
                            let assignmentCheckpointsLength = assignment.checkpoints.length;
                            assignment.checkpoints.forEach((che, cheI) => {
                              assignment.selectedCheckpoints.push(che.checkpointName);
                              assignmentCheckpointsLength--;
                              if (assignmentCheckpointsLength === 0) {
                                assignment.checkpoints = [];
                              }
                            });
                          }
                          this.mission.assignments.push(assignment);
                        }
                      }

                      if (this.mission.assignments.length < 2) {
                        this.assignmentFiller('noAssignment', () => {
                        });
                      } else {
                        this.event.broadcast({ eventName: 'newAssignment', data: '' });
                      }
                    }
                  });
                }
              });
            }
          });
        }
      });
    } else {
      let assignmentAvailable = false;
      if (this.mission.assignments.length !== 0) {
        assignmentAvailable = true;
      }
      let falen = this.mission.fieldAgents.length;
      this.mission.fieldAgents.forEach(fieldAgent => {
        if (!assignmentAvailable) {
          assignment.fieldAgents.push(fieldAgent);
        } else {
          if (fieldAgent.userId !== this.mission.assignments[0].selectedFieldAgent.userId) {
            assignment.fieldAgents.push(fieldAgent);
          }
        }
        assignment.tempFieldAgents.push(fieldAgent);
        falen--;
        if (falen === 0) {
          let checkLen = this.mission.checkpoints.length;

          this.mission.checkpoints.forEach(checkpoint => {
            if (checkpoint.checkpointName !== undefined) {
              const feature = {
                type: 'Feature',
                properties: {
                  message: 'Foo',
                  iconSize: [60, 60]
                },
                geometry: {
                  type: 'Point',
                  coordinates: [checkpoint.checkpointLongitude, checkpoint.checkpointLatitude]
                }
              };
              assignment.tempCheckpoints.push(checkpoint);
              assignment.geojson.features.push(feature);
            }
            checkLen--;
            if (checkLen === 0) {
              cb(assignment);
            }
          });
        }
      });
    }
  }

  databaseRefresh(indexArr?) {
    if (indexArr) {
      let indexArrLenght = indexArr.length;
      indexArr.forEach(i => {
        const checkpointCheker = (checkpoint) => {
          return checkpoint.checkpointName === this.database[i].checkpointName;
        };
        const checkpointIndex = this.mission.checkpoints.findIndex(checkpointCheker);
        if (checkpointIndex !== this.database[i].index) {
          checkpointIndex !== -1 ? this.database[i].index = checkpointIndex : console.log('Nothing found in checkpointCheker');
        }
        indexArrLenght--;
        if (indexArrLenght === 0) {
          const noIndexFinder = (dao) => {
            return dao.index === -1;
          };
          const daoIndex = this.database.findIndex(noIndexFinder);
          daoIndex !== -1 ? this.database[daoIndex].index = this.mission.checkpoints.length - 1 : console.log('null noIndexFinder');
          this.databaseRefresh();
        }
      });
    } else {
      const checkpointCount = this.mission.checkpoints.length;
      const databaseLength = this.database.length;
      const noIndexFinder = (dao) => {
        return dao.index === -1;
      };
      if (checkpointCount < databaseLength) {
        const daoIndex = this.database.findIndex(noIndexFinder);
        if (daoIndex !== -1) {
          this.database[daoIndex].index = this.mission.checkpoints.length - 1;
        }
      } else {
        const daoIndex = this.database.findIndex(noIndexFinder);
        if (daoIndex !== -1) {
          this.database[daoIndex].index = this.mission.checkpoints.length - 1;
          this.databaseRefresh();
        }
      }
    }
  }

  assignmentUpdater(ind, prevName) {
    this.mission.assignments.forEach(assignment => {
      if (prevName === undefined) {
        assignment.tempCheckpoints.push(this.mission.checkpoints[ind]);
        if (this.showAddNewCircuit) {
          if (assignment.selectedCheckpoint.checkpointName === 'No more checkpoints') {
            assignment.selectedCheckpoint = this.mission.checkpoints[ind];
          } else {
            assignment.checkpoints.push(this.mission.checkpoints[ind]);
          }
        } else {
          assignment.selectedCheckpoints.push(this.mission.checkpoints[ind].checkpointName);
        }
      } else {
        if (assignment.selectedCheckpoint.checkpointName === prevName) {
          assignment.selectedCheckpoint = this.mission.checkpoints[ind];
        } else {
          let aschlen = assignment.checkpoints.length;
          if (aschlen === 0) {
            let selecLen = assignment.selectedCheckpoints.length;
            let chIndex = -1;
            let siFlag = false;
            assignment.selectedCheckpoints.forEach((check, si) => {
              if (check === prevName) {
                siFlag = true;
                chIndex = si;
              }
              selecLen--;
              if (selecLen === 0) {
                if (siFlag) {
                  assignment.selectedCheckpoints[chIndex] = this.mission.checkpoints[ind].checkpointName;
                }
              }
            });
          } else {
            let changeIndex = -1;
            let flag = false;
            assignment.checkpoints.forEach((checkpoint, i) => {
              if (checkpoint.checkpointName === prevName) {
                flag = true;
                changeIndex = i;
              } else {
                let selecLen = assignment.selectedCheckpoints.length;
                let chIndex = -1;
                let siFlag = false;
                assignment.selectedCheckpoints.forEach((check, si) => {
                  if (check === prevName) {
                    siFlag = true;
                    chIndex = si;
                  }
                  selecLen--;
                  if (selecLen === 0) {
                    if (siFlag) {
                      assignment.selectedCheckpoints[chIndex] = this.mission.checkpoints[ind].checkpointName;
                    }
                  }
                });
              }
              aschlen--;
              if (aschlen === 0) {
                if (flag) {
                  assignment.checkpoints[changeIndex] = this.mission.checkpoints[ind];
                }
              }
            });
          }
        }
      }
    });
  }

  assignmentInitializer(cb) {
    this.missionFieldAgentsArrayUpdater(() => {
      let faLen = this.userCheckpoints.length;
      this.userCheckpoints.forEach(uc => {
        this.mission.fieldAgents.forEach(fa => {
          if (uc.userId === fa.userId) {
            this.assignmentFiller('assignment', (assignment) => {
              this.processUserCheckpoints(uc, fa, assignment, (assignmentWithCheckpoints) => {
                this.processFieldAgentsArray(uc, fa, assignmentWithCheckpoints, (assignmentWithFieldAgents) => {
                  this.mission.assignments.push(assignmentWithFieldAgents);
                  this.event.broadcast({ eventName: 'newAssignment', data: '' });
                });
              });
            });
            faLen--;
            if (faLen === 0) {
              cb();
            }
          }
        });
      });
    });
  }

  missionFieldAgentsArrayUpdater(cb) {
    if (this.dateChanged) {
      cb();
    } else {
      if (this.userCheckpoints === undefined) {
        let alluserLen = this.allUsers.length;
        this.allUsers.forEach(user => {
          let found = -1;
          const fieldAgentChecker = (fa) => {
            return fa.userId === user.userId;
          };
          found = this.mission.fieldAgents.findIndex(fieldAgentChecker);
          if (found === -1) {
            this.mission.fieldAgents.push(user);
          }
          alluserLen--;
          if (alluserLen === 0) {
            cb();
          }
        });
      } else {
        let userCheckpointLength = this.userCheckpoints.length;
        this.userCheckpoints.forEach(uc => {
          userCheckpointLength--;
          let usersLen = this.allUsers.length;
          this.allUsers.forEach(user => {
            if (uc.userId === user.userId) {
              let found = -1;
              const fieldAgentChecker = (fa) => {
                return fa.userId === user.userId;
              };
              found = this.mission.fieldAgents.findIndex(fieldAgentChecker);
              if (found === -1) {
                this.mission.fieldAgents.push(user);
              }
            }
            usersLen--;
            if (usersLen === 0) {
              if (userCheckpointLength === 0) {
                cb();
              }
            }
          });
        });
      }
    }

  }

  processUserCheckpoints(uc, fa, assignment, cb) {
    let checkLen = assignment.tempCheckpoints.length;
    assignment.tempCheckpoints.forEach(check => {
      if (!this.showAddNewCircuit) {
        assignment.selectedCheckpoints.push(check.checkpointName);
      } else {
        let fl = false;
        let cclen = uc.circuits[0].circuitCheckpoints.length;
        uc.circuits[0].circuitCheckpoints.forEach(cc => {
          if (cc.checkpointId === check.checkpointId) {
            if (!assignment.selectedCheckpoints.includes(check.checkpointName)) {
              assignment.selectedCheckpoints.push(check.checkpointName);
            }
            fl = true;
          }
          cclen--;
          if (cclen === 0) {
            if (!fl) {
              assignment.checkpoints.push(check);
            }
          }
        });
      }
      checkLen--;
      if (checkLen === 0) {
        let ucLen = uc.circuits.length;
        ucLen--;
        uc.circuits.forEach(circuit => {
          let cclen = circuit.circuitCheckpoints.length;
          circuit.circuitCheckpoints.forEach(checkpoint => {
            const start = checkpoint.checkpointStart.split(' ')[1].split(':');
            const end = checkpoint.checkpointEnd.split(' ')[1].split(':');
            if (!assignment.selectedShifts.includes(start[0] + ':' + start[1] + ' - ' + end[0] + ':' + end[1])) {
              assignment.selectedShifts.push(start[0] + ':' + start[1] + ' - ' + end[0] + ':' + end[1]);
            }
            cclen--;
            if (cclen === 0 && ucLen === 0) {
              let shiftLen = assignment.tempShifts.length;
              assignment.tempShifts.forEach(ts => {
                if (!assignment.selectedShifts.includes(ts.timeRange)) {
                  if (assignment.shiftTime === 'Morning' && ts.shiftName === 'Morning') {
                    assignment.shifts.push(ts);
                  } else if (assignment.shiftTime === 'Afternoon' && ts.shiftName === 'Afternoon') {
                    assignment.shifts.push(ts);
                  }
                } else if (assignment.selectedShifts[0] === ts.timeRange) {
                  if (ts.shiftName === 'Morning' && checkpoint.checkpointShift === 'AM') {
                    if (checkpoint.checkpointIterations === 5) {
                      if (!assignment.selectedShifts.includes('14:30 - 16:30')) {
                        assignment.selectedShifts.push('14:30 - 16:30');
                      }
                    } else if (checkpoint.checkpointIterations === 4) {
                      if (!assignment.selectedShifts.includes('16:30 - 19:00')) {
                        assignment.selectedShifts.push('16:30 - 19:00');
                      }
                    }
                  } else if (ts.shiftName === 'Afternoon' && checkpoint.checkpointShift === 'PM') {
                    if (checkpoint.checkpointIterations === 5) {
                      if (!assignment.selectedShifts.includes('12:30 - 14:30')) {
                        assignment.selectedShifts.push('12:30 - 14:30');
                      }
                    } else if (checkpoint.checkpointIterations === 4) {
                      if (!assignment.selectedShifts.includes('10:00 - 12:30')) {
                        assignment.selectedShifts.push('10:00 - 12:30');
                      }
                    }
                  }
                }
                shiftLen--;
                if (shiftLen === 0) {
                  assignment.selectedShift = assignment.shifts[0];
                  assignment.shifts.splice(0, 1);
                  if (this.showAddNewCircuit) {
                    if (assignment.checkpoints.length !== 0) {
                      assignment.selectedCheckpoint = assignment.checkpoints[0];
                      assignment.checkpoints.splice(0, 1);
                    } else {
                      assignment.selectedCheckpoint = {
                        checkpointName: 'No more checkpoints'
                      };
                    }
                  } else {
                    let asschelen = assignment.checkpoints.length;
                    if (asschelen === 0) {
                      if (assignment.selectedCheckpoint.checkpointName === undefined) {
                        assignment.selectedCheckpoint = {
                          checkpointName: 'No more checkpoints'
                        };
                      }
                    } else {
                      assignment.checkpoints.forEach((che, cheI) => {
                        if (!assignment.selectedCheckpoints.includes(che.checkpointName)) {
                          assignment.selectedCheckpoints.push(che.checkpointName);
                        }
                        assignment.checkpoints.splice(cheI, 1);
                        asschelen--;
                        if (asschelen === 0) {
                          assignment.selectedCheckpoint = {
                            checkpointName: 'No more checkpoints'
                          };
                        }
                      });
                    }
                  }
                  assignment.iterations = 9;
                  cb(assignment);
                }
              });
            }
          });
        });
      }
    });
  }

  processFieldAgentsArray(uc, fa, assignment, cb) {
    const assignmentUserIndexFinder = (fieldA) => {
      return fieldA.userId === fa.userId;
    };
    assignment.selectedFieldAgent = fa;
    let falEn = this.mission.fieldAgents.length;
    assignment.fieldAgents = [];
    this.mission.fieldAgents.forEach(fieldAgent => {
      if (this.mission.assignments.length !== 0) {
        if (this.mission.assignments[0].selectedFieldAgent.userId !== fieldAgent.userId && fieldAgent.userId !== fa.userId) {
          assignment.fieldAgents.push(fieldAgent);
          assignment.tempFieldAgents.push(fieldAgent);
        }
      } else {
        if (fieldAgent.userId !== fa.userId) {
          if (assignment.fieldAgents.length === 0) {
            assignment.fieldAgents.push(fieldAgent);
            assignment.tempFieldAgents.push(fieldAgent);
          } else {
            const index = assignment.fieldAgents.findIndex(assignmentUserIndexFinder);
            if (index === -1) {
              assignment.fieldAgents.push(fieldAgent);
              assignment.tempFieldAgents.push(fieldAgent);
            }
          }
        }
      }
      falEn--;
      if (falEn === 0) {
        if (this.mission.assignments.length !== 0) {
          let del = -1;
          let prevAssignLen = this.mission.assignments[0].fieldAgents.length;
          this.mission.assignments[0].fieldAgents.forEach((field, deleteind) => {
            if (assignment.selectedFieldAgent.userId === field.userId) {
              del = deleteind;
            }
            prevAssignLen--;
            if (prevAssignLen === 0) {
              if (del !== -1) {
                this.mission.assignments[0].fieldAgents.splice(del, 1);
              }
              cb(assignment);
            }
          });
        } else {
          cb(assignment);
        }
      }
    });
  }

  /* DOM manipulators
    1. changeCircuitName(circuitName, circuitId)
    2. add2ShiftsArray(shift, i)
    3. add2CheckpointsArray(checkpoint, i)
    4. changeShiftId(id, i)
    5. changeCheckpointName(name, id, i)
    6. updateDatabase(signal, value, newValue)
    7. circuitUpdater(circuitName, prevName)
    8. add2CheckpointsCircuitArray(ind)
    9. changeMissionDate()
    10. selectedItem(e, index)
  */

  selectedItem(e, index) {
    console.log('event', e.item);
    this.mission.checkpoints[index].selected_street.adt_street = e.item;
    this.mission.checkpoints[index].adrnLoaded = false;
    this.mission.checkpoints[index].adrnLoaded = false;
    this.mission.checkpoints[index].data.adptid = null;
    this.getAdrns(index, () => {
      this.getAdptId(index, () => {
      });
    });
    console.log('index', index);
  }

  changeMissionDate() {
    this.mission.assignments = [];
    this.mission.fieldAgents = [];
    this.userCheckpoints = undefined;
    this.getAllFieldAgents(() => {
      this.assignmentFiller('noAssignment', () => {
      });
    });
  }

  circuitUpdater(circuitName, prevName) {
    this.mission.checkpoints.forEach(checkpoint => {
      if (checkpoint.selectedCircuit.circuitName === prevName) {
        checkpoint.selectedCircuit.circuitName = circuitName;
      } else {
        checkpoint.circuits.forEach(circuit => {
          if (circuit.circuitName === prevName) {
            circuit.circuitName = circuitName;
          }
        });
      }
    });
  }

  add2CheckpointsCircuitArray(ind) {
    this.mission.checkpoints.forEach(checkpoint => {
      checkpoint.circuits.push(this.mission.circuits[ind]);
    });
  }

  changeCircuitName(circuitName, id) {
    this.mission.checkpoints.forEach(checkpoint => {
      if (checkpoint.selectedCircuit.circuitId === id) {
        checkpoint.selectedCircuit.circuitName = circuitName;
      } else {
        checkpoint.circuits.forEach(circuit => {
          if (circuit.circuitId === id) {
            circuit.circuitName = circuitName;
          }
        });
      }
    });
  }

  add2ShiftsArray(shift, i) {
    if (this.mission.assignments[i].selectedShifts.length < 2) {
      if (shift.shiftName === 'Morning') {
        if (shift.timeRange === '10:00 - 12:30') {
          if (this.mission.assignments[i].iterations !== 5) {
            if (this.mission.assignments[i].shifts.length === 1 && this.mission.assignments[i].shifts[0].shiftName === 'Morning') {
              this.mission.assignments[i].iterations = this.mission.assignments[i].iterations + 5;
              this.mission.assignments[i].selectedShifts.push(this.mission.assignments[i].selectedShift.timeRange);
              this.mission.assignments[i].selectedShift = {};
              if (this.mission.assignments[i].shifts.length !== 0) {
                this.mission.assignments[i].shifts.forEach((sh, ind) => {
                  if (sh.shiftName === 'Morning') {
                    this.mission.assignments[i].selectedShift = sh;
                    this.mission.assignments[i].shifts.splice(ind, 1);
                  }
                });
              }
            } else {
              this.pedestrainAlertsService.sameShiftCanNotAssigned();
            }
          } else {
            this.pedestrainAlertsService.sameShiftIteration();
          }
        } else if (shift.timeRange === '12:30 - 14:30') {
          if (this.mission.assignments[i].iterations !== 4) {
            if (this.mission.assignments[i].shifts.length === 1 && this.mission.assignments[i].shifts[0].shiftName === 'Morning') {
              this.mission.assignments[i].iterations = this.mission.assignments[i].iterations + 4;
              this.mission.assignments[i].selectedShifts.push(this.mission.assignments[i].selectedShift.timeRange);
              this.mission.assignments[i].selectedShift = {};
              if (this.mission.assignments[i].shifts.length !== 0) {
                this.mission.assignments[i].shifts.forEach((sh, ind) => {
                  if (sh.shiftName === 'Morning') {
                    this.mission.assignments[i].selectedShift = sh;
                    this.mission.assignments[i].shifts.splice(ind, 1);
                  }
                });
              }
            } else {
              this.pedestrainAlertsService.sameShiftCanNotAssigned();
            }
          } else {
            this.pedestrainAlertsService.sameShiftIteration();
          }
        }
      } else if (shift.shiftName === 'Afternoon') {
        if (shift.timeRange === '14:30 - 16:30') {
          if (this.mission.assignments[i].iterations !== 4) {
            if (this.mission.assignments[i].shifts.length === 1 && this.mission.assignments[i].shifts[0].shiftName === 'Afternoon') {
              this.mission.assignments[i].iterations = this.mission.assignments[i].iterations + 4;
              this.mission.assignments[i].selectedShifts.push(this.mission.assignments[i].selectedShift.timeRange);
              this.mission.assignments[i].selectedShift = {};
              if (this.mission.assignments[i].shifts.length !== 0) {
                this.mission.assignments[i].shifts.forEach((sh, ind) => {
                  if (sh.shiftName === 'Afternoon') {
                    this.mission.assignments[i].selectedShift = sh;
                    this.mission.assignments[i].shifts.splice(ind, 1);
                  }
                });
              }
            } else {
              this.pedestrainAlertsService.sameShiftCanNotAssigned();
            }
          } else {
            this.pedestrainAlertsService.sameShiftIteration();
          }
        } else if (shift.timeRange === '16:30 - 19:00') {
          if (this.mission.assignments[i].iterations !== 5) {
            if (this.mission.assignments[i].shifts.length === 1 && this.mission.assignments[i].shifts[0].shiftName === 'Afternoon') {
              this.mission.assignments[i].iterations = this.mission.assignments[i].iterations + 5;
              this.mission.assignments[i].selectedShifts.push(this.mission.assignments[i].selectedShift.timeRange);
              this.mission.assignments[i].selectedShift = {};
              if (this.mission.assignments[i].shifts.length !== 0) {
                this.mission.assignments[i].shifts.forEach((sh, ind) => {
                  if (sh.shiftName === 'Afternoon') {
                    this.mission.assignments[i].selectedShift = sh;
                    this.mission.assignments[i].shifts.splice(ind, 1);
                  }
                });
              }
            } else {
              this.pedestrainAlertsService.sameShiftCanNotAssigned();
            }
          } else {
            this.pedestrainAlertsService.sameShiftIteration();
          }
        }
      }
    }
  }

  add2CheckpointsArray(checkpoint, i) {
    if (this.mission.assignments[i].checkpoints.length === 0) {
      if (this.mission.assignments[i].selectedCheckpoint.checkpointName !== 'No more checkpoints') {
        this.mission.assignments[i].selectedCheckpoints.push(this.mission.assignments[i].selectedCheckpoint.checkpointName);
        this.mission.assignments[i].selectedCheckpoint = {
          checkpointName: 'No more checkpoints'
        };
      } else {
        this.mission.assignments[i].selectedCheckpoint.checkpointName = 'No more checkpoints';
      }
    } else {
      this.mission.assignments[i].selectedCheckpoints.push(this.mission.assignments[i].selectedCheckpoint.checkpointName);
      this.mission.assignments[i].selectedCheckpoint = this.mission.assignments[i].checkpoints[0];
      this.mission.assignments[i].checkpoints.splice(0, 1);
    }
  }

  changeShiftId(id) {
    if (id==1){
      this.isShift = 'Morning';
    }else{
      this.isShift = 'Afternoon';
    }

    let dateE = JSON.parse(localStorage.getItem('date'));
    if (dateE == null) {
      this.getUnassignedUsers(this.mission.missionId, false, this.mission.startDate);
    } else{
      let datePickerDateSelected = new Date(UTILS.getDateFormat(this.mission.startDate));
      let existingDate = new Date(UTILS.getDateFormat(dateE));
      if (datePickerDateSelected.getTime() == existingDate.getTime()) {
        this.getUnassignedUsers(this.mission.missionId, true, this.mission.startDate);
      } else {
        this.getUnassignedUsers(this.mission.missionId, false, this.mission.startDate);
      }
    }

    // this.http.SecurePost('/ref/getAllUnassignedUsers', {
    //   startDate: this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day,
    //   missionId: this.mission.missionId,
    //   shift: this.isShift == "Morning" ? 1 : 2
    // }).subscribe(resFA => {
    //   console.log("Mission", this.mission);
    //   this.fieldAgents = resFA.users;
    //   this.selectedFieldAgent = resFA.users[0];
    // },err=>{
    //     this.custUtils.translateMessageObject({
    //       title: this.translate.instant('No Field agents available'),
    //       text: this.translate.instant('Please change the mission date or  ask admin to add more field agents.'),
    //       type: 'warning',
    //       cancelBtnText: '',
    //       confirmBtnText: 'OK',
    //       outsideClick: false,
    //       showCancelBtn: false
    //     }, message => {
    //       this.custUtils.translateAndPop(message).then(() => {
    //         this.fieldAgents = [];
    //         this.selectedFieldAgent = {};
    //       }).catch(() => {
    //         this.fieldAgents = [];
    //         this.selectedFieldAgent = {};
    //       });
    //     });
    // });
  }

  changeCheckpointName(name, id, i) {
    if (this.mission.checkpoints.length === 3) {
      let count = 0;
      let checkLen = this.mission.checkpoints.length;
      this.mission.assignments = [];
      this.mission.checkpoints.forEach((check, i) => {
        if (check.checkpointName === '' || check.checkpointName === undefined) {
          const databaseObj: CheckpointDaoInterface = {
            id: check.checkpointId,
            checkpointName: check.checkpointName,
            index: i
          };
          this.database.splice(i, 0, databaseObj);
          count++;
        }
        checkLen--;
        if (checkLen === 0) {
          this.taged = [];
          const obj = this.mission.checkpoints.filter(res => res.checkpointName);
          obj.forEach(itm => this.taged.push(itm.checkpointName));

          if (count === 0) {
            if (this.mission.assignments.length === 0) {
              this.assignmentFiller('noAssignment', () => {

              });
            }
          }
        }
      });
    }
    if (!this.showAddNewCircuit) {
      let missionAssignmentsLength = this.mission.assignments.length;
      this.mission.assignments.forEach(assignment => {
        const checkpointFinder = (checkpoint) => {
          return checkpoint === this.database[i].checkpointName;
        };
        const chIndex = assignment.selectedCheckpoints.findIndex(checkpointFinder);
        assignment.selectedCheckpoints[chIndex] = name;
        missionAssignmentsLength--;
        if (missionAssignmentsLength === 0) {
          this.updateDatabase('name', this.database[i].checkpointName, name);
        }
      });
    }
  }

  updateDatabase(signal, value, newValue) {
    if (signal === 'index') {
      let changeindex = -1;
      let databaseLen = this.database.length;
      this.database.forEach((dao, ind) => {
        if (dao.index === value) {
          changeindex = ind;
        }
        databaseLen--;
        if (databaseLen === 0) {
          this.database[changeindex].checkpointName = newValue;
        }
      });
    } else if (signal === 'name') {
      const daoFinder = (dao) => {
        return dao.checkpointName === value;
      };
      const index = this.database.findIndex(daoFinder);
      this.database[index].checkpointName = newValue;
    }
  }

  /* Validators
    1. circuitNameChecker(circuitName, i)
    2. checkpointNameChecker(checkpointName, i)
    3. validateMission(cb)
    4. assignmentValidator(cb)
  */

  circuitNameChecker(circuitName, i) {
    if (!circuitName.replace(/\s/g, '').length) {
      this.reverseGeocoder(circuitName, i, 'circuit');
    }
    if (circuitName === '') {
      this.reverseGeocoder(circuitName, i, 'circuit');
    }
  }

  checkpointNameChecker(checkpointName, i) {
    if (!checkpointName.replace(/\s/g, '').length) {
      this.reverseGeocoder(checkpointName, i, 'checkpoint');
    }
    if (checkpointName === '') {
      this.reverseGeocoder(checkpointName, i, 'checkpoint');
    }
  }

  searchExistingCircuitName(value, i) {
    if (!value) {
      this.mission.circuits[i].existingCircuits = Object.assign([], this.mission.circuits[i].tempExistingCircuits).filter(item => {
        if (this.mission.circuits[i].selectedExistingCircuit.circuitName !== item.circuitName) {
          return item;
        }
      });
    } else {
      this.mission.circuits[i].existingCircuits = Object.assign([], this.mission.circuits[i].tempExistingCircuits).filter(
        item => {
          if (this.mission.circuits[i].selectedExistingCircuit.circuitName !== item.circuitName) {
            return item.circuitName.toLowerCase().indexOf(value.toLowerCase()) > -1;
          }
        }
      );
    }
  }

  validateMission(cb) {
    if (this.mission.missionId && this.mission.missionName) {
      let circuitMessages;
      let circuitLength = this.mission.circuits.length;
      const today = new Date(Date.now());
      const thisDate = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      const missionDate = new Date(this.mission.startDate.year, this.mission.startDate.month - 1, this.mission.startDate.day);
      if (missionDate < thisDate) {
        this.pedestrainAlertsService.dateMoreThanTodayAlert();
        this.event.broadcast({ eventName: 'hideLoader', data: '' });
        this.submitdisabled = false;
      } else {
        if (this.mission.circuits.length === 0) {
          this.pedestrainAlertsService.noCircuits();
          this.event.broadcast({ eventName: 'hideLoader', data: '' });
          this.submitdisabled = false;
        } else {
          this.mission.circuits.forEach(circuit => {
            if (!circuit.existingCircuitsCheck) {
              if (!circuit.ogImage) {
                if (circuit.image) {
                } else {
                  circuitMessages = 'All Fields are mandatory in circuit.';
                }
              }
              if (circuit.circuitLongitude && circuit.circuitLatitude && circuit.circuitName) {
              } else {
                circuitMessages = 'All Fields are mandatory in circuit.';
              }
            }
            circuitLength--;
            if (circuitLength === 0) {
              if (circuitMessages) {
                this.pedestrainAlertsService.searchMapImage(circuitMessages);
                this.event.broadcast({ eventName: 'hideLoader', data: '' });
                this.submitdisabled = false;
              } else {
                let checkpointMessages;
                let checkpointLength = this.mission.checkpoints.length;
                if (this.mission.checkpoints.length < 3) {
                  this.pedestrainAlertsService.addMoreCheckpointAlert();
                  this.event.broadcast({ eventName: 'hideLoader', data: '' });
                  this.submitdisabled = false;
                } else {
                  if (this.checkpointsFound) {
                    this.mission.checkpoints.forEach((checkpoint, ind) => {
                      let found = false;
                      let internalLoopCounter = this.mission.checkpoints.length;
                      this.mission.checkpoints.forEach((check, index) => {
                        if (index !== ind) {
                          if (check.checkpointName === checkpoint.checkpointName) {
                            found = true;
                          }
                          if (check.data.adptid.toString() === checkpoint.data.adptid.toString()) {
                            found = true;
                          }
                        }
                        internalLoopCounter--;
                        if (internalLoopCounter === 0) {
                          if (found) {
                            checkpointMessages = this.translate.instant('All Fields are mandatory in checkpoint.');
                          }
                        }
                      });
                      checkpoint.checkpointDescription = checkpoint.checkpointDescription === undefined ? '' :
                        checkpoint.checkpointDescription;
                      if (checkpoint.checkpointLongitude &&
                        checkpoint.checkpointLatitude &&
                        checkpoint.checkpointName && checkpoint.data.adptid) {
                      } else {
                        checkpointMessages = this.translate.instant('All Fields are mandatory in checkpoint.');
                      }
                      checkpointLength--;
                      if (checkpointLength === 0) {
                        if (checkpointMessages) {
                          this.pedestrainAlertsService.checkPointUnique(checkpointMessages);
                          this.event.broadcast({ eventName: 'hideLoader', data: '' });
                          this.submitdisabled = false;
                        } else {
                          this.assignmentValidator(() => {
                            cb();
                          });
                        }
                      }
                    });
                  } else {
                    this.http.SecurePost('/checkpoint/validateCheckpoints', {
                      adptIds: [this.mission.checkpoints[0].data.adptid, this.mission.checkpoints[1].data.adptid, this.mission.checkpoints[2].data.adptid]
                    }).subscribe(res => {
                      if (!this.mission.circuits[0].existingCircuitsCheck) {
                        this.submitdisabled = false;
                        this.event.broadcast({ eventName: 'hideLoader', data: '' })
                        this.pedestrainAlertsService.combinationAlreadyAdptId();
                      } else {
                        this.mission.checkpoints.forEach((checkpoint, ind) => {
                          let found = false;
                          let internalLoopCounter = this.mission.checkpoints.length;
                          this.mission.checkpoints.forEach((check, index) => {
                            if (index !== ind) {
                              if (check.checkpointName === checkpoint.checkpointName) {
                                found = true;
                              }
                              if (check.data.adptid.toString() === checkpoint.data.adptid.toString()) {
                                found = true;
                              }
                            }
                            internalLoopCounter--;
                            if (internalLoopCounter === 0) {
                              if (found) {
                                checkpointMessages = this.translate.instant('All Fields are mandatory in checkpoint.');
                              }
                            }
                          });
                          checkpoint.checkpointDescription = checkpoint.checkpointDescription === undefined ? '' :
                            checkpoint.checkpointDescription;
                          if (checkpoint.checkpointLongitude &&
                            checkpoint.checkpointLatitude &&
                            checkpoint.checkpointName && checkpoint.data.adptid) {
                          } else {
                            checkpointMessages = this.translate.instant('All Fields are mandatory in checkpoint.');
                          }
                          checkpointLength--;
                          if (checkpointLength === 0) {
                            if (checkpointMessages) {
                              this.pedestrainAlertsService.checkPointUnique(checkpointMessages);
                              this.event.broadcast({ eventName: 'hideLoader', data: '' });
                              this.submitdisabled = false;
                            } else {
                              this.assignmentValidator(() => {
                                cb();
                              });
                            }
                          }
                        });
                      }
                    }, err => {
                      this.mission.checkpoints.forEach((checkpoint, ind) => {
                        let found = false;
                        let internalLoopCounter = this.mission.checkpoints.length;
                        this.mission.checkpoints.forEach((check, index) => {
                          if (index !== ind) {
                            if (check.checkpointName === checkpoint.checkpointName) {
                              found = true;
                            }
                            if (check.data.adptid.toString() === checkpoint.data.adptid.toString()) {
                              found = true;
                            }
                          }
                          internalLoopCounter--;
                          if (internalLoopCounter === 0) {
                            if (found) {
                              checkpointMessages = this.translate.instant('All Fields are mandatory in checkpoint.');
                            }
                          }
                        });
                        checkpoint.checkpointDescription = checkpoint.checkpointDescription === undefined ? '' :
                          checkpoint.checkpointDescription;
                        if (checkpoint.checkpointLongitude &&
                          checkpoint.checkpointLatitude &&
                          checkpoint.checkpointName && checkpoint.data.adptid) {
                        } else {
                          checkpointMessages = this.translate.instant('All Fields are mandatory in checkpoint.');
                        }
                        checkpointLength--;
                        if (checkpointLength === 0) {
                          if (checkpointMessages) {
                            this.pedestrainAlertsService.checkPointUnique(checkpointMessages);
                            this.event.broadcast({ eventName: 'hideLoader', data: '' });
                            this.submitdisabled = false;
                          } else {
                            this.assignmentValidator(() => {
                              cb();
                            });
                          }
                        }
                      });
                    });
                  }
                }
              }
            }
          });
        }
        if (this.mission.circuits.length === 0) {
          this.pedestrainAlertsService.noCircuits();
          this.event.broadcast({ eventName: 'hideLoader', data: '' });
          this.submitdisabled = false;
        } else {
          this.mission.circuits.forEach(circuit => {
            if (!circuit.existingCircuitsCheck) {
              if (!circuit.ogImage) {
                if (circuit.image) {
                } else {
                  circuitMessages = 'All Fields are mandatory in circuit.';
                }
              }
              if (circuit.circuitLongitude && circuit.circuitLatitude && circuit.circuitName) {
              } else {
                circuitMessages = 'All Fields are mandatory in circuit.';
              }
            }
            circuitLength--;
            if (circuitLength === 0) {
              if (circuitMessages) {
                this.pedestrainAlertsService.searchMapImage(circuitMessages);
                this.event.broadcast({ eventName: 'hideLoader', data: '' });
                this.submitdisabled = false;
              } else {
                let checkpointMessages;
                let checkpointLength = this.mission.checkpoints.length;
                if (this.mission.checkpoints.length < 3) {
                  swal(
                    MESSAGECONSTANTS.ALERT_MESSAGES.MORE_CHECKPOINTS_NEEDED,
                    MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ADD_CHECKPOINTS, 'warning');
                  this.event.broadcast({ eventName: 'hideLoader', data: '' });
                  this.submitdisabled = false;
                } else {
                  this.mission.checkpoints.forEach(checkpoint => {
                    checkpoint.checkpointDescription = checkpoint.checkpointDescription === undefined ? '' :
                      checkpoint.checkpointDescription;
                    if (checkpoint.checkpointLongitude &&
                      checkpoint.checkpointLatitude &&
                      checkpoint.checkpointAddress &&
                      checkpoint.checkpointName && checkpoint.checkpointDescription) {
                    } else {
                      checkpointMessages = this.translate.instant('All Fields are mandatory in checkpoint.');
                    }
                    checkpointLength--;
                    if (checkpointLength === 0) {
                      if (checkpointMessages) {
                        this.pedestrainAlertsService.searchLocationImage(checkpointMessages);
                        this.event.broadcast({ eventName: 'hideLoader', data: '' });
                        this.submitdisabled = false;
                      } else {
                        this.assignmentValidator(() => {
                          cb();
                        });
                      }
                    }
                  });
                }
              }
            }
          });
        }
      }
    } else {
      this.pedestrainAlertsService.allFieldsMandatory();
      this.submitdisabled = false;
    }
  }

  assignmentValidator(cb) {
    let len = this.mission.assignments.length;
    const errorMessages = [];
    this.mission.assignments.forEach((assignment, pi) => {
      this.mission.assignments.forEach((checkAssignment, ci) => {
        const aslen = this.mission.assignments.length;
        const chlen = assignment.selectedCheckpoints.length;
        if (chlen === 0) {
          errorMessages.push('ncf');
        }
        if (aslen === 1) {
          errorMessages.push('nea');
        }
        if (pi !== ci) {
          if (assignment.selectedFieldAgent.userId === checkAssignment.selectedFieldAgent.userId &&
            assignment.selectedShift.timeRange === checkAssignment.selectedShift.timeRange) {
            errorMessages.push('sfss');
          } else if (assignment.selectedFieldAgent.userId !== checkAssignment.selectedFieldAgent.userId) {
            let checklen = assignment.selectedCheckpoints.length;
            let flag = false;
            let shiftFlag = false;
            let shiftLen = assignment.selectedShifts.length;
            assignment.selectedShifts.forEach(sh => {
              checkAssignment.selectedShifts.forEach(csk => {
                if (csk === sh) {
                  shiftFlag = true;
                }
                shiftLen--;
                if (shiftLen === 0) {
                  if (shiftFlag) {
                    assignment.selectedCheckpoints.forEach(assigncheck => {
                      checkAssignment.selectedCheckpoints.forEach(checkassign => {
                        if (checkassign === assigncheck) {
                          flag = true;
                        }
                      });
                      checklen--;
                      if (checklen === 0) {
                        if (flag === true) {
                          errorMessages.push('dfss');
                        }
                      }
                    });
                  }
                }
              });
            });
          }
          assignment.iterations = 9;
          checkAssignment.iterations = 9;
          if (!assignment.iterations) {
            errorMessages.push('nif');
          } else if (!checkAssignment.iterations) {
            errorMessages.push('nif');
          } else {
            if (assignment.iterations !== 9) {
              if (!errorMessages.includes('int9')) {
                errorMessages.push('int9');
              }
            }
            if (checkAssignment.iterations !== 9) {
              if (!errorMessages.includes('int9')) {
                errorMessages.push('int9');
              }
            }
          }
        }
      });
      len--;
      if (len === 0) {
        if (errorMessages.length > 0) {
          let elen = errorMessages.length;
          let message = '';
          errorMessages.forEach(err => {
            if (err === 'sfss') {
              if (message.indexOf('Same shift is used for same supervisor<br/>') === -1) {
                message = message + 'Same shift is used for same supervisor<br/>';
              }
            } else if (err === 'dfss') {
              if (message.indexOf('Different supervisors are assigned to same checkpoint in the same shift timings.<br/>') === -1) {
                message = message + 'Different supervisors are assigned to same checkpoint in the same shift timings.<br/>';
              }
            } else if (err === 'nif') {
              if (message.indexOf('Iterations are needed for each assignment.<br/>') === -1) {
                message = message + 'Iterations are needed for each assignment.<br/>';
              }
            } else if (err === 'ncf') {
              if (message.indexOf('Checkpoints are needed in assignment.<br/>') === -1) {
                message = message + 'Checkpoints are needed in assignment.<br/>';
              }
            } else if (err === 'int9') {
              if (message.indexOf('Iterations need to be 9.<br/>') === -1) {
                message = message + 'Iterations need to be 9.<br/>';
              }
            } else if (err === 'nea') {
              if (message.indexOf('More assignments needed.<br/>') === -1) {
                message = message + 'More assignments needed.<br/>';
              }
            }
            elen--;
            if (elen === 0) {
              this.pedestrainAlertsService.conditionBeforeSubmit(message);
              this.submitdisabled = false;
              this.event.broadcast({ eventName: 'hideLoader', data: '' });
            }
          });
        } else {
          cb();
        }
      }
    });
  }

  /* Deletors 
    1. checkpointRemover(cb)
    2. circuitRestarter(cb)
    3. onShiftRemoved(e, i)
    4. deleteCircuit(i)
    5. deleteCheckpoint(i)
  */

  checkpointRemover(cb) {
    this.mission.assignments = [];
    this.mission.checkpoints = [];
    this.database = [];
    cb();
  }
  circuitRestarter(cb) {
    this.mission.circuits = [];
    this.newCircuit = true;
    this.circuitCreator();
    cb();
  }
  onShiftRemoved(e, i) {
    this.mission.assignments[i].tempShifts.forEach(shift => {
      if (shift.timeRange === e) {
        if (shift.timeRange === '10:00 - 12:30' && this.mission.assignments[i].shiftTime === 'Morning') {
          this.mission.assignments[i].iterations = this.mission.assignments[i].iterations - 5;
          this.mission.assignments[i].shifts.push(shift);
        } else if (shift.timeRange === '12:30 - 14:30' && this.mission.assignments[i].shiftTime === 'Morning') {
          this.mission.assignments[i].iterations = this.mission.assignments[i].iterations - 4;
          this.mission.assignments[i].shifts.push(shift);
        } else if (shift.timeRange === '14:30 - 16:30' && this.mission.assignments[i].shiftTime === 'Afternoon') {
          this.mission.assignments[i].iterations = this.mission.assignments[i].iterations - 4;
          this.mission.assignments[i].shifts.push(shift);
        } else if (shift.timeRange === '16:30 - 19:00' && this.mission.assignments[i].shiftTime === 'Afternoon') {
          this.mission.assignments[i].iterations = this.mission.assignments[i].iterations - 5;
          this.mission.assignments[i].shifts.push(shift);
        } else if (shift.timeRange === '10:00 - 12:30' && this.mission.assignments[i].shiftTime !== 'Morning') {
          this.mission.assignments[i].iterations = this.mission.assignments[i].iterations - 5;
        } else if (shift.timeRange === '12:30 - 14:30' && this.mission.assignments[i].shiftTime !== 'Morning') {
          this.mission.assignments[i].iterations = this.mission.assignments[i].iterations - 4;
        } else if (shift.timeRange === '14:30 - 16:30' && this.mission.assignments[i].shiftTime !== 'Afternoon') {
          this.mission.assignments[i].iterations = this.mission.assignments[i].iterations - 4;
        } else if (shift.timeRange === '16:30 - 19:00' && this.mission.assignments[i].shiftTime !== 'Afternoon') {
          this.mission.assignments[i].iterations = this.mission.assignments[i].iterations - 5;
        }
      }
    });
  }

  deleteCircuit(i) {
    this.mission.circuits.splice(i, 1);
  }
  deleteCheckpoint(i) {
    let title = this.checkpointsFound ?
      'You have to use existing circuit or create a new circuit if you want to remove the checkpoint.' :
      'This checkpoint will be lost.';
    this.pedestrainAlertsService.doYouWantContinue(title)
      .then((result) => {
        if (result) {
          this.mission.assignments = [];
          if (this.circuitPresent && !this.checkpointsFound) {
            this.mission.checkpoints.splice(i, 1);
            this.checkpointMapGeoJSON.features.splice(i, 1);
            this.showAddNewCheckpoint = true;
            this.event.broadcast({ eventName: 'hideLoader', data: '' });
          } else if (this.circuitPresent && this.checkpointsFound) {
            this.mission.circuits = [];
            this.mission.checkpoints = [];
            this.newCircuit = true;
            this.checkpointsFound = false;
            const circuit = {
              circuitName: undefined,
              circuitLongitude: 4.3517,
              circuitLatitude: 50.8503,
              ogImage: false,
              existingCircuitsCheck: false,
              existingCircuits: [],
              tempExistingCircuits: [],
              existingCircuitSearch: undefined,
              selectedExistingCircuit: {},
              checkpointsGeoJson: {
                'type': 'FeatureCollection',
                'features': []
              }
            };
            this.checkpointMapGeoJSON.features = [];
            this.existingCircuitsFiller(circuit, (cir) => {
              this.mission.circuits.push(cir);

              this.event.broadcast({ eventName: 'hideLoader', data: '' });
            });
          } else {
            this.mission.checkpoints.splice(i, 1);
            this.showAddNewCheckpoint = true;
            this.checkpointMapGeoJSON.features.splice(i, 1);
            this.event.broadcast({ eventName: 'hideLoader', data: '' });
          }
        }
      }).catch(() => {
        this.pedestrainAlertsService.thanksAlert();
      });
  }

  /* Editors and creators
    1. editMission()
    2. missionCreator()
    3. createCircuit()
    4. checkpointCreator()
    5. addCheckpoints(ids)
    6. updateCheckpointObjectCreator(index)
    7. sendCheckpoint(i, cb)
    8. missionUpdater()
    9. circuitEditor(reqObj, cb)
    10. checkpointEditor(reqObj, cb)
    11. assignmentEditor(reqObj, cb)
    12. assignmentLooper(count, reqObj, cb)
  */
  editMissionRequestBody(){
    let ogMission:any = this.ogMission;
    let obj = {
      "mission": {
        "missionId": this.mission.missionId,
        "missionDescription": this.mission.missionDescription,
        "missionStartDate": `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 00:00:00`,
        "missionEndDate": `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 00:00:00`,
        "missionName": this.mission.missionName,
        "missionTypeId": this.mission.taskTypeId,
        "missionUpdatedById": this.user.userId,
        "missionCampaignId": this.mission.campaignId,
        "classic": this.classic,
        "market": this.market,
        "marketZone": this.marketid,  //null if market zone not selected
        "prm": false,
        "visits": false,
        "missionStatusId": ogMission.missionStatus.statusId
      },
      "circuits": [
        {
          "circuitId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
          "circuitLatitude": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitLatitude  : this.mission.circuits[0].circuitLatitude,
          "circuitLongitude": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitLongitude : this.mission.circuits[0].circuitLongitude,
          "circuitName": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitName : this.mission.circuits[0].circuitName,
          "circuitDescription": this.mission.circuits[0].circuitDescription == undefined ? this.mission.circuits[0].selectedExistingCircuit.circuitDescription : this.mission.circuits[0].circuitDescription,
        }
      ],
      // "circuits": [
      //   {
      //     "circuitId": this.mission.circuits[0].circuitId == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : null): this.mission.circuits[0].circuitId,
      //     "circuitLatitude": this.mission.circuits[0].circuitLatitude,
      //     "circuitLongitude": this.mission.circuits[0].circuitLongitude,
      //     "circuitName": this.mission.circuits[0].circuitName == "" ? this.mission.circuits[0].selectedExistingCircuit.circuitName : this.mission.circuits[0].circuitName,
      //     "circuitDescription": this.mission.circuits[0].circuitDescription == undefined ? this.mission.circuits[0].selectedExistingCircuit.circuitDescription : this.mission.circuits[0].circuitDescription,
      //   }
      // ],
      "checkpoints": [],
      "assignments": [
        {
          "campaignId": this.mission.campaignId,
          "userId": this.selectedFieldAgent.userId,
          "missionId": this.mission.missionId,
          "circuitId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
          //"circuitId": this.mission.circuits[0].circuitId == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : null) : this.mission.circuits[0].circuitId,
          //"checkpointId": this.mission.circuits[0].circuitCheckpoints == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[0].checkpointId : this.mission.checkpoints[0].checkpointId) : this.mission.circuits[0].circuitCheckpoints[0].checkpointId,
          "checkpointId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[0].checkpointId : this.mission.checkpoints[0].checkpointId,
          "shiftId": 1,
          "startDate": this.isShift == 'Morning' ? `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 10:00:00` : `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 12:30:00`,
          "endDate": this.isShift == 'Morning' ? `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 12:30:00` : `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 14:30:00`,
          "iterations": this.isShift == 'Morning' ? 5 : 4,
          "createdBy": this.user.userId,
          "updatedBy": this.user.userId,
          "status": 6
        },
        {
          "campaignId": this.mission.campaignId,
          "userId": this.selectedFieldAgent.userId,
          "missionId": this.mission.missionId,
          "circuitId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
          //"circuitId": this.mission.circuits[0].circuitId == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : null) : this.mission.circuits[0].circuitId,
          //"checkpointId": this.mission.circuits[0].circuitCheckpoints == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[0].checkpointId : this.mission.checkpoints[0].checkpointId) : this.mission.circuits[0].circuitCheckpoints[0].checkpointId,
          "checkpointId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[0].checkpointId : this.mission.checkpoints[0].checkpointId,
          "shiftId": 2,
          "startDate": this.isShift == 'Morning' ? `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 14:30:00` : `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 16:30:00`,
          "endDate": this.isShift == 'Morning' ? `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 16:30:00` : `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 19:00:00`,
          "iterations": this.isShift == 'Morning' ? 4 : 5,
          "createdBy": this.user.userId,
          "updatedBy": this.user.userId,
          "status": 6
        },

        {
          "campaignId": this.mission.campaignId,
          "userId": this.selectedFieldAgent.userId,
          "missionId": this.mission.missionId,
          "circuitId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
          //"circuitId": this.mission.circuits[0].circuitId == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : null) : this.mission.circuits[0].circuitId,
          //"checkpointId": this.mission.circuits[0].circuitCheckpoints == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[1].checkpointId : this.mission.checkpoints[1].checkpointId) : this.mission.circuits[0].circuitCheckpoints[1].checkpointId,
          "checkpointId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[1].checkpointId : this.mission.checkpoints[1].checkpointId,
          "shiftId":1,
          "startDate": this.isShift == 'Morning' ? `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 10:00:00` : `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 12:30:00`,
          "endDate": this.isShift == 'Morning' ? `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 12:30:00` : `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 14:30:00`,
          "iterations": this.isShift == 'Morning' ? 5 : 4,
          "createdBy": this.user.userId,
          "updatedBy": this.user.userId,
          "status": 6
        },
        {
          "campaignId": this.mission.campaignId,
          "userId": this.selectedFieldAgent.userId,
          "missionId": this.mission.missionId,
          "circuitId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
          //"circuitId": this.mission.circuits[0].circuitId == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : null) : this.mission.circuits[0].circuitId,
          //"checkpointId": this.mission.circuits[0].circuitCheckpoints == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[1].checkpointId : this.mission.checkpoints[1].checkpointId) : this.mission.circuits[0].circuitCheckpoints[1].checkpointId,
          "checkpointId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[1].checkpointId : this.mission.checkpoints[1].checkpointId,
          "shiftId": 2,
          "startDate": this.isShift == 'Morning' ? `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 14:30:00` : `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 16:30:00`,
          "endDate": this.isShift == 'Morning' ? `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 16:30:00` : `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 19:00:00`,
          "iterations": this.isShift == 'Morning' ? 4 : 5,
          "createdBy": this.user.userId,
          "updatedBy": this.user.userId,
          "status": 6
        },

        {
          "campaignId": this.mission.campaignId,
          "userId": this.selectedFieldAgent.userId,
          "missionId": this.mission.missionId,
          "circuitId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
          //"circuitId": this.mission.circuits[0].circuitId == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : null) : this.mission.circuits[0].circuitId,
          //"checkpointId": this.mission.circuits[0].circuitCheckpoints == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[2].checkpointId : this.mission.checkpoints[2].checkpointId) : this.mission.circuits[0].circuitCheckpoints[2].checkpointId,
          "checkpointId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[2].checkpointId : this.mission.checkpoints[2].checkpointId,
          "shiftId": 1,
          "startDate": this.isShift == 'Morning' ? `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 10:00:00` : `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 12:30:00`,
          "endDate": this.isShift == 'Morning' ? `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 12:30:00` : `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 14:30:00`,
          "iterations": this.isShift == 'Morning' ? 5 : 4,
          "createdBy": this.user.userId,
          "updatedBy": this.user.userId,
          "status": 6
        },
        {
          "campaignId": this.mission.campaignId,
          "userId": this.selectedFieldAgent.userId,
          "missionId": this.mission.missionId,
          "circuitId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
          //"circuitId": this.mission.circuits[0].circuitId == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : null) : this.mission.circuits[0].circuitId,
          //"checkpointId": this.mission.circuits[0].circuitCheckpoints == undefined ? (this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[2].checkpointId : this.mission.checkpoints[2].checkpointId) : this.mission.circuits[0].circuitCheckpoints[2].checkpointId,
          "checkpointId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[2].checkpointId : this.mission.checkpoints[2].checkpointId,
          "shiftId": 2,
          "startDate": this.isShift == 'Morning' ? `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 14:30:00` : `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 16:30:00`,
          "endDate": this.isShift == 'Morning' ? `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 16:30:00` : `${this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day} 19:00:00`,
          "iterations": this.isShift == 'Morning' ? 4 : 5,
          "createdBy": this.user.userId,
          "updatedBy": this.user.userId,
          "status": 6
        },
      ]
    };

    if (this.mission.circuits[0].circuitCheckpoints && this.existingCircuitsCheck){
      obj.checkpoints = [{
        //"circuitId": this.mission.circuits[0].circuitId,
        "circuitId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
        "checkpointId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[0].checkpointId : this.mission.circuits[0].circuitCheckpoints[0].checkpointId,
        "checkpointLatitude": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[0].checkpointLatitude : this.mission.circuits[0].circuitCheckpoints[0].checkpointLatitude,
        "checkpointLongitude": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[0].checkpointLongitude : this.mission.circuits[0].circuitCheckpoints[0].checkpointLongitude,
        "checkpointName": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[0].checkpointName : this.mission.circuits[0].circuitCheckpoints[0].checkpointName,
        "checkpointAddress": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[0].checkpointAddress : this.mission.circuits[0].circuitCheckpoints[0].checkpointAddress,
        "checkpointDescription": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[0].checkpointDescription : this.mission.circuits[0].circuitCheckpoints[0].checkpointDescription,
        "adptId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[0].adptId : this.mission.circuits[0].circuitCheckpoints[0].adptId
      },
      {
        //"circuitId": this.mission.circuits[0].circuitId,
        "circuitId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
        "checkpointId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[1].checkpointId : this.mission.circuits[0].circuitCheckpoints[1].checkpointId,
        "checkpointLatitude": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[1].checkpointLatitude : this.mission.circuits[0].circuitCheckpoints[1].checkpointLatitude,
        "checkpointLongitude": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[1].checkpointLongitude : this.mission.circuits[0].circuitCheckpoints[1].checkpointLongitude,
        "checkpointName": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[1].checkpointName : this.mission.circuits[0].circuitCheckpoints[1].checkpointName,
        "checkpointAddress": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[1].checkpointAddress : this.mission.circuits[0].circuitCheckpoints[1].checkpointAddress,
        "checkpointDescription": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[1].checkpointDescription : this.mission.circuits[0].circuitCheckpoints[1].checkpointDescription,
        "adptId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[1].adptId : this.mission.circuits[0].circuitCheckpoints[1].adptId
      },
      {
        //"circuitId": this.mission.circuits[0].circuitId,
        "circuitId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
        "checkpointId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[2].checkpointId : this.mission.circuits[0].circuitCheckpoints[2].checkpointId,
        "checkpointLatitude": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[2].checkpointLatitude : this.mission.circuits[0].circuitCheckpoints[2].checkpointLatitude,
        "checkpointLongitude": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[2].checkpointLongitude : this.mission.circuits[0].circuitCheckpoints[2].checkpointLongitude,
        "checkpointName": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[2].checkpointName : this.mission.circuits[0].circuitCheckpoints[2].checkpointName,
        "checkpointAddress": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[2].checkpointAddress : this.mission.circuits[0].circuitCheckpoints[2].checkpointAddress,
        "checkpointDescription": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[2].checkpointDescription : this.mission.circuits[0].circuitCheckpoints[2].checkpointDescription,
        "adptId": this.mission.circuits[0].existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[2].adptId : this.mission.circuits[0].circuitCheckpoints[2].adptId
      }]
    } else{
      obj.checkpoints = [{
        "circuitId": this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
        "checkpointId": this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[0].checkpointId : this.mission.checkpoints[0].checkpointId,
        "checkpointLatitude": this.mission.checkpoints[0].checkpointLatitude,
        "checkpointLongitude": this.mission.checkpoints[0].checkpointLongitude,
        "checkpointName": this.mission.checkpoints[0].checkpointName,
        "checkpointAddress": this.existingCircuitsCheck ? this.mission.checkpoints[0].checkpointAddress : this.mission.checkpoints[0].data.address,
        "checkpointDescription": this.existingCircuitsCheck ? this.mission.checkpoints[0].data.description : this.mission.checkpoints[0].checkpointDescription,
        "adptId": this.mission.checkpoints[0].data.adptid
      },
      {
        "circuitId": this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
        "checkpointId": this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[1].checkpointId : this.mission.checkpoints[1].checkpointId,
        "checkpointLatitude": this.mission.checkpoints[1].checkpointLatitude,
        "checkpointLongitude": this.mission.checkpoints[1].checkpointLongitude,
        "checkpointName": this.mission.checkpoints[1].checkpointName,
        "checkpointAddress": this.existingCircuitsCheck ? this.mission.checkpoints[1].checkpointAddress : this.mission.checkpoints[1].data.address,
        "checkpointDescription": this.mission.checkpoints[1].data.description,
        "adptId": this.mission.checkpoints[1].data.adptid
      },
      {
        "circuitId": this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitId : this.mission.circuits[0].circuitId,
        "checkpointId": this.existingCircuitsCheck ? this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints[2].checkpointId : this.mission.checkpoints[2].checkpointId,
        "checkpointLatitude": this.mission.checkpoints[2].checkpointLatitude,
        "checkpointLongitude": this.mission.checkpoints[2].checkpointLongitude,
        "checkpointName": this.mission.checkpoints[2].checkpointName,
        "checkpointAddress": this.existingCircuitsCheck ? this.mission.checkpoints[2].checkpointAddress : this.mission.checkpoints[2].data.address,
        "checkpointDescription": this.mission.checkpoints[2].data.description,
        "adptId": this.mission.checkpoints[2].data.adptid
      }]
    }
    return obj;

  }
  editMission() {
    console.log('Mission', this.mission);
    this.event.broadcast({ eventName: 'showLoader', data: {} })
    let checkpointLength = this.mission.checkpoints.length;
    this.mission.checkpoints.forEach(checkpoint => {
      if (this.mission.circuits[0].circuitCheckpoints){
        if (this.mission.circuits[0].existingCircuitsCheck){
          this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints.forEach(res => {
            if (res.checkpointId == checkpoint.id) {
              res.checkpointAddress = checkpoint.selected_adrn + ', ' +
                checkpoint.selected_street + ', ' +
                checkpoint.selected_commune + ', ' +
                checkpoint.selected_region + ', ' +
                checkpoint.selected_postalcode + ', ' +
                checkpoint.selected_country
            }
          });
        } else {
          this.mission.circuits[0].circuitCheckpoints.forEach(res => {
            if (res.checkpointId == checkpoint.id ){
              res.checkpointAddress = checkpoint.selected_adrn + ', ' +
              checkpoint.selected_street + ', ' +
              checkpoint.selected_commune + ', ' +
              checkpoint.selected_region + ', ' +
              checkpoint.selected_postalcode + ', ' +
              checkpoint.selected_country
            }
          });
        }
      } else{
        if (this.existingCircuitsCheck){
          checkpoint.checkpointAddress = checkpoint.selected_adrn + ', ' +
          checkpoint.selected_street + ', ' +
          checkpoint.selected_commune + ', ' +
          checkpoint.selected_region + ', ' +
          checkpoint.selected_postalcode + ', ' +
          checkpoint.selected_country
        } else{
          checkpoint.checkpointAddress = checkpoint.data.address;
        }
      }
    });

    this.mission.circuits.forEach(circuit => {
      if (circuit.circuitId && !circuit.ogImage && this.existingCircuitsCheck) {
        const formData = new FormData();
        const XHR = new XMLHttpRequest();
        formData.append('imageType', 'circuit');
        formData.append('uploadedBy', this.user.userId);
        formData.append('circuitId', circuit.circuitId);
        formData.append('image', circuit.image, ((new Date).getTime()).toString() + '_' + circuit.image.name);
        const fileName = circuit.image.name.replace(' ', '_');
        XHR.addEventListener('load', (event) => { });
        XHR.onreadystatechange = (aEvt) => {
          if (XHR.readyState === 4) {
            if (XHR.status === 200) {
              const response = JSON.parse(XHR.response);
              this.http.SecurePost('/mission/editMission', this.editMissionRequestBody()).subscribe(res => {
                  if (res.responseCode == 200) {
                    this.event.broadcast({ eventName: 'hideLoader', data: {} });
                    this.pedestrainAlertsService.missionUpdateSuccess()
                      .then(() => { this.router.navigate(['supervisor/missions']); });
                  }
              }, err => {
              this.event.broadcast({ eventName: 'hideLoader', data: {} });
                this.pedestrainAlertsService.somethingWentWrong()
              });


            } else {
              this.pedestrainAlertsService.somethingWentWrong();
            }
          }
        };
        XHR.addEventListener('error', (event) => {
          this.event.broadcast({ eventName: 'hideLoader', data: '' });
          this.pedestrainAlertsService.somethingWentWrongQuestion();
        });
        XHR.open('POST', this.xmlHttpUrl + '/image/uploadImage');
        XHR.setRequestHeader('Authorization', this.user.accessToken);
        XHR.setRequestHeader('userId', this.user.userId);
        XHR.send(formData);
      } else if (circuit.circuitId && circuit.ogImage && this.existingCircuitsCheck){
        this.http.SecurePost('/mission/editMission', this.editMissionRequestBody()).subscribe(res => {
        if (res.responseCode == 200) {
          this.event.broadcast({ eventName: 'hideLoader', data: {} });
          this.pedestrainAlertsService.missionUpdateSuccess()
            .then(() => { this.router.navigate(['supervisor/missions']); });
        }
        }, err => {
        this.event.broadcast({ eventName: 'hideLoader', data: {} });
          this.pedestrainAlertsService.somethingWentWrong()
        });
      }
      else {
        this.createCircuit();
        // this.http.SecurePost('/mission/editMission', this.editMissionRequestBody()).subscribe(res => {
        // if (res.responseCode == 200) {
        //   this.event.broadcast({ eventName: 'hideLoader', data: {} });
        //   this.pedestrainAlertsService.missionUpdateSuccess()
        //     .then(() => { this.router.navigate(['supervisor/missions']); });
        // }
        // }, err => {
        // this.event.broadcast({ eventName: 'hideLoader', data: {} });
        //   this.pedestrainAlertsService.somethingWentWrong()
        // });
      }
    });

    // else if (circuit.circuitId == undefined && circuit.image) {
    //   this.createCircuit();
    // } 


    // this.submitdisabled = true;
    // this.event.broadcast({ eventName: 'showLoader', data: '' });
    // this.validateMission(() => {
    //   if (this.mission.circuits[0].existingCircuitsCheck) {
    //     this.newCircuit = true;
    //     this.missionCreator();
    //   } else {
    //     const editCheckpoints = [];
    //     const createCheckpoint = [];
    //     let datalength = this.database.length;
    //     this.database.forEach(dao => {
    //       if (dao.id) {
    //         editCheckpoints.push(this.mission.checkpoints[dao.index]);
    //       } else {
    //         createCheckpoint.push(this.mission.checkpoints[dao.index]);
    //       }
    //       datalength--;
    //       if (datalength === 0) {
    //         if (createCheckpoint.length !== 0) {
    //           this.missionCreator();
    //         } else {
    //           let circlen = this.mission.circuits.length;
    //           this.mission.circuits.forEach(circuit => {
    //             if (circuit.circuitId && !circuit.ogImage) {
    //               const formData = new FormData();
    //               const XHR = new XMLHttpRequest();
    //               formData.append('imageType', 'circuit');
    //               formData.append('uploadedBy', this.user.userId);
    //               formData.append('circuitId', circuit.circuitId);
    //               formData.append('image', circuit.image, ((new Date).getTime()).toString() + '_' + circuit.image.name);
    //               const fileName = circuit.image.name.replace(' ', '_');
    //               XHR.addEventListener('load', (event) => { });
    //               XHR.onreadystatechange = (aEvt) => {
    //                 if (XHR.readyState === 4) {
    //                   if (XHR.status === 200) {
    //                     const response = JSON.parse(XHR.response);
    //                     circlen--;
    //                     if (circlen === 0) {
    //                       this.missionUpdater();
    //                     }
    //                   } else {
    //                     this.pedestrainAlertsService.somethingWentWrong();
    //                   }
    //                 }
    //               };
    //               XHR.addEventListener('error', (event) => {
    //                 this.event.broadcast({ eventName: 'hideLoader', data: '' });
    //                 this.pedestrainAlertsService.somethingWentWrongQuestion();
    //               });
    //               XHR.open('POST', this.xmlHttpUrl + '/image/uploadImage');
    //               XHR.setRequestHeader('Authorization', this.user.accessToken);
    //               XHR.setRequestHeader('userId', this.user.userId);
    //               XHR.send(formData);
    //             } else {
    //               circlen--;
    //               if (circlen === 0) {
    //                 this.missionUpdater();
    //               }
    //             }
    //           });
    //         }
    //       }
    //     });
    //   }
    // });
    
  }
  missionCreator() {
    if (this.newCircuit) {
      this.createCircuit();
    } else {
      this.checkpointCreator();
    }
  }
  createCircuit() {
    this.event.broadcast({ eventName: 'changeLoaderMessage', data: 'CREATING CIRCUIT...' });
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    let circuitsLen = this.mission.circuits.length;
    this.mission.circuits.forEach(circuit => {
      if (circuit.existingCircuitsCheck) {
        const formData = new FormData();
        const XHR = new XMLHttpRequest();
        formData.append('missionId', this.mission.missionId);
        formData.append('existingCircuitId', circuit.selectedExistingCircuit.circuitId);
        formData.append('circuitCreatedBy', circuit.selectedExistingCircuit.circuitCreatedById);
        formData.append('circuitUpdatedBy', this.user.userId);
        XHR.addEventListener('load', (event) => { });
        XHR.onreadystatechange = (aEvt) => {
          if (XHR.readyState === 4) {
            if (XHR.status === 200) {
              const response = JSON.parse(XHR.response);
              circuitsLen--;
              if (circuitsLen === 0) {
                this.event.broadcast({ eventName: 'changeLoaderMessage', data: 'CHECKPOINTS CREATED...' });
                this.missionUpdater();
              }
            } else {
              this.pedestrainAlertsService.somethingWentWrong();
            }
          }
        };
        XHR.addEventListener('error', (event) => {
          this.event.broadcast({ eventName: 'hideLoader', data: '' });
          this.pedestrainAlertsService.somethingWentWrongQuestion();
        });
        XHR.open('POST', this.xmlHttpUrl + '/circuit/addCircuit');
        XHR.setRequestHeader('Authorization', this.user.accessToken);
        XHR.setRequestHeader('userId', this.user.userId);
        XHR.send(formData);
      } else {
        const formData = new FormData();
        const XHR = new XMLHttpRequest();
        formData.append('missionId', this.mission.missionId);
        formData.append('circuitName', circuit.circuitName);
        formData.append('circuitLatitude', circuit.circuitLatitude);
        formData.append('circuitLongitude', circuit.circuitLongitude);
        formData.append('circuitCreatedBy', this.user.userId);
        formData.append('circuitUpdatedBy', this.user.userId);
        formData.append('locationId', "0");
        formData.append('locationTypeId', "1");
        formData.append('images', circuit.image, ((new Date).getTime()).toString() + '_' + circuit.image.name);
        const fileName = circuit.image.name.replace(' ', '_');
        XHR.addEventListener('load', (event) => { });
        XHR.onreadystatechange = (aEvt) => {
          if (XHR.readyState === 4) {
            if (XHR.status === 200) {
              const response = JSON.parse(XHR.response);
              this.event.broadcast({ eventName: 'changeLoaderMessage', data: 'CIRCUIT CREATED...' });
              const id = response.responseMessage.split('! ')[2];
              circuitsLen--;
              if (circuitsLen === 0) {
                this.mission.circuits[0].circuitId = id;
                this.checkpointCreator();
                this.event.broadcast({ eventName: 'changeLoaderMessage', data: 'CREATING CHECKPOINTS...' });
              }
            } else {
              this.pedestrainAlertsService.somethingWentWrong();
            }
          }
        };
        XHR.addEventListener('error', (event) => {
          this.event.broadcast({ eventName: 'hideLoader', data: '' });
          this.pedestrainAlertsService.somethingWentWrongQuestion();
        });
        XHR.open('POST', this.xmlHttpUrl + '/circuit/addCircuit');
        XHR.setRequestHeader('Authorization', this.user.accessToken);
        XHR.setRequestHeader('userId', this.user.userId);
        XHR.send(formData);
      }
    });
  }
  checkpointCreator() {
    const idNotPresent = [];
    let checkpointLength = this.mission.checkpoints.length;
    this.mission.checkpoints.forEach((checkpoint, ind) => {
      if (!checkpoint.checkpointId) {
        idNotPresent.push(ind);
      }
      checkpointLength--;
      if (checkpointLength === 0) {
        if (idNotPresent.length !== 0) {
          this.addCheckpoints(idNotPresent);
        }
      }
    });
  }
  addCheckpoints(ids) {
    this.checkpointIndexes = ids;
    this.checkpointIndexes.sort((a, b) => {
      return a - b;
    });
    this.updateCheckpointObjectCreator(0);
  }
  updateCheckpointObjectCreator(index) {
    const idLength = this.checkpointIndexes.length;
    if (idLength !== index) {
      this.sendCheckpoint(this.checkpointIndexes[index], () => {
        const ind = index + 1;
        this.updateCheckpointObjectCreator(ind);
      });
    } else {
      this.event.broadcast({ eventName: 'changeLoaderMessage', data: 'CHECKPOINTS CREATED...' });
      this.missionUpdater();
    }
  }
  sendCheckpoint(i, cb) {
    const checkpoint = this.mission.checkpoints[i];
    const fd = new FormData();
    const XHR = new XMLHttpRequest();
    fd.append('circuitId', this.mission.circuits[0].circuitId);
    fd.append('checkpointName', checkpoint.checkpointName);
    fd.append('checkpointDescription', checkpoint.checkpointDescription);
    fd.append('checkpointAddress', checkpoint.selected_adrn.adt_adrn + ', ' +
      checkpoint.selected_street.adt_street + ', ' +
      checkpoint.selected_commune.com_commune_name_fr + ', ' +
      checkpoint.selected_region.reg_region_name_fr + ', ' +
      checkpoint.selected_postalcode.adt_postal_code + ', ' +
      checkpoint.selected_country.con_country_name_fr);
    fd.append('checkpointLatitude', checkpoint.checkpointLatitude);
    fd.append('checkpointLongitude', checkpoint.checkpointLongitude);
    fd.append('checkpointCreatedBy', this.user.userId);
    fd.append('checkpointUpdatedBy', this.user.userId);
    fd.append('adptId', checkpoint.data.adptid);
    fd.append('position', (i+1));
    XHR.addEventListener('load', function (event) { });
    XHR.onreadystatechange = (aEvt) => {
      if (XHR.readyState === 4) {
        if (XHR.status === 200) {
          const response = JSON.parse(XHR.response);
          const id = response.responseMessage.split('! ')[2];
          checkpoint.checkpointId = parseInt(id, 10);
          cb();
        } else {
          this.pedestrainAlertsService.somethingWentWrong();
        }
      }
    };
    XHR.addEventListener('error', (event) => {
    });
    XHR.open('POST', this.xmlHttpUrl + '/checkpoint/addCheckpoint');
    XHR.setRequestHeader('Authorization', this.user.accessToken);
    XHR.setRequestHeader('userId', this.user.userId);
    XHR.send(fd);
  }
  missionUpdater() {
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this.event.broadcast({ eventName: 'changeLoaderMessage', data: 'UPDATING MISSION...' });
    const reqObj = {
      mission: {
        missionId: this.mission.missionId,
        missionDescription: this.mission.missionDescription,
        missionStartDate: this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day + ' 00:00:00',
        missionEndDate: this.mission.taskTypeId === 3 ?
          this.mission.startDate.year + '-' + this.mission.startDate.month + '-' + this.mission.startDate.day + ' 00:00:00' :
          this.mission.endDate.year + '-' + this.mission.endDate.month + '-' + this.mission.endDate.day + ' 00:00:00',
        missionName: this.mission.missionName,
        missionTypeId: 3
      },
      circuits: [],
      checkpoints: [],
      assignments: []
    };
    
    this.http.SecurePost('/mission/editMission', this.editMissionRequestBody()).subscribe(res => {
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
      this.pedestrainAlertsService.missionUpdateSuccess()
        .then(() => { this.location.back(); }).catch(() => { this.location.back(); });
    }, err => { this.pedestrainAlertsService.somethingWentWrong(); });
    // this.circuitEditor(reqObj, (req) => {
    //   this.checkpointEditor(req, (req2) => {
    //     this.assignmentEditor(req2, (req3) => {
    //       this.http.SecurePost('/mission/editMission', req3).subscribe(res => {
    //         this.event.broadcast({ eventName: 'hideLoader', data: '' });
    //         this.pedestrainAlertsService.missionUpdateSuccess()
    //           .then(() => { this.location.back(); }).catch(() => { this.location.back(); });
    //       }, err => { this.pedestrainAlertsService.somethingWentWrong(); });
    //     });
    //   });
    // });
  }

  circuitEditor(reqObj, cb) {
    let circuitLen = this.mission.circuits.length;
    this.mission.circuits.forEach(circuit => {
      const circuitReq = {
        circuitId: circuit.existingCircuitsCheck ? circuit.selectedExistingCircuit.circuitId : circuit.circuitId,
        circuitLatitude: circuit.existingCircuitsCheck ? circuit.selectedExistingCircuit.circuitLatitude : circuit.circuitLatitude,
        circuitLongitude: circuit.existingCircuitsCheck ? circuit.selectedExistingCircuit.circuitLongitude : circuit.circuitLongitude,
        circuitName: circuit.existingCircuitsCheck ? circuit.selectedExistingCircuit.circuitName : circuit.circuitName,
        circuitDescription: 'Edit Ok'
      };
      reqObj.circuits.push(circuitReq);
      circuitLen--;
      if (circuitLen === 0) {
        cb(reqObj);
      }
    });
  }

  checkpointEditor(reqObj, cb) {
    let checkpointLength = this.mission.checkpoints.length;
    this.mission.checkpoints.forEach(checkpoint => {
      const checkpointReq = {
        circuitId: checkpoint.selectedCircuit.circuitId,
        checkpointId: checkpoint.checkpointId ? checkpoint.checkpointId : checkpoint.id,
        checkpointLatitude: checkpoint.checkpointLatitude,
        checkpointLongitude: checkpoint.checkpointLongitude,
        checkpointName: checkpoint.checkpointName,
        checkpointAddress: checkpoint.selected_adrn.adt_adrn + ', ' +
          checkpoint.selected_street.adt_street + ', ' +
          checkpoint.selected_commune.com_commune_name_fr + ', ' +
          checkpoint.selected_region.reg_region_name_fr + ', ' +
          checkpoint.selected_postalcode.adt_postal_code + ', ' +
          checkpoint.selected_country.con_country_name_fr,
        checkpointDescription: checkpoint.checkpointDescription,
        adptId: checkpoint.data.adptid
      };
      reqObj.checkpoints.push(checkpointReq);
      checkpointLength--;
      if (checkpointLength === 0) {
        cb(reqObj);
      }
    });
  }

  assignmentEditor(reqObj, cb) {
    let count = 0;
    let checkerCount = this.mission.assignments.length;
    this.mission.assignments.forEach(assignment => {
      const indiCount = assignment.selectedCheckpoints.length * assignment.selectedShifts.length;
      count = count + indiCount;
      checkerCount--;
      if (checkerCount === 0) {
        this.assignmentLooper(count, reqObj, (req2) => {
          cb(req2);
        });
      }
    });
  }
  assignmentLooper(count, reqObj, cb) {
    this.mission.assignments.forEach(assignment => {
      assignment.selectedCheckpoints.forEach(checkpoint => {
        assignment.tempCheckpoints.forEach(check => {
          if (check.checkpointName === checkpoint) {
            assignment.selectedShifts.forEach(shift => {
              if (shift === '10:00 - 12:30') {
                assignment.tempShifts.forEach(sh => {
                  if (sh.timeRange === shift) {
                    reqObj.assignments.push({
                      campaignId: this.mission.campaignId,
                      userId: assignment.selectedFieldAgent.userId,
                      missionId: reqObj.mission.missionId,
                      circuitId: check.selectedCircuit.circuitId,
                      checkpointId: check.checkpointId ? check.checkpointId : check.id,
                      shiftId: 1,
                      startDate: reqObj.mission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
                      endDate: reqObj.mission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
                      iterations: 5,
                      createdBy: this.user.userId,
                      updatedBy: this.user.userId,
                      status: 1
                    });
                    count--;
                    if (count === 0) {
                      cb(reqObj);
                    }
                  }
                });
              } else if (shift === '12:30 - 14:30') {
                assignment.tempShifts.forEach(sh => {
                  if (sh.timeRange === shift) {
                    reqObj.assignments.push({
                      campaignId: this.mission.campaignId,
                      userId: assignment.selectedFieldAgent.userId,
                      missionId: reqObj.mission.missionId,
                      circuitId: check.selectedCircuit.circuitId,
                      checkpointId: check.checkpointId ? check.checkpointId : check.id,
                      shiftId: 1,
                      startDate: reqObj.mission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
                      endDate: reqObj.mission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
                      iterations: 4,
                      createdBy: this.user.userId,
                      updatedBy: this.user.userId,
                      status: 1
                    });
                    count--;
                    if (count === 0) {
                      cb(reqObj);
                    }
                  }
                });
              } else if (shift === '14:30 - 16:30') {
                assignment.tempShifts.forEach(sh => {
                  if (sh.timeRange === shift) {
                    reqObj.assignments.push({
                      campaignId: this.mission.campaignId,
                      userId: assignment.selectedFieldAgent.userId,
                      missionId: reqObj.mission.missionId,
                      circuitId: check.selectedCircuit.circuitId,
                      checkpointId: check.checkpointId ? check.checkpointId : check.id,
                      shiftId: 2,
                      startDate: reqObj.mission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
                      endDate: reqObj.mission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
                      iterations: 4,
                      createdBy: this.user.userId,
                      updatedBy: this.user.userId,
                      status: 1
                    });
                    count--;
                    if (count === 0) {
                      cb(reqObj);
                    }
                  }
                });
              } else if (shift === '16:30 - 19:00') {
                assignment.tempShifts.forEach(sh => {
                  if (sh.timeRange === shift) {
                    reqObj.assignments.push({
                      campaignId: this.mission.campaignId,
                      userId: assignment.selectedFieldAgent.userId,
                      missionId: reqObj.mission.missionId,
                      circuitId: check.selectedCircuit.circuitId,
                      checkpointId: check.checkpointId ? check.checkpointId : check.id,
                      shiftId: 2,
                      startDate: reqObj.mission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
                      endDate: reqObj.mission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
                      iterations: 5,
                      createdBy: this.user.userId,
                      updatedBy: this.user.userId,
                      status: 1
                    });
                    count--;
                    if (count === 0) {
                      cb(reqObj);
                    }
                  }
                });
              }
            });
          }
        });
      });
    });
  }

  /* PULL API integrations
    1. getCountries(i, icb)
    2. getRegions(i, icb)
    3. getCommunes(i, icb)
    4. getPostalCodes(i, icb)
    5. getStreets(i, icb)
    6. getAdrns(i, icb)
    7. getAdptId(i, icb)
    8. callAdptIdData(e, i)
    9. streetChecker(val)
  */

  getCountries(i, icb) {
    if (this.mission.checkpoints.length > 1 && i !== 0) {
      this.mission.checkpoints[i].selected_country = this.mission.checkpoints[i - 1].selected_country;
      this.mission.checkpoints[i].countryLoaded = true;
      icb();
    } else {
      this.http.pullCountry().subscribe(res => {
        let countryLen = res.data['Geographic Data'].length;
        this.mission.checkpoints[i].coutries = [];
        res.data['Geographic Data'].forEach(country => {
          this.mission.checkpoints[i].coutries.push(country);
          countryLen--;
          if (countryLen === 0) {
            this.mission.checkpoints[i].selected_country = this.mission.checkpoints[i].coutries[0];
            this.mission.checkpoints[i].coutries.splice(0, 1);
            this.mission.checkpoints[i].countryLoaded = true;
            icb();
          }
        });
      }, err => { });
    }
  }

  getRegions(i, icb) {
    if (this.mission.checkpoints.length > 1 && i !== 0) {
      this.mission.checkpoints[i].selected_region = this.mission.checkpoints[i - 1].selected_region;
      this.mission.checkpoints[i].regionLoaded = true;
      icb();
    } else {
      this.http.pullRegion(this.mission.checkpoints[i].selected_country.con_id).subscribe(reg => {
        if (reg.data['Geographic Data'].length !== 0) {
          let regionLen = reg.data['Geographic Data'].length;
          this.mission.checkpoints[i].regions = [];
          reg.data['Geographic Data'].forEach(region => {
            this.mission.checkpoints[i].regions.push(region);
            regionLen--;
            if (regionLen === 0) {
              this.mission.checkpoints[i].selected_region = this.mission.checkpoints[i].regions[0];
              this.mission.checkpoints[i].regions.splice(0, 1);
              this.mission.checkpoints[i].regionLoaded = true;
              icb();
            }
          });
        } else {
          this.pedestrainAlertsService.postCodeNotAvailableAlert();
          this.mission.checkpoints[i].data.adptid = null;
          this.mission.checkpoints[i].data.quartier = undefined;
        }
      }, err => { });
    }
  }

  getCommunes(i, icb) {
    // if (this.mission.checkpoints.length > 1 && i !== 0) {
    //   this.mission.checkpoints[i].selected_commune = this.mission.checkpoints[i - 1].selected_commune;
    //   this.mission.checkpoints[i].communeLoaded = true;
    //   icb();
    // } else {
      this.http.pullCommune(this.mission.checkpoints[i].selected_region.reg_id).subscribe(com => {
        if (com.data['Geographic Data'].length !== 0) {
          let communeLen = com.data['Geographic Data'].length;
          this.mission.checkpoints[i].communes = [];
          com.data['Geographic Data'].forEach(commune => {
            this.mission.checkpoints[i].communes.push(commune);
            communeLen--;
            if (communeLen === 0) {
              this.mission.checkpoints[i].selected_commune = this.mission.checkpoints[i].communes[0];
              this.mission.checkpoints[i].communes.splice(0, 1);
              this.mission.checkpoints[i].communeLoaded = true;
              icb();
            }
          });
        } else {
          this.pedestrainAlertsService.postCodeNotAvailableAlert();
          this.mission.checkpoints[i].data.adptid = null;
          this.mission.checkpoints[i].data.quartier = undefined;
        }
      }, err => { });
    // }
  }

  getPostalCodes(i, icb) {
    // if (this.mission.checkpoints.length > 1 && i !== 0) {
    //   this.mission.checkpoints[i].selected_postalcode = this.mission.checkpoints[i - 1].selected_postalcode;
    //   this.mission.checkpoints[i].postalCodeLoaded = true;
    //   icb();
    // } else {
      this.http.pullPostalCode(this.mission.checkpoints[i].selected_commune.com_id).subscribe(pcode => {
        if (pcode.data['Geographic Data'].length !== 0) {
          let pcodeLen = pcode.data['Geographic Data'].length;
          this.mission.checkpoints[i].postalcodes = [];
          pcode.data['Geographic Data'].forEach(postalCode => {
            this.mission.checkpoints[i].postalcodes.push(postalCode);
            pcodeLen--;
            if (pcodeLen === 0) {
              this.mission.checkpoints[i].selected_postalcode = this.mission.checkpoints[i].postalcodes[0];
              this.mission.checkpoints[i].postalcodes.splice(0, 1);
              this.mission.checkpoints[i].postalCodeLoaded = true;
              icb();
            }
          });
        } else {
          this.pedestrainAlertsService.postCodeNotAvailableAlert();
          this.mission.checkpoints[i].data.adptid = null;
          this.mission.checkpoints[i].data.quartier = undefined;
        }
      }, err => { });
    // }
  }
  getStreets(i, icb) {
    this.http.pullStreet(this.mission.checkpoints[i].selected_postalcode.adt_postal_code).subscribe(roads => {
      if (roads.data['Geographic Data'].length !== 0) {
        this.mission.checkpoints[i].streetSearchBucket = [];
        let roadsLen = roads.data['Geographic Data'].length;
        this.mission.checkpoints[i].streets = [];
        roads.data['Geographic Data'].forEach(street => {
          this.mission.checkpoints[i].streets.push(street);
          street.adt_street !== null ? this.mission.checkpoints[i].streetSearchBucket.push(street.adt_street) : '';
          roadsLen--;
          if (roadsLen === 0) {
            this.mission.checkpoints[i].selected_street = this.mission.checkpoints[i].streets[0];
            this.mission.checkpoints[i].streets.splice(0, 1);
            this.mission.checkpoints[i].streetSearch = (text$: Observable<string>) =>
              text$
                .debounceTime(200)
                .distinctUntilChanged()
                .map(
                  term =>
                    term === ''
                      ? []
                      : this.mission.checkpoints[i].streetSearchBucket
                        .filter(v =>
                          v.toLowerCase().indexOf(term.toLowerCase()) > -1)
                        .slice(0, 10)
                );
            this.mission.checkpoints[i].streetLoaded = true;
            icb();
          }
        });
      } else {
        this.pedestrainAlertsService.streetsNotAvailableAlert();
        this.mission.checkpoints[i].data.adptid = null;
        this.mission.checkpoints[i].data.quartier = undefined;
      }
    }, err => { });
  }
  getAdrns(i, icb) {
    this.http.pullAdrn(this.mission.checkpoints[i].selected_postalcode.adt_postal_code,
      this.mission.checkpoints[i].selected_street.adt_street).subscribe(ad => {
        if (ad.data['Geographic Data'].length !== 0) {
          this.mission.checkpoints[i].adrns = (filter(ad.data['Geographic Data'], (adrn) => {
            if (!isNull(adrn.adt_adrn)) return adrn;
          }));
          this.mission.checkpoints[i]['selected_adrn'] = this.mission.checkpoints[i].adrns[0];
          this.mission.checkpoints[i].adrns.splice(0, 1);
          this.mission.checkpoints[i].adrnLoaded = true;
          icb();
        } else {
          this.pedestrainAlertsService.adrnNotAvailableAlert();
          this.mission.checkpoints[i].data = { ...this.mission.checkpoints[i].data, adptid: null, quartier: undefined };
        }
      }, err => { });
  }

  getAdptId(i, icb) {
    this.http.pullAdptId(this.mission.checkpoints[i].selected_postalcode.adt_postal_code,
      this.mission.checkpoints[i].selected_street.adt_street,
      this.mission.checkpoints[i].selected_adrn.adt_adrn).subscribe(adpt => {
        if (adpt.data['Geographic Data'].length !== 0) {
          if (this.mission.checkpoints.length === 3) {
            const availableCheckpointsAdptids = [];
            let lent = this.mission.checkpoints.length;
            let letItGo = false;
            const countInArray = (array, what) => {
              return array.filter(item => item == what).length;
            };
            this.mission.checkpoints.forEach((checkp, inde) => {
              if (inde !== i) {
                availableCheckpointsAdptids.push(parseInt(checkp.data.adptid, 10));
                let count = countInArray(availableCheckpointsAdptids, checkp.data.adptid);
                if (count > 1) {
                  letItGo = true;
                }
              } else {
                availableCheckpointsAdptids.push(parseInt(adpt.data['Geographic Data'][0].adt_adptid, 10));
                let count = countInArray(availableCheckpointsAdptids, adpt.data['Geographic Data'][0].adt_adptid);
                if (count > 1) {
                  letItGo = true;
                }
              }
              lent--;
              if (lent === 0) {
                if (!letItGo && availableCheckpointsAdptids.length === 3) {
                  this.http.SecurePost('/checkpoint/validateCheckpoints', {
                    adptIds: availableCheckpointsAdptids
                  }).subscribe(res => {
                    this.pedestrainAlertsService.adptidsAlreadyExist()
                      .then(() => {
                        this.event.broadcast({ eventName: 'showLoader', data: '' });
                        if (this.mission.checkpoints.length === 3) {
                          this.mission.checkpoints.splice(2, 1);
                          this.showAddNewCheckpoint = true;
                          if (this.checkpointMapGeoJSON.features.length === 3) {
                            this.checkpointMapGeoJSON.features.splice(2, 1);
                          }
                          const circuitObject = {
                            selectedMission: this.mission.checkpoints[0].selectedMission,
                            missions: [],
                            existingCircuitsCheck: true,
                            ogImage: true,
                            existingCircuits: [],
                            circuitLongitude: res.data.circuitLongitude,
                            circuitLatitude: res.data.circuitLatitude,
                            tempExistingCircuits: [],
                            existingCircuitSearch: undefined,
                            selectedExistingCircuit: res.data,
                            checkpointsGeoJson: {
                              'type': 'FeatureCollection',
                              'features': [
                                {
                                  'type': 'Feature',
                                  'geometry': {
                                    'type': 'Point',
                                    'coordinates': [res.data.circuitCheckpoints[0].checkpointLongitude,
                                    res.data.circuitCheckpoints[0].checkpointLatitude]
                                  },
                                  'lnglat': [parseFloat(Number(res.data.circuitCheckpoints[0].checkpointLongitude).toFixed(20)),
                                  parseFloat(Number(res.data.circuitCheckpoints[0].checkpointLatitude).toFixed(20))],
                                  'checkpointName': res.data.circuitCheckpoints[0].checkpointName
                                },
                                {
                                  'type': 'Feature',
                                  'geometry': {
                                    'type': 'Point',
                                    'coordinates': [res.data.circuitCheckpoints[1].checkpointLongitude,
                                    res.data.circuitCheckpoints[1].checkpointLatitude]
                                  },
                                  'lnglat': [parseFloat(Number(res.data.circuitCheckpoints[1].checkpointLongitude).toFixed(20)),
                                  parseFloat(Number(res.data.circuitCheckpoints[1].checkpointLatitude).toFixed(20))],
                                  'checkpointName': res.data.circuitCheckpoints[1].checkpointName
                                },
                                {
                                  'type': 'Feature',
                                  'geometry': {
                                    'type': 'Point',
                                    'coordinates': [res.data.circuitCheckpoints[2].checkpointLongitude,
                                    res.data.circuitCheckpoints[2].checkpointLatitude]
                                  },
                                  'lnglat': [parseFloat(Number(res.data.circuitCheckpoints[2].checkpointLongitude).toFixed(20)),
                                  parseFloat(Number(res.data.circuitCheckpoints[2].checkpointLatitude).toFixed(20))],
                                  'checkpointName': res.data.circuitCheckpoints[2].checkpointName
                                }
                              ]
                            },
                            data: {
                              circuitName: '',
                              search: '',
                              lnglat: ['4.4699', '50.5039'],
                              imageUploaded: true,
                              progress: 0,
                              uploadProgress: false
                            }
                          };
                          this.mission.circuits = [];
                          this.mission.circuits.push(circuitObject);
                          this.mission.checkpoints = [];
                          this.mission.assignments = [];
                          this.existingCircuitsCheck = true;
                          this.populateExistingCheckpoints();
                          this.event.broadcast({ eventName: 'hideLoader', data: '' });
                        }
                      })
                      .catch(() => { this.pedestrainAlertsService.sameCheckPointsNotAllowedAlert().then(() => { }).catch(); });
                  }, err => {
                    this.utils.getCheckpointWithAdptid(adpt.data['Geographic Data'][0].adt_adptid, (status, response) => {
                      if (status === 200) {
                        this.mission.checkpoints[i].checkpointName = response.data.checkpoints[0].checkpointName;
                        this.mission.checkpoints[i].checkpointDescription = response.data.checkpoints[0].checkpointDescription;
                        this.mission.checkpoints[i].checkpointNameDisabled = true;

                        this.taged = [];
                        const obj = this.mission.checkpoints.filter(res => res.checkpointName);
                        obj.forEach(itm => this.taged.push(itm.checkpointName));

                        this.checkpointsValidator(valid => {
                          if (valid) {
                            this.mission.assignments = [];
                            this.assignmentFiller('noAssignment', () => { });
                          } else {
                            this.mission.assignments = [];
                          }
                        });
                        this.uniqueAdptIDPopup();
                      } else {
                        this.mission.checkpoints[i].checkpointName = '';
                        this.mission.checkpoints[i].checkpointDescription = '';
                        this.mission.checkpoints[i].checkpointNameDisabled = false;
                        this.taged = [];
                        const obj = this.mission.checkpoints.filter(res => res.checkpointName);
                        obj.forEach(itm => this.taged.push(itm.checkpointName));
                      }
                    });
                    this.mission.checkpoints[i].data.lnglat = [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                    adpt.data['Geographic Data'][0].adt_latitude_wgs84];
                    this.mission.checkpoints[i].data.adptid = 0;
                    this.mission.checkpoints[i].data.adptid = adpt.data['Geographic Data'][0].adt_adptid;
                    this.mission.checkpoints[i].data.quartier =
                      adpt.data['Geographic Data'][0].qub_quartier_name_fr;
                    this.mission.checkpoints[i].data.address = adpt.data['Geographic Data'][0].adt_adrn + ', ' +
                      adpt.data['Geographic Data'][0].adt_street + ', ' +
                      adpt.data['Geographic Data'][0].com_commune_name_fr + ', ' +
                      adpt.data['Geographic Data'][0].reg_region_name_fr + ', ' +
                      adpt.data['Geographic Data'][0].adt_postal_code + ', ' +
                      adpt.data['Geographic Data'][0].con_country_name_fr;
                    this.mission.checkpoints[i].adptid_valid = true;
                    if (this.checkpointMapGeoJSON.features.length >= i + 1) {
                      if(this.market){
                        this.checkpointMapGeoJSON.features[i+1] = {
                          'type': 'Feature',
                          'geometry': {
                            'type': 'Point', 'coordinates':
                              [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                              adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                          },
                          'lnglat': [
                            parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                            parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                          ]
                        };
                      } else{
                        this.checkpointMapGeoJSON.features[i] = {
                          'type': 'Feature',
                          'geometry': {
                            'type': 'Point', 'coordinates':
                              [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                              adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                          },
                          'lnglat': [
                            parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                            parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                          ]
                        };
                      }
                      if (this.mission.assignments.length !== 0) {
                        this.mission.assignments.forEach(assign => {
                          assign.geojson = this.checkpointMapGeoJSON;
                        })
                      }
                    } else {
                      this.checkpointMapGeoJSON.features.push({
                        'type': 'Feature',
                        'geometry': {
                          'type': 'Point', 'coordinates':
                            [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                            adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                        },
                        'lnglat': [
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                        ]
                      });
                      if (this.mission.assignments.length !== 0) {
                        this.mission.assignments.forEach(assign => {
                          assign.geojson = this.checkpointMapGeoJSON;
                        })
                      }
                    }
                    this.checkpointMap.flyTo({
                      center: [
                        adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                        adpt.data['Geographic Data'][0].adt_latitude_wgs84
                      ],
                      zoom: 9,
                      bearing: 0,
                      curve: 1
                    });
                    icb();
                  });
                } else {
                  this.utils.getCheckpointWithAdptid(adpt.data['Geographic Data'][0].adt_adptid, (status, response) => {
                    if (status === 200) {
                      this.mission.checkpoints[i].checkpointName = response.data.checkpoints[0].checkpointName;
                      this.mission.checkpoints[i].checkpointDescription = response.data.checkpoints[0].checkpointDescription;
                      this.mission.checkpoints[i].checkpointNameDisabled = true;
                      this.taged = [];
                      const obj = this.mission.checkpoints.filter(res => res.checkpointName);
                      obj.forEach(itm => this.taged.push(itm.checkpointName));

                      this.uniqueAdptIDPopup();
                      // let uniqueADPTID = [];
                      // this.mission.checkpoints.map(res => res.data).map(res => res.adptid).forEach(n => {
                      //   if (uniqueADPTID.indexOf(Number(n)) == -1) {
                      //     uniqueADPTID.push(Number(n))
                      //   }
                      //   else {
                      //     this.pedestrainAlertsService.uniqueApdtId()
                      //       .then(() => {
                      //         this.mission.checkpoints[i].adptid_valid = false;
                      //       })
                      //       .catch(() => {
                      //         this.mission.checkpoints[i].adptid_valid = false;
                      //       });
                      //   }
                      // });

                    } else {
                      this.mission.checkpoints[i].checkpointName = '';
                      this.mission.checkpoints[i].checkpointDescription = '';
                      this.mission.checkpoints[i].checkpointNameDisabled = false;
                    }
                  });
                  this.mission.checkpoints[i].data.lnglat = [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                  adpt.data['Geographic Data'][0].adt_latitude_wgs84];
                  this.mission.checkpoints[i].data.adptid = 0;
                  this.mission.checkpoints[i].data.adptid = adpt.data['Geographic Data'][0].adt_adptid;
                  this.mission.checkpoints[i].data.quartier =
                    adpt.data['Geographic Data'][0].qub_quartier_name_fr;
                  this.mission.checkpoints[i].data.address = adpt.data['Geographic Data'][0].adt_adrn + ', ' +
                    adpt.data['Geographic Data'][0].adt_street + ', ' +
                    adpt.data['Geographic Data'][0].com_commune_name_fr + ', ' +
                    adpt.data['Geographic Data'][0].reg_region_name_fr + ', ' +
                    adpt.data['Geographic Data'][0].adt_postal_code + ', ' +
                    adpt.data['Geographic Data'][0].con_country_name_fr;
                  this.mission.checkpoints[i].adptid_valid = true;
                  if (this.checkpointMapGeoJSON.features.length >= i + 1) {
                    if (this.market) {
                      this.checkpointMapGeoJSON.features[i+1] = {
                        'type': 'Feature',
                        'geometry': {
                          'type': 'Point', 'coordinates':
                            [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                            adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                        },
                        'lnglat': [
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                        ]
                      };
                    } else{
                      this.checkpointMapGeoJSON.features[i] = {
                        'type': 'Feature',
                        'geometry': {
                          'type': 'Point', 'coordinates':
                            [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                            adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                        },
                        'lnglat': [
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                        ]
                      };
                    }
                  } else {
                    this.checkpointMapGeoJSON.features.push({
                      'type': 'Feature',
                      'geometry': {
                        'type': 'Point', 'coordinates':
                          [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                          adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                      },
                      'lnglat': [
                        parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                        parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                      ]
                    });
                  }
                  if (this.mission.assignments.length !== 0) {
                    this.mission.assignments.forEach(assign => {
                      assign.geojson = this.checkpointMapGeoJSON;
                    })
                  }
                  this.checkpointMap.flyTo({
                    center: [
                      adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                      adpt.data['Geographic Data'][0].adt_latitude_wgs84
                    ],
                    zoom: 9,
                    bearing: 0,
                    curve: 1
                  });
                  icb();
                }
              }
            }); // end of foreach loop
          } else {
            this.utils.getCheckpointWithAdptid(adpt.data['Geographic Data'][0].adt_adptid, (status, response) => {
              if (status === 200) {
                this.mission.checkpoints[i].checkpointName = response.data.checkpoints[0].checkpointName;
                this.mission.checkpoints[i].checkpointDescription = response.data.checkpoints[0].checkpointDescription;
                this.mission.checkpoints[i].checkpointNameDisabled = true;
                this.taged = [];
                const obj = this.mission.checkpoints.filter(res => res.checkpointName);
                obj.forEach(itm => this.taged.push(itm.checkpointName));
                
                this.uniqueAdptIDPopup();
                // let uniqueADPTID = [];
                // this.mission.checkpoints.map(res => res.data).map(res => res.adptid).forEach(n => {
                //   if (uniqueADPTID.indexOf(Number(n)) == -1) {
                //     uniqueADPTID.push(Number(n))
                //   }
                //   else {
                //     this.pedestrainAlertsService.uniqueApdtId()
                //       .then(() => {
                //         this.mission.checkpoints[i].adptid_valid = false;
                //       })
                //       .catch(() => {
                //         this.mission.checkpoints[i].adptid_valid = false;
                //       });
                //   }
                // });
              } else {
                this.mission.checkpoints[i].checkpointName = '';
                this.mission.checkpoints[i].checkpointDescription = '';
                this.mission.checkpoints[i].checkpointNameDisabled = false;
              }
            });
            this.mission.checkpoints[i].data.lnglat = [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
            adpt.data['Geographic Data'][0].adt_latitude_wgs84];
            this.mission.checkpoints[i].data.adptid = 0;
            this.mission.checkpoints[i].data.adptid = adpt.data['Geographic Data'][0].adt_adptid;
            this.mission.checkpoints[i].data.quartier =
              adpt.data['Geographic Data'][0].qub_quartier_name_fr;
            this.mission.checkpoints[i].data.address = adpt.data['Geographic Data'][0].adt_adrn + ', ' +
              adpt.data['Geographic Data'][0].adt_street + ', ' +
              adpt.data['Geographic Data'][0].com_commune_name_fr + ', ' +
              adpt.data['Geographic Data'][0].reg_region_name_fr + ', ' +
              adpt.data['Geographic Data'][0].adt_postal_code + ', ' +
              adpt.data['Geographic Data'][0].con_country_name_fr;
            this.mission.checkpoints[i].adptid_valid = true;
            if (this.checkpointMapGeoJSON.features.length >= i + 1) {
              if (this.checkpointMapGeoJSON.features.length > 0){
                if (this.market) {
                  this.checkpointMapGeoJSON.features[i + 1] = {
                    'type': 'Feature',
                    'geometry': {
                      'type': 'Point', 'coordinates':
                        [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                        adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                    },
                    'lnglat': [
                      parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                      parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                    ]
                  };
                } else {
                  this.checkpointMapGeoJSON.features[i] = {
                    'type': 'Feature',
                    'geometry': {
                      'type': 'Point', 'coordinates':
                        [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                        adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                    },
                    'lnglat': [
                      parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                      parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                    ]
                  };
                }
               // this.checkpointMapGeoJSON.features[i] = {
                //   'type': 'Feature',
                //   'geometry': {
                //     'type': 'Point', 'coordinates':
                //       [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                //       adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                //   },
                //   'lnglat': [
                //     parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                //     parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                //   ]
                // };
              }else{
                this.checkpointMapGeoJSON.features[i] = {
                  'type': 'Feature',
                  'geometry': {
                    'type': 'Point', 'coordinates':
                      [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                      adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                  },
                  'lnglat': [
                    parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                    parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                  ]
                };
              }


              if (this.mission.assignments.length !== 0) {
                this.mission.assignments.forEach(assign => {
                  assign.geojson = this.checkpointMapGeoJSON;
                })
              }
            } else {
              this.checkpointMapGeoJSON.features.push({
                'type': 'Feature',
                'geometry': {
                  'type': 'Point', 'coordinates':
                    [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                    adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                },
                'lnglat': [
                  parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                  parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                ]
              });
              if (this.mission.assignments.length !== 0) {
                this.mission.assignments.forEach(assign => {
                  assign.geojson = this.checkpointMapGeoJSON;
                })
              }
            }
            this.checkpointMap.flyTo({
              center: [
                adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                adpt.data['Geographic Data'][0].adt_latitude_wgs84
              ],
              zoom: 9,
              bearing: 0,
              curve: 1
            });
            icb();
          }
        } else {
          this.pedestrainAlertsService.adptidNotAvailable();
          this.mission.checkpoints[i].data.adptid = null;
          this.mission.checkpoints[i].data.quartier = undefined;
        }
      }, err => { });
  }

  checkpointsValidator(cb) {
    let checkLen = this.mission.checkpoints.length;
    let error = false;
    this.mission.checkpoints.forEach(check => {
      if (check.data.checkpointName !== undefined && check.data.checkpointName !== '') {
        check.checkpointName = check.data.checkpointName;
      }
      if (check.checkpointName === undefined && check.data.checkpointName !== '') {
        error = true;
      }
      if (check.data.adptid === null) {
        error = true;
      }
      checkLen--;
      if (checkLen === 0) {
        if (!error) {
          cb(true);
        } else {
          cb(false);
        }
      }
    })
  }
  callAdptIdData(e, i) {
    if (!this.mission.checkpoints[i].dontKnowAdptId) {
      if (this.mission.checkpoints.length === 3) {
        this.taged = [];
        const obj = this.mission.checkpoints.filter(res => res.checkpointName);
        obj.forEach(itm => this.taged.push(itm.checkpointName));

        this.http.SecurePost('/checkpoint/validateCheckpoints', {
          adptIds: [
            parseInt(this.mission.checkpoints[0].data.adptid, 10),
            parseInt(this.mission.checkpoints[1].data.adptid, 10),
            parseInt(this.mission.checkpoints[2].data.adptid, 10)
          ]
        }).subscribe(res => {
          this.pedestrainAlertsService.adptidsAlreadyExist()
            .then(() => {
              this.event.broadcast({ eventName: 'showLoader', data: '' });
              if (this.mission.checkpoints.length === 3) {
                this.mission.checkpoints.splice(2, 1);
                this.showAddNewCheckpoint = true;
                if (this.checkpointMapGeoJSON.features.length === 3) {
                  this.checkpointMapGeoJSON.features.splice(2, 1);
                }
                const formData = new FormData();
                const XHR = new XMLHttpRequest();
                formData.append('missionId', this.mission.checkpoints[0].selectedMission.missionId);
                formData.append('existingCircuitId', this.mission.checkpoints[0].selectedCircuit.circuitId);
                formData.append('circuitId', res.data.circuitId);
                formData.append('circuitCreatedBy', res.data.circuitCreatedById);
                formData.append('circuitUpdatedBy', this.user.userId);
                XHR.addEventListener('load', (event) => { });
                XHR.onreadystatechange = (aEvt) => {
                  if (XHR.readyState === 4) {
                    if (XHR.status === 200) {
                      const response = JSON.parse(XHR.response);
                      const circuitObject = {
                        selectedMission: this.mission.checkpoints[0].selectedMission,
                        missions: [],
                        existingCircuitsCheck: true,
                        existingCircuits: [],
                        tempExistingCircuits: [],
                        existingCircuitSearch: undefined,
                        selectedExistingCircuit: res.data,
                        checkpointsGeoJson: {
                          'type': 'FeatureCollection',
                          'features': [
                            {
                              'type': 'Feature',
                              'geometry': {
                                'type': 'Point',
                                'coordinates': [res.data.circuitCheckpoints[0].checkpointLongitude,
                                res.data.circuitCheckpoints[0].checkpointLatitude]
                              },
                              'lnglat': [parseFloat(Number(res.data.circuitCheckpoints[0].checkpointLongitude).toFixed(20)),
                              parseFloat(Number(res.data.circuitCheckpoints[0].checkpointLatitude).toFixed(20))],
                              'checkpointName': res.data.circuitCheckpoints[0].checkpointName
                            },
                            {
                              'type': 'Feature',
                              'geometry': {
                                'type': 'Point',
                                'coordinates': [res.data.circuitCheckpoints[1].checkpointLongitude,
                                res.data.circuitCheckpoints[1].checkpointLatitude]
                              },
                              'lnglat': [parseFloat(Number(res.data.circuitCheckpoints[1].checkpointLongitude).toFixed(20)),
                              parseFloat(Number(res.data.circuitCheckpoints[1].checkpointLatitude).toFixed(20))],
                              'checkpointName': res.data.circuitCheckpoints[1].checkpointName
                            },
                            {
                              'type': 'Feature',
                              'geometry': {
                                'type': 'Point',
                                'coordinates': [res.data.circuitCheckpoints[2].checkpointLongitude,
                                res.data.circuitCheckpoints[2].checkpointLatitude]
                              },
                              'lnglat': [parseFloat(Number(res.data.circuitCheckpoints[2].checkpointLongitude).toFixed(20)),
                              parseFloat(Number(res.data.circuitCheckpoints[2].checkpointLatitude).toFixed(20))],
                              'checkpointName': res.data.circuitCheckpoints[2].checkpointName
                            }
                          ]
                        },
                        data: {
                          circuitName: '',
                          search: '',
                          lnglat: ['4.4699', '50.5039'],
                          imageUploaded: true,
                          progress: 0,
                          uploadProgress: false
                        }
                      };
                      this.mission.circuits = [];
                      this.mission.circuits.push(circuitObject);
                      this.checkpointsFound = true;
                      this.populateExistingCheckpoints();
                      this.event.broadcast({ eventName: 'hideLoader', data: '' });
                      this.pedestrainAlertsService.circuitMapSuccess();
                    } else {
                      this.pedestrainAlertsService.somethingWentWrong();
                    }
                  }
                };
                XHR.addEventListener('error', (event) => {
                  this.event.broadcast({ eventName: 'hideLoader', data: '' });
                  this.pedestrainAlertsService.somethingWentWrongQuestion();
                });
                XHR.open('POST', this.xmlHttpUrl + '/circuit/addCircuit');
                XHR.setRequestHeader('Authorization', this.user.accessToken);
                XHR.setRequestHeader('userId', this.user.userId);
                XHR.send(formData);
              }
            })
            .catch(() => {
              this.pedestrainAlertsService.sameCheckPointsNotAllowedAlert();
            });
        }, err => {
          this.utils.getCheckpointWithAdptid(e.target.value, (status, response) => {
            if (status === 200) {
              this.mission.checkpoints[i].checkpointName = response.data.checkpoints[0].checkpointName;
              this.mission.checkpoints[i].checkpointDescription = response.data.checkpoints[0].checkpointDescription;
              this.mission.checkpoints[i].checkpointNameDisabled = true;
              this.checkpointsValidator(valid => {
                if (valid) {
                  this.mission.assignments = [];
                  this.assignmentFiller('noAssignment', () => {

                  });
                } else {
                  this.mission.assignments = [];
                }
              });

              let uniqueADPTID = [];
              this.mission.checkpoints.map(res => res.data).map(res => res.adptid).forEach(n => {
                if (uniqueADPTID.indexOf(Number(n)) == -1) {
                  uniqueADPTID.push(Number(n))
                }
                else {
                  this.pedestrainAlertsService.uniqueApdtId()
                    .then(() => {
                      this.mission.checkpoints[i].adptid_valid = false;
                    })
                    .catch(() => {
                      this.mission.checkpoints[i].adptid_valid = false;
                    });
                }
              });
              //this.uniqueAdptIDPopup();

            } else {
              this.mission.checkpoints[i].checkpointName = '';
              this.mission.checkpoints[i].checkpointDescription = '';
              this.mission.checkpoints[i].checkpointNameDisabled = false;
            }
          });
          this.http.pullAdptIdDetails(e.target.value).subscribe(res => {
            if (res.data['Geographic Data'].length !== 0) {
              const adptIdDet = res.data['Geographic Data'][0];
              const lat = adptIdDet.adt_latitude_wgs84;
              const lng = adptIdDet.adt_longitude_wgs84;
              if (this.checkpointMapGeoJSON.features.length < i) {
                this.checkpointMapGeoJSON.features.push({
                  'type': 'Feature',
                  'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                  'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                });
              } else {
                if(this.market){
                  if (i == 2) {
                    this.checkpointMapGeoJSON.features[i+1] = {
                      'type': 'Feature',
                      'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                      'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                    };
                  } 
                } else{
                  this.checkpointMapGeoJSON.features[i] = {
                    'type': 'Feature',
                    'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                    'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                  };
                }
              }
              this.mission.checkpoints[i].data.lnglat = [lng, lat];
              this.mission.checkpoints[i].selected_postalcode.adt_postal_code = adptIdDet.adt_postal_code;
              this.mission.checkpoints[i].selected_street.adt_street = adptIdDet.adt_street;
              this.mission.checkpoints[i].selected_adrn.adt_adrn = adptIdDet.adt_adrn;
              this.mission.checkpoints[i].selected_commune.com_commune_name_fr = adptIdDet.com_commune_name_fr;
              this.mission.checkpoints[i].selected_region.reg_region_name_fr = adptIdDet.reg_region_name_fr;
              this.mission.checkpoints[i].selected_country.con_country_name_fr = adptIdDet.con_country_name_fr;
              this.mission.checkpoints[i].data.quartier = adptIdDet.qub_quartier_name_fr;
              this.mission.checkpoints[i].data.address = adptIdDet.adt_adrn + ', ' +
                adptIdDet.adt_street + ', ' +
                adptIdDet.com_commune_name_fr + ', ' +
                adptIdDet.reg_region_name_fr + ', ' +
                adptIdDet.adt_postal_code + ', ' +
                adptIdDet.con_country_name_fr;
              this.mission.checkpoints[i].adptid_valid = true;
              this.checkpointMap.flyTo({
                center: [lng, lat],
                zoom: 9,
                bearing: 0,
                curve: 1
              });
              this.mission.checkpoints[i].countryLoaded = true;
              this.mission.checkpoints[i].regionLoaded = true;
              this.mission.checkpoints[i].communeLoaded = true;
              this.mission.checkpoints[i].postalCodeLoaded = true;
              this.mission.checkpoints[i].streetLoaded = true;
              this.mission.checkpoints[i].adrnLoaded = true;
              if (this.checkpointsFound) {
                this.mission.assignments.forEach(assign => {
                  assign.geojson = this.checkpointMapGeoJSON;
                });
              }
            } else {
              this.mission.checkpoints[i].adptid_valid = false;
            }
          }, err => {
            this.mission.checkpoints[i].adptid_valid = false;
          });
        });
      } else {
        if (e.target.value != ""){
          this.utils.getCheckpointWithAdptid(e.target.value, (status, response) => {
            if (status === 200) {
              this.mission.checkpoints[i].checkpointName = response.data.checkpoints[0].checkpointName;
              this.mission.checkpoints[i].checkpointDescription = response.data.checkpoints[0].checkpointDescription;
              this.mission.checkpoints[i].checkpointNameDisabled = true;

              let uniqueADPTID = [];
              this.mission.checkpoints.map(res => res.data).map(res => res.adptid).forEach(n => {
                if (uniqueADPTID.indexOf(Number(n)) == -1) {
                  uniqueADPTID.push(Number(n))
                }
                else {
                  this.pedestrainAlertsService.uniqueApdtId()
                    .then(() => {
                      this.mission.checkpoints[i].adptid_valid = false;
                    })
                    .catch(() => {
                      this.mission.checkpoints[i].adptid_valid = false;
                    });
                }
              });

            } else {
              this.mission.checkpoints[i].checkpointName = '';
              this.mission.checkpoints[i].checkpointDescription = '';
              this.mission.checkpoints[i].checkpointNameDisabled = false;
            }
          });
          this.http.pullAdptIdDetails(e.target.value).subscribe(res => {
            if (res.data['Geographic Data'].length !== 0) {
              const adptIdDet = res.data['Geographic Data'][0];
              const lat = adptIdDet.adt_latitude_wgs84;
              const lng = adptIdDet.adt_longitude_wgs84;
              if (this.checkpointMapGeoJSON.features.length < i) {
                this.checkpointMapGeoJSON.features.push({
                  'type': 'Feature',
                  'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                  'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                });
              } else {
                if (this.checkpointMapGeoJSON.features.length >0){
                  if(this.market){
                    this.checkpointMapGeoJSON.features[i+1] = {
                      'type': 'Feature',
                      'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                      'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                    };
                  } else{
                    this.checkpointMapGeoJSON.features[i] = {
                      'type': 'Feature',
                      'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                      'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                    };
                  }
                }else{
                  this.checkpointMapGeoJSON.features[i] = {
                    'type': 'Feature',
                    'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                    'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                  };
                }
              }
              this.mission.checkpoints[i].data.lnglat = [lng, lat];
              this.mission.checkpoints[i].selected_postalcode.adt_postal_code = adptIdDet.adt_postal_code;
              this.mission.checkpoints[i].selected_street.adt_street = adptIdDet.adt_street;
              this.mission.checkpoints[i].selected_adrn.adt_adrn = adptIdDet.adt_adrn;
              this.mission.checkpoints[i].selected_commune.com_commune_name_fr = adptIdDet.com_commune_name_fr;
              this.mission.checkpoints[i].selected_region.reg_region_name_fr = adptIdDet.reg_region_name_fr;
              this.mission.checkpoints[i].selected_country.con_country_name_fr = adptIdDet.con_country_name_fr;
              this.mission.checkpoints[i].data.quartier = adptIdDet.qub_quartier_name_fr;
              this.mission.checkpoints[i].data.address = adptIdDet.adt_adrn + ', ' +
                adptIdDet.adt_street + ', ' +
                adptIdDet.com_commune_name_fr + ', ' +
                adptIdDet.reg_region_name_fr + ', ' +
                adptIdDet.adt_postal_code + ', ' +
                adptIdDet.con_country_name_fr;
              this.mission.checkpoints[i].adptid_valid = true;
              this.checkpointMap.flyTo({
                center: [lng, lat],
                zoom: 9,
                bearing: 0,
                curve: 1
              });
              this.mission.checkpoints[i].countryLoaded = true;
              this.mission.checkpoints[i].regionLoaded = true;
              this.mission.checkpoints[i].communeLoaded = true;
              this.mission.checkpoints[i].postalCodeLoaded = true;
              this.mission.checkpoints[i].streetLoaded = true;
              this.mission.checkpoints[i].adrnLoaded = true;
              if (this.checkpointsFound) {
                this.mission.assignments.forEach(assign => {
                  assign.geojson = this.checkpointMapGeoJSON;
                });
              }
  
              this.taged = [];
              const obj = this.mission.checkpoints.filter(res => res.checkpointName);
              obj.forEach(itm => this.taged.push(itm.checkpointName));
  
            } else {
              this.mission.checkpoints[i].adptid_valid = false;
            }
          }, err => {
            this.mission.checkpoints[i].adptid_valid = false;
          });
        }
      }
    }
  }
  streetChecker(val) {
    this.mission.checkpoints[val].adrnLoaded = false;
    this.mission.checkpoints[val].data.adptid = null;
  }

  /* Fillers 
    1. fillPullApiFields(i, cb, adptid?)
    2. populateExistingCheckpoints()
  */
  fillPullApiFields(i, cb, adptid?) {
    if (adptid) {
      this.http.pullAdptIdDetails(adptid).subscribe(res => {
        if (res.data['Geographic Data'].length !== 0) {
          const adptIdDet = res.data['Geographic Data'][0];
          const lat = adptIdDet.adt_latitude_wgs84;
          const lng = adptIdDet.adt_longitude_wgs84;
          if (this.checkpointMapGeoJSON.features.length < 3) {
            this.checkpointMapGeoJSON.features.push({
              'type': 'Feature',
              'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
              'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
            });
          }
          if (this.mission.checkpoints.length>0){
            this.mission.checkpoints[i].selected_postalcode.adt_postal_code = adptIdDet.adt_postal_code;
            this.mission.checkpoints[i].selected_street.adt_street = adptIdDet.adt_street;
            this.mission.checkpoints[i].selected_adrn.adt_adrn = adptIdDet.adt_adrn;
            this.mission.checkpoints[i].selected_commune.com_commune_name_fr = adptIdDet.com_commune_name_fr;
            this.mission.checkpoints[i].selected_region.reg_region_name_fr = adptIdDet.reg_region_name_fr;
            this.mission.checkpoints[i].selected_country.con_country_name_fr = adptIdDet.con_country_name_fr;
            this.mission.checkpoints[i].data.quartier = adptIdDet.qub_quartier_name_fr;
            this.mission.checkpoints[i].data.address = adptIdDet.adt_adrn + ', ' +
              adptIdDet.adt_street + ', ' +
              adptIdDet.com_commune_name_fr + ', ' +
              adptIdDet.reg_region_name_fr + ', ' +
              adptIdDet.adt_postal_code + ', ' +
              adptIdDet.con_country_name_fr;
            this.mission.checkpoints[i].adptid_valid = true;
            this.checkpointMap.flyTo({
              center: [lng, lat],
              zoom: 9,
              bearing: 0,
              curve: 1
            });
            this.mission.checkpoints[i].countryLoaded = true;
            this.mission.checkpoints[i].regionLoaded = true;
            this.mission.checkpoints[i].communeLoaded = true;
            this.mission.checkpoints[i].postalCodeLoaded = true;
            this.mission.checkpoints[i].streetLoaded = true;
            this.mission.checkpoints[i].adrnLoaded = true;
          }
          this.loadMapForExistingCircuit = true;
          cb();
        } else {
          this.mission.checkpoints[i].adptid_valid = false;
        }
      }, err => {
          if (this.mission.checkpoints.length>0){
            this.mission.checkpoints[i].adptid_valid = false;
          }
      });
    } else {
      this.getCountries(i, () => {
        this.getRegions(i, () => {
          this.getCommunes(i, () => {
            this.getPostalCodes(i, () => {
              this.getStreets(i, () => {
                this.getAdrns(i, () => {
                  this.getAdptId(i, () => {
                    cb();
                  });
                });
              });
            });
          });
        });
      });
    }
  }
  populateExistingCheckpoints() {
    this.mission.assignments = [];
    this.mission.checkpoints = [];
    this.checkpointMapGeoJSON.features = [];
    let assLen = this.mission.assignments.length;
    const checkpoints = [];
    const updateCheckpointObjectCreator = (index) => {
      const checkpointsLen = checkpoints.length;
      if (checkpointsLen !== index) {
        existingCheckpointPopulator(checkpoints[index], () => {
          const ind = index + 1;
          updateCheckpointObjectCreator(ind);
        });
      } else {
        let ogMission: any = this.ogMission;
        if (ogMission.missionMarketZoneList != null && this.market) {
          if (ogMission.missionMarketZoneList.length > 0) {
            const feature = {
              'type': 'Feature',
              'geometry': { 'type': 'Point', 'coordinates': [ogMission.missionMarketZoneList[0].longitude, ogMission.missionMarketZoneList[0].latitude] },
              'lnglat': [ogMission.missionMarketZoneList[0].longitude, ogMission.missionMarketZoneList[0].latitude],
              'checkpointName': ogMission.missionMarketZoneList[0].officialName,
              'marketSelected': true
            };
            this.checkpointMapGeoJSON.features.push(feature);
          }
        }else{
          if (this.market) {
            const feature = {
              'type': 'Feature',
              'geometry': { 'type': 'Point', 'coordinates': [this.selectedMarketObject.longitude, this.selectedMarketObject.latitude] },
              'lnglat': [this.selectedMarketObject.longitude, this.selectedMarketObject.latitude],
              'checkpointName': this.selectedMarketObject.officialName,
              'marketSelected': true
            };
            this.checkpointMapGeoJSON.features.push(feature);
          }
        }
        
        this.assignmentFiller('noAssignment', () => {
          this.loadMapForExistingCircuit = true;
        });
      }
    };
    const existingCheckpointPopulator = (checkpoint, cb) => {
      this.http.pullAdptIdDetails(checkpoint.adptId).subscribe(res => {
        const response = res.data['Geographic Data'][0];
        const mapObj = {
          selectedMission: this.mission.circuits[0].selectedMission,
          selectedCircuit: this.mission.circuits[0].selectedExistingCircuit,
          selected_adrn: response.adt_adrn,
          selected_street: response.adt_street,
          selected_postalcode: response.adt_postal_code,
          selected_commune: response.com_commune_name_fr,
          selected_region: response.reg_region_name_fr,
          selected_country: response.con_country_name_fr,
          id: checkpoint.checkpointId,
          data: {
            checkpointName: checkpoint.checkpointName,
            checkpointNameDisabled: true,
            description: checkpoint.checkpointDescription,
            adptid: checkpoint.adptId,
            quartier: response.qub_quartier_name_fr,
            lnglat: [response.adt_longitude_wgs84,
            response.adt_latitude_wgs84]
          }
        };
        this.mission.assignments.forEach(assign => {
          assign.geojson.features.push({
            type: 'Feature',
            properties: {
              message: 'Foo',
              iconSize: [60, 60]
            },
            geometry: {
              type: 'Point',
              coordinates: [response.adt_longitude_wgs84, response.adt_latitude_wgs84]
            }
          });
        });
        this.checkpointMapGeoJSON.features.push({
          'type': 'Feature',
          'geometry': {
            'type': 'Point',
            'coordinates': [response.adt_longitude_wgs84,
            response.adt_latitude_wgs84]
          },
          'lnglat': [
            parseFloat(Number(response.adt_longitude_wgs84).toFixed(20)),
            parseFloat(Number(response.adt_latitude_wgs84).toFixed(20))
          ]
        });
        this.mission.checkpoints.push(mapObj);
        if (this.fillEditMissionFlag) {
          const databaseObj: CheckpointDaoInterface = {
            id: checkpoint.checkpointId,
            checkpointName: checkpoint.checkpointName,
            index: this.mission.checkpoints.length - 1
          };
          this.database.push(databaseObj);
          if (this.mission.checkpoints.length === 3) {
            this.fillEditMissionFlag = false;
            const obj = this.mission.checkpoints.map(res => res.data);
            this.taged = obj.map(res => res.checkpointName);
          }
        }

        let circuit = this.mission.circuits[0].checkpointsGeoJson.features.filter(cname => cname.checkpointName == checkpoint.checkpointName)[0];
        circuit.lnglat[0] = parseFloat(Number(response.adt_longitude_wgs84).toFixed(20));
        circuit.lnglat[1] = parseFloat(Number(response.adt_latitude_wgs84).toFixed(20));
        circuit.geometry.coordinates[0] = parseFloat(Number(response.adt_longitude_wgs84).toFixed(20));
        circuit.geometry.coordinates[1] = parseFloat(Number(response.adt_latitude_wgs84).toFixed(20));
        // this.checkpointMap.flyTo({
        //   center: [
        //     response.adt_longitude_wgs84,
        //     response.adt_latitude_wgs84
        //   ],
        //   zoom: 9,
        //   bearing: 0,
        //   curve: 1
        // });
        cb();
      }, err => { });

    };

    let checklen = this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints.length;

    /*
    this.mission.circuits[0].circuitCheckpoints.forEach(checkpoint => {
      checkpoints.push(checkpoint);
      checklen--;
      if (checklen === 0) {
        updateCheckpointObjectCreator(0);
      }
    }); */
    this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints.forEach(checkpoint => {
      checkpoints.push(checkpoint);
      checklen--;
      if (checklen === 0) {
        updateCheckpointObjectCreator(0);
      }
    });
    setTimeout(() => {
      this.enableDropsown=true;  
    }, 5000);
  }

  getMarketZone() {
    this.utils.getMarketZone(this.user.userId).subscribe(res => {
      this.marketZone = res.data;
    })
  }

  classic;
  market;
  marketid = null;
  buttonEnabled = false;
  name = false;
  description = false;
  marketZoneSelected = true;
  selectedMarketZoneValue = this.translate.instant('Select market zone');
  mapObject: any = [];
  onChecked(event, name) {
    // && this.marketid==null
    if (name === 'market') {
      if (event.target.checked) {
        this.buttonEnabled = false;
        //this.classic = false;

        this.marketZoneSelected = false;
        this.market = true

      }
      if (!event.target.checked) {
        //this.classic = true;
        let index1 = this.mission.circuits[0].checkpointsGeoJson.features.findIndex(res => res.marketSelected);
        this.mission.circuits[0].checkpointsGeoJson.features.splice(index1,1);
        
        let index = this.checkpointMapGeoJSON.features.findIndex(res => res.marketSelected);
        this.checkpointMapGeoJSON.features.splice(index,1);
        this.mapObject = []
        this.market = false
        this.marketZoneSelected = true;
        this.selectedMarketZoneValue = this.translate.instant('Select market zone');

        this.marketZoneSelected = true;
        this.marketid = null;

      }
      if (this.name && this.description && this.marketZoneSelected) {
        this.buttonEnabled = true;
      }
    }
    if (name === 'classic') {
      if (event.target.checked) {
        this.marketid = null;
        this.marketZoneSelected = true;

        this.selectedMarketZoneValue = this.translate.instant('Select market zone');
        this.market = false;
        this.classic = true;
        this.mapObject = []
      } else {
        this.buttonEnabled = false;
        this.classic = false;
        this.marketZoneSelected = false;
        this.market = true
      }

    }
  }

  selectedMarketObject;
  selectedMarketZone(id, name) {
    this.marketZoneSelected = true;
    if (this.market && this.name && this.description) {
      this.buttonEnabled = true;
    }
    this.marketid = id;
    this.selectedMarketZoneValue = name;
    let selectedMarketIndex = this.mission.circuits[0].checkpointsGeoJson.features.findIndex(res => res.marketSelected);
    let selectedMarketIndex1 = this.checkpointMapGeoJSON.features.findIndex(res => res.marketSelected);
    if (selectedMarketIndex !=-1){
      this.mission.circuits[0].checkpointsGeoJson.features.splice(selectedMarketIndex,1);
    }
    if (selectedMarketIndex1 != -1) {
      this.checkpointMapGeoJSON.features.splice(selectedMarketIndex1,1);
    }
    
    this.utils.getLocationDetails({ 'locationName': this.selectedMarketZoneValue, 'locationType': 2 }).subscribe(res => {
      let market = res.data;
      this.selectedMarketObject= res.data;
      const feature = {
        'type': 'Feature',
        'geometry': { 'type': 'Point', 'coordinates': [market.longitude, market.latitude] },
        'lnglat': [market.longitude, market.latitude],
        'checkpointName': market.officialName,
        'marketSelected': true
      };
      this.mission.circuits[0].checkpointsGeoJson['features'].push(feature);
      this.checkpointMapGeoJSON.features.push(feature);
    });
  }

  defaultAssignedUserid: any;
  getEndDate(d1) {
    // this.http.SecurePost('/ref/getAllUnassignedUsers', {
    //   startDate: d1.year + '-' + d1.month + '-' + d1.day,
    //   missionId: this.mission.missionId,
    //   shift: this.isShift == "Morning" ? 1 : 2
    // }).subscribe(resFA => {
    //   console.log("Mission",this.mission);
    //   this.fieldAgents = resFA.users;
    //   this.selectedFieldAgent = resFA.users[0];
    // }, err =>{
    //     this.custUtils.translateMessageObject({
    //       title: this.translate.instant('No Field agents available'),
    //       text: this.translate.instant('Please change the mission date or  ask admin to add more field agents.'),
    //       type: 'warning',
    //       cancelBtnText: '',
    //       confirmBtnText: 'OK',
    //       outsideClick: false,
    //       showCancelBtn: false
    //     }, message => {
    //       this.custUtils.translateAndPop(message).then(() => {
    //         this.fieldAgents = [];
    //         this.selectedFieldAgent = {};
    //       }).catch(() => {
    //         this.fieldAgents = [];
    //         this.selectedFieldAgent = {};
    //       });
    //     });
    // });
    let dateE = JSON.parse(localStorage.getItem('date'));
    if (dateE == null){
      this.getUnassignedUsers(this.mission.missionId, false, d1);
    } else{
      let datePickerDateSelected = new Date(UTILS.getDateFormat(d1));
      let existingDate = new Date(UTILS.getDateFormat(dateE));
      if (datePickerDateSelected.getTime() == existingDate.getTime()){
        this.getUnassignedUsers(this.mission.missionId, true, d1);
      } else{
        this.getUnassignedUsers(this.mission.missionId, false, d1);
      }
    }

    // if (UTILS.isMatch(UTILS.minDate, d1, this.mission.missionCampaign.campaignEndDate) && !this.isDisabled(d1, { month: d1.month })) {
    //   this.mission.missionEndDate = d1;
    //   let d = new Date(UTILS.getDateFormat(d1))
    //   if (d.getTime() == this.missionStartDate.getTime()) {
    //     this.defaultUsrDataAssToZone = this.zoneAssignmentBack;
    //     this.defaultUsrDataAssToZone.userId = this.defaultAssignedUserid;
    //     this.getUnassignedUsers(this.missionId, true, d1);
    //   }
    //   else {
    //     this.defaultUsrDataAssToZone.userId = undefined;
    //     this.selectedAssignee = [];
    //     this.getUnassignedUsers(this.missionId, false, d1);
    //   }
    // }
  }

  getUnassignedUsers(missionId, sts, d1) {
    this.http.SecurePost('/ref/getAllUnassignedUsers', {
      startDate: d1.year + '-' + d1.month + '-' + d1.day,
      missionId: missionId,
      shift: this.isShift == "Morning" ? 1 : 2
    }).subscribe(resFA => {
      console.log("Mission",this.mission);
      this.fieldAgents = [];
      this.selectedFieldAgent = {};
      this.fieldAgents = resFA.users;
      if(sts){
        let existingAgent:any = this.ogMission;
        if (existingAgent.agent !=null){
          let agent = this.fieldAgents.filter(res => res.userId == existingAgent.agent.userId);
          if(agent.length == 0){
            resFA.users.splice(0, 0, existingAgent.agent);
          }
        }
      }
      //this.fieldAgents = resFA.users;
      this.selectedFieldAgent = resFA.users[0];
    }, err =>{
        if (sts){
          let existingAgent: any = this.ogMission;
          if (existingAgent.agent == null){
            this.fieldAgents = [];
            this.selectedFieldAgent = {};
          }else{
            this.fieldAgents = [existingAgent.agent];
            this.selectedFieldAgent = existingAgent.agent;
          }
        } else{
          this.custUtils.translateMessageObject({
            title: this.translate.instant('No Field agents available'),
            text: this.translate.instant('Please change the mission date or  ask admin to add more field agents.'),
            type: 'warning',
            cancelBtnText: '',
            confirmBtnText: 'OK',
            outsideClick: false,
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.fieldAgents = [];
              this.selectedFieldAgent = {};
            }).catch(() => {
              this.fieldAgents = [];
              this.selectedFieldAgent = {};
            });
          });
        }
    });
  }

  disableSubmitBtn(){
    // && this.mission.fieldAgents.length > 0 
    //const checkpointName = this.mission.checkpoints.every(res => res.checkpointName);
    let uniqueCheckpoints = [];
    let uniqueCheckpointsFlag = false;
    if (this.existingCircuitsCheck){
      this.mission.checkpoints.map(res => res.data).map(res => res.checkpointName).forEach(n => { if (uniqueCheckpoints.indexOf(n) == -1) { uniqueCheckpoints.push(n) } });
    }else{
      this.mission.checkpoints.map(res => res.checkpointName).forEach(n => {if (uniqueCheckpoints.indexOf(n) == -1) { uniqueCheckpoints.push(n) } });
    }
    if (uniqueCheckpoints.length==3){
      uniqueCheckpointsFlag = uniqueCheckpoints.every(res => res);
    }

    const uniqueArray = [];
    this.mission.checkpoints.map(res => res.data).map(res => res.adptid).forEach((n, i) => {
      if (uniqueArray.indexOf(n) == -1) {
        uniqueArray.push(n)
      }
    });

    if ((this.mission.checkpoints.length == 3 && uniqueCheckpointsFlag && uniqueArray.length == 3) &&  this.mission.missionName && 
      this.mission.missionDescription && (this.fieldAgents.length > 0) &&
      (this.mission.circuits[0].image || this.mission.circuits[0].ogImage) && this.nameExists==false){
      if (this.market && this.marketZoneSelected == false){
        return true;
      }
      // if (this.existingCircuitsCheck == false && this.mission.circuits[0].image == undefined){
      //   return true;
      // }
      return false;
    }
    else{
      return true;
    }
  }

  uniqueAdptIDPopup() {
    let uniqueADPTID = [];
    this.mission.checkpoints.map(res => res.data).map(res => res.adptid).forEach(n => {
      if (uniqueADPTID.indexOf(Number(n)) == -1) {
        uniqueADPTID.push(Number(n))
      }
      else {
        let errorMessage = 'Adptid should be unique</br>Checkpoint name should be unique</br>';
        this.pedestrainAlertsService.warningAlert(errorMessage);
        // this.pedestrainAlertsService.uniqueApdtId()
        //   .then(() => {
        //     this.mission.checkpoints[i].adptid_valid = false;
        //   })
        //   .catch(() => {
        //     this.mission.checkpoints[i].adptid_valid = false;
        //   });
      }
    })
  }
}