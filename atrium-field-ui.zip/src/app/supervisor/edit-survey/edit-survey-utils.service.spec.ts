import { TestBed, inject } from '@angular/core/testing';

import { EditSurveyUtilsService } from './edit-survey-utils.service';

describe('EditSurveyUtilsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EditSurveyUtilsService]
    });
  });

  it('should be created', inject([EditSurveyUtilsService], (service: EditSurveyUtilsService) => {
    expect(service).toBeTruthy();
  }));
});
