import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ApiService } from '@services/apiServices/api.service';
import { EventService } from '@services/events/event.service';
@Component({
    selector: 'app-mission-details',
    templateUrl: './mission-details.component.html',
    styleUrls: ['./mission-details.component.css']
})
export class MissionDetailsComponent implements OnInit {
    missionId: any;
    missionTypeId: any;
    constructor(public _event: EventService, public apiService: ApiService, public route: ActivatedRoute) { }
    ngOnInit() {
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.route.params.subscribe(params => {
            this.missionId = params.id
            this.missionTypeId = params.missionTypeId
        });
    }
}