// core
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, AfterViewInit } from '@angular/core';

// 3rd party
import swal from 'sweetalert2';

// app
import { ApiService } from '@services/apiServices/api.service';
import { SetCampaignDataService } from '@services/set-campaign-data/set-campaign-data.service';
import { EventService } from '@services/events/event.service';
import { LanguageInterface } from '@app/interfaces/interface';
import { TranslationService } from '@services/translation/translation.service';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit, AfterViewInit {

  constructor(
    public api: ApiService,
    public campDataService: SetCampaignDataService,
    public router: Router,
    public event: EventService,
    public translate: TranslationService) { }

  public language: LanguageInterface;
  public languages = [];

  public myForm = new FormGroup({
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    contact: new FormControl('', [Validators.required, Validators.pattern('^[1-9][0-9]{7,13}$')]),
    address: new FormControl('', Validators.required)
  });

  public user = JSON.parse(localStorage.getItem('user-data'));
  ngOnInit() {
    this.getLanguage(this.user.preferredLanguage ? this.user.preferredLanguage : 1);
    this.api.getRoles(this.user.roleId).subscribe(res => {
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
      localStorage.setItem('reloader', 'false');
      this.user.role = res.data[0].name;
    }, err => {
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
      localStorage.setItem('reloader', 'false');
    });
  }

  ngAfterViewInit() {
    if (window.innerWidth <= 992) {
      $('.wrap-textarea>textarea').css('width', '80%');
    }
    if (window.innerWidth >= 992) {
      $('.wrap-textarea>textarea').css('width', '83%');
    }
    if (window.innerWidth >= 1024) {
      $('.wrap-textarea>textarea').css('width', '83%');
    }
    if (window.innerWidth >= 1366) {
      $('.wrap-textarea>textarea').css('width', '85%');
    }
    if (window.innerWidth >= 1600) {
      $('.wrap-textarea>textarea').css('width', '90%');
    }
  }

  toggleLanguage(language) {
    this.languages.push(this.language);
    this.language = language;
    const languagefinder = (lang) => {
      return lang.id === language.id;
    };
    const delInd = this.languages.findIndex(languagefinder);
    this.languages.splice(delInd, 1);
  }

  submit(form: FormGroup) {
    if (form.valid) {
      const reqObj = {
        userId: this.user.userId,
        resetPassword: false,
        resetProfile: false,
        preferredLanguage: this.language.id,
        contactNumber: form.value.contact,
        ...form.value
      };
      this.updateProfile(reqObj);
    }
  }

  getLanguage(id?: string) {
    this.api.getLanguages(id ? id : '').subscribe(res => {
      if (id) {
        this.language = res.data[0];
        this.getLanguage();
      } else {
        return this.languagesParser(res.data);
      }
    }, err => {
      return !id ? 3 : '';
    });
  }

  languagesParser(langArray) {
    langArray.forEach(lang => {
      if (this.language === lang.name) {
        return lang.id;
      }
      if (lang.id !== this.language.id) {
        this.languages.push(lang);
      }
    });
  }

  updateProfile(profile) {
    this.api.updateUser(profile).subscribe(res => {
      this.user = { ...this.user, ...res.updatedData };
      localStorage.removeItem('user-data');
      localStorage.setItem('user-data', JSON.stringify({ ...this.user, ...res.updatedData }));
      this.translate.getLanguageValue('Account updated successfully').subscribe(mes => {
        swal(mes, '', 'success').then(data => {
          this.translate.changeLanguage(res.updatedData.preferredLanguage);
          this.router.navigate(['/supervisor']);
        });
      });
    }, err => { });
  }
}
