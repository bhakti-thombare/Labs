import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { EventService } from '@app/services/events/event.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ApiService } from '@app/services/apiServices/api.service';
import { StorageService } from '@app/services/storage-service.service';

// 3rd party
import { Subscription } from 'rxjs/Subscription';
import { contains, where, isNull } from "underscore";
import { MissionListAlertsService } from '@app/services/Alerts/mission-list-alerts.service';
import { UTILS } from '@app/services/global-utility.service';

// app
import { Observable } from 'rxjs';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { CreateSurveyUtilsService } from '../create-survey/createSurveyUtils/create-survey-utils.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css']
})

export class LocationComponent {

  private subscriptions: Subscription[] = [];
  private utilityFunctions = new UtilityFunctions();
  private sortReverse: boolean = false;
  private isClicked: boolean = true;
  changeMissionDateModalRef: NgbModalRef;
  currentUser: any = JSON.parse(localStorage.getItem('user-data'));
  isSearch: boolean = false;
  isChecked: boolean = false;
  locationLoader: boolean = false;
  isShow: boolean = false;
  searchKey: any;
  sortType: string = 'locationName';
  type: string = 'quartierName';
  campaings: Array<any> = [];
  locationTypes: Array<any> = [];
  locations: Array<any> = [];
  locationsAll: Array<any> = [];
  pagination: Array<any> = [];
  selectedLocation: any = { 'name': 'Location Type' };
  datePipe: any;
  filteredOrders: any[];
  locationName;
  locationType;
  checkpoint: any;
  id: string;
  modal: any;
  survey: any;
  isclicked: boolean = true;
  modalRef: NgbModalRef;

  constructor(
    public router: Router,
    public _event: EventService,
    public modalService: NgbModal,
    public apiService: ApiService,
    private storageService: StorageService,
    public missionListAlertsService: MissionListAlertsService,
    public custUtils: CreateSurveyUtilsService,
    public api: ApiService,
    public translate:TranslateService) {}

  ngOnInit() {
    this.sortReverse = false;
    this.isClicked = true;
    this._event.broadcast({ eventName: 'showLoader', data: '' });
    this.storageService.removeData('missionId&quartierId');

    this.getLocations(10);
    
  }

  /* API Requests */
  getLocations(size) {
    this.locationLoader = true;
    this.subscriptions.push(this.apiService.getLocations({ 'sortBy': 'locationName,asc', 'size': size })
      .subscribe(res => {
        this.locationsAll = res.data.content;
        this.pagination = res.data;
        this.locations = (!isNull(res.data)) ? res.data.content : [];
        this.getLocationType();
        this.locationLoader = true;
        this.filteredOrders = this.locations;
        // this.('name',);
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
      }, err => {
        console.log('inside else');
        this.locationsAll = [];
        this.filteredOrders = [];
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.locationLoader = false;
      }));
  }

  getLocationByName(locationName, searchBy = undefined) {

    this.locationLoader = true;
    this.subscriptions.push(this.apiService.getLocations({ searchBy: locationName, size: 10 })
      .subscribe(res => {
        this.locations = (!isNull(res.data)) ? res.data.content : [];
        this.pagination = res.data;
        this.locationLoader = false;
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
      }, err => {
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.locationLoader = false;
      }));
  }

  toggleDisplay(id) {
    console.log('filteredOrders', this.filteredOrders);
    this.filteredOrders.forEach((element) => {
      element.flag = false;
      if (element.id == id) {
        element.flag = true;
        this.isShow = !this.isShow;
      }

    });


  }

  getLocationType() {
    this.locationLoader = true;
    this.subscriptions.push(this.apiService.getLocationType({})
      .subscribe(res => {
        this.locationTypes = res.data;

        // this.locationTypes.unshift({id:4 , name: "All" });      
        // this.selectedLocation = this.locationTypes[0];
        this.locationLoader = false;
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
      }, err => {
        this.locationTypes = [];
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.locationLoader = false;
        this.filteredOrders = [];
      }));

  }
  getLocationByType(filterBy, id) {
    console.log(id);
    this.locationLoader = true;
    this.locationType = 'locationType,' + id;
    this.subscriptions.push(this.apiService.getLocations({ filterBy: this.locationType, size: 10 })
      .subscribe(res => {
        if (res.data.content.length !== 0) {

          this.pagination = res.data;
          this.locationsAll = res.data.content;
          this.filteredOrders = res.data.content;
          this.locations = res.data.content;
          this.locationLoader = false;
          this._event.broadcast({ eventName: 'hideLoader', data: '' })
        } else {
          console.log('156');
          this._event.broadcast({ eventName: 'hideLoader', data: '' });
          this.locationLoader = false;
          this.locations = [];
          this.filteredOrders =[];
        }
      }, err => {

console.log('163');
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.locationLoader = false;
        this.locations = [];
        this.filteredOrders =[];
      }));
  }

  selectLocationType(newLocation: string) {
    this.locationLoader = true;
    this.selectedLocation = newLocation;
    // if (this.selectedLocation.name === 'All') {
    //   this.getLocations();
    // }
    // else {
    this.getLocationByType(undefined, this.selectedLocation.id);
    // }
  }

  /* redirectors */
  editLocation(id, name, locationId,elementId) {
    this.custUtils.translateMessageObject({
      title: this.translate.instant('Edit Location'),
      text: 'This edited location will replace the old location for new missions. But it won’t affect all the missions that are already created. Are you sure you want to edit it?',
      type: 'warning',
      outsideClick: false,
      cancelBtnText: 'No',
      confirmBtnText: 'Yes',
      showCancelBtn: true
    }, message => {
      this.custUtils.translateAndPop(message).then(() => {
        this.gotoEdit(id, name, locationId,elementId);
      }).catch(() => {
        this.router.navigate([`/supervisor/location`]);
        this.getLocations(10);
      });
    });
  }

  gotoEdit(selectedId, name, locationId,elementId) {
    console.log('location id:', locationId);

    if (selectedId == 3) {
      this.router.navigate(['/supervisor/edit-location/cs-zone/' + name + '/' + locationId + '/' + elementId]);
    }
    else if (selectedId == 1) {
      this.router.navigate(['/supervisor/edit-location/pf-zone/' + name + '/' + locationId + '/' + elementId]);
    }
    else {
      this.router.navigate(['/supervisor/edit-location/market-zone/' + name + '/' + locationId + '/' + elementId]);
    }
  }


  deleteLocation(id) {
    const req = {
      locationId: id,
    };
    this.custUtils.translateMessageObject({
      title: this.translate.instant('Delete Location'),
      text: 'This location will be removed from location list and won’t be selectable for new missions. But it won’t affect all missions already created. Are you sure you want to delete it?',
      type: 'warning',
      outsideClick: false,
      cancelBtnText: 'No',
      confirmBtnText: 'Yes',
      showCancelBtn: true
    }, message => {
      this.custUtils.translateAndPop(message).then(() => {
        this.gotoDelete(req);
      }).catch(() => {
        console.log('hi');
        this.router.navigate([`/supervisor/location`]);
        this.getLocations(10);
      });
    });
  }

  gotoDelete(req) {
    this.locationLoader = true;
    this.api.deleteLocation(req).subscribe(res => {
      this.custUtils.translateMessageObject({
        title: 'Location deleted successfully!',
        text: '',
        type: 'success',
        outsideClick: false,
        cancelBtnText: '',
        confirmBtnText: 'Ok',
        showCancelBtn: false
      }, message => {
        this.custUtils.translateAndPop(message).then(() => {
          this.router.navigate([`/supervisor/location`]);
          this.selectedLocation = { 'name': 'Location Type' };
          this.getLocations(10);
        }).catch(() => {

        });
      });
    }, err => {
      this.custUtils.translateMessageObject({
        title: 'Something went wrong',
        text: 'Location not deleted, please try again',
        type: 'error',
        outsideClick: true,
        cancelBtnText: '',
        confirmBtnText: 'Ok',
        showCancelBtn: false
      }, message => {
        this.custUtils.translateAndPop(message).then(() => {
          this.router.navigate([`/supervisor/location`]);
          this.getLocations(10);
        }).catch(() => {
          this.router.navigate([`/supervisor/location`]);
          this.getLocations(10);
        });
      });
    });
  }

  /* dynamic css */
  dropdownClicked($event) { }
  /* Validators */
  isValidMissionDate(d) {
    let currentDate_ = new Date(UTILS.getDateFormatWithoutZero(UTILS.getDatePickerDateFormat(new Date()))).getTime();
    let startDateMission = new Date(UTILS.getDateFormatWithoutZero(d)).getTime();
    return startDateMission > currentDate_;
  }
  /* Validators */
  /* Local Utility functions */
  getTransformedDate(d: string) {
    const d_ = (d) ? new Date(d.replace(/\s/g, "T")) : null;
    if (d_) return this.datePipe.transform(d_, 'yyyy-MM-dd');
    else return 'NA';
  }
  /* getters */
  /* Search and toggle the search input box */
  clearSearch() {
    this.searchKey = '';
    this.isSearch = false;
    this.selectedLocation = { 'name': 'Location Type' };

    this.getLocations(10);
  }

  /* Search and toggle the search input box */
  sortOrders(property) {

    this.sortType = property;
    this.sortReverse = !this.sortReverse;
    this.isClicked = !this.isClicked;
    this.filteredOrders.sort(this.dynamicSort(property));
  }

  sortOrders1(property) {

    this.type = property;
    this.sortReverse = !this.sortReverse;
    this.isClicked = !this.isClicked;
    this.filteredOrders.sort(this.dynamicSort1(property));
  }


  dynamicSort1(property) {
    let sortOrder = 1;

    if (this.sortReverse)
      sortOrder = -1;
    return function (a, b) {

      let result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;

      return result * sortOrder;
    }
  }


  dynamicSort(property) {
    let sortOrder = 1;

    if (this.sortReverse) {
      sortOrder = -1;
    }
    return function (a, b) {

      let result = (a[property].toLowerCase() < b[property].toLowerCase()) ? -1 : (a[property].toLowerCase() > b[property].toLowerCase()) ? 1 : 0;

      let data = result * sortOrder;
      return data;
    }
  }

  filterOrders(search: string, location) {
    console.log("location=", location);
    // var items = search.split(' ').filter(o => o).map(o => o.toLowerCase());
    // this.filteredOrders = this.filteredOrders.filter(o => {
    //   for (var item of items) {
    //     var flag = false;
    //     for (var prop in o) {
    //       if (prop != '$$hashKey' && (o[prop] + '').toLowerCase().indexOf(item) != -1) {
    //         flag = true;
    //         break;
    //       }
    //     }
    //     if (!flag)
    //       return false;
    //   }
    //   return true;

    // });
    // console.log('filteredOrders', this.filteredOrders);
    // if( this.filteredOrders.length===0){
    let locationId;
    if (location !== 'Location Type') {

      if (location == 'Circuit') {
        locationId = 1;
      } else if (location == 'Market Zone') {
        locationId = 2;
      } else if (location == 'Survey Zone') {
        locationId = 3;
      }
      this.locationName = "name," + search;
      this.locationType = "locationType," + locationId;
      // this._event.broadcast({ eventName: 'showLoader', data: '' });
      this.locationLoader = true;  
      // this.subscriptions.push(this.apiService.getLocations({ 'searchBy': locationName, 'filterBy': locationType,'size': 10 })
      this.api.getLocations({ 'searchBy': this.locationName, 'filterBy': this.locationType }).subscribe(res => {
        this.pagination = res.data;
        this.locations = (!isNull(res.data)) ? res.data.content : [];
        this.selectedLocation = { 'name': location };

        this.locationLoader = false;
        this.filteredOrders = this.locations;
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
      }, err => {
        this.filteredOrders = [];
        this.locations = [];
        this.selectedLocation = { 'name': 'Location Type' };
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.locationLoader = false;
      });
    }
    else {
      const locationName = "name," + search;
      // const locationType="locationType,"+location;
      // this._event.broadcast({ eventName: 'showLoader', data: '' });
      this.locationLoader = true;
      this.subscriptions.push(this.apiService.getLocations({ 'searchBy': locationName, 'size': 10 })
        .subscribe(res => {

          this.pagination = res.data;
          this.locations = (!isNull(res.data)) ? res.data.content : [];

          this.locationLoader = false;
          this.filteredOrders = this.locations;
          this.selectedLocation = { 'name': 'Location Type' };
          console.log('locations', this.locations, 'order', this.filteredOrders);
          // this.('name',);
          this._event.broadcast({ eventName: 'hideLoader', data: '' });
        }, err => {
          this.filteredOrders = [];
          this.locations = [];
          this.selectedLocation = { 'name': 'Location Type' };

          this._event.broadcast({ eventName: 'hideLoader', data: '' });
          this.locationLoader = false;
        }));

    }
  }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }

  viewMore(pagination, location) {

    pagination.numberOfElements = 10 + pagination.numberOfElements;
    let locationId;
    if (location !== 'Location Type') {

      if (location == 'Circuit') {
        locationId = 1;
      } else if (location == 'Market zone') {
        locationId = 2;
      } else if (location == 'Survey zone') {
        locationId = 3;
      }
      this.locationType = "locationType," + locationId;
      // this._event.broadcast({ eventName: 'showLoader', data: '' });
      this.locationLoader = true;

      // this.subscriptions.push(this.apiService.getLocations({ 'searchBy': locationName, 'filterBy': locationType,'size': 10 })
      this.api.getLocations({ 'filterBy': this.locationType, 'sortBy': 'locationName,asc', size: pagination.numberOfElements }).subscribe(res => {
        this.pagination = res.data;
        this.locations = (!isNull(res.data)) ? res.data.content : [];
        this.selectedLocation = { 'name': location };

        this.locationLoader = false;
        this.filteredOrders = this.locations;
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
      }, err => {
        this.filteredOrders = [];
        this.locations = [];
        this.selectedLocation = { 'name': 'Location Type' };

        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        this.locationLoader = false;
      });
    }
    else {

      this.locationLoader = true;
      this.subscriptions.push(this.apiService.getLocations({ 'sortBy': 'locationName,asc', 'size': pagination.numberOfElements })
        .subscribe(res => {
          this.pagination = res.data;
          this.locations = (!isNull(res.data)) ? res.data.content : [];

          this.locationLoader = false;
          this.filteredOrders = this.locations;
          this.selectedLocation = { 'name': 'Location Type' };
          console.log('locations', this.locations, 'order', this.filteredOrders);
          // this.('name',);
          this._event.broadcast({ eventName: 'hideLoader', data: '' });
        }, err => {
          this.filteredOrders = [];
          this.locations = [];
          this.selectedLocation = { 'name': 'Location Type' };

          this._event.broadcast({ eventName: 'hideLoader', data: '' });
          this.locationLoader = false;
        }));

    }
  }
  @ViewChild ('surveySelectionModal') reassignModal1;
  openModal(){
    this.modalRef = this.modalService.open(this.reassignModal1, {
          backdrop: false,
          keyboard: false,
      })
  }
  close(){
    this.modalRef.close();
  }

  submitSurveyType(selectedMissionType) {
    if(selectedMissionType==3){
    this.router.navigate([`/supervisor/location/cs-zone/${selectedMissionType}`]);
    this.modalRef.close();
    }
    else if(selectedMissionType==1){
      this.router.navigate([`/supervisor/location/pf-zone/${selectedMissionType}`]);
      this.modalRef.close();
    }
    else{
      this.router.navigate([`/supervisor/location/market-zone/${selectedMissionType}`]);
      this.modalRef.close();
    }
  }
}
