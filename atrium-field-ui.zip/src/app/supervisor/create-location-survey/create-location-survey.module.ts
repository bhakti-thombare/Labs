// core
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// 3rd party
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxMapboxGLModule } from 'ngx-mapbox-gl';
import { ChartsModule } from 'ng2-charts';
import { TagInputModule } from 'ngx-chips';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { TranslateModule } from '@ngx-translate/core';
import { Ng4FilesModule } from 'angular4-files-upload';
import { NgSelectModule } from '@ng-select/ng-select';

// app 
import { CONFIG } from '@app/config';
import { PipesModule } from '@pipes/pipes.module';
import { CsZoneComponent } from '@app/supervisor/create-location-survey/cs-zone/cs-zone.component';
import { PfCircuitComponent } from './pf-circuit/pf-circuit.component';
import { StandsMarketComponent } from './stands-market/stands-market.component';
import { CircleLocationMapComponent } from './create-location-survey-utils/circle-location-map/circle-location-map.component';
import { CreateLocationSurveyUtilsModule } from './create-location-survey-utils/create-location-survey-utils.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    PipesModule,
    TranslateModule,
    NgxChartsModule,
    CreateLocationSurveyUtilsModule,
    TagInputModule,
    ChartsModule,
    Ng4FilesModule,
    FormsModule,
    ReactiveFormsModule,
    NgxMapboxGLModule.forRoot({
      accessToken: CONFIG.mapBoxAccessToken
    }),
    SelectDropDownModule,
    NgSelectModule
  ],
  exports: [CsZoneComponent, PfCircuitComponent, StandsMarketComponent],
  declarations: [CsZoneComponent, PfCircuitComponent, StandsMarketComponent, CircleLocationMapComponent]
})
export class CreateLocationSurveyModule { }
