import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CsZoneComponent } from './cs-zone.component';

describe('CsZoneComponent', () => {
  let component: CsZoneComponent;
  let fixture: ComponentFixture<CsZoneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CsZoneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CsZoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
