import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StandsMarketComponent } from './stands-market.component';

describe('StandsMarketComponent', () => {
  let component: StandsMarketComponent;
  let fixture: ComponentFixture<StandsMarketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StandsMarketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandsMarketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
