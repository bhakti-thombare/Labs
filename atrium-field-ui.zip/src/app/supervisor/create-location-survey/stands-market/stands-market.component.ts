import { Component, OnInit, ElementRef, Renderer2, AfterViewInit } from '@angular/core';
import { ApiService } from '@app/services/apiServices/api.service';
import { EventService } from '@app/services/events/event.service';
import { HttpService } from '@app/services/http-service';
import { HttpClient } from '@angular/common/http';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { CreateSurveyUtilsService } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.service';
import { missionTypes, ApiConstants } from '@app/constants/constants';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { map } from 'rxjs/operator/map';
import { PedestrainAlertsService } from '@app/services/Alerts/pedestrainAlerts/pedestrain-alerts.service';


declare var google: any;

@Component({
  selector: 'app-stands-market',
  templateUrl: './stands-market.component.html',
  styleUrls: ['./stands-market.component.css']
})
export class StandsMarketComponent implements OnInit{

  // cleaveForm: FormGroup;
  today = new Date(Date.now());

  minDate = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };

  minEndDate = {
    day: null,
    month: null,
    year: null
  };
  check=false;
  check1=false;
  check2=false;
  check3=false;
  check4=false;
 check5=false;
 check6=false;
 check7=false;


  model: NgbDateStruct;
  timeInput: '=';
  validation: '=';
  preValue = '';
  timeRegex = /(1[012]|[1-9]|0[1-9]):[0-5][0-9]/;

  createMissionForm: FormGroup = new FormGroup({
    missionStartDate: new FormControl('', Validators.required),
    missionEndDate: new FormControl('', Validators.required),
    estimatedTimeHourHour: new FormControl('', Validators.required),
    estimatedTimeHourMin: new FormControl('', Validators.required),
    shortName: new FormControl('', Validators.required),
    officilatName: new FormControl('', Validators.required),
    missionDescription: new FormControl('')
  });
  marketLoaded: boolean;
  existingMarkets = [];
  existingMarketsFound: boolean;
  tempmissions: any;
  missions: any;
  missionsLoaded: boolean;
  marketNameDisabled: boolean;
  step2Completed: any;
  disableStep2: boolean;
  marketZoneId: any;
  market: any;
  datepickers = [];
  busyDates = [];

  user = JSON.parse(localStorage.getItem('user-data'));
  mapObject: any = {}
  mission = {
    selectedCampaign: {
      startDateObj: {},
      endDateObj: {}
    },
    markets: [],
    assignments: [],
    missionStartDate: '',
    missionEndDate: '',
    estimatedTimeHour: null,
    estimatedTimeMinutes: null,
    missionName: '',
    missionDescription: ''
  };
  calendarReady: boolean = false;
  missionTypesLoaded: boolean;
  missionTypes: any[];
  selectedMissionType: any;


  zoneNameDisabled = true;

  rerender = false;
  campaignsLoaded: boolean;
  campaigns: any;
  time2: any;
  endDate: string;

  constructor(public http: HttpClient,
    private fb: FormBuilder,
    public rd: Renderer2,
    public el: ElementRef,
    public router: Router,
    public route: ActivatedRoute,
    public event: EventService,
    public _http: HttpService,
    public custUtils: CreateSurveyUtilsService,
    public pedestrainAlertsService: PedestrainAlertsService,
    public api: ApiService,
    public location: Location) {
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this._http.pullCountry().subscribe(res => { }, err => { });
    const date = new Date(Date.now());
    const month = date.getMonth() + 1;
    localStorage.removeItem('busyDates');
    this.api.getUsedMissionDates(date.getFullYear() + '-' + month + '-' + date.getDate(), 4)
      .subscribe(res => {
        let busyDatesLen = res.dateDto.length;
        res.dateDto.forEach(resdate => {
          resdate.day = parseInt(resdate.day, 10);
          resdate.month = parseInt(resdate.month, 10);
          resdate.year = parseInt(resdate.year, 10);
          this.busyDates.push(resdate);
          busyDatesLen--;
          if (busyDatesLen === 0) {
            localStorage.setItem('busyDates', JSON.stringify(this.busyDates));
            this.calendarReady = true;
          }
        });
      }, err => {
        this.calendarReady = true;
      });
  }
  ngAfterViewInit() {}

  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6;
  }

  getCampaigns() {
    this.campaignsLoaded = false;
    this.api.getUserCampaigns(this.user.userId).subscribe(res => {
      this.custUtils.campaignsInitializer(res.data.campaigns, response => {
        if (response.message === 'campaignExpired') {
          this.custUtils.translateMessageObject({
            title: 'Campaign expired.',
            text: 'Please contact admin for more campaigns.',
            type: 'warning',
            outsideClick: true,
            showCancelBtn: false,
            confirmBtnText: 'OK',
            cancelBtnText: ''
          }, (responseMessageObject) => {
            this.custUtils.translateAndPop(responseMessageObject).then(() => {
              this.location.back();
            }).catch(() => {
              this.location.back();
            });
          });
        } else if (response.message === 'success') {
          this.campaigns = response.campaigns;
          this.mission.selectedCampaign = this.campaigns[0];
          localStorage.setItem('campaignStartDate', JSON.stringify(this.mission.selectedCampaign.startDateObj));
          localStorage.setItem('campaignEndDate', JSON.stringify(this.mission.selectedCampaign.endDateObj));
          this.campaigns.splice(0, 1);
          this.campaignsLoaded = true;
        }
      });
    }, err => { });
  }

  ngOnInit() {
    this.mission.markets = [];
    // this.getCampaigns();
    this.getMissions(() => {
      this.getMarkets(() => {
        this.marketLoaded = true;
      });
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
    });
    this.getMissionTypes();
    // this.cleaveForm = this.fb.group({
    //   date1: ['', Validators.required],
    //   date2: ['', Validators.required],
    //   creditcard: ['', Validators.required],
    //   phone: ['', Validators.required],
    //   time1: ['', Validators.required],
    //   time2: ['', Validators.required],
    // });

    //  this.time2 = new Cleave('#scheduleMonOpen', {
    //   time: true,
    //   timePattern: ['h', 'm']
    // });
  }

  getMissions(cb) {
    this.api.getMissionsCreatedByOfMissionType(this.user.userId, missionTypes.STANDS_SURVEY_TYPE_ID).subscribe(res => {
      this.tempmissions = res.data.missions;
      this.custUtils.skipCalculator(res.data.missions, (missions, bool) => {
        this.mission = missions; // missions without zones
        this.missionsLoaded = true;
        cb();
      });
    }, err => {
      cb();
    });
  }

  getMarkets(cb) {
    const locationType = 'locationType,2';
    this.api.getLocations({ 'filterBy': locationType }).subscribe(res => {
      let marketsLength = res.data.content.length;
      if (res.data.content.length !== 0) {
        res.data.content.forEach(market => {
          this.existingMarkets.push(market);
          marketsLength--;
          if (marketsLength === 0) {
            if (this.existingMarkets.length !== 0) {
              this.existingMarketsFound = true;
            }
            this.marketObjectCreator(() => {
              cb();
            });
          }
        });
      }
    }, err => {
      this.existingMarketsFound = false;
      this.marketObjectCreator(() => {
        cb();
      });
    });
  }

  marketObjectCreator(cb) {
    this.mission.markets = [];
    this.mission.markets.push({
      officialName: undefined,
      shortName: undefined,
      address: undefined,
      lat: null,
      lng: null,
      adptId: null,
      startDate: null,
      endDate: null,
      expectedNumberOfStands: null,
      numberOfSubscribedStands: null,
      numberOfUnSubscribedStands: null,
      managementAuthority: null,
      existingMarketCheck: false,
      scheduleMonOpen: null,
      scheduleMonClose: null,
      scheduleTueOpen: null,
      scheduleTueClose: null,
      scheduleWedOpen: null,
      scheduleWedClose: null,
      scheduleThurOpen: null,
      scheduleThurClose: null,
      scheduleFriOpen: null,
      scheduleFriClose: null,
      scheduleSatOpen: null,
      scheduleSatClose: null,
      scheduleSunOpen: null,
      scheduleSunClose: null
    });
    if (this.missions !== undefined) {
      if (this.missions.length === 0) {
        cb();
      } else {
        let noZoneMissionLength = this.missions.length;
        this.missions.forEach(mission => {
          this.mission.markets[0].missions.push(mission);
          noZoneMissionLength--;
          if (noZoneMissionLength === 0) {
            this.mission.markets[0].selectedMission = this.mission.markets[0].missions[0];
            this.mission.markets[0].missions.splice(0, 1);
            cb();
          }
        });
      }
    } else {
      cb();
    }
  }

  macAddressFormat(mac, event) {
    // var macAddress = event.target.value.toUpperCase();
    if (!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) {
      event.preventDefault();
      event.stopPropagation();
    }
    else {
      if (event.keyCode != 13) {

        var macAddr = event.target.value;
        var rash;

        var alphaNum = /^[A-Za-z0-9]+$/;
        if (macAddr.includes(':')) {
          if (macAddr.length == 5) {
            // console.log('393', event.target.value);
            var parts = event.target.value.split(':');
            // console.log(parts);
            if (parts[1] > 59) {
              parts[1] = 59;
              event.target.value = parts[0] + ':' + parts[1];
              // console.log('425', event.target.value);
            }
            if (parts[0] > 24) {
              parts[0] = 24;
              event.target.value = parts[0] + ':' + parts[1];
              // console.log('425', event.target.value);
            }
            console.log('final', event.target.value);
          } else if (macAddr.length == 4) {
            // console.log('393', event.target.value);
            var parts = event.target.value.split(':');
            // console.log(parts);
            if (parts[1] > 5) {
              parts[1] = 5;
              event.target.value = parts[0] + ':' + parts[1];
              // console.log('425', event.target.value);
            }
            if (parts[0] > 24) {
              parts[0] = 24;
              event.target.value = parts[0] + ':' + parts[1];
              // console.log('425', event.target.value);
            }
            console.log('final', event.target.value);
          }
        }
        if (macAddr.length == 2 && alphaNum.test(macAddr)) {

          // macAddr = macAddr.replace(/(.{2})/g, "$1:").slice(0, -1);
          macAddr = macAddr + ':';
          event.target.value = macAddr;
          rash = event.target.value;
          console.log('389', event.target.value);
        }
        else if (macAddr.length == 2) {
          if (macAddr > 24) {
            event.target.value = 24;
            rash = event.target.value;
            console.log('395', event.target.value);
          }
          else
            if (macAddr > 12) {
              var count = macAddr - 12;
              event.target.value = 12 + count;
              rash = event.target.value;
              console.log(event.target.value);
            }

        }
        else if (!alphaNum.test(macAddr)) {
          console.log("only alpha-numeric allowed");
        }
      }
    }
  }

  macAddressFormat1(mac, event) {
    // var macAddress = event.target.value.toUpperCase();
    if (!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) {
      event.preventDefault();
      event.stopPropagation();
    }
    else {
      if (event.keyCode != 13) {

        var macAddr = event.target.value;
        var rash;

        var alphaNum = /^[A-Za-z0-9]+$/;
        if (macAddr.includes('/')) {
          if (macAddr.length == 5) {
            // console.log('393', event.target.value);
            var parts = event.target.value.split('/');
            // console.log(parts);
            if (parts[1] > 12) {
              parts[1] = 12;
              event.target.value = parts[0] + '/' + parts[1];
              // console.log('425', event.target.value);
            }
            if (parts[0] > 31) {
              parts[0] = 31;
              event.target.value = parts[0] + '/' + parts[1];
              // console.log('425', event.target.value);
            }

          } else if (macAddr.length == 4) {
            // console.log('393', event.target.value);
            var parts = event.target.value.split('/');
            // console.log(parts);
            if (parts[1] > 5) {
              parts[1] = 5;
              event.target.value = parts[0] + '/' + parts[1];
              // console.log('425', event.target.value);
            }
            if (parts[0] > 31) {
              parts[0] = 31;
              event.target.value = parts[0] + '/' + parts[1];
              // console.log('425', event.target.value);
            }
            console.log('final', event.target.value);
          }
        }
        if (macAddr.length == 2 && alphaNum.test(macAddr)) {

          // macAddr = macAddr.replace(/(.{2})/g, "$1:").slice(0, -1);
          macAddr = macAddr + '/';
          event.target.value = macAddr;
          rash = event.target.value;

        }
        else if (macAddr.length == 2) {
          if (macAddr > 31) {
            event.target.value = 31;
            rash = event.target.value;
            console.log('395', event.target.value);
          }
        }
        else if (!alphaNum.test(macAddr)) {
          console.log("only alpha-numeric allowed");
        }
      }
    }
  }

  getMissionTypes() {
    this.missionTypesLoaded = false;
    this.missionTypes = [];

    this.api.getMissionTypes().subscribe(res => {
      let typeLen = res.data.length;
      res.data.forEach(type => {
        if (type.id === 3 || type.id === 4) {
          this.missionTypes.push(type);
        }
        typeLen--;
        if (typeLen === 0) {
          if (this.missionTypes[0].id === 4) {
            this.selectedMissionType = this.missionTypes[0];
            this.missionTypes.splice(0, 1);
          } else {
            this.selectedMissionType = this.missionTypes[1];
            this.missionTypes.splice(1, 1);
          }
          this.missionTypesLoaded = true;
        }
      });
    }, err => {
      console.log('err', err);
    });
  }
  getLngLat(search, index, page) {
    const api = new google.maps.Geocoder;
    if (!(Array.isArray(search))) {
      search = search + ' Brussels';
      if (!this.step2Completed) {
        api.geocode({ address: search }, (result: any) => {
          if (result.length !== 0) {
            this.mission.markets[0].address = result[0].formatted_address;
            this.mission.markets[0].lng = result[0].geometry.location.lng();
            this.mission.markets[0].lat = result[0].geometry.location.lat();
            this.mapObject = { 'longitude': result[0].geometry.location.lng(), 'latitude': result[0].geometry.location.lat()};
          }else {
            this.pedestrainAlertsService.enterValidLocation();
          }
        });
      }
    }
    else {
      if (!this.step2Completed) {
        this.mission.markets[0].lng = search[0];
        this.mission.markets[0].lat = search[1];
        this.mapObject = { 'longitude': search[0], 'latitude': search[1] };
        api.geocode({ latLng: { lat: search[1], lng: search[0] } }, result => {
          if (result) this.mission.markets[0].address = result[0].formatted_address;
        });
      }
    }
  }

  instanceForCampaign(d1) {
    this.datepickers.push(d1);
  }

  saveAndOpen(form) {
    this.validateZone(form,() => {
      this.createMarket(form);
    })
  }


  validateZone(form,cb) {
    const market = this.mission.markets[0];
    if (market.existingMarketCheck) {
      cb();
    } else {
      if (this.mission.missionStartDate && this.mission.missionEndDate) {
        let startParts = this.mission.missionStartDate.split('/');
        let endParts = this.mission.missionEndDate.split('/');
        if (startParts[1] > endParts[1]) {
          this.custUtils.translateMessageObject({
            title: 'Enddate should be greater than Startdate',
            text: '',
            type: 'warning',
            cancelBtnText: '',
            confirmBtnText: 'OK',
            outsideClick: false,
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              console.log('hha');
            }).catch(() => {
              console.log('hha');
            });
          });
        }
        else if(startParts[1] == endParts[1]){
          if(startParts[0] > endParts[0]){
            this.custUtils.translateMessageObject({
              title: 'Enddate should be greater than Startdate',
              text: '',
              type: 'warning',
              cancelBtnText: '',
              confirmBtnText: 'OK',
              outsideClick: false,
              showCancelBtn: false
            }, message => {
              this.custUtils.translateAndPop(message).then(() => {
                console.log('hha');
              }).catch(() => {
                console.log('hha');
              });
            });
          }
          else{
            cb();    
          }
        }
        else{
        cb();
        }
      } 
      else {
        this.custUtils.translateMessageObject({
          title: 'All fields are mandatory',
          text: '',
          type: 'warning',
          cancelBtnText: '',
          confirmBtnText: 'OK',
          outsideClick: false,
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
            console.log('hha');
          }).catch(() => {
            console.log('hha');
          });
        });
      }
    }
  }


  // changeLocalDate(date) {
  //   this.mission.missionEndDate = {
  //     year: null,
  //     month: null,
  //     day: null
  //   };
  //   localStorage.setItem('date', JSON.stringify(date));
  //   this.minEndDate = date;
  // }

  createMarket(formData) {
    this.disableStep2 = true;

    const market = this.mission.markets[0];
    const reqObj = {
      shortName: market.shortName,
      officialName: market.officialName,
      locationTypeId: 2,
      locationId: market.id,
      startDate: this.mission.missionStartDate,
      endDate: this.mission.missionEndDate,
      createdBy: this.user.userId,
      updatedBy: this.user.userId,
      adptId: market.adptId,
      latitude: market.lat,
      longitude: market.lng,
      address: market.address,
      expectedNumberOfStands: market.expectedNumberOfStands,
      numberOfSubscribedStands: market.numberOfSubscribedStands,
      numberOfUnSubscribedStands: market.numberOfUnSubscribedStands,
      managementAuthority: market.managementAuthority,
      scheduleMonOpen: (market.scheduleMonOpen)?market.scheduleMonOpen+':00':null,
      scheduleMonClose: (market.scheduleMonClose)?market.scheduleMonClose+':00':null,
      scheduleTueOpen: (market.scheduleTueOpen)?market.scheduleTueOpen+':00':null,
      scheduleTueClose: (market.scheduleTueClose)?market.scheduleTueClose+':00':null,
      scheduleWedOpen: (market.scheduleWedOpen)?market.scheduleWedOpen+':00':null,
      scheduleWedClose: (market.scheduleWedClose)?market.scheduleWedClose+':00':null,
      scheduleThurOpen: (market.scheduleThurOpen)?market.scheduleThurOpen+':00':null,
      scheduleThurClose: (market.scheduleThurClose)?market.scheduleThurClose+':00':null,
      scheduleFriOpen: (market.scheduleFriOpen)?market.scheduleFriOpen+':00':null,
      scheduleFriClose: (market.scheduleFriClose)?market.scheduleFriClose+':00':null,
      scheduleSatOpen: ( market.scheduleSatOpen)?market.scheduleSatOpen+':00':null,
      scheduleSatClose: (market.scheduleSatClose)?market.scheduleSatClose+':00':null,
      scheduleSunOpen:( market.scheduleSunOpen)?market.scheduleSunOpen+':00':null,
      scheduleSunClose:(market.scheduleSunClose)?market.scheduleSunClose+':00':null,
    };
    this.createAndMapMarketWithMission(reqObj);
  }
  createAndMapMarketWithMission(req) {
    let marketName = req.name;
    this.api.addMarket(req).subscribe(res => {
      this.marketZoneId = res.responseMessage.split('! ')[2];
      this.custUtils.translateMessageObject({
        title: 'Market zone created successfully',
        text: '',
        type: 'success',
        outsideClick: true,
        cancelBtnText: '',
        confirmBtnText: 'Ok',
        showCancelBtn: false
      }, message => {
        this.custUtils.translateAndPop(message).then(() => {
          this.step2Completed = true;
          this.router.navigate([`/supervisor/location`]);
        }).catch(() => {
          this.router.navigate([`/supervisor/location`]);
          this.step2Completed = true;
        });
      });
    }, err => {
      let response = JSON.parse(err._body);
      if (response.responseMessage === "undefined") {
        this.custUtils.translateMessageObject({
          title: 'Something went wrong!',
          text: 'Market zone not created please try again',
          type: 'error',
          outsideClick: true,
          cancelBtnText: '',
          confirmBtnText: 'Ok',
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
            this.disableStep2 = false;
          }).catch(() => {
            this.disableStep2 = false;
          });
        });
      } else {
        if (response.responseMessage.includes('Market Zone already exists!')) {
          let backEndString = response.responseMessage.split('Zone with ')[1];
          // let zoneName = backEndString.split(' already exists')[0];
          this.custUtils.translateMessageObject({
            title: 'Market with the same name already present',
            text: 'Please create market zone with unique name',
            type: 'error',
            outsideClick: false,
            cancelBtnText: '',
            confirmBtnText: 'Ok',
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.existingMarkets.forEach(extMarket => {
                if (extMarket.locationName.toLowerCase() === marketName.toLowerCase()) {
                  this.mapObject = { 'longitude': extMarket.longitude, 'latitude': extMarket.latitude };
                  this.market[0].selectedZone = extMarket;
                  this.market[0].existingMarketCheck = true;
                  this.event.broadcast({ eventName: 'existing-market-selected', data: extMarket.longitude + ',' + extMarket.latitude + ',' + 'map0' });

                }
              });
              this.disableStep2 = false;
            }).catch(() => {
              this.disableStep2 = false;
            });
          });
        } else {
          this.custUtils.translateMessageObject({
            title: 'All fields are mandatory',
            text: 'Please click on an area on Map for the latitude and longitude',
            type: 'error',
            outsideClick: true,
            cancelBtnText: '',
            confirmBtnText: 'Ok',
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.disableStep2 = false;
            }).catch(() => {
              this.disableStep2 = false;
            });
          });
        }
      }
    });
  }
  
monChecked(event){

  console.log("event=",event);
  if(event.target.checked){
    this.check=true;
  } else {
    console.log("false moi",this.mission);
    this.check=false;
    this.mission.markets[0].scheduleMonClose="";
    this.mission.markets[0].scheduleMonOpen="";
  }
  
}
tueChecked(event){
 console.log("event=",event);
 if(event.target.checked){
   this.check2=true;
 } else {
   this.check2=false;
   this.mission.markets[0].scheduleTueClose=""
    this.mission.markets[0].scheduleTueOpen=""
 }
 
}
wedChecked(event){
 console.log("event=",event);
 if(event.target.checked){
   this.check3=true;
 } else {
   this.check3=false;
   this.mission.markets[0].scheduleWedClose=""
    this.mission.markets[0].scheduleWedOpen=""
 }
 
}
thuChecked(event){
 console.log("event=",event);
 if(event.target.checked){
   this.check4=true;
 } else {
   this.check4=false;
   this.mission.markets[0].scheduleThurClose=""
    this.mission.markets[0].scheduleThurOpen=""
 }
 
}
friChecked(event){
 console.log("event=",event);
 if(event.target.checked){
   this.check5=true;
 } else {
   this.mission.markets[0].scheduleFriClose=""
    this.mission.markets[0].scheduleFriOpen=""
   this.check5=false;
 }
 
}
satChecked(event){
 console.log("event=",event);
 if(event.target.checked){
   this.check6=true;
 } else {
   this.mission.markets[0].scheduleSatClose=""
    this.mission.markets[0].scheduleSatOpen=""
   this.check6=false;
 }
 
}
sunChecked(event){
 console.log("event=",event);
 if(event.target.checked){
   this.check7=true;
 } else {
   this.mission.markets[0].scheduleSunClose=""
    this.mission.markets[0].scheduleSunOpen=""
   this.check7=false;
 }
 
}

  gotoCancel(event) {

    this.router.navigate([`/supervisor/location`]);
  }

  keyDown(e){
    // charCode > 31 && (charCode < 48 || charCode > 57)
    if(!(e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105)){
      e.preventDefault();
      e.stopPropagation();
    }
  }

  keyUp(e){
    if(!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58) 
      || e.keyCode == 8)) {
        e.preventDefault();
      e.stopPropagation();
    }
  }

  keyUp1(e){
    if(!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58) 
      || e.keyCode == 8)) {
        return false;
    }
  }

  isDisable(){
    if ((this.mission.markets[0].managementAuthority && this.mission.markets[0].officialName
      && this.mission.markets[0].adptId && this.mission.markets[0].address
      && (this.mission.markets[0].expectedNumberOfStands && this.mission.markets[0].expectedNumberOfStands!=='0') && (this.mission.markets[0].numberOfSubscribedStands==0 || this.mission.markets[0].numberOfSubscribedStands )
      && (this.mission.markets[0].numberOfUnSubscribedStands  || this.mission.markets[0].numberOfUnSubscribedStands==0) && this.mission.missionStartDate
      && this.mission.missionEndDate ))      
      {
        let list =  [];        
        if(this.check){
          list.push('Monday');
        }
        if(this.check2){
          list.push('Tuesday');
        }
        if(this.check3){
          list.push('Wednesday');
        }
        if(this.check4){
          list.push('Thursday');
        }
        if(this.check5){
          list.push('Friday');
        }
        if(this.check6){
          list.push('Saturday');
        }
        if(this.check7){
          list.push('Sunday');
        }

        let boolean = list.every((res,index)=>{
          if(res == 'Monday'){
            return this.mission.markets[0].scheduleMonOpen != "" && this.mission.markets[0].scheduleMonOpen != null && this.mission.markets[0].scheduleMonClose != "" && this.mission.markets[0].scheduleMonClose != null;
          }
          if(res == 'Tuesday'){
            return this.mission.markets[0].scheduleTueOpen != "" && this.mission.markets[0].scheduleTueOpen != null && this.mission.markets[0].scheduleTueClose != "" && this.mission.markets[0].scheduleTueClose != null;
          }
          if(res == 'Wednesday'){
            return this.mission.markets[0].scheduleWedOpen != "" && this.mission.markets[0].scheduleWedOpen != null && this.mission.markets[0].scheduleWedClose != "" && this.mission.markets[0].scheduleWedClose != null;
          }
          if (res == 'Thursday'){
            return this.mission.markets[0].scheduleThurOpen != "" && this.mission.markets[0].scheduleThurOpen != null && this.mission.markets[0].scheduleThurClose != "" && this.mission.markets[0].scheduleThurClose != null;
          }
          if (res == 'Friday'){
            return this.mission.markets[0].scheduleFriOpen != "" && this.mission.markets[0].scheduleFriOpen != null && this.mission.markets[0].scheduleFriClose != "" && this.mission.markets[0].scheduleFriClose != null;
          }
          if (res == 'Saturday'){
            return this.mission.markets[0].scheduleSatOpen != "" && this.mission.markets[0].scheduleSatOpen != null && this.mission.markets[0].scheduleSatClose != "" && this.mission.markets[0].scheduleSatClose != null;
          }
          if (res == 'Sunday'){
            return this.mission.markets[0].scheduleSunOpen != "" && this.mission.markets[0].scheduleSunOpen != null && this.mission.markets[0].scheduleSunClose != "" && this.mission.markets[0].scheduleSunClose != null;
          }
        });

        if(list.length > 0){
          if (boolean == true){
            return false;
          }
        }
      return true;
    }else{
      return true;
    }         
  }
}
