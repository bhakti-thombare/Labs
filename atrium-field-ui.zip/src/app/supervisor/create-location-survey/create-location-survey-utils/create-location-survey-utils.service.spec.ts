import { TestBed, inject } from '@angular/core/testing';

import { CreateLocationSurveyUtilsService } from './create-location-survey-utils.service';

describe('CreateLocationSurveyUtilsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CreateLocationSurveyUtilsService]
    });
  });

  it('should be created', inject([CreateLocationSurveyUtilsService], (service: CreateLocationSurveyUtilsService) => {
    expect(service).toBeTruthy();
  }));
});
