import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateLocationSurveyUtilsService } from './create-location-survey-utils.service';
import { HttpService } from '@app/services/http-service';


@NgModule({
  imports: [CommonModule],
  providers: [CreateLocationSurveyUtilsService, HttpService]
})
export class CreateLocationSurveyUtilsModule { }
