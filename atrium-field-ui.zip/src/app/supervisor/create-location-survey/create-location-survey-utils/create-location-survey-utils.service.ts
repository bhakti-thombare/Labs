import { Injectable } from '@angular/core';
import { HttpService } from '@app/services/http-service';
import { TranslateService } from '@ngx-translate/core';
import { TranslationService } from '@app/services/translation/translation.service';
import swal from 'sweetalert2';

@Injectable()
export class CreateLocationSurveyUtilsService {


  constructor(public http: HttpService, public translate: TranslateService, public translation: TranslationService) { }

  pedSkipCalc(missions, currStep, step2, cb) {
    const tempmissions = [];
    let len = missions.length;
    let showSkip: boolean;
    missions.forEach(mission => {
      if (mission.missionType.id === 3) {
        if (currStep === 2) {
          if (mission.missionCircuits.length === 0) {
            tempmissions.push(mission);
          }
        } else if (currStep === 3) {
          if (mission.missionCircuits.length > 0) {
            this.skipChecker(mission.missionCircuits, push => {
              if (push) {
                tempmissions.push(mission);
              }
            })
          }
        } else {
          tempmissions.push(mission);
        }
      } else if (mission.missionType.id !== 3) {
        tempmissions.push(mission);
      }

      len--;
      if (len === 0) {
        if (tempmissions.length > 0) {
          if (currStep === 1) {
            this.showSkip(tempmissions, skip => {
              cb({ message: 'success', data: tempmissions, skip1: skip });
            })
          } else {
            cb({ message: 'success', data: tempmissions, skip1: true });
          }
        } else {
          if (currStep === 2) {
            if (step2) {
              cb({ message: 'open', data: tempmissions, page: 3 });
            } else {
              cb({ message: 'skip', data: tempmissions, page: 2 });
            }
          } else {
            cb({ message: 'missionsNotLoaded' });
          }
        }
      }
    });
  }

  skipChecker(circuits, cb) {
    let circuitLen = circuits.length;
    let pushFlag = false;
    circuits.forEach(circuit => {
      if (circuit.circuitCheckpoints.length < 3) {
        pushFlag = true;
      }
      circuitLen--;
      if (circuitLen === 0) {
        if (pushFlag) {
          cb(true);
        }
      }
    });
  }

  showSkip(missions, cb) {
    let mlne = missions.length;
    let checkerArr = [];
    missions.forEach(miss => {
      if (miss.missionType.id === 3) {
        if (miss.missionCircuits.length > 0) {
          miss.missionCircuits.forEach(circuit => {
            if (circuit.circuitCheckpoints.length === 3) {
              checkerArr.push(true);
            } else {
              checkerArr.push(false);
            }
          });
        } else {
          checkerArr.push(false);
        }
      } else {
        checkerArr.push(false);
      }
      mlne--;
      if (mlne === 0) {
        if (checkerArr.includes(false)) {
          cb(true);
        } else {
          cb(false);
        }
      }
    });
  }

  campaignsInitializer(campaigns, cb) {
    let tempArr;
    tempArr = [];
    let len = campaigns.length;
    const today = new Date(Date.now());
    const todayDate = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    campaigns.forEach(camp => {
      const campStartDay = parseInt(camp.campaignStartDate.split('-')[2].split(' ')[0], 10);
      const campStartMonth = parseInt(camp.campaignStartDate.split('-')[1], 10);
      const campStartYear = parseInt(camp.campaignStartDate.split('-')[0], 10);
      camp.startDateObj = { year: campStartYear, month: campStartMonth, day: campStartDay };
      const startDate = new Date(campStartYear, campStartMonth - 1, campStartDay, 0, 0, 0, 0);
      const campEndDay = parseInt(camp.campaignEndDate.split('-')[2].split(' ')[0], 10);
      const campEndMonth = parseInt(camp.campaignEndDate.split('-')[1], 10);
      const campEndYear = parseInt(camp.campaignEndDate.split('-')[0], 10);
      camp.endDateObj = { year: campEndYear, month: campEndMonth, day: campEndDay };
      const endDate = new Date(campEndYear, campEndMonth - 1, campEndDay, 23, 59, 59, 0);
      if (endDate >= todayDate) {
        if (camp.campaignStatus.statusId !== 1) {
          if (!camp.campaignIsArchived) {
            tempArr.push(camp);
          }
        }
      }
      len--;
      if (len === 0) {
        if (tempArr.length === 0) {
          cb({ message: 'campaignExpired' });
        } else {
          cb({ message: 'success', campaigns: tempArr });
        }
      }
    });
  }

  translateAndPop(sweetAlertOptions) {
    return swal({
      title: sweetAlertOptions.title,
      text: sweetAlertOptions.text,
      type: sweetAlertOptions.type,
      allowOutsideClick: sweetAlertOptions.outsideClick,
      showCancelButton: sweetAlertOptions.showCancelBtn,
      confirmButtonText: sweetAlertOptions.confirmBtnText,
      cancelButtonText: sweetAlertOptions.cancelBtnText
    });
  }

  translateMessageObject(sweetAlertObj, cb) {
    let responseObject = sweetAlertObj;
    if (sweetAlertObj.title !== '') {
      this.translation.getLanguageValue(sweetAlertObj.title).subscribe((title) => {
        responseObject.title = title;
        if (sweetAlertObj.text !== '') {
          this.translation.getLanguageValue(sweetAlertObj.text).subscribe((text) => {
            responseObject.text = text;
            if (sweetAlertObj.confirmBtnText !== '') {
              this.translation.getLanguageValue(sweetAlertObj.confirmBtnText).subscribe((confirmBtnText) => {
                responseObject.confirmBtnText = confirmBtnText;
                if (sweetAlertObj.cancelBtnText !== '') {
                  this.translation.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
                    responseObject.cancelBtnText = cancelBtnText;
                    cb(responseObject);
                  });
                } else {
                  cb(responseObject);
                }
              });
            } else if (sweetAlertObj.cancelBtnText !== '') {
              this.translation.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
                responseObject.cancelBtnText = cancelBtnText;
                cb(responseObject);
              });
            } else {
              cb(responseObject);
            }
          });
        } else if (sweetAlertObj.confirmBtnText !== '') {
          this.translation.getLanguageValue(sweetAlertObj.confirmBtnText).subscribe((confirmBtnText) => {
            responseObject.confirmBtnText = confirmBtnText;
            if (sweetAlertObj.cancelBtnText !== '') {
              this.translation.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
                responseObject.cancelBtnText = cancelBtnText;
                cb(responseObject);
              });
            } else {
              cb(responseObject);
            }
          });
        } else if (sweetAlertObj.cancelBtnText !== '') {
          this.translation.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
            responseObject.cancelBtnText = cancelBtnText;
            cb(responseObject);
          });
        } else {
          cb(responseObject);
        }
      });
    } else if (sweetAlertObj.text !== '') {
      this.translation.getLanguageValue(sweetAlertObj.text).subscribe((text) => {
        responseObject.text = text;
        if (sweetAlertObj.confirmBtnText !== '') {
          this.translation.getLanguageValue(sweetAlertObj.confirmBtnText).subscribe((confirmBtnText) => {
            responseObject.confirmBtnText = confirmBtnText;
            if (sweetAlertObj.cancelBtnText !== '') {
              this.translation.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
                responseObject.cancelBtnText = cancelBtnText;
                cb(responseObject);
              });
            } else {
              cb(responseObject);
            }
          });
        } else if (sweetAlertObj.cancelBtnText !== '') {
          this.translation.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
            responseObject.cancelBtnText = cancelBtnText;
            cb(responseObject);
          });
        } else {
          cb(responseObject);
        }
      });
    } else if (sweetAlertObj.confirmBtnText !== '') {
      this.translation.getLanguageValue(sweetAlertObj.confirmBtnText).subscribe((confirmBtnText) => {
        responseObject.confirmBtnText = confirmBtnText;
        if (sweetAlertObj.cancelBtnText !== '') {
          this.translation.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
            responseObject.cancelBtnText = cancelBtnText;
            cb(responseObject);
          });
        } else {
          cb(responseObject);
        }
      });
    } else if (sweetAlertObj.cancelBtnText !== '') {
      this.translation.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
        responseObject.cancelBtnText = cancelBtnText;
      });
    } else {
      cb(responseObject);
    }
  }

  skipCalculator(missions, cb) {
    let skipCheck = false;
    let responseMissions = [];
    let missionLength = missions.length;
    missions.forEach(mission => {
      if (mission.missionZones.length === 0) {
        responseMissions.push(mission);
        skipCheck = true;
      }
      missionLength--;
      if (missionLength === 0) {
        if (skipCheck) {
          cb(responseMissions, true);
        } else {
          cb(responseMissions, false);
        }
      }
    });
  }

  nameParser(geometries, cb) {
    cb(geometries);
  }
}
