import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CircleLocationMapComponent } from './circle-location-map.component';

describe('CircleLocationMapComponent', () => {
  let component: CircleLocationMapComponent;
  let fixture: ComponentFixture<CircleLocationMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CircleLocationMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CircleLocationMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
