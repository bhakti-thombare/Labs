import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PfCircuitComponent } from './pf-circuit.component';

describe('PfCircuitComponent', () => {
  let component: PfCircuitComponent;
  let fixture: ComponentFixture<PfCircuitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PfCircuitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PfCircuitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
