// core imports
import { Component, OnInit, EventEmitter, Output, ViewChild, ElementRef, Renderer2, AfterViewInit } from '@angular/core';
import { Location } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, Validators } from '@angular/forms';

// 3rd party
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

// app
import { ApiConstants } from '@app/constants/constants';
import { EventService } from '@services/events/event.service';
import { HttpService } from '@app/services/http-service';
import { CreateSurveyUtilsService } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.service';
import { ApiService } from '@services/apiServices/api.service';
import { missionTypes, statuses } from '@app/constants/constants';
import { Router } from '@angular/router';
import { UTILS } from '@app/services/global-utility.service';
import { CampaignSummaryService } from '@services/campaign-summary/campaign-summary.service'
import { TranslateService } from '@ngx-translate/core';
import { PedestrainAlertsService } from '@app/services/Alerts/pedestrainAlerts/pedestrain-alerts.service';

declare var google: any;

@Component({
  selector: 'app-stands',
  templateUrl: './stands.component.html',
  styleUrls: ['./stands.component.css']
})
export class StandsComponent implements OnInit {

  @Output() surveyChange = new EventEmitter();

  @ViewChild('stepOne') stepOne: ElementRef;
  @ViewChild('stepTwo') stepTwo: ElementRef;
  @ViewChild('zonesDropdown') zonesDropdown: ElementRef;
  mapObject: any = []
  xmlHttpUrl = ApiConstants.BASE_URL;

  today = new Date(Date.now());
  currentDate = new Date(Date.now());
  minDate = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };

  minEndDate = {
    day: null,
    month: null,
    year: null
  };

  model: NgbDateStruct;

  createMissionForm: FormGroup = new FormGroup({
    missionStartDate: new FormControl('', Validators.required),
    missionEndDate: new FormControl('', Validators.required),
    estimatedTimeHourHour: new FormControl('', Validators.required),
    estimatedTimeHourMin: new FormControl('', Validators.required),
    missionName: new FormControl('', Validators.required),
    missionDescription: new FormControl('')
  });

  morning = true;

  user = JSON.parse(localStorage.getItem('user-data'));
  showSkipInStep1: boolean;
  step1: boolean;
  step2: boolean;
  loaderOn: boolean;
  step3: boolean;
  step4: boolean;
  step1Completed = false;
  step2Completed: boolean;
  step3Completed: boolean;
  step4Completed: boolean;
  hideStep1 = false;
  hideStep2 = true;
  hideStep3 = true;
  hideStep4 = true;
  hideStep5 = true;
  marketOpen = [];
  pageOpenAllowed: boolean;
  campaignsLoaded: boolean;
  assignmentsLoaded = false;
  existingZonesCheck = false;
  missionsLoaded = false;
  summaryLoaded = false;
  missionTypesLoaded: boolean;
  calendarReady = false;
  selectedMissionType: any;
  missionTypes: any;
  showNewAssignmentBtn = true;
  existingMarketsFound = false;
  existingZones = [];
  disableStep1 = false;
  disableStep2 = false;
  disableStep3 = false;
  disableStep4 = false;
  zoneMissionFound = false;
  loadMapForExistingCircuit = false;
  disableMapClick = false;
  datepickers = [];
  fieldAgents = [];
  busyDates = [];
  summaryObj;
  shifts = [
    {
      shiftName: 'Morning',
      timeRange: '8:45 - 13:00',
      startTime: '8:45',
      endTime: '13:00'
    },
    {
      shiftName: 'Afternoon',
      timeRange: '13:00 - 17:15',
      startTime: '13:00',
      endTime: '17:15'
    }
  ];
  campaignFlag = false;
  prev: number;

  campaigns = [];

  missions: any;
  tempmissions: any;

  zones: any;

  zoneLoaded = false;

  missionId: string;

  freeUsers = [];

  summary = {
    mission: {},
    zones: [],
    assignments: []
  };
  marketMissionLoaded = false;
  parent2Toggle;
  mission = {
    selectedCampaign: {
      campaignEndDate: '',
      campaignStartDate: '',
      startDateObj: {},
      endDateObj: {},
      campaignName:this.translate.instant('Select compaign')
    },
    markets: [],
    selectedMarket: [],
    assignments: [],
    missionStartDate: {
      year: null,
      month: null,
      day: null
    },
    missionEndDate: {
      year: null,
      month: null,
      day: null
    },
    missionEndDate1:'',
    missionStartDate1:'',
    estimatedTimeHour: null,
    estimatedTimeMinutes: null,
    missionName: '',
    missionDescription: ''
  };

  zoneNameDisabled = true;

  rerender = false;
  marketLoaded = false;
  existingZonesFound: boolean = false;
  marketNameDisabled: boolean;
  assignmnts: any[];
  endDate: string;
  placeName: any;
  flag1: boolean =true;

  constructor(public http: HttpClient,
    public pedestrainAlertsService: PedestrainAlertsService,
    public rd: Renderer2,
    private router: Router,
    public el: ElementRef,
    public event: EventService,
    public _http: HttpService,
    private location: Location,
    private campaign: CampaignSummaryService,
    public custUtils: CreateSurveyUtilsService,
    public translate:TranslateService,
    public api: ApiService) {
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this._http.pullCountry().subscribe(res => { }, err => { });

  }

  getMissionDates(){
    const date = new Date(Date.now());
    const month = date.getMonth() + 1;
    localStorage.removeItem('busyDates');
    this.busyDates=[]
    this.api.getShiftWiseUsedMissionDates(date.getFullYear() + '-' + month + '-' + date.getDate(), 7,this.morning?1:2)
      .subscribe(res => {
        let busyDatesLen = res.dateDto.length;
        res.dateDto.forEach(resdate => {
          resdate.day = parseInt(resdate.day, 10);
          resdate.month = parseInt(resdate.month, 10);
          resdate.year = parseInt(resdate.year, 10);
          this.busyDates.push(resdate);
          busyDatesLen--;
          if (busyDatesLen === 0) {
            localStorage.setItem('busyDates', JSON.stringify(this.busyDates));
            this.calendarReady = true;
          }
        });
      }, err => {
        this.calendarReady = true;
      });
  }

  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6;
  }

  isDisabled(date: NgbDateStruct, current: { month: number }) {
    // console.log("market open=",this.marketOpen);
    // this.marketOpen=[1,2]
    const d = new Date(date.year, date.month - 1, date.day);
    if (localStorage.getItem('campaignFlag') === 'false') {

      return false
    } else {

      const now = new Date(Date.now());
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));

      const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
      const busyDates = JSON.parse(localStorage.getItem('busyDates'));
      const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
      const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
      const sdate = new Date(date.year, date.month - 1, date.day);

      if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
        if (busyDates !== null) {
          let found = -1;
          const dateFinder = (dateObj) => {
            const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));



            if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
              inDate.getDate() === sdate.getDate()) {
              return true;
            } else {
              return false;
            }
          };

          found = busyDates.findIndex(dateFinder);

          let available = !busyDates.findIndex(dateFinder)

          if (found !== -1) {
            return true

          } else {
            let market = JSON.parse(localStorage.getItem('marketOpen'));
            market = JSON.parse(localStorage.getItem("marketOpen"))

            if (d.getDay() === market[0] || d.getDay() === market[1] || d.getDay() === market[2] || d.getDay() === market[3] ||
              d.getDay() === market[4] || d.getDay() === market[5] || d.getDay() === market[6] || d.getDay() === market[7]) {

              return true;

            }


          }
        } else {
          console.log("not busy=available");
          let market = JSON.parse(localStorage.getItem('marketOpen'));
          market = JSON.parse(localStorage.getItem("marketOpen"))

          if (d.getDay() === market[0] || d.getDay() === market[1] || d.getDay() === market[2] || d.getDay() === market[3] ||
            d.getDay() === market[4] || d.getDay() === market[5] || d.getDay() === market[6] || d.getDay() === market[7]) {

            return true;

          } else {
            return false;
          }

        }
      } else {
        return true;
      }
    }
  }

  isEndDisabled(date: NgbDateStruct, current: { month: number }) {
    const localDate = JSON.parse(localStorage.getItem('date'));
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const minDate = new Date(localDate.year, localDate.month, localDate.day);
    const campaignStartDate = new Date(startCheck.year, startCheck.month, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month, endCheck.day);
    const sdate = new Date(date.year, date.month, date.day);

    if (sdate >= minDate && sdate >= campaignStartDate && sdate <= campaignEndDate) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };

        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return true;
    }
  }
  marketZone;
  getMarketZone(cb) {
    this.api.getMarketZone(this.user.userId).subscribe(res => {
      this.marketZone = res.data;
      let marketsLength = res.data.length;
      if (marketsLength !== 0) {
        this.marketZone.forEach(zone => {
          this.existingZones.push(zone);
          marketsLength--;
          if (marketsLength === 0) {
            if (this.existingZones.length !== 0) {
              this.existingMarketsFound = true;
            }
            this.zoneObjectCreator(() => {
              cb();
            });
          }
        });
      }
    }, err => {
      this.existingMarketsFound = false;
      this.zoneObjectCreator(() => {
        cb();
      });
    });
  }
  textControl = new FormControl();
  textControl1 = new FormControl();

  nameExists = false;
  selectedMarketZoneValue = "Select Market Zone"
  selectedMarketZone(id, name) {
    console.log("id=", id);
    this.marketid = id;
    this.selectedMarketZoneValue = name;
    console.log("selectedMarketZoneValue=", this.selectedMarketZoneValue);

  }
  name = false;
  description = false;
  buttonEnabled = false;

  ngOnInit() {
    this.placeName=this.translate.instant('Select compaign');
    this.mission.missionEndDate = null;
    this.mission.missionStartDate = null;
    // console.log('this.createMissionForm=',this.createMissionForm)
    this.textControl1.valueChanges.pipe(
    ).subscribe((res) => {
      res = res.trim()
      if (res !== '') {
        this.description = true
      } else {
        this.description = false
      }
      //  console.log("this.name1=",this.name,this.description);

      if (this.name && this.description) {
        this.buttonEnabled = true;
      } else {
        this.buttonEnabled = false;
      }
    });
    this.textControl.valueChanges.pipe(
    ).subscribe((res) => {
      res = res.trim()
      if (res !== '') {
        this.name = true
      } else {
        this.name = false
      }
      console.log("this.name1=", this.name, this.description);

      if (this.name && this.description) {
        this.buttonEnabled = true;
      } else {
        this.buttonEnabled = false;
      }
      if (res !== '') {
        // console.log("res=",res)
        this.api.getMissionName(res).subscribe((res) => {
          this.name = true;
          this.nameExists = false;
        }, (error) => {
          this.name = false;
          this.nameExists = true;
        })
      }
    });

    this.mission.markets = [];
    this.step1 = true;
    this.prev = 1;
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this.getCampaigns();
    this.getMissions(() => {
      this.getMarketZone(() => {
        this.marketLoaded = true;
      });
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
    });
    this.getMissionTypes();
    $('.mapboxgl-canvas').css('width', '100%');
    $('.mapboxgl-canvas').css('height', '100%');
  }

  ngAfterViewInit() {
    $('app-stands').on('click', (e) => {
      setTimeout(() => {
        if (this.existingZonesCheck) {
          if (e.target.className === 'nav-link mission-dd open-dd' || e.target.id === 'openDD') {
            if (!e.target.parentNode.className.includes('show')) {
              this.parent2Toggle = this.zonesDropdown.nativeElement;
              this.classAdder();
            } else if (e.target.parentNode.className.includes('show')) {
              this.parent2Toggle = this.zonesDropdown.nativeElement;
              this.classRemover();
            }
          } else if (e.target.id === 'searchZoneName' || e.target.id === 'dontHideDD1' || e.target.id === 'dontHideDD2' || e.target.id === 'dontHideDD3' || e.target.id === 'dontHideDD4') {

          } else {
            this.parent2Toggle = this.zonesDropdown.nativeElement;
            this.classRemover();
          }
        }
      }, 100);
    });
  }

  classRemover() {
    this.rd.removeClass(this.parent2Toggle.parentNode, 'show');
  }

  classAdder() {
    this.rd.addClass(this.parent2Toggle.parentNode, 'show');
  }

  getCampaigns() {
    this.campaignsLoaded = false;
    this.api.getUserCampaigns(this.user.userId).subscribe(res => {
      console.log("comapaigns==", res);

      this.custUtils.campaignsInitializer(res.data.campaigns, response => {
        if (response.message === 'campaignExpired') {
          this.custUtils.translateMessageObject({
            title: 'Campaign expired.',
            text: 'Please contact admin for more campaigns.',
            type: 'warning',
            outsideClick: true,
            showCancelBtn: false,
            confirmBtnText: 'OK',
            cancelBtnText: ''
          }, (responseMessageObject) => {
            this.custUtils.translateAndPop(responseMessageObject).then(() => {
              this.location.back();
            }).catch(() => {
              this.location.back();
            });
          });
        } else if (response.message === 'success') {

          const data = res.data;
          const today = new Date();
          const todaydate = new Date(
            today.getFullYear(),
            today.getMonth(),
            today.getDate()
          );
          if (this.campaign.selectedCampaign === undefined) {
            // this.mission.selectedCampaign=data.campaigns[1];
            data.campaigns.forEach(element => {
              if (element.campaignId !== this.mission.selectedCampaign['campaignId']) {

                data.campaigns.forEach(element => {
                  const campaignEndDate = new Date(element.campaignEndDate)

                  if (!(campaignEndDate < todaydate)) {

                    // this.mission.selectedCampaign = element;

                  }
                })

                const campaignEndDate = new Date(element.campaignEndDate)


                if (!(campaignEndDate < todaydate))
                  this.campaigns.push(element)
              }
            });

          } else {


            let campaignEndDate = new Date(this.campaign.selectedCampaign.campaignEndDate)
            if (campaignEndDate < todaydate) {

              data.campaigns.forEach(element => {
                if (campaignEndDate < todaydate) {

                  // this.mission.selectedCampaign = element;

                }
              })
            } else {
              // this.mission.selectedCampaign=this.campaign.selectedCampaign
            }



            data.campaigns.forEach(element => {
              if (element.campaignId !== this.mission.selectedCampaign['campaignId']) {
                campaignEndDate = new Date(element.campaignEndDate)

                if (!(campaignEndDate < todaydate)) {
                  this.campaigns.push(element)

                }
              }
            });
          }
          // this.mission.selectedCampaign=this.campaign.selectedCampaign;
          // data.campaigns.forEach(element => {
          //   if(element.campaignId!==this.campaign.selectedCampaign.campaignId){
          //     console.log("element",element);

          //       this.campaigns.push(element)
          //   }
          // });
          // this.campaigns.push();          
          // this.mission.selectedCampaign = data.campaigns[0];
          // localStorage.setItem('campaignStartDate', JSON.stringify(this.mission.selectedCampaign.startDateObj));
          // localStorage.setItem('campaignEndDate', JSON.stringify(this.mission.selectedCampaign.endDateObj));
          // this.campaigns.splice(0, 1);
          this.campaignsLoaded = true;
        }
      });
    }, err => { });
  }

  getMissions(cb) {
    this.api.getMissionsCreatedByOfMissionType(this.user.userId, missionTypes.CUSTOMER_SURVEY_TYPE_ID).subscribe(res => {
      this.tempmissions = res.data.missions;
      this.custUtils.skipCalculator(res.data.missions, (missions, bool) => {
        this.missions = missions; // missions without zones
        this.missionsLoaded = true;
        // if (bool) {
        this.showSkipInStep1 = true;
        // } else {
        //   this.showSkipInStep1 = false;
        // }
        cb();
      });
    }, err => {
      this.showSkipInStep1 = false;
      cb();
    });
  }
  zoneObjectCreator(cb) {
    this.mission.markets.push({
      id: null,
      shortName: undefined,
      officialName: undefined,
      locationTypeId: 2,
      createdBy: this.user.userId,
      updatedBy: this.user.userId,
      adptId: null,
      latitude: null,
      startDate: undefined,
      endDate: undefined,
      longitude: null,
      address: undefined,
      expectedNumberOfStands: null,
      numberOfSubscribedStands: null,
      numberOfUnSubscribedStands: null,
      managementAuthority: undefined,
      scheduleMonOpen: null,
      scheduleMonClose: null,
      scheduleTueOpen: null,
      scheduleTueClose: null,
      scheduleWedOpen: null,
      scheduleWedClose: null,
      scheduleThurOpen: null,
      scheduleThurClose: null,
      scheduleFriOpen: null,
      scheduleFriClose: null,
      scheduleSatOpen: null,
      scheduleSatClose: null,
      scheduleSunOpen: null,
      scheduleSunClose: null,
      existingZonesCheck: false,
      existingZones: [],
      selectedZone: {},
      missions: [],
      selectedMission: {}
    });
    if (this.missions !== undefined) {
      if (this.missions.length === 0) {
        cb();
      } else {
        let noZoneMissionLength = this.missions.length;
        this.missions.forEach(mission => {
          this.mission.markets[0].missions.push(mission);
          noZoneMissionLength--;
          if (noZoneMissionLength === 0) {
            this.mission.markets[0].selectedMission = this.mission.markets[0].missions[0];
            this.marketMissionLoaded = true;
            this.mission.markets[0].missions.splice(0, 1);
            cb();
          }
        });
      }
    } else {
      cb();
    }
  }
  check = false;
  check1 = false;
  check2 = false;
  check3 = false;
  check4 = false;
  check5 = false;
  check6 = false;
  check7 = false;
  
  monChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check = true;
    } else {
      console.log("false moi", this.mission);
      this.check = false;
      this.mission.markets[0].scheduleMonClose = "";
      this.mission.markets[0].scheduleMonOpen = "";
    }

  }
  tueChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check2 = true;
    } else {
      this.check2 = false;
      this.mission.markets[0].scheduleTueClose = ""
      this.mission.markets[0].scheduleTueOpen = ""
    }

  }
  wedChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check3 = true;
    } else {
      this.check3 = false;
      this.mission.markets[0].scheduleWedClose = ""
      this.mission.markets[0].scheduleWedOpen = ""
    }

  }
  thuChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check4 = true;
    } else {
      this.check4 = false;
      this.mission.markets[0].scheduleThurClose = ""
      this.mission.markets[0].scheduleThurOpen = ""
    }

  }
  friChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check5 = true;
    } else {
      this.mission.markets[0].scheduleFriClose = ""
      this.mission.markets[0].scheduleFriOpen = ""
      this.check5 = false;
    }

  }
  satChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check6 = true;
    } else {
      this.mission.markets[0].scheduleSatClose = ""
      this.mission.markets[0].scheduleSatOpen = ""
      this.check6 = false;
    }

  }
  sunChecked(event) {
    console.log("event=", event);
    if (event.target.checked) {
      this.check7 = true;
    } else {
      this.mission.markets[0].scheduleSunClose = ""
      this.mission.markets[0].scheduleSunOpen = ""
      this.check7 = false;
    }
  }
  usedExisting = false;
  toggleCheckBox(i, event) {
    if (event.target.checked) {
      this.usedExisting = true;
    } else {
      this.usedExisting = false;
    }
    this.check = false;
    this.check1 = false;
    this.check2 = false;
    this.check3 = false;
    if (event.target.checked !== this.mission.markets[i].existingZonesCheck) {
      this.mission.markets[i].existingZonesCheck = event.target.checked
    }
    if (this.mission.markets[i].existingZonesCheck) {
      this.existingZonesCheck = true;
      this.existingZoneMapFiller(i);
      this.disableMapClick = true;
    } else {
      this.mapObject = [{ 'latitude': 50.84559909325273, 'longitude': 4.348614006026935, flag: false }];

      this.existingZonesCheck = false;
      // console.log('536',this.mission);
      this.mission.markets[i].shortName = undefined;
      this.mission.markets[i].officialName = undefined;
      this.mission.markets[i].address = undefined;
      this.mission.markets[i].latitude = null;
      this.mission.markets[i].longitude = null;
      this.mission.markets[i].adptId = null;
      this.mission.missionEndDate1=null;
      this.mission.missionStartDate1=null;
      this.mission.markets[i].expectedNumberOfStands = null;
      this.mission.markets[i].numberOfSubscribedStands = null;
      this.mission.markets[i].numberOfUnSubscribedStands = null;
      this.mission.markets[i].managementAuthority = null;
      this.mission.markets[i].scheduleMonOpen = null;
      this.mission.markets[i].scheduleMonClose = null;
      this.mission.markets[i].scheduleTueOpen = null;
      this.mission.markets[i].scheduleTueClose = null;
      this.mission.markets[i].scheduleWedOpen = null;
      this.mission.markets[i].scheduleWedClose = null;
      this.mission.markets[i].scheduleThurOpen = null;
      this.mission.markets[i].scheduleThurClose = null;
      this.mission.markets[i].scheduleFriOpen = null;
      this.mission.markets[i].scheduleFriClose = null;
      this.mission.markets[i].scheduleSatOpen = null;
      this.mission.markets[i].scheduleSatClose = null;
      this.mission.markets[i].scheduleSunOpen = null;
      this.mission.markets[i].scheduleSunClose = null;
      this.mission.markets[i].selectedZone.endDate=null;
      this.mission.markets[i].selectedZone.startDate=null;
      this.mission.markets[i].selectedZone.scheduleWedClose=null;
      this.zoneNameDisabled = true;
      this.disableMapClick = false;
    }
  }

  // existingZoneMapFiller(i) {
  //   if (this.existingZones.length !== 0) {
  //     this.mission.markets[i].existingZones = [];
  //     let existingZoneLength = this.existingZones.length;
  //     console.log('existingZones',this.existingZones);
  //     this.existingZones.forEach(zone => {
  //       this.mission.markets[i].existingZones.push(zone);
  //       existingZoneLength--;
  //       if (existingZoneLength === 0) {
  //         this.mission.markets[i].selectedZone = this.mission.markets[i].existingZones[4];
  //         console.log('this.mission.markets[i].selectedZone',this.mission.markets[i].selectedZone);
  //         this.api.getLocationDetails({'locationName':this.mission.markets[i].selectedZone.name,'locationType':2}).subscribe(res => {
  //           let market=res.data;

  //         console.log('585');
  //         this.mission.markets.push({
  //           id: market.id,
  //           // name: market.shortName,
  //           shortName: market.shortName,
  //           officialName:market.officialName,
  //           locationTypeId: 2,
  //           createdBy: this.user.userId,
  //           updatedBy: this.user.userId,
  //           adptId: market.adptId,
  //           latitude: market.latitude,
  //           startDate : market.startDate,
  //           endDate : market.endDate,
  //           longitude: market.longitude,
  //           address: market.address,
  //           expectedNumberOfStands: market.expectedNumberOfStands,
  //           numberOfSubscribedStands: market.numberOfSubscribedStands,
  //           numberOfUnSubscribedStands: market.numberOfUnSubscribedStands,
  //           managementAuthority: market.managementAuthority
  //       });
  //       this.mission.missionEndDate=UTILS.getDatePickerDateFormat(market.endDate);
  //       this.mission.missionStartDate= UTILS.getDatePickerDateFormat(market.startDate);
  //         this.mission.markets[i].existingZones.splice(0, 1);
  //         this.mapObject = [{ 'longitude':  market.longitude, 'latitude':  market.latitude ,flag:false}];
  //         // this.event.broadcast({ eventName: 'existing-zone-selected', data: this.mission.markets[i].selectedZone.longitude + ',' + this.mission.markets[i].selectedZone.latitude + ',' + 'map0' });
  //       });
  //       }
  //     });
  //   }
  // }



  replace(num) {
    console.log('num', num);
    if (num) {
      var res = num.split(':', 2);
      res = res[0] + ':' + res[1]
      console.log('res', res);
      return res;
    }
    else {
      console.log('res', res);
      return res = null;
    }

  }

  existingZoneMapFiller(i) {
    if (this.existingZones.length !== 0) {
      this.mission.markets[i].existingZones = [];
      let existingZoneLength = this.existingZones.length;
      this.existingZones.forEach(zone => {
        this.mission.markets[i].existingZones.push(zone);
        existingZoneLength--;
        if (existingZoneLength === 0) {
          this.mission.markets[i].selectedZone = this.mission.markets[i].existingZones[0];

          this.api.getLocationDetails({ 'locationName': this.mission.markets[i].selectedZone.name, 'locationType': 2 })
            .subscribe(res => {
              let market = res.data;
              console.log(market);
              this.mission.selectedMarket=[];
              this.mission.selectedMarket.push({
                id: market.id,
                shortName: market.shortName,
                officialName: market.officialName,
                locationTypeId: 2,
                locationId: market.locationId,
                createdBy: this.user.userId,
                updatedBy: this.user.userId,
                adptId: market.adptId,
                latitude: market.latitude,
                startDate: market.startDate,
                endDate: market.endDate,
                longitude: market.longitude,
                address: market.address,
                expectedNumberOfStands: market.expectedNumberOfStands,
                numberOfSubscribedStands: market.numberOfSubscribedStands,
                numberOfUnSubscribedStands: market.numberOfUnSubscribedStands,
                managementAuthority: market.managementAuthority,
                scheduleMonOpen:this.replace(market.scheduleMonOpen),
                scheduleMonClose:this.replace(market.scheduleMonClose),
                scheduleTueOpen: this.replace(market.scheduleTueOpen),
                scheduleTueClose: this.replace(market.scheduleTueClose),
                scheduleWedOpen: this.replace(market.scheduleWedOpen),
                scheduleWedClose: this.replace(market.scheduleWedClose),
                scheduleThurOpen: this.replace(market.scheduleThurOpen),
                scheduleThurClose: this.replace(market.scheduleThurClose),
                scheduleFriOpen: this.replace(market.scheduleFriOpen),
                scheduleFriClose: this.replace(market.scheduleFriClose),
                scheduleSatOpen: this.replace(market.scheduleSatOpen),
                scheduleSatClose: this.replace(market.scheduleSatClose),
                scheduleSunOpen: this.replace(market.scheduleSunOpen),
                scheduleSunClose: this.replace(market.scheduleSunClose)
              });
              this.mission.markets[i].selectedZone = this.mission.selectedMarket[0];
              console.log(this.mission.selectedMarket[0],'selectedZone',this.mission.markets[i].selectedZone);
              // this.mission.missionEndDate = UTILS.getDatePickerDateFormat(this.mission.markets[i].selectedZone.endDate);
              // this.mission.missionStartDate = UTILS.getDatePickerDateFormat(this.mission.markets[i].selectedZone.startDate);
              this.mission.missionEndDate1 = (this.mission.markets[i].selectedZone.endDate);
              this.mission.missionStartDate1 =(this.mission.markets[i].selectedZone.startDate);
              this.mapObject = [{ 'longitude': this.mission.markets[i].selectedZone.longitude, 'latitude': this.mission.markets[i].selectedZone.latitude, flag: false }]
              this.mapobj2 = this.mapObject;

              // this.api.getLocationDetails({'locationName':this.mission.markets[i].selectedZone.name,'locationType':2}).subscribe(res => {
              // let market=res.data;
              // console.log(res.data);
              // this.mission.markets[i].selectedZone =res.data;
              // console.log(this.mission.markets[i].selectedZone);
              // this.mission.missionEndDate=UTILS.getDatePickerDateFormat(this.mission.markets[i].selectedZone.endDate);
              // this.mission.missionStartDate= UTILS.getDatePickerDateFormat(this.mission.markets[i].selectedZone.startDate);

              // this.mapObject= [{'longitude': this.mission.markets[i].selectedZone.longitude, 'latitude': this.mission.markets[i].selectedZone.latitude,flag:false },{'longitude':'','latitude':'',flag:false}]
              // this.mapobj2=this.mapObject


              // });
              // console.log('this.mission.markets[i].selectedZone ',this.mission.markets[i].selectedZone );

              this.mission.markets[i].existingZones.splice(0, 1);
            });
        }
      });
    }
  }

  getMissionTypes() {
    this.missionTypesLoaded = false;
    this.missionTypes = [];

    this.api.getMissionTypes().subscribe(res => {
      let typeLen = res.data.length;
      res.data.forEach(type => {
        if (type.id === 3 || type.id === 4) {
          this.missionTypes.push(type);
        }
        typeLen--;
        if (typeLen === 0) {
          if (this.missionTypes[0].id === 4) {
            this.selectedMissionType = this.missionTypes[0];
            this.missionTypes.splice(0, 1);
          } else {
            this.selectedMissionType = this.missionTypes[1];
            this.missionTypes.splice(1, 1);
          }
          this.missionTypesLoaded = true;
        }
      });
    }, err => {
      console.log('err', err);
    });
  }
  /**
   * Get address by Lat and long for create survey
   * 
   **/
  gotoCancel(event) {

    this.router.navigate([`/supervisor/missions`]);
  }

  mapobj2 = [];
  getLngLat(search, index, page) {
    const api = new google.maps.Geocoder;
    // this.flag1 = false;
    if (!(Array.isArray(search))) {
      search = search + ' Brussels';
      if (!this.step2Completed) {
        api.geocode({ address: search }, (result: any) => {
          if (result.length !== 0) {
            this.mission.markets[0].address = result[0].formatted_address;
            this.mission.markets[0].longitude = result[0].geometry.location.lng();
            this.mission.markets[0].latitude = result[0].geometry.location.lat();
            this.mapObject = [{ 'longitude': result[0].geometry.location.lng(), 'latitude': result[0].geometry.location.lat()}];
            this.mapobj2 = this.mapObject;
            // this.flag1 = true;
          }else {
            this.pedestrainAlertsService.enterValidLocation();    // Issue 920 resolved
          }
        });
        this.marketNameDisabled = false;
      }
    } else {
      if (!this.step2Completed) {
        api.geocode({ latLng: { lat: search[1], lng: search[0] } }, result => {
          if (result) this.mission.markets[0].address = result[0].formatted_address;
        });
        this.mission.markets[0].longitude = search[0];
        this.mission.markets[0].latitude = search[1];
        this.mapObject = [{'longitude': search[0], 'latitude': search[1] }];
        this.marketNameDisabled = false;
        this.flag1 = true;
      }
    }
  }

  surveySelection(surveyId) {
    this.surveyChange.emit(surveyId);
  }

  toggleMissionType(mType) {
    if (mType.id !== 3) {
      this.missionTypes.push(this.selectedMissionType);
      this.selectedMissionType = mType;
      let removeIndex: number;
      this.missionTypes.forEach((tsk, i) => {
        if (tsk === mType) {
          removeIndex = i;
        }
      });
      this.missionTypes.splice(removeIndex, 1);
    } else {
      this.surveySelection(mType.id);
    }
  }

  instanceForCampaign(d1) {
    this.datepickers.push(d1);
  }

  toggleCampaign(camp) {
    this.datepickers.forEach(datePicker => {
      datePicker.close();
    });
    this.mission.missionStartDate = {
      year: null,
      month: null,
      day: null
    };
    this.mission.missionEndDate = {
      year: null,
      month: null,
      day: null
    };
    this.mission.selectedCampaign.campaignName==this.translate.instant('Select compaign')?delete this.mission.selectedCampaign.campaignName:false;
    this.campaigns.push(this.mission.selectedCampaign);
    this.mission.selectedCampaign = camp;
    const campStart = camp.campaignStartDate.split(' ')[0];
    // localStorage.setItem('campaignStartDate', JSON.stringify({
    //   day: parseInt(campStart.split('-')[2], 10),
    //   month: parseInt(campStart.split('-')[1], 10),
    //   year: parseInt(campStart.split('-')[0], 10)
    // }));
    // const campEnd = camp.campaignEndDate.split(' ')[0];
    // localStorage.setItem('campaignEndDate', JSON.stringify({
    //   day: parseInt(campEnd.split('-')[2], 10),
    //   month: parseInt(campEnd.split('-')[1], 10),
    //   year: parseInt(campEnd.split('-')[0], 10)
    // }));
    let removeIndex: number;
    this.campaigns.forEach((campaign, i) => {
      if (campaign === camp) {
        removeIndex = i;
      }
    });
    this.campaigns.splice(removeIndex, 1);
  }

  changeLocalDate(date) {
    this.mission.missionEndDate = {
      year: null,
      month: null,
      day: null
    };
    localStorage.setItem('date', JSON.stringify(date));
    this.minEndDate = date;
  }

  saveAndOpen(step, form) {
    if (step === 1) {
      this.mapObject = [];
      this.getMissionDates();
      // this.validateMission(form, () => {
      this.createMission(form);
      // });
    } else if (step === 2) {
      this.validateMarket(form, () => {
        this.createMarket(form);
      })
    } else if (step === 3) {
      // console.log("step 3");

      this.validateAssignment(() => {
        this.createAssignment();
      })
    } else if (step === 4) {
      this.event.broadcast({ eventName: 'showLoader', data: '' });
      this.location.back();
    }
  }

  validateMission(form, cb) {
    if (form.value.nameOfMission !== '' && form.value.startDateMission.day !== null && form.value.startDateMission.day !== null) {
      cb();
    } else {
      this.custUtils.translateMessageObject({
        title: 'All fields are mandatory',
        text: 'Date and name of the mission are required.',
        type: 'error',
        outsideClick: true,
        showCancelBtn: false,
        confirmBtnText: 'OK',
        cancelBtnText: ''
      }, (responseMessageObject) => {
        this.custUtils.translateAndPop(responseMessageObject).then(() => {

        }).catch(() => {

        });
      });
    }
  }
  goto() {

    this.router.navigate(['/supervisor/missions'])
  }
  createMission(formData) {
    if (this.mission.selectedCampaign.campaignName == this.translate.instant('Select compaign')) {
      this.pedestrainAlertsService.selectCampagin();
    }
    else {
      this.disableStep1 = true;
      this.disableStep1 = true;
      let startdate: any
      let endDateMission
      console.log("this.mission=", this.mission);
      startdate = this.mission.selectedCampaign.campaignStartDate;
      endDateMission = this.mission.selectedCampaign.campaignEndDate;
      console.log("startdate=", startdate);

      startdate = startdate.split(' ');
      startdate = startdate[0].split('-');
      console.log("startdate=", startdate);
      const startdayObj = {
        year: startdate[0],
        month: startdate[1],
        day: startdate[2]
      }
      endDateMission = endDateMission.split(' ');
      endDateMission = endDateMission[0].split('-');
      console.log("startdate=", endDateMission);
      const enddayObj = {
        year: endDateMission[0],
        month: endDateMission[1],
        day: endDateMission[2]
      }


      // if (!this.step1Completed) {
      const now1 = new Date(Date.now());
      const CurrentDate = new Date(now1.getFullYear(), now1.getMonth(), now1.getDate()); 
      console.log("lets check=", new Date(this.mission.selectedCampaign.campaignEndDate) < CurrentDate);
      console.log("check 1=", new Date(this.mission.selectedCampaign.campaignEndDate), CurrentDate);


      if (new Date(this.mission.selectedCampaign.campaignEndDate) < CurrentDate) {
        this.campaignFlag = false
        localStorage.setItem('campaignFlag', 'false');
      } else {
        localStorage.setItem('campaignFlag', 'true');
        this.campaignFlag = true
        localStorage.setItem('campaignStartDate', JSON.stringify(startdayObj));
        localStorage.setItem('campaignEndDate', JSON.stringify(enddayObj));
      }
      if (!this.step1Completed) {
        // const startDate = this.mission.missionStartDate.year + '-' +
        //   formData.value.startDateMission.month + '-' + formData.value.startDateMission.day + ' ' + '00:00:00';
        // const endDate = formData.value.startDateMission.year + '-' +
        //   formData.value.startDateMission.month + '-' +
        //   formData.value.startDateMission.day + ' ' + '00:00:00';
        const now = Date.now();
        const creationDate = new Date(now);
        const nowYear = creationDate.getFullYear();
        const nowMonth = creationDate.getMonth() + 1;
        const nowDay = creationDate.getDate();
        const nowInReq = nowYear + '-' + nowMonth + '-' + nowDay + ' ' + '00:00:00';
        const estimatedTime = (parseInt('10', 10) * 60) + parseInt('10', 10);

        const reqObj = {
          // missionName: formData.value.nameOfMission,
          // missionDescription: formData.value.missionDesc,
          // missionTypeId: this.selectedMissionType['id'],
          // missionCreationDate: nowInReq.toString(),
          // missionStartDate: startDate.toString(),
          // missionEndDate: endDate.toString(),
          // missionCampaignId: this.mission.selectedCampaign['campaignId'],
          // missionCreatedById: this.user.userId,
          // missionEstimatedTime: estimatedTime,
          // missionStatusId: statuses.YETTOASSIGN
          missionName: this.mission.missionName,
          missionDescription: this.mission.missionDescription,
          missionTypeId: 7,
          missionCreationDate: nowInReq.toString(),
          missionCampaignId: this.mission.selectedCampaign['campaignId'],
          missionCreatedById: this.user.userId,
          missionStatusId: 3,
          classic: false,
          market: this.market && this.marketid !== null,
          marketZone: this.market ? this.marketid : null,
          prm: false,
          visits: false
        };

        this._http.SecurePost('/mission/addMission', reqObj).subscribe(res => {
          this.missionId = res.responseMessage.split('! ')[1];
          this.custUtils.translateMessageObject({
            title: 'Mission created successfully',
            text: 'Please create zone for this mission',
            type: 'success',
            cancelBtnText: '',
            confirmBtnText: 'OK',
            outsideClick: false,
            showCancelBtn: false
          }, res => {
            this.custUtils.translateAndPop(res).then(() => {
              var elemant1 = document.getElementById('missionName');
              elemant1.setAttribute("disabled", "true");
              var elemant2 = document.getElementById('missionDescription');
              elemant2.setAttribute("disabled", "true");
              this.pageOpenAllowed = true;
              this.step1Completed = true;
              this.getMissions(() => {
                this.disableStep1 = false;
                this.open(2);
              });
            }).catch(() => {

            });
          });
        }, err => {
          console.log(err._body);
        });
      }
    }
  }

    open(page) {
      console.log("in step 3", this.mission.markets[0]);

      if ((page === 2 && this.prev === 1 && this.pageOpenAllowed) || (page === 2 && this.step2)) {
        this.step2 = true;
        if (this.prev === 1 && !this.step2Completed) {
          if (this.mission.markets.length === 0) {
            this.zoneObjectCreator(() => {
            });
          } else {
            this.zoneObjectUpdater(() => {

            });
          }
        }
        this.prev = 2;
        this.hideStep1 = true;
        this.hideStep3 = true;
        this.hideStep4 = true;
        this.hideStep5 = true;
        this.hideStep2 = false;
        this.pageOpenAllowed = false;
        this.event.broadcast({ eventName: 'circle-map-loaded', data: '' });
      } else if ((page === 3 && this.prev === 2 && this.pageOpenAllowed) || (page === 3 && this.step3)) {
        this.step3 = true;
        console.log("in step 3", this.mission.markets[0]);

        console.log('insdide step 3');
        if (this.prev === 2) {
          if (this.mission.assignments.length === 0) {
            this.assignmentObjectCreator();
          }
        }
        this.prev = 3;
        this.hideStep1 = true;
        this.hideStep3 = false;
        this.hideStep4 = true;
        this.hideStep5 = true;
        this.hideStep2 = true;
        this.pageOpenAllowed = false;
      } else if (page === 1 && this.step1 && this.pageOpenAllowed) {
        this.step1 = true;
        this.prev = 1;
        this.hideStep2 = true;
        this.hideStep3 = true;
        this.hideStep4 = true;
        this.hideStep5 = true;
        this.hideStep1 = false;
        this.pageOpenAllowed = false;
      } else if (page === 4 && this.prev === 3 && this.pageOpenAllowed) {
        // this.mapObject = [{ 'longitude': this.mission.markets[0].longitude, 'latitude': this.mission.markets[0].latit, flag:false}];
        console.log("in page 4 lalang=", this.mapObject);

        console.log("missions=", this.mission);



        this.step4 = true;
        if (this.prev === 3) {
          this.summaryCreator();
        }
        this.prev = 4;
        this.hideStep2 = true;
        this.hideStep3 = true;
        this.hideStep4 = false;
        this.hideStep1 = true;
        this.pageOpenAllowed = false;
      }
    }

    summaryCreator() {
      this.summaryLoaded = false;
      this.summaryObj = {
        mission: this.mission.markets[0].selectedMission,
        zone: this.mission.markets[0],
        assignment: this.mission.assignments[0],
      }
      console.log(this.summaryObj);

      setTimeout(() => {
        this.summaryLoaded = true;
        this.event.broadcast({ eventName: 'circle-map-loaded', data: '' });
      }, 500);
      setTimeout(() => {
        console.log('hi', this.summaryObj.zone.selectedZone.latitude);
        // this.getLngLat();
        // this.mapObject= [{'longitude': this.summaryObj.zone.selectedZone.longitude, 'latitude': this.summaryObj.zone.selectedZone.latitude,flag:false }];     
        this.event.broadcast({ eventName: 'existing-zone-selected', data: this.summaryObj.zone.selectedZone.latitude + ',' + this.summaryObj.zone.selectedZone.longitude + ',' + 'map1' });
      }, 700);
    }

    zoneObjectUpdater(cb) {
      if (this.step1Completed) {
        this._http.SecureGet('/ref/getAllMissions?id=' + this.missionId).subscribe(res => {
          // console.log(this.mission.markets);
          this.mission.markets.forEach(zone => {
            zone.selectedMission = res.data.missions[0];
            this.zoneMissionFound = true;
          });
        });
        // this.mapObject.push({ 'latitude': 50.84559909325273, 'longitude': 4.348614006026935, flag: true },{ 'longitude': this.mission.markets[0].longitude, 'latitude': this.mission.markets[0].latitude, flag: true });

      }
    }

    skip(currStep) {
      if (currStep === 1) {
        this.step2 = true;
        this.hideStep1 = true;
        this.hideStep3 = true;
        this.hideStep4 = true;
        this.hideStep5 = true;
        this.hideStep2 = false;
        if (this.prev === 1) {
          if (this.mission.markets.length === 0) {
            this.event.broadcast({ eventName: 'showLoader', data: '' });
            this.zoneObjectCreator(() => {
              this.event.broadcast({ eventName: 'circle-map-loaded', data: '' });
            });
            this.prev = 2;
          } else {
            this.prev = 2;
            this.event.broadcast({ eventName: 'circle-map-loaded', data: '' });
          }
        }
        this.rd.setStyle(this.stepOne.nativeElement, 'cursor', 'pointer', 1);
        this.step1 = false;
      }
    }

    getExistingZonesDropdownStyle(val) {
      if (val) {
        console.log('970');
        return { 'margin-top': '40px', 'margin-bottom': '190px' };
      } else {
        // console.log('973');
        return { 'margin-top': '30px', 'margin-bottom': '10px' };
      }
    }

    existingDropdownToggled(value, i) {
      if (!value) {
        this.mission.markets[i].existingZones = Object.assign([], this.existingZones).filter(item => {
          console.log('this.existingZones', this.existingZones);
          if (this.mission.markets[i].selectedZone.shortName !== item.shortName) {
            return item;
          }
        });
      }
    }

    // validateZone(cb) {
    //   const zone = this.mission.markets[0];
    //   if (zone.existingZonesCheck) {
    //     cb();
    //   } else {
    //     console.log('Zone', zone);
    //     if (zone.name !== undefined && zone.name !== '' && zone.address !== undefined && zone.address !== '' && zone.adptId !== null && zone.adptId !== '' && zone.lat !== null && zone.lng !== null) {
    //       cb();
    //     } else {
    //       this.custUtils.translateMessageObject({
    //         title: 'All fields are mandatory',
    //         text: 'Please click on an area on Map for the latitude and longitude.',
    //         type: 'warning',
    //         cancelBtnText: '',
    //         confirmBtnText: 'OK',
    //         outsideClick: false,
    //         showCancelBtn: false
    //       }, message => {
    //         this.custUtils.translateAndPop(message).then(() => {
    //           console.log('hha');
    //         }).catch(() => {
    //           console.log('hha');
    //         });
    //       });
    //     }
    //   }
    // }

    createZone() {
      this.disableStep2 = true;
      const zone = this.mission.markets[0];
      if (zone.existingZonesCheck) {
        const reqObj = {
          missionId: zone.selectedMission.missionId,
          zoneUpdatedBy: this.user.userId,
          zoneId: zone.selectedZone.id,
          locationTypeId: 3
        };
        this.mapMissionWithExistingZone(reqObj);
      } else {
        const reqObj = {
          missionId: zone.selectedMission.missionId,
          zoneCreatedBy: this.user.userId,
          zoneUpdatedBy: this.user.userId,
          zoneAdptId: zone.adptId,
          zoneName: zone.name,
          zoneLatitude: zone.lat,
          zoneLongitutde: zone.lng,
          zoneAddress: zone.address,
          locationId: null,
          locationTypeId: 3
        };
        this.createAndMapZoneWithMission(reqObj);
      }
    }

    createAndMapZoneWithMission(req) {
      let zoneName = req.zoneName;
      this.api.createZone(req).subscribe(res => {
        this.marketZoneId = res.responseMessage.split('! ')[2];
        this.custUtils.translateMessageObject({
          title: 'Zone created successfully',
          text: 'Mission mapped with this zone',
          type: 'success',
          outsideClick: true,
          cancelBtnText: '',
          confirmBtnText: 'Ok',
          showCancelBtn: false
        }, message => {

          this.custUtils.translateAndPop(message).then(() => {
            this.pageOpenAllowed = true;
            this.step2Completed = true;
            this.disableStep3 = false;
            this.disableMapClick = true;
            this.open(3);
          }).catch(() => {
            this.pageOpenAllowed = true;
            this.step2Completed = true;
            this.disableStep3 = false;
            this.disableMapClick = true;
            this.open(3);
          });
        });
      }, err => {
        let response = JSON.parse(err._body);
        if (response.responseMessage === undefined) {
          this.custUtils.translateMessageObject({
            title: 'Something went wrong',
            text: 'Zone not created please try again',
            type: 'error',
            outsideClick: true,
            cancelBtnText: '',
            confirmBtnText: 'Ok',
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.disableStep2 = false;
            }).catch(() => {
              this.disableStep2 = false;
            });
          });
        } else {
          if (response.responseMessage.includes('Zone with')) {
            let backEndString = response.responseMessage.split('Zone with ')[1];
            // let zoneName = backEndString.split(' already exists')[0];
            this.custUtils.translateMessageObject({
              title: 'Zone with the same name already present',
              text: 'Do you want to use the exisiting zone?',
              type: 'error',
              outsideClick: false,
              cancelBtnText: 'No, cancel',
              confirmBtnText: 'Yes, use exising zone',
              showCancelBtn: true
            }, message => {
              this.custUtils.translateAndPop(message).then(() => {
                this.existingZones.forEach(extZone => {
                  if (extZone.name.toLowerCase() === zoneName.toLowerCase()) {
                    // this.mapObject = [{ 'longitude': extZone.longitude, 'latitude': extZone.latitude ,flag:false}];
                    this.mission.markets[0].selectedZone = extZone;
                    this.mission.markets[0].existingZonesCheck = true;
                    this.event.broadcast({ eventName: 'existing-zone-selected', data: extZone.longitude + ',' + extZone.latitude + ',' + 'map0' });
                    this.disableMapClick = true;
                  }
                });
                this.disableStep2 = false;
              }).catch(() => {
                this.disableStep2 = false;
              });
            });
          } else {
            this.custUtils.translateMessageObject({
              title: 'Something went wrong',
              text: 'Zone not created please try again',
              type: 'error',
              outsideClick: true,
              cancelBtnText: '',
              confirmBtnText: 'Ok',
              showCancelBtn: false
            }, message => {
              this.custUtils.translateAndPop(message).then(() => {
                this.disableStep2 = false;
              }).catch(() => {
                this.disableStep2 = false;
              });
            });
          }
        }
      });
    }

    toggleExistingZone(market, i, e) {
      console.log('market', market, 'mission', this.mission.markets);
      this.api.getLocationDetails({ 'locationName': market.name, 'locationType': 2 }).subscribe(res => {
        let market = res.data;
        console.log(market);

        this.mission.selectedMarket.push({
          id: market.id,
          shortName: market.shortName,
          officialName: market.officialName,
          locationTypeId: 2,
          // locationId:id,
          createdBy: this.user.userId,
          updatedBy: this.user.userId,
          adptId: market.adptId,
          latitude: market.latitude,
          startDate: market.startDate,
          endDate: market.endDate,
          longitude: market.longitude,
          address: market.address,
          expectedNumberOfStands: market.expectedNumberOfStands,
          numberOfSubscribedStands: market.numberOfSubscribedStands,
          numberOfUnSubscribedStands: market.numberOfUnSubscribedStands,
          managementAuthority: market.managementAuthority,
          scheduleMonOpen: this.replace(market.scheduleMonOpen),
          scheduleMonClose: this.replace(market.scheduleMonClose),
          scheduleTueOpen: this.replace(market.scheduleTueOpen),
          scheduleTueClose: this.replace(market.scheduleTueClose),
          scheduleWedOpen: this.replace(market.scheduleWedOpen),
          scheduleWedClose: this.replace(market.scheduleWedClose),
          scheduleThurOpen: this.replace(market.scheduleThurOpen),
          scheduleThurClose: this.replace(market.scheduleThurClose),
          scheduleFriOpen: this.replace(market.scheduleFriOpen),
          scheduleFriClose: this.replace(market.scheduleFriClose),
          scheduleSatOpen: this.replace(market.scheduleSatOpen),
          scheduleSatClose: this.replace(market.scheduleSatClose),
          scheduleSunOpen: this.replace(market.scheduleSunOpen),
          scheduleSunClose: this.replace(market.scheduleSunClose)
        });
        this.mission.markets[i].selectedZone = this.mission.selectedMarket[this.mission.selectedMarket.length - 1];
        console.log(this.mission);

        this.mission.missionEndDate = UTILS.getDatePickerDateFormat(this.mission.markets[i].selectedZone.endDate);
        this.mission.missionStartDate = UTILS.getDatePickerDateFormat(this.mission.markets[i].selectedZone.startDate);
        this.mapObject = [{ 'longitude': res.data.longitude, 'latitude': res.data.latitude, flag: false }];
        this.mission.markets[i].existingZones.push(this.mission.markets[i].selectedZone);
        //this.mission.markets[i].existingZones.splice(e, 1);
        // this.mission.markets[i].selectedZone = market;
        this.event.broadcast({ eventName: 'existing-zone-selected', data: this.mission.markets[i].selectedZone.longitude + ',' + this.mission.markets[i].selectedZone.latitude + ',' + 'map0' });
      });
    }

    searchExistingZoneName(value, i) {
      if (!value) {
        console.log('this.existingZones', this.existingZones, 'selectedone', this.mission.markets[i].selectedZon);
        this.mission.markets[i].existingZones = Object.assign([], this.existingZones).filter(item => {
          if (this.mission.markets[i].selectedZone.name !== item.name) {
            return item;
          }
        });
      } else {
        this.mission.markets[i].existingZones = Object.assign([], this.existingZones).filter(
          item => {
            if (this.mission.markets[i].selectedZone.shortName !== item.name) {
              return item.name.toLowerCase().indexOf(value.toLowerCase()) > -1;
            }
          }
        );
      }
    }
    userId = true;
    saveWithoutAssign() {
      this.userId = false;
      this.agentSelected = false;
      this.createAssignment();
    }
    changeShiftId(id) {
      if (id === 1) {
        this.morning = true;
        this.getMissionDates()
        if (this.startDate !== undefined) {
          this.dateSelected = true
          this.startDate = `${this.missionDate} 08:45:00`
          this.endDates = `${this.missionDate} 13:00:00`
          this.assignmentObjectCreator()

        }
      } else {
        this.morning = false;
        this.getMissionDates()
        if (this.startDate !== undefined) {
          this.dateSelected = true
          this.startDate = `${this.missionDate} 13:00:00`
          this.endDates = `${this.missionDate} 17:15:00`
          this.assignmentObjectCreator()
        }
      }
    }
    startDate;
    selectedDate;
    dateSelected = false;
    selectedDateStep3;
    endDates;
    missionDate;
    getDate(d1) {
      var g1 = new Date();
      console.log("d1.day=", d1.day, g1.getDay(), this.minDate, this.minDate.day === d1.day);

      const d2 = new Date(d1.year, d1.month - 1, d1.day);
      var CurrentDate = new Date()
      var d = new Date();
      // var d = new Date(CurrentDate),
      let dateToday = {
        month: '' + (d.getMonth() + 1),
        day: '' + d.getDate(),
        year: d.getFullYear()
      }

      var endDateCheck = JSON.parse(localStorage.getItem('campaignEndDate'));

      var endDateCheck1 = new Date(`${endDateCheck.year}-${endDateCheck.month}-${endDateCheck.day}`)
      var startDateCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
      var startDateCheck1 = new Date(`${startDateCheck.year}-${startDateCheck.month}-${startDateCheck.day}`)

      if (dateToday.month.length < 2)
        dateToday.month = '0' + dateToday.month;
      if (dateToday.day.length < 2)
        dateToday.day = '0' + dateToday.day;
      var today = `${dateToday.year}-${dateToday.month}-${dateToday.day}`

      var GivenDate = new Date(`${d1.year}-${d1.month}-${d1.day}`);
      const month1 = String(d1.month).padStart(2, "0");
      const day1 = String(d1.day).padStart(2, "0");
      var todayDate = `${d1.year}-${month1}-${day1}`
      // console.log("give date=", GivenDate);

      // console.log("GivenDate < endDateCheck==", (GivenDate > endDateCheck));
      let market = JSON.parse(localStorage.getItem('marketOpen'));
      // console.log("enable market=", market);
      market = JSON.parse(localStorage.getItem("marketOpen"))
      // console.log("market=", market, market.includes(GivenDate.getDay()));
      const month = String(d1.month).padStart(2, "0");
      const day = String(d1.day).padStart(2, "0");
      this.missionDate = `${d1.year}-${month}-${day}`
      this.selectedDateStep3 = `${d1.year}-${month}-${day} 00:00:00`
      if (this.morning) {

        this.startDate = `${d1.year}-${month}-${day} 08:45:00`
        this.endDates = `${d1.year}-${month}-${day} 13:00:00`


      } else {
        this.startDate = `${d1.year}-${month}-${day} 13:00:00`
        this.endDates = `${d1.year}-${month}-${day} 17:15:00`
      }
      if (this.campaignFlag) {
        if (!market.includes(GivenDate.getDay())) {
          if ((!(GivenDate > endDateCheck1) && !(GivenDate < startDateCheck1)) || (GivenDate == startDateCheck1)) {
            if (GivenDate >= CurrentDate || (today === todayDate)) {
              // } else if(this.minDate.day===d1.day) {
              console.log("in else if");

              this.dateSelected = true;
              this.mission.missionStartDate = {
                year: d1.year,
                month: d1.month,
                day: d1.day
              }
              // const month = String(d1.month).padStart(2, "0");
              // const day = String(d1.day).padStart(2, "0");
              // this.startDate = `${d1.year}-${month}-${day} 00:00:00`
              this.selectedDate = {
                year: d1.year,
                month: d1.month,
                day: d1.day
              }
              this.assignmentObjectCreator();
            }
          }
        }
      } else {
        if (GivenDate >= CurrentDate || (today === todayDate)) {
          // } else if(this.minDate.day===d1.day) {
          console.log("in else if");

          this.dateSelected = true;
          this.mission.missionStartDate = {
            year: d1.year,
            month: d1.month,
            day: d1.day
          }
          // const month = String(d1.month).padStart(2, "0");
          // const day = String(d1.day).padStart(2, "0");
          // this.startDate = `${d1.year}-${month}-${day} 00:00:00`
          this.selectedDate = {
            year: d1.year,
            month: d1.month,
            day: d1.day
          }
          this.assignmentObjectCreator();
        }
      }



      // (YYYY-MM-DD) 
      //   var g2 = new Date(`${d1.year}-${d1.month}-${d1.day}`); 
      //   if (g1.getTime() > g2.getTime()) {

      //   } else{
      //   this.dateSelected=true;
      //   this.mission.missionStartDate={
      //      year:d1.year,
      //      month:d1.month,
      //      day:d1.day
      //   }
      //   const month=String(d1.month).padStart(2, "0");
      //   this.selectedDate={
      //     year:d1.year,
      //     month:d1.month,
      //     day:d1.day
      //   }
      //   console.log("date selected...!!!");
      //   this.startDate=`${d1.year}-${month}-${d1.day} 00:00:00`;

      //   this.assignmentObjectCreator();
      // }
    }

    assignmentObjectCreator() {
      console.log('inside assign');
      this.mission.assignments = [];
      // console.log("this.marketid=",this.marketid,"zone id=",this.zoneId);
      const market = this.mission.markets[0];

      this.api.getMarketZone(market.selectedZone.id).subscribe(res => {

        console.log('getMarketZone', res.data);
        const obj = {
          selectedZone: res.data,
          selectedFieldAgent: {
          },
          fieldAgents: [],
          tempFieldAgents: [],
          shiftTimings: [
            {
              first: '08:45',
              second: '13:00'
            },
            {
              first: '13:00',
              second: '17:15'
            }
          ]
        };
        this.assignmentFieldAgentsFiller(obj, (freeUsers) => {
          obj.fieldAgents = freeUsers;
          obj.tempFieldAgents = freeUsers;
          obj.selectedFieldAgent = obj.fieldAgents[0];
          //  console.log("selectedfield agent=",obj.selectedFieldAgent);
          if (!this.dateSelected) {
            obj.fieldAgents.splice(0, 1);
            obj.selectedFieldAgent['firstName'] = ' ';
            obj.selectedFieldAgent['lastName'] = '';

          }
          this.mission.assignments.push(obj);
          this.assignmnts = this.mission.assignments

          this.assignmentsLoaded = true;
        });
      }, err => {

      });

    }

    assignmentFieldAgentsFiller(assignment, cb) {
      // console.log('this.mission.markets[0].selectedMission.missionStartDate', this.mission.markets[0].selectedMission.missionStartDate);
      this.api.getUnassignedUsers({
        // startDate: this.mission.markets[0].selectedMission.missionStartDate.split(' ')[0],
        startDate: this.dateSelected ? this.selectedDateStep3 : this.currentDate,
        missionId: this.mission.markets[0].selectedMission.missionId,
        shift: this.morning ? 1 : 2
      }).subscribe(res => {
        cb(res.users);

      }, err => {
        this.custUtils.translateMessageObject({
          title: this.translate.instant('No Field agents available'),
          text: this.translate.instant('Please change the mission date or  ask admin to add more field agents.'),
          type: 'warning',
          cancelBtnText: '',
          confirmBtnText: 'OK',
          outsideClick: false,
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
            this.mission.assignments = this.assignmnts
            this.dateSelected = false;
            assignment.fieldAgents = [];
            this.agentSelected = false
            // this.location.back();
          }).catch(() => {
            this.mission.assignments = this.assignmnts
            this.dateSelected = false;
            assignment.fieldAgents = [];
            this.agentSelected = false
            // this.location.back();
          });
        });
      });
    }

    checkAndOpen(page) { // on click of wizard this fuction decides if allow access can go to utils
      if ((page === 1 && this.step1) || (page === 2 && this.step2) ||
        (page === 3 && this.step3) || (page === 4 && this.step4)) {
        this.pageOpenAllowed = true;
      }
      if (page === 1 && this.step2) {
        if (!this.step2Completed && !this.step1Completed) {
          // this.pageOpenAllowed = true;
          // this.step1 = true;
        } else if (this.step2Completed && this.step1Completed) {
          this.pageOpenAllowed = true;
          this.step1 = true;
        } else if (this.step1Completed && !this.step2Completed) {
          this.pageOpenAllowed = true;
          this.step1 = true;
        } else {
          this.pageOpenAllowed = false;
          this.step1 = false;
        }
      } else if (page === 2 && this.step3) {

      } else if (page === 3) {
        if (this.step3Completed) {

        }
      }
      this.open(page);
    }

    toggleMission(mission, i) {
      // console.log(mission, i);
      let deleteIndex;
      this.mission.markets[i].missions.push(this.mission.markets[i].selectedMission);
      let zoneMissionLength = this.mission.markets[i].missions.length;
      this.mission.markets[i].missions.forEach((miss, del) => {
        if (miss.missionId === mission.missionId) {
          deleteIndex = del;
        }
        zoneMissionLength--;
        if (zoneMissionLength === 0) {
          this.mission.markets[i].missions.splice(deleteIndex, 1);
          this.mission.markets[i].selectedMission = mission;
        }
      });
    }
    selectedFieldAgent = false;
    agentSelected = false;
    toggleFieldAgent(fa, i) {
      let deleteIndex;
      this.agentSelected = true;
      this.selectedFieldAgent = true;

      this.mission.assignments[0].fieldAgents.push(this.mission.assignments[0].selectedFieldAgent);
      // console.log("fieldAgents=",this.fieldAgents);

      this.mission.assignments[0].selectedFieldAgent = fa;
      let faLength = this.mission.assignments[0].fieldAgents.length;
      this.mission.assignments[0].fieldAgents.forEach((fieldAgent, delI) => {
        if (fa.userId === fieldAgent.userId) {
          deleteIndex = delI;
        }
        faLength--;
        if (faLength === 0) {
          this.mission.assignments[0].fieldAgents.splice(deleteIndex, 1);
        }
      });
    }

    validateAssignment(cb) {
      if (this.assignmentsLoaded) {
        cb();
      }
    }

    createAssignment() {
      this.disableStep3 = true;
      const requestAssignmentObject = {
        missionId: this.missionId ? this.missionId : this.mission.markets[0].selectedMission.missionId,
        missionTypeId: 7,
        missionEstimatedTime: 610,
        missionStartDate: this.selectedDateStep3,
        missionEndDate: this.selectedDateStep3,
        assignMission: this.userId,

        assignments: [{
          userId: this.userId ? this.mission.assignments[0].selectedFieldAgent.userId : null,
          campaignId: this.mission.markets[0].selectedMission.missionCampaign.campaignId,
          missionId: this.missionId ? this.missionId : this.mission.markets[0].selectedMission.missionId,
          marketZone: this.mission.markets[0].selectedZone.id,
          createdBy: this.user.userId,
          updatedBy: this.user.userId,
          shiftId: this.morning ? 1 : 2,
          startDate: this.startDate,
          endDate: this.endDates,
        }]
      };
      requestAssignmentObject.missionId = parseInt(requestAssignmentObject.missionId, 10);

      const sendAssignment = (i) => {
        // const reqObj = {
        //   userId: this.mission.assignments[0].selectedFieldAgent.userId,
        //   campaignId: this.mission.markets[0].selectedMission.missionCampaign.campaignId,
        //   missionId: this.missionId ? this.missionId : this.mission.markets[0].selectedMission.missionId,
        //   zone: this.mission.assignments[0].selectedZone.id,
        //   createdBy: this.user.userId,
        //   updatedBy: this.user.userId,
        //   shiftId: i + 1,
        //   startDate: this.startDate + ' ' + this.mission.assignments[0].shiftTimings[i].first + ':00',
        //   endDate: this.startDate + ' ' + this.mission.assignments[0].shiftTimings[i].second + ':00',
        // };
        // requestAssignmentObject.assignments.push(reqObj);
        if (i >= 1) {
          this.api.assignCustomerSurvey(requestAssignmentObject).subscribe(res => {
            this.custUtils.translateMessageObject({
              title: 'Assignments created successfully',
              text: '',
              type: 'success',
              cancelBtnText: '',
              confirmBtnText: 'OK',
              outsideClick: false,
              showCancelBtn: false
            }, message => {
              this.custUtils.translateAndPop(message).then(() => {
                this.pageOpenAllowed = true;
                this.step3Completed = true;
                this.disableStep4 = false;
                console.log("this.mapobject before openning step 4", this.mapObject);

                this.open(4);
              }).catch(() => {
                this.pageOpenAllowed = true;
                this.step3Completed = true;
                this.disableStep4 = false;
                this.open(4);
              });
            });
          }, err => {
            this.custUtils.translateMessageObject({
              title: 'Assignments were not successful',
              text: 'Please try again',
              type: 'error',
              cancelBtnText: '',
              confirmBtnText: 'OK',
              outsideClick: false,
              showCancelBtn: false
            }, message => {
              this.custUtils.translateAndPop(message).then(() => {
                this.disableStep3 = false;
              }).catch(() => {
                this.disableStep3 = false;
              });
            });
          });
        } else {
          i++;
          sendAssignment(i);
        }
      };
      sendAssignment(0);
    }


    classic = true;
    market = false;
    marketid = null;
    onChecked(name, id) {
      if (name === 'market') {
        this.market = true;
      }
      if (name === 'classic') {
        this.marketid = null;
        this.selectedMarketZoneValue = "Select market zone"
        this.market = false;
        this.classic = true;
      }
    }
    createMarket(formData) {
      // console.log("create market ");
      const market1 = this.mission.markets[0];
      this.disableStep2 = true;
      // const startDate = this.mission.missionStartDate.year + '-' +
      //   formData.value.startDateMission.month + '-' + formData.value.startDateMission.day;// + ' ' + '00:00:00';
      // const endDate = formData.value.endDateMission.year + '-' +
      //   formData.value.endDateMission.month + '-' +
      //   formData.value.endDateMission.day;// + ' ' + '00:00:00';
      //   this.endDate=endDate;
      // const now = Date.now();
      // const creationDate = new Date(now);
      // const nowYear = creationDate.getFullYear();
      // const nowMonth = creationDate.getMonth() + 1;
      // const nowDay = creationDate.getDate();
      // const nowInReq = nowYear + '-' + nowMonth + '-' + nowDay + ' ' + '00:00:00';
      // const estimatedTime = (parseInt('10', 10) * 60) + parseInt('10', 10);

      const market = this.mission.markets[0];
      if (this.existingZonesCheck) {
        const reqObj = {
          missionId: market1.selectedMission.missionId,
          shortName: market.selectedZone.shortName,
          officialName: market.selectedZone.officialName,
          locationTypeId: 2,
          marketZoneId: market.selectedZone.id,
          locationId: market.selectedZone.locationId,
          startDate: market.selectedZone.startDate,
          endDate: market.selectedZone.endDate,
          createdBy: this.user.userId,
          updatedBy: this.user.userId,
          adptId: market.selectedZone.adptId,
          latitude: market.selectedZone.latitude,
          longitude: market.selectedZone.longitude,
          address: market.selectedZone.address,
          expectedNumberOfStands: market.selectedZone.expectedNumberOfStands,
          numberOfSubscribedStands: market.selectedZone.numberOfSubscribedStands,
          numberOfUnSubscribedStands: market.selectedZone.numberOfUnSubscribedStands,
          managementAuthority: market.selectedZone.managementAuthority,
          scheduleMonOpen: (market.selectedZone.scheduleMonOpen) ? `${(market.selectedZone.scheduleMonOpen)}:00` : null,
          scheduleMonClose: (market.selectedZone.scheduleMonClose) ? `${(market.selectedZone.scheduleMonClose)}:00` : null,
          scheduleTueOpen: (market.selectedZone.scheduleTueOpen) ? `${(market.selectedZone.scheduleTueOpen)}:00` : null,
          scheduleTueClose: (market.selectedZone.scheduleTueClose) ? `${(market.selectedZone.scheduleTueClose)}:00` : null,
          scheduleWedOpen: (market.selectedZone.scheduleWedOpen) ? `${market.selectedZone.scheduleWedOpen}:00` : null,
          scheduleWedClose: (market.selectedZone.scheduleWedClose) ? `${market.selectedZone.scheduleWedClose}:00` : null,
          scheduleThurOpen: (market.selectedZone.scheduleThurOpen) ? `${market.selectedZone.scheduleThurOpen}:00` : null,
          scheduleThurClose: (market.selectedZone.scheduleThurClose) ? `${market.selectedZone.scheduleThurClose}:00` : null,
          scheduleFriOpen: (market.selectedZone.scheduleFriOpen) ? `${market.selectedZone.scheduleFriOpen}:00` : null,
          scheduleFriClose: (market.selectedZone.scheduleFriClose) ? `${market.selectedZone.scheduleFriClose}:00` : null,
          scheduleSatOpen: (market.selectedZone.scheduleSatOpen) ? `${market.selectedZone.scheduleSatOpen}:00` : null,
          scheduleSatClose: (market.selectedZone.scheduleSatClose) ? `${market.selectedZone.scheduleSatClose}:00` : null,
          scheduleSunOpen: (market.selectedZone.scheduleSunOpen) ? `${market.selectedZone.scheduleSunOpen}:00` : null,
          scheduleSunClose: (market.selectedZone.scheduleSunClose) ? `${market.selectedZone.scheduleSunClose}:00` : null
        };
        this.mapMissionWithExistingZone(reqObj);
      } else {
        console.log(this.mission, market);
        const reqObj = {
          missionId: market1.selectedMission.missionId,
          shortName: market.shortName,
          officialName: market.officialName,
          locationTypeId: 2,
          locationId: null,
          // startDate: startDate,
          // endDate: endDate,
          startDate: this.mission.missionStartDate1,
          endDate: this.mission.missionEndDate1,
          createdBy: this.user.userId,
          updatedBy: this.user.userId,
          adptId: market.adptId,
          latitude: market.latitude,
          longitude: market.longitude,
          address: market.address,
          expectedNumberOfStands: market.expectedNumberOfStands,
          numberOfSubscribedStands: market.numberOfSubscribedStands,
          numberOfUnSubscribedStands: market.numberOfUnSubscribedStands,
          managementAuthority: market.managementAuthority,
          scheduleMonOpen: (market.scheduleMonOpen) ? market.scheduleMonOpen + ':00' : null,
          scheduleMonClose: (market.scheduleMonClose) ? market.scheduleMonClose + ':00' : null,
          scheduleTueOpen: (market.scheduleTueOpen) ? market.scheduleTueOpen + ':00' : null,
          scheduleTueClose: (market.scheduleTueClose) ? market.scheduleTueClose + ':00' : null,
          scheduleWedOpen: (market.scheduleWedOpen) ? market.scheduleWedOpen + ':00' : null,
          scheduleWedClose: (market.scheduleWedClose) ? market.scheduleWedClose + ':00' : null,
          scheduleThurOpen: (market.scheduleThurOpen) ? market.scheduleThurOpen + ':00' : null,
          scheduleThurClose: (market.scheduleThurClose) ? market.scheduleThurClose + ':00' : null,
          scheduleFriOpen: (market.scheduleFriOpen) ? market.scheduleFriOpen + ':00' : null,
          scheduleFriClose: (market.scheduleFriClose) ? market.scheduleFriClose + ':00' : null,
          scheduleSatOpen: (market.scheduleSatOpen) ? market.scheduleSatOpen + ':00' : null,
          scheduleSatClose: (market.scheduleSatClose) ? market.scheduleSatClose + ':00' : null,
          scheduleSunOpen: (market.scheduleSunOpen) ? market.scheduleSunOpen + ':00' : null,
          scheduleSunClose: (market.scheduleSunClose) ? market.scheduleSunClose + ':00' : null,
          creationDate: null,
          lastUpdatedOn: null,
        };
        this.createAndMapMarketWithMission(reqObj);
      }
    }

    mapMissionWithExistingZone(req) {
      this.api.missionMarketMapping(req).subscribe(res => {
        this.marketZoneId = req.marketZoneId;
        this.custUtils.translateMessageObject({
          title: 'Zone mapped successfully',
          text: 'Mission mapped with this market zone',
          type: 'success',
          outsideClick: true,
          cancelBtnText: '',
          confirmBtnText: 'Ok',
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
            this.pageOpenAllowed = true;
            this.step2Completed = true;
            this.disableStep3 = false;
            this.disableMapClick = true;
            this.open(3);
          }).catch(() => {
            this.pageOpenAllowed = true;
            this.step2Completed = true;
            this.disableStep3 = false;
            this.disableMapClick = true;
            this.open(3);
          });
        });
      }, err => {
        this.custUtils.translateMessageObject({
          title: 'Zone not mapped',
          text: 'Please try again',
          type: 'error',
          outsideClick: true,
          cancelBtnText: '',
          confirmBtnText: 'Ok',
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
            this.disableStep2 = false;
          }).catch(() => {
            this.disableStep2 = false;
          });
        });
      });
    }

    validateMarket(form, cb) {
      this.marketOpen = []
      var market
      if (this.usedExisting) {
        market = this.mission.markets[0].selectedZone;

      } else {
        market = this.mission.markets[0];
      }
      console.log('market', market);

      if (market.scheduleMonOpen === null) {
        this.marketOpen.push(1)
      }
      if (market.scheduleTueOpen === null) {
        this.marketOpen.push(2)
      }
      if (market.scheduleWedOpen === null) {
        this.marketOpen.push(3)
      }
      if (market.scheduleThurOpen === null) {
        this.marketOpen.push(4)
      }
      if (market.scheduleFriOpen === null) {
        this.marketOpen.push(5)
      }
      if (market.scheduleSatOpen === null) {
        this.marketOpen.push(6)
      }
      if (market.scheduleSunOpen === null) {
        this.marketOpen.push(0)
      }
      console.log("market open=", this.marketOpen);

      // localStorage.setItem('marketOpen', this.marketOpen.toString());
      localStorage.setItem("marketOpen", JSON.stringify(this.marketOpen));
      console.log('market.existingMarketCheck');
      if (this.existingZonesCheck) {
        cb();
      } else {
        console.log(this.mission);
        if (this.mission.missionStartDate1 && this.mission.missionEndDate1) {
          let startParts = this.mission.missionStartDate1.split('/');
          let endParts = this.mission.missionEndDate1.split('/');
          if (startParts[1] > endParts[1]) {
            this.custUtils.translateMessageObject({
              title: 'Enddate should be greater than Startdate',
              text: '',
              type: 'warning',
              cancelBtnText: '',
              confirmBtnText: 'OK',
              outsideClick: false,
              showCancelBtn: false
            }, message => {
              this.custUtils.translateAndPop(message).then(() => {
                console.log('hha');
              }).catch(() => {
                console.log('hha');
              });
            });
          }
          else if (startParts[1] == endParts[1]) {
            if (startParts[0] > endParts[0]) {
              this.custUtils.translateMessageObject({
                title: 'Enddate should be greater than Startdate',
                text: '',
                type: 'warning',
                cancelBtnText: '',
                confirmBtnText: 'OK',
                outsideClick: false,
                showCancelBtn: false
              }, message => {
                this.custUtils.translateAndPop(message).then(() => {
                  console.log('hha');
                }).catch(() => {
                  console.log('hha');
                });
              });
            }
            else {
              cb();
            }
          }
          else {
            cb();
          }
        }
        else {
          this.custUtils.translateMessageObject({
            title: 'All fields are mandatory',
            text: '',
            type: 'warning',
            cancelBtnText: '',
            confirmBtnText: 'OK',
            outsideClick: false,
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              console.log('hha');
            }).catch(() => {
              console.log('hha');
            });
          });
        }
      }
    }
    existingMarkets = [];
    marketZoneId;
    createAndMapMarketWithMission(req) {
      console.log('req', req);
      let marketName = req.name;
      this.api.addMarket(req).subscribe(res => {
        this.marketZoneId = res.responseMessage.split('! ')[2];
        this.custUtils.translateMessageObject({
          title: 'Market zone created successfully',
          text: '',
          type: 'success',
          outsideClick: true,
          cancelBtnText: '',
          confirmBtnText: 'Ok',
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
            this.pageOpenAllowed = true;
            this.step2Completed = true;
            this.disableStep3 = false;
            this.disableMapClick = true;
            this.open(3);
          }).catch(() => {
            this.pageOpenAllowed = true;
            this.step2Completed = true;
            this.disableStep3 = false;
            this.disableMapClick = true;
            this.open(3);
          });
        });
      }, err => {
        let response = JSON.parse(err._body);
        if (response.responseMessage === "undefined") {
          this.custUtils.translateMessageObject({
            title: 'Something went wrong!',
            text: 'Market zone not created please try again',
            type: 'error',
            outsideClick: true,
            cancelBtnText: '',
            confirmBtnText: 'Ok',
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.disableStep2 = false;
            }).catch(() => {
              this.disableStep2 = false;
            });
          });
        } else {
          if (response.responseMessage.includes('Market Zone already exists!')) {
            let backEndString = response.responseMessage.split('Zone with ')[1];
            // let zoneName = backEndString.split(' already exists')[0];
            this.custUtils.translateMessageObject({
              title: 'Market with the same name already present',
              text: 'Please create market zone with unique name',
              type: 'error',
              outsideClick: false,
              cancelBtnText: '',
              confirmBtnText: 'Ok',
              showCancelBtn: false
            }, message => {
              this.custUtils.translateAndPop(message).then(() => {
                this.existingMarkets.forEach(extMarket => {
                  if (extMarket.locationName.toLowerCase() === marketName.toLowerCase()) {
                    this.mapObject = [{ 'longitude': extMarket.longitude, 'latitude': extMarket.latitude, flag: false }];
                    this.market[0].selectedZone = extMarket;
                    this.market[0].existingMarketCheck = true;
                    this.event.broadcast({ eventName: 'existing-market-selected', data: extMarket.longitude + ',' + extMarket.latitude + ',' + 'map0' });

                  }
                });
                this.disableStep2 = false;
              }).catch(() => {
                this.disableStep2 = false;
              });
            });
          } else {
            this.custUtils.translateMessageObject({
              title: 'All fields are mandatory',
              text: 'Please click on an area on Map for the latitude and longitude',
              type: 'error',
              outsideClick: true,
              cancelBtnText: '',
              confirmBtnText: 'Ok',
              showCancelBtn: false
            }, message => {
              this.custUtils.translateAndPop(message).then(() => {
                this.disableStep2 = false;
              }).catch(() => {
                this.disableStep2 = false;
              });
            });
          }
        }
      });
    }

    keyDown(e){
      // charCode > 31 && (charCode < 48 || charCode > 57)
      if (!(e.keyCode >= 47 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105)) {
        e.preventDefault();
        e.stopPropagation();
      }
    }

    keyUp(e){
      if (!((e.keyCode > 95 && e.keyCode < 106) || (e.keyCode > 47 && e.keyCode < 58)
        || e.keyCode == 8)) {
        return false;
      }
    }

    keyUp1(e){
      if (!((e.keyCode > 95 && e.keyCode < 106)
        || (e.keyCode > 47 && e.keyCode < 58)
        || e.keyCode == 8)) {
        return false;
      }
    }

    macAddressFormat(mac, event) {
      // var macAddress = event.target.value.toUpperCase();
      if (!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) {
        event.preventDefault();
        event.stopPropagation();
      }
      else {
        if (event.keyCode != 13) {

          var macAddr = event.target.value;
          var rash;

          var alphaNum = /^[A-Za-z0-9]+$/;
          if (macAddr.includes(':')) {
            if (macAddr.length == 5) {
              // console.log('393', event.target.value);
              var parts = event.target.value.split(':');
              // console.log(parts);
              if (parts[1] > 59) {
                parts[1] = 59;
                event.target.value = parts[0] + ':' + parts[1];
                // console.log('425', event.target.value);
              }
              if (parts[0] > 23) {
                parts[0] = 23;
                event.target.value = parts[0] + ':' + parts[1];
                // console.log('425', event.target.value);
              }
              console.log('final', event.target.value);
            } else if (macAddr.length == 4) {
              // console.log('393', event.target.value);
              var parts = event.target.value.split(':');
              // console.log(parts);
              if (parts[1] > 5) {
                parts[1] = 5;
                event.target.value = parts[0] + ':' + parts[1];
                // console.log('425', event.target.value);
              }
              if (parts[0] > 24) {
                parts[0] = 24;
                event.target.value = parts[0] + ':' + parts[1];
                // console.log('425', event.target.value);
              }
              console.log('final', event.target.value);
            }
          }
          if (macAddr.length == 2 && alphaNum.test(macAddr)) {

            // macAddr = macAddr.replace(/(.{2})/g, "$1:").slice(0, -1);
            macAddr = macAddr + ':';
            event.target.value = macAddr;
            rash = event.target.value;
            console.log('389', event.target.value);
          }
          else if (macAddr.length == 2) {
            if (macAddr > 24) {
              event.target.value = 24;
              rash = event.target.value;
              console.log('395', event.target.value);
            }
            else
              if (macAddr > 12) {
                var count = macAddr - 12;
                event.target.value = 12 + count;
                rash = event.target.value;
                console.log(event.target.value);
              }

          }
          else if (!alphaNum.test(macAddr)) {
            console.log("only alpha-numeric allowed");
          }
        }
      }
    }

    macAddressFormat1(mac, event) {
      // var macAddress = event.target.value.toUpperCase();
      if (!(event.keyCode >= 47 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) {
        event.preventDefault();
        event.stopPropagation();
      }
      else {
        if (event.keyCode != 13) {

          var macAddr = event.target.value;
          var rash;

          var alphaNum = /^[A-Za-z0-9]+$/;
          if (macAddr.includes('/')) {
            if (macAddr.length == 5) {
              // console.log('393', event.target.value);
              var parts = event.target.value.split('/');
              // console.log(parts);
              if (parts[1] > 12) {
                parts[1] = 12;
                event.target.value = parts[0] + '/' + parts[1];
                // console.log('425', event.target.value);
              }
              if (parts[0] > 31) {
                parts[0] = 31;
                event.target.value = parts[0] + '/' + parts[1];
                // console.log('425', event.target.value);
              }

            } else if (macAddr.length == 4) {
              // console.log('393', event.target.value);
              var parts = event.target.value.split('/');
              // console.log(parts);
              if (parts[1] > 5) {
                parts[1] = 5;
                event.target.value = parts[0] + '/' + parts[1];
                // console.log('425', event.target.value);
              }
              if (parts[0] > 31) {
                parts[0] = 31;
                event.target.value = parts[0] + '/' + parts[1];
                // console.log('425', event.target.value);
              }
              console.log('final', event.target.value);
            }
          }
          if (macAddr.length == 2 && alphaNum.test(macAddr)) {

            // macAddr = macAddr.replace(/(.{2})/g, "$1:").slice(0, -1);
            macAddr = macAddr + '/';
            event.target.value = macAddr;
            rash = event.target.value;

          }
          else if (macAddr.length == 2) {
            if (macAddr > 31) {
              event.target.value = 31;
              rash = event.target.value;
              console.log('395', event.target.value);
            }
          }
          else if (!alphaNum.test(macAddr)) {
            console.log("only alpha-numeric allowed");
          }
        }
      }
    }

    isDisable() {
      if ((this.mission.markets[0].managementAuthority && this.mission.markets[0].officialName
        && this.mission.markets[0].adptId && this.mission.markets[0].address
        && (this.mission.markets[0].expectedNumberOfStands && this.mission.markets[0].expectedNumberOfStands !== '0') && (this.mission.markets[0].numberOfSubscribedStands == 0 || this.mission.markets[0].numberOfSubscribedStands)
        && (this.mission.markets[0].numberOfUnSubscribedStands || this.mission.markets[0].numberOfUnSubscribedStands == 0) && this.mission.missionStartDate1
        && this.mission.missionEndDate1)) {
        let list = [];
        if (this.check) {
          list.push('Monday');
        }
        if (this.check2) {
          list.push('Tuesday');
        }
        if (this.check3) {
          list.push('Wednesday');
        }
        if (this.check4) {
          list.push('Thursday');
        }
        if (this.check5) {
          list.push('Friday');
        }
        if (this.check6) {
          list.push('Saturday');
        }
        if (this.check7) {
          list.push('Sunday');
        }

        let boolean = list.every((res, index) => {
          if (res == 'Monday') {
            return this.mission.markets[0].scheduleMonOpen != "" && this.mission.markets[0].scheduleMonOpen != null && this.mission.markets[0].scheduleMonClose != "" && this.mission.markets[0].scheduleMonClose != null;
          }
          if (res == 'Tuesday') {
            return this.mission.markets[0].scheduleTueOpen != "" && this.mission.markets[0].scheduleTueOpen != null && this.mission.markets[0].scheduleTueClose != "" && this.mission.markets[0].scheduleTueClose != null;
          }
          if (res == 'Wednesday') {
            return this.mission.markets[0].scheduleWedOpen != "" && this.mission.markets[0].scheduleWedOpen != null && this.mission.markets[0].scheduleWedClose != "" && this.mission.markets[0].scheduleWedClose != null;
          }
          if (res == 'Thursday') {
            return this.mission.markets[0].scheduleThurOpen != "" && this.mission.markets[0].scheduleThurOpen != null && this.mission.markets[0].scheduleThurClose != "" && this.mission.markets[0].scheduleThurClose != null;
          }
          if (res == 'Friday') {
            return this.mission.markets[0].scheduleFriOpen != "" && this.mission.markets[0].scheduleFriOpen != null && this.mission.markets[0].scheduleFriClose != "" && this.mission.markets[0].scheduleFriClose != null;
          }
          if (res == 'Saturday') {
            return this.mission.markets[0].scheduleSatOpen != "" && this.mission.markets[0].scheduleSatOpen != null && this.mission.markets[0].scheduleSatClose != "" && this.mission.markets[0].scheduleSatClose != null;
          }
          if (res == 'Sunday') {
            return this.mission.markets[0].scheduleSunOpen != "" && this.mission.markets[0].scheduleSunOpen != null && this.mission.markets[0].scheduleSunClose != "" && this.mission.markets[0].scheduleSunClose != null;
          }
        });

        if (list.length > 0) {
          if (boolean == true) {
            return false;
          }
        }
        return true;
      } else {
        return true;
      }
    }

  }