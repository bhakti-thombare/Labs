// core imports
import { Component, OnInit, EventEmitter, Output, ViewChild, ElementRef, Renderer2, AfterViewInit } from '@angular/core';
import { Location } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, Validators } from '@angular/forms';

// 3rd party
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

// app
import { ApiConstants } from '@app/constants/constants';
import { EventService } from '@services/events/event.service';
import { HttpService } from '@app/services/http-service';
import { CreateSurveyUtilsService } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.service';
import { ApiService } from '@services/apiServices/api.service';
import { missionTypes, statuses } from '@app/constants/constants';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import {CampaignSummaryService} from '@services/campaign-summary/campaign-summary.service'
import { PedestrainAlertsService } from '@app/services/Alerts/pedestrainAlerts/pedestrain-alerts.service';

declare var google: any;

@Component({
  selector: 'app-customer-survey',
  templateUrl: './customer-survey.component.html',
  styleUrls: ['./customer-survey.component.css']
})
export class CustomerSurveyComponent implements OnInit, AfterViewInit {

  @Output() surveyChange = new EventEmitter();

  @ViewChild('stepOne') stepOne: ElementRef;
  @ViewChild('stepTwo') stepTwo: ElementRef;
  @ViewChild('zonesDropdown') zonesDropdown: ElementRef;

  xmlHttpUrl = ApiConstants.BASE_URL;
  marketZoneSelected=true;
  today = new Date(Date.now());
  currentDate=new Date(Date.now());
  minDate = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };

  minEndDate = {
    day: null,
    month: null,
    year: null
  };

  model: NgbDateStruct;

  createMissionForm: FormGroup = new FormGroup({
    missionStartDate: new FormControl('', Validators.required),
    missionEndDate: new FormControl('', Validators.required),
    estimatedTimeHourHour: new FormControl('', Validators.required),
    estimatedTimeHourMin: new FormControl('', Validators.required),
    missionName: new FormControl('', Validators.required),
    missionDescription: new FormControl('')
  });

  zoneId;
  morning = true;
  campaignFlag=false;
  user = JSON.parse(localStorage.getItem('user-data'));
  showSkipInStep1: boolean;
  step1: boolean;
  step2: boolean;
  loaderOn: boolean;
  step3: boolean;
  step4: boolean;
  step1Completed=false;
  step2Completed: boolean;
  step3Completed: boolean;
  step4Completed: boolean;
  hideStep1 = false;
  hideStep2 = true;
  hideStep3 = true;
  hideStep4 = true;
  hideStep5 = true;
  pageOpenAllowed: boolean;
  campaignsLoaded: boolean;
  assignmentsLoaded = false;
  existingZonesCheck = false;
  missionsLoaded = false;
  summaryLoaded = false;
  missionTypesLoaded: boolean;
  calendarReady = false;
  selectedMissionType: any;
  missionTypes: any;
  showNewAssignmentBtn = true;
  existingZonesFound = false;
  existingZones = [];
  disableStep1 = false;
  disableStep2 = false;
  disableStep3 = false;
  disableStep4 = false;
  zoneMissionFound = false;
  loadMapForExistingCircuit = false;
  disableMapClick = false;
  datepickers = [];
  fieldAgents = [];
  busyDates = [];
  summaryObj;
  shifts = [
    {
      shiftName: 'Morning',
      timeRange: '8:45 - 13:00',
      startTime: '8:45',
      endTime: '13:00'
    },
    {
      shiftName: 'Afternoon',
      timeRange: '13:00 - 17:15',
      startTime: '13:00',
      endTime: '17:15'
    }
  ];

  prev: number;

  campaigns=[];

  missions: any;
  tempmissions: any;

  zones: any;

  zoneLoaded = false;

  missionId: string;

  freeUsers = [];

  summary = {
    mission: {},
    zones: [],
    assignments: []
  };

  zoneMissionLoaded = false;
  parent2Toggle;
  mission = {
    selectedCampaign: {
      campaignStartDate:'',
      campaignEndDate:'',
      startDateObj: {},
      endDateObj: {},
      campaignName:this.translate.instant('Select compaign'),
    },
    zones: [],
    markets:[],
    assignments: [],
    missionStartDate: {
      year: null,
      month: null,
      day: null
    },
    missionEndDate: {
      year: null,
      month: null,
      day: null
    },
    estimatedTimeHour: null,
    estimatedTimeMinutes: null,
    missionName: '',
    missionDescription: ''
  };

  zoneNameDisabled = true;

  rerender = false;
  minDate1;
  placeName: any;
  constructor(public http: HttpClient,
    public pedestrainAlertsService: PedestrainAlertsService,
    public translate: TranslateService,
    public rd: Renderer2,
    public el: ElementRef,
    public event: EventService,
    public _http: HttpService,
    private location: Location,
    public custUtils: CreateSurveyUtilsService,
    private campaign:CampaignSummaryService,

    public api: ApiService,
    private router:Router) {
      const current = new Date();

      this.minDate1 = {
        
        year: current.getFullYear(),
        month: current.getMonth() + 1,
        day: current.getDate()
      };
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this._http.pullCountry().subscribe(res => { }, err => { });
    // this.getMissiondates()
    // const date = new Date(Date.now());
    // const month = date.getMonth() + 1;
    // localStorage.removeItem('busyDates');
    // this.api.getShiftWiseUsedMissionDates(date.getFullYear() + '-' + month + '-' + date.getDate(), missionTypes.CUSTOMER_SURVEY_TYPE_ID,1)
    //   .subscribe(res => {
    //     let busyDatesLen = res.dateDto.length;
    //     res.dateDto.forEach(resdate => {
    //       resdate.day = parseInt(resdate.day, 10);
    //       resdate.month = parseInt(resdate.month, 10);
    //       resdate.year = parseInt(resdate.year, 10);
    //       this.busyDates.push(resdate);
    //       busyDatesLen--;
    //       if (busyDatesLen === 0) {
    //         localStorage.setItem('busyDates', JSON.stringify(this.busyDates));
    //         this.calendarReady = true;
    //       }
    //     });
      // }, err => {
      //   this.calendarReady = true;
      // });
  }
  goto(){
    
    this.router.navigate(['/supervisor/missions'])
  }
  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6;
  }

  isDisabled(date: NgbDateStruct, current: { month: number }) {

   
      // console.log("issisabled dates",this.campaignFlag);
if( localStorage.getItem('campaignFlag')==='false'){
  console.log("return false");
  
  return false
} else {
  const now = new Date(Date.now());
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    console.log("startcheck=",startCheck);
    
    const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
    console.log("campaignStartDate=",campaignStartDate);
    
    const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
    const sdate = new Date(date.year, date.month - 1, date.day);

    if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };

        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return true;
    }
}

  
  }

  isEndDisabled(date: NgbDateStruct, current: { month: number }) {
    if(!this.campaignFlag){
      return false;
    } else {
      const localDate = JSON.parse(localStorage.getItem('date'));
      const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
      const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
      const busyDates = JSON.parse(localStorage.getItem('busyDates'));
      const minDate = new Date(localDate.year, localDate.month, localDate.day);
      const campaignStartDate = new Date(startCheck.year, startCheck.month, startCheck.day);
      const campaignEndDate = new Date(endCheck.year, endCheck.month, endCheck.day);
      const sdate = new Date(date.year, date.month, date.day);
  
      if (sdate >= minDate && sdate >= campaignStartDate && sdate <= campaignEndDate) {
        if (busyDates !== null) {
          let found = -1;
          const dateFinder = (dateObj) => {
            const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
            if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
              inDate.getDate() === sdate.getDate()) {
              return true;
            } else {
              return false;
            }
          };
  
          found = busyDates.findIndex(dateFinder);
          if (found !== -1) {
            return true;
          } else {
            return false;
          }
        } else {
          return false;
        }
      } else {
        return true;
      }
    }
   
  }
  marketZone;
  getMarketZone(){
    this.api.getMarketZone(this.user.userId).subscribe(res=>{
      this.marketZone=res.data;
    })
  }
  textControl = new FormControl();
  textControl1 = new FormControl();

  nameExists=false;
  selectedMarketZoneValue=this.translate.instant('Select market zone')
  
  selectedMarketZone(id,name) {
    this.marketZoneSelected=true;
    if(this.market && this.name && this.description){
      this.buttonEnabled=true;

    }
    this.marketid=id;
    this.selectedMarketZoneValue=name;
    this.api.getLocationDetails({'locationName':this.selectedMarketZoneValue,'locationType':2}).subscribe(res => {
      let market=res.data;
      this.mission.markets.push({
        longitude: market.longitude,
        latitude: market.latitude
      });
      this.mapObject.push({ 'longitude': 4.348614006026935, 'latitude': 50.84559909325273, flag: true },{ 'longitude': this.mission.markets[0].longitude, 'latitude': this.mission.markets[0].latitude, flag: true });
    });
  }

  name=false;
  description=false;
  buttonEnabled=false;

  ngOnInit() {    
    this.placeName=this.translate.instant('Select compaign');
      this.textControl1.valueChanges.pipe(
        ).subscribe((res)=>{
             res=res.trim()
             if(res !== ''){
               this.description=true
             } else {
               this.description=false
             }
             
             if(this.name && this.marketZoneSelected && this.description){
                 this.buttonEnabled=true;
             } else {
               this.buttonEnabled=false;
             }
        });
      this.textControl.valueChanges.pipe(
      ).subscribe((res)=>{
      
        
        res=res.trim()
        if(res !== ''){
          this.name=true
        } else {
          this.name=false
        }

        if(this.name && this.marketZoneSelected && this.description){
          this.buttonEnabled=true;
      } else {
        this.buttonEnabled=false;
      }

        if(res!==''){
        this.api.getMissionName(res).subscribe((res)=>{
            this.name=true;
            this.nameExists=false;
            
        
          
        },(error)=>{
            this.name=false;
            this.nameExists=true;
        
          
        })
      }
      });

    this.getMarketZone()
    this.mission.zones = [];
    this.step1 = true;
    this.prev = 1;
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this.getCampaigns();
    this.getMissions(() => {
      this.getZones(() => {
        this.zoneLoaded = true;
      });
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
    });
    this.getMissionTypes();
  }

  ngAfterViewInit() {
    $('app-customer-survey').on('click', (e) => {
      setTimeout(() => {
        if (this.existingZonesCheck) {
          if (e.target.className === 'nav-link mission-dd open-dd' || e.target.id === 'openDD') {
            if (!e.target.parentNode.className.includes('show')) {
              this.parent2Toggle = this.zonesDropdown.nativeElement;
              this.classAdder();
            } else if (e.target.parentNode.className.includes('show')) {
              this.parent2Toggle = this.zonesDropdown.nativeElement;
              this.classRemover();
            }
          } else if (e.target.id === 'searchZoneName' || e.target.id === 'dontHideDD1' || e.target.id === 'dontHideDD2' || e.target.id === 'dontHideDD3' || e.target.id === 'dontHideDD4') {

          } else {
            this.parent2Toggle = this.zonesDropdown.nativeElement;
            this.classRemover();
          }
        }
      }, 100);
    });
  }

  classRemover() {
    this.rd.removeClass(this.parent2Toggle.parentNode, 'show');
  }

  classAdder() {
    this.rd.addClass(this.parent2Toggle.parentNode, 'show');
  }

  getCampaigns() {
    this.campaignsLoaded = false;
    this.api.getUserCampaigns(this.user.userId).subscribe(res => {
      this.custUtils.campaignsInitializer(res.data.campaigns, response => {
        if (response.message === 'campaignExpired') {
          this.custUtils.translateMessageObject({
            title: 'Campaign expired.',
            text: 'Please contact admin for more campaigns.',
            type: 'warning',
            outsideClick: true,
            showCancelBtn: false,
            confirmBtnText: 'OK',
            cancelBtnText: ''
          }, (responseMessageObject) => {
            this.custUtils.translateAndPop(responseMessageObject).then(() => {
              this.location.back();
            }).catch(() => {
              this.location.back();
            });
          });
        } else if (response.message === 'success') {
          const data = res.data;
          const today = new Date();
          const todaydate = new Date(
            today.getFullYear(),
            today.getMonth(),
            today.getDate()
          );
          if (this.campaign.selectedCampaign === undefined) {
            // this.mission.selectedCampaign=data.campaigns[1];
            data.campaigns.forEach(element => {
              
              if (element.campaignId !== this.mission.selectedCampaign['campaignId']) {
              
                data.campaigns.forEach(element => {
                  const campaignEndDate = new Date(element.campaignEndDate)

                  // if (!(campaignEndDate < today)) {

                  //   this.mission.selectedCampaign = element;

                  // }
                })

                const campaignEndDate = new Date(element.campaignEndDate)


                if (!(campaignEndDate < todaydate)){
                
                  this.campaigns.push(element)

                }
              }
            });

          } else {


            let campaignEndDate = new Date(this.campaign.selectedCampaign.campaignEndDate)
            if (campaignEndDate < todaydate) {

              data.campaigns.forEach(element => {

                if (campaignEndDate < todaydate) {

                  // this.mission.selectedCampaign = element;

                }
              })
            } else {
              // this.mission.selectedCampaign=this.campaign.selectedCampaign

            }



            data.campaigns.forEach(element => {
              if (element.campaignId !== this.mission.selectedCampaign['campaignId']) {
                campaignEndDate = new Date(element.campaignEndDate)

                if (!(campaignEndDate < todaydate)) {
                  this.campaigns.push(element)

                }
              }
            });
          }
          
          // this.mission.selectedCampaign=this.campaign.selectedCampaign;
          
          // data.campaigns.forEach(element => {
          //   if(element.campaignId!==this.campaign.selectedCampaign.campaignId){
          //     console.log("element",element);
              
          //       this.campaigns.push(element)
          //   }
          // });
          
          // localStorage.setItem('campaignStartDate', JSON.stringify(this.mission.selectedCampaign.startDateObj));
          // localStorage.setItem('campaignEndDate', JSON.stringify(this.mission.selectedCampaign.endDateObj));
          // this.campaigns.splice(0, 1);
          this.campaignsLoaded = true;
        }
      });
    }, err => { });
  }

  getMissions(cb) {
    this.api.getMissionsCreatedByOfMissionType(this.user.userId, missionTypes.CUSTOMER_SURVEY_TYPE_ID).subscribe(res => {
      this.tempmissions = res.data.missions;
      this.custUtils.skipCalculator(res.data.missions, (missions, bool) => {
        this.missions = missions; // missions without zones
        this.missionsLoaded = true;
        // if (bool) {
          this.showSkipInStep1 = true;
        // } else {
        //   this.showSkipInStep1 = false;
        // }
        cb();
      });
    }, err => {
      this.showSkipInStep1 = false;
      cb();
    });
  }

  getZones(cb) {
    this.api.getZones().subscribe(res => {
      let zonesLength = res.data.zones.length;
      if (res.data.zones.length !== 0) {
        res.data.zones.forEach(zone => {
          this.existingZones.push(zone);
          zonesLength--;
          if (zonesLength === 0) {
            if (this.existingZones.length !== 0) {
              this.existingZonesFound = true;
            }
            this.zoneObjectCreator(() => {
              cb();
            });
          }
        });
      }
    }, err => {
      this.existingZonesFound = false;
      this.zoneObjectCreator(() => {
        cb();
      });
    });
  }

  zoneObjectCreator(cb) {
    this.mission.zones = [];
    this.mission.zones.push({
      name: undefined,
      address: undefined,
      lat: null,
      lng: null,
      adptId: null,
      existingZonesCheck: false,
      existingZones: [],
      selectedZone: {},
      missions: [],
      selectedMission: {}
    });
    if (this.missions !== undefined) {
      if (this.missions.length === 0) {
        cb();
      } else {
        let noZoneMissionLength = this.missions.length;
        this.missions.forEach(mission => {
          this.mission.zones[0].missions.push(mission);
          noZoneMissionLength--;
          if (noZoneMissionLength === 0) {
            this.mission.zones[0].selectedMission = this.mission.zones[0].missions[0];
            this.zoneMissionLoaded = true;
            this.mission.zones[0].missions.splice(0, 1);
            cb();
          }
        });
      }
    } else {
      cb();
    }
  }

  // toggleCheckBox(i, event) {
  //   if (event.target.checked !== this.mission.zones[i].existingZonesCheck) {
  //     this.mission.zones[i].existingZonesCheck = event.target.checked;
  //   }
  //   // console.log('this.mission.zones[i].existingZonesCheck',this.mission.zones[i].existingZonesCheck);
  //   if (this.mission.zones[i].existingZonesCheck) {
  //     this.existingZonesCheck = true;
  //     this.existingZoneMapFiller(i);
  //     this.disableMapClick = true;
  //   } else {
  //     this.mapObject = { 'latitude': 50.84559909325273, 'longitude': 4.348614006026935,flag:false };
  //     this.existingZonesCheck = false;
  //     this.mission.zones[i].name = undefined;
  //     this.mission.zones[i].address = undefined;
  //     this.mission.zones[i].lat = null;
  //     this.mission.zones[i].lng = null;
  //     this.mission.zones[i].adptId = null;
  //     this.zoneNameDisabled = true;
  //     this.disableMapClick = false;
  //   }
  // }
   
toggleCheckBox(i, event) {
  console.log("this.missions.zone=",this.mission);
  
  if (event.target.checked !== this.mission.zones[i].existingZonesCheck) {
    console.log("toggle 1");
    
    this.mission.zones[i].existingZonesCheck = event.target.checked;
    
  } 
   // console.log('this.mission.zones[i].existingZonesCheck',this.mission.zones[i].existingZonesCheck);
  if (this.mission.zones[i].existingZonesCheck) {
    console.log("toggle 2");
    
    this.existingZonesCheck = true;
    this.existingZoneMapFiller(i);
    this.disableMapClick = true;
  }else {
   if (this.market) {
      console.log('inside if');
      this.mapObject = [{ 'longitude': this.mission.markets[0].longitude, 'latitude': this.mission.markets[0].latitude, flag: true }];
      this.mapobj2=this.mapObject;
      console.log("mapobj==",this.mapObject,this.mapobj2);
      
      this.existingZonesCheck = false;
      // this.mission.zones[i].name = undefined;
      // this.mission.zones[i].address = undefined;
      // this.mission.zones[i].lat = null;
      // this.mission.zones[i].lng = null;
      // this.mission.zones[i].adptId = null;
      this.zoneNameDisabled = true;
      this.disableMapClick = false;
  }
  else{
      console.log('inside if');
      this.mapObject=[];        
      this.existingZonesCheck = false;
      // this.mission.zones[i].name = undefined;
      // this.mission.zones[i].address = undefined;
      // this.mission.zones[i].lat = null;
      // this.mission.zones[i].adptId = null;
      // this.mission.zones[i].lng = null;
      this.zoneNameDisabled = true;
      this.disableMapClick = false;
      // this.event.broadcast({ eventName: 'existing-zone-selected', data: this.mission.zones[i].selectedZone.longitude + ',' + this.mission.zones[i].selectedZone.latitude + ',' + 'map0' });
  }
  }
  
}
  mapObject: any = [];
  existingZoneMapFiller(i) {
    if (this.existingZones.length !== 0) {
      this.mission.zones[i].existingZones = [];
      let existingZoneLength = this.existingZones.length;
      this.existingZones.forEach(zone => {
        this.mission.zones[i].existingZones.push(zone);
        existingZoneLength--;
        if (existingZoneLength === 0) {
          this.mission.zones[i].selectedZone = this.mission.zones[i].existingZones[0];
          this.mission.zones[i].existingZones.splice(0, 1);
          if (this.market) {
            console.log("in if existing map");
            
            this.mapObject=
            [{ 'longitude': this.mission.zones[i].selectedZone.longitude, 'latitude': this.mission.zones[i].selectedZone.latitude, flag: false },
            { 'longitude': this.mission.markets[0].longitude, 'latitude': this.mission.markets[0].latitude, flag: true }];
            this.mapobj2=this.mapObject
            console.log("mapobj2=",this.mapobj2);
            
            // console.log('mapObject while toggle',this.mapObject);
          }
          else{
            console.log("in else of existing");
            
          this.mapObject=[{'longitude': this.mission.zones[i].selectedZone.longitude, 'latitude': this.mission.zones[i].selectedZone.latitude,flag:false }];
          // this.event.broadcast({ eventName: 'existing-zone-selected', data: this.mission.zones[i].selectedZone.longitude + ',' + this.mission.zones[i].selectedZone.latitude + ',' + 'map0' });
          }
        }
      });
    }
  }

  getMissionTypes() {
    this.missionTypesLoaded = false;
    this.missionTypes = [];

    this.api.getMissionTypes().subscribe(res => {
      let typeLen = res.data.length;
      res.data.forEach(type => {
        if (type.id === 3 || type.id === 4) {
          this.missionTypes.push(type);
        }
        typeLen--;
        if (typeLen === 0) {
          if (this.missionTypes[0].id === 4) {
            this.selectedMissionType = this.missionTypes[0];
            this.missionTypes.splice(0, 1);
          } else {
            this.selectedMissionType = this.missionTypes[1];
            this.missionTypes.splice(1, 1);
          }
          this.missionTypesLoaded = true;
        }
      });
    }, err => {
      console.log('err', err);
    });
  }
  /**
   * Get address by Lat and long for create survey
   * 
   **/
  mapobj2=[]
  getLngLat(e) {
    const api = new google.maps.Geocoder;
    let flag;
    if (!this.step2Completed) {
      this.mission.zones[0].lng = e[0];
      this.mission.zones[0].lat = e[1];
      if (!this.market ) {
        this.mapObject=[{'longitude': e[0], 'latitude': e[1], flag:false },{'longitude': '', 'latitude': '', flag:false}];
        this.mapobj2=this.mapObject
         console.log('inside if',this.mapObject);
      }
      else {
        this.mapObject=[{'longitude': e[0], 'latitude': e[1], flag: false,step4:true},{'longitude': this.mission.markets[0].longitude, 'latitude': this.mission.markets[0].latitude,flag:false,step4:false}];
         console.log('inside else',this.mapObject);
        this.mapobj2=this.mapObject
      }
      this.mission.zones[0].name = undefined;
      this.mission.zones[0].adptId = null;
      this.zoneNameDisabled = false;
      api.geocode({ latLng: { lat: e[1], lng: e[0]} }, result => {
        console.log("result=",result);
        console.log("this.mission=",this.mission);
        
        if (result) {
          this.mission.zones[0].address = result[0].formatted_address;
          this.mission.zones[0].selectedZone.address = result[0].formatted_address;

        }
      });
    }
  }

  surveySelection(surveyId) {
    this.surveyChange.emit(surveyId);
  }

  toggleMissionType(mType) {
    if (mType.id !== 3) {
      this.missionTypes.push(this.selectedMissionType);
      this.selectedMissionType = mType;
      let removeIndex: number;
      this.missionTypes.forEach((tsk, i) => {
        if (tsk === mType) {
          removeIndex = i;
        }
      });
      this.missionTypes.splice(removeIndex, 1);
    } else {
      this.surveySelection(mType.id);
    }
  }
  
  instanceForCampaign(d1) {
    this.datepickers.push(d1);
  }

  toggleCampaign(camp) {
    this.datepickers.forEach(datePicker => {
      datePicker.close();
    });
    this.mission.missionStartDate = {
      year: null,
      month: null,
      day: null
    };
    this.mission.missionEndDate = {
      year: null,
      month: null,
      day: null
    };
    this.mission.selectedCampaign.campaignName==this.translate.instant('Select compaign')?delete this.mission.selectedCampaign.campaignName:false;
    this.campaigns.push(this.mission.selectedCampaign);
    this.mission.selectedCampaign = camp;
    const campStart = camp.campaignStartDate.split(' ')[0];
    // localStorage.setItem('campaignStartDate', JSON.stringify({
    //   day: parseInt(campStart.split('-')[2], 10),
    //   month: parseInt(campStart.split('-')[1], 10),
    //   year: parseInt(campStart.split('-')[0], 10)
    // }));
    // const campEnd = camp.campaignEndDate.split(' ')[0];
    // localStorage.setItem('campaignEndDate', JSON.stringify({
    //   day: parseInt(campEnd.split('-')[2], 10),
    //   month: parseInt(campEnd.split('-')[1], 10),
    //   year: parseInt(campEnd.split('-')[0], 10)
    // }));
    let removeIndex: number;
    this.campaigns.forEach((campaign, i) => {
      if (campaign === camp) {
        removeIndex = i;
      }
    });
    this.campaigns.splice(removeIndex, 1);
  }

  changeLocalDate(date) {
    this.mission.missionEndDate = {
      year: null,
      month: null,
      day: null
    };
    localStorage.setItem('date', JSON.stringify(date));
    this.minEndDate = date;
  }
assignmnts;
  saveAndOpen(step, form) {
    if (step === 1) {
      // this.validateMission(form, () => {
        this.createMission(form);
      // });
    } else if (step === 2) {
      this.validateZone(() => {
        this.createZone();
      })
      this.getMissiondates();
    } else if (step === 3) {
      
      
      this.userId=true;
      this.validateAssignment(() => {
        this.createAssignment();
      })
    } else if (step === 4) {
      this.event.broadcast({ eventName: 'showLoader', data: '' });
      this.goto();
    }
  }

  validateMission(form, cb) {
    if (form.value.nameOfMission !== '' && form.value.startDateMission.day !== null) {
      cb();
    } else {
      this.custUtils.translateMessageObject({
        title: 'All fields are mandatory',
        text: 'Date and name of the mission are required.',
        type: 'error',
        outsideClick: true,
        showCancelBtn: false,
        confirmBtnText: 'OK',
        cancelBtnText: ''
      }, (responseMessageObject) => {
        this.custUtils.translateAndPop(responseMessageObject).then(() => {

        }).catch(() => {

        });
      });
    }
  }

  createMission(formData) {
    if (this.mission.selectedCampaign.campaignName == this.translate.instant('Select compaign')) {
      this.pedestrainAlertsService.selectCampagin();
    }
    else {
      this.disableStep1 = true;
      if (!this.step1Completed) {
        // const startDate = this.mission.missionStartDate.year + '-' +
        //   formData.value.startDateMission.month + '-' + formData.value.startDateMission.day + ' ' + '00:00:00';
        // const endDate = formData.value.startDateMission.year + '-' +
        //   formData.value.startDateMission.month + '-' +
        //   formData.value.startDateMission.day + ' ' + '00:00:00';
        const now = Date.now();
        const creationDate = new Date(now);
        const nowYear = creationDate.getFullYear();
        const nowMonth = creationDate.getMonth() + 1;
        const nowDay = creationDate.getDate();
        const nowInReq = nowYear + '-' + nowMonth + '-' + nowDay + ' ' + '00:00:00';
        const estimatedTime = (parseInt('10', 10) * 60) + parseInt('10', 10);

        const reqObj = {
          // missionName: formData.value.nameOfMission,
          // missionDescription: formData.value.missionDesc,
          // missionTypeId: this.selectedMissionType['id'],
          // missionCreationDate: nowInReq.toString(),
          // missionStartDate: startDate.toString(),
          // missionEndDate: endDate.toString(),
          // missionCampaignId: this.mission.selectedCampaign['campaignId'],
          // missionCreatedById: this.user.userId,
          // missionEstimatedTime: estimatedTime,
          // missionStatusId: statuses.YETTOASSIGN
          missionName: this.mission.missionName,
          missionDescription: this.mission.missionDescription,
          missionTypeId: this.selectedMissionType['id'],
          missionCreationDate: nowInReq.toString(),
          missionCampaignId: this.mission.selectedCampaign['campaignId'],
          missionCreatedById: this.user.userId,
          missionStatusId: 3,
          classic: !this.market,
          market: this.market && this.marketid !== null,
          marketZone: this.market ? this.marketid : null,
          prm: false,
          visits: false
        };

        this._http.SecurePost('/mission/addMission', reqObj).subscribe(res => {
          this.missionId = res.responseMessage.split('! ')[1];
          this.custUtils.translateMessageObject({
            title: 'Mission created successfully',
            text: 'Please create zone for this mission',
            type: 'success',
            cancelBtnText: '',
            confirmBtnText: 'OK',
            outsideClick: false,
            showCancelBtn: false
          }, res => {
            this.custUtils.translateAndPop(res).then(() => {

              this.pageOpenAllowed = true;
              this.step1Completed = true;
              this.createMissionForm.disable();
              // document.getElementById("missionName").disabled = true;
              var elemant1 = document.getElementById('missionName');
              elemant1.setAttribute("disabled", "true");
              var elemant2 = document.getElementById('missionDescription');
              elemant2.setAttribute("disabled", "true");
              var elemant3 = document.getElementById('market');
              elemant3.setAttribute("disabled", "true");
              var elemant3 = document.getElementById('classic');
              elemant3.setAttribute("disabled", "true");
              //  this.createMissionForm.controls['missionName'].disable();
              // this.createMissionForm.controls['missionDescription'].disable();

              this.getMissions(() => {
                this.disableStep1 = false;
                this.open(2);
              });
            }).catch(() => {

            });
          });
        }, err => {
          console.log(err._body);
        });
      }
      let startdate: any
      let endDate
      console.log("this.mission=", this.mission);
      startdate = this.mission.selectedCampaign.campaignStartDate;
      endDate = this.mission.selectedCampaign.campaignEndDate;
      console.log("startdate=", startdate);

      startdate = startdate.split(' ');
      startdate = startdate[0].split('-');
      console.log("startdate=", startdate);
      const startdayObj = {
        year: startdate[0],
        month: startdate[1],
        day: startdate[2]
      }
      endDate = endDate.split(' ');
      endDate = endDate[0].split('-');
      console.log("startdate=", endDate);
      const enddayObj = {
        year: endDate[0],
        month: endDate[1],
        day: endDate[2]
      }
      
      const now = new Date(Date.now());
      const CurrentDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());      
      console.log("lets check=", new Date(this.mission.selectedCampaign.campaignEndDate) < CurrentDate);
      console.log("check 1=", new Date(this.mission.selectedCampaign.campaignEndDate), CurrentDate);


      if (new Date(this.mission.selectedCampaign.campaignEndDate) < CurrentDate) {
        this.campaignFlag = false;
        localStorage.setItem('campaignFlag', 'false');
      } else {
        this.campaignFlag = true;
        localStorage.setItem('campaignFlag', 'true');
        localStorage.setItem('campaignStartDate', JSON.stringify(startdayObj));
        localStorage.setItem('campaignEndDate', JSON.stringify(enddayObj));
      }
    }
  }

  open(page) {
    if ((page === 2 && this.prev === 1 && this.pageOpenAllowed) || (page === 2 && this.step2)) {
      this.step2 = true;
      if (this.prev === 1 && !this.step2Completed) {
        if (this.mission.zones.length === 0) {
          this.zoneObjectCreator(() => {

          });
        } else {
          this.zoneObjectUpdater(() => {

          });
        }
      }
      this.prev = 2;
      this.hideStep1 = true;
      this.hideStep3 = true;
      this.hideStep4 = true;
      this.hideStep5 = true;
      this.hideStep2 = false;
      this.pageOpenAllowed = false;
      this.event.broadcast({ eventName: 'circle-map-loaded', data: '' });
    } else if ((page === 3 && this.prev === 2 && this.pageOpenAllowed) || (page === 3 && this.step3)) {
      this.step3 = true;
      if (this.prev === 2) {
        if (this.mission.assignments.length === 0) {
          this.assignmentObjectCreator();
        }
      }
      this.prev = 3;
      this.hideStep1 = true;
      this.hideStep3 = false;
      this.hideStep4 = true;
      this.hideStep5 = true;
      this.hideStep2 = true;
      this.pageOpenAllowed = false;
    } else if (page === 1 && this.step1 && this.pageOpenAllowed) {
      this.step1 = true;
      this.prev = 1;
      this.hideStep2 = true;
      this.hideStep3 = true;
      this.hideStep4 = true;
      this.hideStep5 = true;
      this.hideStep1 = false;
      this.pageOpenAllowed = false;
    } else if (page === 4 && this.prev === 3 && this.pageOpenAllowed) {
      this.market =this.market;
      this.classic=true;
      this.step4 = true;
      this.market
      if (this.prev === 3) {
        this.summaryCreator();
      }
      this.prev = 4;
      this.hideStep2 = true;
      this.hideStep3 = true;
      this.hideStep4 = false;
      this.hideStep1 = true;
      this.pageOpenAllowed = false;
    }
  }

  // summaryCreator() {
  //   this.summaryLoaded = false;
  //   this.summaryObj = {
  //     mission: this.mission.zones[0].selectedMission,
  //     zone: this.mission.zones[0],
  //     assignment: this.mission.assignments[0],
  //   }
  //   setTimeout(() => {
  //     this.summaryLoaded = true;
  //     this.event.broadcast({ eventName: 'circle-map-loaded', data: '' });
  //   }, 500);
  //   setTimeout(() => {
  //     this.event.broadcast([{ eventName: 'existing-zone-selected', data: this.summaryObj.zone.lng + ',' + this.summaryObj.zone.lat + ',' + 'map1' },{ 'longitude': this.mission.markets[0].longitude, 'latitude': this.mission.markets[0].latitude, flag: true }]);
  //   }, 700);
  // }
  summaryCreator() {
    this.summaryLoaded = false;
    this.summaryObj = {
      mission: this.mission.zones[0].selectedMission,
      zone: this.mission.zones[0].selectedZone,
      assignment: this.mission.assignments[0],
    }
    console.log("summary obj==",this.summaryObj);
    
    console.log("this.mission=",this.mission);
    // this.mission.zones[0].selectedZone=this.mapObject;
    if(this.market){
      
      // this.mapObject=
      // [{ 'longitude': this.mission.zones[0].selectedZone[0].longitude, 'latitude': this.mission.zones[0].selectedZone[0].latitude, flag: true },
      // { 'longitude': this.mission.zones[0].selectedZone[1].longitude, 'latitude': this.mission.zones[0].selectedZone[1].latitude, flag: true }]
      // { 'longitude': this.mission.zones[0].selectedZone[2].longitude, 'latitude': this.mission.zones[0].selectedZone[2].latitude, flag: true },
      // { 'longitude': this.mission.zones[0].selectedZone[3].longitude, 'latitude': this.mission.zones[0].selectedZone[3].latitude, flag: true }]
    
      // [{ 'longitude': this.mission.zones[0].selectedZone.longitude, 'latitude': this.mission.zones[0].selectedZone.latitude, flag: true },
      // { 'longitude': this.mission.markets[0].longitude, 'latitude': this.mission.markets[0].latitude, flag: true }];
      console.log(this.mission); 
    }
    else{
    // this.mapObject=[{'longitude': this.summaryObj.zone.lng, 'latitude':this.summaryObj.zone.lng,flag:false }];
    }
    setTimeout(() => {
      this.summaryLoaded = true;
      this.event.broadcast({ eventName: 'circle-map-loaded', data: '' });
    }, 500);
    // setTimeout(() => {
    //   this.event.broadcast([{ eventName: 'existing-zone-selected', data: this.summaryObj.zone.lng + ',' + this.summaryObj.zone.lat + ',' + this.mission.markets[0].longitude + ',' + this.mission.markets[0].latitude + ',' + 'map1' }]); 
    // }, 700);
  }

  zoneObjectUpdater(cb) {
    if (this.step1Completed) {
    
      this._http.SecureGet('/ref/getAllMissions?id=' + this.missionId).subscribe(res => {
        // console.log(this.mission.zones);
        this.mission.zones.forEach(zone => {
          zone.selectedMission = res.data.missions[0];
          this.zoneMissionFound = true;
        });
        if (this.market ) {
          console.log("after save1=",this.mapObject);

          // this.mapObject.push({ 'latitude': 50.84559909325273, 'longitude': 4.348614006026935, flag: true },{ 'longitude': this.mission.markets[0].longitude, 'latitude': this.mission.markets[0].latitude, flag: true });
          // console.log('inside else', this.mapObject);
          console.log("after save2=",this.mapObject);

        }
      });
    }
    console.log("after save3=",this.mapObject);

  }

  skip(currStep) {
    if (currStep === 1) {
      this.step2 = true;
      this.hideStep1 = true;
      this.hideStep3 = true;
      this.hideStep4 = true;
      this.hideStep5 = true;
      this.hideStep2 = false;
      if (this.prev === 1) {
        if (this.mission.zones.length === 0) {
          this.event.broadcast({ eventName: 'showLoader', data: '' });
          this.zoneObjectCreator(() => {
            this.event.broadcast({ eventName: 'circle-map-loaded', data: '' });
          });
          this.prev = 2;
        } else {
          this.prev = 2;
          this.event.broadcast({ eventName: 'circle-map-loaded', data: '' });
        }
      }
      this.rd.setStyle(this.stepOne.nativeElement, 'cursor', 'pointer', 1);
      this.step1 = false;
    }
  }

  getExistingZonesDropdownStyle(val) {
    if (val) {
      return { 'margin-top': '40px', 'margin-bottom': '190px' };
    } else {
      return { 'margin-top': '30px', 'margin-bottom': '10px' };
    }
  }

  existingDropdownToggled(value, i) {
    if (!value) {
      this.mission.zones[i].existingZones = Object.assign([], this.existingZones).filter(item => {
        if (this.mission.zones[i].selectedZone.name !== item.name) {
          return item;
        }
      });
    }
  }

  validateZone(cb) {
    const zone = this.mission.zones[0];
    if (zone.existingZonesCheck) {
      cb();
    } else {
      if (zone.name !== undefined && zone.name !== '' && zone.address !== undefined && zone.address !== '' && zone.adptId !== null && zone.adptId !== '' && zone.lat !== null && zone.lng !== null) {
        cb();
      } else {
        this.custUtils.translateMessageObject({
          title: 'All fields are mandatory',
          text: 'Please click on an area on Map for the latitude and longitude.',
          type: 'warning',
          cancelBtnText: '',
          confirmBtnText: 'OK',
          outsideClick: false,
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
          }).catch(() => {
          });
        });
      }
    }
  }

  createZone() {
    this.disableStep2 = true;
    console.log('in create zone mission=',this.mission);
    


    const zone = this.mission.zones[0];
    if (zone.existingZonesCheck) {
      const reqObj = {
        missionId: zone.selectedMission.missionId,
        zoneUpdatedBy: this.user.userId,
        zoneId: zone.selectedZone.id,
        locationTypeId : 3
      };
      this.mapMissionWithExistingZone(reqObj);
    } else {
      this.mission.zones[0].selectedZone.name = this.mission.zones[0].name;
    this.mission.zones[0].selectedZone.adptId = this.mission.zones[0].adptId;
      const reqObj = {
        missionId: zone.selectedMission.missionId,
        zoneCreatedBy: this.user.userId,
        zoneUpdatedBy: this.user.userId,
        zoneAdptId: zone.adptId,
        zoneName: zone.name,
        zoneLatitude: zone.lat,
        zoneLongitutde: zone.lng,
        zoneAddress: zone.address,
        locationId : null,
        locationTypeId : 3
      };
      this.createAndMapZoneWithMission(reqObj);
    }
  }

  mapMissionWithExistingZone(req) {
    this.api.missionZoneMapping(req).subscribe(res => {
      this.zoneId = req.zoneId;
      this.custUtils.translateMessageObject({
        title: 'Zone mapped successfully',
        text: 'Mission mapped with this zone',
        type: 'success',
        outsideClick: true,
        cancelBtnText: '',
        confirmBtnText: 'Ok',
        showCancelBtn: false
      }, message => {
        this.custUtils.translateAndPop(message).then(() => {
          this.pageOpenAllowed = true;
          this.step2Completed = true;
          this.disableStep3 = false;
          this.disableMapClick = true;
          this.open(3);
        }).catch(() => {
          this.pageOpenAllowed = true;
          this.step2Completed = true;
          this.disableStep3 = false;
          this.disableMapClick = true;
          this.open(3);
        });
      });
    }, err => {
      this.custUtils.translateMessageObject({
        title: 'Zone not mapped',
        text: 'Please try again',
        type: 'error',
        outsideClick: true,
        cancelBtnText: '',
        confirmBtnText: 'Ok',
        showCancelBtn: false
      }, message => {
        this.custUtils.translateAndPop(message).then(() => {
          this.disableStep2 = false;
        }).catch(() => {
          this.disableStep2 = false;
        });
      });
    });
  }

  createAndMapZoneWithMission(req) {
    let zoneName = req.zoneName;
    this.api.createZone(req).subscribe(res => {
      this.zoneId = res.responseMessage.split('! ')[2];
      this.custUtils.translateMessageObject({
        title: 'Zone created successfully',
        text: 'Mission mapped with this zone',
        type: 'success',
        outsideClick: true,
        cancelBtnText: '',
        confirmBtnText: 'Ok',
        showCancelBtn: false
      }, message => {
        this.custUtils.translateAndPop(message).then(() => {
          this.pageOpenAllowed = true;
          this.step2Completed = true;
          this.disableStep3 = false;
          this.disableMapClick = true;
          this.open(3);
        }).catch(() => {
          this.pageOpenAllowed = true;
          this.step2Completed = true;
          this.disableStep3 = false;
          this.disableMapClick = true;
          this.open(3);
        });
      });
    }, err => {
      let response = JSON.parse(err._body);
      if (response.responseMessage === undefined) {
        this.custUtils.translateMessageObject({
          title: 'Something went wrong',
          text: 'Zone not created please try again',
          type: 'error',
          outsideClick: true,
          cancelBtnText: '',
          confirmBtnText: 'Ok',
          showCancelBtn: false
        }, message => {
          this.custUtils.translateAndPop(message).then(() => {
            this.disableStep2 = false;
          }).catch(() => {
            this.disableStep2 = false;
          });
        });
      } else {
        if (response.responseMessage.includes('Zone with')) {
          let backEndString = response.responseMessage.split('Zone with ')[1];
          // let zoneName = backEndString.split(' already exists')[0];
          this.custUtils.translateMessageObject({
            title: 'Zone with the same name already present',
            text: 'Do you want to use the exisiting zone?',
            type: 'error',
            outsideClick: false,
            cancelBtnText: 'No, cancel',
            confirmBtnText: 'Yes, use exising zone',
            showCancelBtn: true
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.existingZones.forEach(extZone => {
                if (extZone.name.toLowerCase() === zoneName.toLowerCase()) {
                  this.mapObject = [{ 'longitude': extZone.longitude, 'latitude': extZone.latitude,step4:true }];
                  this.mission.zones[0].selectedZone = extZone;
                  this.mission.zones[0].existingZonesCheck = true;
                  this.event.broadcast({ eventName: 'existing-zone-selected', data: extZone.longitude + ',' + extZone.latitude + ',' + 'map0' });
                  this.disableMapClick = true;
                }
              });
              this.disableStep2 = false;
            }).catch(() => {
              this.disableStep2 = false;
            });
          });
        } else {
          this.custUtils.translateMessageObject({
            title: 'Something went wrong',
            text: 'Zone not created please try again',
            type: 'error',
            outsideClick: true,
            cancelBtnText: '',
            confirmBtnText: 'Ok',
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.disableStep2 = false;
            }).catch(() => {
              this.disableStep2 = false;
            });
          });
        }
      }
    });
    
  }

  toggleExistingZone(zone, i, e) {
    this.mapObject = [{ 'longitude': zone.longitude, 'latitude': zone.latitude,step4:true }];
    if(this.market){
      this.mapObject.push({ 'longitude': this.mission.markets[0].longitude, 'latitude': this.mission.markets[0].latitude, flag: true });

    }
    this.mapobj2=this.mapObject
    this.mission.zones[i].existingZones.push(this.mission.zones[i].selectedZone);
    this.mission.zones[i].existingZones.splice(e, 1);
    this.mission.zones[i].selectedZone = zone;
    this.event.broadcast({ eventName: 'existing-zone-selected', data: this.mission.zones[i].selectedZone.longitude + ',' + this.mission.zones[i].selectedZone.latitude + ',' + 'map0' });
  }

  searchExistingZoneName(value, i) {
    if (!value) {
      this.mission.zones[i].existingZones = Object.assign([], this.existingZones).filter(item => {
        if (this.mission.zones[i].selectedZone.name !== item.name) {
          return item;
        }
      });
    } else {
      this.mission.zones[i].existingZones = Object.assign([], this.existingZones).filter(
        item => {
          if (this.mission.zones[i].selectedZone.name !== item.name) {
            return item.name.toLowerCase().indexOf(value.toLowerCase()) > -1;
          }
        }
      );
    }
  }
getMissiondates(){
  const date = new Date(Date.now());
  const month = date.getMonth() + 1;
  localStorage.removeItem('busyDates');
  this.busyDates=[]
  this.api.getShiftWiseUsedMissionDates(date.getFullYear() + '-' + month + '-' + date.getDate(), missionTypes.CUSTOMER_SURVEY_TYPE_ID,this.morning?1:2)
    .subscribe(res => {
      console.log("res=",res);
      
      let busyDatesLen = res.dateDto.length;
      res.dateDto.forEach(resdate => {
        resdate.day = parseInt(resdate.day, 10);
        resdate.month = parseInt(resdate.month, 10);
        resdate.year = parseInt(resdate.year, 10);
        
        this.busyDates.push(resdate);
        
        busyDatesLen--;
        if (busyDatesLen === 0) {
          localStorage.setItem('busyDates', JSON.stringify(this.busyDates));
          
          this.calendarReady = true;
        }
      });
    }, err => {
      this.calendarReady = true;
    });
 
}
  changeShiftId(id) {
    if (id === 1) {
      this.morning = true;
      this.getMissiondates();
      if(this.startDate!== undefined){
        this.dateSelected=true;
        this.startDate = `${this.missionDate} 08:45:00`
        this.endDate = `${this.missionDate} 13:00:00`
    
        this.assignmentObjectCreator()
      }
    } else {
      this.morning = false;
      this.getMissiondates();
      if(this.startDate!== undefined){
        this.dateSelected=true
        this.startDate = `${this.missionDate} 13:00:00`
        this.endDate = `${this.missionDate} 17:15:00`
      
        this.assignmentObjectCreator()
        
      }    }
  }
  startDate;
  endDate;
  dateSelected=false;
  selectedDate;
  missionDate;
  getDate(d1) {
    this.currentDate = this.startDate;

    var g1 = new Date();
    // (YYYY-MM-DD) 
    var CurrentDate = new Date()
    var d = new Date();
    // var d = new Date(CurrentDate),
    let dateToday = {
      month: '' + (d.getMonth() + 1),
      day: '' + d.getDate(),
      year: d.getFullYear()
    }


    if (dateToday.month.length < 2)
      dateToday.month = '0' + dateToday.month;
    if (dateToday.day.length < 2)
      dateToday.day = '0' + dateToday.day;
    var today = `${dateToday.year}-${dateToday.month}-${dateToday.day}`
    var endDateCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    var startDateCheck = JSON.parse(localStorage.getItem('campaignStartDate'));


    endDateCheck = new Date(`${endDateCheck.year}-${endDateCheck.month}-${endDateCheck.day}`)
    startDateCheck = new Date(`${startDateCheck.year}-${startDateCheck.month}-${startDateCheck.day}`)

    // var g2 = new Date(`${d1.year}-${d1.month}-${d1.day}`); 
    // console.log("d1.day=", d1.day, g1.getMonth(), this.minDate, this.minDate.day === d1.day);
    var GivenDate = new Date(`${d1.year}-${d1.month}-${d1.day}`);
    // console.log("given date=", GivenDate.toString(), today);
    const month1 = String(d1.month).padStart(2, "0");
    const day1 = String(d1.day).padStart(2, "0");
    // console.log("givendate=", GivenDate, "startdatecheck=", !(GivenDate > endDateCheck), !(GivenDate < startDateCheck));
    const month = String(d1.month).padStart(2, "0");
    const day = String(d1.day).padStart(2, "0");
    this.selectedDate = `${d1.year}-${month}-${day} 00:00:00`
    this.missionDate = `${d1.year}-${month}-${day}`

    var todayDate = `${d1.year}-${month1}-${day1}`
    if (this.campaignFlag) {
      if ((!(GivenDate > endDateCheck) && !(GivenDate < startDateCheck)) || (GivenDate == startDateCheck)) {
        const month = String(d1.month).padStart(2, "0");
        const day = String(d1.day).padStart(2, "0");
        this.selectedDate = `${d1.year}-${month}-${day} 00:00:00`
        this.missionDate = `${d1.year}-${month}-${day}`

        if (this.morning) {

          this.startDate = `${d1.year}-${month}-${day} 08:45:00`
          this.endDate = `${d1.year}-${month}-${day} 13:00:00`
        } else {
          this.startDate = `${d1.year}-${month}-${day} 13:00:00`
          this.endDate = `${d1.year}-${month}-${day} 17:15:00`
        }
        if (GivenDate >= CurrentDate || (today === todayDate)) {
          // } else if(this.minDate.day===d1.day) {
          console.log("in else if");

          this.dateSelected = true;
          this.mission.missionStartDate = {
            year: d1.year,
            month: d1.month,
            day: d1.day
          }
          // const month=String(d1.month).padStart(2, "0");
          // const day=String(d1.day).padStart(2, "0");
          // this.startDate=`${d1.year}-${month}-${day} 00:00:00`
          this.currentDate = this.startDate;

          this.assignmentObjectCreator();
        }
      }
    } else {
      if (GivenDate >= CurrentDate || (today === todayDate)) {
        // } else if(this.minDate.day===d1.day) {
        console.log("in else if");

        this.dateSelected = true;
        this.mission.missionStartDate = {
          year: d1.year,
          month: d1.month,
          day: d1.day
        }
        // const month=String(d1.month).padStart(2, "0");
        // const day=String(d1.day).padStart(2, "0");
        // this.startDate=`${d1.year}-${month}-${day} 00:00:00`
        this.currentDate = this.startDate;
        this.assignmentObjectCreator();
      }
    }


    // else {
    //   this.dateSelected=true;
    //   this.mission.missionStartDate={
    //      year:d1.year,
    //      month:d1.month,
    //      day:d1.day
    //   }
    //   const month=String(d1.month).padStart(2, "0");
    //   const day=String(d1.day).padStart(2, "0");
    //   this.startDate=`${d1.year}-${month}-${day} 00:00:00`
    //   this.assignmentObjectCreator();
    // }

  }

  assignmentObjectCreator() {
    this.mission.assignments = [];
    this.api.getZone(this.zoneId).subscribe(res => {
      const obj = {
        selectedZone: res.data.zones[0],
        selectedFieldAgent: {
        },
        fieldAgents: [],
        tempFieldAgents: [],
        shiftTimings: [
          {
            first: '08:45',
            second: '13:00'
          },
          {
            first: '13:00',
            second: '17:15'
          }
        ]
      };
      this.assignmentFieldAgentsFiller(obj, (freeUsers) => {
        obj.fieldAgents = freeUsers;
        console.log();
        
        obj.tempFieldAgents = freeUsers;
          obj.selectedFieldAgent = obj.fieldAgents[0];
         if(!this.dateSelected){
          obj.fieldAgents.splice(0, 1);
           obj.selectedFieldAgent['firstName']=' ';
           obj.selectedFieldAgent['lastName']= '';
           

         }
        this.mission.assignments.push(obj);
        this.assignmnts=this.mission.assignments
        console.log("open step 3=",this.assignmnts);
        this.assignmentsLoaded = true;
      });
    }, err => {

    });

  }

  assignmentFieldAgentsFiller(assignment, cb) {
    this.api.getUnassignedUsers({
      // startDate: this.mission.zones[0].selectedMission.missionStartDate.split(' ')[0],
      startDate:this.dateSelected?this.selectedDate:this.currentDate,
      missionId: this.mission.zones[0].selectedMission.missionId,
      shift:this.morning?1:2
    }).subscribe(res => {
      // this.dateSelected=true;
      cb(res.users);
    }, err => {
      this.custUtils.translateMessageObject({
        title: this.translate.instant('No Field agents available')  ,
        text: this.translate.instant('Please change the mission date or  ask admin to add more field agents.'),
        type: 'warning',
        cancelBtnText: '',
        confirmBtnText: 'OK',
        outsideClick: false,
        showCancelBtn: false
      }, message => {
        this.custUtils.translateAndPop(message).then(() => {
          this.mission.assignments=this.assignmnts
          this.dateSelected=false;
          assignment.fieldAgents=[];
          this.agentSelected=false
          // this.location.back();
        }).catch(() => {
          this.mission.assignments=this.assignmnts
          this.dateSelected=false;
          assignment.fieldAgents=[];
          this.agentSelected=false

          // this.location.back();
        });
      });
    });
  }

  checkAndOpen(page) { // on click of wizard this fuction decides if allow access can go to utils
    if ((page === 1 && this.step1) || (page === 2 && this.step2) ||
      (page === 3 && this.step3) || (page === 4 && this.step4)) {
      this.pageOpenAllowed = true;
    }
    if (page === 1 && this.step2) {
      if (!this.step2Completed && !this.step1Completed) {
        // this.pageOpenAllowed = true;
        // this.step1 = true;
      } else if (this.step2Completed && this.step1Completed) {
        this.pageOpenAllowed = true;
        this.step1 = true;
      } else if (this.step1Completed && !this.step2Completed) {
        this.pageOpenAllowed = true;
        this.step1 = true;
      } else {
        this.pageOpenAllowed = false;
        this.step1 = false;
      }
    } else if (page === 2 && this.step3) {

    } else if (page === 3) {
      if (this.step3Completed) {

      }
    }
    this.open(page);
  }

  toggleMission(mission, i) {
    let deleteIndex;
    this.mission.zones[i].missions.push(this.mission.zones[i].selectedMission);
    let zoneMissionLength = this.mission.zones[i].missions.length;
    this.mission.zones[i].missions.forEach((miss, del) => {
      if (miss.missionId === mission.missionId) {
        deleteIndex = del;
      }
      zoneMissionLength--;
      if (zoneMissionLength === 0) {
        this.mission.zones[i].missions.splice(deleteIndex, 1);
        this.mission.zones[i].selectedMission = mission;
      }
    });
  }
 agentSelected=false;
  toggleFieldAgent(fa, i) {
    
    this.agentSelected=true;
    let deleteIndex;
    this.mission.assignments[0].fieldAgents.push(this.mission.assignments[0].selectedFieldAgent);
    
    this.mission.assignments[0].selectedFieldAgent = fa;
    let faLength = this.mission.assignments[0].fieldAgents.length;
    this.mission.assignments[0].fieldAgents.forEach((fieldAgent, delI) => {
      if (fa.userId === fieldAgent.userId) {
        deleteIndex = delI;
      }
      faLength--;
      if (faLength === 0) {
        this.mission.assignments[0].fieldAgents.splice(deleteIndex, 1);
      }
    });
  }

  validateAssignment(cb) {
    if (this.assignmentsLoaded) {
      cb();
    }
  }
  userId=true;
  saveWithoutAssign(){
    this.agentSelected=false;

    this.userId=false;
    this.createAssignment();
  }
  createAssignment() {
    var elemant1 = document.getElementById('calender');
            elemant1.setAttribute("disabled","true"); 
    this.disableStep3 = true;
    const requestAssignmentObject = {
      missionId: this.missionId ? this.missionId : this.mission.zones[0].selectedMission.missionId,
  missionTypeId: this.selectedMissionType['id'],
  missionEstimatedTime: 610,
  missionStartDate: this.selectedDate ,
  missionEndDate: this.selectedDate,
  assignMission:this.userId,
      assignments:[
        {
          userId:this.userId? this.mission.assignments[0].selectedFieldAgent.userId:null,
            campaignId: this.mission.zones[0].selectedMission.missionCampaign.campaignId,
            missionId: this.missionId ? this.missionId : this.mission.zones[0].selectedMission.missionId,
            zone: this.mission.assignments[0].selectedZone.id,
            createdBy: this.user.userId,
            updatedBy: this.user.userId,
            shiftId: this.morning?1:2,
            startDate: `${this.startDate}`,
            endDate: `${this.endDate}`,
        }
      ]
    };

    
    requestAssignmentObject.missionId = parseInt(requestAssignmentObject.missionId, 10);

    const sendAssignment = (i) => {
      // const reqObj = {
      //   userId:this.userId? this.mission.assignments[0].selectedFieldAgent.userId:null,
      //   campaignId: this.mission.zones[0].selectedMission.missionCampaign.campaignId,
      //   missionId: this.missionId ? this.missionId : this.mission.zones[0].selectedMission.missionId,
      //   zone: this.mission.assignments[0].selectedZone.id,
      //   createdBy: this.user.userId,
      //   updatedBy: this.user.userId,
      //   shiftId: this.morning?1:2,
      //   startDate: this.startDate + ' ' + this.mission.assignments[0].shiftTimings[i].first + ':00',
      //   endDate: this.startDate + ' ' + this.mission.assignments[0].shiftTimings[i].second + ':00',
      // };
      // this.userId?
      // requestAssignmentObject.assignments.push(reqObj):null;
      if (i >= 1) {
        this.api.assignCustomerSurvey(requestAssignmentObject).subscribe(res => {
          this.custUtils.translateMessageObject({
            title: 'Assignments created successfully',
            text: '',
            type: 'success',
            cancelBtnText: '',
            confirmBtnText: 'OK',
            outsideClick: false,
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.pageOpenAllowed = true;
              this.step3Completed = true;
              this.disableStep4 = false;
              this.open(4);
            }).catch(() => {
              this.pageOpenAllowed = true;
              this.step3Completed = true;
              this.disableStep4 = false;
              this.open(4);
            });
          });
        }, err => {
          this.custUtils.translateMessageObject({
            title: 'Assignments were not successful',
            text: 'Please try again',
            type: 'error',
            cancelBtnText: '',
            confirmBtnText: 'OK',
            outsideClick: false,
            showCancelBtn: false
          }, message => {
            this.custUtils.translateAndPop(message).then(() => {
              this.disableStep3 = false;
            }).catch(() => {
              this.disableStep3 = false;
            });
          });
        });
      } else {
        i++;
        sendAssignment(i);
      }
    };
    sendAssignment(0);
  }


  classic=true;
   market=false;
   marketid=null;
  onChecked(event,name){
    // && this.marketid==null
    if(name==='market'){
      if(event.target.checked){
        this.buttonEnabled=false;
        this.classic=false;

        this.marketZoneSelected=false;
        this.market=true

      }
      if(!event.target.checked){
        this.classic=true;
        this.mapObject=[]
        this.market=false
        this.marketZoneSelected=true;
        this.selectedMarketZoneValue=this.translate.instant('Select market zone')

        this.marketZoneSelected=true;
       

      }
      if(this.name && this.description && this.marketZoneSelected ){
        this.buttonEnabled=true;
    }
      // this.market=event.target.checked;
    }
    if(name==='classic'){
      if(event.target.checked){
        this.marketid=null;
        this.marketZoneSelected=true;

        this.selectedMarketZoneValue=this.translate.instant('Select market zone')
        this.market=false;
        this.classic=true;
        this.mapObject=[]
      } else {
        this.buttonEnabled=false;
        this.classic=false;
        this.marketZoneSelected=false;
        this.market=true
      }
     
    }
  }
}

