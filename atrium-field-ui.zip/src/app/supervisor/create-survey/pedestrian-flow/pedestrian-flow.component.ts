// core
import {
  Component, OnInit, ElementRef, ViewChild,
  Renderer2, EventEmitter, Output, OnChanges
} from '@angular/core';
import { Location } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import {  FormGroup, FormControl, Validators, NgForm } from '@angular/forms';
import * as mapboxCircle from 'mapbox-gl-circle';
// 3rd party
import {filter, isNull} from 'underscore';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import {
  Ng4FilesStatus,
  Ng4FilesSelected,
  Ng4FilesService,
  Ng4FilesConfig
} from 'angular4-files-upload';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from "@ngx-translate/core";


// app
import { HttpService } from '@app/services/http-service';
import { EventService } from '@services/events/event.service';
import { UTILS } from '@services/global-utility.service';
import { ApiConstants } from '@app/constants/constants';
import { ApiService } from '@services/apiServices/api.service';
import { CreateSurveyUtilsService } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.service';
import { TranslationService } from '@services/translation/translation.service';
import { missionTypes } from '@app/constants/constants';
import { PedestrainAlertsService } from '@services/Alerts/pedestrainAlerts/pedestrain-alerts.service';
import { debounceTime } from 'rxjs/operator/debounceTime';
import { Router } from '@angular/router';
import {CampaignSummaryService} from '@services/campaign-summary/campaign-summary.service'


declare var google: any;
/* @author : Pratik Bhuta
  the functions are separated according to the following:-
  1. Getters
  2. Togglers
  3. Creators
  4. DOM Flags Manipulators
  5. Fillers
  6. Validators
  7. Deletors
*/

@Component({
  selector: 'app-pedestrian-flow',
  templateUrl: './pedestrian-flow.component.html',
  styleUrls: ['./pedestrian-flow.component.css']
})
export class PedestrianFlowComponent implements OnInit {
  
  @Output() surveyChange = new EventEmitter();
  @ViewChild('stepOne') stepOne: ElementRef;
  @ViewChild('stepTwo') stepTwo: ElementRef;
  @ViewChild('circuitsDropdown') circuitsDropdown: ElementRef;
  xmlHttpUrl = ApiConstants.BASE_URL;
  myCircle1 = new mapboxCircle({ lat: 39.984, lng: -75.343 }, 150, {
    editable: false,
    maxRadius: 150,
    fillColor: 'purple'
  });
  
  today = new Date(Date.now());

  minDate = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };

  minEndDate = {
    day: null,
    month: null,
    year: null
  };
  formatter = (result: string) => result.toUpperCase();
  model: NgbDateStruct;
  public selectedFiles;

  createMissionForm: FormGroup = new FormGroup({
    missionStartDate: new FormControl('', Validators.required),
    missionEndDate: new FormControl('', Validators.required),
    estimatedTimeHourHour: new FormControl('', Validators.required),
    estimatedTimeHourMin: new FormControl('', Validators.required),
    missionName: new FormControl('', Validators.required),
    missionDescription: new FormControl('')
  });

  user = JSON.parse(localStorage.getItem('user-data'));
  showskipin2: boolean;
  showSkipInStep1: boolean;
  dontshowskipin3: boolean;
  step1: boolean;
  step2: boolean;
  loaderOn: boolean;
  step3: boolean; // remove true
  step4: boolean;
  step5: boolean;
  step1Completed=false;
  step2Completed=false;
  step3Completed=false;
  step4Completed=false;
  step5Completed=false;
  showStep5: boolean;
  parent2Toggle;
  hideStep1 = false;
  hideStep2 = true;
  noCheckpointCircuits = [];
  hideStep3 = true;
  hideStep4 = true;
  hideStep5 = true;
  pageOpenAllowed: boolean;
  campaignsLoaded: boolean;
  assignmentsLoaded: boolean;
  existingCircuitsCheck = false;
  missionsLoaded = false;
  circuitsLoaded = false;
  missionTypesLoaded: boolean;
  calendarReady = false;
  selectedMissionType: any;
  showMissionsInCheckpoint = false;
  missionTypes: any;
  showAddNewCircuit = true;
  showNewAssignmentBtn = true;
  showAddNewCheckpoint = true;
  existingCircuitsFound = true;
  existingCircuits = [];
  disableStep1 = false;
  disableStep2 = false;
  disableStep3 = false;
  disableStep4 = false;
  loadMapForExistingCircuit = false;
  datepickers = [];
  dkadptIdDisabled = false;
  checkpointsOnMap = [];
  fieldUsers=[];
  checkpointMap;

  checkpointMapGeoJSON = {
    'type': 'FeatureCollection',
    'features': [],

  };

  fieldAgents = [];

  busyDates = [];

  shifts: any = [];

  geojson = {
    type: 'FeatureCollection',
    features: []
  };
  marketZoneSelected=true;
  prev: number;

  campaigns=[];

  missions: any;
  tempmissions: any;

  circuits: any;

  missionId: string;

  freeUsers = [];

  summary = {
    mission: {},
    circuits: [],
    checkpoints: [],
    assignments: []
  };

  mission = {
    selectedCampaign: {
      campaignStartDate:'',
      campaignEndDate:'',
      startDateObj: {},
      endDateObj: {},
      campaignName:this.translate.instant('Select compaign')
    },
    markets:[],
    circuits: [],
    checkpoints: [],
    assignments: [],
    missionStartDate: {
      year: null,
      month: null,
      day: null
    },
    missionEndDate: {
      year: null,
      month: null,
      day: null
    },
    estimatedTimeHour: null,
    estimatedTimeMinutes: null,
    missionName: '',
    missionDescription: ''
  };

  circuitNameDisabled = true;

  rerender = false;
  private testConfig: Ng4FilesConfig = {
    acceptExtensions: ['jpeg', 'jpg', 'png'],
    maxFilesCount: 1,
    maxFileSize: 20000000,
    totalFilesSize: 20000000
  };
  count: number=1;
  marketName: any;
  checkpointNames: any=[];
  enableDropsown: boolean=false;
  placeName: any;


  constructor(
    private campaign:CampaignSummaryService,
    private translate:TranslateService,
    public http: HttpClient,
    public rd: Renderer2,
    public el: ElementRef,
    public event: EventService,
    public _http: HttpService,
    private ng4FilesService: Ng4FilesService,
    private location: Location,
    public pedUtils: CreateSurveyUtilsService,
    public api: ApiService,
    public pedestrainAlertsService: PedestrainAlertsService,
    public traslate: TranslationService,
    public traslateService: TranslateService,
    private apiService: ApiService,
    private router:Router
  ) {
    

    // this._http.pullCountry().subscribe(res => { }, err => { });
  }
  textControl = new FormControl();
  textControl1 = new FormControl();
  campaignflag=false
  nameExists=false;
  name=false;
  description=false;
  buttonEnabled=false;
  ngOnInit() {
    this.placeName=this.translate.instant('Select compaign');
    console.log('this.createMissionForm=',this.createMissionForm)
    this.textControl1.valueChanges.pipe(
      ).subscribe((res)=>{
        res=res.trim();
           if(res !== ''){
             this.description=true
           } else {
             this.description=false
           }
           if(this.name && this.marketZoneSelected && this.description ){
               this.buttonEnabled=true;
           } else {
             this.buttonEnabled=false;
           }
      });
    this.textControl.valueChanges.pipe(
    ).subscribe((res)=>{
      res=res.trim();
      if(res !== ''){
        this.name=true
      } else {
        this.name=false
      }
      if(this.name && this.description && this.marketZoneSelected ){
        this.buttonEnabled=true;
    } else {
      this.buttonEnabled=false;
    }
    if(res!==''){
      this.api.getMissionName(res).subscribe((res)=>{
          
          this.nameExists=false;
          this.name=true
      },(error)=>{
    
          this.nameExists=true;
          this.name=false
      
        
      })
    }
    });
  
    // Variable initialization */
    
  
    this.getMarketZone();
    this.getMissionNameToSkip();
    this.getPedestrianMissions();
    this.getPedestrianCircuits();
    this.shifts = UTILS.getShiftMocks();
    /* Variable initialization */
    this.ng4FilesService.addConfig(this.testConfig, 'my-image-config');
    this.step1 = true;
    this.prev = 1;
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this.getCampaigns();
    /* this.getAllFieldAgents(() => {
    }); */
    this.getExistingCicuits();
    this.getMissions(() => {
      this.getCircuits(() => {
        this.circuitsLoaded = true;
      });
      this.missionsLoaded = true;
      this.event.hideLoader({});
    });
    this.getMissionTypes();
  }
  goto(){
    
    this.router.navigate(['/supervisor/missions'])
  }

  getMissionNameToSkip() {
    const missionName = localStorage.getItem('missonNameExist');
    if(missionName !=null) {
      this.showSkipInStep1 = true;
    } 
  }



  /**
   * to get the getPedestrianMissions details
   * @memberof PedestrianFlowComponent
   */
  getPedestrianMissions() {
    this.apiService.getPedestrianMissions().subscribe(res => {
      console.log(res);
    })
  }


  /**
   * getPedestrianCircuits function
   * @memberof PedestrianFlowComponent
   */
  getPedestrianCircuits(){
    this.apiService.getPedestrianCircuits().subscribe(res => {
      console.log(res);
    })
  }

  getMissionDates() {
    const date = new Date(Date.now());
    const month = date.getMonth() + 1;
    localStorage.removeItem('busyDates');
    this.busyDates=[]
    this.api.getShiftWiseUsedMissionDates(date.getFullYear() + '-' +
      + month + '-' + date.getDate(), missionTypes.PEDESTRIAN_FLOW_SURVEY_TYPE_ID,this.morning?1:2).subscribe(res => {
        let busyDatesLen = res.dateDto.length;
        res.dateDto.forEach(resdate => {
          resdate.day = parseInt(resdate.day, 10);
          resdate.month = parseInt(resdate.month, 10);
          resdate.year = parseInt(resdate.year, 10);
          this.busyDates.push(resdate);
          busyDatesLen--;
          if (busyDatesLen === 0) {
            localStorage.setItem('busyDates', JSON.stringify(this.busyDates));
            this.calendarReady = true;
          }
        });
      }, err => {
        this.calendarReady = true;
      });
  }

  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6;
  }
  // can be isolated
  streetChecker(val) {
    this.mission.checkpoints[val].adrnLoaded = false;
    this.mission.checkpoints[val].data.adptid = null;
  }

  isDisabled(date: NgbDateStruct, current: { month: number }) {
    if( localStorage.getItem('campaignFlag')==='false'){
      console.log("return false");
      
      return false
    } else{
      const now = new Date(Date.now());
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
      const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
      const busyDates = JSON.parse(localStorage.getItem('busyDates'));
      const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
      const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
      const sdate = new Date(date.year, date.month - 1, date.day);
  
      if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
        if (busyDates !== null) {
          let found = -1;
          const dateFinder = (dateObj) => {
            const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
            if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
              inDate.getDate() === sdate.getDate()) {
              return true;
            } else {
              return false;
            }
          };
  
          found = busyDates.findIndex(dateFinder);
          if (found !== -1) {
            return true;
          } else {
            return false;
          }
        } else {
          return false;
        }
      } else {
        return true;
      }
    }
   
  }
  // can be isolated
  selectedItem(e, index) {
    this.mission.checkpoints[index].selected_street.adt_street = e.item;
    this.mission.checkpoints[index].adrnLoaded = false;
    this.mission.checkpoints[index].data.adptid = null;
    this.getAdrns(index, () => {
      this.getAdptId(index, () => {
      });
    });
  }
  // can be isolated
  isEndDisabled(date: NgbDateStruct, current: { month: number }) {
    const localDate = JSON.parse(localStorage.getItem('date'));
    const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    const busyDates = JSON.parse(localStorage.getItem('busyDates'));
    const minDate = new Date(localDate.year, localDate.month, localDate.day);
    const campaignStartDate = new Date(startCheck.year, startCheck.month, startCheck.day);
    const campaignEndDate = new Date(endCheck.year, endCheck.month, endCheck.day);
    const sdate = new Date(date.year, date.month, date.day);

    if (sdate >= minDate && sdate >= campaignStartDate && sdate <= campaignEndDate) {
      if (busyDates !== null) {
        let found = -1;
        const dateFinder = (dateObj) => {
          const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
          if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
            inDate.getDate() === sdate.getDate()) {
            return true;
          } else {
            return false;
          }
        };

        found = busyDates.findIndex(dateFinder);
        if (found !== -1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  public filesSelect(selectedFiles: Ng4FilesSelected, i): void {
    if (selectedFiles.status !== Ng4FilesStatus.STATUS_SUCCESS) {
      this.selectedFiles = selectedFiles.status;
      if (this.selectedFiles === 2) {
        this.pedestrainAlertsService.fileSizeShouldNotMT20MB();
      } else if (this.selectedFiles === 4) {
        this.pedestrainAlertsService.fileExtensionAlert();
      }
      return;
    }

    if (selectedFiles.files && selectedFiles.files[0]) {
      const reader = new FileReader();
      this.mission.circuits[i].data.imageUploaded = false;
      this.mission.circuits[i].data.uploadProgress = true;
      for (let j = 0; j <= 100; j++) {
        setTimeout(() => {
          this.mission.circuits[i].data.progress = j;
          if (j === 100) {
            reader.onload = (e: any) => {
              this.mission.circuits[i].data.imageUploaded = true;
              this.mission.circuits[i].data.image = selectedFiles.files[0];
              const str = '#img' + i;
              $(str).attr('src', e.target.result);
            };
            reader.readAsDataURL(selectedFiles.files[0]);
          }
        }, 100);
      }

    }

    this.selectedFiles = Array.from(selectedFiles.files).map(file => file.name);
  }

  ngAfterViewInit() {

    $('app-pedestrian-flow').on('click', (e) => {
      setTimeout(() => {
        if (this.existingCircuitsCheck) {
          // console.log(e);
          // console.log($('#dontHideDD'));
          if (e.target.className === 'nav-link mission-dd open-dd' || e.target.id === 'openDD') {
            if (!e.target.parentNode.className.includes('show')) {
              this.parent2Toggle = this.circuitsDropdown.nativeElement;
              this.classAdder();
            } else if (e.target.parentNode.className.includes('show')) {
              this.parent2Toggle = this.circuitsDropdown.nativeElement;
              this.classRemover();
            }
          } else if (e.target.id === 'searchCircuitName' || e.target.id === 'dontHideDD1' || e.target.id === 'dontHideDD2' || e.target.id === 'dontHideDD3' || e.target.id === 'dontHideDD4') {

          } else {
            this.parent2Toggle = this.circuitsDropdown.nativeElement;
            this.classRemover();
          }
        }
      }, 100);
    });

    // this.event.currentMessage.subscribe(message => {
    //   if (message && message.eventName !== 'default') {
    //     if (message.eventName === 'existing-circuit-dd-clicked') {
    //       setTimeout(() => {
    //         this.parent2Toggle = this.circuitsDropdown.nativeElement;
    //         this.rd.listen(this.circuitsDropdown.nativeElement, 'click', () => {
    //           if (this.parent2Toggle.parentNode.classList[1] === 'show') {
    //             this.classRemover();
    //           } else {
    //             this.classAdder();
    //           }
    //         });
    //       }, 500);
    //     }
    //   }
    // });

    this.event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'newAssignment') {
          $('.ng2-tag-input__text-input').css('display', 'none');
          $('.ng2-tag-input').css('border-bottom', '0');

          $('.click2Scroll').click(function () {
            $('.wrap-textarea').scrollTop($('.wrap-textarea')[0].scrollHeight);
          });
        } else if (message.eventName === 'existing-circuit-dropdown-clicked') {
          // document.getElementById('searchCircuitName').focus();
          $('#searchCircuitName').focus();
        }
      }
    });

    this.event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'mapLoaded') {
          $('.mapboxgl-canvas').css('width', '100%');
          $('.mapboxgl-canvas').css('height', '100%');
        }
      }
    });

  }

  classRemover() {
    this.rd.removeClass(this.parent2Toggle.parentNode, 'show');
  }

  classAdder() {
    this.rd.addClass(this.parent2Toggle.parentNode, 'show');
  }

  getExistingCicuits() {
    this.api.getAllCircuitsWithCheckpoints(true).subscribe(res => {
      let existingCircuitsLength = res.data.circuits.length;
      res.data.circuits.forEach(circuit => {
        this.existingCircuits.push(circuit);
        existingCircuitsLength--;
        if (existingCircuitsLength === 0) {
          this.existingCircuitsFound = true;
        }
      });
    }, err => {
      this.existingCircuitsFound = false;
    });

    this.api.getAllCircuitsWithCheckpoints(false).subscribe(res => {
      if (res.data.circuits.length !== null) {
        res.data.circuits.forEach(circuit => {
          this.noCheckpointCircuits.push(circuit);
        });
      }
    }, err => {
      console.log('err', err);
    });

  }

  onMapLoad(map) { // Create flow map initializer can go in utility methods
    this.event.broadcast({ eventName: 'mapLoaded', data: '' });
    if (this.prev === 2) {
      console.log('here hyu',this.mission);
      this.mission.circuits.forEach(circuit => {
        if (!('map' in circuit)) {
          circuit.map = map;
        }
        const feature1 = {
          'type': 'Feature',
          'geometry': { 'type': 'Point', 'coordinates': circuit.data.lnglat },
          'lnglat': circuit.data.lnglat,
          'checkpointName': ''
          
        };                  
        // this.mission.circuits[index].data['lng'].push(feature1);
        circuit.checkpointsGeoJson['features'].push(feature1);
      });
      console.log(this.mission.circuits); 

    } else if (this.prev === 3) {
      console.log('why are yiu',this.mission.circuits[0].data.lnglat); 
      this.checkpointMap = map;
      if (this.existingCircuitsCheck) {

        this.checkpointMap.flyTo({
          center: [this.mission.checkpoints[0].data.lnglat[0],
            this.mission.checkpoints[0].data.lnglat[1]],
          zoom: 9,
          bearing: 0,
          curve: 1,
          color:'purple'
        });
      }
      setTimeout(() => {
        this.checkpointMap.resize();
      }, 500);
    }else{
      this.checkpointMap = map;
      if (this.existingCircuitsCheck) {

        this.checkpointMap.flyTo({
          center: [this.mission.checkpoints[0].data.lnglat[0],
          this.mission.checkpoints[0].data.lnglat[1]],
          zoom: 9,
          bearing: 0,
          curve: 1,
          color: 'purple'
        });
      }
      setTimeout(() => {
        this.checkpointMap.resize();
      }, 500);
      // console.log(this.assignments);
      // this.assignments.forEach(circuit => {
      //   if (!('map' in circuit)) {
      //     circuit.map = map;
      //   }
      // });
      console.log(this.assignments);
    }
  }

  changeLocalDate(date) {
    this.mission.missionEndDate = {
      year: null,
      month: null,
      day: null
    };
    localStorage.setItem('date', JSON.stringify(date));
    this.minEndDate = date;
  }
  startDate;
  dateSelected=false;
  getDate(d1) {
    var g1 = new Date();
    let endDateCheck = JSON.parse(localStorage.getItem('campaignEndDate'));

    var endDateCheck1 = new Date(`${endDateCheck.year}-${endDateCheck.month}-${endDateCheck.day}`)
    let startDateCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
    var startDateCheck1 = new Date(`${startDateCheck.year}-${startDateCheck.month}-${startDateCheck.day}`)


    // (YYYY-MM-DD) 
    var CurrentDate = new Date()
    var d = new Date();
    // var d = new Date(CurrentDate),
    let dateToday = {
      month: '' + (d.getMonth() + 1),
      day: '' + d.getDate(),
      year: d.getFullYear()
    }


    if (dateToday.month.length < 2)
      dateToday.month = '0' + dateToday.month;
    if (dateToday.day.length < 2)
      dateToday.day = '0' + dateToday.day;
    var today = `${dateToday.year}-${dateToday.month}-${dateToday.day}`


    // var g2 = new Date(`${d1.year}-${d1.month}-${d1.day}`); 
    // console.log("d1.day=", d1.day, g1.getMonth(), this.minDate, this.minDate.day === d1.day);
    var GivenDate = new Date(`${d1.year}-${d1.month}-${d1.day}`);
    const month1 = String(d1.month).padStart(2, "0");
    const day1 = String(d1.day).padStart(2, "0");
    var todayDate = `${d1.year}-${month1}-${day1}`
    // console.log("checkdate", startDateCheck);
    // console.log((GivenDate > endDateCheck), (GivenDate < startDateCheck));


    if (this.campaignflag) {
      if ((!(GivenDate > endDateCheck1) && !(GivenDate < startDateCheck1)) || (GivenDate == startDateCheck1)) {
        if (GivenDate >= CurrentDate || (today === todayDate)) {


          // if (d1.day >= this.minDate.day ) {
          // this.dateSelected=true;
          this.dateSelected = true;
          this.mission.missionStartDate = {
            year: d1.year,
            month: d1.month,
            day: d1.day
          }
          // console.log("mision startdate=", this.mission.missionStartDate);

          localStorage.setItem('date', JSON.stringify(d1));


          this.startDate = `${d1.year}-${d1.month}-${d1.day}`
          const endDate = '2020-10-12 ' + '23:59:00'
          const startDate = '2020-10-12 ' + '00:00:00'
          this._http.SecureGet('/ref/getDatesInRange?startDate=' + startDate + '&endDate=' + endDate).subscribe(res => {
            console.log("res field agents=", res);

          }, err => {
          });
          this.getAllFieldAgents();
        }
      }
    } else {
      if (GivenDate >= CurrentDate || (today === todayDate)) {


        // if (d1.day >= this.minDate.day ) {
        // this.dateSelected=true;
        this.dateSelected = true;
        this.mission.missionStartDate = {
          year: d1.year,
          month: d1.month,
          day: d1.day
        }
        console.log("mision startdate=", this.mission.missionStartDate);

        localStorage.setItem('date', JSON.stringify(d1));

        console.log("date selected...!!!");
        this.startDate = `${d1.year}-${d1.month}-${d1.day}`
        const endDate = '2020-10-12 ' + '23:59:00'
        const startDate = '2020-10-12 ' + '00:00:00'
        this._http.SecureGet('/ref/getDatesInRange?startDate=' + startDate + '&endDate=' + endDate).subscribe(res => {
          console.log("res field agents=", res);

        }, err => {
        });
        this.getAllFieldAgents();
      }
    }


  }

  /* *******************************  GETTERS  ***************************************
  getCampaigns()
  getMissionTypes()
  getMissions(cb)
  getAllShifts(cb)
  getAllFieldAgents(cb)
  getCircuits(cb)
  getLatLong(search, index, page)
  */
  getMissionType(missionTypeName) { return (missionTypeName == "Pedestrian Flow Survey") ? 'Pedestrian Flow' : missionTypeName; }
  getCampaigns() {
    this.campaignsLoaded = false;
    this.api.getUserCampaigns(this.user.userId).subscribe(res => {

      this.pedUtils.campaignsInitializer(res.data.campaigns, response => {

        if (response.message === 'campaignExpired') {
          this.pedestrainAlertsService.campaignExpiredAlert()
            .then(() => { this.location.back(); }).catch(() => { this.location.back(); });
        } else if (response.message === 'success') {
          const data= res.data;
          // this.campaigns=[data.campaigns[1]]; 
          const today = new Date();
          const todaydate = new Date(
            today.getFullYear(),
            today.getMonth(),
            today.getDate()
          );
          if (this.campaign.selectedCampaign === undefined) {
            // this.mission.selectedCampaign=data.campaigns[1];
            data.campaigns.forEach(element => {
              if (element.campaignId !== this.mission.selectedCampaign['campaignId']) {

                data.campaigns.forEach(element => {
                  const campaignEndDate = new Date(element.campaignEndDate)

                  if (!(campaignEndDate < todaydate)) {

                    // this.mission.selectedCampaign = element;

                  }
                })

                const campaignEndDate = new Date(element.campaignEndDate)


                if (!(campaignEndDate < todaydate))
                  this.campaigns.push(element)
              }
            });

          } else {

            let campaignEndDate = new Date(this.campaign.selectedCampaign.campaignEndDate)
            if (campaignEndDate < today) {

              data.campaigns.forEach(element => {

                if (campaignEndDate < todaydate) {

                  // this.mission.selectedCampaign = element;

                }
              })
            } else {
              // this.mission.selectedCampaign=this.campaign.selectedCampaign

            }



            data.campaigns.forEach(element => {
              if (element.campaignId !== this.mission.selectedCampaign['campaignId']) {
                campaignEndDate = new Date(element.campaignEndDate)

                if (!(campaignEndDate < todaydate)) {
                  this.campaigns.push(element)

                }
              }
            });
          }
          
         

          
          // this.campaigns = response.campaigns;
          // this.mission.selectedCampaign = this.campaigns[0];
          // localStorage.setItem('campaignStartDate', JSON.stringify(this.mission.selectedCampaign.startDateObj));
          // localStorage.setItem('campaignEndDate', JSON.stringify(this.mission.selectedCampaign.endDateObj));
          // this.campaigns.splice(0, 1);
          this.campaignsLoaded = true;
        }
      });
    }, err => {
    });
  }
  marketZone;
  getMarketZone(){
    this.api.getMarketZone(this.user.userId).subscribe(res=>{
      console.log('response=',res);
      this.marketZone=res.data;

    })
  }
  selectedMarketZoneValue=this.translate.instant('Select market zone');

  selectedMarketZone(id,name){
    this.marketZoneSelected=true;
    if(this.market && this.name && this.description){
      this.buttonEnabled=true;

    }
    this.marketid=id;
    this.selectedMarketZoneValue=name;
    this.api.getLocationDetails({'locationName':this.selectedMarketZoneValue,'locationType':2}).subscribe(res => {
      let market=res.data;
      this.mission.markets.push({
        longitude: market.longitude,
        latitude: market.latitude
      });
      // this.mapObject.push({ 'longitude': this.mission.markets[0].longitude, 'latitude': this.mission.markets[0].latitude});
      // console.log('markets selected',this.mission.markets);
    });
    console.log("selectedMarketZoneValue=",this.mission);
  }

  getMissionTypes() {
    this.missionTypesLoaded = false;
    this.missionTypes = [];

    this.api.getMissionTypes().subscribe(res => {
      let typeLen = res.data.length;
      res.data.forEach(type => {
        if (type.id === 3 || type.id === 4) {
          this.missionTypes.push(type);
        }
        typeLen--;
        if (typeLen === 0) {
          this.selectedMissionType = this.missionTypes[0];
          this.missionTypes.splice(0, 1);
          this.missionTypesLoaded = true;
        }
      });
    }, err => {
      console.log('err', err);
    });
  }

  getMissions(cb) {
    this.api.getMissionsCreatedByOfMissionType(this.user.userId, missionTypes.PEDESTRIAN_FLOW_SURVEY_TYPE_ID).subscribe(res => {
      this.tempmissions = res.data.missions;
      this.pedUtils.pedSkipCalc(res.data.missions, this.prev, this.step2Completed, response => {
        if (response.message === 'success') {
          this.missions = response.data;
          // s.showSkipInStep1 = response.skip1;
          cb();
        } else if (response.message === 'open') {
          this.missions = response.data;
          this.open(response.page);
        } else if (response.message === 'skip') {
          this.missions = response.data;
          this.skip(response.page);
        } else if (response.message === 'missionsNotLoaded') {
          this.missionsLoaded = false;
          this.event.hideLoader({});
        }
      });
    }, err => {
      this.missionsLoaded = false;
      this.event.hideLoader({});
    })


  }

  getAllShifts(cb) {
    /* this._http.Get("/ref/getAllShifts").subscribe(res => {
      console.log("response", res);
      cb();
    }, err => {
      console.log("error", err);
      cb();
    }); */
    cb();
  }
  firstAgent;
  getAllFieldAgents() {
    const month = this.today.getMonth() + 1;
    const today = this.today.getFullYear() + '-' + month + '-' + this.today.getDate();
    console.log("start date=",this.startDate);
    
    this.api.getUnassignedUsers({
      startDate:this.startDate?this.startDate: this.currentDate,
      missionId: this.mission.checkpoints[0].selectedMission.missionId,
      shift:this.morning?1:2
    }).subscribe(res => {
      console.log("all field agents=",res);
      this.firstAgent=res.users[0]
      console.log("firstagent==",this.firstAgent);
      
      this.fieldUsers=res.users
      this.fieldAgents = [];
      let len = res.users.length;
      // if (res.users.length >= 2) {
      //   res.users.forEach(fa => {
      //     if (!fa.resetPassword && fa.isActive) {
      //       this.fieldAgents.push(fa);
      //     }
      //     len--;
      //     if (len === 0) {
      //       cb();
      //     }
      //   });
      // } else {
      //   this.pedestrainAlertsService.agentsNotFree()
      //     .then(() => { this.location.back(); }).catch(() => { this.location.back(); });
      // }
    }, err => {
      this.pedestrainAlertsService.agentsNotFree()
        .then(() => { 
          this.assignments=this.assignments2
        console.log("mission assi=",this.assignments);
        this.dateSelected=false;
        this.fieldUsers=[]
        this.selectedAgent=undefined
        this.enableSave=false;
        }).catch(() => {
          this.assignments=this.assignments2
        console.log("mission assi=",this.assignments);
        this.dateSelected=false;
        this.fieldUsers=[]
        this.selectedAgent=undefined
        this.enableSave=false;


        });
    });
  }

  getCircuits(cb) {
    // this.circuitsLoaded = false;
    if (this.step2Completed) {
      this._http.SecureGet('/ref/getAllMissions?id=' + this.mission.circuits[0].selectedMission.missionId).subscribe(res => {
        this.circuits = res.data.missions[0].missionCircuits;
        cb();
      }, err => {
      });
    } else {
      if (this.prev === 3) {
        let len = this.missions.length;
        const circuits = [];
        this.missions.forEach(mission => {
          if (mission.missionCircuits.length > 0) {
            mission.missionCircuits.forEach(circuit => {
              if (mission.missionType.id === 3) {
                if (circuit.circuitCheckpoints.length < 3) {
                  if (!circuits.includes(circuit)) {
                    circuits.push(circuit);
                  }
                }
              } else {
                if (!circuits.includes(circuit)) {
                  circuits.push(circuit);
                }
              }
            });
          }
          len--;
          if (len === 0) {
            this.circuits = circuits;
            cb();
          }
        });
      } else {
        let len = this.missions.length;
        const circuits = [];
        this.missions.forEach(mission => {
          if (mission.missionCircuits.length > 0) {
            mission.missionCircuits.forEach(circuit => {
              if (circuits === undefined) {
                circuits.push(circuit);
              } else {
                if (!circuits.includes(circuit)) {
                  circuits.push(circuit);
                }
              }
            });
          }
          len--;
          if (len === 0) {
            this.circuits = circuits;
            cb();
          }
        });
      }
    }
  }

  getLatLong(search, index, page) {
    const api = new google.maps.Geocoder;
    api.geocode({ address: search }, (data: any) => {
      if (data.length !== 0) {
        let delInd;
        if (page === 2) {
          console.log('mission',this.mission);
          const found = Object.assign([], this.mission.circuits[index].tempExistingCircuits).filter((extCir) => {
            const c1 = extCir.circuitName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
            const c2 = search.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
            return c1.toLowerCase() === c2.toLowerCase();
          });
          if (found.length !== 0) {
            console.log('here');
            this.pedestrainAlertsService.circuitAlreadyexistWithSameName().then(() => {
              let deleteIndex;
              let extCirLen = this.mission.circuits[index].existingCircuits.length;
              const extCirLen2 = this.mission.circuits[index].existingCircuits.length;
              let foundCircuit = {};
              if (extCirLen2 === 0) {
                this.existingCircuitsCheckpoitFiller(index);
              } else {
                const c3 = this.mission.circuits[index].selectedExistingCircuit.circuitName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                const c4 = search.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                if (c3.toLowerCase() === c4.toLowerCase()) {
                  this.existingCircuitsCheckpoitFiller(index);
                } else {
                  this.mission.circuits[index].existingCircuits.forEach((extCir, i) => {
                    const c7 = extCir.circuitName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                    const c8 = search.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
                    if (c7.toLowerCase() === c8.toLowerCase()) {
                      deleteIndex = i;
                      foundCircuit = extCir;
                    }
                    extCirLen--;
                    if (extCirLen === 0) {
                      this.mission.circuits[index].existingCircuits.push(this.mission.circuits[index].selectedExistingCircuit);
                      this.mission.circuits[index].selectedExistingCircuit = foundCircuit;
                      this.mission.circuits[index].existingCircuits.splice(deleteIndex, 1);
                      this.existingCircuitsCheckpoitFiller(index);
                    }
                  });
                }
              }
            }).catch(() => {
              this.mission.circuits[index].data.search = '';
              this.mission.circuits[index].data.circuitName = '';
            });
          } else {
            console.log('hi');
            if (this.noCheckpointCircuits.length !== 0) {
              console.log('eashj');
              const foundno = Object.assign([], this.noCheckpointCircuits).filter(extCir => {
                return extCir.circuitName === search;
              });
              if (foundno.length !== 0) {
                this.pedestrainAlertsService.nosubordinateCheckpoints().then(() => {
                  this.mission.circuits[index].data.search = '';
                  this.mission.circuits[index].data.circuitName = '';
                }).catch(() => {
                  this.mission.circuits[index].data.search = '';
                  this.mission.circuits[index].data.circuitName = '';
                });
              } else {

                if (this.market) {
                  this.mission.circuits[index].checkpointsGeoJson['features']=[];
                  this.circuitNameDisabled = false;
                  this.mission.circuits[index].data.circuitName = search;
                  this.mission.circuits[index].data.lnglat=[data[0].geometry.location.lng(), data[0].geometry.location.lat()];
                  
                  this._http.SecureGet('/ref/getAllMissions?id=' + this.missionId).subscribe(res => {
                    const feature1 = {
                      'type': 'Feature',
                      'geometry': { 'type': 'Point', 'coordinates': [res.data.missions[0].missionMarketZoneList[0].longitude, res.data.missions[0].missionMarketZoneList[0].latitude] },
                      'lnglat': [res.data.missions[0].missionMarketZoneList[0].longitude, res.data.missions[0].missionMarketZoneList[0].latitude],
                      'checkpointName': res.data.missions[0].missionMarketZoneList[0].officialName,
                      'fillColor': 'purple',
                      'existingCircuit': 'true',
                      'isSearch': 'false',
                    };
                    this.mission.circuits[index].checkpointsGeoJson['features'].push(feature1);
                  });
                  // const feature1 = {
                  //   'type': 'Feature',
                  //   'geometry': { 'type': 'Point', 'coordinates': [this.mission.markets[0].longitude, this.mission.markets[0].latitude] },
                  //   'lnglat': [this.mission.markets[0].longitude, this.mission.markets[0].latitude],
                  //   'checkpointName': 'Market Zone',
                  //   'fillColor':'purple',
                  //   'existingCircuit': 'true'
                  // };                  
                  // // this.mission.circuits[index].data['lng'].push(feature1);
                  // this.mission.circuits[index].checkpointsGeoJson['features'].push(feature1);

                  const feature = {
                    'type': 'Feature',
                    'geometry': { 'type': 'Point', 'coordinates': [data[0].geometry.location.lng(), data[0].geometry.location.lat()] },
                    'lnglat': [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                    'checkpointName': '',
                    'fillColor':'blue',
                    'isSearch':'true',
                    //'existingCircuit': 'true'
                  };
                  // this.mission.circuits[index].data['lng'].push(feature);
                  this.mission.circuits[index].checkpointsGeoJson['features'].push(feature);
                  this.mission.circuits[index].map.flyTo({
                    center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                    // center: this.mission.circuits[index].data.lnglat,
                    zoom: 9,
                    bearing: 0,
                    curve: 1
                  });                
                }
                else {
                  this.mission.circuits[index].checkpointsGeoJson['features']=[];
                  console.log('why');
                  this.circuitNameDisabled = false;                 
                  this.mission.circuits[index].data.circuitName = search;
                  this.mission.circuits[index].data.lnglat = [data[0].geometry.location.lng(), data[0].geometry.location.lat()];
                  console.log('raksa');
                  const feature = {
                    'type': 'Feature',
                    'geometry': { 'type': 'Point', 'coordinates': [data[0].geometry.location.lng(), data[0].geometry.location.lat()] },
                    'lnglat': [data[0].geometry.location.lng(), data[0].geometry.location.lat()]
                  };
                  this.mission.circuits[index].checkpointsGeoJson['features'].push(feature);
                  this.mission.circuits[index].map.flyTo({
                    center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                    zoom: 9,
                    bearing: 0,
                    curve: 1
                  });
                }
              }
            } else {
              console.log('hiiiiiiiiii');
              if (this.market) {

                this.circuitNameDisabled = false;
                this.mission.circuits[index].data.circuitName = search;
                this.mission.circuits[index].data.lnglat=([data[0].geometry.location.lng(), data[0].geometry.location.lat()]);
                console.log(this.mission.circuits[index].data.lnglat);
                this.mission.circuits[index].map.flyTo({
                  center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                  // center: this.mission.circuits[index].data.lnglat,
                  zoom: 9,
                  bearing: 0,
                  curve: 1
                });
              }
              else {
                this.circuitNameDisabled = false;
                this.mission.circuits[index].data.circuitName = search;
                this.mission.circuits[index].data.lnglat = [data[0].geometry.location.lng(), data[0].geometry.location.lat()];
                this.mission.circuits[index].map.flyTo({
                  center: [data[0].geometry.location.lng(), data[0].geometry.location.lat()],
                  zoom: 9,
                  bearing: 0,
                  curve: 1
                });
              }
              // this.myCircle1.setCenter({ lat: parseFloat(this.mission.markets[0].longitude), lng: parseFloat(this.mission.markets[0].longitude) }).setRadius(150).addTo( this.mission.circuits[index].map);
            }
          }
        }
      } else {
        //this.pedestrainAlertsService.googleGeocoderError(); 
        this.pedestrainAlertsService.enterValidLocation();    // Issue 920 resolved
      }
    }, error => {

    });
  }

  currentDate=new Date(Date.now());
  getDatesForAssignment(cb) {
    // const startDate = this.mission.checkpoints[0].selectedMission.missionStartDate;
    // const endDate = this.mission.checkpoints[0].selectedMission.missionEndDate.split(' ')[0] + ' 23:59:59';
    const endDate='2020-10-12 '+'23:59:59'
    const startDate='2020-10-12 '+'00:00:00'
    this._http.SecureGet('/ref/getDatesInRange?startDate=' + startDate + '&endDate=' + endDate).subscribe(res => {
      cb(res.data.stringList);
    }, err => {
    });
  }

  /* ********************************  TOGGLERS  *************************************
    toggleCampaign(camp)
    toggleMissionType(mType)
    circuitMissionToggler(mission)
    toggleMission(mission, i)
    checkpointMissionToggler(mission)
    toggleCheckpointMission(mission, i)
    toggleCircuit(circuit, i)
    toggleShift(shift, i)
    toggleFieldAgent(fa, i)
    toggleCheckpoint(checkpoint, i)
    toggleCheckBox(i)
    toggleExistingCircuit(circuit, circuitIndex)
  */
  useExisting=false
  toggleCheckBox(i, event) {
    if(event.target.checked){
      this.useExisting=true;
    }else {
      this.useExisting=false;
    }
    if (event.target.checked !== this.mission.circuits[i].existingCircuitsCheck) {
      this.mission.circuits[i].existingCircuitsCheck = event.target.checked;
    }
    if (this.mission.circuits[i].existingCircuitsCheck) {
      this.existingCircuitsCheckpoitFiller(i);
    } else {
      if (this.market) {
        this.mission.circuits[i].checkpointsGeoJson['features']=[];
        console.log(this.mission.circuits[i].data.lnglat);
        // this.mission.circuits[i].data.lnglat=[this.mission.markets[0].longitude, this.mission.markets[0].latitude];
        // console.log(this.mission.circuits[i].data.lnglat);
        this._http.SecureGet('/ref/getAllMissions?id=' + this.missionId).subscribe(res => {
          const feature1 = {
            'type': 'Feature',
            'geometry': { 'type': 'Point', 'coordinates': [res.data.missions[0].missionMarketZoneList[0].longitude, res.data.missions[0].missionMarketZoneList[0].latitude] },
            'lnglat': [res.data.missions[0].missionMarketZoneList[0].longitude, res.data.missions[0].missionMarketZoneList[0].latitude],
            'checkpointName': res.data.missions[0].missionMarketZoneList[0].officialName,
            'fillColor': 'purple',
            'isSearch': 'false'
          };
        
          this.mission.circuits[i].checkpointsGeoJson['features'].push(feature1);
        });  
        const feature = {
          'type': 'Feature',
          'geometry': { 'type': 'Point', 'coordinates': [this.mission.circuits[i].data.lnglat[0],this.mission.circuits[i].data.lnglat[1]] },
          'lnglat': [this.mission.circuits[i].data.lnglat[0],this.mission.circuits[i].data.lnglat[1]],
          'checkpointName': '',
          'fillColor':'purple'
  
        };
        // this.mission.circuits[i].checkpointsGeoJson['features'].push(feature);
        this.mission.checkpoints = [];
        this.mission.circuits[i].map.flyTo({
          center: this.mission.circuits[i].data.lnglat,
          zoom: 9,
          bearing: 0,
          curve: 1,
        });
        this.mission.circuits[i].data.circuitName = '';
        this.circuitNameDisabled = true;
        this.checkpointMapGeoJSON.features = [];
        this.geojson.features = [];
        this.existingCircuitsCheck = false;
      }
      else {
        this.mission.circuits[i].checkpointsGeoJson['features']=[];
        const feature = {
          'type': 'Feature',
          'geometry': { 'type': 'Point', 'coordinates': [this.mission.circuits[i].data.lnglat[0],this.mission.circuits[i].data.lnglat[1]] },
          'lnglat': [this.mission.circuits[i].data.lnglat[0],this.mission.circuits[i].data.lnglat[1]],
          'checkpointName': '',
          'fillColor':'purple'
  
        };
        this.mission.circuits[i].checkpointsGeoJson['features'].push(feature);
        this.mission.checkpoints = [];
        this.mission.circuits[i].map.flyTo({
          center: this.mission.circuits[i].data.lnglat,
          zoom: 9,
          bearing: 0,
          curve: 1
        });

        this.mission.circuits[i].data.circuitName = '';
        this.circuitNameDisabled = true;
        this.geojson.features = [];
        this.checkpointMapGeoJSON.features = [];
        this.existingCircuitsCheck = false;
      }
    }
  }

  toggleCountry(country, i) {
    if (i === 0 && this.mission.checkpoints.length > 1) {
      this.pedestrainAlertsService.removeOtherCheckpoints().then(() => {
        this.mission.checkpoints.splice(i + 1); // remove all others
        this.checkpointMapGeoJSON.features.splice(i + 1);
        this.mission.checkpoints[i].countries.push(this.mission.checkpoints[i].selected_country);
        this.mission.checkpoints[i].regionLoaded = false;
        this.mission.checkpoints[i].communeLoaded = false;
        this.mission.checkpoints[i].postalCodeLoaded = false;
        this.mission.checkpoints[i].streetLoaded = false;
        this.mission.checkpoints[i].adrnLoaded = false;
        this.mission.checkpoints[i].adrnLoaded = false;
        this.mission.checkpoints[i].selected_country = country;
        let deleteIndex = -1;
        let countryLen = this.mission.checkpoints[i].countries.length;
        this.showAddNewCheckpoint = true;
        this.mission.checkpoints[i].countries.forEach((con, index) => {
          if (con.con_id === country.con_id) {
            deleteIndex = index;
          }
          countryLen--;
          if (countryLen === 0) {
            this.mission.checkpoints[i].countries.splice(deleteIndex, 1);
            this.getRegions(i, () => {
              this.getCommunes(i, () => {
                this.getPostalCodes(i, () => {
                  this.getStreets(i, () => {
                    this.getAdrns(i, () => {
                      this.getAdptId(i, () => {
                      });
                    });
                  });
                });
              });
            });
          }
        });
      }).catch(() => { });
    } else {
      this.mission.checkpoints[i].countries.push(this.mission.checkpoints[i].selected_country);
      this.mission.checkpoints[i].regionLoaded = false;
      this.mission.checkpoints[i].communeLoaded = false;
      this.mission.checkpoints[i].postalCodeLoaded = false;
      this.mission.checkpoints[i].streetLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].selected_country = country;
      let deleteIndex = -1;
      let countryLen = this.mission.checkpoints[i].countries.length;
      this.mission.checkpoints[i].countries.forEach((con, index) => {
        if (con.con_id === country.con_id) {
          deleteIndex = index;
        }
        countryLen--;
        if (countryLen === 0) {
          this.mission.checkpoints[i].countries.splice(deleteIndex, 1);
          this.getRegions(i, () => {
            this.getCommunes(i, () => {
              this.getPostalCodes(i, () => {
                this.getStreets(i, () => {
                  this.getAdrns(i, () => {
                    this.getAdptId(i, () => {
                    });
                  });
                });
              });
            });
          });
        }
      });
    }
  }

  toggleRegion(region, i) {
    if (i === 0 && this.mission.checkpoints.length > 1) {
      this.pedestrainAlertsService.removeOtherCheckpoints()
        .then(() => {
          this.mission.checkpoints.splice(i + 1);
          this.checkpointMapGeoJSON.features.splice(i + 1);
          this.mission.checkpoints[i].communeLoaded = false;
          this.mission.checkpoints[i].postalCodeLoaded = false;
          this.mission.checkpoints[i].streetLoaded = false;
          this.mission.checkpoints[i].adrnLoaded = false;
          this.mission.checkpoints[i].adrnLoaded = false;
          this.mission.checkpoints[i].regions.push(this.mission.checkpoints[i].selected_region);
          this.mission.checkpoints[i].selected_region = region;
          let deleteIndex = -1;
          let regionLen = this.mission.checkpoints[i].regions.length;
          this.showAddNewCheckpoint = true;
          this.mission.checkpoints[i].regions.forEach((reg, index) => {
            if (reg.reg_id === region.reg_id) {
              deleteIndex = index;
            }
            regionLen--;
            if (regionLen === 0) {
              this.mission.checkpoints[i].regions.splice(deleteIndex, 1);
              this.getCommunes(i, () => {
                this.getPostalCodes(i, () => {
                  this.getStreets(i, () => {
                    this.getAdrns(i, () => {
                      this.getAdptId(i, () => {
                      });
                    });
                  });
                });
              });

            }
          });
        }).catch(() => { });
    } else {
      this.mission.checkpoints[i].communeLoaded = false;
      this.mission.checkpoints[i].postalCodeLoaded = false;
      this.mission.checkpoints[i].streetLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].regions.push(this.mission.checkpoints[i].selected_region);
      this.mission.checkpoints[i].selected_region = region;
      let deleteIndex = -1;
      let regionLen = this.mission.checkpoints[i].regions.length;
      this.mission.checkpoints[i].regions.forEach((reg, index) => {
        if (reg.reg_id === region.reg_id) {
          deleteIndex = index;
        }
        regionLen--;
        if (regionLen === 0) {
          this.mission.checkpoints[i].regions.splice(deleteIndex, 1);
          this.getCommunes(i, () => {
            this.getPostalCodes(i, () => {
              this.getStreets(i, () => {
                this.getAdrns(i, () => {
                  this.getAdptId(i, () => {
                  });
                });
              });
            });
          });

        }
      })
    }

  }

  toggleCommune(commune, i) {
    if (i === 0 && this.mission.checkpoints.length > 1) {
      this.pedestrainAlertsService.removeOtherCheckpoints().then(() => {
        this.mission.checkpoints.splice(i + 1);
        this.checkpointMapGeoJSON.features.splice(i + 1);
        this.mission.checkpoints[i].postalCodeLoaded = false;
        this.mission.checkpoints[i].streetLoaded = false;
        this.mission.checkpoints[i].adrnLoaded = false;
        this.mission.checkpoints[i].adrnLoaded = false;
        this.mission.checkpoints[i].communes.push(this.mission.checkpoints[i].selected_commune);
        this.mission.checkpoints[i].selected_commune = commune;
        let deleteIndex = -1;
        let communeLen = this.mission.checkpoints[i].communes.length;
        this.showAddNewCheckpoint = true;
        this.mission.checkpoints[i].communes.forEach((com, index) => {
          if (com.com_id === commune.com_id) {
            deleteIndex = index;
          }
          communeLen--;
          if (communeLen === 0) {
            this.mission.checkpoints[i].communes.splice(deleteIndex, 1);

            this.getPostalCodes(i, () => {
              this.getStreets(i, () => {
                this.getAdrns(i, () => {
                  this.getAdptId(i, () => {
                  });
                });
              });
            });

          }
        });
      }).catch(() => { });
    } else {
      this.mission.checkpoints[i].postalCodeLoaded = false;
      this.mission.checkpoints[i].streetLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].communes.push(this.mission.checkpoints[i].selected_commune);
      this.mission.checkpoints[i].selected_commune = commune;
      let deleteIndex = -1;
      let communeLen = this.mission.checkpoints[i].communes.length;
      this.mission.checkpoints[i].communes.forEach((com, index) => {
        if (com.com_id === commune.com_id) {
          deleteIndex = index;
        }
        communeLen--;
        if (communeLen === 0) {
          this.mission.checkpoints[i].communes.splice(deleteIndex, 1);

          this.getPostalCodes(i, () => {
            this.getStreets(i, () => {
              this.getAdrns(i, () => {
                this.getAdptId(i, () => {
                });
              });
            });
          });

        }
      });
    }
  }

  togglePostalCode(postalCode, i) {
    if (i === 0 && this.mission.checkpoints.length > 1) {
      this.pedestrainAlertsService.removeOtherCheckpoints().then(() => {
        this.mission.checkpoints.splice(i + 1);
        this.checkpointMapGeoJSON.features.splice(i + 1);
        this.mission.checkpoints[i].streetLoaded = false;
        this.mission.checkpoints[i].adrnLoaded = false;
        this.mission.checkpoints[i].adrnLoaded = false;
        this.mission.checkpoints[i].postalcodes.push(this.mission.checkpoints[i].selected_postalcode);
        this.mission.checkpoints[i].selected_postalcode = postalCode;
        this.showAddNewCheckpoint = true;
        let deleteIndex = -1;
        let postalCodeLen = this.mission.checkpoints[i].postalcodes.length;
        this.mission.checkpoints[i].postalcodes.forEach((pos, index) => {
          if (pos.adt_postal_code === postalCode.adt_postal_code) {
            deleteIndex = index;
          }
          postalCodeLen--;
          if (postalCodeLen === 0) {
            this.mission.checkpoints[i].postalcodes.splice(deleteIndex, 1);

            this.getStreets(i, () => {
              this.getAdrns(i, () => {
                this.getAdptId(i, () => {
                });
              });
            });

          }
        });
      }).catch(() => { });
    } else {
      this.mission.checkpoints[i].streetLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].adrnLoaded = false;
      this.mission.checkpoints[i].postalcodes.push(this.mission.checkpoints[i].selected_postalcode);
      this.mission.checkpoints[i].selected_postalcode = postalCode;
      let deleteIndex = -1;
      let postalCodeLen = this.mission.checkpoints[i].postalcodes.length;
      this.mission.checkpoints[i].postalcodes.forEach((pos, index) => {
        if (pos.adt_postal_code === postalCode.adt_postal_code) {
          deleteIndex = index;
        }
        postalCodeLen--;
        if (postalCodeLen === 0) {
          this.mission.checkpoints[i].postalcodes.splice(deleteIndex, 1);

          this.getStreets(i, () => {
            this.getAdrns(i, () => {
              this.getAdptId(i, () => {
              });
            });
          });

        }
      });
    }
  }

  toggleStreet(street, i) {
    this.mission.checkpoints[i].adrnLoaded = false;
    this.mission.checkpoints[i].adrnLoaded = false;
    this.mission.checkpoints[i].streets.push(this.mission.checkpoints[i].selected_street);
    this.mission.checkpoints[i].selected_street = street;
    let deleteIndex = -1;
    let streetLen = this.mission.checkpoints[i].streets.length;
    this.mission.checkpoints[i].streets.forEach((str, index) => {
      if (str.adt_street === street.adt_street) {
        deleteIndex = index;
      }
      streetLen--;
      if (streetLen === 0) {
        this.mission.checkpoints[i].streets.splice(deleteIndex, 1);
        this.getAdrns(i, () => {
          this.getAdptId(i, () => {
          });
        });
      }
    });
  }

  toggleAdrn(adrn, i) {
    console.log(adrn, i);
    this.mission.checkpoints[i].adrns.push(this.mission.checkpoints[i].selected_adrn);
    this.mission.checkpoints[i].selected_adrn = adrn;
    let deleteIndex = -1;
    let adrnLen = this.mission.checkpoints[i].adrns.length;
    this.mission.checkpoints[i].adrns.forEach((ad, index) => {
      if (ad.adt_adrn === adrn.adt_adrn) {
        deleteIndex = index;
      }
      adrnLen--;
      if (adrnLen === 0) {
        this.mission.checkpoints[i].adrns.splice(deleteIndex, 1);
        this.getAdptId(i, () => {
        });
      }
    });
  }

  instanceForCampaign(d1) {
    this.datepickers.push(d1);
  }

  toggleCampaign(camp) {
    this.datepickers.forEach(datePicker => {
      datePicker.close();
    });
    this.mission.missionStartDate = {
      year: null,
      month: null,
      day: null
    };
    this.mission.missionEndDate = {
      year: null,
      month: null,
      day: null
    };
    this.mission.selectedCampaign.campaignName==this.translate.instant('Select compaign')?delete this.mission.selectedCampaign.campaignName:false;
    this.campaigns.push(this.mission.selectedCampaign);
    this.mission.selectedCampaign = camp;
    const campStart = camp.campaignStartDate.split(' ')[0];
    // localStorage.setItem('campaignStartDate', JSON.stringify({
    //   day: parseInt(campStart.split('-')[2], 10),
    //   month: parseInt(campStart.split('-')[1], 10),
    //   year: parseInt(campStart.split('-')[0], 10)
    // }));
    // const campEnd = camp.campaignEndDate.split(' ')[0];
    // localStorage.setItem('campaignEndDate', JSON.stringify({
    //   day: parseInt(campEnd.split('-')[2], 10),
    //   month: parseInt(campEnd.split('-')[1], 10),
    //   year: parseInt(campEnd.split('-')[0], 10)
    // }));
    let removeIndex: number;
    this.campaigns.forEach((campaign, i) => {
      if (campaign === camp) {
        removeIndex = i;
      }
    });
    this.campaigns.splice(removeIndex, 1);
  }

  toggleExistingCircuit(circuit, circuitIndex, event) {
    this.enableDropsown=false;
    this.checkpointNames=[];
    if (event.path[2].className.includes('show')) {
      event.path[2].className.includes('show') // Pratik left for you
    }
    let flag;
    this.mission.circuits[circuitIndex].existingCircuits.forEach((ad, index) => {
      if (ad.circuitName === 'Select') {
        this.mission.circuits[circuitIndex].existingCircuits.splice(index, 1);        
      }
    });
    this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitName==this.translate.instant('Select')?false:this.mission.circuits[circuitIndex].existingCircuits.push(this.mission.circuits[circuitIndex].selectedExistingCircuit);
    this.mission.circuits[circuitIndex].selectedExistingCircuit = circuit;
    let deleteIndex;
    let eclen = this.mission.circuits[circuitIndex].existingCircuits.length;
    this.mission.circuits[circuitIndex].existingCircuits.forEach((ec, delI) => {
      if (ec.circuitId === circuit.circuitId) {
        deleteIndex = delI;
      }
      eclen--;
      if (eclen === 0) {
        this.mission.circuits[circuitIndex].existingCircuits.splice(deleteIndex, 1);
        this.mission.circuits[circuitIndex].checkpointsGeoJson.features = [];
        let checkLens = this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints.length;
        if (this.market) {
          // console.log('4087 market swlected',this.mission);
          this.mission.circuits[circuitIndex].checkpointsGeoJson['features'] = [];
          this._http.SecureGet('/ref/getAllMissions?id=' + this.missionId).subscribe(res => {
           
            const feature1 = {
              'type': 'Feature',
              'geometry': { 'type': 'Point', 'coordinates': [res.data.missions[0].missionMarketZoneList[0].longitude, res.data.missions[0].missionMarketZoneList[0].latitude] },
              'lnglat': [res.data.missions[0].missionMarketZoneList[0].longitude, res.data.missions[0].missionMarketZoneList[0].latitude],
              'checkpointName': res.data.missions[0].missionMarketZoneList[0].officialName,
              'fillColor': 'purple',
              'existingCircuit': 'true',
              'isSearch': 'false'
            };   
            this.marketName=res.data.missions[0].missionMarketZoneList[0].officialName;        
            this.mission.circuits[0].checkpointsGeoJson['features'].push(feature1);
          });

          
          // const feature1 = {
          //   'type': 'Feature',
          //   'geometry': { 'type': 'Point', 'coordinates': [this.mission.markets[0].longitude, this.mission.markets[0].latitude] },
          //   'lnglat': [this.mission.markets[0].longitude, this.mission.markets[0].latitude],
          //   'checkpointName': 'Market Zone',
          //   'fillColor':'purple'
    
          // };
          // this.mission.circuits[circuitIndex].checkpointsGeoJson['features'].push(feature1);

          this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints.sort(function(a, b) {
            return a.position - b.position;
          });
          this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints.forEach(extCheck => {
            const feature = {
              'type': 'Feature',
              'geometry': { 'type': 'Point', 'coordinates': [extCheck.checkpointLongitude, extCheck.checkpointLatitude] },
              'lnglat': [extCheck.checkpointLongitude, extCheck.checkpointLatitude],
              'checkpointName': extCheck.checkpointName,
              'existingCircuit': 'false'
            };
            
            this.checkpointNames.push(extCheck.checkpointName);
            console.log(this.checkpointNames);
            this.mission.circuits[circuitIndex].checkpointsGeoJson['features'].push(feature);
            checkLens--;
            if (checkLens === 0) {
              this.populateExistingCheckpoints();
              this.mission.circuits[circuitIndex].map.flyTo({
                center: [this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints[0].checkpointLongitude,
                this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints[0].checkpointLatitude],
                zoom: 9,
                bearing: 0,
                curve: 1
              });
            }
          });      
        }
        else{
          this.checkpointNames=[];
          this.mission.circuits[circuitIndex].checkpointsGeoJson['features']=[];
          this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints.sort(function(a, b) {
            return a.position - b.position;
          });
          this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints.forEach(extCheck => {
          const feature = {
            'type': 'Feature',
            'geometry': { 'type': 'Point', 'coordinates': [extCheck.checkpointLongitude, extCheck.checkpointLatitude] },
            'lnglat': [extCheck.checkpointLongitude, extCheck.checkpointLatitude],
            'checkpointName': extCheck.checkpointName,            
          };
          this.checkpointNames.push(extCheck.checkpointName);
          this.mission.circuits[circuitIndex].checkpointsGeoJson['features'].push(feature);
          checkLens--;
          if (checkLens === 0) {
            this.populateExistingCheckpoints();
            this.mission.circuits[circuitIndex].map.flyTo({
              center: [this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints[0].checkpointLongitude,
              this.mission.circuits[circuitIndex].selectedExistingCircuit.circuitCheckpoints[0].checkpointLatitude],
              zoom: 9,
              bearing: 0,
              curve: 1
            });
          }
        });
      }
    }
     
    });
  }

  surveySelection(surveyId) {
    this.surveyChange.emit(surveyId);
  }

  toggleMissionType(mType) {
    if (mType.id !== 4) {
      this.missionTypes.push(this.selectedMissionType);
      this.selectedMissionType = mType;
      let removeIndex: number;
      this.missionTypes.forEach((tsk, i) => {
        if (tsk === mType) {
          removeIndex = i;
        }
      });
      this.missionTypes.splice(removeIndex, 1);
    } else {
      this.surveySelection(mType.id);
    }
  }

  circuitMissionToggler(mission) {
    this.mission.circuits.forEach((circuit, i) => {
      this.mission.circuits[i].missions.push(this.mission.circuits[i].selectedMission);
      this.mission.circuits[i].selectedMission = mission;
      let removeIndex: number;
      let len = this.mission.circuits[i].missions.length;
      this.mission.circuits[i].missions.forEach((miss, ind) => {
        if (mission === miss) {
          removeIndex = ind;
        }
        len--;
        if (len === 0) {
          this.mission.circuits.forEach(c => {
            c.selectedMission = mission;
          });
        }
      });
      this.mission.circuits[i].missions.splice(removeIndex, 1);
    });
  }

  toggleMission(mission, i) {
    if (mission.missionType.id === 3) {
      const circlen = mission.missionCircuits.length + this.mission.circuits.length;
      if (circlen > 1) {
        this.pedestrainAlertsService.toggleMission().then(() => {
          for (let j = this.mission.circuits.length - 1; j > 0; j--) {
            this.mission.circuits.splice(j, 1);
          }
          this.circuitMissionToggler(mission);
        }).catch(() => { });
      } else {
        this.circuitMissionToggler(mission);
      }
      this.showAddNewCircuit = false;
    } else {
      this.circuitMissionToggler(mission);
      this.showAddNewCircuit = true;
    }
  }

  checkpointMissionToggler(mission) {
    this.mission.checkpoints.forEach((checkpoint, i) => {
      if (mission.missionCircuits.length !== 0) {
        if (mission.missionCircuits[0] !== checkpoint.selectedCircuit) {
          checkpoint.circuits = [];
          let len = this.circuits.length;
          this.circuits.forEach(circuit => {
            if (checkpoint.selectedCircuit !== circuit) {
              checkpoint.circuits.push(circuit);
            }
            len--;
            if (len === 0) {
              let indexOfSelectedMission = -1;
              let mclength = checkpoint.circuits.length;
              checkpoint.circuits.forEach((circ, index) => {
                if (circ.circuitId === mission.missionCircuits[0].circuitId) {
                  indexOfSelectedMission = index;
                }
                mclength--;
                if (mclength === 0) {
                  if (indexOfSelectedMission !== -1) {
                    let tempSelectedCircuit = this.mission.checkpoints[i].selectedCircuit;
                    const pushableCircuits = [];
                    let missionCircuitLen = mission.missionCircuits.length;
                    mission.missionCircuits.forEach(cir => {
                      if (mission.missionType.id === 3 && cir.circuitCheckpoints.length <= 2) {
                        pushableCircuits.push(cir);
                      } else {
                        pushableCircuits.push(cir);
                      }
                      missionCircuitLen--;
                      if (missionCircuitLen === 0) {
                        tempSelectedCircuit = pushableCircuits[0];
                        pushableCircuits.splice(0, 1);
                        checkpoint.circuits = pushableCircuits;
                        checkpoint.selectedCircuit = tempSelectedCircuit;
                        checkpoint.data.lnglat = [tempSelectedCircuit.circuitLongitude, tempSelectedCircuit.circuitLatitude];
                        this.checkpointMap.flyTo({
                          center: [tempSelectedCircuit.circuitLongitude, tempSelectedCircuit.circuitLatitude],
                          zoom: 9,
                          bearing: 0,
                          curve: 1
                        });
                        this.myCircle1.setCenter({ lat: parseFloat(this.mission.markets[0].longitude), lng: parseFloat(this.mission.markets[0].longitude) }).setRadius(150).addTo(this.checkpointMap);
                      }
                    });
                  }
                }
              });
            }
          });
        } else if (mission.missionCircuits[0] === checkpoint.selectedCircuit) {
          checkpoint.circuits = [];
          let clen = this.circuits.length;
          this.circuits.forEach(circuit => {
            if (checkpoint.selectedCircuit !== circuit) {
              checkpoint.circuits.push(circuit);
            }
            clen--;
            if (clen === 0) {
              const indexOfSelectedMission = checkpoint.circuits.indexOf(mission.missionCircuits[0]);
              checkpoint.circuits = [];
              const circuits = [];
              let len = mission.missionCircuits.length;
              mission.missionCircuits.forEach(circ => {
                circuits.push(circ);
                len--;
                if (len === 0) {
                  checkpoint.selectedCircuit = circuits[0];
                  checkpoint.data.lnglat = [circuits[0].circuitLongitude, circuits[0].circuitLatitude];
                  this.checkpointMap.flyTo({
                    center: [circuits[0].circuitLongitude, circuits[0].circuitLatitude],
                    zoom: 9,
                    bearing: 0,
                    curve: 1
                  });
                  this.myCircle1.setCenter({ lat: parseFloat(this.mission.markets[0].longitude), lng: parseFloat(this.mission.markets[0].longitude) }).setRadius(150).addTo(this.checkpointMap);
                  circuits.splice(0, 1);
                  checkpoint.circuits = circuits;
                }
              });
            }
          });

        }
        checkpoint.missions.push(checkpoint.selectedMission);
        checkpoint.selectedMission = mission;
        if (checkpoint.selectedMission.missionType.id === 3) {
          const checkpointsLength = this.mission.checkpoints.length + checkpoint.selectedCircuit.circuitCheckpoints.length;
          if (checkpointsLength === 3) {
            this.showAddNewCheckpoint = false;
          }
        }
        let removeIndex: number;
        checkpoint.missions.forEach((miss, ind) => {
          if (mission === miss) {
            removeIndex = ind;
          }
        });
        checkpoint.missions.splice(removeIndex, 1);
      } else {
        this.pedestrainAlertsService.addCircuitMissionAlert(mission.missionName).then(() => { }).catch(() => { });
      }
    });
  }

  toggleCheckpointMission(mission, i) {
    if (mission.missionType.id === 3 && this.mission.checkpoints.length >= 3) {
      if (this.mission.checkpoints.length > 3) {
        this.pedestrainAlertsService.checkPointsMoreThan3().then(() => {
          for (let j = this.mission.checkpoints.length - 1; j > 0; j--) {
            this.mission.checkpoints.splice(j, 1);
          }
          this.showAddNewCheckpoint = true;
          this.checkpointMissionToggler(mission);
        });
      } else {
        this.checkpointMissionToggler(mission);
      }
    } else {
      this.showAddNewCheckpoint = true;
      this.checkpointMissionToggler(mission);
    }

  }

  toggleCircuit(circuit, i) {
    this.mission.checkpoints[i].circuits.push(this.mission.checkpoints[i].selectedCircuit);
    this.mission.checkpoints[i].selectedCircuit = circuit;
    this.mission.checkpoints[i].data.lnglat = [circuit.circuitLongitude, circuit.circuitLatitude];
    this.mission.checkpoints[i].map.flyTo({
      center: [circuit.circuitLongitude, circuit.circuitLatitude],
      zoom: 9,
      bearing: 0,
      curve: 1
    });
    this.myCircle1.setCenter({ lat: parseFloat(this.mission.markets[0].longitude), lng: parseFloat(this.mission.markets[0].longitude) }).setRadius(150).addTo( this.mission.checkpoints[i].map);
    let removeIndex: number;
    this.mission.checkpoints[i].circuits.forEach((circ, ind) => {
      if (circuit === circ) {
        removeIndex = ind;
      }
    });
    this.mission.checkpoints[i].circuits.splice(removeIndex, 1);
  }

  // toggleShift(shift, i) {
  //   this.mission.assignments[i].shifts.push(this.mission.assignments[i].selectedShift);
  //   this.mission.assignments[i].selectedShift = shift;
  //   let len = this.mission.assignments[i].shifts.length;
  //   let deleteIndex = -1;
  //   this.mission.assignments[i].shifts.forEach((s, ind) => {
  //     if (shift === s) {
  //       deleteIndex = ind;
  //     }
  //     len--;
  //     if (len === 0) {
  //       this.mission.assignments[i].shifts.splice(deleteIndex, 1);
  //     }
  //   });
  // }
  
  selectedAgentUserId;
  selectedAgent;
  enableSave=false;
  toggleFieldAgent(fa, i) {
    this.enableSave=true;
    this.selectedAgentUserId=fa.userId
    console.log("togglefield agent=",fa,i);
    console.log("this.mission=",this.mission);
    this.selectedAgent=fa;
  
    
    let length = this.mission.assignments.length;
    let flag = false;
    this.mission.assignments.forEach((assign, ind) => {
      if (ind !== i) {
        if (fa.userId === assign.selectedFieldAgent.userId) {
          flag = true;
        }
        let delInd = -1;
        let flen = assign.fieldAgents.length;
        assign.fieldAgents.forEach((f, ing) => {
          if (f.userId === fa.userId) {
            delInd = ing;
          }
          flen--;
          if (flen === 0) {
            assign.fieldAgents.splice(delInd, 1);
            assign.fieldAgents.push(this.mission.assignments[i].selectedFieldAgent);
          }
        });
      }
      length--;
      if (length === 0) {
        if (flag === false) {
          this.mission.assignments[i].fieldAgents.push(this.mission.assignments[i].selectedFieldAgent);
          this.mission.assignments[i].selectedFieldAgent = fa;
          let len = this.mission.assignments[i].fieldAgents.length;
          let deleteIndex = -1;
          this.mission.assignments[i].fieldAgents.forEach((f, di) => {
            if (fa === f) {
              deleteIndex = di;
            }
            len--;
            if (len === 0) {
              this.mission.assignments[i].fieldAgents.splice(deleteIndex, 1);
            }
          });
        } else {
          this.pedestrainAlertsService.alreadyFieldAgentsusedAssignment().then(() => { }).catch(() => { });
        }
      }
    });
  }

  toggleCheckpoint(checkpoint, i) {
    this.mission.assignments[i].checkpoints.push(this.mission.assignments[i].selectedCheckpoint);
    this.mission.assignments[i].selectedCheckpoint = checkpoint;
    let len = this.mission.assignments[i].checkpoints.length;
    let deleteIndex = -1;
    this.mission.assignments[i].fieldAgents.forEach((ch, ind) => {
      if (checkpoint === ch) {
        deleteIndex = ind;
      }
      len--;
      if (len === 0) {
        this.mission.assignments[i].checkpoints.splice(deleteIndex, 1);
      }
    });
  }
shift=1;
morning=true;
  changeShiftId(id, i) {
    console.log("shift changed",id,i);
    console.log(",this.startDate",this.startDate);
    
    
    if(id===1){
      this.morning=true;
      this.shift=1;
      this.getMissionDates();
      if(this.startDate){
        this.getAllFieldAgents()

      }
      
    } else {
      this.morning=false;
      this.shift=2;
      this.getMissionDates();
      if(this.startDate){
        this.getAllFieldAgents()

      }
         }
    if (id !== this.mission.assignments[i].shiftId) {
      this.mission.assignments[i].shifts = [];
      let shiftLen = this.shifts.length;
      this.shifts.forEach(shift => {
        if (id === 1 && shift.shiftName === 'Morning' && !this.mission.assignments[i].selectedShifts.includes(shift.timeRange)) {
          this.mission.assignments[i].shifts.push(shift);
        } else if (id === 2 && shift.shiftName === 'Afternoon' && !this.mission.assignments[i].selectedShifts.includes(shift.timeRange)) {
          this.mission.assignments[i].shifts.push(shift);
        }
        shiftLen--;
        if (shiftLen === 0) {
          this.mission.assignments[i].selectedShift = this.mission.assignments[i].shifts[0];
          this.mission.assignments[i].shifts.splice(0, 1);
          this.mission.assignments[i].shiftId = id;
        }
      });
    }
  }


  /* *****************************  CREATORS  ************************************
    createMission(formData)
    createCircuit()
    createCheckpoint()
    circuitMapCreator()
    circuitMapUpdater()
    checkpointMapCreator()
    checkpointObjectMaker()
    assignmentMapMaker()
    assignmentMapCreator()
    createAssignment()
    */
  createMission(formData) {
    if (this.mission.selectedCampaign.campaignName == this.translate.instant('Select compaign')) {
      this.pedestrainAlertsService.selectCampagin();
    }
    else {
      this.disableStep1 = true;
      let startdate: any
      let endDateMission
      console.log("this.mission=", this.mission);
      startdate = this.mission.selectedCampaign.campaignStartDate;
      endDateMission = this.mission.selectedCampaign.campaignEndDate;
      console.log("startdate=", startdate);

      startdate = startdate.split(' ');
      startdate = startdate[0].split('-');
      console.log("startdate=", startdate);
      const startdayObj = {
        year: startdate[0],
        month: startdate[1],
        day: startdate[2]
      }
      endDateMission = endDateMission.split(' ');
      endDateMission = endDateMission[0].split('-');
      console.log("startdate=", endDateMission);
      const enddayObj = {
        year: endDateMission[0],
        month: endDateMission[1],
        day: endDateMission[2]
      }


      // if (!this.step1Completed) {
      const now1 = new Date(Date.now());
      const CurrentDate = new Date(now1.getFullYear(), now1.getMonth(), now1.getDate()); 
      console.log("lets check=", new Date(this.mission.selectedCampaign.campaignEndDate) < CurrentDate);
      console.log("check 1=", new Date(this.mission.selectedCampaign.campaignEndDate), CurrentDate);


      if (new Date(this.mission.selectedCampaign.campaignEndDate) < CurrentDate) {
        this.campaignflag = false;
        localStorage.setItem('campaignFlag', 'false');
      } else {
        this.campaignflag = true
        localStorage.setItem('campaignFlag', 'true');

        localStorage.setItem('campaignStartDate', JSON.stringify(startdayObj));
        localStorage.setItem('campaignEndDate', JSON.stringify(enddayObj));
      }

      const startDate = this.mission.missionStartDate.year + '-' +
        this.mission.missionStartDate.month + '-' + this.mission.missionStartDate.day + ' ' + '00:00:00';
      const endDate = this.selectedMissionType['id'] === 3 ?
        this.mission.missionStartDate.year + '-' +
        this.mission.missionStartDate.month + '-' +
        this.mission.missionStartDate.day + ' ' + '00:00:00' :
        this.mission.missionEndDate.year + '-' +
        this.mission.missionEndDate.month + '-' +
        this.mission.missionEndDate.day + ' ' + '00:00:00';
      const now = Date.now();
      const creationDate = new Date(now);
      const nowYear = creationDate.getFullYear();
      const nowMonth = creationDate.getMonth() + 1;
      const nowDay = creationDate.getDate();
      const nowInReq = nowYear + '-' + nowMonth + '-' + nowDay + ' ' + '00:00:00';
      const estimatedTime = (parseInt('10', 10) * 60) + parseInt('10', 10);

      const reqObj = {
        missionName: this.mission.missionName,
        missionDescription: this.mission.missionDescription,
        missionTypeId: this.selectedMissionType['id'],
        missionCreationDate: nowInReq.toString(),
        missionCampaignId: this.mission.selectedCampaign['campaignId'],
        missionCreatedById: this.user.userId,
        missionStatusId: 3,
        classic: true,
        market: this.market,
        marketZone: this.market ? this.marketid : null,
        prm: false,
        visits: false

      };

      localStorage.setItem('missonNameExist', reqObj.missionName);
      this._http.SecurePost('/mission/addMission', reqObj).subscribe(res => {
        this.missionId = res.responseMessage.split('! ')[1];
        this.pedestrainAlertsService.missionCreatedSuccessAlert()
          .then(() => {
            this.pageOpenAllowed = true;
            this.step1Completed = true;
            if (this.selectedMissionType.id === 3) {
              this.showAddNewCircuit = false;
            }
            this.getMissions(() => {
              this.disableStep1 = false;
              this.open(2);
              var elemant1 = document.getElementById('missionName');
              elemant1.setAttribute("disabled", "true");
              var elemant2 = document.getElementById('missionDescription');
              elemant2.setAttribute("disabled", "true");
              var elemant3 = document.getElementById('market');
              elemant3.setAttribute("disabled", "true");
            });
          }).catch(() => {
            this.pageOpenAllowed = true;
            this.step1Completed = true;
            if (this.selectedMissionType.id === 3) {
              this.showAddNewCircuit = false;
            }
            this.getMissions(() => {
              this.disableStep1 = false;
              this.open(2);
            });
          });
      }, err => {

      });
    }
  }

  populateExistingCheckpoints() {
    this.mission.checkpoints = [];
    this.geojson.features = [];
    const checkpoints = [];
    console.log('mission.circuits', this.mission.circuits);
    this.checkpointMapGeoJSON.features = [];
    const updateCheckpointObjectCreator = (index) => {
      const checkpointsLen = checkpoints.length;
      if (checkpointsLen !== index) {
        existingCheckpointPopulator(checkpoints[index], () => {
          const ind = index + 1;
          updateCheckpointObjectCreator(ind);
        });
       
      } else {
        if (this.market) {
          console.log('1874');
          this.geojson.features.push({
            type: 'Feature',
            properties: {
              message: 'Foo',
              iconSize: [60, 60]
            },
            geometry: {
              type: 'Point',
              coordinates: [this.mission.markets[0].longitude, this.mission.markets[0].latitude]
            },
            'checkpointName': 'Market Zone'
          });
         
          this.checkpointMapGeoJSON.features.push({
            'type': 'Feature',
            'geometry': {
              'type': 'Point',
              'coordinates': [this.mission.markets[0].longitude,
              this.mission.markets[0].latitude]
            },
            'existingCircuit':'true',
            'isSearch': 'false',
            'lnglat': [
              parseFloat(Number(this.mission.markets[0].longitude).toFixed(20)),
              parseFloat(Number(this.mission.markets[0].latitude).toFixed(20))
            ],
            'checkpointName': this.marketName
          });
        }
        this.loadMapForExistingCircuit = true;
      }
    };
    let i=0;
    const existingCheckpointPopulator = (checkpoint, cb) => {

      this._http.pullAdptIdDetails(checkpoint.adptId).subscribe(res => {
        this.count+=1;
        
        const response = res.data['Geographic Data'][0];
        const mapObj = {
          selectedMission: this.mission.circuits[0].selectedMission,
          selectedCircuit: this.mission.circuits[0].selectedExistingCircuit,
          selected_adrn: response.adt_adrn,
          selected_street: response.adt_street,
          selected_postalcode: response.adt_postal_code,
          selected_commune: response.com_commune_name_fr,
          selected_region: response.reg_region_name_fr,
          selected_country: response.con_country_name_fr,
          id: checkpoint.checkpointId,
          position: this.count,
          data: {
            checkpointName: checkpoint.checkpointName,
            description: checkpoint.checkpointDescription,
            adptid: checkpoint.adptId,
            quartier: response.qub_quartier_name_fr,
            lnglat: [response.adt_longitude_wgs84,
            response.adt_latitude_wgs84]
          }
        };
        if (this.market) {
          console.log('1874');
          this.geojson.features.push({
            type: 'Feature',
            properties: {
              message: 'Foo',
              iconSize: [60, 60]
            },
            geometry: {
              type: 'Point',
              coordinates: [this.mission.markets[0].longitude, this.mission.markets[0].latitude]
            },
            'checkpointName': this.marketName
          });
             this.geojson.features.push({
            type: 'Feature',
            properties: {
              message: 'Foo',
              iconSize: [60, 60]
            },
            geometry: {
              type: 'Point',
              coordinates: [response.adt_longitude_wgs84, response.adt_latitude_wgs84]
            }
          });
        } else {
          this.geojson.features.push({
            type: 'Feature',
            properties: {
              message: 'Foo',
              iconSize: [60, 60]
            },
            geometry: {
              type: 'Point',
              coordinates: [response.adt_longitude_wgs84, response.adt_latitude_wgs84]
            }
          });
        }
        this.checkpointMapGeoJSON.features.push({
          'type': 'Feature',
          'geometry': {
            'type': 'Point',
            'coordinates': [response.adt_longitude_wgs84,
            response.adt_latitude_wgs84]
          },
          'existingCircuit':'false',
          'lnglat': [
            parseFloat(Number(response.adt_longitude_wgs84).toFixed(20)),
            parseFloat(Number(response.adt_latitude_wgs84).toFixed(20))
          ],
          'checkpointName': this.checkpointNames[i]
        });
        i+=1;
        // console.log('2366',response);
        if(this.market)
        this.existingCircuitsCheck = true;
        this.mission.checkpoints.push(mapObj);
        cb();
      }, err => {
        console.log('err', err);
      });
    };

    let checklen = this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints.length;
    // this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.sort(function(a, b) {
    //   return a.position - b.position;
    // });
    this.mission.circuits[0].selectedExistingCircuit.circuitCheckpoints.forEach(checkpoint => {
      checkpoints.push(checkpoint);
      checklen--;
      if (checklen === 0) {
        updateCheckpointObjectCreator(0);
      }
    });
    setTimeout(() => {
      this.enableDropsown=true;  
    }, 5000);
  }

  createCircuit() {
    this.disableStep2 = true;
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    let circuitsLen = this.mission.circuits.length;
    this.mission.circuits.forEach(circuit => {
      if (circuit.existingCircuitsCheck) {

        const formData = new FormData();
        const XHR = new XMLHttpRequest();
        formData.append('missionId', circuit.selectedMission.missionId);
        formData.append('existingCircuitId', circuit.selectedExistingCircuit.circuitId);
        formData.append('circuitCreatedBy', circuit.selectedExistingCircuit.circuitCreatedById);
        formData.append('circuitUpdatedBy', this.user.userId);
        formData.append('locationId', '0');
        formData.append('locationTypeId', '1');
        XHR.addEventListener('load', (event) => {

        });
        XHR.onreadystatechange = (aEvt) => {
          if (XHR.readyState === 4) {
            if (XHR.status === 200) {
              const response = JSON.parse(XHR.response);
              circuitsLen--;
              if (circuitsLen === 0) {
                this.event.hideLoader({});
                this.pedestrainAlertsService.circuitCreatedSuccessAlert().then(() => {
                  this.pageOpenAllowed = true;
                  this.step2Completed = true;
                  this.validateCircuits(valid => {
                    console.log(valid);
                    if (valid) {
                      this.disableStep2 = false;
                      this.open(3);
                    } else {
                      if (this.existingCircuitsCheck) {
                        this.disableStep2 = false;
                        this.open(3);
                      } else {
                        this.disableStep2 = false;
                        this.pedestrainAlertsService.somethingWentWrong().then(() => { }).catch(() => { });
                      }
                    }
                  });
                });
              }
            } else {
              this.disableStep2 = false;
              this.pedestrainAlertsService.somethingWentWrong().then(() => { }).catch(() => { });
            }
          }
        };
        XHR.addEventListener('error', (event) => {
          this.disableStep2 = false;
          this.event.hideLoader({});
          this.pedestrainAlertsService.somethingWentWrongQuestion().then(() => { }).catch(() => { });
        });

        XHR.open('POST', this.xmlHttpUrl + '/circuit/addCircuit');
        XHR.setRequestHeader('Authorization', this.user.accessToken);
        XHR.setRequestHeader('userId', this.user.userId);
        XHR.send(formData);
      } else {
        const formData = new FormData();
        const XHR = new XMLHttpRequest();
        formData.append('missionId', circuit.selectedMission.missionId);
        formData.append('circuitName', circuit.data.circuitName);
        formData.append('circuitLatitude', circuit.data.lnglat[1]);
        formData.append('circuitLongitude', circuit.data.lnglat[0]);
        formData.append('circuitCreatedBy', this.user.userId);
        formData.append('circuitUpdatedBy', this.user.userId);
        formData.append('locationId', '0');
        formData.append('locationTypeId', '1');
        formData.append('images', circuit.data.image, ((new Date).getTime()).toString() + '_' + circuit.data.image.name);
        const fileName = circuit.data.image.name.replace(' ', '_');
        XHR.addEventListener('load', (event) => {

        });
        XHR.onreadystatechange = (aEvt) => {
          if (XHR.readyState === 4) {
            if (XHR.status === 200) {
              const response = JSON.parse(XHR.response);

              const id = response.responseMessage.split('! ')[2];
              circuitsLen--;
              if (circuitsLen === 0) {
                this.event.hideLoader({});
                this.pedestrainAlertsService.circuitCreatedSuccessAlert().then(() => {
                  this.pageOpenAllowed = true;
                  this.step2Completed = true;
                  this.validateCircuits(valid => {
                    if (valid) {
                      this.disableStep2 = false;
                      this.open(3);
                    } else {
                      this.disableStep2 = false;
                      this.pedestrainAlertsService.somethingWentWrong();
                    }
                  });
                });
              }
            } else {
              this.disableStep2 = false;
              this.pedestrainAlertsService.somethingWentWrong();
            }
          }
        };
        XHR.addEventListener('error', (event) => {
          this.disableStep2 = false;
          this.event.hideLoader({});
          this.pedestrainAlertsService.somethingWentWrong();
        });

        XHR.open('POST', this.xmlHttpUrl + '/circuit/addCircuit');
        XHR.setRequestHeader('Authorization', this.user.accessToken);
        XHR.setRequestHeader('userId', this.user.userId);
        XHR.send(formData);
      }
    });
  }

  createCheckpoint() {
    this.disableStep3 = true;
    // this.assignmentMapCreator();
    this.checkpointIndexSetter(0);

  }

  checkpointIndexSetter(index) {
    const len = this.mission.checkpoints.length;
    if (this.existingCircuitsCheck) {
      this.pageOpenAllowed = true;
      this.step3Completed = true;
      this.disableStep3 = false;
      this.assignmentMapCreator();
      this.open(4);
    } else {
      if (len !== index) {
        this.sendCheckpoint(this.mission.checkpoints[index], index, (i) => {
          const ind = i + 1;
          this.checkpointIndexSetter(ind);
        });
      } else {
        this.pedestrainAlertsService.checkPointsSuccessAlert()
          .then(() => {
            console.log("check point ===");
            
            this.pageOpenAllowed = true;
            this.step3Completed = true;
            this.disableStep3 = false;
            this.open(4);
          }).catch(() => { });
      }
    }
  }

  sendCheckpoint(checkpoint, index, cb) {
    const fd = new FormData();
    const XHR = new XMLHttpRequest();
    fd.append('circuitId', checkpoint.selectedCircuit.circuitId);
    fd.append('checkpointName', checkpoint.data.checkpointName);
    fd.append('checkpointDescription', checkpoint.data.description);
    fd.append('checkpointAddress', checkpoint.data.address);
    fd.append('adptId', checkpoint.data.adptid);
    fd.append('checkpointLatitude', checkpoint.data.lnglat[1]);
    fd.append('checkpointLongitude', checkpoint.data.lnglat[0]);
    fd.append('checkpointCreatedBy', this.user.userId);
    fd.append('checkpointUpdatedBy', this.user.userId);
    fd.append('position', index+1);
    if (this.market) {
      console.log('1874');
      this.geojson.features.push({
        type: 'Feature',
        properties: {
          message: 'Foo',
          iconSize: [60, 60]
        },
        geometry: {
          type: 'Point',
          coordinates: [this.mission.markets[0].longitude, this.mission.markets[0].latitude]
        },
        'checkpointName': 'Market Zone'
      });
      
    this.geojson.features.push({
      type: 'Feature',
      properties: {
        message: 'Foo',
        iconSize: [60, 60]
      },
      geometry: {
        type: 'Point',
        coordinates: [checkpoint.data.lnglat[0], checkpoint.data.lnglat[1]]
      }
    });
    }
    else{

    this.geojson.features.push({
      type: 'Feature',
      properties: {
        message: 'Foo',
        iconSize: [60, 60]
      },
      geometry: {
        type: 'Point',
        coordinates: [checkpoint.data.lnglat[0], checkpoint.data.lnglat[1]]
      }
    });
  }
    XHR.addEventListener('load', function (event) {
    });

    XHR.onreadystatechange = (aEvt) => {
      if (XHR.readyState === 4) {
        if (XHR.status === 200) {
          const response = JSON.parse(XHR.response);

          const id = response.responseMessage.split('! ')[2];
          this.mission.checkpoints[index].id = parseInt(id, 10);
          cb(index);
        } else {
          this.disableStep3 = false;
          this.pedestrainAlertsService.somethingWentWrong();
        }
      }
    };
    XHR.addEventListener('error', (event) => {
      this.disableStep3 = false;
    });
    XHR.open('POST', this.xmlHttpUrl + '/checkpoint/addCheckpoint');
    XHR.setRequestHeader('Authorization', this.user.accessToken);
    XHR.setRequestHeader('userId', this.user.userId);
    XHR.send(fd);
  }

  sendAssignment(req) {
    console.log("in send assignment.......");
    
    this.disableStep4 = true;
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this._http.SecurePost('/mission/assignMission', req).subscribe(res => {
      this.event.hideLoader({});
      this.pedestrainAlertsService.assignmentSuccessAlert()
        .then(() => {
          this.viewSummary(() => {
            this.pageOpenAllowed = true;
            this.step4Completed = true;
            this.step5Completed = true;
            this.open(5);
          });
        }).catch(() => {
          this.pageOpenAllowed = true;
          this.step4Completed = true;
          this.open(5);
        });
    }, err => {
      console.log("errorr.....");
      
      this.disableStep4 = false;
      this.pedestrainAlertsService.assignmentWaringAlert().then(() => { 
      }).catch(() => {
        
       });
    });
  }

  createAssignment() {
    let count = 0;
    let checkerCount = this.mission.assignments.length;
     this.assignmentLooper()
    // this.mission.assignments.forEach(assignment => {
    //   const indiCount = assignment.selectedCheckpoints.length * assignment.selectedShifts.length;
    //   count = count + indiCount;
    //   checkerCount--;
    //   if (checkerCount === 0) {
    //     this.assignmentLooper(count);
    //   }
    // });
  }
  saveWithoutFlag=false;
  saveWithoutAssign(){
    this.selectedAgent=undefined;
    this.saveWithoutFlag=true;
    // this.agentSelected=false;

    // this.userId=false;
    this.assignmentLooper();
  }

  assignmentLooper() {
    console.log("in assignment looper");
    
    const reqObj = {
      missionStartDate:`${this.startDate} 00:00:00`,
      missionEndDate:`${this.startDate} 00:00:00`,
      missionId:this.mission.checkpoints[0].selectedMission.missionId,
      missionTypeId:3,
      missionEstimatedTime:610,
      assignMission:!this.saveWithoutFlag,
      assignments: []
    };
    let circuitId=0
    console.log("in assignmentloopchecker=",this.assignments);
    if(this.mission.assignments){
      this.assignments.forEach(element => {
        if( element.tempCheckpoints){
          element.tempCheckpoints.forEach(element2 => {
            circuitId=element2.selectedCircuit.circuitId
          });
        }
      
      });
    }

    if(!this.useExisting){
      console.log("mission=",this.assignments);
      
      this.assignments.forEach(element => {
        console.log("element=",element);
        
        circuitId=element.selectedCircuit.circuitId
      });
    }
    
    

    console.log("this.assignments=",this.assignments,this.mission.assignments[0]);
    // if(!this.saveWithoutFlag){
      if(this.morning){
        this.mission.assignments[0].tempCheckpoints.forEach(element => {
          reqObj.assignments.push({
            userId: !this.saveWithoutFlag?this.selectedAgentUserId:null,
            campaignId:this.mission.selectedCampaign['campaignId'],
            missionId: this.mission.checkpoints[0].selectedMission.missionId,
            circuitId: circuitId ,
            iterations: 5,
            shiftId: 1,
            marketZone:this.market?this.marketid:null,
            checkpointId: element.id,
            startDate:`${this.startDate} 10:00:00`,
            endDate:`${this.startDate} 12:30:00`,
            missionType:3,
            // startDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
            // endDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
            createdBy: this.user.userId,
            updatedBy: this.user.userId,
            assignedBy: this.user.userId
          });
          reqObj.assignments.push({
            userId: !this.saveWithoutFlag?this.selectedAgentUserId:null,
            campaignId:this.mission.selectedCampaign['campaignId'],
            missionId: this.mission.checkpoints[0].selectedMission.missionId,
            circuitId: circuitId ,
            iterations: 4,
            shiftId: 2,
            marketZone:this.market?this.marketid:null,
            checkpointId: element.id,
            startDate:`${this.startDate} 14:30:00`,
            endDate:`${this.startDate} 16:30:00`,
            missionType:3,
            // startDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
            // endDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
            createdBy: this.user.userId,
            updatedBy: this.user.userId,
            assignedBy: this.user.userId
          });
        });
        
      } else {
        this.mission.assignments[0].tempCheckpoints.forEach(element => {
          reqObj.assignments.push({
            userId: !this.saveWithoutFlag?this.selectedAgentUserId:null,
            campaignId:this.mission.selectedCampaign['campaignId'],
            missionId: this.mission.checkpoints[0].selectedMission.missionId,
            circuitId: circuitId ,
            iterations: 4,
            shiftId: 1,
            marketZone:this.market?this.marketid:null,
            checkpointId: element.id,
            startDate:`${this.startDate} 12:30:00`,
            endDate:`${this.startDate} 14:30:00`,
            missionType:3,
            // startDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
            // endDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
            createdBy: this.user.userId,
            updatedBy: this.user.userId,
            assignedBy: this.user.userId
          });
          reqObj.assignments.push({
            userId: !this.saveWithoutFlag?this.selectedAgentUserId:null,
            campaignId:this.mission.selectedCampaign['campaignId'],
            missionId: this.mission.checkpoints[0].selectedMission.missionId,
            circuitId: circuitId ,
            iterations: 5,
            shiftId: 2,
            marketZone:this.market?this.marketid:null,
            checkpointId: element.id,
            startDate:`${this.startDate} 16:30:00`,
            endDate:`${this.startDate} 19:00:00`,
            missionType:3,
            // startDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
            // endDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
            createdBy: this.user.userId,
            updatedBy: this.user.userId,
            assignedBy: this.user.userId
          });
        });
       
      }
      
    // }
      
    this.sendAssignment(reqObj);
if(this.mission.assignments){
    this.mission.assignments.forEach(assignment => {
      assignment.selectedCheckpoints.forEach(checkpoint => {
        assignment.tempCheckpoints.forEach(check => {
          if (check.data.checkpointName === checkpoint) {
            assignment.selectedShifts.forEach(shift => {
              // reqObj.assignments.push({
              //   userId: assignment.selectedFieldAgent.userId,
              //   missionId: this.mission.checkpoints[0].selectedMission.missionId,
              //   circuitId: check.selectedCircuit.circuitId,
              //   checkpointId: check.id,
              //   shiftId: 1,
              //   startDate:"2020-09-15 00:00:00",
              //   endDate:"2020-09-15 23:59:59",
              //   // startDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
              //   // endDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
              //   iterations: 5,
              //   createdBy: this.user.userId,
              //   updatedBy: this.user.userId,
              //   assignedBy: this.user.userId
              // });
              // count--;
              // if (count === 0) {
              // if (shift === '10:00 - 12:30') {
              //   this.shifts.forEach(sh => {
              //     if (sh.timeRange === shift) {
              //       reqObj.assignments.push({
              //         userId: assignment.selectedFieldAgent.userId,
              //         missionId: this.mission.checkpoints[0].selectedMission.missionId,
              //         circuitId: check.selectedCircuit.circuitId,
              //         checkpointId: check.id,
              //         shiftId: 1,
              //         startDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
              //         endDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
              //         iterations: 5,
              //         createdBy: this.user.userId,
              //         updatedBy: this.user.userId,
              //         assignedBy: this.user.userId
              //       });
              //       // count--;
              //       // if (count === 0) {
              //         this.sendAssignment(reqObj);
              //       // }
              //     }
              //   });
              // } else if (shift === '12:30 - 14:30') {
              //   this.shifts.forEach(sh => {
              //     if (sh.timeRange === shift) {
              //       reqObj.assignments.push({
              //         userId: assignment.selectedFieldAgent.userId,
              //         missionId: this.mission.checkpoints[0].selectedMission.missionId,
              //         circuitId: check.selectedCircuit.circuitId,
              //         checkpointId: check.id,
              //         shiftId: 1,
              //         startDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
              //         endDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
              //         iterations: 4,
              //         createdBy: this.user.userId,
              //         updatedBy: this.user.userId,
              //         assignedBy: this.user.userId
              //       });
              //       count--;
              //       if (count === 0) {
              //         this.sendAssignment(reqObj);
              //       }
              //     }
              //   });
              // } else if (shift === '14:30 - 16:30') {
              //   this.shifts.forEach(sh => {
              //     if (sh.timeRange === shift) {
              //       reqObj.assignments.push({
              //         userId: assignment.selectedFieldAgent.userId,
              //         missionId: this.mission.checkpoints[0].selectedMission.missionId,
              //         circuitId: check.selectedCircuit.circuitId,
              //         checkpointId: check.id,
              //         shiftId: 2,
              //         startDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
              //         endDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
              //         iterations: 4,
              //         createdBy: this.user.userId,
              //         updatedBy: this.user.userId,
              //         assignedBy: this.user.userId
              //       });
              //       count--;
              //       if (count === 0) {
              //         this.sendAssignment(reqObj);
              //       }
              //     }
              //   });
              // } else if (shift === '16:30 - 19:00') {
              //   this.shifts.forEach(sh => {
              //     if (sh.timeRange === shift) {
              //       reqObj.assignments.push({
              //         userId: assignment.selectedFieldAgent.userId,
              //         missionId: this.mission.checkpoints[0].selectedMission.missionId,
              //         circuitId: check.selectedCircuit.circuitId,
              //         checkpointId: check.id,
              //         shiftId: 2,
              //         startDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.startTime + ':00',
              //         endDate: this.mission.checkpoints[0].selectedMission.missionStartDate.split(' ')[0] + ' ' + sh.endTime + ':00',
              //         iterations: 5,
              //         createdBy: this.user.userId,
              //         updatedBy: this.user.userId,
              //         assignedBy: this.user.userId
              //       });
              //       count--;
              //       if (count === 0) {
              //         this.sendAssignment(reqObj);
              //       }
              //     }
              //   });
              // }
            });
          }
        });
      });
    });
  }
}

  circuitMapCreator() {
    const mapObj = {
      selectedMission: {},
      missions: [],
      existingCircuitsCheck: false,
      existingCircuits: [],
      tempExistingCircuits: [],
      existingCircuitSearch: undefined,
      selectedExistingCircuit: {},
      checkpointsGeoJson: {
        'type': 'FeatureCollection',
        'features': []
      },
      data: {
        circuitName: '',
        search: '',
        lnglat: ['4.3517', '50.8503'],
        imageUploaded: false,
        progress: 0,
        uploadProgress: false
      }
    };
    if (this.step1Completed) {
      this._http.SecureGet('/ref/getAllMissions?id=' + this.missionId).subscribe(res => {
        mapObj.selectedMission = res.data.missions[0];
        if (this.existingCircuits.length !== 0) {
          let len = this.existingCircuits.length;
          this.existingCircuits.forEach(ext => {
            mapObj.existingCircuits.push(ext);
            mapObj.tempExistingCircuits.push(ext);
            len--;
            if (len === 0) {
              mapObj.selectedExistingCircuit = mapObj.existingCircuits[0];
              mapObj.existingCircuits.splice(0, 1);
              this.mission.circuits.push(mapObj);
              // this.circuitMissionFiller();
              this.missionsLoaded = true;
              this.event.hideLoader({});
            }
          });          
          this.mission.circuits[0].checkpointsGeoJson['features'] = [];
          if(res.data.missions[0].missionMarketZoneList !=null){
            const feature = {
              'type': 'Feature',
              'geometry': { 'type': 'Point', 'coordinates': [res.data.missions[0].missionMarketZoneList[0].longitude, res.data.missions[0].missionMarketZoneList[0].latitude] },
              'lnglat': [res.data.missions[0].missionMarketZoneList[0].longitude, res.data.missions[0].missionMarketZoneList[0].latitude],
              'checkpointName': res.data.missions[0].missionMarketZoneList[0].officialName,
              'fillColor': 'purple',
              'isSearch': 'false'
            };
            
            this.mission.circuits[0].checkpointsGeoJson['features'].push(feature);
          }
        } else {
          this.mission.circuits.push(mapObj);
          // this.circuitMissionFiller();
          this.missionsLoaded = true;
          this.event.hideLoader({});
        }
      }, err => {
        console.log('err', err);
      });
    } else {
      this.getMissions(() => {
        if (this.mission.circuits.length === 0) {
          if (this.existingCircuits.length !== 0) {
            let len = this.existingCircuits.length;
            this.existingCircuits.forEach(ext => {
              mapObj.existingCircuits.push(ext);
              mapObj.tempExistingCircuits.push(ext);
              len--;
              if (len === 0) {
                mapObj.selectedExistingCircuit = mapObj.existingCircuits[0];
                mapObj.existingCircuits.splice(0, 1);
                this.mission.circuits.push(mapObj);
                this.circuitMissionFiller();
                this.missionsLoaded = true;
              }
            });
          } else {
            this.mission.circuits.push(mapObj);
            this.circuitMissionFiller();
            this.missionsLoaded = true;
          }
        } else {
          mapObj.selectedMission = this.mission.circuits[0].selectedMission;
          if (this.mission.circuits[0].selectedMission.missionType.id === 3) {
            this.showAddNewCircuit = false;
          } else {
            this.showAddNewCircuit = true;
          }
          if (this.existingCircuits.length !== 0) {
            let len = this.existingCircuits.length;
            this.existingCircuits.forEach(ext => {
              mapObj.existingCircuits.push(ext);
              mapObj.tempExistingCircuits.push(ext);
              len--;
              if (len === 0) {
                mapObj.selectedExistingCircuit = mapObj.existingCircuits[0];
                mapObj.existingCircuits.splice(0, 1);
                this.mission.circuits.push(mapObj);
                this.circuitMissionFiller();
                this.missionsLoaded = true;
              }
            });
          } else {
            this.mission.circuits.push(mapObj);
            this.circuitMissionFiller();
            this.missionsLoaded = true;
          }
        }
      });
    }
  }

  getExistingCircuitsDropdownStyle(val) {
    if (val) {
      return { 'margin-top': '40px', 'margin-bottom': '190px' };
    } else {
      return { 'margin-top': '190px', 'margin-bottom': '40px' };
    }
  }

  circuitMapUpdater() {
    if (this.step1Completed) {
      this._http.SecureGet('/ref/getAllMissions?id=' + this.missionId).subscribe(res => {
        this.mission.circuits.forEach(circuit => {
          circuit.selectedMission = res.data.missions[0];          
        });
      });
    }
  }

  checkpointMapCreator() {
    if (this.step2Completed) {
      if (this.mission.circuits[0].selectedMission.missionType.id === 3) {
        if (this.mission.checkpoints.length !== 0) {
          let numberOfCheckpoints;
          if (this.mission.checkpoints[0].selectedCircuit.circuitCheckpoints.length !== 0) {
            numberOfCheckpoints = this.mission.checkpoints.length + this.mission.checkpoints[0].selectedCircuit.circuitCheckpoints.length;
          } else {
            numberOfCheckpoints = this.mission.checkpoints.length;
          }
          if (numberOfCheckpoints < 3) {
            if (numberOfCheckpoints > 2) {
              this.showAddNewCheckpoint = false;
            } else {
              this.showAddNewCheckpoint = true;
            }
            this.checkpointObjectMaker();
          } else {
            this.showAddNewCheckpoint = false;
          }
        } else {
          this.checkpointObjectMaker();
        }
      } else {
        this.checkpointObjectMaker();
      }
    } else {
      if (this.mission.checkpoints.length !== 0) {
        if (this.mission.checkpoints[0].selectedMission.missionType.id === 3) {
          let numberOfCheckpoints;
          if (this.mission.checkpoints[0].selectedCircuit.circuitCheckpoints.length !== 0) {
            numberOfCheckpoints = this.mission.checkpoints.length + this.mission.checkpoints[0].selectedCircuit.circuitCheckpoints.length;
          } else {
            numberOfCheckpoints = this.mission.checkpoints.length;
          }
          if (numberOfCheckpoints < 3) {
            if (numberOfCheckpoints > 2) {
              this.showAddNewCheckpoint = false;
            } else {
              this.showAddNewCheckpoint = true;
            }
            this.checkpointObjectMaker();
          }
        } else {
          this.checkpointObjectMaker();
        }
      } else {
        this.checkpointObjectMaker();
      }
    }
  }

  checkpointObjectMaker() {
    const mapObj = {
      selectedMission: {},
      missions: [],
      selectedCircuit: {},
      circuits: [],
      selected_adrn: {
        adt_adrn: ''
      },
      streetSearchBucket: [],
      adrns: [],
      selected_street: {
        adt_street: ''
      },
      streets: [],
      selected_postalcode: {
        adt_postal_code: ''
      },
      postalcodes: [],
      selected_commune: {
        com_commune_name_fr: ''
      },
      communes: [],
      selected_region: {
        reg_region_name_fr: ''
      },
      regions: [],
      selected_country: {
        con_country_name_fr: ''
      },
      coutries: [],
      adptid_valid: true,
      dontKnowAdptId: true,
      countryLoaded: false,
      regionLoaded: false,
      communeLoaded: false,
      postalCodeLoaded: false,
      streetLoaded: false,
      adrnLoaded: false,
      data: {
        checkpointName: '',
        checkpointNameDisabled: false,
        search: '',
        address: '',
        description: '',
        adptid: null,
        quartier: undefined,
        lnglat: []
      }
    };
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this.loaderOn = true;
    this.getMissions(() => {
      this.getCircuits(() => {
        mapObj.data.lnglat = [this.circuits[0].circuitLongitude, this.circuits[0].circuitLatitude];
        this.mission.checkpoints.push(mapObj);
        console.log('2586',this.mission);
        this.checkpointMissionFiller(() => {
        });
        this.checkpointCircuitFiller(() => {
        });
        this.fillPullApiFields(this.mission.checkpoints.length - 1, () => {
        });
        if (this.mission.checkpoints.length !== 0) {
          this.event.hideLoader({});
          this.addNewCheckpointChecker();
          this.circuitsLoaded = true;
          this.loaderOn = false;
        }
      });
    });
  }

  addNewCheckpointChecker() {

    if (this.step2Completed) {
      if (this.mission.circuits[0].selectedMission.missionType.id === 3) {
        if (this.mission.checkpoints.length !== 0) {
          let numberOfCheckpoints;
          if (this.mission.checkpoints[0].selectedCircuit.circuitCheckpoints.length !== 0) {
            numberOfCheckpoints = this.mission.checkpoints.length + this.mission.checkpoints[0].selectedCircuit.circuitCheckpoints.length;
          } else {
            numberOfCheckpoints = this.mission.checkpoints.length;
          }
          if (numberOfCheckpoints < 3) {
            if (numberOfCheckpoints > 2) {
              this.showAddNewCheckpoint = false;
            } else {
              this.showAddNewCheckpoint = true;
            }
          } else {
            this.showAddNewCheckpoint = false;
          }
        } else {
          if (this.mission.checkpoints.length !== 0) {
            if (this.mission.checkpoints[0].selectedMission.missionType.id === 3) {
              let numberOfCheckpoints;
              if (this.mission.checkpoints[0].selectedCircuit.circuitCheckpoints.length !== 0) {
                numberOfCheckpoints = this.mission.checkpoints.length +
                  this.mission.checkpoints[0].selectedCircuit.circuitCheckpoints.length;
              } else {
                numberOfCheckpoints = this.mission.checkpoints.length;
              }
              if (numberOfCheckpoints < 3) {
                if (numberOfCheckpoints > 2) {
                  this.showAddNewCheckpoint = false;
                } else {
                  this.showAddNewCheckpoint = true;
                }
              }
            }
          }
        }
      }
    }

  }

  assignmentMapMaker() {
    console.log("assignmentmap maker");
    
    const mapObj = {
      selectedCheckpoint: {},
      selectedCheckpoints: [],
      checkpoints: [],
      tempCheckpoints: [],
      selectedShift: {},
      selectedShifts: [],
      shiftId: 1,
      shifts: [],
      fieldAgents: [],
      dates: [],
      selecteDate: '',
      selectedFieldAgent: {},
      data: {
        iterations: 0,
        lnglat: ['4.3517', '50.8503'],
      }
    };

    this.mission.assignments.push(mapObj);

    if (this.mission.assignments.length === 2) {
      this.showNewAssignmentBtn = false;
    }

    this.assignmentCheckpointsFiller(() => { });
    // this.getAllFieldAgents(() => {
    //   this.assignmentFieldAgentsFiller(() => {
    //     this.event.broadcast({ eventName: 'newAssignment', data: '' });
    //   });
    // });
    this.getAllShifts(() => {
      this.assignmentShiftsFiller(() => {
      });
    });

    this.getDatesForAssignment((dates) => {
      let len = dates.length;
      dates.forEach(date => {
        mapObj.dates.push(date.split(' ')[0]);
        len--;
        if (len === 0) {
          mapObj.selecteDate = mapObj.dates[0];
          mapObj.dates.splice(0, 1);
        }
      });
    });
    this.assignmentsLoaded = true;
  }

  assignmentMapCreator() {
    this.assignmentMapMaker();
  }

  toggleCheckpointForAssignment(checkpoint, i) {
    console.log("3135=",this.mission,checkpoint);
    
    if (!this.mission.assignments[i].selectedCheckpoints.includes(checkpoint)) {
      this.mission.assignments[i].selectedCheckpoints.push(checkpoint);
      this.mission.circuits[i].selectedCheckpoints.push(checkpoint)
    } else {
      let len = this.mission.assignments[i].selectedCheckpoints.length;
      let removeIndex = -1;
      this.mission.assignments[i].selectedCheckpoints.forEach((check, rmi) => {
        if (checkpoint === check) {
          removeIndex = rmi;
        }
        len--;
        if (len === 0) {
          this.mission.assignments[i].selectedCheckpoints.splice(removeIndex, 1);
        }
      });


      this.mission.circuits[0].selectedCheckpoints.forEach((check, rmi) => {
        if (checkpoint === check) {
          removeIndex = rmi;
        }
        len--;
        if (len === 0) {
          this.mission.circuits[0].selectedCheckpoints.splice(removeIndex, 1);
        }
      });
    }
  }

  toggleDontknowAdptIdCheckbox(i, event) {
    this.mission.checkpoints[i].countryLoaded = false;
    this.mission.checkpoints[i].regionLoaded = false;
    this.mission.checkpoints[i].communeLoaded = false;
    this.mission.checkpoints[i].postalCodeLoaded = false;
    this.mission.checkpoints[i].streetLoaded = false;
    this.mission.checkpoints[i].adrnLoaded = false;
    this.mission.checkpoints[i].adptid_valid = false;
    this.mission.checkpoints[i].data.adptid = null;
    this.mission.checkpoints[i].data.quartier = undefined;
    if (!this.mission.checkpoints[i].dontKnowAdptId) {
      this.fillPullApiFields(i, () => {

      });
    } else {
     
      if (this.checkpointMapGeoJSON.features.length < i) {
        this.checkpointMapGeoJSON.features.push({
          'type': 'Feature',
          'geometry': {
            'type': 'Point',
            'coordinates': [
              this.mission.checkpoints[i].selectedCircuit.circuitLongitude,
              this.mission.checkpoints[i].selectedCircuit.circuitLatitude
            ]
          },
          'existingCircuit':'false',
          'lnglat': [
            parseFloat(Number(this.mission.checkpoints[i].selectedCircuit.circuitLongitude).toFixed(20)),
            parseFloat(Number(this.mission.checkpoints[i].selectedCircuit.circuitLatitude).toFixed(20))
          ]
        });
        console.log('3342');
      } else {
        this.checkpointMapGeoJSON.features[i] = {
          'type': 'Feature',
          'geometry': {
            'type': 'Point',
            'coordinates': [
              this.mission.checkpoints[i].selectedCircuit.circuitLongitude,
              this.mission.checkpoints[i].selectedCircuit.circuitLatitude
            ]
          },
          'existingCircuit':'false',
          'lnglat': [
            parseFloat(Number(this.mission.checkpoints[i].selectedCircuit.circuitLongitude).toFixed(20)),
            parseFloat(Number(this.mission.checkpoints[i].selectedCircuit.circuitLatitude).toFixed(20))
          ]
        };
        if(this.market){
          this.checkpointMapGeoJSON.features.push({
            'type': 'Feature',
            'geometry': {
              'type': 'Point',
              'coordinates': [this.mission.markets[0].longitude,
              this.mission.markets[0].latitude]
            }, 
            'existingCircuit':'true',
            'isSearch': 'false',
            'lnglat': [
              parseFloat(Number(this.mission.markets[0].longitude).toFixed(20)),
              parseFloat(Number(this.mission.markets[0].latitude).toFixed(20))
            ],
            'checkpointName':'Market Zone'
          });
          }
          console.log('3373',this.checkpointMapGeoJSON);
      }
    }
  }

  getCountries(i, icb) {
    if (this.mission.checkpoints.length > 1 && i > 0) {
      this.mission.checkpoints[i].selected_country = this.mission.checkpoints[i - 1].selected_country;
      this.mission.checkpoints[i].countryLoaded = true;
      icb();
    } else {
      this._http.pullCountry().subscribe(res => {
        let countryLen = res.data['Geographic Data'].length;
        this.mission.checkpoints[i].coutries = [];
        res.data['Geographic Data'].forEach(country => {
          this.mission.checkpoints[i].coutries.push(country);
          countryLen--;
          if (countryLen === 0) {
            this.mission.checkpoints[i].selected_country = this.mission.checkpoints[i].coutries[0];
            this.mission.checkpoints[i].coutries.splice(0, 1);
            this.mission.checkpoints[i].countryLoaded = true;
            icb();
          }
        });
      }, err => {
      });
    }
  }

  getRegions(i, icb) {
    if (this.mission.checkpoints.length > 1 && i > 0) {
      this.mission.checkpoints[i].selected_region = this.mission.checkpoints[i - 1].selected_region;
      this.mission.checkpoints[i].regionLoaded = true;
      icb();
    } else {
      this._http.pullRegion(this.mission.checkpoints[i].selected_country.con_id).subscribe(reg => {
        if (reg.data['Geographic Data'].length !== 0) {
          let regionLen = reg.data['Geographic Data'].length;
          this.mission.checkpoints[i].regions = [];
          reg.data['Geographic Data'].forEach(region => {
            this.mission.checkpoints[i].regions.push(region);
            regionLen--;
            if (regionLen === 0) {
              this.mission.checkpoints[i].selected_region = this.mission.checkpoints[i].regions[0];
              this.mission.checkpoints[i].regions.splice(0, 1);
              this.mission.checkpoints[i].regionLoaded = true;
              icb();
            }
          });
        } else {
          this.pedestrainAlertsService.postCodeNotAvailableAlert();
          this.mission.checkpoints[i].data.adptid = null;
          this.mission.checkpoints[i].data.quartier = undefined;
        }
      }, err => {
      });
    }
  }

  getCommunes(i, icb) {
    // if (this.mission.checkpoints.length > 1 && i > 0) {
    //   this.mission.checkpoints[i].selected_commune = this.mission.checkpoints[i - 1].selected_commune;
    //   this.mission.checkpoints[i].communeLoaded = true;
    //   icb();
    // } else {
      this._http.pullCommune(this.mission.checkpoints[i].selected_region.reg_id).subscribe(com => {
        if (com.data['Geographic Data'].length !== 0) {
          let communeLen = com.data['Geographic Data'].length;
          this.mission.checkpoints[i].communes = [];
          com.data['Geographic Data'].forEach(commune => {
            this.mission.checkpoints[i].communes.push(commune);
            communeLen--;
            if (communeLen === 0) {
              this.mission.checkpoints[i].selected_commune = this.mission.checkpoints[i].communes[0];
              this.mission.checkpoints[i].communes.splice(0, 1);
              this.mission.checkpoints[i].communeLoaded = true;
              icb();
            }
          });
        } else {
          this.pedestrainAlertsService.postCodeNotAvailableAlert();
          this.mission.checkpoints[i].data.adptid = null;
          this.mission.checkpoints[i].data.quartier = undefined;
        }

      }, err => {
      });
    // }
  }

  getPostalCodes(i, icb) {
    // if (this.mission.checkpoints.length > 1 && i > 0) {
    //   this.mission.checkpoints[i].selected_postalcode = this.mission.checkpoints[i - 1].selected_postalcode;
    //   this.mission.checkpoints[i].postalCodeLoaded = true;
    //   icb();
    // } else {
      this._http.pullPostalCode(this.mission.checkpoints[i].selected_commune.com_id).subscribe(pcode => {
        if (pcode.data['Geographic Data'].length !== 0) {
          let pcodeLen = pcode.data['Geographic Data'].length;
          this.mission.checkpoints[i].postalcodes = [];
          pcode.data['Geographic Data'].forEach(postalCode => {
            this.mission.checkpoints[i].postalcodes.push(postalCode);
            pcodeLen--;
            if (pcodeLen === 0) {
              this.mission.checkpoints[i].selected_postalcode = this.mission.checkpoints[i].postalcodes[0];
              this.mission.checkpoints[i].postalcodes.splice(0, 1);
              this.mission.checkpoints[i].postalCodeLoaded = true;
              icb();
            }
          });
        } else {
          this.pedestrainAlertsService.postCodeNotAvailableAlert();
          this.mission.checkpoints[i].data.adptid = null;
          this.mission.checkpoints[i].data.quartier = undefined;
        }
      }, err => {
      });
    // }
  }

  getStreets(i, icb) {

    this._http.pullStreet(this.mission.checkpoints[i].selected_postalcode.adt_postal_code).subscribe(roads => {
      if (roads.data['Geographic Data'].length !== 0) {
        this.mission.checkpoints[i].streetSearchBucket = [];
        let roadsLen = roads.data['Geographic Data'].length;
        this.mission.checkpoints[i].streets = [];
        roads.data['Geographic Data'].forEach(street => {
          this.mission.checkpoints[i].streets.push(street);

          street.adt_street !== null ? this.mission.checkpoints[i].streetSearchBucket.push(street.adt_street) : '';
          roadsLen--;
          if (roadsLen === 0) {
            this.mission.checkpoints[i].selected_street = this.mission.checkpoints[i].streets[0];
            this.mission.checkpoints[i].streets.splice(0, 1);
            this.mission.checkpoints[i].streetSearch = (text$: Observable<string>) =>
              text$
                .debounceTime(200)
                .distinctUntilChanged()
                .map(
                  term =>
                    term === ''
                      ? []
                      : this.mission.checkpoints[i].streetSearchBucket
                        .filter(v =>
                          v.toLowerCase().indexOf(term.toLowerCase()) > -1)
                        .slice(0, 10)
                );
            this.mission.checkpoints[i].streetLoaded = true;
            icb();
          }
        });
      } else {
        this.pedestrainAlertsService.streetsNotAvailableAlert();
        this.mission.checkpoints[i].data.adptid = null;
        this.mission.checkpoints[i].data.quartier = undefined;
      }
    }, err => {
    });

  }

  getAdrns(i, icb) {
    this._http.pullAdrn(this.mission.checkpoints[i].selected_postalcode.adt_postal_code,
      this.mission.checkpoints[i].selected_street.adt_street).subscribe(ad => {
        if (ad.data['Geographic Data'].length !== 0) {
          this.mission.checkpoints[i].adrns = (filter(ad.data['Geographic Data'], (adrn) => {
            if (!isNull(adrn.adt_adrn)) return adrn;
          }));
          this.mission.checkpoints[i]['selected_adrn'] = this.mission.checkpoints[i].adrns[0];
          this.mission.checkpoints[i].adrns.splice(0, 1);
          this.mission.checkpoints[i].adrnLoaded = true;
          icb();
        } else {
          this.pedestrainAlertsService.adrnNotAvailableAlert();
          this.mission.checkpoints[i].data = { ...this.mission.checkpoints[i].data, adptid: null, quartier: undefined };
        }
      }, err => { });
  }

  getAdptId(i, icb) {

    this._http.pullAdptId(this.mission.checkpoints[i].selected_postalcode.adt_postal_code,
      this.mission.checkpoints[i].selected_street.adt_street,
      this.mission.checkpoints[i].selected_adrn.adt_adrn).subscribe(adpt => {
        if (adpt.data['Geographic Data'].length !== 0) {
          if (this.mission.checkpoints.length === 3) {
            const availableCheckpointsAdptids = [];
            let lent = this.mission.checkpoints.length;
            let letItGo = false;
            const countInArray = (array, what) => {
              return array.filter(item => item == what).length;
            };
            this.mission.checkpoints.forEach((checkp, inde) => {
              if (inde !== i) {
                availableCheckpointsAdptids.push(parseInt(checkp.data.adptid, 10));
                let count = countInArray(availableCheckpointsAdptids, checkp.data.adptid);
                if (count > 1) {
                  letItGo = true;
                }
              } else {
                availableCheckpointsAdptids.push(parseInt(adpt.data['Geographic Data'][0].adt_adptid, 10));
                let count = countInArray(availableCheckpointsAdptids, adpt.data['Geographic Data'][0].adt_adptid);
                if (count > 1) {
                  letItGo = true;
                }
              }
              lent--;
              if (lent === 0) {
                if (!letItGo && availableCheckpointsAdptids.length === 3) {
                  this._http.SecurePost('/checkpoint/validateCheckpoints', {
                    adptIds: availableCheckpointsAdptids
                  }).subscribe(res => {
                    this.pedestrainAlertsService.adptidsAlreadyExist()
                      .then(() => {

                        this.event.broadcast({ eventName: 'showLoader', data: '' });
                        if (this.mission.checkpoints.length === 3) {
                          console.log('2982');
                          this.mission.checkpoints.splice(2, 1);
                          this.showAddNewCheckpoint = true;
                          if (this.checkpointMapGeoJSON.features.length === 3) {
                            this.checkpointMapGeoJSON.features.splice(2, 1);
                          }
                          const formData = new FormData();
                          const XHR = new XMLHttpRequest();
                          formData.append('missionId', this.mission.checkpoints[0].selectedMission.missionId);
                          formData.append('existingCircuitId', res.data.circuitId);
                          formData.append('circuitId', this.mission.checkpoints[0].selectedCircuit.circuitId);
                          formData.append('circuitCreatedBy', res.data.circuitCreatedById);
                          formData.append('circuitUpdatedBy', this.user.userId);
                          formData.append(' locationId', '0');
                          formData.append('locationTypeId', '1');
                          XHR.addEventListener('load', (event) => {

                          });
                        
                          XHR.onreadystatechange = (aEvt) => {
                            if (XHR.readyState === 4) {
                              if (XHR.status === 200) {
                                const response = JSON.parse(XHR.response);
                                const circuitObject = {
                                  selectedMission: this.mission.checkpoints[0].selectedMission,
                                  missions: [],
                                  existingCircuitsCheck: true,
                                  existingCircuits: [],
                                  tempExistingCircuits: [],
                                  existingCircuitSearch: undefined,
                                  selectedExistingCircuit: res.data,
                                  checkpointsGeoJson: {
                                    'type': 'FeatureCollection',
                                    'features': [
                                      {
                                        'type': 'Feature',
                                        'geometry': {
                                          'type': 'Point',
                                          'coordinates': [res.data.circuitCheckpoints[0].checkpointLongitude,
                                          res.data.circuitCheckpoints[0].checkpointLatitude]
                                        },
                                        'lnglat': [parseFloat(Number(res.data.circuitCheckpoints[0].checkpointLongitude).toFixed(20)),
                                        parseFloat(Number(res.data.circuitCheckpoints[0].checkpointLatitude).toFixed(20))]
                                      },
                                      {
                                        'type': 'Feature',
                                        'geometry': {
                                          'type': 'Point',
                                          'coordinates': [res.data.circuitCheckpoints[1].checkpointLongitude,
                                          res.data.circuitCheckpoints[1].checkpointLatitude]
                                        },
                                        'lnglat': [parseFloat(Number(res.data.circuitCheckpoints[1].checkpointLongitude).toFixed(20)),
                                        parseFloat(Number(res.data.circuitCheckpoints[1].checkpointLatitude).toFixed(20))]
                                      },
                                      {
                                        'type': 'Feature',
                                        'geometry': {
                                          'type': 'Point',
                                          'coordinates': [res.data.circuitCheckpoints[2].checkpointLongitude,
                                          res.data.circuitCheckpoints[2].checkpointLatitude]
                                        },
                                        'lnglat': [parseFloat(Number(res.data.circuitCheckpoints[2].checkpointLongitude).toFixed(20)),
                                        parseFloat(Number(res.data.circuitCheckpoints[2].checkpointLatitude).toFixed(20))]
                                      }
                                    ]
                                  },
                                  data: {
                                    circuitName: '',
                                    search: '',
                                    lnglat: ['4.4699', '50.5039'],
                                    imageUploaded: true,
                                    progress: 0,
                                    uploadProgress: false
                                  }
                                };
                                this.mission.circuits = [];
                                this.mission.circuits.push(circuitObject);
                                this.populateExistingCheckpoints();
                                this.event.broadcast({
                                  eventName: 'hideLoader',
                                });
                                this.pedestrainAlertsService.circuitMappedSuccessAlert();
                              } else {
                                this.pedestrainAlertsService.somethingWentWrong();
                              }
                            }
                          };
                        
                          XHR.addEventListener('error', (event) => {
                            this.event.hideLoader({});
                            this.pedestrainAlertsService.somethingWentWrongQuestion();
                          });

                          XHR.open('POST', this.xmlHttpUrl + '/circuit/addCircuit');
                          XHR.setRequestHeader('Authorization', this.user.accessToken);
                          XHR.setRequestHeader('userId', this.user.userId);
                          XHR.send(formData);
                        }


                      })
                      .catch(() => {

                        this.pedestrainAlertsService.sameCheckPointsNotAllowedAlert()
                          .then(() => {
                            this.mission.checkpoints[i].data.checkpointName = undefined;
                            this.mission.checkpoints[i].data.adptid = null;
                          }).catch(() => {
                            this.mission.checkpoints[i].data.checkpointName = undefined;
                            this.mission.checkpoints[i].data.adptid = null;
                          });

                      });

                  }, err => {
                    this._http.SecureGet('/ref/getAllCheckpoints?adptId=' + parseInt(adpt.data['Geographic Data'][0].adt_adptid, 10)).subscribe(resp => {
                      this.mission.checkpoints[i].data.lnglat = [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                      adpt.data['Geographic Data'][0].adt_latitude_wgs84];
                      this.mission.checkpoints[i].data.adptid = 0;
                      this.mission.checkpoints[i].data.adptid = adpt.data['Geographic Data'][0].adt_adptid;
                      this.mission.checkpoints[i].data.checkpointName = resp.data.checkpoints[0].checkpointName;
                      this.mission.checkpoints[i].data.checkpointDescription = resp.data.checkpoints[0].checkpointDescription;
                      this.mission.checkpoints[i].data.checkpointNameDisabled = true;
                      this.mission.checkpoints[i].data.quartier =
                        adpt.data['Geographic Data'][0].qub_quartier_name_fr;
                      this.mission.checkpoints[i].data.address = adpt.data['Geographic Data'][0].adt_adrn + ', ' +
                        adpt.data['Geographic Data'][0].adt_street + ', ' +
                        adpt.data['Geographic Data'][0].com_commune_name_fr + ', ' +
                        adpt.data['Geographic Data'][0].reg_region_name_fr + ', ' +
                        adpt.data['Geographic Data'][0].adt_postal_code + ', ' +
                        adpt.data['Geographic Data'][0].con_country_name_fr;
                      this.mission.checkpoints[i].adptid_valid = true;
                      console.log('I am not selected');
                      if (this.checkpointMapGeoJSON.features.length >= i + 1) {
                        this.checkpointMapGeoJSON.features[i] = {
                          'type': 'Feature',
                          'geometry': {
                            'type': 'Point', 'coordinates':
                              [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                              adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                          },
                          'existingCircuit':'false',
                          'lnglat': [
                            parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                            parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                          ]
                        };
                        console.log(this.checkpointNames);
                        if(this.market){
                          this.checkpointMapGeoJSON.features.push({
                            'type': 'Feature',
                            'geometry': {
                              'type': 'Point',
                              'coordinates': [this.mission.markets[0].longitude,
                              this.mission.markets[0].latitude]
                            },
                            'existingCircuit':'true',
                            'isSearch': 'false',
                            'lnglat': [
                              parseFloat(Number(this.mission.markets[0].longitude).toFixed(20)),
                              parseFloat(Number(this.mission.markets[0].latitude).toFixed(20))
                            ],
                            'checkpointName':'Market Zone'
                          });
                          }
                          console.log('3752');
                      } else {
                        this.checkpointMapGeoJSON.features.push({
                          'type': 'Feature',
                          'geometry': {
                            'type': 'Point', 'coordinates':
                              [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                              adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                          },
                          'existingCircuit':'false',
                          'lnglat': [
                            parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                            parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                          ]
                        });
                        console.log('3766');
                      }

                      this.checkpointMap.flyTo({
                        center: [
                          adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                          adpt.data['Geographic Data'][0].adt_latitude_wgs84
                        ],
                        zoom: 9,
                        bearing: 0,
                        curve: 1
                      });
                      
                      console.log('Checkpoint', this.mission.checkpoints);
                      icb();
                    }, err1 => {
                      this.mission.checkpoints[i].data.lnglat = [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                      adpt.data['Geographic Data'][0].adt_latitude_wgs84];
                      this.mission.checkpoints[i].data.adptid = 0;
                      this.mission.checkpoints[i].data.adptid = adpt.data['Geographic Data'][0].adt_adptid;
                      this.mission.checkpoints[i].data.quartier =
                        adpt.data['Geographic Data'][0].qub_quartier_name_fr;
                      this.mission.checkpoints[i].data.checkpointName = '';
                      this.mission.checkpoints[i].data.checkpointNameDisabled = false;
                      this.mission.checkpoints[i].data.checkpointDescription = '';
                      this.mission.checkpoints[i].data.address = adpt.data['Geographic Data'][0].adt_adrn + ', ' +
                        adpt.data['Geographic Data'][0].adt_street + ', ' +
                        adpt.data['Geographic Data'][0].com_commune_name_fr + ', ' +
                        adpt.data['Geographic Data'][0].reg_region_name_fr + ', ' +
                        adpt.data['Geographic Data'][0].adt_postal_code + ', ' +
                        adpt.data['Geographic Data'][0].con_country_name_fr;
                      this.mission.checkpoints[i].adptid_valid = true;
                      if (this.checkpointMapGeoJSON.features.length >= i + 1) {
                        this.checkpointMapGeoJSON.features[i] = {
                          'type': 'Feature',
                          'geometry': {
                            'type': 'Point', 'coordinates':
                              [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                              adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                          },
                          'existingCircuit':'false',
                          'lnglat': [
                            parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                            parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                          ]
                        };
                        console.log('3811');
                      } else {
                        this.checkpointMapGeoJSON.features.push({
                          'type': 'Feature',
                          'geometry': {
                            'type': 'Point', 'coordinates':
                              [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                              adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                          },
                          'existingCircuit':'false',
                          'lnglat': [
                            parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                            parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                          ]
                        });
                        console.log('3825');
                      }

                      this.checkpointMap.flyTo({
                        center: [
                          adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                          adpt.data['Geographic Data'][0].adt_latitude_wgs84
                        ],
                        zoom: 9,
                        bearing: 0,
                        curve: 1
                      });
                      console.log('Checkpoint', this.mission.checkpoints);
                      icb();
                    });

                  });
                } else {
                  this._http.SecureGet('/ref/getAllCheckpoints?adptId=' + parseInt(adpt.data['Geographic Data'][0].adt_adptid, 10)).subscribe(resp => {
                    this.mission.checkpoints[i].data.lnglat = [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                    adpt.data['Geographic Data'][0].adt_latitude_wgs84];
                    this.mission.checkpoints[i].data.adptid = 0;
                    this.mission.checkpoints[i].data.adptid = adpt.data['Geographic Data'][0].adt_adptid;
                    this.mission.checkpoints[i].data.checkpointName = resp.data.checkpoints[0].checkpointName;
                    this.mission.checkpoints[i].data.checkpointDescription = resp.data.checkpoints[0].checkpointDescription;
                    this.mission.checkpoints[i].data.checkpointNameDisabled = true;
                    this.mission.checkpoints[i].data.quartier =
                      adpt.data['Geographic Data'][0].qub_quartier_name_fr;
                    this.mission.checkpoints[i].data.address = adpt.data['Geographic Data'][0].adt_adrn + ', ' +
                      adpt.data['Geographic Data'][0].adt_street + ', ' +
                      adpt.data['Geographic Data'][0].com_commune_name_fr + ', ' +
                      adpt.data['Geographic Data'][0].reg_region_name_fr + ', ' +
                      adpt.data['Geographic Data'][0].adt_postal_code + ', ' +
                      adpt.data['Geographic Data'][0].con_country_name_fr;
                    this.mission.checkpoints[i].adptid_valid = true;
                    if (this.checkpointMapGeoJSON.features.length >= i + 1) {
                      this.checkpointMapGeoJSON.features[i] = {
                        'type': 'Feature',
                        'geometry': {
                          'type': 'Point', 'coordinates':
                            [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                            adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                        },
                        'existingCircuit':'false',
                        'lnglat': [
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                        ]
                      };
                      console.log('3873');
                    } else {
                      this.checkpointMapGeoJSON.features.push({
                        'type': 'Feature',
                        'geometry': {
                          'type': 'Point', 'coordinates':
                            [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                            adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                        },
                        'existingCircuit':'false',
                        'lnglat': [
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                        ]
                      });
                      console.log('3887');
                    }

                    this.checkpointMap.flyTo({
                      center: [
                        adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                        adpt.data['Geographic Data'][0].adt_latitude_wgs84
                      ],
                      zoom: 9,
                      bearing: 0,
                      curve: 1
                    });
                    console.log('Checkpoint', this.mission.checkpoints);
                    icb();
                  }, err1 => {
                    this.mission.checkpoints[i].data.lnglat = [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                    adpt.data['Geographic Data'][0].adt_latitude_wgs84];
                    this.mission.checkpoints[i].data.adptid = 0;
                    this.mission.checkpoints[i].data.adptid = adpt.data['Geographic Data'][0].adt_adptid;
                    this.mission.checkpoints[i].data.quartier =
                      adpt.data['Geographic Data'][0].qub_quartier_name_fr;
                    this.mission.checkpoints[i].data.checkpointName = '';
                    this.mission.checkpoints[i].data.checkpointNameDisabled = false;
                    this.mission.checkpoints[i].data.checkpointDescription = '';
                    this.mission.checkpoints[i].data.address = adpt.data['Geographic Data'][0].adt_adrn + ', ' +
                      adpt.data['Geographic Data'][0].adt_street + ', ' +
                      adpt.data['Geographic Data'][0].com_commune_name_fr + ', ' +
                      adpt.data['Geographic Data'][0].reg_region_name_fr + ', ' +
                      adpt.data['Geographic Data'][0].adt_postal_code + ', ' +
                      adpt.data['Geographic Data'][0].con_country_name_fr;
                    this.mission.checkpoints[i].adptid_valid = true;
                    if (this.checkpointMapGeoJSON.features.length >= i + 1) {
                      this.checkpointMapGeoJSON.features[i] = {
                        'type': 'Feature',
                        'geometry': {
                          'type': 'Point', 'coordinates':
                            [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                            adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                        },
                        'existingCircuit':'false',
                        'lnglat': [
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                        ]
                      };
                      console.log('3931');
                    } else {
                      this.checkpointMapGeoJSON.features.push({
                        'type': 'Feature',
                        'geometry': {
                          'type': 'Point', 'coordinates':
                            [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                            adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                        },
                        'existingCircuit':'false',
                        'lnglat': [
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                          parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                        ]
                      });
                      console.log('3945');
                    }

                    this.checkpointMap.flyTo({
                      center: [
                        adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                        adpt.data['Geographic Data'][0].adt_latitude_wgs84
                      ],
                      zoom: 9,
                      bearing: 0,
                      curve: 1
                    });
                    console.log('Checkpoint', this.mission.checkpoints);
                    icb();
                  });
                }
              }
            });
          } else {
            this._http.SecureGet('/ref/getAllCheckpoints?adptId=' + parseInt(adpt.data['Geographic Data'][0].adt_adptid, 10)).subscribe(resp => {
              this.mission.checkpoints[i].data.lnglat = [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
              adpt.data['Geographic Data'][0].adt_latitude_wgs84];
              this.mission.checkpoints[i].data.adptid = 0;
              this.mission.checkpoints[i].data.adptid = adpt.data['Geographic Data'][0].adt_adptid;
              this.mission.checkpoints[i].data.checkpointName = resp.data.checkpoints[0].checkpointName;
              this.mission.checkpoints[i].data.checkpointDescription = resp.data.checkpoints[0].checkpointDescription;
              this.mission.checkpoints[i].data.checkpointNameDisabled = true;
              this.mission.checkpoints[i].data.quartier =
                adpt.data['Geographic Data'][0].qub_quartier_name_fr;
              this.mission.checkpoints[i].data.address = adpt.data['Geographic Data'][0].adt_adrn + ', ' +
                adpt.data['Geographic Data'][0].adt_street + ', ' +
                adpt.data['Geographic Data'][0].com_commune_name_fr + ', ' +
                adpt.data['Geographic Data'][0].reg_region_name_fr + ', ' +
                adpt.data['Geographic Data'][0].adt_postal_code + ', ' +
                adpt.data['Geographic Data'][0].con_country_name_fr;
              this.mission.checkpoints[i].adptid_valid = true;
              if (this.checkpointMapGeoJSON.features.length >= i + 1) {
                this.checkpointMapGeoJSON.features[i] = {
                  'type': 'Feature',
                  'geometry': {
                    'type': 'Point', 'coordinates':
                      [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                      adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                  },
                  'existingCircuit':'false',
                  'lnglat': [
                    parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                    parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                  ]
                };
                console.log('3993');
              } else {
                this.checkpointMapGeoJSON.features.push({
                  'type': 'Feature',
                  'geometry': {
                    'type': 'Point', 'coordinates':
                      [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                      adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                  },
                  'existingCircuit':'false',
                  'lnglat': [
                    parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                    parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                  ]
                });
                console.log('4008');
              }

              this.checkpointMap.flyTo({
                center: [
                  adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                  adpt.data['Geographic Data'][0].adt_latitude_wgs84
                ],
                zoom: 9,
                bearing: 0,
                curve: 1
              });
              console.log('Checkpoint', this.mission.checkpoints);
              icb();
            }, err1 => {
              this.mission.checkpoints[i].data.lnglat = [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
              adpt.data['Geographic Data'][0].adt_latitude_wgs84];
              this.mission.checkpoints[i].data.adptid = 0;
              this.mission.checkpoints[i].data.adptid = adpt.data['Geographic Data'][0].adt_adptid;
              this.mission.checkpoints[i].data.quartier =
                adpt.data['Geographic Data'][0].qub_quartier_name_fr;
              this.mission.checkpoints[i].data.checkpointName = '';
              this.mission.checkpoints[i].data.checkpointNameDisabled = false;
              this.mission.checkpoints[i].data.checkpointDescription = '';
              this.mission.checkpoints[i].data.address = adpt.data['Geographic Data'][0].adt_adrn + ', ' +
                adpt.data['Geographic Data'][0].adt_street + ', ' +
                adpt.data['Geographic Data'][0].com_commune_name_fr + ', ' +
                adpt.data['Geographic Data'][0].reg_region_name_fr + ', ' +
                adpt.data['Geographic Data'][0].adt_postal_code + ', ' +
                adpt.data['Geographic Data'][0].con_country_name_fr;
              this.mission.checkpoints[i].adptid_valid = true;
              if (this.checkpointMapGeoJSON.features.length >= i + 1) {
                this.checkpointMapGeoJSON.features[i] = {
                  'type': 'Feature',
                  'geometry': {
                    'type': 'Point', 'coordinates':
                      [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                      adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                  },
                  'existingCircuit':'false',
                  'lnglat': [
                    parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                    parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                  ]
                };
                console.log('4052');
              } else {
                this.checkpointMapGeoJSON.features.push({
                  'type': 'Feature',
                  'geometry': {
                    'type': 'Point', 'coordinates':
                      [adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                      adpt.data['Geographic Data'][0].adt_latitude_wgs84]
                  },
                  'existingCircuit':'false',
                  'lnglat': [
                    parseFloat(Number(adpt.data['Geographic Data'][0].adt_longitude_wgs84).toFixed(20)),
                    parseFloat(Number(adpt.data['Geographic Data'][0].adt_latitude_wgs84).toFixed(20))
                  ],
                  
                });
                console.log('4067');
              }

              this.checkpointMap.flyTo({
                center: [
                  adpt.data['Geographic Data'][0].adt_longitude_wgs84,
                  adpt.data['Geographic Data'][0].adt_latitude_wgs84
                ],
                zoom: 9,
                bearing: 0,
                curve: 1
              });
              // console.log('Checkpoint', this.mission.checkpoints);
              icb();
            });
          }
        } else {
          this.pedestrainAlertsService.adptidNotAvailable();
          this.mission.checkpoints[i].data.adptid = null;
          this.mission.checkpoints[i].data.quartier = undefined;
        }
      }, err => {
      });
  }



  fillPullApiFields(i, cb) {
    this.getCountries(i, () => {
      this.getRegions(i, () => {
        this.getCommunes(i, () => {
          this.getPostalCodes(i, () => {
            this.getStreets(i, () => {
              this.getAdrns(i, () => {
                this.getAdptId(i, () => {
                });
              });
            });
          });
        });
      });
    });

  }

  /* ***********************  DOM Flags Manipulators  **********************************
    open(page)
    checkAndOpen(page)
    skip(currStep)
    saveAndOpen(page, form)
    dontDoAnything()
    onItemRemoved(e, assignmentI)
    add2CheckpointsArray()
  */
  assignments;
  assignments2;
  checkpoints=[]
  open(page) {
    if ((page === 2 && this.prev === 1 && this.pageOpenAllowed) || (page === 2 && this.step2)) {
      this.step2 = true;
      if (this.prev === 1) {
        if (this.mission.circuits.length === 0) {
          this.circuitMapCreator();
        } else {
          this.circuitMapUpdater();
        }
      }
      this.prev = 2;
      this.hideStep1 = true;
      this.hideStep3 = true;
      this.hideStep4 = true;
      this.hideStep5 = true;
      this.hideStep2 = false;
      this.pageOpenAllowed = false;
    } else if ((page === 3 && this.prev === 2 && this.pageOpenAllowed) || (page === 3 && this.step3)) {
      this.step3 = true;
      if (this.prev === 2) {
        if (this.mission.checkpoints.length === 0) {
          console.log('hi');
          this.checkpointMapCreator();
        }
      }
      this.prev = 3;
      this.hideStep1 = true;
      this.hideStep2 = true;
      this.hideStep4 = true;
      this.hideStep5 = true;
      this.hideStep3 = false;
      this.pageOpenAllowed = false;
      console.log('3607',this.mission.circuits);
    } else if ((page === 4 && this.prev === 3 && this.pageOpenAllowed) || (page === 4 && this.step4)) {
      this.step4 = true;
      this.hideStep3=true;
      // console.log("this.mission.assignments=",this.mission.assignments[0]);
      
      // console.log("this.mission.assignments[0]=",this.mission.assignments[0]);
      if(this.useExisting){
        this.assignments=[this.mission.assignments[0]]
        this.assignments2=this.assignments

      } else {
        this.checkpoints=[]
        console.log("this.mission=",this.mission);
        this.assignments=[this.mission.checkpoints[0]]

        this.mission.checkpoints.forEach((element)=>{
          console.log("element=",element.data.checkpointName);
          this.checkpoints.push(element.data.checkpointName)
          
          // element.selectedCheckpoint.push(element.data.checkpointName)
        })
        console.log("this.mission=",this.mission);

        this.assignments2=this.assignments
        
      }
      this.assignmentMapCreator();
      // if (this.prev === 3) {
      //   console.log("this.mission.assignments=",this.mission.assignments);
        
      //   // if (this.mission.assignments.length === 0) {
      //   //   this.assignmentMapCreator();
      //   // }
      // }
      this.prev = 4;
      this.hideStep1 = true;
      this.hideStep3 = true;
      this.hideStep2 = true;
      this.hideStep5 = true;
      this.hideStep4 = false;
      this.pageOpenAllowed = false;
    } else if ((page === 5 && this.prev === 4 && this.pageOpenAllowed) || (page === 5 && this.step5)) {
      this.step5 = true;
      this.prev = 5;
      this.hideStep1 = true;
      this.hideStep3 = true;
      this.hideStep4 = true;
      this.hideStep2 = true;
      this.hideStep5 = false;
      this.showStep5 = true;
      this.pageOpenAllowed = false;
    } else if (page === 1 && this.step1 && this.pageOpenAllowed) {
      this.step1 = true;
      this.prev = 1;
      this.hideStep2 = true;
      this.hideStep3 = true;
      this.hideStep4 = true;
      this.hideStep5 = true;
      this.hideStep1 = false;
      this.pageOpenAllowed = false;
    }
  }

  checkAndOpen(page) { // on click of wizard this fuction decides if allow access can go to utils
    if ((page === 1 && this.step1) || (page === 2 && this.step2) ||
      (page === 3 && this.step3) || (page === 4 && this.step4) || (page === 5 && this.step5)) {
      this.pageOpenAllowed = true;
      if (page === 3) {
        if (this.step3Completed) {
          this.checkpointMap.flyTo({
            center: [this.checkpointMapGeoJSON.features[0].geometry.coordinates[0],
            this.checkpointMapGeoJSON.features[0].geometry.coordinates[1]],
            zoom: 9,
            bearing: 0,
            curve: 1
          });
        }
      }
    }
    if (page === 1 && this.step2) {
      if (!this.step2Completed && !this.step1Completed) {
        this.pageOpenAllowed = true;
        this.step1 = false;
      } else if (this.step2Completed && this.step1Completed) {
        this.pageOpenAllowed = true;
        this.step1 = true;
      } else if (this.step1Completed && !this.step2Completed) {
        this.pageOpenAllowed = true;
        this.step1 = true;
      } else {
        this.pageOpenAllowed = false;
        this.step1 = false;
      }
    } else if (page === 2 && this.step3) {
      let len = this.missions.length;
      const checkarray = [];
      this.missions.forEach(mission => {
        if (mission.missionType.id === 3) {
          if (mission.missionCircuits.length === 1) {
            checkarray.push(true);
          }
        } else {
          checkarray.push(false);
        }
        len--;
        if (len === 0) {
          if (checkarray.includes(false)) {
            if (!this.step3Completed && !this.step2Completed) {
              this.pageOpenAllowed = true;
              this.step2 = true;
            } else if (this.step3Completed && this.step2Completed) {
              this.pageOpenAllowed = true;
              this.step2 = true;
            } else if (!this.step3Completed && this.step2Completed) {
              this.pageOpenAllowed = true;
              this.step2 = true;
            } else {
              this.pageOpenAllowed = false;
              this.step2 = false;
            }
          } else {
            if (this.step2Completed) {
              this.pageOpenAllowed = true;
              this.step2 = true;
            } else {
              this.pageOpenAllowed = false;
              this.step2 = false;
            }
          }
        }
      });
    } else if (page === 3) {
      if (this.step3Completed) {
        this.checkpointMap.flyTo({
          center: [this.checkpointMapGeoJSON.features[0].geometry.coordinates[0],
          this.checkpointMapGeoJSON.features[0].geometry.coordinates[1]],
          zoom: 9,
          bearing: 0,
          curve: 1
        })
      }
    }
    this.open(page);
  }

  skip(currStep) { // can go to util decides where the user go after click
    if (currStep === 1) {
      console.log(currStep);
      this.step1 = false;
      this.step2 = true;
      this.hideStep1 = true;
      this.hideStep3 = true;
      this.hideStep4 = true;
      this.hideStep5 = true;
      this.hideStep2 = false;
      if (this.prev === 1) {
        if (this.mission.circuits.length === 0) {
          this.event.broadcast({ eventName: 'showLoader', data: '' });
          this.circuitMapCreator();
          this.validateCircuits(valid => {
            if (valid) {
              this.showskipin2 = true;
            } else {
              this.showskipin2 = false;
            }
          });
          this.prev = 2;
        } else {
          this.prev = 2;
        }
      }
      // this.rd.setStyle(this.stepOne.nativeElement, 'cursor', 'pointer', 1);
    } else if (currStep === 2) {
      if (this.prev === 2) {
        if (this.missions.length === 0) {
          this.event.broadcast({ eventName: 'showLoader', data: '' });
          this.step3 = true;
          this.hideStep2 = true;
          this.hideStep1 = true;
          this.hideStep4 = true;
          this.hideStep5 = true;
          this.hideStep3 = false;
          this.showMissionsInCheckpoint = true;
          if (this.existingCircuitsCheck === true) {
            this.existingCircuitsCheck = false;
            this.checkpointMapGeoJSON.features = [];
            this.mission.checkpoints = [];
            this.geojson.features = [];
          }
          if (this.mission.checkpoints.length === 0) {
            this.checkpointMapCreator();
          } else {
            this.event.hideLoader({});
          }
          this.prev = 3;
          this.rd.setStyle(this.stepTwo.nativeElement, 'cursor', 'pointer', 1);
          this.step2 = false;
        } else {
          this.event.broadcast({ eventName: 'showLoader', data: '' });
          if (this.existingCircuitsCheck === true) {
            this.existingCircuitsCheck = false;
            this.checkpointMapGeoJSON.features = [];
            this.mission.checkpoints = [];
            this.geojson.features = [];
          }
          this.validateCircuits((valid) => {
            if (valid) {
              this.step3 = true;
              this.hideStep2 = true;
              this.hideStep1 = true;
              this.hideStep4 = true;
              this.hideStep5 = true;
              this.hideStep3 = false;
              this.showMissionsInCheckpoint = true;
              if (this.mission.checkpoints.length === 0) {
                this.checkpointMapCreator();
              } else {
                this.event.hideLoader({});
              }
              this.prev = 3;
              this.rd.setStyle(this.stepTwo.nativeElement, 'cursor', 'pointer', 1);
              this.step2 = false;
            } else {
              this.event.hideLoader({});
              this.pedestrainAlertsService.pleaseAddCircuitWarningAlert();
            }
          });
        }
      }
    }
  }

  saveAndOpen(page, form) {
    console.log("page=",page);
    
    if (page === 1) {
      if (form.valid) {
        console.log("form valid");
        
        this.createMission(form);
        // if (this.selectedMissionType.id === 3) {
        //   if (this.mission.missionStartDate.day != null) {
        //     this.createMission(form);
        //     this.showskipin2 = false;
        //   } else {
        //     // this.pedestrainAlertsService.datesMandatoryAlert().then(() => { }).catch(() => { });
        //   }
        // } else {
        //   if (this.mission.missionStartDate.day != null && this.mission.missionEndDate.day != null) {
        //     this.createMission(form);
        //     this.showskipin2 = false;
        //   } else {
        //     // this.pedestrainAlertsService.datesMandatoryAlert().then(() => { }).catch(() => { });
        //   }
        // }
      } else {
        // this.pedestrainAlertsService.dateMandatoryAlert().then(() => { }).catch(() => { });
      }
    } else if (page === 2) {
      this.circuitFormChecker(() => {
        this.createCircuit();
      });
      this.dontshowskipin3 = false;
    } else if (page === 3) {
      this.checkpointFormChecker(() => {
        this.createCheckpoint();
        this.getMissionDates();

      });
      this.dontshowskipin3 = false;
     

    } else if (page === 4) {
      localStorage.removeItem('missonNameExist');
      // this.assignmentFormChecker(() => {
        this.createAssignment();
      // });
    }
  }

  dontDoAnything() {
    return false;
  }

  onItemRemoved(e, i) {
    if (this.mission.assignments[i].selectedCheckpoint.data.checkpointName === 'No more checkpoints') {
      this.mission.assignments[i].tempCheckpoints.forEach(check => {
        if (check.data.checkpointName === e) {
          this.mission.assignments[i].selectedCheckpoint = check;
        }
      });
    } else {
      this.mission.assignments[i].tempCheckpoints.forEach(check => {
        if (check.data.checkpointName === e) {
          this.mission.assignments[i].checkpoints.push(check);
        }
      });
    }
  }

  onShiftRemoved(e, i) {
    this.shifts.forEach(shift => {
      if (shift.timeRange === e) {
        if (shift.timeRange === '10:00 - 12:30' && this.mission.assignments[i].shiftId === 1) {
          this.mission.assignments[i].data.iterations = this.mission.assignments[i].data.iterations - 5;
          this.mission.assignments[i].shifts.push(shift);
        } else if (shift.timeRange === '12:30 - 14:30' && this.mission.assignments[i].shiftId === 1) {
          this.mission.assignments[i].data.iterations = this.mission.assignments[i].data.iterations - 4;
          this.mission.assignments[i].shifts.push(shift);
        } else if (shift.timeRange === '14:30 - 16:30' && this.mission.assignments[i].shiftId === 2) {
          this.mission.assignments[i].data.iterations = this.mission.assignments[i].data.iterations - 4;
          this.mission.assignments[i].shifts.push(shift);
        } else if (shift.timeRange === '16:30 - 19:00' && this.mission.assignments[i].shiftId === 2) {
          this.mission.assignments[i].data.iterations = this.mission.assignments[i].data.iterations - 5;
          this.mission.assignments[i].shifts.push(shift);
        } else if (shift.timeRange === '10:00 - 12:30' && this.mission.assignments[i].shiftId !== 1) {
          this.mission.assignments[i].data.iterations = this.mission.assignments[i].data.iterations - 5;
        } else if (shift.timeRange === '12:30 - 14:30' && this.mission.assignments[i].shiftId !== 1) {
          this.mission.assignments[i].data.iterations = this.mission.assignments[i].data.iterations - 4;
        } else if (shift.timeRange === '14:30 - 16:30' && this.mission.assignments[i].shiftId !== 2) {
          this.mission.assignments[i].data.iterations = this.mission.assignments[i].data.iterations - 4;
        } else if (shift.timeRange === '16:30 - 19:00' && this.mission.assignments[i].shiftId !== 2) {
          this.mission.assignments[i].data.iterations = this.mission.assignments[i].data.iterations - 5;
        }
      }
    });
  }

  add2CheckpointsArray(checkpoint, i) {
    console.log("4342=",this.mission,checkpoint);
    
    if (this.mission.assignments[i].checkpoints.length === 0) {
      if (this.mission.assignments[i].selectedCheckpoint.data.checkpointName !== 'No more checkpoints') {
        this.mission.assignments[i].selectedCheckpoints.push(this.mission.assignments[i].selectedCheckpoint.data.checkpointName);
        this.mission.assignments[i].selectedCheckpoint = {
          data: {
            checkpointName: 'No more checkpoints'
          }
        };
      } else {
        this.mission.assignments[i].selectedCheckpoint.data.checkpointName = 'No more checkpoints';
      }
    } else {
      this
      this.mission.assignments[i].selectedCheckpoints.push(this.mission.assignments[i].selectedCheckpoint.data.checkpointName);
      this.mission.assignments[i].selectedCheckpoint = this.mission.assignments[i].checkpoints[0];
      this.mission.assignments[i].checkpoints.splice(0, 1);
    }
  }

  add2ShiftsArray(shift, i) {
    if (this.mission.assignments[i].selectedShifts.length < 2) {
      if (shift.shiftName === 'Morning') {
        if (shift.timeRange === '10:00 - 12:30') {
          if (this.mission.assignments[i].data.iterations !== 5) {
            if (this.mission.assignments[i].shifts.length === 1 && this.mission.assignments[i].shifts[0].shiftName === 'Morning') {
              this.mission.assignments[i].data.iterations = this.mission.assignments[i].data.iterations + 5;
              this.mission.assignments[i].selectedShifts.push(this.mission.assignments[i].selectedShift.timeRange);
              this.mission.assignments[i].selectedShift = {};
              if (this.mission.assignments[i].shifts.length !== 0) {
                this.mission.assignments[i].shifts.forEach((sh, ind) => {
                  if (sh.shiftName === 'Morning') {
                    this.mission.assignments[i].selectedShift = sh;
                    this.mission.assignments[i].shifts.splice(ind, 1);
                  }
                });
              }
            } else {
              this.pedestrainAlertsService.sameShiftCanNotAssigned();
            }
          } else {
            this.pedestrainAlertsService.sameShiftIteration();
          }
        } else if (shift.timeRange === '12:30 - 14:30') {
          if (this.mission.assignments[i].data.iterations !== 4) {
            if (this.mission.assignments[i].shifts.length === 1 && this.mission.assignments[i].shifts[0].shiftName === 'Morning') {
              this.mission.assignments[i].data.iterations = this.mission.assignments[i].data.iterations + 4;
              this.mission.assignments[i].selectedShifts.push(this.mission.assignments[i].selectedShift.timeRange);
              this.mission.assignments[i].selectedShift = {};
              if (this.mission.assignments[i].shifts.length !== 0) {
                this.mission.assignments[i].shifts.forEach((sh, ind) => {
                  if (sh.shiftName === 'Morning') {
                    this.mission.assignments[i].selectedShift = sh;
                    this.mission.assignments[i].shifts.splice(ind, 1);
                  }
                });
              }
            } else {
              this.pedestrainAlertsService.sameShiftCanNotAssigned();
            }
          } else {
            this.pedestrainAlertsService.sameShiftIteration();
          }
        }
      } else if (shift.shiftName === 'Afternoon') {
        if (shift.timeRange === '14:30 - 16:30') {
          if (this.mission.assignments[i].data.iterations !== 4) {
            if (this.mission.assignments[i].shifts.length === 1 && this.mission.assignments[i].shifts[0].shiftName === 'Afternoon') {
              this.mission.assignments[i].data.iterations = this.mission.assignments[i].data.iterations + 4;
              this.mission.assignments[i].selectedShifts.push(this.mission.assignments[i].selectedShift.timeRange);
              this.mission.assignments[i].selectedShift = {};
              if (this.mission.assignments[i].shifts.length !== 0) {
                this.mission.assignments[i].shifts.forEach((sh, ind) => {
                  if (sh.shiftName === 'Afternoon') {
                    this.mission.assignments[i].selectedShift = sh;
                    this.mission.assignments[i].shifts.splice(ind, 1);
                  }
                });
              }
            } else {
              this.pedestrainAlertsService.sameShiftCanNotAssigned();
            }
          } else {
            this.pedestrainAlertsService.sameShiftIteration();
          }
        } else if (shift.timeRange === '16:30 - 19:00') {
          if (this.mission.assignments[i].data.iterations !== 5) {
            if (this.mission.assignments[i].shifts.length === 1 && this.mission.assignments[i].shifts[0].shiftName === 'Afternoon') {
              this.mission.assignments[i].data.iterations = this.mission.assignments[i].data.iterations + 5;
              this.mission.assignments[i].selectedShifts.push(this.mission.assignments[i].selectedShift.timeRange);
              this.mission.assignments[i].selectedShift = {};
              if (this.mission.assignments[i].shifts.length !== 0) {
                this.mission.assignments[i].shifts.forEach((sh, ind) => {
                  if (sh.shiftName === 'Afternoon') {
                    this.mission.assignments[i].selectedShift = sh;
                    this.mission.assignments[i].shifts.splice(ind, 1);
                  }
                });
              }
            } else {
              this.pedestrainAlertsService.sameShiftCanNotAssigned();
            }
          } else {
            this.pedestrainAlertsService.sameShiftIteration();
          }
        }
      }
    }
  }

  goBack() {
    this.location.back();
  }

  viewSummary(cb) {
    this.summary.mission = this.mission.checkpoints[0].selectedMission;
    let checklen = this.mission.checkpoints.length;
    const pushArray = [];
    if(this.market){
          this.mission.checkpoints.forEach(checkpoint => {
            this.mission.markets.push({
              longitude: checkpoint.selectedCircuit.longitude,
              latitude: checkpoint.selectedCircuit.latitude
            });
            checkpoint.selectedCircuit.checkpointsGeoJson=this.mission.circuits[0].checkpointsGeoJson;
            checkpoint.selectedCircuit.existingCircuitsCheck=this.mission.circuits[0].existingCircuitsCheck;
            if (!pushArray.includes(checkpoint.selectedCircuit.circuitId)) {
              pushArray.push(checkpoint.selectedCircuit.circuitId);
              this.summary.circuits.push(checkpoint.selectedCircuit);
            }
            this.summary.checkpoints.push(checkpoint);
            checklen--;
            if (checklen === 0) {
              let assiLen = this.mission.assignments.length;
              this.mission.assignments.forEach(assignment => {
                this.summary.assignments.push(assignment);
                assiLen--;
                if (assiLen === 0) {
                  cb();
                }
              });
            }
          });
          console.log('4008',this.summary.circuits);
    }else{
    this.mission.checkpoints.forEach(checkpoint => {
      checkpoint.selectedCircuit.checkpointsGeoJson=this.mission.circuits[0].checkpointsGeoJson;
      checkpoint.selectedCircuit.existingCircuitsCheck=this.mission.circuits[0].existingCircuitsCheck;
      if (!pushArray.includes(checkpoint.selectedCircuit.circuitId)) {
        pushArray.push(checkpoint.selectedCircuit.circuitId);
        this.summary.circuits.push(checkpoint.selectedCircuit);
        console.log('4454',this.summary.circuits);
      }
      this.summary.checkpoints.push(checkpoint);
      checklen--;
      if (checklen === 0) {
        let assiLen = this.mission.assignments.length;
        this.mission.assignments.forEach(assignment => {
          this.summary.assignments.push(assignment);
          assiLen--;
          if (assiLen === 0) {
            cb();
          }
        });
      }
    });
  }
  }

  searchExistingCircuitName(value, i) {
    if (!value) {
      this.mission.circuits[i].existingCircuits = Object.assign([], this.mission.circuits[i].tempExistingCircuits).filter(item => {
        if (this.mission.circuits[i].selectedExistingCircuit.circuitName !== item.circuitName) {
          return item;
        }
      });
    } else {
      this.mission.circuits[i].existingCircuits = Object.assign([], this.mission.circuits[i].tempExistingCircuits).filter(
        item => {
          if (this.mission.circuits[i].selectedExistingCircuit.circuitName !== item.circuitName) {
            return item.circuitName.toLowerCase().indexOf(value.toLowerCase()) > -1;
          }
        }
      );
    }
  }

  existingDropdownToggled(value, i) {
    if (!value) {
      this.mission.circuits[i].existingCircuits = Object.assign([], this.mission.circuits[i].tempExistingCircuits).filter(item => {
        if (this.mission.circuits[i].selectedExistingCircuit.circuitName !== item.circuitName) {
          return item;
        }
      });
    }
  }

  /* ********************************    Fillers    *************************************
     circuitMissionFiller()
     checkpointMissionFiller(cb)
     assignmentCheckpointsFiller(cb)
     assignmentFieldAgentsFiller(cb)
     assignmentShiftsFiller(cb)
     checkpointCircuitFiller(cb)
  */

  existingCircuitsCheckpoitFiller(i) {
    this.checkpointNames=[];
    this.mission.circuits[i].checkpointsGeoJson.features = [];
    let checkLens = this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.length;
    if (this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.length !== 0) {
      this.mission.circuits[i].existingCircuitsCheck = true;
      this.existingCircuitsCheck = true;
    }
    if (this.market) {
      // console.log('4087 market swlected',this.mission);
      this._http.SecureGet('/ref/getAllMissions?id=' + this.missionId).subscribe(res => {
        const feature1 = {
          'type': 'Feature',
          'geometry': { 'type': 'Point', 'coordinates': [res.data.missions[0].missionMarketZoneList[0].longitude, res.data.missions[0].missionMarketZoneList[0].latitude] },
          'lnglat': [res.data.missions[0].missionMarketZoneList[0].longitude, res.data.missions[0].missionMarketZoneList[0].latitude],
          'checkpointName': res.data.missions[0].missionMarketZoneList[0].officialName,
          'fillColor': 'purple',
          'existingCircuit':'true',
          'isSearch': 'false'
        };       
        // this.mission.circuits[i].checkpointsGeoJson['features'].push(feature1);
        this.marketName= res.data.missions[0].missionMarketZoneList[0].officialName;
      });  
      // console.log(this.mission.circuits[i].selectedExistingCircuit);
      this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.sort(function(a, b) {
        return a.position - b.position;
      });
      this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.forEach(extCheck => {
        const feature = {
          'type': 'Feature',
          'geometry': { 'type': 'Point', 'coordinates': [extCheck.checkpointLongitude, extCheck.checkpointLatitude] },
          'lnglat': [extCheck.checkpointLongitude, extCheck.checkpointLatitude],
          'checkpointName': extCheck.checkpointName,
          'existingCircuit': 'false'
        };
        // this.mission.circuits[i].checkpointsGeoJson['features'].push(feature);
      
        // this.checkpointNames.push(extCheck.checkpointName);
        console.log(this.checkpointNames);
        checkLens--;
        if (checkLens === 0) {
      
          // this.populateExistingCheckpoints();
          this.mission.circuits[i].existingCircuitsCheck = true;
          this.existingCircuitsCheck = true;
          // this.mission.circuits[i].map.flyTo({
          //   center: [this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints[0].checkpointLongitude,
          //   this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints[0].checkpointLatitude],
          //   zoom: 9,
          //   bearing: 0,
          //   curve: 1
          // });
          // if(this.mission.markets[0].longitude){
          //   this.myCircle1.setCenter({ lat: parseFloat(this.mission.markets[0].longitude), lng: parseFloat(this.mission.markets[0].longitude) }).setRadius(150).addTo(this.mission.circuits[i].map);

          // }
        }
      });
      this.mission.circuits[0].selectedExistingCircuit.circuitName =this.translate.instant('Select');
    } else {
      this.mission.circuits[0].selectedExistingCircuit.circuitName =this.translate.instant('Select');
      // console.log('4087 market not swlected',this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints);
      this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.sort(function(a, b) {
        return a.position - b.position;
      });
      
      // console.log('Sorted:',this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints);
      this.mission.circuits[i].selectedExistingCircuit.circuitCheckpoints.forEach(extCheck => {
        const feature1 = {
          'type': 'Feature',
          'geometry': { 'type': 'Point', 'coordinates': [extCheck.checkpointLongitude, extCheck.checkpointLatitude] },
          'lnglat': [extCheck.checkpointLongitude, extCheck.checkpointLatitude],
          'checkpointName': extCheck.checkpointName,          
        };
        // this.mission.circuits[i].checkpointsGeoJson['features'].push(feature1);
        // this.checkpointNames.push(extCheck.checkpointName);
        // console.log(this.checkpointNames);
        checkLens--;
        const feature = {
          'type': 'Feature',
          'geometry': { 'type': 'Point', 'coordinates': [this.mission.circuits[i].data.lnglat[0],this.mission.circuits[i].data.lnglat[1]] },
          'lnglat': [this.mission.circuits[i].data.lnglat[0],this.mission.circuits[i].data.lnglat[1]],
          'checkpointName': '',
          'fillColor':'purple'
  
        };
        this.mission.circuits[i].checkpointsGeoJson['features'].push(feature);
        if (checkLens === 0) {
          // this.populateExistingCheckpoints();
          this.mission.circuits[i].existingCircuitsCheck = true;
          this.existingCircuitsCheck = true;
        }
      });
    }
    this.enableDropsown=true;
  }

  circuitMissionFiller() {
    let len = this.missions.length;
    const missions = [];
    this.missions.forEach(mission => {
      missions.push(mission);
      len--;
      if (len === 0) {
        this.mission.circuits[this.mission.circuits.length - 1].selectedMission = missions[0];
        this.mission.circuits[this.mission.circuits.length - 1].missions = missions;
        this.mission.circuits[this.mission.circuits.length - 1].missions.splice(0, 1);
        this.missionsLoaded = true;
        if (this.mission.circuits[this.mission.circuits.length - 1].selectedMission.missionType.id === 3) {
          this.showAddNewCircuit = false;
        } else {
          this.showAddNewCircuit = true;
        }
        this.event.hideLoader({});
      }
    });
  }

  checkpointMissionFiller(cb) {
    if (this.mission.checkpoints.length > 1) {
      this.mission.checkpoints[this.mission.checkpoints.length - 1].selectedMission = this.mission.checkpoints[0].selectedMission;
      cb();
    } else {
      if (this.step2Completed) {
        this.mission.checkpoints[this.mission.checkpoints.length - 1].selectedMission = this.mission.circuits[0].selectedMission;
        this.mission.checkpoints[this.mission.checkpoints.length - 1].missions = [];
        this.showMissionsInCheckpoint = true;
      } else {
        let mlen = this.missions.length;
        const missions = [];
        this.missions.forEach(mission => {
          if (mission.missionCircuits.length !== 0) {
            missions.push(mission);
          }
          mlen--;
          if (mlen === 0) {
            this.mission.checkpoints[this.mission.checkpoints.length - 1].selectedMission = missions[0];
            this.mission.checkpoints[this.mission.checkpoints.length - 1].missions = missions;
            this.mission.checkpoints[this.mission.checkpoints.length - 1].missions.splice(0, 1);
            cb();
          }
        });
      }
    }
  }

  assignmentCheckpointsFiller(cb) {
    const checkpoints = [];
    let checklen = this.mission.checkpoints.length;
    this.mission.checkpoints.forEach(checkpoint => {
      checkpoints.push(checkpoint);
      this.mission.assignments[this.mission.assignments.length - 1].tempCheckpoints.push(checkpoint);
      checklen--;
      if (checklen === 0) {
        if (this.mission.checkpoints[0].selectedMission.missionType.id === 3) {
          let len = checkpoints.length;
          checkpoints.forEach(check => {
            this.mission.assignments[this.mission.assignments.length - 1].selectedCheckpoints.push(check.data.checkpointName);
            len--;
            if (len === 0) {
              this.mission.assignments[this.mission.assignments.length - 1].selectedCheckpoint = {
                data: {
                  checkpointName: 'No more checkpoints'
                }
              };
              this.mission.assignments[this.mission.assignments.length - 1].data.lnglat = checkpoints[0].data.lnglat;
              cb();
            }
          });
        } else {
          this.mission.assignments[this.mission.assignments.length - 1].selectedCheckpoint = checkpoints[0];
          this.mission.assignments[this.mission.assignments.length - 1].checkpoints = checkpoints;
          this.mission.assignments[this.mission.assignments.length - 1].data.lnglat = checkpoints[0].data.lnglat;
          this.mission.assignments[this.mission.assignments.length - 1].checkpoints.splice(0, 1);
          cb();
        }
      }
    });
  }

  assignmentFieldAgentsFiller(cb) {
    const fieldAgents = [];
    let falen = this.fieldAgents.length;
    this.fieldAgents.forEach(fa => {
      fieldAgents.push(fa);
      falen--;
      if (falen === 0) {
        if (this.mission.assignments.length > 1) {
          const id = this.mission.assignments[0].selectedFieldAgent.userId;
          const pushableArray = [];
          let lem = fieldAgents.length;
          fieldAgents.forEach(fl => {
            if (id !== fl.userId) {
              pushableArray.push(fl);
            }
            lem--;
            if (lem === 0) {
              this.mission.assignments[this.mission.assignments.length - 1].fieldAgents = pushableArray;
              this.mission.assignments[this.mission.assignments.length - 1].selectedFieldAgent = pushableArray[0];
              let pfl = this.mission.assignments[0].fieldAgents.length;
              let deleteFieldAgentInd;
              this.mission.assignments[0].fieldAgents.forEach((fk, q) => {
                if (this.mission.assignments[this.mission.assignments.length - 1].selectedFieldAgent.userId === fk.userId) {
                  deleteFieldAgentInd = q;
                }
                pfl--;
                if (pfl === 0) {
                  this.mission.assignments[0].fieldAgents.splice(deleteFieldAgentInd, 1);
                  this.mission.assignments[this.mission.assignments.length - 1].fieldAgents.splice(0, 1);
                  cb();
                }
              });
            }
          });
        } else {
          this.mission.assignments[this.mission.assignments.length - 1].fieldAgents = fieldAgents;
          this.mission.assignments[this.mission.assignments.length - 1].selectedFieldAgent = fieldAgents[0];
          this.mission.assignments[this.mission.assignments.length - 1].fieldAgents.splice(0, 1);
          cb();
        }
      }
    });
  }

  assignmentShiftsFiller(cb) {
    const shifts = [];
    let slen = this.shifts.length;
    this.shifts.forEach(fa => {
      shifts.push(fa);
      slen--;
      if (slen === 0) {
        if (this.mission.assignments[this.mission.assignments.length - 1].shiftId === 1) {
          this.mission.assignments[this.mission.assignments.length - 1].shifts.push(shifts[0]);
          this.mission.assignments[this.mission.assignments.length - 1].shifts.push(shifts[1]);
          this.mission.assignments[this.mission.assignments.length - 1].selectedShift = shifts[0];
          this.mission.assignments[this.mission.assignments.length - 1].shifts.splice(0, 1);
          cb();
        } else {
          this.mission.assignments[this.mission.assignments.length - 1].shifts.push(shifts[2]);
          this.mission.assignments[this.mission.assignments.length - 1].shifts.push(shifts[3]);
          this.mission.assignments[this.mission.assignments.length - 1].selectedShift = shifts[0];
          this.mission.assignments[this.mission.assignments.length - 1].shifts.splice(0, 1);
          cb();
        }
      }
    });
  }

  checkpointCircuitFiller(cb) {
    if (this.step2Completed) {
      let len = this.circuits.length;
      const circuits = [];
      this.circuits.forEach(circuit => {
        circuits.push(circuit);
        len--;
        if (len === 0) {
          this.mission.checkpoints[this.mission.checkpoints.length - 1].selectedCircuit = circuits[0];
          this.mission.checkpoints[this.mission.checkpoints.length - 1].circuits = circuits;
          this.mission.checkpoints[this.mission.checkpoints.length - 1].circuits.splice(0, 1);
          this.circuitsLoaded = true;
          this.event.hideLoader({});
          cb();
        }
      });
    } else {
      const circuits = [];
      const mclen = this.mission.checkpoints[this.mission.checkpoints.length - 1].selectedMission.missionCircuits.length;
      if (mclen !== 0) {
        let clen = this.mission.checkpoints[this.mission.checkpoints.length - 1].selectedMission.missionCircuits.length;
        this.mission.checkpoints[this.mission.checkpoints.length - 1].selectedMission.missionCircuits.forEach(circuit => {
          circuits.push(circuit);
          clen--;
          if (clen === 0) {
            this.mission.checkpoints[this.mission.checkpoints.length - 1].selectedCircuit = circuits[0];
            if (this.mission.checkpoints[this.mission.checkpoints.length - 1].selectedMission.missionType.id === 3) {
              const checkpointsLength = this.mission.checkpoints.length +
                this.mission.checkpoints[this.mission.checkpoints.length - 1].selectedCircuit.circuitCheckpoints.length;
              if (checkpointsLength > 2) {
                this.showAddNewCheckpoint = false;
              }
            }

            this.mission.checkpoints[this.mission.checkpoints.length - 1].circuits = circuits;
            this.mission.checkpoints[this.mission.checkpoints.length - 1].circuits.splice(0, 1);
            this.circuitsLoaded = true;
            this.event.hideLoader({});
            cb();
          }
        });
      } else if (mclen === 0) {
        cb();
      }
    }
  }

  callAdptIdData(e, i) {
    if (!this.mission.checkpoints[i].dontKnowAdptId) {
      if (this.mission.checkpoints.length === 3) {
        let checker = false;
        let check2Len = this.mission.checkpoints.length;
        this.mission.checkpoints.forEach((check1, check1I) => {
          check2Len--;
          let check1Len = this.mission.checkpoints.length;
          this.mission.checkpoints.forEach((check2, check2I) => {
            if (check1I !== check2I) {
              let check1AdptId = parseInt(check1.data.adptid, 10);
              let check2AdptId = parseInt(check2.data.adptid, 10);
              if (check1AdptId === check2AdptId) {
                checker = true;
              }
            }
            check1Len--;
            if (check1Len === 0 && check2Len === 0) {
              if (!checker) {
                this._http.SecurePost('/checkpoint/validateCheckpoints', {
                  adptIds: [
                    parseInt(this.mission.checkpoints[0].data.adptid, 10),
                    parseInt(this.mission.checkpoints[1].data.adptid, 10),
                    parseInt(this.mission.checkpoints[2].data.adptid, 10)
                  ]
                }).subscribe(res => {
                  this.pedestrainAlertsService.adptidsAlreadyExist().then(() => {

                    this.event.broadcast({ eventName: 'showLoader', data: {} });
                    if (this.mission.checkpoints.length === 3) {
                      this.mission.checkpoints.splice(2, 1);
                      this.showAddNewCheckpoint = true;
                      if (this.checkpointMapGeoJSON.features.length === 3) {
                        this.checkpointMapGeoJSON.features.splice(2, 1);
                      }
                      const formData = new FormData();
                      const XHR = new XMLHttpRequest();
                      formData.append('missionId', this.mission.checkpoints[0].selectedMission.missionId);
                      formData.append('existingCircuitId', res.data.circuitId);
                      formData.append('circuitId', this.mission.checkpoints[0].selectedCircuit.circuitId);
                      formData.append('circuitCreatedBy', res.data.circuitCreatedById);
                      formData.append('circuitUpdatedBy', this.user.userId);
                      formData.append(' locationId', '0');
                      formData.append('locationTypeId', '1');
                      XHR.addEventListener('load', (event) => {

                      });
                      XHR.onreadystatechange = (aEvt) => {
                        if (XHR.readyState === 4) {
                          if (XHR.status === 200) {
                            const response = JSON.parse(XHR.response);
                            const circuitObject = {
                              selectedMission: this.mission.checkpoints[0].selectedMission,
                              missions: [],
                              existingCircuitsCheck: true,
                              existingCircuits: [],
                              tempExistingCircuits: [],
                              existingCircuitSearch: undefined,
                              selectedExistingCircuit: res.data,
                              checkpointsGeoJson: {
                                'type': 'FeatureCollection',
                                'features': [
                                  {
                                    'type': 'Feature',
                                    'geometry': {
                                      'type': 'Point',
                                      'coordinates': [res.data.circuitCheckpoints[0].checkpointLongitude,
                                      res.data.circuitCheckpoints[0].checkpointLatitude]
                                    },
                                    'lnglat': [parseFloat(Number(res.data.circuitCheckpoints[0].checkpointLongitude).toFixed(20)),
                                    parseFloat(Number(res.data.circuitCheckpoints[0].checkpointLatitude).toFixed(20))],
                                    'checkpointName':res.data.circuitCheckpoints[0].checkpointName
                                  },
                                  {
                                    'type': 'Feature',
                                    'geometry': {
                                      'type': 'Point',
                                      'coordinates': [res.data.circuitCheckpoints[1].checkpointLongitude,
                                      res.data.circuitCheckpoints[1].checkpointLatitude]
                                    },
                                    'lnglat': [parseFloat(Number(res.data.circuitCheckpoints[1].checkpointLongitude).toFixed(20)),
                                    parseFloat(Number(res.data.circuitCheckpoints[1].checkpointLatitude).toFixed(20))],
                                    'checkpointName':res.data.circuitCheckpoints[1].checkpointName
                                  },
                                  {
                                    'type': 'Feature',
                                    'geometry': {
                                      'type': 'Point',
                                      'coordinates': [res.data.circuitCheckpoints[2].checkpointLongitude,
                                      res.data.circuitCheckpoints[2].checkpointLatitude]
                                    },
                                    'lnglat': [parseFloat(Number(res.data.circuitCheckpoints[2].checkpointLongitude).toFixed(20)),
                                    parseFloat(Number(res.data.circuitCheckpoints[2].checkpointLatitude).toFixed(20))],
                                    'checkpointName':res.data.circuitCheckpoints[2].checkpointName
                                  },
                                  {
                                    'type': 'Feature',
                                    'geometry': { 'type': 'Point', 'coordinates': [this.mission.markets[0].longitude, this.mission.markets[0].latitude] },
                                    'lnglat': [this.mission.markets[0].longitude, this.mission.markets[0].latitude],
                                    'checkpointName': 'Market Zone',
                                    'fillColoe':'purple'
                            
                                  }
                                ]
                              },
                              data: {
                                circuitName: '',
                                search: '',
                                lnglat: ['4.4699', '50.5039'],
                                imageUploaded: true,
                                progress: 0,
                                uploadProgress: false
                              }
                            };
                            this.mission.circuits = [];
                            this.mission.circuits.push(circuitObject);
                            this.populateExistingCheckpoints();
                            this.event.broadcast({ eventName: 'hideLoader', data: {} });
                            this.pedestrainAlertsService.circuitMappedSuccessAlert();
                          } else {
                            this.pedestrainAlertsService.somethingWentWrong();
                          }
                        }
                      };
                      XHR.addEventListener('error', (event) => {
                        this.event.broadcast({ eventName: 'hideLoader', data: {} });
                        this.pedestrainAlertsService.somethingWentWrongQuestion();
                      });

                      XHR.open('POST', this.xmlHttpUrl + '/circuit/addCircuit');
                      XHR.setRequestHeader('Authorization', this.user.accessToken);
                      XHR.setRequestHeader('userId', this.user.userId);
                      XHR.send(formData);
                    }

                  }).catch(() => {
                    this.pedestrainAlertsService.sameCheckPointsNotAllowedAlert();
                  });
                }, err => {

                  this._http.SecureGet('/ref/getAllCheckpoints?adptId=' + e.target.value).subscribe(res => {
                    this._http.pullAdptIdDetails(e.target.value).subscribe(resp => {
                      if (resp.data['Geographic Data'].length !== 0) {
                        const adptIdDet = resp.data['Geographic Data'][0];
                        const lat = adptIdDet.adt_latitude_wgs84;
                        const lng = adptIdDet.adt_longitude_wgs84;
                        if (this.checkpointMapGeoJSON.features.length < i) {
                          this.checkpointMapGeoJSON.features.push({
                            'type': 'Feature',
                            'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                            'existingCircuit':'false',
                            'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                          });
                          console.log('5130');
                        } else {
                          this.checkpointMapGeoJSON.features[i] = {
                            'type': 'Feature',
                            'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                            'existingCircuit':'false',
                            'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                          };
                          console.log('5137');
                        }
                        this.mission.checkpoints[i].data.lnglat = [lng, lat];
                        this.mission.checkpoints[i].selected_postalcode.adt_postal_code = adptIdDet.adt_postal_code;
                        this.mission.checkpoints[i].selected_street.adt_street = adptIdDet.adt_street;
                        this.mission.checkpoints[i].selected_adrn.adt_adrn = adptIdDet.adt_adrn;
                        this.mission.checkpoints[i].selected_commune.com_commune_name_fr = adptIdDet.com_commune_name_fr;
                        this.mission.checkpoints[i].selected_region.reg_region_name_fr = adptIdDet.reg_region_name_fr;
                        this.mission.checkpoints[i].selected_country.con_country_name_fr = adptIdDet.con_country_name_fr;
                        this.mission.checkpoints[i].data.quartier = adptIdDet.qub_quartier_name_fr;
                        this.mission.checkpoints[i].data.address = adptIdDet.adt_adrn + ', ' +
                          adptIdDet.adt_street + ', ' +
                          adptIdDet.com_commune_name_fr + ', ' +
                          adptIdDet.reg_region_name_fr + ', ' +
                          adptIdDet.adt_postal_code + ', ' +
                          adptIdDet.con_country_name_fr;
                        this.mission.checkpoints[i].adptid_valid = true;
                        this.mission.checkpoints[i].data.checkpointName = res.data.checkpoints[0].checkpointName;
                        this.mission.checkpoints[i].data.checkpointDescription = res.data.checkpoints[0].checkpointDescription;
                        this.mission.checkpoints[i].data.checkpointNameDisabled = true;
                        console.log(this.mission.checkpoints[i]);
                        this.checkpointMap.flyTo({
                          center: [lng, lat],
                          zoom: 9,
                          bearing: 0,
                          curve: 1
                        });
                        this.mission.checkpoints[i].countryLoaded = true;
                        this.mission.checkpoints[i].regionLoaded = true;
                        this.mission.checkpoints[i].communeLoaded = true;
                        this.mission.checkpoints[i].postalCodeLoaded = true;
                        this.mission.checkpoints[i].streetLoaded = true;
                        this.mission.checkpoints[i].adrnLoaded = true;
                      } else {
                        this.mission.checkpoints[i].adptid_valid = false;
                      }
                    }, err2 => {
                      this.mission.checkpoints[i].adptid_valid = false;
                    });
                  }, err1 => {
                    this._http.pullAdptIdDetails(e.target.value).subscribe(resp => {
                      if (resp.data['Geographic Data'].length !== 0) {
                        const adptIdDet = resp.data['Geographic Data'][0];
                        const lat = adptIdDet.adt_latitude_wgs84;
                        const lng = adptIdDet.adt_longitude_wgs84;
                        if (this.checkpointMapGeoJSON.features.length < i) {
                          this.checkpointMapGeoJSON.features.push({
                            'type': 'Feature',
                            'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                            'existingCircuit':'false',
                            'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                          });
                          console.log('5188');
                        } else {
                          this.checkpointMapGeoJSON.features[i] = {
                            'type': 'Feature',
                            'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                            'existingCircuit':'false',
                            'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                          };
                          console.log('5195');
                        }
                        this.mission.checkpoints[i].data.lnglat = [lng, lat];
                        this.mission.checkpoints[i].selected_postalcode.adt_postal_code = adptIdDet.adt_postal_code;
                        this.mission.checkpoints[i].selected_street.adt_street = adptIdDet.adt_street;
                        this.mission.checkpoints[i].selected_adrn.adt_adrn = adptIdDet.adt_adrn;
                        this.mission.checkpoints[i].selected_commune.com_commune_name_fr = adptIdDet.com_commune_name_fr;
                        this.mission.checkpoints[i].selected_region.reg_region_name_fr = adptIdDet.reg_region_name_fr;
                        this.mission.checkpoints[i].selected_country.con_country_name_fr = adptIdDet.con_country_name_fr;
                        this.mission.checkpoints[i].data.quartier = adptIdDet.qub_quartier_name_fr;
                        this.mission.checkpoints[i].data.checkpointName = '';
                        this.mission.checkpoints[i].data.checkpointNameDisabled = false;
                        this.mission.checkpoints[i].data.checkpointDescription = '';
                        this.mission.checkpoints[i].data.address = adptIdDet.adt_adrn + ', ' +
                          adptIdDet.adt_street + ', ' +
                          adptIdDet.com_commune_name_fr + ', ' +
                          adptIdDet.reg_region_name_fr + ', ' +
                          adptIdDet.adt_postal_code + ', ' +
                          adptIdDet.con_country_name_fr;
                        this.mission.checkpoints[i].adptid_valid = true;
                        console.log(this.mission.checkpoints[i]);
                        this.checkpointMap.flyTo({
                          center: [lng, lat],
                          zoom: 9,
                          bearing: 0,
                          curve: 1
                        });
                        this.mission.checkpoints[i].countryLoaded = true;
                        this.mission.checkpoints[i].regionLoaded = true;
                        this.mission.checkpoints[i].communeLoaded = true;
                        this.mission.checkpoints[i].postalCodeLoaded = true;
                        this.mission.checkpoints[i].streetLoaded = true;
                        this.mission.checkpoints[i].adrnLoaded = true;
                      } else {
                        this.mission.checkpoints[i].adptid_valid = false;
                      }
                    }, err2 => {
                      this.mission.checkpoints[i].adptid_valid = false;
                    });
                  })

                });
              } else {
                this.pedestrainAlertsService.uniqueApdtId()
                  .then(() => {
                    this.mission.checkpoints[i].adptid_valid = false;
                  })
                  .catch(() => {
                    this.mission.checkpoints[i].adptid_valid = false;
                  });
              }
            }
          });
        })
      } else {
        this._http.SecureGet('/ref/getAllCheckpoints?adptId=' + e.target.value).subscribe(resp => {
          this._http.pullAdptIdDetails(e.target.value).subscribe(res => {
            if (res.data['Geographic Data'].length !== 0) {
              const adptIdDet = res.data['Geographic Data'][0];
              const lat = adptIdDet.adt_latitude_wgs84;
              const lng = adptIdDet.adt_longitude_wgs84;
              if (this.checkpointMapGeoJSON.features.length < i) {
                this.checkpointMapGeoJSON.features.push({
                  'type': 'Feature',
                  'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                  'existingCircuit':'false',
                  'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                });
                console.log('5262');
              } else {
                this.checkpointMapGeoJSON.features[i] = {
                  'type': 'Feature',
                  'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                  'existingCircuit':'false',
                  'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                };
                console.log('5269');
              }
              this.mission.checkpoints[i].data.lnglat = [lng, lat];
              this.mission.checkpoints[i].selected_postalcode.adt_postal_code = adptIdDet.adt_postal_code;
              this.mission.checkpoints[i].selected_street.adt_street = adptIdDet.adt_street;
              this.mission.checkpoints[i].selected_adrn.adt_adrn = adptIdDet.adt_adrn;
              this.mission.checkpoints[i].selected_commune.com_commune_name_fr = adptIdDet.com_commune_name_fr;
              this.mission.checkpoints[i].selected_region.reg_region_name_fr = adptIdDet.reg_region_name_fr;
              this.mission.checkpoints[i].selected_country.con_country_name_fr = adptIdDet.con_country_name_fr;
              this.mission.checkpoints[i].data.quartier = adptIdDet.qub_quartier_name_fr;
              this.mission.checkpoints[i].data.checkpointName = resp.data.checkpoints[0].checkpointName;
              this.mission.checkpoints[i].data.checkpointDescription = resp.data.checkpoints[0].checkpointDescription;
              this.mission.checkpoints[i].data.checkpointNameDisabled = true;
              this.mission.checkpoints[i].data.address = adptIdDet.adt_adrn + ', ' +
                adptIdDet.adt_street + ', ' +
                adptIdDet.com_commune_name_fr + ', ' +
                adptIdDet.reg_region_name_fr + ', ' +
                adptIdDet.adt_postal_code + ', ' +
                adptIdDet.con_country_name_fr;
              this.mission.checkpoints[i].adptid_valid = true;
              console.log(this.mission.checkpoints[i]);
              this.checkpointMap.flyTo({
                center: [lng, lat],
                zoom: 9,
                bearing: 0,
                curve: 1
              });
              this.mission.checkpoints[i].countryLoaded = true;
              this.mission.checkpoints[i].regionLoaded = true;
              this.mission.checkpoints[i].communeLoaded = true;
              this.mission.checkpoints[i].postalCodeLoaded = true;
              this.mission.checkpoints[i].streetLoaded = true;
              this.mission.checkpoints[i].adrnLoaded = true;
              console.log('checkpoint', this.mission.checkpoints);
            } else {
              this.mission.checkpoints[i].adptid_valid = false;
            }
          }, err => {
            this.mission.checkpoints[i].adptid_valid = false;
            console.log('Error', err);
          });
        }, err1 => {
          this._http.pullAdptIdDetails(e.target.value).subscribe(res => {
            if (res.data['Geographic Data'].length !== 0) {
              const adptIdDet = res.data['Geographic Data'][0];
              const lat = adptIdDet.adt_latitude_wgs84;
              const lng = adptIdDet.adt_longitude_wgs84;
              if (this.checkpointMapGeoJSON.features.length < i) {
                this.checkpointMapGeoJSON.features.push({
                  'type': 'Feature',
                  'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                  'existingCircuit':'false',
                  'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                });
                console.log('5322');
              } else {
                this.checkpointMapGeoJSON.features[i] = {
                  'type': 'Feature',
                  'geometry': { 'type': 'Point', 'coordinates': [lng, lat] },
                  'existingCircuit':'false',
                  'lnglat': [parseFloat(Number(lng).toFixed(20)), parseFloat(Number(lat).toFixed(20))]
                };
                console.log('5329');
              }
              this.mission.checkpoints[i].data.lnglat = [lng, lat];
              this.mission.checkpoints[i].selected_postalcode.adt_postal_code = adptIdDet.adt_postal_code;
              this.mission.checkpoints[i].selected_street.adt_street = adptIdDet.adt_street;
              this.mission.checkpoints[i].selected_adrn.adt_adrn = adptIdDet.adt_adrn;
              this.mission.checkpoints[i].selected_commune.com_commune_name_fr = adptIdDet.com_commune_name_fr;
              this.mission.checkpoints[i].selected_region.reg_region_name_fr = adptIdDet.reg_region_name_fr;
              this.mission.checkpoints[i].selected_country.con_country_name_fr = adptIdDet.con_country_name_fr;
              this.mission.checkpoints[i].data.quartier = adptIdDet.qub_quartier_name_fr;
              this.mission.checkpoints[i].data.checkpointName = '';
              this.mission.checkpoints[i].data.checkpointNameDisabled = false;
              this.mission.checkpoints[i].data.checkpointDescription = '';
              this.mission.checkpoints[i].data.address = adptIdDet.adt_adrn + ', ' +
                adptIdDet.adt_street + ', ' +
                adptIdDet.com_commune_name_fr + ', ' +
                adptIdDet.reg_region_name_fr + ', ' +
                adptIdDet.adt_postal_code + ', ' +
                adptIdDet.con_country_name_fr;
              this.mission.checkpoints[i].adptid_valid = true;
              console.log(this.mission.checkpoints[i]);
              this.checkpointMap.flyTo({
                center: [lng, lat],
                zoom: 9,
                bearing: 0,
                curve: 1
              });
              this.mission.checkpoints[i].countryLoaded = true;
              this.mission.checkpoints[i].regionLoaded = true;
              this.mission.checkpoints[i].communeLoaded = true;
              this.mission.checkpoints[i].postalCodeLoaded = true;
              this.mission.checkpoints[i].streetLoaded = true;
              this.mission.checkpoints[i].adrnLoaded = true;
              console.log('checkpoint', this.mission.checkpoints);
            } else {
              this.mission.checkpoints[i].adptid_valid = false;
            }
          }, err => {
            this.mission.checkpoints[i].adptid_valid = false;
            console.log('Error', err);
          });
        });

      }
    }
  }

  /* *******************************    VALIDATORS    **********************************
    circuitFormChecker(cb)
    checkpointFormChecker(cb)
    validateCircuits(cb)
    assignmentFormChecker(cb)
  */

  circuitFormChecker(cb) {
    let len = this.mission.circuits.length;
    let errorMessage = '';
    this.mission.circuits.forEach(circuit => {
      if (!circuit.existingCircuitsCheck) {
        if (circuit.data.circuitName === '' || circuit.data.circuitName === undefined) {
          errorMessage = errorMessage + 'Please fill up the circuit name field</br>';
        } 
        else if (circuit.data.imageUploaded === false) {
          errorMessage = errorMessage + 'Please attach an image for each circuit</br>';
        }
         else {
          const found = Object.assign([], circuit.tempExistingCircuits).filter((extCir) => {
            const c1 = extCir.circuitName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
            const c2 = circuit.data.circuitName.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\s\{\}\[\]\\\/]/gi, '');
            return c1.toLowerCase() === c2.toLowerCase();
          });
          if (found.length !== 0) {
            errorMessage = errorMessage + 'The circuit name is already used with existing circuit with checkpoints</br>';
          } else {
            const foundno = Object.assign([], this.noCheckpointCircuits).filter(extCir => {
              return extCir.circuitName === circuit.data.circuitName;
            });
            if (foundno.length !== 0) {
              errorMessage = errorMessage + 'The circuit name is already used with existing circuit without checkpoints</br>';
            }
          }
        }
      }
      len--;
      if (len === 0) {
        if (errorMessage !== '') {
          this.pedestrainAlertsService.warningAlert(errorMessage);
        } else {
          cb();
        }
      }
    });
  }

  checkpointFormChecker(cb) {
    if (this.existingCircuitsCheck) {
      cb();
    } else {
      if (this.mission.checkpoints[0].selectedMission.missionType.id === 3 && this.showAddNewCheckpoint) {
        this.pedestrainAlertsService.needMoreCheckPoints();
      } else {

        this._http.SecurePost('/checkpoint/validateCheckpoints', {
          adptIds: [this.mission.checkpoints[0].data.adptid, this.mission.checkpoints[1].data.adptid, this.mission.checkpoints[2].data.adptid]
        }).subscribe(res => {
          this.pedestrainAlertsService.combinationAlreadyAdptId();
        }, err => {
          let len = this.mission.checkpoints.length;
          let errorMessage = '';
          this.mission.checkpoints.forEach((checkpoint, pI) => {
            len--;
            let childCounter = this.mission.checkpoints.length;
            if ((checkpoint.data.checkpointName === '' || checkpoint.data.checkpointName === undefined) && !errorMessage.includes('Please fill up the checkpoint name field')) {
              errorMessage = errorMessage + 'Please fill up the checkpoint name field</br>';
            }
            if ((checkpoint.data.adptid === '' || checkpoint.data.adptid === null || checkpoint.data.adptid === undefined) && !errorMessage.includes('Please fill up the adptid')) {
              errorMessage = errorMessage + 'Please fill up the adptid</br>';
            }
            if (!checkpoint.adptid_valid && !errorMessage.includes('Please enter a valid ADPTID')) {
              errorMessage = errorMessage + 'Please enter a valid ADPTID</br>';
            }
            this.mission.checkpoints.forEach((check, cI) => {
              if (cI !== pI) {
                if ((check.data.adptid.toString() === checkpoint.data.adptid.toString()) && !errorMessage.includes('Adptid should be unique')) {
                  errorMessage = errorMessage + 'Adptid should be unique</br>';
                }
                if ((check.data.checkpointName === checkpoint.data.checkpointName) && !errorMessage.includes('Checkpoint name should be unique')) {
                  errorMessage = errorMessage + 'Checkpoint name should be unique</br>';
                }
              }
              childCounter--;
              if (len === 0 && childCounter === 0) {
                if (errorMessage !== '') {
                  this.pedestrainAlertsService.warningAlert(errorMessage);
                } else {
                  cb();
                }
              }
            });
          });
        });
      }
    }
  }

  validateCircuits(cb) {
    this.getMissions(() => {
      let validation = false;
      if (this.mission.circuits[0] !== undefined) {
        validation = this.mission.circuits[0].existingCircuitsCheck;
        if (validation) {
          cb(validation);
        }
      }
      if (this.tempmissions.length !== 0) {
        let missLen = this.tempmissions.length;
        this.tempmissions.forEach(miss => {
          if (miss.missionType.id === 3) {
            if (miss.missionCircuits.length === 1) {
              if (miss.missionCircuits[0].circuitCheckpoints.length < 3) {
                validation = true;
              }
            }
          } else {
            if (miss.missionCircuits.length > 0) {
              validation = true;
            }
          }
          missLen--;
          if (missLen === 0) {
            if (!validation) {
              this.pageOpenAllowed = false;
              this.step2Completed = false;
            }
            cb(validation);
          }
        });
      }
    });
  }

  assignmentFormChecker(cb) {
    let len = this.mission.assignments.length;
    const errorMessages = [];
    this.mission.assignments.forEach((assignment, pi) => {
      this.mission.assignments.forEach((checkAssignment, ci) => {
        const aslen = this.mission.assignments.length;
        const chlen = assignment.selectedCheckpoints.length;
        if (chlen === 0) {
          errorMessages.push('ncf');
        }
        if (aslen === 1) {
          errorMessages.push('nea');
        }
        if (pi !== ci) {
          if (assignment.selectedFieldAgent.userId ===
            checkAssignment.selectedFieldAgent.userId && assignment.selectedShift.timeRange === checkAssignment.selectedShift.timeRange) {
            errorMessages.push('sfss');
          } else if (assignment.selectedFieldAgent.userId !== checkAssignment.selectedFieldAgent.userId) {
            let checklen = assignment.selectedCheckpoints.length;
            let flag = false;
            let shiftFlag = false;
            let shiftLen = assignment.selectedShifts.length;
            assignment.selectedShifts.forEach(sh => {
              checkAssignment.selectedShifts.forEach(csk => {
                if (csk === sh) {
                  shiftFlag = true;
                }
                shiftLen--;
                if (shiftLen === 0) {
                  if (shiftFlag) {
                    assignment.selectedCheckpoints.forEach(assigncheck => {
                      checkAssignment.selectedCheckpoints.forEach(checkassign => {
                        if (checkassign === assigncheck) {
                          flag = true;
                        }
                      });
                      checklen--;
                      if (checklen === 0) {
                        if (flag === true) {
                          errorMessages.push('dfss');
                        }
                      }
                    });
                  }
                }
              });
            });
          }
          if (!assignment.data.iterations) {
            errorMessages.push('nif');
          } else if (!checkAssignment.data.iterations) {
            errorMessages.push('nif');
          } else {
            if (assignment.data.iterations !== 9) {
              if (!errorMessages.includes('int9')) {
                errorMessages.push('int9');
              }
            }
            if (checkAssignment.data.iterations !== 9) {
              if (!errorMessages.includes('int9')) {
                errorMessages.push('int9');
              }
            }
          }
        }
      });
      len--;
      if (len === 0) {
        if (errorMessages.length > 0) {
          let elen = errorMessages.length;
          let message = '';
          errorMessages.forEach(err => {
            if (err === 'sfss') {
              if (message.indexOf('Same shift is used for same supervisor') === -1) {
                message = message + 'Same shift is used for same supervisor</br>';
              }
            } else if (err === 'dfss') {
              if (message.indexOf('Different field agents are assigned to same checkpoint in the same shift timings') === -1) {
                message = message + 'Different field agents are assigned to same checkpoint in the same shift timings</br>';
              }
            } else if (err === 'nif') {
              if (message.indexOf('Iterations are needed for each assignment') === -1) {
                message = message + 'Iterations are needed for each assignment</br>';
              }
            } else if (err === 'ncf') {
              if (message.indexOf('Checkpoints are needed in assignment') === -1) {
                message = message + 'Checkpoints are needed in assignment</br>';
              }
            } else if (err === 'int9') {
              if (message.indexOf('Iterations need to be 9') === -1) {
                message = message + 'Iterations need to be 9</br>';
              }
            } else if (err === 'nea') {
              if (message.indexOf('More assignments needed') === -1) {
                message = message + 'More assignments needed</br>';
              }
            }
            elen--;
            if (elen === 0) {
              this.pedestrainAlertsService.conditionBeforeSubmit(message);
            }
          });
        } else { cb(); }
      }
    });
  }

  /* ********************** DELETORS **************************************
    deleteCircuit(index)
    deleteCheckpoint(index)
  */

  deleteCircuit(index) {
    this.pedestrainAlertsService.removeCircuitAlert().then(() => {
      this.mission.circuits.splice(index, 1);
    }).catch(() => { });;
  }

  deleteCheckpoint(index) {
    this.pedestrainAlertsService.removeCheckPoints()
      .then(() => {
        this.mission.checkpoints.splice(index, 1);
        let checkpointsLength;
        if (this.mission.checkpoints[0].selectedCircuit.circuitCheckpoints.lenght === undefined) {
          checkpointsLength = this.mission.checkpoints.length;
        } else {
          checkpointsLength = this.mission.checkpoints[0].selectedCircuit.circuitCheckpoints.lenght + this.mission.checkpoints.length;
        }
        if (checkpointsLength <= 3) {
          if (checkpointsLength > 2) {
            this.showAddNewCheckpoint = false;
          } else {
            this.showAddNewCheckpoint = true;
          }
        }
        this.checkpointMapGeoJSON.features.splice(index, 1);
      }).catch(() => { });
  }
   classic=true;
   market=false;
   marketid=null;
  onChecked(event,name){
    if(name==='market'){
      if(event.target.checked && this.marketid==null){
        this.buttonEnabled=false;
        this.marketZoneSelected=false;

      }
      if(!event.target.checked){
        this.marketZoneSelected=true;
        
        if(this.name && this.description && this.marketZoneSelected ){
          this.buttonEnabled=true;
      }

      }
      this.market=event.target.checked;
    }
    if(name==='classic'){
      this.marketid=null;
      this.selectedMarketZoneValue=this.translate.instant('Select market zone')
      this.market=false;
      this.classic=true;
    }
  }

}