import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PedestrianFlowComponent } from './pedestrian-flow.component';

describe('PedestrianFlowComponent', () => {
  let component: PedestrianFlowComponent;
  let fixture: ComponentFixture<PedestrianFlowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PedestrianFlowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PedestrianFlowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
