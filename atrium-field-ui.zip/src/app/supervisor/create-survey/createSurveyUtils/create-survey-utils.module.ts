// core
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// app
import { CreateSurveyUtilsService } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.service';
import { HttpService } from '@app/services/http-service';

@NgModule({
    imports: [CommonModule],
    providers: [CreateSurveyUtilsService, HttpService]
})
export class CreateSurveyUtilsModule { }