// core
import { Component, OnInit, AfterViewInit, Output, EventEmitter, Input, OnChanges } from '@angular/core';

// 3rd party
import { isEmpty } from "underscore";
import * as mapBox from 'mapbox-gl';
import * as mapboxCircle from 'mapbox-gl-circle';

// app
import { DataConstants } from '@app/constants/constants';
import { EventService } from '@services/events/event.service';

declare function require(name: string);
Object.getOwnPropertyDescriptor(mapBox, "accessToken").set(DataConstants.MAPBOX_ACCESS_TOKEN);
@Component({
  selector: 'app-circle-map',
  templateUrl: './circle-map.component.html',
  styleUrls: ['./circle-map.component.css']
})
export class CircleMapComponent implements OnInit, OnChanges, AfterViewInit {
  @Output() lngLat = new EventEmitter;
  @Input() disableClick: string;
  @Input() mapObject: any = [];
  @Input() isMarketUnchecked: boolean = false;
  firstAssigned: boolean = true;
  map;
  myCircle = new mapboxCircle({ lat: 39.984, lng: -75.343 }, 150, {
    editable: false,
    maxRadius: 150,
    fillColor: '#29AB87'
  });
  myCircle1 = new mapboxCircle({ lat: 39.984, lng: -75.343 }, 150, {
    editable: false,
    maxRadius: 150,
    fillColor: 'purple'
  });
  marker = new mapBox.Marker();
flag;
  constructor(public event: EventService) {
  }
  ngAfterViewInit() {
    // this.mapObject = { 'latitude': 50.84559909325273, 'longitude': 4.348614006026935 };
    this.mapInit();
    this.mapInitalizer();
    this.mapClickListner();
    this.mapResize();
  }

  ngOnInit() {
    this.firstAssigned = false;
    
  }

  sendLatLng(lngLat) {
    this.lngLat.emit(lngLat);
  }
  /* !this.firstAssigned &&  */
  ngOnChanges() {
         try 
     { if (!isEmpty(this.mapObject)) { this.mapInitalizer(); } } 
     catch (error) { console.log("Map Error"); } 
    }
  mapInit() {
    
    this.map = new mapBox.Map({
      container: 'map',
      style: 'mapbox://styles/mapbox/streets-v8',
      center: [4.348614006026935, 50.84559909325273],
      zoom: 16
    });
    this.map.addControl(new mapBox.NavigationControl());
  }
  // mapInitalizer() {
  //   if (!isEmpty(this.mapObject)) {
  //     console.log('mapObject',this.mapObject);
  //     this.mapObject.forEach(element => {
  //       this.flag=element.flag;
  //     });
  //     if(this.flag){
  //     this.mapObject.forEach(mapObject => {
  //     this.mapObject.latitude = parseFloat(mapObject.latitude).toFixed(14);
  //     this.mapObject.longitude = parseFloat(mapObject.longitude).toFixed(14);
  //     this.marker.setLngLat([parseFloat(mapObject.longitude), parseFloat(mapObject.latitude)]).addTo(this.map);
  //     this.map.flyTo({
  //       center: [parseFloat(mapObject.longitude), parseFloat(mapObject.latitude)],
  //       zoom: 16,
  //       bearing: 0,
  //       curve: 1
  //     });
  //     if(!mapObject.flag){
  //     this.myCircle.setCenter({ lat: parseFloat(mapObject.latitude), lng: parseFloat(mapObject.longitude) }).setRadius(150).addTo(this.map);
      
  //     }
  //     else{
  //       this.myCircle1.setCenter({ lat: parseFloat(mapObject.latitude), lng: parseFloat(mapObject.longitude) }).setRadius(150).addTo(this.map);

  //     }
  //   });}
  //   else{
  //     this.mapObject.latitude = parseFloat(this.mapObject.latitude).toFixed(14);
  //     this.mapObject.longitude = parseFloat(this.mapObject.longitude).toFixed(14);
  //     this.marker.setLngLat([parseFloat(this.mapObject.longitude), parseFloat(this.mapObject.latitude)]).addTo(this.map);
  //     this.map.flyTo({
  //       center: [parseFloat(this.mapObject.longitude), parseFloat(this.mapObject.latitude)],
  //       zoom: 16,
  //       bearing: 0,
  //       curve: 1
  //     });
      
  //     this.myCircle.setCenter({ lat: parseFloat(this.mapObject.latitude), lng: parseFloat(this.mapObject.longitude) }).setRadius(150).addTo(this.map);
      
  //   }
  // }
  // }
  csStep4Map=[]
  mapInitalizer() {
    console.log(this.mapObject)
    
    if (this.mapObject.length ===0) {
      console.log('119');
      this.myCircle.setCenter({ lat: 0, lng: 0 }).setRadius(150).addTo(this.map);
    } else if(this.mapObject[0].hasOwnProperty('step4')){
      console.log("has property");
      
      this.mapObject.forEach(mapObject => {
        this.mapObject.latitude = parseFloat(mapObject.latitude).toFixed(14);
        this.mapObject.longitude = parseFloat(mapObject.longitude).toFixed(14);
        this.marker.setLngLat([parseFloat(mapObject.longitude), parseFloat(mapObject.latitude)]).addTo(this.map);
        this.map.flyTo({
          center: [parseFloat(mapObject.longitude), parseFloat(mapObject.latitude)],
          zoom: 16,
          bearing: 0,
          curve: 1
        });

        if (mapObject.step4) {
          console.log("green map...",mapObject.flag);
          
          this.myCircle.setCenter({ lat: parseFloat(mapObject.latitude), lng: parseFloat(mapObject.longitude) }).setRadius(150).addTo(this.map);

        }
        else {
          console.log("purple map....",mapObject.flag);
          
          this.myCircle1.setCenter({ lat: parseFloat(mapObject.latitude), lng: parseFloat(mapObject.longitude) }).setRadius(150).addTo(this.map);

        }
      });
    }
    else {
      this.mapObject.forEach(element => {
        // if(element.flag){
          this.flag = element.flag;
        // } else {
        //   this.csStep4Map.push(element)

        // }
      
      });
      if (this.flag) {
        console.log("flaggg test..!!");
        
        // console.log('81');
        this.mapObject.forEach(mapObject => {
          this.mapObject.latitude = parseFloat(mapObject.latitude).toFixed(14);
          this.mapObject.longitude = parseFloat(mapObject.longitude).toFixed(14);
          this.marker.setLngLat([parseFloat(mapObject.longitude), parseFloat(mapObject.latitude)]).addTo(this.map);
          this.map.flyTo({
            center: [parseFloat(mapObject.longitude), parseFloat(mapObject.latitude)],
            zoom: 16,
            bearing: 0,
            curve: 1
          });

          if (!mapObject.flag) {
            console.log("green map...",mapObject.flag);
            
            this.myCircle.setCenter({ lat: parseFloat(mapObject.latitude), lng: parseFloat(mapObject.longitude) }).setRadius(150).addTo(this.map);

          }
          else {
            console.log("purple map....",mapObject.flag);
            
            this.myCircle1.setCenter({ lat: parseFloat(mapObject.latitude), lng: parseFloat(mapObject.longitude) }).setRadius(150).addTo(this.map);

          }
        });
      }
      else {
        console.log('103', this.mapObject);
        if (this.isMarketUnchecked == true){
          this.myCircle1.remove();
          // this.map = new mapBox.Map({
          //   container: 'map',
          //   style: 'mapbox://styles/mapbox/streets-v8',
          //   center: [4.348614006026935, 50.84559909325273],
          //   zoom: 16
          // });
          // this.map.addControl(new mapBox.NavigationControl());
          // this.mapResize();
          // this.mapClickListner();
        }

          this.mapObject.latitude = parseFloat(this.mapObject[0].latitude).toFixed(14);
          this.mapObject.longitude = parseFloat(this.mapObject[0].longitude).toFixed(14);
          this.marker.setLngLat([parseFloat(this.mapObject[0].longitude), parseFloat(this.mapObject[0].latitude)]).addTo(this.map);
          this.map.flyTo({
            center: [parseFloat(this.mapObject[0].longitude), parseFloat(this.mapObject[0].latitude)],
            zoom: 16,
            bearing: 0,
            curve: 1
          });
  
          this.myCircle.setCenter({ lat: parseFloat(this.mapObject[0].latitude), lng: parseFloat(this.mapObject[0].longitude) }).setRadius(150).addTo(this.map);
       

      }
  
    }
  }
  mapClickListner() {
    this.map.on('click', (e) => {
      if (!this.disableClick) {
        try {
          this.marker.setLngLat([e.lngLat.lng, e.lngLat.lat]).addTo(this.map);
          this.sendLatLng([e.lngLat.lng, e.lngLat.lat]);
          this.myCircle.setCenter({ lat: e.lngLat.lat, lng: e.lngLat.lng }).setRadius(150).addTo(this.map);
          this.map.flyTo({
            center: [e.lngLat.lng, e.lngLat.lat],
            zoom: 16,
            bearing: 1,
            curve: 1
          });
        } catch (error) { console.log('Exception Handled'); }
      } else {
        
        this.marker.remove();
        console.log("elseee",this.marker);

      }
    });
  }

  mapResize() {
    this.map.on('load', (e) => {
      this.map.resize();
    });
  }
}
