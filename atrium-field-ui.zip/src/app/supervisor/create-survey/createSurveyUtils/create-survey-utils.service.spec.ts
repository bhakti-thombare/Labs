import { TestBed, inject } from '@angular/core/testing';

import { CreateSurveyUtilsService } from './create-survey-utils.service';

describe('CreateSurveyUtilsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CreateSurveyUtilsService]
    });
  });

  it('should be created', inject([CreateSurveyUtilsService], (service: CreateSurveyUtilsService) => {
    expect(service).toBeTruthy();
  }));
});
