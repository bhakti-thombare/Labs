// core
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// 3rd party
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxMapboxGLModule } from 'ngx-mapbox-gl';
import { ChartsModule } from 'ng2-charts';
import { TagInputModule } from 'ngx-chips';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { TranslateModule } from '@ngx-translate/core';
import { Ng4FilesModule } from 'angular4-files-upload';
import { NgSelectModule } from '@ng-select/ng-select';


// app 
import { CONFIG } from '@app/config';
import { PipesModule } from '@pipes/pipes.module';
import { CreateSurveyUtilsModule } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.module';
import { PedestrianFlowComponent } from '@app/supervisor/create-survey/pedestrian-flow/pedestrian-flow.component';
import { CustomerSurveyComponent } from '@app/supervisor/create-survey/customer-survey/customer-survey.component';
import { CircleMapComponent } from '@app/supervisor/create-survey/createSurveyUtils/circle-map/circle-map.component';
import { PosPoiFlowComponent } from '@app/supervisor/create-survey/pos-poi-flow/pos-poi-flow.component';
import { PosPoiCMapComponent } from '@app/supervisor/create-survey/pos-poi-flow/pos-poi-c-map/pos-poi-c-map.component';
import { MissionPreviewComponent } from '@app/supervisor/create-survey/pos-poi-flow/mission-preview/mission-preview.component';
import { QuartierPreviewComponent } from '@app/supervisor/create-survey/pos-poi-flow/quartier-preview/quartier-preview.component';
import { DateAndAgentPreviewComponent } from '@app/supervisor/create-survey/pos-poi-flow/date-and-agent-preview/date-and-agent-preview.component';
import { StandsComponent } from './stands/stands.component';

@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    PipesModule,
    TranslateModule,
    NgxChartsModule,
    CreateSurveyUtilsModule,
    TagInputModule,
    ChartsModule,
    Ng4FilesModule,
    FormsModule,
    ReactiveFormsModule,
    NgxMapboxGLModule.forRoot({
      accessToken: CONFIG.mapBoxAccessToken
    }),
    SelectDropDownModule,
    NgSelectModule
  ],
  exports: [PedestrianFlowComponent, CustomerSurveyComponent, PosPoiFlowComponent, PosPoiCMapComponent,StandsComponent,CircleMapComponent],
  declarations: [PedestrianFlowComponent, CustomerSurveyComponent, CircleMapComponent, PosPoiFlowComponent, PosPoiCMapComponent, MissionPreviewComponent, QuartierPreviewComponent, DateAndAgentPreviewComponent, StandsComponent]
})
export class CreateSurveyModule { }
