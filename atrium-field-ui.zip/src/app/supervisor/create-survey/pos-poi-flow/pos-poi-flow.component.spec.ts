import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PosPoiFlowComponent } from './pos-poi-flow.component';

describe('PosPoiFlowComponent', () => {
  let component: PosPoiFlowComponent;
  let fixture: ComponentFixture<PosPoiFlowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PosPoiFlowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PosPoiFlowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
