import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuartierPreviewComponent } from './quartier-preview.component';

describe('QuartierPreviewComponent', () => {
  let component: QuartierPreviewComponent;
  let fixture: ComponentFixture<QuartierPreviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuartierPreviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuartierPreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
