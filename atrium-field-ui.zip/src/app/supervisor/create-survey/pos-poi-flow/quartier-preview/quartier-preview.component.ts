import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'quartier-preview',
  templateUrl: './quartier-preview.component.html',
  styleUrls: ['./quartier-preview.component.css']
})
export class QuartierPreviewComponent implements OnInit {
  @Input() mission: any = {};
  @Input() subType: string;
  @Input() quartierName: string;
  @Input() numberOfPOS: number = 0;
  @Input() numberOfCheckpoints: number = 0;
  @Input() quartierDetails: Array<any> = [];
  @Input() coordinates: Array<any> = [];
  constructor() { }

  ngOnInit() {
  }

}
