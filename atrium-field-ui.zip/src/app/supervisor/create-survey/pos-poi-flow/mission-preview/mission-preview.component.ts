import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'mission-preview',
  templateUrl: './mission-preview.component.html',
  styleUrls: ['./mission-preview.component.css']
})
export class MissionPreviewComponent implements OnInit {
  @Input() mission: any = {};
  @Input() campaignName
  constructor() { }

  ngOnInit() {
    console.log("input missions=", this.mission );
    
  }

}
