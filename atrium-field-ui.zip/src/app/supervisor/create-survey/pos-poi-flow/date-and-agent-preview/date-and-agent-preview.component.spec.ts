import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DateAndAgentPreviewComponent } from './date-and-agent-preview.component';

describe('DateAndAgentPreviewComponent', () => {
  let component: DateAndAgentPreviewComponent;
  let fixture: ComponentFixture<DateAndAgentPreviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DateAndAgentPreviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DateAndAgentPreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
