import { Component, OnInit, Input } from '@angular/core';

import { UTILS } from '@services/global-utility.service';

@Component({
  selector: 'date-and-agent-preview',
  templateUrl: './date-and-agent-preview.component.html',
  styleUrls: ['./date-and-agent-preview.component.css']
})
export class DateAndAgentPreviewComponent implements OnInit {
  @Input() mission: any = {};
  @Input() assignments: any = {};
  @Input() filedAgent: any = {};
  @Input() days: number;
  startDate: Date;
  endDate: Date;
  constructor() { }

  ngOnInit() {
    console.log("this.assignments=",this.assignments);
    console.log("fieldagent in date component=",this.filedAgent);
    
    
    // this.startDate = new Date(UTILS.getDateTimeFormat(this.assignments.startDate))
    // this.endDate = new Date(UTILS.getDateTimeFormat(this.assignments.endDate))
    this.startDate=this.assignments.startDate;
    this.endDate=this.assignments.endDate
  }

}
