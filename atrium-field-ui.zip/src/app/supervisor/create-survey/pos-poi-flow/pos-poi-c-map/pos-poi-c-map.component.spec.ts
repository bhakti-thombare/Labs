import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PosPoiCMapComponent } from './pos-poi-c-map.component';

describe('PosPoiCMapComponent', () => {
  let component: PosPoiCMapComponent;
  let fixture: ComponentFixture<PosPoiCMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PosPoiCMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PosPoiCMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
