// core
import { Component, OnInit, Output, EventEmitter, Input, OnChanges } from '@angular/core';


// 3rd party
import { fromPromise } from 'rxjs/observable/fromPromise';
import * as mapBox from 'mapbox-gl';
import {
  each,
  keys,
  isNull,
  map,
  values,
  isArray,
  filter,
  isString,
  isNumber
} from "underscore";

// app
import { EventService } from '@services/events/event.service';
import { GlobalUtility } from '@services/global-utility.service';

declare var google;
declare let L;
@Component({
  selector: 'app-pos-poi-c-map',
  templateUrl: './pos-poi-c-map.component.html',
  styleUrls: ['./pos-poi-c-map.component.css']
})

export class PosPoiCMapComponent implements OnChanges {
  @Output() lngLat = new EventEmitter;
  @Input() disableClick: string;
  @Input() quartierDetails: any = {};
  @Input() coordinateOnMap: any = {};

  @Input() coordinates: Array<any> = [];
  @Input() mapObject: any = { 'latitude': 4.355607, 'longitude': 50.878899 };
  map;
  dynamicId: number = 0;
  firstAssigned: boolean = true;
  constructor(public event: EventService, public globalUtils: GlobalUtility) { }

  ngAfterViewInit() {
    this.mapInit();
    this.mapInitalizer();
    this.mapClickListner();
    this.mapResize();
    this.firstAssigned = false;
  }
  ngOnChanges($event) {
    let changedVariables = keys($event);
    if (changedVariables.includes('coordinates')) this.setCoordinates($event);
    if (changedVariables.includes('coordinateOnMap')) {
      this.setCoordinatesOnMap(this.coordinateOnMap);
    }
    if (changedVariables.includes('quartierDetails')) {
      this.setQuartierDetailsPOS();
      this.setQuartierDetailsCheckpoints();
    }
  }
  setCoordinatesOnMap(locateCoordinates) {
    let newCoordinates = [];
    if (locateCoordinates) {
      this.removeMarkerCheckpoints();
      newCoordinates = [locateCoordinates.latitude, locateCoordinates.longitude];
      this.flyTo1(newCoordinates);
      this.setMarkerCheckpoints(locateCoordinates.latitude, locateCoordinates.longitude);
      this.setOnMPD(locateCoordinates.latitude, locateCoordinates.longitude);
    }
  }
  mapInit() {
    this.map = new mapBox.Map({
      container: 'map',
      style: 'mapbox://styles/mapbox/streets-v8',
      center: [4.355607, 50.878899],
      zoom: 8
    });
    this.map.addControl(new mapBox.NavigationControl());

  }
  mapInitalizer() {
    this.map.flyTo({
      center: [4.355607, 50.878899],
      zoom: 8,
      bearing: 0,
      curve: 1
    });

    // this.setMarker(0, 0);
  }
  mapClickListner() {
    this.map.on('click', (e) => {
      console.log(e);
      this.map.resize();
    });
  }

  mapResize() {

    this.map.on('load', (e) => {
      this.map.resize();
      if (!isNull(this.coordinates)) {
        if (this.coordinates.length > 0) {
          this.loadPolygon(`${this.dynamicId + 2}`);
          let times = 0;
          let interval = setInterval(() => {
            this.map.resize();
            if (times == 5) clearInterval(interval);
            else times++;
          }, 1000);
        }
      }
    });

  }
  source: any
  loadPolygon(dynamicId) {
    fromPromise(
      new Promise((resolve, reject) => {
        resolve({
          cords: map(this.coordinates, (co) => {
            return map(
              values(co), (mco) => {
                return parseFloat(mco)
              }).reverse();
          }), length: this.coordinates.length
        });
      })
    ).subscribe((cords) => {
      
      if (isArray(cords['cords'])) {
        let id = 'maine' + dynamicId;

        /**Code for Issue 848 Start */
        //this.flyTo(cords['cords'][0]);
        //console.log("cords==>",cords);
        let flyToCenter;
        if(cords['cords'].length){
          let centerCoordinates = [this.findCenterLong(cords),this.findCenterLat(cords)];
          //console.log("centerCoordinates",centerCoordinates);
          flyToCenter = centerCoordinates;
        }
        this.flyTo(flyToCenter);
        /**Code for Issue 848 End */
        
        if (cords['length'] > 0) {
          this.map.addLayer({
            'id': id,
            'type': 'line',
            'source': {
              'type': 'geojson',
              'data': {
                'type': 'Feature',
                'geometry': {
                  'type': 'Polygon',
                  'coordinates': [cords['cords']]
                }
              }
            },
            'layout': {},
            'paint': {
              'line-color': '#29AB87',
              'line-width': 3
            }
          });
          this.map.resize();
        }
      }
    });
  }
  
  /**Code for Issue 848 Start */
  findCenterLat(cords){
    let centerLat = 0;
    if (isArray(cords['cords'])){
      if(cords['cords'].length){
        let MinLat = cords['cords'][0][1];
        let MaxLat = cords['cords'][0][1];
        cords['cords'].forEach(element => {
          //console.log("element[0]==:",element[0]," && element[1]==:",element[1]);
          if(element[1]<MinLat){MinLat = element[1]}
          if(element[1]>MaxLat){MaxLat = element[1]}
        });
        //console.log("MinLat",MinLat,"MaxLat",MaxLat);
        centerLat = MinLat + ((MaxLat - MinLat)/2);
        return centerLat;
      }
    }
  }
  findCenterLong(cords){
    let centerLon = 0;
    if (isArray(cords['cords'])){
      if(cords['cords'].length){
        let MinLon = cords['cords'][0][0];
        let MaxLon = cords['cords'][0][0];
        cords['cords'].forEach(element => {
          //console.log("element[0]==:",element[0]," && element[1]==:",element[1]);
          if(element[0]<MinLon){MinLon = element[0]}
          if(element[0]>MaxLon){MaxLon = element[0]}
        });
        //console.log("MinLon",MinLon,"MaxLon",MaxLon);
        centerLon = MinLon + ((MaxLon - MinLon)/2);
        return centerLon;
      }
    }
  }
  /**Code for Issue 848 End */


  sendLatLng(lngLat) {
    this.lngLat.emit(lngLat);
  }
  Markers: Array<any> = [];
  MarkersPOS: Array<any> = [];
  Bounds: Array<any> = [];
  setMarkerPOS(lng, lat) {
    // create a DOM element for the marker
    let el = document.createElement('span');
    el.className = 'marker';
    el.style.backgroundImage = 'url(/assets/icons/posDot.png)';
    el.style.backgroundRepeat = "no-repeat";
    el.style.backgroundSize = "contain";
    el.style.width = '20px';
    el.style.height = '20px';
    // add marker to map
    let marker = new mapBox.Marker(el);
    marker.setLngLat([lng, lat]).addTo(this.map);
    this.MarkersPOS = [...this.MarkersPOS, marker];
  }
  bounds = new mapBox.LngLatBounds();
  setMarkerCheckpoints(lng, lat) {

    let el = document.createElement('span');
    el.className = 'marker';
    // $(el).text(this.index);
    el.style.backgroundImage = 'url(/assets/icons/checkpointDot.png)';
    el.style.backgroundRepeat = "no-repeat";
    // el.style.textAlign = "center";
    // el.style.color = "#fff";
    el.style.backgroundSize = "100% 100%";
    el.style.width = '20px';
    el.style.height = '20px';
    // add marker to map
    setTimeout(() => {
      let marker = new mapBox.Marker(el)
        .setLngLat([lng, lat])
        .addTo(this.map);
      this.Markers = [...this.Markers, marker];
    }, 0);
    // this.bounds.extend(new mapBox.LngLat(lng, lat));
  }

  setOnMPD(lng, lat) {
    // create a DOM element for the marker
    let el = document.createElement('span');
    el.className = 'marker';
    // $(el).text(this.index);
    el.style.backgroundImage = 'url(/assets/icons/posDot.png)';
    el.style.backgroundRepeat = "no-repeat";
    // el.style.textAlign = "center";
    // el.style.color = "#fff";
    el.style.backgroundSize = "100% 100%";
    el.style.width = '20px';
    el.style.height = '20px';
    // add marker to map
    setTimeout(() => {
      let marker = new mapBox.Marker(el)
        .setLngLat([lng, lat])
        .addTo(this.map);
      this.Markers = [...this.Markers, marker];
    }, 0);
    // this.bounds.extend(new mapBox.LngLat(lng, lat));
  }
  async removeMarkerCheckpoints() {
    return each(this.Markers, (marker) => {
      marker.remove();
    });
  }
  async removeMarkerPOS() {
    return each(
      this.MarkersPOS, (marker) => {
        marker.remove();
      });
  }
  flyTo(a: Array<number>) {
    if (this.map) {
      this.map.flyTo({
        center: a,
        zoom: 13,
        bearing: 0,
        curve: 1
      });    
    }
  }

  flyTo1(a: Array<number>) {
    if (this.map) {
      this.map.flyTo({
        center: a,
        zoom: 19,
        bearing: 0,
        curve: 1
      });    
    }
  }

  addPolygone(dynamicId) {
    if (this.map.getLayer(`maine${(dynamicId - 1)}`)) {
      fromPromise(new Promise((resolve) => resolve(this.map.removeLayer(`maine${dynamicId - 1}`))))
        .subscribe(() => {
          this.loadPolygon(`${dynamicId}`);
        });
    } else {
      this.loadPolygon(`${dynamicId}`);
    }
  }
  async getActiveCheckpoints(checkpints: Array<any> = []) { return filter(checkpints, (checkpoint) => checkpoint.checkpoint == 1); }
  /* OnChange Methods */
  setQuartierDetailsPOS() {
    try {
      const pos = (this.quartierDetails.pos) ? JSON.parse(this.quartierDetails.pos) : null;
      if (isArray(pos)) {
        this.removeMarkerPOS().then(() => {
          each(pos, (qpos) => {
            const lng = parseFloat(parseFloat(qpos.pos_longitude_wgs84).toFixed(5));
            const lat = parseFloat(parseFloat(qpos.pos_latitude_wgs84).toFixed(5));
            this.setMarkerPOS(lng, lat);
          });
        });
      } else {
        this.removeMarkerPOS();
      }
    } catch (error) { console.log("Map Error"); }
  }

  checkPoints: Array<any> = [];
  index = 0;
  setQuartierDetailsCheckpoints() {
    try {
      const checkpoints = (this.quartierDetails.checkPoints) ? JSON.parse(this.quartierDetails.checkPoints) : null;
      if (isArray(checkpoints)) {
        this.removeMarkerCheckpoints().then(() => {
          this.getActiveCheckpoints(checkpoints)
            .then(checkpointsFiltered => {
              each(checkpointsFiltered, (checkpoint) => {
                const lng = parseFloat((checkpoint.wgs84_X));
                const lat = parseFloat((checkpoint.wgs84_Y));
                this.checkPoints = [...this.checkPoints, [lng, lat]];
                this.setMarkerCheckpoints(lng, lat);
              });
            });
        });
      } else {
        this.removeMarkerCheckpoints();
      }
    } catch (error) { console.log("Map Error"); }
  }
  setCoordinates($event) {
    try {
      if (!$event.coordinates.firstChange) {
        if (isArray($event.coordinates.previousValue) ||
          isString($event.coordinates.previousValue) ||
          isNumber($event.coordinates.previousValue)) {
          this.addPolygone(this.dynamicId);
          this.dynamicId++;
          // this.loadPolygon(0);
        }
      }
    } catch (error) { console.log("Map Error", error); }
  }
  /* OnChange Methods */

  async getGeoJSON(checkpoints: Array<any>) {
    const geoJSON = { "type": "FeatureCollection", "features": [] }
    return {
      ...geoJSON, features: map(checkpoints, (checkpoint) => {
        const lng = parseFloat((checkpoint.y));
        const lat = parseFloat((checkpoint.x));
        return {
          "type": "Feature",
          "properties": { "iconSize": [20, 20] },
          "geometry": {
            "type": "Point",
            "coordinates": [lng, lat]
          }
        }
      })
    }
  }
}
