// core imports
import { Router } from '@angular/router';
import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  AfterViewInit,
  OnChanges,
  OnDestroy
} from '@angular/core';
import { Validators, FormGroup, FormBuilder, FormControl } from '@angular/forms';

// 3rd party library
import { Subscription } from 'rxjs/Subscription';
import * as $ from 'jquery';
import {
  each,
  map,
  isArray,
  filter,
  isEmpty,
  defaults,
  findWhere,
  isUndefined
} from 'underscore';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { TranslateService } from '@ngx-translate/core';
import {CampaignSummaryService} from '@services/campaign-summary/campaign-summary.service'

// application imports
import {
  AssignFA2POS,
  UpdateMission,
  MapPOS
} from '@services/apiServices/reqBodies';
import { PedestrainAlertsService } from '@services/Alerts/pedestrainAlerts/pedestrain-alerts.service';
import { EventService } from '@services/events/event.service';
import { UTILS } from '@services/global-utility.service';
import { statuses, Globals, missionTypes } from '@app/constants/constants';
import { ApiService } from '@services/apiServices/api.service';
import {
  UnassignedUsersPos,
  MapQuartier
} from '@services/apiServices/reqBodies';
import { Step4Wizards } from '@app/model/pos-models';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { CustomerSurveyAlertsService } from '@app/services/Alerts/customer-survey-alerts.service';
import { StorageService } from '@app/services/storage-service.service';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Http } from '@angular/http';
import { HttpService } from '@app/services/http-service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-pos-poi-flow',
  templateUrl: './pos-poi-flow.component.html',
  styleUrls: ['./pos-poi-flow.component.css']
})
export class PosPoiFlowComponent
  implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  @ViewChild('stepOne') stepOne: ElementRef;
  @ViewChild('stepTwo') stepTwo: ElementRef;
  private utilityFunctions = new UtilityFunctions();
  private subscriptions: Subscription[] = [];

  /* Object Declations */
  isStepDone: Step4Wizards = {
    step1Completed: false,
    step2Completed: false,
    step3Completed: false,
    step4Completed: false
  };
  missionFromScratch: any = {};
  unAssignedMission: any = {};
  campaingConfig: any = {};
  unAssignedMConf: any = {};
  config: any = {};
  configQuartier: any = {};
  configSubtype: any = {};
  configAgents: any = {};
  // Missions objects step wise
  step1MissionsObj: any = {};
  quartierDetails: any = {};
  datesData: any;
  /* Object Declations */

  /* Array Declarations */
  campaign: any = null;
  missionDates: Array<string> = [];
  coordinates: any = [];
  campaignOptions: Array<any> = [];
  unAssignedMissions: Array<any> = [];
  optionsQuartier: any = [];
  optionsAgents: any = [];
  optionsSubtype: any = [];
  options: any = [];
  /* Array Declarations */

  /* Flag declarations */
  user = JSON.parse(localStorage.getItem('user-data'));
  quartier: any = null;
  selectedFieldAgent: any = null;
  days: number = 0;
  step: any = 1;
  today: Date = new Date();
  missionId: number;
  missionName: string;
  localUtilInstance: any;
  globals: any;
  maxDate: any;
  minDate: any;
  transactionMsg: string;
  selectedMission: Array<any> = [];
  selectedSubtype: any = null;
  /* Flag declarations */

  /* Boolean declarations */
  isSkip: boolean = false;
  safari: boolean;
  isQuartierReceived: boolean = false;
  isYetToAssignMissions: boolean = false;
  noCampains: boolean = false;
  isStep: any = { step1: false, step2: false, step3: false, step4: false };
  /* Boolean declarations */

  /* Validation objects */
  step1Form: FormGroup;
  step3Form: FormGroup;
  fieldName: string;
  agentAssigned=false;
  placeName: any;

  /* Validation objects */

  constructor(
    public pedestrainAlertsService: PedestrainAlertsService,
    public apiService: ApiService,
    public fb: FormBuilder,
    private event: EventService,
    private router: Router,
    private pedsAlerts: PedestrainAlertsService,
    private translate: TranslateService,
    public custAlerts: CustomerSurveyAlertsService,
    private storageService: StorageService,
    private CampaignSelected:CampaignSummaryService,
    private http:HttpClient

  ) {}
  textControl = new FormControl();
  textControl1 = new FormControl();

  nameExists=false;
  name=false;
  description=false;
  buttonEnabled=false;  
  ngOnInit() {
    this.placeName=this.translate.instant('Select compaign');
      this.textControl1.valueChanges.pipe(
        ).subscribe((res)=>{
          // res=res.trim();
          res=$.trim(res);

             if(res !== ''){
               this.description=true
             } else {
               this.description=false
             }
             if(this.name && this.description){
                 this.buttonEnabled=true;
             } else {
               this.buttonEnabled=false;
             }
        });
      this.textControl.valueChanges.pipe(
      ).subscribe((res)=>{
        //  res=(res.toString()).trim();
        res=$.trim(res)
        ;
        
        if(res !== ''){
          this.name=true
        } else {
          this.name=false
        }
        if(this.name && this.description){
          this.buttonEnabled=true;
      } else {
        this.buttonEnabled=false;
      }
      if(res!==''){
        this.apiService.getMissionName(res).subscribe((res)=>{
            
          this.nameExists=false;
          this.name=true;
          
      
        
      },(error)=>{
          this.name=false;
          this.nameExists=true;
      
        
      })
      }
        
      });


    this.localUtilInstance = UTILS;
    this.globals = Globals;
    this.campaingConfig = {
      displayKey: 'campaignName',
      search: true,
      placeholder: this.translate.instant('Select campaign'),
      multiple: false
    };
    this.unAssignedMConf = {
      displayKey: 'missionName',
      search: true,
      placeholder: this.translate.instant('Select Mission'),
      multiple: false,
      limitTo: 10
    };
    this.config = {
      displayKey: 'name',
      search: true,
      placeholder: this.translate.instant('Select capmpaign'),
      multiple: false,
      limitTo: 5
    };
    this.configQuartier = {
      displayKey: 'name',
      search: true,
      placeholder: this.translate.instant('Select quartier'),
      multiple: false,
      limitTo: 10
    };
    this.configSubtype = {
      displayKey: 'name',
      search: false,
      placeholder: this.translate.instant('Select Subtype'),
      multiple: false,
      notFoundText: this.translate.instant('No items found')
    };
    this.configAgents = {
      displayKey: 'fullname',
      search: true,
      placeholder: this.translate.instant('Select agent'),
      multiple: false
    };
    this.event.showLoader({});
    this.getAllCampaigns();
    this.step1Validation();
    this.step3Validation();
    this.getAllPosMissions();
    this.getBrowserName();
    this.getMissiondates();
    this.getMission(this.missionId)
    // Temporary basis
    // this.getAllQuartiers();
    // this.getUsedMissionDates(this.today);
  }

  ngAfterViewInit() {
    this.borderTheSelectDropdown();
    let search = this.translate.instant('Search');
    $('.ngx-dorpdown-container').on('click', function() {
      $('.search-container > label').html(
        '<span _ngcontent-c8="" class="nsdicon-search"></span> ' + search
      );
    });
  }

  ngOnChanges($event) {
    console.log($event);
  }
  goto(){
    
    this.router.navigate(['/supervisor/missions'])
  }
  /* Step functionality */
  stepTraverser(_step) {
    this.step = _step;
    this.isStep = { ...this.getDefaultStep(), [`step${_step}`]: true };
  }
  stepCheckAndOpen(_step) {
    this.fieldName = this.storageService.getData('fieldName');
    this.step = _step;
  }
  getDefaultStep() {
    return defaults(this.isStep, {
      step1: false,
      step2: false,
      step3: false,
      step4: false
    });
  }

  skipStep(stepFrom) {
    this.isSkip = true;
    // this.isStepDone[`step${stepFrom}Completed`] = true;
    this.stepTraverser(stepFrom + 1);
    this.getAllQuartiers();
  }

  getBrowserName() {
    var ua = navigator.userAgent.toLowerCase();
    if (ua.indexOf('safari') != -1) {
      if (ua.indexOf('chrome') > -1) {
        // console.log('Chrome Detected...'); // Chrome
      } else {
        this.safari = true;
        // console.log('safari Detected...');
      }
    }
  }
  //step 1
  missionDescription;
  missionStep1;
  createMission() {
    this.missionStep1={
      campaignName:this.campaign,
      missionType:"POS",
      missionName:this.missionName,
      missionDescription:this.missionDescription,
      classic:this.classic,
      pmr:this.pmr,
      visits:this.visits,
      morning:this.morning
    }
    if(this.compaignName==this.translate.instant('Select compaign')){
      this.pedestrainAlertsService.selectCampagin();
    }
    else{
      this.event.showLoader({});
      let obj = {
        missionTypeId: 2,
        missionCreationDate: UTILS.getDateFormat(
          UTILS.getDatePickerDateFormat(new Date())
        ),
        missionCampaignId: this.campaignId,
        // updatedBy: this.user.userId,
        missionCreatedById: this.user.userId,
        classic: true,
        market: false,
  
        prm:this.pmr,
        visits:this.visits,
        marketZone:null,
        missionStatusId: this.agentAssigned ?6:3,
        // ...this.step1Form.value
        missionName:this.missionName,
        missionDescription:this.missionDescription
      };
      this.missionFromScratch = this.step1Form.value;
      this.missionName = this.step1Form.value.missionName;
      this.isStepDone.step1Completed = true;
      this.addMission(obj);
    }
    
    // if (!isEmpty(this.campaign) && this.step1Form.valid) {
     
    // } else {
    //   this.noCampains = true;
    // }
    // }"missionName": "Test CS Mission",
    // "missionDescription": "Test CS Mission",
    // "missionTypeId": 4,
    // "missionCreationDate": "2020-8-24 00:00:00",
    // "missionCampaignId": 145,
    // "missionCreatedById": 93,
    // "missionStatusId": 3,
    // "missionSubSection" : 1,
    // "marketZone" : null,
    // "prm" : false,
    // "visits" : false
    // this.stepTraverser(2);
  }
  //step 2
  assignOrCreateQuartier() {
    this.event.showLoader({});
    this.getUsedMissionDates(this.today)
    this.mapQuartier({
      mission: this.missionId,
      quartier: this.quartier.quartierId,
      user: this.user.userId,
      creationDate: UTILS.getDateFormatWithTime(new Date()),
      updatedOn: UTILS.getDateFormatWithTime(new Date())
    });
  }
  userId=true;
  saveWithoutAssign(){
    // this.selectedFieldAgent.fullname="";
    this.userId=false;
    this.assignFieldAgents(false);
    this.selectedFieldAgent.fullname=this.translate.instant('Select agent')
    this.storageService.setData('fieldName', this.translate.instant('Select agent'));

  }
  //step 3
  dateObj;
  step3completed=false;
  assignFieldAgents(flag) {
    this.agentAssigned=true;
    if(!this.userId){
      this.userId=false;
    } else {
      this.userId=true
    }
    this.step3completed=true;
    var elemant1 = document.getElementById('calender');
            elemant1.setAttribute("disabled","true"); 
    this.event.showLoader({});
    this.dateObj={
      startDate:this.startDate,
      endDate:this.startDate
    }
    this.missionStep1={
      campaignName:this.campaign,
      missionType:"POS",
      missionName:this.missionName,
      missionDescription:this.missionDescription,
      classic:this.classic,
      pmr:this.pmr,
      visits:this.visits,
      morning:this.morning
    }
    this.updateMission(
      {
        ...UTILS.getUpdateMissionBody(),
        missionId: this.missionId,
        missionSubSection:1,
        subType: this.selectedSubtype.id,

        // missionStartDate: UTILS.getDateTimeFormat(
        //   this.step3Form.value.startDate
        // ),
        
        missionStartDate:this.startDate,
        missionEndDate:this.startDate,
        // missionEndDate: UTILS.getDateTimeFormat(
        //   this.step3Form.value.endDate
        // ),
        missionUpdatedById: this.user.userId
      },
      4
    );

    this.assignPosMission({
      missionId: this.missionId,
      campaignId: this.campaignId,
      shift:this.morning?1:2,
      missionDates: [this.missiondates],
      userId: this.userId?this.selectedFieldAgent.userId:null,
      createdBy: this.user.userId,
      updatedBy: this.user.userId,
      status: statuses.YETTOASSIGN,
      creationDate: null,
      lastUpdatedOn: null,
      assignMission : flag
    });
  }

  // step 4
  submit() {
    this.router.navigate(['supervisor/missions']);
  }
  /* Step functionality */

  /* Dynamic css */
  borderTheSelectDropdown() {
    $('.ngx-dorpdown-container').css('border', '1px solid lightgray');
    $('.ngx-dropdown-button').css('border-bottom', 'none !important');
  }
  /* Dynamic css */

  /* API CALLS */
  compaignName;
  campaignData;
  campaignId;
  getAllCampaigns() {
    this.subscriptions.push(
      this.apiService
        .getAllCampaigns({ assignedTo: this.user.userId })
        .subscribe(
          res => {
            this.event.hideLoader({});

            //this.campaignOptions = res.data.campaigns;
            /** Start Code to get Valid Campaign in POS Creation Dropdown List (In Progress campaign only displayed By checking the End Date of the Campaign*/

            let tempCampList: any = [];
            const today = new Date(Date.now());
            const todayDate = new Date(
              today.getFullYear(),
              today.getMonth(),
              today.getDate()
            );
            //console.log("todayDate:::::",todayDate);
            res.data.campaigns.forEach(camp => {
              const campEndDay = parseInt(
                camp.campaignEndDate.split('-')[2].split(' ')[0],
                10
              );
              const campEndMonth = parseInt(
                camp.campaignEndDate.split('-')[1],
                10
              );
              const campEndYear = parseInt(
                camp.campaignEndDate.split('-')[0],
                10
              );
              const endDate = new Date(
                campEndYear,
                campEndMonth - 1,
                campEndDay,
                23,
                59,
                59,
                0
              );

              if (endDate >= todayDate) {
                //console.log("endDate::::====",endDate);
                tempCampList.push(camp);
              }
            });
            // this.campaignOptions = tempCampList;

            /* Start _1 :This is implemented by using Campaign Status as In-Progress
        let tempCampList: any = [];

        console.log("res",res.data.campaigns);
        res.data.campaigns.forEach(element => {
          if(element.campaignStatus.statusId == 2){
            //console.log("CAmpaign IN Prog:",element);
            tempCampList.push(element);
          }
        });
        //console.log(tempCampList);
        
        this.campaignOptions = tempCampList;
        /** End */
            // this.compaignName=res.data.campaigns[0].campaignName
            this.campaign=res.data.campaigns[0];
            this.campaignData=res.data.campaigns;
            const todaydate = new Date(
              today.getFullYear(),
              today.getMonth(),
              today.getDate()
            );

            if(this.CampaignSelected.selectedCampaign!==undefined){
              const campaignEndDate = new Date(this.CampaignSelected.selectedCampaign.campaignEndDate)
              // if(!(campaignEndDate < todaydate)){
              //   this.compaignName=this.translate.instant('Select compaign');
              // } else {
                this.campaignData.forEach((element,index)=>{
                  if(this.CampaignSelected.selectedCampaign.campaignId!==element.campaignId){
                    const campaignEndDate = new Date(element.campaignEndDate)
                    console.log("campaign undefined",campaignEndDate);
                    
                    if (!(campaignEndDate < todaydate)){
                      this.compaignName=this.translate.instant('Select compaign')
  
                      this.campaignOptions.push(element);
                    }
                  }
                  else{
                    const campaignEndDate = new Date(element.campaignEndDate)
                   
                    if (!(campaignEndDate < todaydate)){
                      this.compaignName=this.translate.instant('Select compaign')
  
                      this.campaignOptions.push(element);
                    }
                  
                  }
                })
              // }
              this.campaignId=this.CampaignSelected.selectedCampaign.campaignId;
              // this.campaignData.forEach((element,index)=>{
              //   // if(this.CampaignSelected.selectedCampaign.campaignId!==element.campaignId){
              //     const campaignEndDate = new Date(element.campaignEndDate)
                  
              //     if (!(campaignEndDate < today)){
              //       this.campaignOptions.push(element)

              //     }
              //   // }
              // })
            } else {
              this.compaignName=this.translate.instant('Select compaign');
              // this.campaignId=res.data.campaigns[0].campaignId;
              this.campaignData.forEach((element,index)=>{
                // if(res.data.campaigns[0].campaignId!==element.campaignId){
                  const campaignEndDate = new Date(element.campaignEndDate)                  
                  if (!(campaignEndDate < todaydate)){
                  this.campaignOptions.push(element)
                // }
              }
              })
            }
            // this.campaignOptions = res.data.campaigns; /** by Mohammad Shuaib */
          //  this.campaignOptions= this.campaignOptions.slice(1)
            
          },
          err => {
            this.event.hideLoader({});
          }
        )
    );
  }

  addMission(requestPayload) {
    this.subscriptions.push(
      this.apiService.addMission(requestPayload, {}).subscribe(
        res => {
          this.event.hideLoader({});
          this.pedsAlerts.missionCreatedSuccessPOSAlert().then(() => {
            this.missionId = parseInt(res.responseMessage.split(' ')[2]);
            this.getMission(this.missionId)
            this.isStep.step1 = true;
            this.stepTraverser(2);
            this.getAllQuartiers(); //get quartiers list
          });
        },
        err => {
          this.event.hideLoader({});
          this.pedsAlerts.somethingWentWrong();
        }
      )
    );
  }

  getAllPosMissions() {
    this.subscriptions.push(
      this.apiService
        .getAllPosMissions({ statusId: statuses.YETTOASSIGN })
        .subscribe(
          res => {
            if (res) {
              this.unAssignedMissions = res.data.missions;
              this.isYetToAssignMissions = res.data.missions.length > 0;
              if (this.unAssignedMissions.length == 1) {
                this.missionId = this.unAssignedMissions[0].missionId;
                // this.missionName = this.unAssignedMissions[0].missionName;
              }
            }
          },
          err => {}
        )
    );
  }
  /* Get All Quartiers List for dropdown */
  getAllQuartiers() {
    this.subscriptions.push(
      this.apiService.getAllQuartiers({}).subscribe(
        res => {
          this.optionsQuartier = res.data.quartiers;
        },
        err => {
          console.log(err);
        }
      )
    );
  }
  /* Get only quartier on selection of quartier */
  quartierDetailsCheckpoints: Array<any> = [];
  quartierDetails2;
  getQuartiers(quartierId) {
    let data;
    this.subscriptions.push(
      this.apiService.getQuartiers({ quartierId: quartierId }).subscribe(
        res => {
          this.http.get(res.data).subscribe(result => {

          this.isQuartierReceived = false;
          if (result) {
            console.log("res=", result);

            this.quartierDetails = result;
            this.quartierDetails2 = result;
            const _data = this.quartierDetails.checkPoints
              ? JSON.parse(this.quartierDetails.checkPoints)
              : [];
            this.quartierDetailsCheckpoints = _data;
            this.quartierDetails = {
              ...this.quartierDetails
            };
          } else this.quartierDetails = {};
          this.transactionMsg = '';
          this.setSubTypeOptions(this.quartierDetails);
        },
        err => {
          this.isQuartierReceived = false;
          this.transactionMsg = '';
          this.quartier = null;
          this.pedsAlerts.somethingWentWrong();
        }
      )
    },
    err => {
      this.isQuartierReceived = false;
      this.transactionMsg = '';
      this.quartier = null;
      this.pedsAlerts.somethingWentWrong();
    }));
  }

  /* Datepicker related API's */
  getUsedMissionDates(date) {
    let currentDate = UTILS.getDatePickerDateFormat(date);
    Globals.BUSY_DATES = []

    this.subscriptions.push(
      this.apiService
        .getShiftWiseUsedMissionDates(
          UTILS.getDateFormatWithoutZero(currentDate),
          missionTypes.POS_POI_TYPE_ID,this.morning?1:2
        )
        .subscribe(
          res => {
            Globals.BUSY_DATES = res.dateDto;
            
          },
          err => (Globals.BUSY_DATES = [])
        )
    );
  }
  
  /* Datepicker related API's */
  getAllUnassignedUsersPos(reqBody: UnassignedUsersPos) {
    this.optionsAgents=[]
    this.subscriptions.push(
      this.apiService.getAllUnassignedUsersPos(reqBody).subscribe(
        res => {
          this.selectedFieldAgentValue=false;

          this.optionsAgents = [];
          this.optionsAgents = map(res.users, m =>
            UTILS.extendKey(m, { fullname: `${m.firstName} ${m.lastName}` })
          );
        },
        err => {
          if (err.status === 400) {
            this.optionsAgents=[]
            this.selectedFieldAgentValue=false;
            this.custAlerts.noAgentFound();
          }
        }
      )
    );
  }

  mapQuartier(reqBody: MapQuartier) {
    this.subscriptions.push(
      this.apiService.mapQuartier({}, reqBody).subscribe(
        res => {
          if (res.responseCode == '200') {
            //Updating mission for subtype ['Stores only','Stores only And Stores & checkpoints]
            this.updateMission(
              {
                ...UTILS.getUpdateMissionBody(),
                missionId: this.missionId,
                subType: this.selectedSubtype.id,
                missionUpdatedById: this.user.userId,
                missionCampaignId: this.campaignId,
                missionCheckpointsToAdd: null,
                missionCircuits: null,
                missionCircuitsToAdd: null,
                      
missionCreatedById: null,
missionCreationDate: null,
missionDescription: null,
missionEndDate: this.startDate,
missionEstimatedTime: null,
missionIsArchived: null,
missionName: this.missionName,
missionNumberOfCheckpoints: null,
missionNumberOfCircuits: null,
missionStartDate: this.startDate,
missionStatusId: this.agentAssigned ?6:3,
missionTypeId: 3,
missionZonesToAdd: null,

              },
              3
            );
            
            //Mapping pos
            this.mapPOS();
          }
        },
        err => {
          this.event.hideLoader({});
          this.pedsAlerts
            .somethingWentWrong()
            .then(() => {})
            .catch(() => {});
        }
      )
    );
  }

  // Assign Field agent to mission
  assignPosMission(reqBody: AssignFA2POS) {
  
    this.subscriptions.push(
      this.apiService.assignPosMission({}, reqBody).subscribe(
        res => {
          if (res.responseCode == '200') {
            this.datesData = {
              startDate:this.startDate
              // startDate: new Date(
              //   UTILS.getDateFormat(this.step3Form.value.startDate)
              // ),
              // endDate: new Date(
              //   UTILS.getDateFormat(this.step3Form.value.endDate)
              // )
            };
            this.isStepDone.step3Completed = true;
            this.event.hideLoader({});
            this.pedsAlerts.assignmentSuccessAlert().then(() => {
               this.stepTraverser(4);

            });
          }
        },
        err => {
          this.event.hideLoader({});
          this.pedsAlerts.somethingWentWrong();
        }
      )
    );
  }

  // Add subtype into mission
  updateMission(objectParam: UpdateMission, step) {
    
    this.getMission(this.missionId);
    if (this.startDate != undefined){
      this.subscriptions.push(
        this.apiService
          .updateMission(
            {
            
                missionTypeId: 2,
                missionCreationDate: UTILS.getDateFormat(
                  UTILS.getDatePickerDateFormat(new Date())
                ),
                missionCampaignId: this.campaignId,
                missionId: this.missionId,
                missionStartDate:this.startDate,
                missionEndDate:this.startDate,
                missionUpdatedById: this.user.userId,
                // updatedBy: this.user.userId,
                missionCreatedById: this.user.userId,
                classic: true,
                market: false,
                subType: this.selectedSubtype.id,
  
                prm:this.pmr,
                visits:this.visits,
                marketZone:null,
                missionStatusId: this.agentAssigned ?6:3,
                // ...this.step1Form.value
                missionName:this.missionName,
                missionDescription:this.missionDescription
            
              
            },
            {}
          )
          .subscribe(
            
            res => {
              if (res.responseCode == '200') {
              }
            },
            err => {
              this.event.hideLoader({});
              this.pedsAlerts.somethingWentWrong();
            }
          )
      );
    }
  }

  getMission(id) {
    this.subscriptions.push(
      this.apiService.getAllMissions({ id: id }).subscribe(
        res => {
          
          this.selectedMission = [...res.data.missions];
        

          Globals.campaignStartDate =
            res.data.missions[0].missionCampaign.campaignStartDate;
            let startdate:any
            let endDate
            startdate=res.data.missions[0].missionCampaign.campaignStartDate;
            endDate=res.data.missions[0].missionCampaign.campaignEndDate;
            startdate = startdate.split(' ');   
            startdate =startdate[0].split('-');   
        const startdayObj={
        year:startdate[0],
        month:startdate[1],
        day:startdate[2]
        }
        endDate = endDate.split(' ');   
        endDate =endDate[0].split('-');   
        const enddayObj={
        year:endDate[0],
        month:endDate[1],
        day:endDate[2]
        }
        
        localStorage.setItem('campaignStartDate', JSON.stringify(startdayObj));
        localStorage.setItem('campaignEndDate', JSON.stringify(enddayObj));
          Globals.campaignEndDate =
            res.data.missions[0].missionCampaign.campaignEndDate;
          this.setMinMaxDate();
        },
        err => {
          console.log(err);
        }
      )
    );
  }

  mapPOS() {
    // let mapPOS: Array<MapPOS> = [];
    let mapPOS;
    mapPOS = this.quartierDetails2.pos
      ? JSON.parse(this.quartierDetails.pos)
      : [];
      
    this.updateJSONKeys(mapPOS).then(mapPOSRes => {
      this.subscriptions.push(
        this.apiService
          .mapPOS(
            {},
            {
              missionId: this.missionId,
              posDtos: mapPOSRes,
              quartierName: this.quartier.name,
              quartier: this.quartier.quartierId
            }
          )
          .subscribe(
            res => {
              if (res.responseCode == '200') {
                if (this.selectedSubtype.id) {
                  this.getQuartierAssignmentAlert();
                  this.mapPosCheckpints();
                }
              }
            },
            err => {
              this.event.hideLoader({});
            }
          )
      );
    });
  }

  mapPosCheckpints() {
    this.updateJSONKeys(this.quartierDetailsCheckpoints).then(
      mapCheckointsRes => {
        this.subscriptions.push(
          this.apiService
            .mapPosCheckpoints(
              {},
              {
                missionId: this.missionId,
                dtos: mapCheckointsRes
              }
            )
            .subscribe(
              res => {
                if (res.responseCode == '200') {
                  this.event.hideLoader({});
                  this.quartierDetailsCheckpoints = [];
                  this.getQuartierAssignmentAlert();
                }
              },
              err => {
                this.event.hideLoader({});
              }
            )
        );
      }
    );
  }
  /* API CALLS */

  /* Validators */
  step1Validation() {
    this.step1Form = this.fb.group({
      missionName: [
        {
          value: null,
          disabled: this.isStepDone.step1Completed
        },
        Validators.compose([
          Validators.required,
          Validators.maxLength(30),
          Validators.pattern('[a-zA-Z0-9_]+.*$')
        ])
      ],
      missionDescription: [
        { value: null, disabled: this.isStepDone.step1Completed },
        Validators.compose([Validators.maxLength(200)])
      ]
    });
  }
  step1ButtonValidation() {
    // if (!isEmpty(this.campaign)) 
    return true;
    // else return false;
  }
  step2Validation() {
    const isMissionSelected =
      !isEmpty(this.missionFromScratch) || this.missionId;
    if (
      !isEmpty(this.quartier) &&
      isMissionSelected &&
      !isEmpty(this.selectedSubtype)
    ) {
      return true;
    } else return false;
  }
  step3Validation() {
    this.step3Form = this.fb.group({
      missionName: [null, Validators.compose([Validators.required])],
      startDate: [null, Validators.compose([Validators.required])],
      endDate: [null, Validators.compose([Validators.required])]
    });
  }
  step4Validation() {
    return isEmpty(this.selectedFieldAgent);
  }
  /* Validators */

  /* Datepicker related methods */
  // isDisabled(date: NgbDate, current: { month: number }) {
  //   const isDateFind = findWhere(
  //     Globals.BUSY_DATES,
  //     UTILS.getDatePickerIntFormat(date)
  //   );
  //   const currentDate = new Date(UTILS.getDateFormat(date));
  //   const day = currentDate.getDay();
  //   const isWeekend = day != 0 && day != 6;
  //   if (!isWeekend || !isUndefined(isDateFind)) return true;
  //   else return false;
  // }
  busyDates;
  calendarReady
  getMissiondates(){
    const date = new Date(Date.now());
    const month = date.getMonth() + 1;
    localStorage.removeItem('busyDates');
    this.busyDates=[]
    this.apiService.getShiftWiseUsedMissionDates(date.getFullYear() + '-' + month + '-' + date.getDate(), missionTypes.CUSTOMER_SURVEY_TYPE_ID,this.morning?1:2)
    .subscribe(res => {
        
        let busyDatesLen = res.dateDto.length;
        res.dateDto.forEach(resdate => {
          resdate.day = parseInt(resdate.day, 10);
          resdate.month = parseInt(resdate.month, 10);
          resdate.year = parseInt(resdate.year, 10);
          
          this.busyDates.push(resdate);
          
          busyDatesLen--;
          if (busyDatesLen === 0) {
            localStorage.setItem('busyDates', JSON.stringify(this.busyDates));
            
            this.calendarReady = true;
          }
        });
      }, err => {
        this.calendarReady = true;
      });
   
  }
  isDisabled(date: NgbDateStruct, current: { month: number }) {

   
    // console.log("issisabled dates",this.campaignFlag);

const now = new Date(Date.now());
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
  const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
  const busyDates = JSON.parse(localStorage.getItem('busyDates'));
  
  const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
  
  const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
  const sdate = new Date(date.year, date.month - 1, date.day);

  if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
    if (busyDates !== null) {
      let found = -1;
      const dateFinder = (dateObj) => {
        const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
        if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
          inDate.getDate() === sdate.getDate()) {
          return true;
        } else {
          return false;
        }
      };

      found = busyDates.findIndex(dateFinder);
      if (found !== -1) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  } else {
    return true;
  }



}
  isDisabled2(date: NgbDate, current: { month: number }) {
    const isDateFind = findWhere(
      Globals.BUSY_DATES,
      UTILS.getDatePickerIntFormat(date)
    );
    const currentDate = new Date(UTILS.getDateFormat(date));
    const day = currentDate.getDay();
    const isWeekend = day != 0 && day != 6;
    if (!isWeekend && isUndefined(isDateFind)) return true;
    else return false;
  }
  /* Datepicker related methods */

  /* Events */
  selectedCompaign=false;

  selectCampaign(event) {
    this.campaignOptions=[]
    this.compaignName=event.campaignName;
    this.campaignId=event.campaignId;
    const today=new Date()
    const todayDate = new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate()
    );
    this.campaignData.forEach((element,index)=>{
      if(this.campaignId!==element.campaignId){
        const campaignEndDate = new Date(element.campaignEndDate)
        
        if (!(campaignEndDate < todayDate)){
          this.campaignOptions.push(element);
        }
      }
    })
    
    
    this.selectedCompaign=true;
    this.campaign = event;
  }
  getOnlyQuartier($event) {
    if ($event) {
      this.coordinates = [];
      this.selectedSubtype = null;
      this.isQuartierReceived = true;
      this.transactionMsg = this.translate.instant(
        'Getting quartier boundary coordinates'
      );
      this.subscriptions.push(
        this.apiService
          .getQuartierCordinates({ quartier: this.quartier.quartierId })
          .subscribe(
            res => {
              this.coordinates = res.data.dtos ? res.data.dtos : [];
              this.transactionMsg = this.translate.instant(
                'Getting quartier details'
              );
              this.getQuartiers(this.quartier.quartierId);

            },
            err => {
              this.isQuartierReceived = false;
              this.transactionMsg = '';
              this.pedsAlerts
                .somethingWentWrong()
                .then(() => {
                  this.quartier = null;
                })
                .catch(() => {});
            }
          )
      );
    }
  }

  getPosLength(data: any) {
    try {
      const _data = data.pos ? JSON.parse(data.pos) : [];
      if (isArray(_data)) return _data.length;
      else return 0;
    } catch (error) {
      console.log(error);
    }
  }

  getCheckpointsLength(data: any) {
    try {
      const _data = data.checkPoints ? JSON.parse(data.checkPoints) : [];
      if (isArray(_data)) return filter(_data, d => d.checkpoint == 1).length;
      else return 0;
    } catch (error) {
      console.log(error);
    }
  }

  getExistingMissionaName($event) {
    this.unAssignedMission.missionName = $event;
    this.missionName = $event ? $event.missionName : null;
    this.missionId = $event ? $event.missionId : null;
  }
 startDate;
 dateSelected=false;
 missiondates;
 currentDate;
 endDate;
 missionStartDate;
 selectedDate;
 missionDate
 campaignFlag
  getDate(d1) {
    const date = d1;
    this.currentDate = this.startDate;
    this.dateSelected = true;
    const months = String(date.month).padStart(2, "0");
    const days = String(date.day).padStart(2, "0");
    this.missiondates = `${date.year}-${months}-${days}`
    this.startDate = `${d1.year}-${months}-${days} 00:00:00`

    var g1 = new Date();
    // (YYYY-MM-DD) 
    var CurrentDate = new Date()
    var d = new Date();
    // var d = new Date(CurrentDate),
    let dateToday = {
      month: '' + (d.getMonth() + 1),
      day: '' + d.getDate(),
      year: d.getFullYear()
    }


    if (dateToday.month.length < 2)
      dateToday.month = '0' + dateToday.month;
    if (dateToday.day.length < 2)
      dateToday.day = '0' + dateToday.day;
    var today = `${dateToday.year}-${dateToday.month}-${dateToday.day}`
    let endDateCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
    let startDateCheck = JSON.parse(localStorage.getItem('campaignStartDate'));


    var endDateCheck1 = new Date(`${endDateCheck.year}-${endDateCheck.month}-${endDateCheck.day}`)
    var startDateCheck1 = new Date(`${startDateCheck.year}-${startDateCheck.month}-${startDateCheck.day}`)



    // var g2 = new Date(`${d1.year}-${d1.month}-${d1.day}`); 
    var GivenDate = new Date(`${d1.year}-${d1.month}-${d1.day}`);
    const month1 = String(d1.month).padStart(2, "0");
    const day1 = String(d1.day).padStart(2, "0");
    const month = String(d1.month).padStart(2, "0");
    const day = String(d1.day).padStart(2, "0");
    this.selectedDate = `${d1.year}-${month}-${day} 00:00:00`
    this.missionDate = `${d1.year}-${month}-${day}`

    var todayDate = `${d1.year}-${month1}-${day1}`
    if (localStorage.getItem('campaignFlag')==='true') {
      if ((!(GivenDate > endDateCheck1) && !(GivenDate < startDateCheck1)) || (GivenDate == startDateCheck1)) {
        const month = String(d1.month).padStart(2, "0");
        const day = String(d1.day).padStart(2, "0");
        this.selectedDate = `${d1.year}-${month}-${day} 00:00:00`
        this.missionDate = `${d1.year}-${month}-${day}`


        if (GivenDate >= CurrentDate || (today === todayDate)) {
          // } else if(this.minDate.day===d1.day) {

          this.dateSelected = true;
          this.missionStartDate = {
            year: d1.year,
            month: d1.month,
            day: d1.day
          }
          // const month=String(d1.month).padStart(2, "0");
          // const day=String(d1.day).padStart(2, "0");
          // this.startDate=`${d1.year}-${month}-${day} 00:00:00`
          this.currentDate = this.startDate;

          this.getAllUnassignedUsersPos({
            // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
            // endDate: UTILS.getDateFormatWithTime(endDate),
            startDate: `${date.year}-${date.month}-${date.day}`,
            endDate: `${date.year}-${date.month}-${date.day}`,
            iterations: 9,
            shift: this.morning ? 1 : 2,
            missionId: this.missionId
          });
        }
      }
    } else {
      if (GivenDate >= CurrentDate || (today === todayDate)) {
        // } else if(this.minDate.day===d1.day) {

        this.dateSelected = true;
        this.missionStartDate = {
          year: d1.year,
          month: d1.month,
          day: d1.day
        }
        // const month=String(d1.month).padStart(2, "0");
        // const day=String(d1.day).padStart(2, "0");
        // this.startDate=`${d1.year}-${month}-${day} 00:00:00`
        this.currentDate = this.startDate;
        this.getAllUnassignedUsersPos({
          // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
          // endDate: UTILS.getDateFormatWithTime(endDate),
          startDate: `${date.year}-${date.month}-${date.day}`,
          endDate: `${date.year}-${date.month}-${date.day}`,
          iterations: 9,
          shift: this.morning ? 1 : 2,
          missionId: this.missionId
        });
      }
    }


    // else {
    //   this.dateSelected=true;
    //   this.mission.missionStartDate={
    //      year:d1.year,
    //      month:d1.month,
    //      day:d1.day
    //   }
    //   const month=String(d1.month).padStart(2, "0");
    //   const day=String(d1.day).padStart(2, "0");
    //   this.startDate=`${d1.year}-${month}-${day} 00:00:00`
    //   this.assignmentObjectCreator();
    // }

  }

  getEndDate(date: NgbDate, currentMonth) {
    this.dateSelected=true;
    // const _date = new Date(UTILS.getDateFormat(date));
    // const campaignStartDate = new Date(Globals.campaignStartDate);
    // const campaignEndDate = new Date(Globals.campaignEndDate);
    // const current = { month: currentMonth };
    // const startDate = new Date(
    //   UTILS.getDateFormat(this.step3Form.value.startDate)
    // );
    // if (_date >= startDate) {
      // if (campaignStartDate <= _date && !this.isDisabled2(date, current)) {
        // this.step3Form.controls['endDate'].setValue(date);
        // this.step3Form.controls['missionName'].setValue(this.missionName);
        // let startDate = UTILS.getDateFormat(
        //   this.step3Form.controls['startDate'].value
        // );
        // const endDate = new Date(UTILS.getDateFormat(date));
        // UTILS.getDatesArrayByDates(new Date(startDate), endDate).then(data => {
        //   this.days = data.length;
        //   this.missionDates = data.dateArray;
        // });
        const month=String(date.month).padStart(2, "0");
      const day=String(date.day).padStart(2, "0");
      this.missiondates=`${date.year}-${month}-${day}`
        this.startDate=`${date.year}-${month}-${day} 00:00:00`;
        this.getAllUnassignedUsersPos({
          // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
          // endDate: UTILS.getDateFormatWithTime(endDate),
          startDate:`${date.year}-${date.month}-${date.day}`,
          endDate:`${date.year}-${date.month}-${date.day}`,
          iterations: 9,
          shift: this.morning?1:2,
          missionId: this.missionId
        });
      // }
    // }
  }
  selectedFieldAgentValue=false;
  getFieldAgent($event) {
    this.selectedFieldAgentValue=true;
    this.selectedFieldAgent = $event;
    this.storageService.setData('fieldName', this.selectedFieldAgent.fullname);
  }

  getSubtype($event) {
    this.selectedSubtype = $event;
  }

  setSubTypeOptions(quartierDetails) {
    if (this.getCheckpointsLength(quartierDetails) > 0) {
      this.optionsSubtype = [];
      this.optionsSubtype = this.getTranslation(Globals.MISSION_SUBTYPES_BOTH);
    } else {
      this.optionsSubtype = [];
      this.optionsSubtype = this.getTranslation(
        Globals.MISSION_SUBTYPES_STOERS
      );
      this.selectedSubtype = this.getTranslation(
        Globals.MISSION_SUBTYPES_STOERS
      )[0];
    }
  }
  resetEnddate(date) {
    this.days = 0;
    this.step3Form.controls['endDate'].setValue(null);
    this.optionsAgents = [];
  }
  /* Events */

  
  /* UTILS */
  setMinMaxDate() {
    const minDate_ = new Date(UTILS.getDateTimeFormat(UTILS.minDate));
    const campaignStartDate = new Date(Globals.campaignStartDate);
    if (minDate_ < campaignStartDate)
      this.minDate = UTILS.getDatePickerDateFormat(Globals.campaignStartDate);
    else this.minDate = UTILS.minDate;

    this.maxDate = UTILS.getDatePickerDateFormat(Globals.campaignEndDate);
    
  }
  setCampaignId() {
    
    if (isEmpty(this.campaign))
    
    
      return this.selectedMission[0].missionCampaign.campaignId;
    else return this.campaign.campaignId;
    
  }

  async updateJSONKeys(data: Array<any>) {
    return map(data, (item, index) => {
      return this.getRenamedObject(item);
    });
  }

  getRenamedObject(obj) {
    let newObj = {};
    each(obj, (value, key) => {
      newObj[UTILS.toCamelCase(key.split('_').join(' '))] = value;
    });
    return newObj;
  }

  getQuartierAssignmentAlert() {
    this.pedsAlerts
      .quartierAssignSuccessAlert()
      .then(() => {
        this.isStepDone.step2Completed = true;
        this.stepTraverser(3);
      })
      .catch(() => {});
  }
  //translating the values of subtype dropdown
  getTranslation(obj: Array<any> = []) {
    let newObj = [];
    each(obj, (o, i) => {
      newObj.push({ ...o, name: this.translate.instant(o.name.toString()) });
    });
    return newObj;
  }

  ngOnDestroy() {
    this.storageService.removeData('fieldName');
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }
  
  classic=true;
  visits=false;
  pmr=false;
  onChecked(event,id){
    if(event.target.checked){
         if(id==='classic'){
           this.classic=true;
         } else if(id==='pmr'){
           this.pmr=true;
         } else {
           this.visits=true;
         }
    }
    if(!event.target.checked){
      if(id==='classic'){
        this.classic=false;
      } else if(id==='pmr'){
        this.pmr=false;
      } else {
        this.visits=false;
      }

 }
    
  }
  
  morning=true;
  changeShiftId(id) {
    
    
    if (id === 1) {
      this.morning = true;
      this.getUsedMissionDates(this.today);
      if(this.startDate !== undefined){
        this.getAllUnassignedUsersPos({
          // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
          // endDate: UTILS.getDateFormatWithTime(endDate),
          startDate:this.startDate,
          endDate:this.startDate,
          iterations: 9,
          shift: this.morning?1:2,
          missionId: this.missionId
        });
      }
     
    } else {
      this.morning = false;
      this.getUsedMissionDates(this.today);
      if(this.startDate !== undefined){
        this.getAllUnassignedUsersPos({
          // startDate: UTILS.getDateFormatWithTime(new Date(startDate)),
          // endDate: UTILS.getDateFormatWithTime(endDate),
          startDate:this.startDate,
          endDate:this.startDate,
          iterations: 9,
          shift: this.morning?1:2,
          missionId: this.missionId
        });
      }
    }
  }
}
