export const CONFIG = {
    "mapBoxAccessToken": 'pk.eyJ1IjoiYmxhemVjbGFuIiwiYSI6ImNqOWZxM3h1MzAzMW8zMnJxd3g0NzZ5a20ifQ.5IdwsnKmxrQftgM-3-P5IA#11.0/50.839325/4.347952/0',
    "gmapAPIKey": 'AIzaSyCZVe-L8JKBxpndD6l5CgsRiPQ1LwjrfH0'
}