// core imports
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule} from '@angular/forms';

// 3rd party imports
import { NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { TagInputModule } from 'ngx-chips';
import { ChartsModule } from 'ng2-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { TranslateModule } from '@ngx-translate/core';

// app imports
import { DashboardComponent} from '@app/admin/dashboard/dashboard.component';
import { AdminRoutes} from '@app/admin/admin.routes';
import { UsersComponent } from '@app/admin/users/users.component';
import { CampaignComponent } from '@app/admin/campaign/campaign.component';
import { AssignCampaignComponent } from '@app/admin/assign-campaign/assign-campaign.component';
import { CreateCampaignComponent } from '@app/admin/create-campaign/create-campaign.component';
import { AddUserComponent } from '@app/admin/add-user/add-user.component';
import { InvitePeopleComponent } from '@app/admin/invite-people/invite-people.component';
import { EditCampaignComponent } from '@app/admin/edit-campaign/edit-campaign.component';
import { EditUserComponent } from '@app/admin/edit-user/edit-user.component';
import { ProfileComponent } from '@app/admin/profile/profile.component';
import { ActivitiesComponent } from '@app/admin/activities/activities.component';
import { ReportsComponent } from '@app/admin/reports/reports.component';
import { RoleComponent } from '@app/admin/role/role.component';
import { CreateRoleComponent } from '@app/admin/create-role/create-role.component';
import { EditRoleComponent } from '@app/admin/edit-role/edit-role.component';
import { TeamManagementComponent } from '@app/admin/team-management/team-management.component';
import { PipesModule } from '@pipes/pipes.module';
import { CreateTeamComponent } from '@app/admin/create-team/create-team.component';
import { EditTeamComponent } from '@app/admin/edit-team/edit-team.component';
import { UnavailabilityComponent } from '@app/admin/unavailability/unavailability.component.ts';
import { AdminComponent } from './admin.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminRoutes),
    NgbModule,
    NgxChartsModule,
    TranslateModule,
    TagInputModule,
    ChartsModule,
    PipesModule,
    FormsModule,
  ],
  declarations: [
    AdminComponent,
    DashboardComponent,
    UsersComponent,
    CampaignComponent,
    AssignCampaignComponent,
    CreateCampaignComponent,
    AddUserComponent,
    InvitePeopleComponent,
    EditCampaignComponent,
    EditUserComponent,
    ProfileComponent,
    ActivitiesComponent,
    ReportsComponent,
    RoleComponent,
    CreateRoleComponent,
    EditRoleComponent,
    TeamManagementComponent,
    CreateTeamComponent,
    EditTeamComponent,
    UnavailabilityComponent
  ]
})
export class AdminModule {}
