// core imports
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Location } from '@angular/common';

// app imports
import { HttpService } from '@app/services/http-service';
import { EventService } from '@services/events/event.service';
@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})
export class RoleComponent implements OnInit, AfterViewInit {
  private roles: any;

  constructor(
    private http: HttpService,
    private location: Location,
    private event: EventService
  ) { }

  ngOnInit() {
    this.getAllRoles();
  }

  ngAfterViewInit() {
    this.event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'got-all-roles-event') {
          if (window.innerWidth <= 414) {
            $('.hide-in-mobile').css('display', 'none');
          }
        }
      }
    });
  }

  getAllRoles() {
    this.http.SecureGet('/ref/getAllRoles?withModules=true').subscribe(
      res => {
        this.roles = res.data;
        let roles_len = this.roles.length;
        this.roles.forEach(role => {
          if (role.modules.length !== 0) {
            const len = role.modules.length;
            role.csvModules = '';
            role.modules.forEach(module => {
              if (role.csvModules === '') {
                role.csvModules = module.name;
              } else {
                role.csvModules = role.csvModules + ', ' + module.name;
              }
            });
          } else {
            role.csvModules = 'No Modules assigned yet.';
          }
          roles_len--;
          if (roles_len === 0) {
            setTimeout(() => {
              this.event.broadcast({
                eventName: 'got-all-roles-event',
                data: ''
              });
            }, 30);
          }
        });
      },
      err => {
        console.log(err);
      }
    );
  }

  editRole(role) {
  }
}
