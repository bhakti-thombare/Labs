// core imports
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

// 3rd party
import 'rxjs/add/operator/map';
import swal from 'sweetalert2';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

// app imports
import { HttpService } from '@app/services/http-service';
import { CampaignSummaryService } from '@services/campaign-summary/campaign-summary.service';
import { EventService } from '@services/events/event.service';
import { TranslationService } from '@services/translation/translation.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';
@Component({
  selector: 'app-edit-campaign',
  templateUrl: './edit-campaign.component.html',
  styleUrls: ['./edit-campaign.component.css']
})
export class EditCampaignComponent implements OnInit {
  public campaign = {
    name: '',
    description: '',
    campaignStartDate: {
      day: null,
      month: null,
      year: null
    },
    campaignEndDate: {
      day: null,
      month: null,
      year: null
    },
    campaignStatus: {
      statusId: null,
      statusName: undefined
    },
    campaignIsArchived: false
  };
  public disableSubmit = false;
  public myForm: FormGroup;
  public campaignId;
  selectedSupervisor = {
    firstName: '',
    lastName: '',
    isActive: false,
    resetProfile: true,
    userId: null
  };
  supervisors = [];


  today = new Date(Date.now());

  minDate = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };

  minEndDate = {
    day: null,
    month: null,
    year: null
  };

  startDateEntered = false;
  showFieldAgents = false;

  model: NgbDateStruct;

  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6;
  }


  isDisabled(date: NgbDateStruct, current: { month: number }) {
    const now = new Date(Date.now());
    const missionStatus = localStorage.getItem('missionStatus');
    const missionStartDate = JSON.parse(localStorage.getItem('campaignMissionStartDate'));
    const missionEndDate = JSON.parse(localStorage.getItem('missionEndDate'));

    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const sdate = new Date(date.year, date.month, date.day);
    const startdate = new Date(missionStartDate.year, missionStartDate.month, missionStartDate.day);
    const enddate = new Date(missionStartDate.year, missionStartDate.month, missionStartDate.day);

    if(missionStatus=="2"){

      console.log("helloooo");
      
      if (startdate >= sdate && enddate >= startdate) {
        return false;
      } else {
        return true;
      }
    } else{
      if (sdate >= today) {
        return false;
      } else {
        return true;
      }
    }
    
  }

  isEndDisabled(date: NgbDateStruct, current: { month: number }) {
    //return true means disable the dates
    // console.log("active campaign=",this.activeCampaign);
    
    const missionStatus = localStorage.getItem('missionStatus');

    const localDate = JSON.parse(localStorage.getItem('date'));
    const missionDate = JSON.parse(localStorage.getItem('missionEndDate'));

    const now = new Date(Date.now());
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const sdate = new Date(date.year, date.month - 1, date.day);
    const minDate = new Date(localDate.year, localDate.month - 1, localDate.day);
    if(missionStatus=="2"){
      const minDate = new Date(missionDate.year, missionDate.month - 1, missionDate.day);

      if (sdate >= minDate && sdate >= today) {
        return false;
      } else {
        return true;
      }
    } else {
      if (sdate >= minDate && sdate >= today) {
        return false;
      } else {
        return true;
      }
    }
   
  }

  activeCampaign;
  constructor(public location: Location,
    public router: Router,
    public http: HttpService,
    private route: ActivatedRoute,
    public campServ: CampaignSummaryService,
    public event: EventService,
    public translateService: TranslationService) {
    this.route.params.subscribe(params => {
      this.campaignId = params.id;
      this.event.broadcast({ eventName: 'showLoader', data: '' });
      this.http.SecureGet('/ref/getAllCampaigns?id=' + params.id).subscribe(res => {
        const c = res.data.campaigns[0];
        localStorage.setItem('missionStatus',c.campaignStatus.statusId);

        // if(c.campaignStatus.statusId==2){
          const campaignMissionStartDate={
            day:c.campaignMissionStartDate?c.campaignMissionStartDate.substring(8,10):"06",
            month:c.campaignMissionStartDate?c.campaignMissionStartDate.substring(5,7):"11",
            year:c.campaignMissionStartDate?c.campaignMissionStartDate.substring(0,4):"2020"
          }
          const missionEndDate={
            day:c.campaignMissionEndDate?c.campaignMissionEndDate.substring(8,10):"06",
            month:c.campaignMissionEndDate?c.campaignMissionEndDate.substring(5,7):"11",
            year:c.campaignMissionEndDate?c.campaignMissionEndDate.substring(0,4):"2020"
          }
          localStorage.setItem('missionEndDate', JSON.stringify(missionEndDate));
          localStorage.setItem('campaignMissionStartDate', JSON.stringify(campaignMissionStartDate));


          
        // }

        console.log('Campaign', c);
        if (c.campaignAssignedTo === null) {
          this.getAllFieldAgents();
        } else {
          if (c.campaignStatus.statusName === 'Pending') {
            this.getAllMissionsAssociatedWithCampaign(() => {
              this.getAllFieldAgents(c.campaignAssignedTo);
            });
          } else {
            this.showFieldAgents = false;
            this.event.broadcast({ eventName: 'hideLoader', data: '' });
          }
        }
        const startDate = {
          day: null,
          month: null,
          year: null
        };
        const endDate = {
          day: null,
          month: null,
          year: null
        };
        if (c.campaignStartDate) {
          startDate.day = parseInt(c.campaignStartDate.split(' ')[0].split('-')[2], 10);
          startDate.month = parseInt(c.campaignStartDate.split(' ')[0].split('-')[1], 10);
          startDate.year = parseInt(c.campaignStartDate.split(' ')[0].split('-')[0], 10);
          endDate.day = parseInt(c.campaignEndDate.split(' ')[0].split('-')[2], 10);
          endDate.month = parseInt(c.campaignEndDate.split(' ')[0].split('-')[1], 10);
          endDate.year = parseInt(c.campaignEndDate.split(' ')[0].split('-')[0], 10);
          this.startDateEntered = true;
          const today = new Date(Date.now());
          if (today.getFullYear() === startDate.year) {
            if ((today.getMonth() + 1) === startDate.month) {
              if (today.getDate() <= startDate.day) {
                this.minDate = {
                  day: today.getDate(),
                  month: today.getMonth() + 1,
                  year: today.getFullYear()
                };
              } else {
                this.minDate = startDate;
              }
            } else {
              this.minDate = startDate;
            }
          } else {
            this.minDate = startDate;
          }
          console.log('startDate', startDate);
          console.log('endDate', endDate);
        }
        this.campaign = {
          name: c.campaignName,
          description: c.campaignDescription ? c.campaignDescription : '',
          campaignStartDate: startDate,
          campaignEndDate: endDate,
          campaignStatus: c.campaignStatus,
          campaignIsArchived: c.campaignIsArchived
        };
        localStorage.setItem('date', JSON.stringify(startDate));
      }, err => {
        console.log('err', err);
      });
    });
  }


  ngOnInit() {
    this.myForm = new FormGroup({
      'campaignName': new FormControl('', Validators.required),
      'campaignDescription': new FormControl('', Validators.required)
    });
  }

  getAllMissionsAssociatedWithCampaign(cb) {
    this.http.SecureGet('/mission/getMissionCountsByCampaign?campaignId=' + this.campaignId).subscribe(res => {
      if (res.data.missionTotalCount > 0) {
        this.showFieldAgents = false;
        this.event.broadcast({ eventName: 'hideLoader', data: {} });
      } else {
        cb();
      }
    }, err => {
      this.showFieldAgents = false;
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
      console.log('err', err);
    });
  }

  goBack() {
    this.location.back();
  }

  getAllFieldAgents(existingUser?) {
    this.http.SecureGet('/ref/getAllUsers?roleId=2').subscribe(res => {
      let userCount = res.data.users.length;
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
      res.data.users.forEach(user => {
        if (existingUser) {
          if (user.isActive && !user.resetProfile) {
            if (user.userId !== existingUser.userId) {
              this.supervisors.push(user);
            } else {
              this.selectedSupervisor = existingUser;
            }
          }
        } else {
          if (user.isActive && !user.resetProfile) {
            this.supervisors.push(user);
          }
        }
        userCount--;
        if (userCount === 0) {
          if (existingUser) {
            if (Object.keys(this.selectedSupervisor).length === 0 && this.selectedSupervisor.constructor === Object) {
              this.selectedSupervisor = this.supervisors[0];
              this.supervisors.splice(0, 1);
              this.event.broadcast({ eventName: 'hideLoader', data: '' });
            }
          } else {
            this.selectedSupervisor = this.supervisors[0];
            this.supervisors.splice(0, 1);
            this.event.broadcast({ eventName: 'hideLoader', data: '' });
          }
          this.showFieldAgents = true;
        }
      });
    }, err => {
      console.log('Error found in getalluser', err);
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
    });
  }

  editCampaign(form) {
    if (form.valid && this.campaign.campaignStartDate.day != null && this.campaign.campaignEndDate.day != null) {
      this.disableSubmit = true;
      const camp = form.value;
      const user = JSON.parse(localStorage.getItem('user-data'));
      if (this.campaign.campaignStatus.statusId === 4) {
        camp.campaignAssignedTo = this.selectedSupervisor.userId;
      }
      camp.campaignUpdatedBy = user.userId;
      camp.campaignId = this.campaignId;
      camp.campaignStartDate = this.campaign.campaignStartDate.year +
        '-' + this.campaign.campaignStartDate.month +
        '-' + this.campaign.campaignStartDate.day + ' 00:00:00';
      camp.campaignEndDate = this.campaign.campaignEndDate.year + '-' +
        this.campaign.campaignEndDate.month + '-' +
        this.campaign.campaignEndDate.day + ' 00:00:00';
      camp.campaignStatus = this.campaign.campaignStatus.statusId;
      this.http.SecurePost('/campaign/updateCampaign', camp).subscribe(data => {
        console.log('data', data);
        this.campServ.getStatus();
        this.translateService.getLanguageValue(data.responseMessage).subscribe(resMessage => {
          swal(
            resMessage,
            '',
            'success'
          ).then(() => {
            this.location.back();
          });
        });
        // tslint:disable-next-line:no-unused-expression
        this.myForm.reset();
      }, err => {
        this.translateService.getLanguageValue(err.errorMessage).subscribe(errMessage => {
          swal(
            errMessage,
            '',
            'error'
          );
        });
      });
    } else {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.BOTH_FIELDS_MANDATORY).subscribe(res => {
        swal(
          res,
          '',
          'warning'
        );
      });
    }
  }

  changeLocalDate(date, e) {
    console.log(e);
    if (!e.target.classList.contains('text-lightgrey')) {
      this.campaign.campaignEndDate = {
        year: null,
        month: null,
        day: null
      };
      localStorage.setItem('date', JSON.stringify(date));
      this.minEndDate = date;
      this.startDateEntered = true;
    }
  }

  toggleSupervisor(supervisor) {
    if (this.selectedSupervisor.isActive && !this.selectedSupervisor.resetProfile) {
      this.supervisors.push(this.selectedSupervisor);
      let delIndex = -1;
      let len = this.supervisors.length;
      this.supervisors.forEach((sup, i) => {
        if (sup.userId === supervisor.userId) {
          delIndex = i;
        }
        len--;
        if (len === 0) {
          if (delIndex !== -1) {
            this.supervisors.splice(delIndex, 1);
            this.selectedSupervisor = supervisor;
          }
        }
      });
    } else {
      let delIndex = -1;
      let len = this.supervisors.length;
      this.supervisors.forEach((sup, i) => {
        if (sup.userId === supervisor.userId) {
          delIndex = i;
        }
        len--;
        if (len === 0) {
          if (delIndex !== -1) {
            this.supervisors.splice(delIndex, 1);
            this.selectedSupervisor = supervisor;
          }
        }
      });
    }
  }

}
