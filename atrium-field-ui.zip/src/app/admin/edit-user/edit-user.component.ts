// core imports
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

// 3rd party imports
import 'rxjs/add/operator/map';
import swal from 'sweetalert2';

// app imports
import { HttpService } from '@app/services/http-service';
import { TranslationService } from '@services/translation/translation.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  public disableSubmit = false;
  public user = {
    firstName: '',
    address: '',
    lastName: '',
    contact: '',
    roleId: ''
  };
  public userId;
  public role;
  constructor(public location: Location,
    public router: Router,
    public http: HttpService,
    private route: ActivatedRoute,
    private translateService: TranslationService) {
    this.route.params.subscribe(params => {
      this.userId = params.id;
      this.http.SecureGet('/ref/getAllUsers?id=' + params.id).subscribe(res => {
        const u = res.data.users[0];
        this.user = {
          firstName: u.firstName ? u.firstName : '',
          address: u.address ? u.address : '',
          lastName: u.lastName ? u.lastName : '',
          contact: u.contactNumber ? u.contactNumber : '',
          roleId: u.roleId ? u.roleId : ''
        };
        this.role = u.roleId === 2 ? 'Supervisor' : 'Field agent';
      }, err => {
      });
    });
  }
  private myForm = new FormGroup({
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    contact: new FormControl('', [Validators.required, Validators.pattern('^[1-9][0-9]{7,14}$')]),
    address: new FormControl('', Validators.required)
  });
  ngOnInit() {
    this.role = 'Field agent';
  }

  toggleRole(role2toggle) {
    console.log(role2toggle);
    this.role = role2toggle;
  }

  submit(form) {
    if (form.valid) {
      this.disableSubmit = true;
      console.log(form.value);
      const reqObj = {
        userId: this.userId,
        roleId: this.role === 'Field agent' ? 3 : 2,
        firstName: form.value.firstName,
        lastName: form.value.lastName,
        contactNumber: form.value.contact,
        address: form.value.address
      };

      this.http.SecurePost('/user/updateUser', reqObj).subscribe(res => {
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.USER_UPDATED_SUCCESSFULLY).subscribe(message => {
          swal(message, '', 'success').then(d => {
            this.location.back();
          });
        });
      }, err => {
        this.disableSubmit = false;
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.SOMETHING_WENT_WRONG).subscribe(messageTitle => {
          this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_CONTACT_ADMIN_FOR_THE_ASSISTANCE).subscribe(messageText => {
            swal(
              messageTitle,
              messageText,
              'error'
            );
          });
        });
      });
    }
  }

  goBack() {
    this.location.back();
  }

}
