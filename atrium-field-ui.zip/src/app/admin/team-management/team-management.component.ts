import { Component, OnInit } from '@angular/core';

import { HttpService } from '@app/services/http-service';
import { EventService } from '@services/events/event.service';

@Component({
  selector: 'app-team-management',
  templateUrl: './team-management.component.html',
  styleUrls: ['./team-management.component.css']
})
export class TeamManagementComponent implements OnInit {

  public teams: [any];
  public showTeams = false;

  constructor(public http: HttpService, public _event: EventService) { }

  ngOnInit() {
    this.getAllTeams();
  }

  getAllTeams() {
    this._event.broadcast({ eventName: 'showLoader', data: '' });
    this.http.SecureGet('/ref/getAllTeams?withMembers=true').subscribe(res => {
      this.teams = res.data;
      let teamsCount: number = this.teams.length;
      let membersFound = false;
      this.teams.forEach(team => {
        team.supervisor.fullName = team.supervisor.firstName + ' ' + team.supervisor.lastName;
        if (team.members != null) {
          let teamMembers = '';
          let len: number = team.members.length;
          team.members.forEach(member => {
            if (teamMembers !== '') {
              teamMembers = teamMembers + ', ' + member.firstName + ' ' + member.lastName;
            } else {
              teamMembers = teamMembers + member.firstName + ' ' + member.lastName;
            }
            len--;
            if (len === 0) {
              team.teamMembers = teamMembers;
              this.showTeams = true;
              membersFound = true;
              this._event.broadcast({ eventName: 'hideLoader', data: '' });
            }
          });
        }
        teamsCount--;
        if (teamsCount === 0) {
          if (membersFound) {
          } else {
            this.showTeams = false;
          }
        }
      });
    }, err => {
      this._event.broadcast({ eventName: 'hideLoader', data: '' });
    });
  }

}
