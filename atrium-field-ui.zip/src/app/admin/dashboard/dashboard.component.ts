// core imports
import {
  Component,
  OnInit,
  ElementRef,
  Renderer2,
  AfterViewInit,
  ViewChild
} from '@angular/core';
import {
  trigger,
  style,
  transition,
  animate,
  keyframes,
  query,
  stagger
} from '@angular/animations';
import { Location } from '@angular/common';

// 3rd party imports
import swal from 'sweetalert2';

// app imports
import { HttpService } from '@app/services/http-service';
import { CampaignSummaryService } from '@services/campaign-summary/campaign-summary.service';
import { EventService } from '@services/events/event.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  animations: [
    trigger('completeProgressBar', [
      transition('*=>*', [
        query(
          '.progress .progress-right .progress-bar',
          stagger('300ms', [
            animate(
              '1s ease-in',
              keyframes([
                style({ transform: 'rotate' + '(' + 0 + 'deg)' }),
                style({
                  transform:
                    'rotate' +
                    '(' +
                    sessionStorage.getItem('rightComplete') +
                    'deg)'
                })
              ])
            )
          ]),
          { optional: true }
        ),
        query(
          '.progress.blue .progress-left .progress-bar',
          stagger('300ms', [
            animate(
              '1s ease-in',
              keyframes([
                style({ transform: 'rotate(' + 0 + 'deg)' }),
                style({
                  transform:
                    'rotate' +
                    '(' +
                    sessionStorage.getItem('leftComplete') +
                    'deg)'
                })
              ])
            )
          ]),
          { optional: true }
        )
      ])
    ]),
    trigger('inProgressProgressBar', [
      transition('*=>*', [
        query(
          '.progress .progress-right .progress-bar',
          stagger('300ms', [
            animate(
              '1s ease-in',
              keyframes([
                style({ transform: 'rotate(0deg)' }),
                style({
                  transform:
                    'rotate' +
                    '(' +
                    sessionStorage.getItem('rightInProgress') +
                    'deg)'
                })
              ])
            )
          ]),
          { optional: true }
        ),
        query(
          '.progress.mediumorchid .progress-left .progress-bar',
          stagger('300ms', [
            animate(
              '1s ease-in',
              keyframes([
                style({ transform: 'rotate(0deg)' }),
                style({
                  transform:
                    'rotate' +
                    '(' +
                    sessionStorage.getItem('leftInProgress') +
                    'deg)'
                })
              ])
            )
          ]),
          { optional: true }
        )
      ])
    ]),
    trigger('pendingProgressBar', [
      transition('*=>*', [
        query(
          '.progress .progress-right .progress-bar',
          stagger('300ms', [
            animate(
              '1s ease-in',
              keyframes([
                style({ transform: 'rotate(0deg)' }),
                style({
                  transform:
                    'rotate' +
                    '(' +
                    sessionStorage.getItem('rightPending') +
                    'deg)'
                })
              ])
            )
          ]),
          { optional: true }
        ),
        query(
          '.progress.yellow .progress-left .progress-bar',
          stagger('300ms', [
            animate(
              '1s ease-in',
              keyframes([
                style({ transform: 'rotate(0deg)' }),
                style({
                  transform:
                    'rotate' +
                    '(' +
                    sessionStorage.getItem('leftPending') +
                    'deg)'
                })
              ])
            )
          ]),
          { optional: true }
        )
      ])
    ])
  ]
})
export class DashboardComponent implements OnInit, AfterViewInit {

  private sessionObj = JSON.parse(
    sessionStorage.getItem('percentageWithDegrees')
  );

  single = [
    {
      name: 'Germany',
      value: 0
    },
    {
      name: 'USA',
      value: 3
    },
    {
      name: 'France',
      value: 4
    }
  ];

  multi = [
    {
      name: 'Completed',
      series: [
        {
          name: '6-11-2017',
          value: 0
        },
        {
          name: '9-11-2017',
          value: 3
        },
        {
          name: '17-11-2017',
          value: 5
        }
      ]
    },

    {
      name: 'In progress',
      series: [
        {
          name: '6-11-2017',
          value: 3
        },
        {
          name: '9-11-2017',
          value: 5
        },
        {
          name: '17-11-2017',
          value: 7
        }
      ]
    },

    {
      name: 'Pending',
      series: [
        {
          name: '6-11-2017',
          value: 4
        },
        {
          name: '9-11-2017',
          value: 7
        },
        {
          name: '17-11-2017',
          value: 9
        }
      ]
    }
  ];

  view: any[];

  // options
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  sessionLoaded = false;
  showLegend = true;
  showXAxisLabel = true;
  xAxisLabel = 'Dates';
  showYAxisLabel = true;
  yAxisLabel = 'No. of campaigns';

  colorScheme = {
    domain: ['#049dff', '#c849ec', '#fdba04', '#AAAAAA']
  };

  // line, area
  autoScale = true;

  constructor(
    private rd: Renderer2,
    private http: HttpService,
    private campSummary: CampaignSummaryService,
    private location: Location,
    private _event: EventService
  ) { }

  @ViewChild('completeLeftBar') completeLeftBar: ElementRef;
  @ViewChild('completeRightBar') completeRightBar: ElementRef;
  @ViewChild('inProgressLeftBar') inProgressLeftBar: ElementRef;
  @ViewChild('inProgressRightBar') inProgressRightBar: ElementRef;
  @ViewChild('pendingLeftBar') pendingLeftBar: ElementRef;
  @ViewChild('pendingRightBar') pendingRightBar: ElementRef;

  ngOnInit() {

    if (window.innerWidth <= 414) {
      this.view = [175, 150];
    } else if (window.innerWidth <= 992) {
      this.view = [550, 300];
    } else if (window.innerWidth <= 1024) {
      this.view = [550, 300];
    } else if (window.innerWidth <= 1366) {
      this.view = [400, 170];
    } else {
      this.view = [420, 170];
    }

    const checker = localStorage.getItem('on-load');
    if (checker) {
      if (checker === 'true') {
        localStorage.setItem('on-load', 'false');
        window.location.reload();
      } else if (checker === 'false') {
        this.campSummary.getStatus();
        this.sessionObj = JSON.parse(sessionStorage.getItem('percentageWithDegrees'));
      }
    } else {
      localStorage.removeItem('user-data');
      swal({
        title: 'Session Expired!',
        text: 'Please login again.',
        type: 'warning',
        allowOutsideClick: false
      }).then(res => {
        window.location.reload();
      });
    }

  }

  ngAfterViewInit() {

    this._event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'sessionLoaded') {
          this.sessionLoaded = true;
          this._event.broadcast({ eventName: 'loadJQuery', data: '' });
        }
      }
    });

    this._event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'loadJQuery') {
          setTimeout(() => {
            if (window.innerWidth <= 414) {
              $('.nlp').css('padding', '0');
              $('.nlp').css('margin-bottom', '10px');
              $('.nrp').css('padding', '0');
              $('.nrp').css('margin-top', '10px');
            } else if (window.innerWidth <= 992) {
              $('.progressbar-div').css('padding', '0');
              $('.progressbar-div').css('margin-bottom', '5%');
              $('.progressbar-div').toggleClass('col-md-6');
              $('.graph-div').css('padding', '0');
              $('.graph-div').toggleClass('col-md-6');
            } else if (window.innerWidth <= 1024) {
              $('.progressbar-div').css('padding', '0');
              $('.progressbar-div').css('margin-bottom', '5%');
              $('.progressbar-div').toggleClass('col-md-6');
              $('.progressbar-div').toggleClass('col-lg-7');
              $('.graph-div').css('padding', '0');
              $('.graph-div').toggleClass('col-md-6');
              $('.graph-div').toggleClass('col-lg-5');
            }

            $('.legend-title-text').css('display', 'none');
            $('.legend-label-text').css('font-size', '11px');
            $('.legend-label').css('margin-left', '3px');
            $('.legend-label').css('margin-right', '0px');
            $('.legend-label-color').css('height', '10px');
            $('.legend-label-color').css('width', '10px');
            $('.legend-label-color').css('margin-right', '0px');
            $('.y.axis>g>text').css('font-size', '12px');
            $('.x.axis>g>text').css('font-size', '12px');
            $('.tick>text').css('font-size', '11px');
            $('.legend-labels').css('width', '80px');
            $('#tab-selectbyid1').click(function () {
              if (window.innerWidth <= 992) {
                $('.progressbar-div').css('padding', '0');
                $('.progressbar-div').css('margin-bottom', '5%');
                $('.progressbar-div').toggleClass('col-md-6');
                $('.graph-div').css('padding', '0');
                $('.graph-div').toggleClass('col-md-6');
              } else if (window.innerWidth <= 1024) {
                $('.progressbar-div').css('padding', '0');
                $('.progressbar-div').css('margin-bottom', '5%');
                $('.progressbar-div').toggleClass('col-md-6');
                $('.progressbar-div').toggleClass('col-lg-7');
                $('.graph-div').css('padding', '0');
                $('.graph-div').toggleClass('col-md-6');
                $('.graph-div').toggleClass('col-lg-5');
              }
              $('.legend-title-text').css('display', 'none');
              $('.legend-label-text').css('font-size', '11px');
              $('.legend-label').css('margin-left', '3px');
              $('.legend-label').css('margin-right', '0px');
              $('.legend-label-color').css('height', '10px');
              $('.legend-label-color').css('width', '10px');
              $('.legend-label-color').css('margin-right', '0px');
              $('.y.axis>g>text').css('font-size', '12px');
              $('.x.axis>g>text').css('font-size', '12px');
              $('.tick>text').css('font-size', '11px');
              $('.legend-labels').css('width', '80px');
            });
            $('#tab-selectbyid2').click(function () {
              if (window.innerWidth <= 414) {
                $('.nlp').css('padding', '0');
                $('.nlp').css('margin-bottom', '10px');
                $('.nrp').css('padding', '0');
                $('.nrp').css('margin-top', '10px');
              }
            });
          }, 100);
        }
      }
    });



  }

  // animations
  completeAnimationDoneEvent(e) {
    this.completeRightBar.nativeElement.style.transform =
      'rotate' + '(' + sessionStorage.getItem('rightComplete') + 'deg)';
    this.completeLeftBar.nativeElement.style.transform =
      'rotate' + '(' + sessionStorage.getItem('leftComplete') + 'deg)';
  }

  inProgressAnimationDoneEvent(e) {
    this.inProgressRightBar.nativeElement.style.transform =
      'rotate' + '(' + sessionStorage.getItem('rightInProgress') + 'deg)';
    this.inProgressLeftBar.nativeElement.style.transform =
      'rotate' + '(' + sessionStorage.getItem('leftInProgress') + 'deg)';
  }

  pendingAnimationDoneEvent(e) {
    this.pendingRightBar.nativeElement.style.transform =
      'rotate' + '(' + sessionStorage.getItem('rightPending') + 'deg)';
    this.pendingLeftBar.nativeElement.style.transform =
      'rotate' + '(' + sessionStorage.getItem('leftPending') + 'deg)';
  }

}

