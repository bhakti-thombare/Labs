// core imports
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';

// 3rd 
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/map';
import swal from 'sweetalert2';

// app imports
import { HttpService } from '@app/services/http-service';
import { TranslationService } from '@services/translation/translation.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

let supervisor = [];
let fieldAgent = [];
@Component({
  selector: 'app-create-team',
  templateUrl: './create-team.component.html',
  styleUrls: ['./create-team.component.css']
})
export class CreateTeamComponent implements OnInit, AfterViewInit {

  dontShowTheForm = false;
  submitDisable = true;
  fieldAgentNotSelected = true;
  mainSubmitDisable = false;
  supervisor = {
    selectedFieldAgent: '',
    supervisorName: '',
    fieldAgents: [],
    searchData: ''
  };

  users = [];
  supervisors = [];
  fieldAgents = [];

  private myForm;
  formatter = (result: string) => result.toUpperCase();
  searchSupervisor = (text$: Observable<string>) =>
    text$
      .debounceTime(200)
      .distinctUntilChanged()
      .map(
        term =>
          term === ''
            ? []
            : supervisor
              .filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1)
              .slice(0, 10)
      )

  searchFieldAgent = (text$: Observable<string>) =>
    text$
      .debounceTime(200)
      .distinctUntilChanged()
      .map(
        term =>
          term === ''
            ? []
            : fieldAgent
              .filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1)
              .slice(0, 10)
      )

  constructor(
    public router: Router,
    public http: HttpService,
    public location: Location,
    public translateService: TranslationService
  ) { }

  ngOnInit() {
    this.myForm = new FormGroup({
      supervisorSelected: new FormControl('', Validators.required),
      fieldAgentSelected: new FormControl('', Validators.required),
      searchData: new FormControl('', Validators.required)
    });
    this.getUsers();
  }

  ngAfterViewInit() {
    $('.ng2-tag-input__text-input').css('display', 'none');

    if (window.innerWidth <= 414) {
      $('.invite-button').toggleClass('float-right');
      $('.add-button').toggleClass('mr-2');
      $('.add-button').css('margin-right', '0');
      $('.search-input').css('margin-top', '20px');
      $('.search-input').css('margin-bottom', '20px');
      $('.search-input').css('width', '100%');
    }
  }

  getUsers() {
    this.http.SecureGet('/ref/getAllUsers').subscribe(
      res => {
        const loggedInUser = JSON.parse(localStorage.getItem('user-data'));
        supervisor = [];
        fieldAgent = [];
        this.users = res.data.users;
        let len: number = res.data.users.length;
        res.data.users.forEach(user => {
          if (user.roleId === 2 && user.isActive && !user.resetPassword) {
            this.supervisors.push(user);
          } else if (user.roleId === 3 && user.isActive && !user.resetPassword) {
            fieldAgent.push(user.firstName + ' ' + user.lastName);
            this.fieldAgents.push(user);
          }
          len--;
          if (len === 0) {
            this.avoidSupervisorsWithTeams();
          }
        });
      },
      err => {
      }
    );
  }

  avoidSupervisorsWithTeams() {

    this.http.SecureGet('/ref/getAllTeams').subscribe(res => {
      let len: number = res.data.length;
      const avoidNames = [];
      res.data.forEach(team => {
        this.supervisors.forEach(sup => {
          if (team.supervisor.userId === sup.userId) {
            const fullName: string = sup.firstName + ' ' + sup.lastName;
            avoidNames.push(fullName);
          }
        });

        len--;
        if (len === 0) {
          let innerLen = this.supervisors.length;
          this.supervisors.forEach(sup => {
            const fullName = sup.firstName + ' ' + sup.lastName;
            if (avoidNames.indexOf(fullName) === -1) {
              supervisor.push(fullName);
            }
            innerLen--;
            if (innerLen === 0) {
              if (supervisor.length === 0) {
                this.dontShowTheForm = true;
              }
            }
          });

        }
      });

    }, err => {
      this.supervisors.forEach(sup => {
        const fname = sup.firstName + ' ' + sup.lastName;
        supervisor.push(fname);
      });
    });
  }

  addToAgentsArray() {
    if (
      this.supervisor.selectedFieldAgent !== '' &&
      this.supervisor.supervisorName !== ''
    ) {
      if (!this.supervisor.fieldAgents.includes(this.supervisor.selectedFieldAgent) &&
        fieldAgent.includes(this.supervisor.selectedFieldAgent)) {
        this.supervisor.fieldAgents.push(this.supervisor.selectedFieldAgent);
        this.submitDisable = false;
        this.fieldAgentNotSelected = true;
        this.swapMembersInBuckets(this.supervisor.selectedFieldAgent);
      } else {
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_VALID_FIELD_AGENT).subscribe(message => {
          swal(message, '', 'warning');
        });
      }
      this.supervisor.selectedFieldAgent = '';
    } else if (
      this.supervisor.supervisorName === '' &&
      this.supervisor.selectedFieldAgent !== ''
    ) {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_SUPERVISOR).subscribe(message => {
        swal(message, '', 'warning');
      });
    }
  }

  onFieldAgentRemoved(e) {
    if (this.supervisor.fieldAgents.length === 0) {
      this.submitDisable = true;
    }
    this.swapMembersInBuckets(e);
  }

  swapMembersInBuckets(faName) {
    if (fieldAgent.includes(faName)) {
      const i = fieldAgent.indexOf(faName);
      fieldAgent.splice(i, 1);
    } else if (!fieldAgent.includes(faName)) {
      fieldAgent.push(faName);
    }
  }

  submitTeam(form) {
    this.mainSubmitDisable = true;
    const agents = this.supervisor.fieldAgents;
    const faIds = [];
    if (agents.length !== 0 && (this.supervisor.supervisorName !== '' || this.supervisor.supervisorName !== undefined)) {
      let len = this.fieldAgents.length;
      this.fieldAgents.forEach(fa => {
        const fullName = fa.firstName + ' ' + fa.lastName;
        agents.forEach(agent => {
          if (agent === fullName) {
            faIds.push(fa.userId);
          }
        });
        len--;
        if (len === 0) {
          const slen = this.supervisors.length;
          this.supervisors.forEach(sup => {
            const sname = sup.firstName + ' ' + sup.lastName;
            if (sname === this.supervisor.supervisorName) {
              this.http.SecurePost('/team/addTeam', { teamSupervisor: sup.userId, teamMembers: faIds }).subscribe(res => {
                this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.TEAM_CREATED_SUCCESSFULLY).subscribe(message => {
                  swal(message + '!', '', 'success').then(() => {
                    this.location.back();
                  }).catch(() => {
                    this.location.back();
                  });
                });

              }, err => {
              });
            }
          });
        }
      });
    } else {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_SUPERVISOR_AND_FIELD_AGENTS).subscribe(message => {
        swal(message, '', 'warning');
        this.mainSubmitDisable = false;
      });

    }
  }

  supervisorChanged() {
    setTimeout(() => {
      if (!supervisor.includes(this.supervisor.supervisorName)) {
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_VALID_SUPERVISOR).subscribe(message => {
          swal(message, '', 'warning').then(() => {
            this.supervisor.supervisorName = '';
          });
        });

      }
    }, 200);
  }

  reset() {
    this.supervisor.supervisorName = '';
    this.supervisor.selectedFieldAgent = '';
    let len = this.supervisor.fieldAgents.length;
    this.supervisor.fieldAgents.forEach(fa => {
      this.swapMembersInBuckets(fa);
      len--;
      if (len === 0) {
        this.supervisor.fieldAgents = [];
      }
    });
  }

  goBack() {
    this.location.back();
  }

  watchSupervisor(e) {
    if (e === '' || this.supervisor.fieldAgents.length === 0) {
      this.submitDisable = true;
    } else {
      this.submitDisable = false;
    }
  }

  watchFieldAgent(e) {
    if (fieldAgent.includes(e)) {
      this.fieldAgentNotSelected = false;
    } else {
      this.fieldAgentNotSelected = true;
    }

  }

}
