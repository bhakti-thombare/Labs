// core imports
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

// 3rd party
import swal from 'sweetalert2';

// app imports
import { HttpService } from '@app/services/http-service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';


@Component({
  selector: 'app-edit-role',
  templateUrl: './edit-role.component.html',
  styleUrls: ['./edit-role.component.css']
})
export class EditRoleComponent implements OnInit, AfterViewInit {

  myForm: any;
  role: any = {
    name: ''
  };
  disableSubmit = false;
  nameOfRole: any;
  roleId: any;
  allModules: any;
  reqModules: any;
  dropDownModules: any = [];
  selectedModules: any = [];
  selectedModuleArr: any = [];
  tempModules: any = [];
  oneCompleted = false;

  constructor(private http: HttpService, private route: ActivatedRoute, public location: Location, public router: Router) {
    this.route.params.subscribe(params => {
      this.roleId = params.id;
    });
  }

  ngOnInit() {
    this.myForm = new FormGroup({
      'roleName': new FormControl('', Validators.required)
    });

    this.getReady();

  }

  ngAfterViewInit() {
    $('.ng2-tag-input__text-input').css('display', 'none');
    $('.ng2-tag-input').css('border-bottom', '0');

    $('.click2Scroll').click(function () {
      $('.wrap-textarea').scrollTop($('.wrap-textarea')[0].scrollHeight);
    });

    if (window.innerWidth <= 414) {
      $('.submit-button').css('width', '100%');
      $('.add-button').css('width', '100%');
    } else if (window.innerWidth <= 768) {
      $('.submit-button').css('width', '100%');
      $('.add-button').css('width', '100%');
    }

  }

  getReady() {
    this.http.SecureGet('/ref/getAllModules').subscribe(res => {
      this.allModules = res.data;
      sessionStorage.setItem('modules', JSON.stringify(this.allModules));
      this.http
        .SecureGet('/ref/getAllRoles?withModules=true&roleId=' + this.roleId)
        .subscribe(
          resp => {
            this.reqModules = resp.data[0].modules;
            this.nameOfRole = resp.data[0].name;
            this.processModules();
          },
          erro => {
          }
        );
    }, err => {
      console.log(err);
    });
  }

  processModules() {
    let allModLen = this.allModules.length;
    const allModIds = [];
    const reqModIds = [];
    let reqLen: any;
    if (this.reqModules != null) {
      reqLen = this.reqModules.length;
    }
    if (this.reqModules == null) {
      const temp = this.allModules;
      temp.forEach(all => {
        this.dropDownModules.push(all);
      });
      this.role = this.dropDownModules[0];
      this.dropDownModules.splice(0, 1);
    } else if (reqLen === allModLen) {
      this.role.name = 'No more modules.';
      this.allModules.forEach(allMod => {
        this.selectedModuleArr.push(allMod.name);
      });
    } else {
      this.allModules.forEach(allMod => {
        allModIds.push(allMod.id);
        allModLen--;

        if (allModLen === 0) {
          this.reqModules.forEach(reqMod => {
            if (reqModIds.includes(reqMod.Id) === false) {
              reqModIds.push(reqMod.id);
            }
            reqLen--;
            if (reqLen === 0) {
              let allModLen2 = this.allModules.length;
              this.allModules.forEach(allMod2 => {
                if (reqModIds.includes(allMod2.id) === false) {
                  this.dropDownModules.push(allMod2);
                } else {
                  this.selectedModuleArr.push(allMod2.name);
                  this.selectedModules.push(allMod2);
                }
                allModLen2--;
                if (allModLen2 === 0) {
                  this.role = this.dropDownModules[0];
                  this.dropDownModules.splice(0, 1);
                }
              });
            }
          });
        }

      });
    }
  }

  toggleModule(id) {
    this.dropDownModules.forEach(mod => {
      if (mod.id === id) {
        const temp = this.role;
        const index = this.dropDownModules.indexOf(mod);
        if (index > -1) {
          this.role = this.dropDownModules[index];
          this.dropDownModules[index] = temp;
        }
      }
    });
  }

  add2ModulesArray(role) {
    if (this.selectedModuleArr.indexOf(role.name) === -1) {
      if (this.dropDownModules.length === 0) {
        if (this.role.name !== 'No more modules.') {
          this.selectedModuleArr.push(role.name);
          this.role.name = 'No more modules.';
          this.oneCompleted = false;
        }
      } else {
        this.selectedModuleArr.push(role.name);
        this.role = this.dropDownModules[0];
        this.dropDownModules.splice(0, 1);
      }
    } else {
      swal(MESSAGECONSTANTS.ALERT_MESSAGES.ALREADY_INCLUDED_IN_MODULES, '', 'warning');
    }
  }

  onItemRemoved(e) {
    const data = JSON.parse(sessionStorage.getItem('modules'));
    data.forEach(mod => {
      if (mod.name === e) {
        if (this.dropDownModules.length === 0 && this.oneCompleted === false) {
          if (this.role.name === 'No more modules.') {
            this.role = mod;
            this.oneCompleted = true;
          } else {
            this.dropDownModules.push(mod);
          }
        } else {
          this.dropDownModules.push(mod);
        }
      }
    });
  }

  editRole() {
    this.disableSubmit = true;
    const selectedModIds = [];
    const data = JSON.parse(sessionStorage.getItem('modules'));
    let allModLen = data.length;
    if (this.selectedModuleArr.length === 0) {
      swal(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_MODULES_FOR_THE_ROLE,
        MESSAGECONSTANTS.ALERT_MESSAGES.IF_YOU_WANT_TO_DELETE_ROLE_PLEASE_ASK_ADMIN,
        'warning').then(() => {
          this.disableSubmit = false;
        });
    } else {
      data.forEach(allMod => {
        if (this.selectedModuleArr.includes(allMod.name) === true) {
          selectedModIds.push(allMod.id);
        }
        allModLen--;
        if (allModLen === 0) {
          this.http.SecurePost('/role/updateModulesForRole', { roleId: this.roleId, roleModules: selectedModIds }).subscribe(res => {
            swal(MESSAGECONSTANTS.ALERT_MESSAGES.ROLE_UPDATED_SUCCESSFULLY, '', 'success').then(response => {
              this.location.back();
            });
          }, err => {
            this.disableSubmit = false;
          });
        }
      });
    }
  }

  goBack() {
    this.location.back();
  }

}
