// core imports
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

// 3rd party
import 'rxjs/add/operator/map';
import swal from 'sweetalert2';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

// application imports
import { HttpService } from '@app/services/http-service';
import { CampaignSummaryService } from '@services/campaign-summary/campaign-summary.service';
import { TranslationService } from '@services/translation/translation.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

@Component({
  selector: 'app-create-campaign',
  templateUrl: './create-campaign.component.html',
  styleUrls: ['./create-campaign.component.css']
})
export class CreateCampaignComponent implements OnInit, AfterViewInit {
  constructor(
    public location: Location,
    public router: Router,
    public http: HttpService,
    public campServ: CampaignSummaryService,
    public translateService: TranslationService
  ) { }
  disableSubmit = false;
  campaign = {
    campaignEndDate: {
      year: null,
      month: null,
      day: null
    },
    campaignStartDate: {
      year: null,
      month: null,
      day: null
    },
    campaignName: undefined,
    campaignDescription: undefined
  };
  private myForm: FormGroup;

  today = new Date(Date.now());

  minDate = {
    day: this.today.getDate(),
    month: this.today.getMonth() + 1,
    year: this.today.getFullYear()
  };

  minEndDate = {
    day: null,
    month: null,
    year: null
  };

  startDateEntered = false;

  model: NgbDateStruct;

  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6;
  }


  isDisabled(date: NgbDateStruct, current: { month: number }) {

    const currTimestamp = Date.now();
    const now = new Date(currTimestamp);
    const currDate = now.getDate();
    const currMonth = now.getMonth() + 1;
    const currFullYear = now.getFullYear();

    if (date.year === currFullYear) {
      if (date.month === currMonth) {
        if (date.day < currDate) {
          return true;
        }
      } else if (date.month < currMonth) {
        return true;
      }
    } else if (date.year < currFullYear) {
      return true;
    } else if (date.year > currFullYear) {
      return false;
    }

  }

  isEndDisabled(date: NgbDateStruct, current: { month: number }) {
    const localDate = JSON.parse(localStorage.getItem('date'));
    if (date.year === localDate.year) {
      if (date.month === localDate.month) {
        if (date.day < localDate.day) {
          return true;
        }
      } else if (date.month < localDate.month) {
        return true;
      }
    } else if (date.year < localDate.year) {
      return true;
    } else if (date.year > localDate.year) {
      return false;
    }
  }


  ngOnInit() {
    this.myForm = new FormGroup({
      campaignName: new FormControl('', Validators.required),
      campaignDescription: new FormControl('', Validators.required)
    });
  }

  ngAfterViewInit() {
    if (window.innerWidth <= 414) {
      $('.create-button').css('width', '100%');
    }
  }

  goBack() {
    this.location.back();
  }

  createCampaign(form) {
    if (form.valid && this.campaign.campaignStartDate.day != null && this.campaign.campaignEndDate.day != null) {
      this.disableSubmit = true;
      const camp = form.value;
      const user = JSON.parse(localStorage.getItem('user-data'));
      camp.campaignUpdatedBy = user.userId;
      camp.campaignCreatedBy = user.userId;
      camp.campaignUpdatedBy = user.userId;
      camp.campaignStartDate = this.campaign.campaignStartDate.year + '-' +
        this.campaign.campaignStartDate.month + '-' + this.campaign.campaignStartDate.day + ' 00:00:00';
      camp.campaignEndDate = this.campaign.campaignEndDate.year + '-' +
        this.campaign.campaignEndDate.month + '-' + this.campaign.campaignEndDate.day + ' 00:00:00';
      this.http.SecurePost('/campaign/addCampaign', camp).subscribe(
        data => {
          this.campServ.getStatus();
          this.translateService.getLanguageValue(data.responseMessage).subscribe(resMessage => {
            swal(resMessage, '', 'success').then(response => {
              this.location.back();
            });
          });
          this.myForm.reset();
        },
        err => {
          const error = JSON.parse(err._body);
          this.translateService.getLanguageValue(error.responseMessage).subscribe(errMessage => {
            swal(errMessage, '', 'error');
          });
          this.disableSubmit = false;
        }
      );
    } else {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ALL_FIELDS_ARE_MANDATORY).subscribe(res => {
        swal(res + '!', '', 'warning');
      });
    }
  }

  changeLocalDate(date, e) {
    if (!e.target.classList.contains('text-lightgrey')) {
      this.campaign.campaignEndDate = {
        year: null,
        month: null,
        day: null
      };
      localStorage.setItem('date', JSON.stringify(date));
      this.minEndDate = date;
      this.startDateEntered = true;
    }
  }
}
