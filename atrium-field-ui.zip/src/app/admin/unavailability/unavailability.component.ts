import { Component, OnInit, ElementRef, Renderer2, ViewChild } from '@angular/core';
import { ApiService } from '@app/services/apiServices/api.service';
import { EventService } from '@app/services/events/event.service';
import { HttpService } from '@app/services/http-service';
import { Location } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { NgbDateStruct, NgbModal, ModalDismissReasons, NgbModalRef, NgbActiveModal, NgbInputDatepicker, NgbDatepicker, NgbDatepickerConfig } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CreateSurveyUtilsService } from '@app/supervisor/create-survey/createSurveyUtils/create-survey-utils.service';
import { missionTypes, ApiConstants } from '@app/constants/constants';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { Action } from 'rxjs/scheduler/Action';
import { TranslationService } from '@app/services/translation/translation.service';

declare var google: any;
@Component({
  selector: 'app-unavailability',
  templateUrl: './unavailability.component.html',
  styleUrls: ['./unavailability.component.css'],
  providers: [NgbActiveModal]
})
export class UnavailabilityComponent implements OnInit {
  @ViewChild('surveySelectionModal') private surveySelectionModal;


  user = JSON.parse(localStorage.getItem('user-data'));
  modal;
  userID;
  closeResult: string;
  model: NgbDateStruct;
  calendarReady: boolean;
  datepickers = [];
  busyDates = [];
  campaignsLoaded: boolean;
  fullDaySelected: boolean = true;
  campaigns: any;
  missionTypes: any[];
  selectedMissionType: any;
  shifts: any[];
  times: any[];
  selectedShift: any = String;
  selectedTime: any = String;

    mission = {
      selectedCampaign: {
        startDateObj: {},
        endDateObj: {}
      },
      missionStartDate: {
        year: null,
        month: null,
        day: null
      },
      missionEndDate: {
        year: null,
        month: null,
        day: null
      },
      estimatedTimeHour: null,
      estimatedTimeMinutes: null,
     nextDay:[]
    };

  unavailabilityForm:FormGroup;
  modalReference: NgbModalRef;
  today: NgbDateStruct;
  isDisabled: any;
  disabledDates = [];
  getUnavailableDateDate:any;
  AMData = []; 
  PMData = [];  
  selectedShiftChange:any;
  minEndDateDisable:any;
  isStartDate:any;
  isEndDate:any;  
  getFullDayData = [];
  checkDuplicateDate = [];

  @ViewChild('item') shiftView:any;
    
  constructor(
    public api: ApiService,
    public event: EventService,
    public router: Router,
    public _http: HttpService,
    private location: Location,
    public custUtils: CreateSurveyUtilsService,
    public modalService: NgbModal,    
    private translateService: TranslationService,
    public route: ActivatedRoute,
    public activeModal: NgbActiveModal,
    private config: NgbDatepickerConfig) {

    const current = new Date();
    config.minDate = {
      year: current.getFullYear(), month:
        current.getMonth() + 1, day: current.getDate()
    };
    //config.maxDate = { year: 2099, month: 12, day: 31 };
    config.outsideDays = 'hidden';
    
    this.event.broadcast({ eventName: 'showLoader', data: '' });
    this._http.pullCountry().subscribe(res => { }, err => { });
    const date = new Date(Date.now());
    const month = date.getMonth() + 1;
    localStorage.removeItem('busyDates');
    this.changeSurveyModal(this.surveySelectionModal);
    this.shifts = ["Full Day", "Half Day"];
    this.selectedShift = "Full Day";
    this.times = ["AM", "PM", "All Day"];
    this.selectedTime = "AM";
    this.calendarReady = true;

  }
  ngOnInit() {
    let date = new Date();
    this.today = { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() };
    this.route.params.subscribe(params => {
      this.userID = params.id;
      this.getCampaigns(this.userID);
    });
    this.getMissionTypes();
    this.api.getUnavailableDate(this.userID).subscribe(res => {
      let today = this.convert(new Date());
      this.getUnavailableDateDate = res.data;
      // this.disabledDates = res.data.map((d:any)=>{
      //   let date = this.convert(d)
      //   return {
      //     year: Number(date.split('-')[0]), 
      //     month: Number(date.split('-')[1]),
      //     day: Number(date.split('-')[2])
      //   }
      // });      
      this.disabledDates.push({ year: Number(today.split('-')[0]), month: Number(today.split('-')[1]), day: Number(today.split('-')[2]) });

      this.isDisabled  = (date: NgbDate, current: { month: number, year: number }) => {
        return this.disabledDates.find((x:any) => NgbDate.from(x).equals(date)) ? true : false;
      }
     
    });
  }

  convert(str) {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  ChangeSortOrder(newSortOrder: string, day) {
    this.selectedShift = newSortOrder;
    if (this.selectedShift == "Full Day") {
      this.fullDaySelected = true;
    }
    else {
      this.fullDaySelected = false;
    }
    console.log(this.fullDaySelected);
  }

  ChangeShifts(time: string) {
    if (this.fullDaySelected) {
      this.selectedTime = time;
    }
    else {
      this.selectedTime = '';
    }
  }

  getMissionTypes() {
    this.missionTypes = [];    
    this.api.getMissionTypes().subscribe(res => {
      let typeLen = res.data.length;
      res.data.forEach(type => {
        if (type.id === 3 || type.id === 4 || type.id === 2) {
          if (type.id === 3) {
            type.name = 'Pedestrian Flow';
            this.missionTypes.push(type);
          }
          else this.missionTypes.push(type);
        }
        typeLen--;
        if (typeLen === 0) {
          this.selectedMissionType = this.missionTypes[0];
          this.missionTypes.splice(0, 1);
          this.event.broadcast({ eventName: 'hideLoader', data: '' });
          this.changeSurveyModal(this.surveySelectionModal);
        }
      });
    }, err => {
      this.event.broadcast({ eventName: 'hideLoader', data: '' });
    });
  }

  changeSurveyModal(modal) {
    // keyboard: false, backdrop: 'static'
    this.modal = this.modalService.open(modal, { keyboard: false, backdrop: 'static'});
    this.modal.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  gotoClose(d) {
    this.modal.close();
    this.router.navigate([`/admin/users`]);
    //this.location.back();
  }

  createUserForm: FormGroup = new FormGroup({
    missionStartDate: new FormControl('', Validators.required),
    missionEndDate: new FormControl('', Validators.required),
    estimatedTimeHourHour: new FormControl('', Validators.required),
    estimatedTimeHourMin: new FormControl('', Validators.required),
    missionName: new FormControl('', Validators.required),
    missionDescription: new FormControl('')
  });

  minEndDate: any;
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return reason;
    }
  }

  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6;
  }



  // isDisabled(date: NgbDateStruct, current: { month: number }) {
  //   const now = new Date(Date.now());
  //   const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  //   const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
  //   const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
  //   const busyDates = JSON.parse(localStorage.getItem('busyDates'));
  //   const campaignStartDate = new Date(startCheck.year, startCheck.month - 1, startCheck.day);
  //   const campaignEndDate = new Date(endCheck.year, endCheck.month - 1, endCheck.day);
  //   const sdate = new Date(date.year, date.month - 1, date.day);

  //   if (sdate >= campaignStartDate && sdate >= today && sdate <= campaignEndDate) {
  //     if (busyDates !== null) {
  //       let found = -1;
  //       const dateFinder = (dateObj) => {
  //         const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
  //         if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
  //           inDate.getDate() === sdate.getDate()) {
  //           return true;
  //         } else {
  //           return false;
  //         }
  //       };

  //       found = busyDates.findIndex(dateFinder);
  //       if (found !== -1) {
  //         return true;
  //       } else {
  //         return false;
  //       }
  //     } else {
  //       return false;
  //     }
  //   } else {
  //     return true;
  //   }
  // }

  instanceForCampaign(d1) {
    this.datepickers.push(d1);
    console.log('d1');
  }

  changeLocalDate(date) {
    this.mission.missionEndDate = {
      year: null,
      month: null,
      day: null
    };
    localStorage.setItem('date', JSON.stringify(date));
    this.minEndDate = date;
  }

  getDaysArray(start, end) {
    var dArray = [];
    let eday= new Date(end);
    let edd = eday.setDate(eday.getDate() + 1);
    while (start <= eday) {

      // Adding the date to array 
      dArray.push(new Date(start));

      // Increment the date by 1 day 
      let d=new Date(start);
      start = d.setDate(d.getDate()+1);
    }
    return dArray; 

    // for (var arr = [], dt = new Date(start); dt <= end; dt.setDate(dt.getDate() + 1)) {
    //   arr.push(new Date(dt));
    // }
    // return arr;
  };

  getLeaves() {
    var startDate = new Date(this.mission.missionStartDate.year + '-' + this.mission.missionStartDate.month + '-' + this.mission.missionStartDate.day);
    var endDate = new Date(this.mission.missionEndDate.year + '-' + this.mission.missionEndDate.month + '-' + this.mission.missionEndDate.day);
    this.isStartDate = {
      year: startDate.getFullYear(), month:
        startDate.getMonth()+1, day: startDate.getDate()
    };

    this.isEndDate = {
      year: endDate.getFullYear(), month:
        endDate.getMonth()+1, day: endDate.getDate()
    };
   

    let daysCount = this.getDaysArray(startDate, endDate);
    // let iscurrentDay = daysCount.findIndex(n=> this.convert(n) == this.convert(new Date()));
    // if (iscurrentDay != -1){
    //   daysCount.splice(iscurrentDay,1);
    // }

    daysCount.splice(daysCount.length - 1, 1);
    
    if (this.mission.nextDay.length == 0){
      daysCount.forEach(itm => {
        let convertDate = this.convert(itm);
        if (this.disabledDates.length > 0){
          let getIndex = this.disabledDates.findIndex((dt: any) => (String((dt.year + "-" + (dt.month < 10 ? "0" + dt.month : dt.month) + "-" + (dt.day < 10 ? "0" + dt.day : dt.day))) == String(convertDate)));
          if(getIndex == -1){
            this.mission.nextDay.push({ date: itm, shift: '' });            
          }

        } else {
          this.mission.nextDay.push({ date: itm, shift: '' });                    
        }
      });
    } else {
      let allDateArray = [];
      if(this.disabledDates.length > 0){
        this.disabledDates.forEach(dt => {
          let disableDate = dt.year + '-' + dt.month + '-' + (dt.day < 10 ? "0" + dt.day : dt.day); 
          allDateArray.push(disableDate);
        })
      }

      this.mission.nextDay.forEach(itm=>{
        let existDate = this.convert(itm.date);
        allDateArray.push(existDate);         
      });

      daysCount.forEach(res => {
        let compareNewDate = this.convert(res);
        if (allDateArray.indexOf(compareNewDate) == -1) {
          this.mission.nextDay.push({ date: res, shift: '' });
        }       
      });

    }
   
  }

  getRash(h){
    var startDate = new Date(this.mission.missionStartDate.year + '-' + this.mission.missionStartDate.month + '-' + this.mission.missionStartDate.day);
    let nextDay1 = new Date(startDate);
    for(let i=0;i<h;i++){
    nextDay1.setDate(nextDay1.getDate() + i);
    
    console.log('nextDay1',nextDay1);
    this.mission.nextDay.push(new Date(nextDay1));
      // nextDay1.getFullYear() + '-' + nextDay1.getMonth() + '-' + nextDay1.getDate());
    }
    console.log(this.mission);
  }
  private createDateFromNgbDate(ngbDate: NgbDate): Date {
    const date: Date = new Date(Date.UTC(ngbDate.year, ngbDate.month - 1, ngbDate.day));
    return date;
  }

  // isEndDisabled(date: NgbDateStruct, current: { month: number }) {
  //   const localDate = JSON.parse(localStorage.getItem('date'));
  //   const startCheck = JSON.parse(localStorage.getItem('campaignStartDate'));
  //   const endCheck = JSON.parse(localStorage.getItem('campaignEndDate'));
  //   const busyDates = JSON.parse(localStorage.getItem('busyDates'));
  //   const minDate = new Date(localDate.year, localDate.month, localDate.day);
  //   const campaignStartDate = new Date(startCheck.year, startCheck.month, startCheck.day);
  //   const campaignEndDate = new Date(endCheck.year, endCheck.month, endCheck.day);
  //   const sdate = new Date(date.year, date.month, date.day);

  //   if (sdate >= minDate && sdate >= campaignStartDate && sdate <= campaignEndDate) {
  //     if (busyDates !== null) {
  //       let found = -1;
  //       const dateFinder = (dateObj) => {
  //         const inDate = new Date(parseInt(dateObj.year, 10), parseInt(dateObj.month, 10) - 1, parseInt(dateObj.day, 10));
  //         if (inDate.getFullYear() === sdate.getFullYear() && inDate.getMonth() === sdate.getMonth() &&
  //           inDate.getDate() === sdate.getDate()) {
  //           return true;
  //         } else {
  //           return false;
  //         }
  //       };

  //       found = busyDates.findIndex(dateFinder);
  //       if (found !== -1) {
  //         return true;
  //       } else {
  //         return false;
  //       }
  //     } else {
  //       return false;
  //     }
  //   } else {
  //     return true;
  //   }
  // }


  getCampaigns(id) {
    this.campaignsLoaded = false;
    this.api.getUserCampaigns(id).subscribe(res => {
      console.log(res.data.campaigns);
      this.custUtils.campaignsInitializer(res.data.campaigns, response => {
        if (response.message === 'campaignExpired') {
          this.custUtils.translateMessageObject({
            title: 'Campaign expired.',
            text: 'Please contact admin for more campaigns.',
            type: 'warning',
            outsideClick: true,
            showCancelBtn: false,
            confirmBtnText: 'OK',
            cancelBtnText: ''
          }, (responseMessageObject) => {
            this.custUtils.translateAndPop(responseMessageObject).then(() => {
              this.location.back();
            }).catch(() => {
              this.location.back();
            });
          });
        } else if (response.message === 'success') {
          this.campaigns = response.campaigns;
          this.mission.selectedCampaign = this.campaigns[0];
          localStorage.setItem('campaignStartDate', JSON.stringify(this.mission.selectedCampaign.startDateObj));
          localStorage.setItem('campaignEndDate', JSON.stringify(this.mission.selectedCampaign.endDateObj));
          this.campaigns.splice(0, 1);
          this.campaignsLoaded = true;
        }
      });
    }, err => { });
  }

  Save(){
    this.mission.nextDay = [];
    this.getLeaves();

    let obj= {
        "agentId" : this.userID,
        "unavailablility" : [],
        "createdBy": localStorage.getItem('userId'),
        "updatedBy": localStorage.getItem('userId')
    };

    let obj1 = {
      "agentId": this.userID,
      "unavailablility": [],
      "createdBy": localStorage.getItem('userId'),
      "updatedBy": localStorage.getItem('userId')
    };
    // for (let item in this.mission.nextDay){
    //   obj.unavailablility.push({ date: this.convert(this.mission.nextDay[item].date), shift: this.mission.nextDay[item].shift })
    // }

    for (let item in this.mission.nextDay) {
      if (this.selectedShiftChange == 'fd'){
        obj.unavailablility.push({ date: this.convert(this.mission.nextDay[item].date), shift: 'AM' });
        obj1.unavailablility.push({ date: this.convert(this.mission.nextDay[item].date), shift: 'PM' });
      }else{
        obj.unavailablility.push({ date: this.convert(this.mission.nextDay[item].date), shift: this.selectedShiftChange});
      }
    }

    if (this.selectedShiftChange == 'fd'){
      this.api.postUnavailableUser(obj).subscribe(res => {
        this.api.postUnavailableUser(obj1).subscribe(res => {
          this.modal.close();
          this.location.back();
        });        
      });
    } else{
      this.api.postUnavailableUser(obj).subscribe(res => {
        this.modal.close();
        this.location.back();
      });
    }
  }

  removeSelectedDate(item, index){
    this.mission.nextDay.splice(index,1);
  }

  changeAmPm(day, value){
    day.shift = value;
  }

  changeShift(day, value){
    if (value == "Full Day"){
      day.shift = 'fd';            
    }else{
      day.shift =  null;
    }
  }
  disableShift(day){
    if (day.shift == '' || day.shift == "fd"){
      return true;
    }else{
      return false;
    }
  }

  disableSave(){
    if (this.mission.nextDay.length == 0 || this.selectedShiftChange==null){
      return true;
    }
    return false;
    //return !(this.mission.nextDay.every(res => res.shift != "" && res.shift != null));
  }

  isToday(date: NgbDateStruct) {
    if (!this.today)
      return false;
    return date.year == this.today.year &&
      date.month == this.today.month &&
      date.day == this.today.day
  }

  disableDateOnShiftChange(value){
    this.disabledDates = [];
    let today = this.convert(new Date());    
    if (value == 'AM'){
      this.selectedShiftChange = value;
      if (this.AMData.length == 0){
        this.AMData = this.getUnavailableDateDate.filter(res=>res.shift == 1);
      }
      this.disabledDates = this.AMData.map((d:any)=>{
        let date = this.convert(d.date)
        return {
          year: Number(date.split('-')[0]), 
          month: Number(date.split('-')[1]),
          day: Number(date.split('-')[2])
        }
      });
      this.disabledDates.push({ year: Number(today.split('-')[0]), month: Number(today.split('-')[1]), day: Number(today.split('-')[2]) });
    } else if (value == 'PM'){
      this.selectedShiftChange = value;
      if (this.PMData.length == 0){
        this.PMData = this.getUnavailableDateDate.filter(res => res.shift == 2);
      }
      this.disabledDates = this.PMData.map((d: any) => {
        let date = this.convert(d.date)
        return {
          year: Number(date.split('-')[0]),
          month: Number(date.split('-')[1]),
          day: Number(date.split('-')[2])
        }
      });
      this.disabledDates.push({ year: Number(today.split('-')[0]), month: Number(today.split('-')[1]), day: Number(today.split('-')[2]) });
    } else {
      this.selectedShiftChange = 'fd';
      if (this.checkDuplicateDate.length == 0){
        this.getFullDayData = [];                
        this.getUnavailableDateDate.forEach(d=>{
          if (this.checkDuplicateDate.indexOf(d.date) == -1){
            this.checkDuplicateDate.push(d.date);
          }else{
            this.getFullDayData.push(d.date);
          }
        });
      }
      
      this.disabledDates = this.checkDuplicateDate.map((d: any) => {
        let date = this.convert(d);
        return {
          year: Number(date.split('-')[0]),
          month: Number(date.split('-')[1]),
          day: Number(date.split('-')[2])
        }
      });
      this.disabledDates.push({ year: Number(today.split('-')[0]), month: Number(today.split('-')[1]), day: Number(today.split('-')[2]) });
    }
  }

  selectStartDate(dt){
    var startDate = new Date(this.mission.missionStartDate.year + '-' + this.mission.missionStartDate.month + '-' + this.mission.missionStartDate.day);
    this.isStartDate = {
      year: startDate.getFullYear(), month:
        startDate.getMonth()+1, day: startDate.getDate()
    };

    this.minEndDateDisable = {
      year: dt.year,
      month: dt.month,
      day: dt.day
    };
  }

  ngOnDestroy() {
    this.modal.close();
    $(document.body).removeClass("modal-open modal");
    $(".modal-backdrop").remove();
    $('ngb-modal-window').remove();
  }

  // startClickEvent(d1, d2){
  //   d1.toggle();
  //   this.d2.close();
  // }
  // endClickEvent(d2, d1){
  //   //d2.toggle(); d1.close();
  //   d2.toggle();
  //   this.d1.close();
  // }
}
