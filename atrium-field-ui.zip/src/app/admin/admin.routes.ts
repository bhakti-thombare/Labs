import { Routes } from '@angular/router';
import { DashboardComponent } from '@app/admin/dashboard/dashboard.component';
import { UsersComponent } from '@app/admin/users/users.component';
import { CampaignComponent } from '@app/admin/campaign/campaign.component';
import { AssignCampaignComponent } from '@app/admin/assign-campaign/assign-campaign.component';
import { CreateCampaignComponent } from '@app/admin/create-campaign/create-campaign.component';
import { AddUserComponent } from '@app/admin/add-user/add-user.component';
import { InvitePeopleComponent } from '@app/admin/invite-people/invite-people.component';
import { EditCampaignComponent } from '@app/admin/edit-campaign/edit-campaign.component';
import { EditUserComponent } from '@app/admin/edit-user/edit-user.component';
import { ProfileComponent } from '@app/admin/profile/profile.component';
import { ActivitiesComponent } from '@app/admin/activities/activities.component';
import { RoleComponent } from '@app/admin/role/role.component';
import { ReportsComponent } from '@app/admin/reports/reports.component';
import { CreateRoleComponent } from '@app/admin/create-role/create-role.component';
import { EditRoleComponent } from '@app/admin/edit-role/edit-role.component';
import { TeamManagementComponent } from '@app/admin/team-management/team-management.component';
import { FormGuardService } from '@services/form-guard/form-guard.service';
import { CreateTeamComponent } from '@app/admin/create-team/create-team.component';
import { EditTeamComponent } from '@app/admin/edit-team/edit-team.component';
import { UnavailabilityComponent } from './unavailability/unavailability.component';
import { AdminComponent } from './admin.component';
import { AuthGaurdService } from '@app/services/auth-guard/auth-gaurd.service';
 
export const AdminRoutes: Routes = [
    {
        path: '',
        component: AdminComponent,
        canActivate: [AuthGaurdService],
        children: [
            {
                path: '',
                redirectTo: 'dashboard',
                component: DashboardComponent
            },
            {
                path: 'dashboard',
                component: DashboardComponent
            },
            {
                path: 'users',
                component: UsersComponent
            },
            {
                path: 'activities',
                component: ActivitiesComponent
            },
            {
                path: 'roles',
                component: RoleComponent
            },
            {
                path: 'roles/create',
                component: CreateRoleComponent
            },
            {
                path: 'roles/edit/:id',
                component: EditRoleComponent
            },
            {
                path: 'reports',
                component: ReportsComponent
            },
            {
                path: 'profile',
                component: ProfileComponent,
                canDeactivate: [FormGuardService]
            },
            {
                path: 'users/addUser',
                component: AddUserComponent
            },
            {
                path: 'users/editUser/:id',
                component: EditUserComponent
            },
            {
                path: 'users/unavailability/:id',
                component: UnavailabilityComponent
            },
            {
                path: 'users/invite',
                component: InvitePeopleComponent
            },
            {
                path: 'campaign',
                component: CampaignComponent
            },
            {
                path: 'campaign/assign',
                component: AssignCampaignComponent
            },
            {
                path: 'campaign/edit/:id',
                component: EditCampaignComponent
            },
            {
                path: 'campaign/create',
                component: CreateCampaignComponent
            },
            {
                path: 'teams',
                component: TeamManagementComponent
            },
            {
                path: 'teams/create',
                component: CreateTeamComponent
            },
            {
                path: 'teams/edit/:id',
                component: EditTeamComponent
            }
        ]
    },
    


    /* Redirect to paths */
    /* {
        path: '',
        redirectTo: 'admin/dashboard',
        pathMatch: 'full'
    }, {
        path: 'admin',
        redirectTo: 'admin/dashboard',
        pathMatch: 'full'
    }, {
        path: 'dashboard',
        redirectTo: 'admin/dashboard',
        pathMatch: 'full'
    }, {
        path: 'users',
        redirectTo: 'admin/users',
        pathMatch: 'full'
    }, {
        path: 'campaign',
        redirectTo: 'admin/campaign',
        pathMatch: 'full'
    }, {
        path: 'campaign/assign',
        redirectTo: 'admin/campaign/assign',
        pathMatch: 'full'
    }, {
        path: 'campaign/edit/:id',
        redirectTo: 'admin/campaign/edit/:id',
        pathMatch: 'full'
    }, {
        path: 'campaign/create',
        redirectTo: 'admin/campaign/create',
        pathMatch: 'full'
    }, {
        path: 'users/addUser',
        redirectTo: 'admin/users/addUser',
        pathMatch: 'full'
    }, {
        path: 'users/invite',
        redirectTo: 'admin/users/invite',
        pathMatch: 'full'
    }, {
        path: 'users/editUser/:id',
        redirectTo: 'admin/users/editUser/:id',
        pathMatch: 'full'
    },{
        path: 'users/unavailability/:id',
        redirectTo: 'admin/users/unavailability/:id',
        pathMatch: 'full'
    },
     {
        path: 'profile',
        redirectTo: 'admin/profile',
        pathMatch: 'full'
    },
    {
        path: 'activities',
        redirectTo: 'admin/activities',
        pathMatch: 'full'
    },
    {
        path: 'roles',
        redirectTo: 'admin/roles',
        pathMatch: 'full'
    },
    {
        path: 'roles/create',
        redirectTo: 'admin/roles/create',
        pathMatch: 'full'
    },
    {
        path: 'roles/edit/:id',
        redirectTo: 'admin/roles/edit/:id',
        pathMatch: 'full'
    },
    {
        path: 'reports',
        redirectTo: 'admin/reports',
        pathMatch: 'full'
    },
    {
        path: 'teams',
        redirectTo: 'admin/teams',
        pathMatch: 'full'
    },
    {
        path: 'teams/create',
        redirectTo: 'admin/teams/create',
        pathMatch: 'full'
    },
    {
        path: 'teams/edit/:id',
        redirectTo: 'admin/teams/edit/:id',
        pathMatch: 'full'
    }, */
    /* Component Paths */

    /* {
        path: 'dashboard',
        component: DashboardComponent
    },
    {
        path: 'users',
        component: UsersComponent
    },
    {
        path: 'activities',
        component: ActivitiesComponent
    },
    {
        path: 'roles',
        component: RoleComponent
    },
    {
        path: 'roles/create',
        component: CreateRoleComponent
    },
    {
        path: 'roles/edit/:id',
        component: EditRoleComponent
    },
    {
        path: 'reports',
        component: ReportsComponent
    },
    {
        path: 'profile',
        component: ProfileComponent,
        canDeactivate: [FormGuardService]
    },
    {
        path: 'users/addUser',
        component: AddUserComponent
    },
    {
        path: 'users/editUser/:id',
        component: EditUserComponent
    },
    {
        path: 'users/unavailability/:id',
        component: UnavailabilityComponent
    },
    {
        path: 'users/invite',
        component: InvitePeopleComponent
    },
    {
        path: 'campaign',
        component: CampaignComponent
    },
    {
        path: 'campaign/assign',
        component: AssignCampaignComponent
    },
    {
        path: 'campaign/edit/:id',
        component: EditCampaignComponent
    },
    {
        path: 'campaign/create',
        component: CreateCampaignComponent
    },
    {
        path: 'teams',
        component: TeamManagementComponent
    },
    {
        path: 'teams/create',
        component: CreateTeamComponent
    },
    {
        path: 'teams/edit/:id',
        component: EditTeamComponent
    } */
];