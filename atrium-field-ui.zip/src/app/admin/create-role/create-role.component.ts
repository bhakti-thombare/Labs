// core imports
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';

// 3rd party
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import swal from 'sweetalert2';

// app imports
import { HttpService } from '@app/services/http-service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

@Component({
  selector: 'app-create-role',
  templateUrl: './create-role.component.html',
  styleUrls: ['./create-role.component.css']
})

export class CreateRoleComponent implements OnInit, AfterViewInit {

  constructor(private http: HttpService, private location: Location) { }

  private disableSubmit = false;
  private myForm;
  private selectedModule = [];
  private rolename;
  private oneCompleted = false;
  private modules = [];
  private tempModules = [];
  private role = {
    id: '',
    name: '',
    description: ''
  };
  private selectedModulesId = [];

  ngOnInit() {
    this.myForm = new FormGroup({
      'roleName': new FormControl('', Validators.required)
    });
    this.getModules();
  }

  ngAfterViewInit() {
    $('.ng2-tag-input__text-input').css('display', 'none');
    $('.ng2-tag-input').css('border-bottom', '0');

    $('.click2Scroll').click(function () {
      $('.wrap-textarea').scrollTop($('.wrap-textarea')[0].scrollHeight);
    });
  }

  getModules() {
    this.http.SecureGet('/ref/getAllModules').subscribe(res => {
      this.modules = res.data;
      this.modules.forEach(mod => {
        this.tempModules.push(mod);
      });
      sessionStorage.setItem('modules', JSON.stringify(res.data));
      this.role = this.modules[0];
      this.modules.splice(0, 1);
    }, err => {
    });
  }

  addModule(id) {
    this.modules.forEach(mod => {
      if (mod.id === id) {
        const temp = this.role;
        const index = this.modules.indexOf(mod);
        if (index > -1) {
          this.role = this.modules[index];
          this.modules[index] = temp;
        }
      }
    });
  }

  createRole(form, e) {
    if ((form.value.nameOfRole !== '' && form.value.nameOfRole != null &&
      form.value.nameOfRole !== undefined) && form.value.moduleSelected.length !== 0) {
      this.disableSubmit = true;
      this.http.SecurePost('/role/addRole', { roleName: form.value.nameOfRole }).subscribe(res => {
        const arr = res.responseMessage.split('Role Created! Id: ');
        let len = this.tempModules.length;
        this.tempModules.forEach(mod => {
          if (this.selectedModule.indexOf(mod.name) !== -1) {
            this.selectedModulesId.push(mod.id);
          }
          len--;
          if (len === 0) {
            this.http.SecurePost('/role/updateModulesForRole', { roleId: parseInt(arr[1], 10), roleModules: this.selectedModulesId })
              .subscribe(response => {
                swal(MESSAGECONSTANTS.ALERT_MESSAGES.ROLE_CREATED_SUCCESSFULLY, '', 'success').then(data => {
                  this.location.back();
                });
              }, err => {
                swal('Error', MESSAGECONSTANTS.ALERT_MESSAGES.SOMETHING_WENT_WRONG, 'error');
              });
          }
        });
      }, err => {
        swal('Error', MESSAGECONSTANTS.ALERT_MESSAGES.SOMETHING_WENT_WRONG, 'error');
      });
    } else if ((form.value.nameOfRole === '' || form.value.nameOfRole == null || form.value.nameOfRole === undefined)) {
      swal(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ADD_ROLE_NAME, MESSAGECONSTANTS.ALERT_MESSAGES.ROLE_NAME_REQUIRED, 'warning');
    } else if (form.value.moduleSelected.length === 0) {
      swal(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ADD_MODULES_TO_THE_ROLE, MESSAGECONSTANTS.ALERT_MESSAGES.NO_MODULES_ADDED_FOR_THIS_ROLE, 'warning');
    }
  }

  add2ModulesArray(role) {
    if (this.selectedModule.indexOf(role.name) === -1) {
      if (this.modules.length === 0) {
        if (this.role.name !== 'No more modules.') {
          this.selectedModule.push(role.name);
          this.role.name = 'No more modules.';
          this.oneCompleted = false;
        }
      } else {
        this.selectedModule.push(role.name);
        this.role = this.modules[0];
        this.modules.splice(0, 1);
      }
    } else {
      swal(MESSAGECONSTANTS.ALERT_MESSAGES.ALREADY_INCLUDED_IN_MODULES, '', 'warning');
    }
  }

  onItemRemoved(e) {
    const data = JSON.parse(sessionStorage.getItem('modules'));
    data.forEach(mod => {
      if (mod.name === e) {
        if (this.modules.length === 0 && this.oneCompleted === false) {
          if (this.role.name === 'No more modules.') {
            this.role = mod;
            this.oneCompleted = true;
          }
        } else {
          this.modules.push(mod);
        }
      }
    });
  }

  goBack() {
    this.location.back();
  }

}
