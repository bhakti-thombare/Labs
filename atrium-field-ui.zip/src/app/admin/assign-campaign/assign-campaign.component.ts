// core imports
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { AfterViewInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { FormControl, FormGroup, Validators } from '@angular/forms';

// 3rd party imports
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import swal from 'sweetalert2';

// app imports
import { HttpService } from '@app/services/http-service';
import { CampaignSummaryService } from '@services/campaign-summary/campaign-summary.service';
import { TranslationService } from '@services/translation/translation.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

let people = [];

@Component({
  selector: 'app-assign-campaign',
  templateUrl: './assign-campaign.component.html',
  styleUrls: ['./assign-campaign.component.css']
})
export class AssignCampaignComponent implements OnInit, AfterViewInit {
  public model: any;
  public noSupervisors: boolean;
  public noCampaigns: boolean;
  private myForm: FormGroup;
  private campaign = {
    assignedUser: ''
  };
  private campaigns;
  private users = [];
  public query = '';
  public filteredList = [];
  public elementRef;
  public campName;
  private loggedInUser;
  disableSubmitButton = false;

  formatter = (result: string) => result.toUpperCase();

  search = (text$: Observable<string>) =>
    text$
      .debounceTime(200)
      .distinctUntilChanged()
      .map(
        term =>
          term === ''
            ? []
            : people
              .filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1)
              .slice(0, 10)
      )

  constructor(
    public location: Location,
    public http: HttpService,
    public campServ: CampaignSummaryService,
    public translateService: TranslationService
  ) { }

  ngOnInit() {
    this.myForm = new FormGroup({
      userAssigned: new FormControl('', Validators.required),
      campaignName: new FormControl('', Validators.required)
    });
    this.loggedInUser = JSON.parse(localStorage.getItem('user-data'));
    this.campName = -1;
    this.getCampaigns();
    this.getUsers();
  }

  ngAfterViewInit() {
    if (window.innerWidth <= 414) {
      $('.assign-button').css('width', '100%');
      $('.mb-xs-3').css('margin-bottom', '1rem');
    }
  }

  getCampaigns() {
    this.http.SecureGet('/ref/getAllCampaigns').subscribe(
      res => {
        this.campaigns = [];
        let len = res.data.campaigns.legth;
        res.data.campaigns.forEach(campaign => {
          if (campaign.campaignStatus.statusId === 3 && !campaign.campaignIsArchived) {
            this.campaigns.push(campaign);
          }
          len--;
          if (len === 0) {
            if (this.campaigns.length === 0) {
              this.noCampaigns = true;
            } else {
              this.noCampaigns = false;
            }
          }
        });
      },
      err => {
      }
    );
  }

  getUsers() {
    people = [];
    this.http.SecureGet('/ref/getAllUsers').subscribe(
      res => {
        console.log(res.data);
        let len = res.data.users.length;
        res.data.users.forEach(user => {
          if (user.roleId === 2 && user.isActive && !user.resetPassword) {
            people.push(user.firstName + ' ' + user.lastName);
            this.users.push({
              name: user.firstName + ' ' + user.lastName,
              id: user.userId
            });
          }
          len--;
          if (len === 0) {
            if (this.users.length === 0) {
              this.noSupervisors = true;
            } else {
              this.noSupervisors = false;
            }
          }
        });
      },
      err => { }
    );
  }
  goBack() {
    this.location.back();
  }

  assignMember(form, e) {
    e.preventDefault();
    if (form.valid && this.campName !== -1) {
      this.disableSubmitButton = true;
      let len = this.users.length;
      let userFound = false;
      this.users.forEach(user => {
        if (user.name === form.value.assignedUser) {
          userFound = true;
          const reqObj = {
            campaignId: form.value.campName,
            campaignAssignedTo: user.id,
            campaignUpdatedBy: this.loggedInUser.userId,
            campaignStatus: 4
          };
          this.http.SecurePost('/campaign/updateCampaign', reqObj).subscribe(
            data => {
              this.campServ.getStatus();
              this.translateService.getLanguageValue(data.responseMessage).subscribe(resMessage => {
                swal(resMessage, '', 'success').then(response => {
                  this.location.back();
                }).catch(() => {
                  this.location.back();
                });
              });
            },
            err => {
            }
          );
        }
        len--;
        if (len === 0) {
          if (!userFound) {
            this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_VALID_USER).subscribe(trResTitle => {
              this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.THE_USER_SHOULD_BE_A_SUPERVISOR).subscribe(trResText => {
                swal(
                  trResTitle,
                  trResText,
                  'warning'
                ).then(() => {
                  this.disableSubmitButton = false;
                  this.campaign.assignedUser = '';
                }).catch(() => {
                  this.disableSubmitButton = false;
                  this.campaign.assignedUser = '';
                });
              });
            });
          }
        }
      });
    } else {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ALL_FIELDS_ARE_MANDATORY).subscribe(res => {
        swal(res, '', 'warning');
        this.disableSubmitButton = false;
      });
    }
  }
  selectCampaign(event) {
  }
}
