// core imports
import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Location } from '@angular/common';

// 3rdf party imports
import swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';

// app imports
import { InitialsService } from '@services/initials/initials.service';
import { CampaignSummaryService } from '@services/campaign-summary/campaign-summary.service';
import { EventService } from '@services/events/event.service';
import { HttpService } from '@app/services/http-service';
import { TranslationService } from '@services/translation/translation.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  smallSideBar: boolean; // toggle sidebar with a small sidebar
  initials; // Profile user name initials in the profile dropdown
  showSideBar = false; // Hide the sidebar if only profile page is opened in case of resetpassword or resetprofile is true
  user; // User from localstorage
  sessionObj; // sessionObj for dashboard
  dontShowTopSide = false; // Hide the topside if only profile page is opened in case of resetpassword or resetprofile is true
  currentState: any;
  showExtraMenuItems = false; // responsive menu items shown if screen size detected is smaller than usual
  pushRightClass = 'show-menu-modal'; // adjusts the body of the main container as per the size of the sidebar
  constructor(public router: Router,
    public initialsSevice: InitialsService,
    public location: Location,
    private translate: TranslateService,
    public campData: CampaignSummaryService,
    public event: EventService,
    public http: HttpService,
    public translateService: TranslationService) {

    this.router.events.subscribe(val => {
      if (val instanceof NavigationEnd && window.innerWidth <= 992) {
        this.showExtraMenuItems = true;
      } else if (val instanceof NavigationEnd && window.innerWidth >= 992) {
        this.showExtraMenuItems = false;
      }
    });
  }
  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user-data'));
    this.user.preferredLanguage ? this.changeLanguage() : this.translate.setDefaultLang('en');
    this.sessionObj = JSON.parse(sessionStorage.getItem('percentageWithDegrees'));
    if (!localStorage.getItem('user-data')) {
      this.router.navigate(['login']);
    } else {
      if (!this.sessionObj) {
        this.event.broadcast({ eventName: 'showLoader', data: '' });
        localStorage.setItem('reloader', 'true');
      }
    }
    if (this.user.resetProfile && this.user.isActive) {
      this.dontShowTopSide = true;
    }
    $('.nav-sidebar a').on('click', function () {
      $('.nav-sidebar')
        .find('.active')
        .removeClass('active');
      $(this)
        .parent()
        .addClass('active');
    });
    this.smallSideBar = false;
    if (this.user.firstName !== undefined && this.user.lastName !== undefined) {
      this.initials = this.initialsSevice.fetch(
        this.user.firstName,
        this.user.lastName
      );
    }
  }

  /* 
    changeLanguage:- 
    1. Changes the language as per the preferred language of logged in user
  */

  changeLanguage() {
    if (this.user.preferredLanguage === 3) {
      this.translate.setDefaultLang('en');
    } else if (this.user.preferredLanguage === 2) {
      this.translate.setDefaultLang('nl');
    } else {
      this.translate.setDefaultLang('fr');
    }
  }

  /* 
    toggleSidebar:-
    1. sidebar toggler
  */
  toggleSidebar() {
    const dom: any = document.querySelector('.toggler-icon');
    const mainCont: any = document.querySelector('.main-container');
    const sidebar: any = document.querySelector('.mini-sidebar');
    this.smallSideBar = true;
    mainCont.classList.toggle('ml-60');
    sidebar.classList.toggle('sidebar-toggler');
    dom.classList.toggle('change');
  }

  isToggled(): boolean {
    const dom: Element = document.querySelector('body');
    return dom.classList.contains(this.pushRightClass);
  }

  toggleIconsBar() {
    if (this.smallSideBar) {
      this.smallSideBar = false;
    } else {
      this.smallSideBar = true;
    }
  }

  /* 
    onLoggedout:-
    1. Log out functionality
  */

  onLoggedout() {
    if (this.router.url === '/admin/profile') {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ARE_U_SURE_U_WANT_TO_LOGOUT).subscribe(resTitle => {
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.YES_LOGOUT).subscribe(resBtnMsg => {
          this.translateService.getLanguageValue('Cancel').subscribe(cancelBtnMsg => {
            swal({
              title: resTitle,
              text: '',
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              cancelButtonText: cancelBtnMsg,
              confirmButtonText: resBtnMsg + '!'
            }).then(
              success => {
                this.http.SecureGet('/user/logout').subscribe(res => {
                  this.translate.setDefaultLang('en');
                  localStorage.clear();
                  sessionStorage.clear();
                  window.location.reload();
                }, err => {
                  this.translate.setDefaultLang('en');
                  localStorage.clear();
                  sessionStorage.clear();
                  window.location.reload();
                });
              }
            ).catch(() => {
              console.log('Session still active');
            });
          });
        });
      });
    } else {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ARE_U_SURE_U_WANT_TO_LOGOUT).subscribe(resTitle => {
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.YES_LOGOUT).subscribe(resBtnMsg => {
          this.translateService.getLanguageValue('Cancel').subscribe(cancelBtnMsg => {
            swal({
              title: resTitle,
              text: '',
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              cancelButtonText: cancelBtnMsg,
              confirmButtonText: resBtnMsg + '!'
            }).then(
              success => {
                this.http.SecureGet('/user/logout').subscribe(res => {
                  this.translate.setDefaultLang('en');
                  localStorage.clear();
                  sessionStorage.clear();
                  this.router.navigate(['/login']);
                }, err => {
                  this.translate.setDefaultLang('en');
                  localStorage.clear();
                  sessionStorage.clear();
                  this.router.navigate(['/login']);
                });
              }
            ).catch(() => {
              console.log('Session still active');
            });
          });
        });
      });
    }
  }
}
