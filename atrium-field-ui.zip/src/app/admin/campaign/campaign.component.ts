// core imports
import {
  Component,
  OnInit,
  ElementRef,
  Renderer2,
  AfterViewInit,
  ViewChild
} from '@angular/core';
import { Router } from '@angular/router';

// 3rd party imports
import 'rxjs/add/operator/map';
import swal from 'sweetalert2';

// app imports
import { HttpService } from '@app/services/http-service';
import { EventService } from '@services/events/event.service';
import { TranslationService } from '@services/translation/translation.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

@Component({
  selector: 'app-campaign',
  templateUrl: './campaign.component.html',
  styleUrls: ['./campaign.component.css']
})
export class CampaignComponent implements OnInit, AfterViewInit {
  private showNullMessage = false;
  private user = JSON.parse(localStorage.getItem('user-data'));
  private filters = {
    archive: true,
    done: true,
    inProgress: true,
    pending: true,
    yetToAssign: true,
    overdue: true
  };
  private createMessage = '';
  private assignMessage = '';
  public bk_campaigns = [];
  public campaigns = [];
  constructor(
    public router: Router,
    public http: HttpService,
    private rd: Renderer2,
    private _event: EventService,
    private translateService: TranslationService
  ) { }
  imageUrl: any;
  parent2Toggle: any;
  @ViewChild('dropDown') dropDown: ElementRef;

  ngAfterViewInit() {
    this.parent2Toggle = this.dropDown.nativeElement;
    this.rd.listen(this.dropDown.nativeElement, 'click', () => {
      if (this.parent2Toggle.parentNode.classList[1] === 'show') {
        this.classRemover();
      } else {
        this.classAdder();
      }
    });

    if (window.innerWidth <= 414) {
      $('.container').css('padding', '0');
      $('.option-buttons.col-4').css('padding', '0');
      $('.option-buttons.col-4').css('margin', '0');
    } else if (window.innerWidth === 1024) {
    }

    $('.card-block').scroll(function () {
      const $openDD = $('.dropdown-options').find('[aria-expanded=true]');
      $openDD.attr('aria-expanded', 'false');
      $('.dropdown-options').removeClass('show');
    });

    this._event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'campaign-dd-clicked') {
          $('.dropdown-options').click(function () {
            const $btndropdown = $(this).find('.dropdown-toggle');
            const $listholder = $(this).find('.dropdown-menu');
            let $marginTop = 0;
            if (window.innerWidth <= 414) {
              $marginTop = 340;
            } else {
              $marginTop = 249;
            }
            $(this).css('position', 'static');
            $listholder.css({
              top:
                $btndropdown.offset().top +
                $btndropdown.outerHeight(true) -
                $marginTop +
                'px',
              left: 'auto'
            });
          });
        }
      }
    });
  }

  classRemover() {
    this.imageUrl = 'assets/icons/Filter-normal_Icon.png';
    this.rd.removeClass(this.parent2Toggle.parentNode, 'show');
  }

  classAdder() {
    this.imageUrl = 'assets/icons/Filter-selected_Icon.png';
    this.rd.addClass(this.parent2Toggle.parentNode, 'show');
  }
  ngOnInit() {
    this.getCampaigns();
    this.imageUrl = 'assets/icons/Filter-normal_Icon.png';
    if (window.innerWidth <= 414) {
      this.createMessage = 'CREATE';
      this.assignMessage = 'ASSIGN';
    } else if (window.innerWidth === 1024) {
      this.createMessage = 'CREATE';
      this.assignMessage = 'ASSIGN';
    } else {
      this.createMessage = 'CREATE CAMPAIGN';
      this.assignMessage = 'ASSIGN CAMPAIGN';
    }
  }

  cancel() {
    this.classRemover();
    this.campaigns = this.bk_campaigns;
    if (this.campaigns.length !== 0) {
      this.showNullMessage = false;
    }
    this.filters = {
      archive: true,
      done: true,
      inProgress: true,
      pending: true,
      yetToAssign: true,
      overdue: true
    };
  }

  applyFilter() {
    this.classRemover();
    this.campaigns = [];
    let campLen = this.bk_campaigns.length;
    this.bk_campaigns.forEach(camp => {
      if (this.filters.archive) {
        if (
          (camp.campaignStatus.statusId === 1 && this.filters.done) ||
          (camp.campaignStatus.statusId === 2 && this.filters.inProgress) ||
          (camp.campaignStatus.statusId === 4 && this.filters.pending) ||
          (camp.campaignStatus.statusId === 3 && this.filters.yetToAssign) ||
          (camp.campaignStatus.statusId === 9 && this.filters.overdue)
        ) {
          this.campaigns.push(camp);
        } else if (
          (camp.campaignStatus.statusId === 1 && camp.campaignIsArchived) ||
          (camp.campaignStatus.statusId === 2 && camp.campaignIsArchived) ||
          (camp.campaignStatus.statusId === 4 && camp.campaignIsArchived) ||
          (camp.campaignStatus.statusId === 3 && camp.campaignIsArchived) ||
          (camp.campaignStatus.statusId === 9 && camp.campaignIsArchived)
        ) {
          this.campaigns.push(camp);
        } else if (
          !this.filters.archive &&
          !this.filters.done &&
          !this.filters.inProgress &&
          !this.filters.pending &&
          !this.filters.yetToAssign &&
          !this.filters.overdue
        ) {
          this.campaigns = this.bk_campaigns;
          if (this.campaigns.length !== 0) {
            this.showNullMessage = false;
          }
          this.filters = {
            archive: true,
            done: true,
            inProgress: true,
            pending: true,
            yetToAssign: true,
            overdue: true
          };
        }
      } else {
        if (!camp.campaignIsArchived) {
          if (
            (camp.campaignStatus.statusId === 1 && this.filters.done) ||
            (camp.campaignStatus.statusId === 2 && this.filters.inProgress) ||
            (camp.campaignStatus.statusId === 4 && this.filters.pending) ||
            (camp.campaignStatus.statusId === 3 && this.filters.yetToAssign) ||
            (camp.campaignStatus.statusId === 9 && this.filters.overdue)
          ) {
            this.campaigns.push(camp);
          } else if (
            !this.filters.archive &&
            !this.filters.done &&
            !this.filters.inProgress &&
            !this.filters.pending &&
            !this.filters.yetToAssign &&
            !this.filters.overdue
          ) {
            this.campaigns = this.bk_campaigns;
            if (this.campaigns.length !== 0) {
              this.showNullMessage = false;
            }
            this.filters = {
              archive: true,
              done: true,
              inProgress: true,
              pending: true,
              yetToAssign: true,
              overdue: true
            };
          }
        }
      }

      campLen--;
      if (campLen === 0) {
        if (this.campaigns.length === 0) {
          this.showNullMessage = true;
        } else {
          this.showNullMessage = false;
        }
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
      }
    });
  }

  getCampaigns() {
    this._event.broadcast({ eventName: 'showLoader', data: '' });
    this.http.SecureGet('/ref/getAllCampaigns').subscribe(
      res => {
        this.bk_campaigns = res.data.campaigns;
        this.campaigns = res.data.campaigns;
        this.campaigns.forEach(camp => {
          camp.campaignStartDate = camp.campaignStartDate.split(' ')[0];
          camp.campaignEndDate = camp.campaignEndDate.split(' ')[0];
        });
        this.bk_campaigns.forEach(camp => {
          camp.campaignStartDate = camp.campaignStartDate.split(' ')[0];
          camp.campaignEndDate = camp.campaignEndDate.split(' ')[0];
        });
        if (this.campaigns.length !== 0) {
          this.showNullMessage = false;
        } else {
          this.showNullMessage = true;
        }
        this.applyFilter();
      },
      err => {
        this.showNullMessage = true;
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
      }
    );
  }

  assign() {
    this.router.navigate(['admin/campaign/assign']);
  }

  archiveCampaign(id) {
    this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ARE_U_SURE_U_WANT_TO_ARCHIVE_THIS_CAMPAIGN).subscribe(trResTitle => {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ALL_DATA_WILL_BE_ARCHIVED).subscribe(trResText => {
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.YES_ARCHIVE_IT).subscribe(trResBtnText => {
          this.translateService.getLanguageValue('Cancel').subscribe(trResCnlText => {
            swal({
              title: trResTitle + '?',
              text: trResText,
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: trResBtnText,
              cancelButtonText: trResCnlText
            }).then(() => {
              this.http
                .SecurePost('/campaign/updateCampaign', {
                  campaignId: id,
                  campaignIsArchived: true,
                  campaignUpdatedBy: this.user.userId
                })
                .subscribe(
                  res => {
                    this.getCampaigns();
                    swal(res.responseMessage, '', 'success');
                  },
                  err => {
                  }
                );
            }).catch(() => {
              console.log('Alert closed');
            });
          });
        });
      });
    });
  }

  restoreCampaign(id) {
    this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ARE_YOU_SURE_U_WANT_TO_RESTORE_THIS_CAMPAIGN).subscribe(trResTitle => {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ALL_THE_DATA_IN_IT_WILL_BE_RESTORED).subscribe(trResText => {
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.YES_RESTORE_IT).subscribe(trResBtnText => {
          this.translateService.getLanguageValue('Cancel').subscribe(trResCnlText => {
            swal({
              title: trResTitle + '?',
              text: trResText,
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: trResBtnText,
              cancelButtonText: trResCnlText
            }).then(() => {
              this.http
                .SecurePost('/campaign/updateCampaign', {
                  campaignId: id,
                  campaignIsArchived: false,
                  campaignUpdatedBy: this.user.userId
                })
                .subscribe(
                  res => {
                    this.getCampaigns();
                    swal(res.responseMessage, '', 'success');
                  },
                  err => {
                  }
                );
            }).catch(() => {
              console.log('Alert closed');
            });
          });
        });
      });
    });
  }

  dropDownClicked() {
    this._event.broadcast({ eventName: 'campaign-dd-clicked', data: '' });
  }

  editCampaign(id) {
    this.router.navigate(['/admin/campaign/edit/' + id]);
  }
}

/* Kindly use this in JQuery projects.
$('.dd .btn-primary').on('click', function (event) {
  $(this).parent().toggleClass('show');
});
$('body').on('click', function (e) {
  if (!$('.dd .btn-primary').is(e.target) && $('.dd .btn-primary').has(e.target).length === 0 && $('.show').has(e.target).length === 0) {
    $('.dd').removeClass('show');
  }
}); */
