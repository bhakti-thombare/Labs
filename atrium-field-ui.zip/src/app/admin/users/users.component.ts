// core imports
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

// 3rd party imports
import swal from 'sweetalert2';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/map';

// app imports
import { HttpService } from '@app/services/http-service';
import { InitialsService } from '@services/initials/initials.service';
import { EventService } from '@services/events/event.service';
import { TranslationService } from '@services/translation/translation.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

let supervisor = [];
let fieldAgent = [];
let people = [];

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit, AfterViewInit {
  constructor(
    public router: Router,
    public http: HttpService,
    private initialsService: InitialsService,
    private _event: EventService,
    private translateService: TranslationService
  ) { }
  searchFlag = false;
  dontShowCloseImage = false;
  showNullMessage = false;
  inviteMessage = '';
  addMessage = '';
  supervisor = {
    selectedFieldAgent: '',
    supervisorName: '',
    fieldAgents: [],
    searchData: ''
  };
  users = [];
  users_bk = [];
  private myForm;
  formatter = (result: string) => result.toUpperCase();
  searchSupervisor = (text$: Observable<string>) =>
    text$
      .debounceTime(200)
      .distinctUntilChanged()
      .map(
        term =>
          term === ''
            ? []
            : supervisor
              .filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1)
              .slice(0, 10)
      )

  searchFieldAgent = (text$: Observable<string>) =>
    text$
      .debounceTime(200)
      .distinctUntilChanged()
      .map(
        term =>
          term === ''
            ? []
            : fieldAgent
              .filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1)
              .slice(0, 10)
      )

  search = (text$: Observable<string>) =>
    text$
      .debounceTime(200)
      .distinctUntilChanged()
      .map(
        term =>
          term === ''
            ? []
            : people
              .filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1)
              .slice(0, 10)
      )


  ngOnInit() {
    this.myForm = new FormGroup({
      supervisorSelected: new FormControl('', Validators.required),
      fieldAgentSelected: new FormControl('', Validators.required),
      searchData: new FormControl('', Validators.required)
    });
    this.getUsers();
    if (window.innerWidth <= 414) {
      this.searchFlag = true;
      this.inviteMessage = 'INVITE';
      this.addMessage = 'ADD';
    } else {
      this.inviteMessage = 'INVITE PEOPLE';
      this.addMessage = 'ADD USER';
    }
  }

  ngAfterViewInit() {
    $('.ng2-tag-input__text-input').css('display', 'none');

    if (window.innerWidth <= 414) {
      $('.invite-button').toggleClass('float-right');
      $('.add-button').toggleClass('mr-2');
      $('.add-button').css('margin-right', '0');
      $('.search-input').css('margin-top', '20px');
      $('.search-input').css('margin-bottom', '20px');
      $('.search-input').css('width', '100%');
    }

    this._event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'user-dd-clicked') {
          $('.dropdown-options').click(function () {
            const $btndropdown = $(this).find('.dropdown-toggle');
            const $listholder = $(this).find('.dropdown-menu');
            let $marginTop = 0;
            if (window.innerWidth <= 414) {
              $marginTop = 310;
            } else {
              $marginTop = 219;
            }
            $(this).css('position', 'static');
            $listholder.css({
              top:
                $btndropdown.offset().top +
                $btndropdown.outerHeight(true) -
                $marginTop +
                'px',
              left: 'auto'
            });
          });
        }
      }
    });
  }

  /* addToAgentsArray() {
    if (
      this.supervisor.selectedFieldAgent != "" &&
      this.supervisor.supervisorName != ""
    ) {
      this.supervisor.fieldAgents.includes(this.supervisor.selectedFieldAgent)
        ? console.log("already present")
        : this.supervisor.fieldAgents.push(this.supervisor.selectedFieldAgent);
      this.supervisor.selectedFieldAgent = "";
    } else if (
      this.supervisor.supervisorName == "" &&
      this.supervisor.selectedFieldAgent != ""
    ) {
      swal("Please select a Supervisor", "", "warning");
    }
  } */

  searchUser() {
    console.log(this.supervisor.searchData);
    this.users.forEach(user => {
      if (user.firstName + ' ' + user.lastName === this.supervisor.searchData) {
        this.users_bk = this.users;
        this.users = [];
        this.users.push(user);
      }
    });
  }

  getUsers() {
    this._event.broadcast({ eventName: 'showLoader', data: '' });
    this.http.SecureGet('/ref/getAllUsers').subscribe(
      res => {
        const loggedInUser = JSON.parse(localStorage.getItem('user-data'));
        this.users = [];
        supervisor = [];
        fieldAgent = [];
        people = [];
        let len = res.data.users.length;
        res.data.users.forEach(user => {
          console.log(user);
          if (
            !user.resetPassword &&
            loggedInUser.userId !== user.userId &&
            user.roleId !== 1
          ) {
            user.initials = this.initialsService.fetch(
              user.firstName,
              user.lastName
            );
            this.users.push(user);
            this.users_bk.push(user);
            supervisor.push(user.firstName + ' ' + user.lastName);
            people.push(user.firstName + ' ' + user.lastName);
            fieldAgent.push(user.firstName + ' ' + user.lastName);
          }  
          len--;
          if (len === 0) {
            this._event.broadcast({ eventName: 'hideLoader', data: '' });
          }
        
        });
      },
      err => {
        this.showNullMessage = true;
        this._event.broadcast({ eventName: 'hideLoader', data: '' });
        console.log('error in getAllUsers API', err);
      }
    );
  }

  setSearchFlag() {
    if (window.innerWidth <= 414) {
      this.supervisor.searchData = '';
      this.users = this.users_bk;
    } else {
      if (this.searchFlag) {
        this.supervisor.searchData = '';
        this.users = this.users_bk;
        this.searchFlag = false;
      } else {
        this.searchFlag = true;
      }
    }
  }

  reset() {
    this.supervisor = {
      selectedFieldAgent: '',
      supervisorName: '',
      fieldAgents: [],
      searchData: ''
    };
  }

  deactivateUser(id, role) {
    console.log(id);
    if (role === 2) {
      this.http.SecureGet('/ref/getAllCampaigns?assignedTo=' + id).subscribe(res => {
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.CAMPAIGN_ASSIGNED_TO_THIS_USER).subscribe(trResTitle => {
          this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_REASSING_CAMPAIGN_THEN_DEACTIVATE_THE_USER).subscribe(trResText => {
            swal({
              title: trResTitle,
              text: trResText,
              type: 'warning'
            });
          });
        });
      }, err => {
        console.log('err', err);

        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ARE_YOU_SURE_WANT_TO_DEACTIVATE_USER).subscribe(trResTitle => {
          this.translateService.getLanguageValue('Yes, de-activate user').subscribe(trResBtnText => {
            swal({
              title: trResTitle + '?',
              text: '',
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: trResBtnText + '!'
            }).then(() => {
              console.log(id);
              this.http
                .SecurePost('/user/updateUser', { userId: id, isActive: false })
                .subscribe(
                  res => {
                    this.getUsers();
                    this.translateService.getLanguageValue(res.responseMessage).subscribe(resMessage => {
                      swal(resMessage, '', 'success');
                    });
                  },
                  erro => {
                    const error = JSON.parse(erro._body);
                    this.translateService.getLanguageValue(error.responseMessage).subscribe(errMessage => {
                      swal(errMessage, '', 'error');
                    });
                  }
                );
            });
          });
        });
      });
    } else if (role === 3) {
      this.http.SecureGet('/ref/getAllMissions?assignedTo=' + id).subscribe(res => {

        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.MISSION_ASSIGNED_TO_THIS_USER).subscribe(trResTitle => {
          this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_REASIGN_THE_MISSION_THEN_DEACTIVATE_THIS_USER).subscribe(trResText => {
            swal({
              title: trResTitle,
              text: trResText,
              type: 'warning'
            });
          });
        });
      }, err => {

        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ARE_YOU_SURE_WANT_TO_DEACTIVATE_USER).subscribe(trResTitle => {
          this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.YES_DEACTIVATE_USER).subscribe(trResBtnText => {
            swal({
              title: trResTitle + '?',
              text: '',
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: trResBtnText + '!'
            }).then(() => {
              console.log(id);
              this.http
                .SecurePost('/user/updateUser', { userId: id, isActive: false })
                .subscribe(
                  res => {
                    this.getUsers();
                    this.translateService.getLanguageValue(res.responseMessage).subscribe(resMessage => {
                      swal(resMessage, '', 'success');
                    });
                  },
                  erro => {
                    const error = JSON.parse(erro._body);
                    this.translateService.getLanguageValue(error.responseMessage).subscribe(errMessage => {
                      swal(errMessage, '', 'error');
                    });
                  }
                );
            });
          });
        });
      });
    }
  }

  activateUser(id) {
    this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ARE_YOU_SURE_U_WANT_TO_ACTIVATE_USER).subscribe(trResTitle => {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.YES_ACTIVATE_USER).subscribe(trResBtnText => {
        swal({
          title: trResTitle + '?',
          text: '',
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: trResBtnText + '!'
        }).then(() => {
          console.log(id);
          this.http
            .SecurePost('/user/updateUser', { userId: id, isActive: true })
            .subscribe(
              res => {
                console.log(res);
                this.getUsers();
                this.translateService.getLanguageValue(res.responseMessage).subscribe(resMessage => {
                  swal(resMessage, '', 'success');
                });
              },
              err => {
                const error = JSON.parse(err._body);
                this.translateService.getLanguageValue(error.responseMessage).subscribe(errMessage => {
                  swal(errMessage, '', 'error');
                });
              }
            );
        });
      });
    });
  }

  dropdownClicked() {
    this._event.broadcast({ eventName: 'user-dd-clicked', data: '' });
  }
}
