// core imports
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, AfterViewInit } from '@angular/core';

// 3rd party
import { Observable } from 'rxjs/Observable';

const refData = [];

@Component({
  selector: 'app-activities',
  templateUrl: './activities.component.html',
  styleUrls: ['./activities.component.css']
})
export class ActivitiesComponent implements OnInit, AfterViewInit {

  constructor() { }
  private searchFlag: boolean;
  private dontShowClose: boolean;
  private model = {
    searchData: ''
  };
  private myForm = new FormGroup({
    searchData: new FormControl('', Validators.required)
  });
  private formatter = (result: string) => result.toUpperCase();
  private search = (text$: Observable<string>) =>
    text$
      .debounceTime(200)
      .distinctUntilChanged()
      .map(
        term =>
          term === ''
            ? []
            : refData
              .filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1)
              .slice(0, 10)
      )
  ngOnInit() {
    if (window.innerWidth <= 1024) {
      this.searchFlag = true;
      this.dontShowClose = true;
    }
  }

  ngAfterViewInit() {
    if (window.innerWidth <= 768) {
      $('.users').toggleClass('float-right');
      $('.users').toggleClass('float-left');
      $('.users').toggleClass('ml-3');
      $('.button-options').toggleClass('mb-3');
      $('.actions>ul').css('left', 'auto');
      $('.actions>ul').css('right', '0');
    } else if (window.innerWidth <= 1024) {

    }
  }

  setSearchFlag() {
    if (window.innerWidth <= 1024) {

    } else {
      if (this.searchFlag) {
        this.searchFlag = false;
      } else {
        this.searchFlag = true;
      }
    }
  }

}
