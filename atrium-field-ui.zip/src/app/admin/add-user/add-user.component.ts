// core imports
import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';

// 3rd party imports
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import swal from 'sweetalert2';

//application imports 
import { HttpService } from '@app/services/http-service';
import { TranslationService } from '@services/translation/translation.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';
import { UtilityFunctions } from '@app/shared/utility-functions';
const people = [];

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit, AfterViewInit, OnDestroy {
  private subscriptions: Subscription[] = [];
  private utilityFunctions = new UtilityFunctions();
  public role;
  private myForm: FormGroup;
  private user = {};
  private disableSubmit = false;
  constructor(public location: Location, public http: HttpService, public translateService: TranslationService) { }

  ngOnInit() {
    this.myForm = new FormGroup({
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      email: new FormControl('', Validators.required),
      contact: new FormControl('', [Validators.required, Validators.pattern('^[1-9][0-9]{7,13}$')]),
      // 'password': new FormControl('', [Validators.required, Validators.pattern('^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$')]),
      address: new FormControl('', Validators.required)
    });
    this.role = 'Field agent';
  }

  ngAfterViewInit() {
    if (window.innerWidth <= 414) {
      $('.select-role').css('width', '67%');
      $('.select-role').css('margin-left', '45px');
      $('.img-container').toggleClass('col-sm-3');
      $('.input-container').toggleClass('col-sm-9');
      $('.input-container').css('width', '70%');
      $('.input-container').css('margin-left', '12px');
      $('.role-dropdown').css('margin-top', '-25px');
      $('.open-dd').toggleClass('dropdown-toggle');
      $('.open-dd').toggleClass('roletoggler');
    } else if (window.innerWidth <= 1024) {
      $('.select-role').css('width', '80%');
    }
  }

  goBack() {
    this.location.back();
  }

  toggleRole(role2toggle) {
    console.log(role2toggle);
    this.role = role2toggle;
  }

  submit(form) {
    if (form.valid) {
      this.disableSubmit = true;
      console.log(form.value);
      const reqObj = {
        roleId: this.role === 'Field agent' ? 3 : 2,
        firstName: form.value.firstName,
        lastName: form.value.lastName,
        email: form.value.email,
        contactNumber: form.value.contact,
        address: form.value.address,
        resetPassword: false,
        resetProfile: false
      };
      this.subscriptions.push(this.http.SecurePost('/user/register', reqObj).subscribe(
        res => {
          this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ADDED_SUCCESSFULLY).subscribe(trResTitle => {
            this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ACTIVATION_EMAIL_SENT).subscribe(trResText => {
              swal(
                reqObj.firstName + ' ' + trResTitle,
                trResText,
                'success'
              ).then(data => {
                this.goBack();
              });
            });
          });
        },
        err => {
          if (err._body) {
            const error = JSON.parse(err._body);
            console.log(error);
            if (error.responseCode === '200') {
              if (error.data.duplicateActiveUser.length !== 0) {
                this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.HAS_ALREADY_BEEN_REGISTERED_AND_IS_ACTIVE).subscribe(trResTitle => {
                  swal(
                    error.data.duplicateActiveUser[0] +
                    ' ' + trResTitle,
                    '',
                    'warning'
                  ).then(data => {
                    this.goBack();
                  });
                });
              } else if (error.data.duplicateInActiveAndNotReset.length !== 0) {
                this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.HAS_ALREADY_BEEN_REGISTERED_AND_IS_NOT_ACTIVE).subscribe(trResTitle => {
                  this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ASK_ADMIN_FOR_REACTIVATION).subscribe(trResText => {
                    swal(
                      error.data.duplicateInActiveAndNotReset[0] +
                      ' ' + trResTitle,
                      trResText,
                      'warning'
                    ).then(data => {
                      this.goBack();
                    });
                  });
                });
              } else if (error.data.duplicateActiveAndReset.length !== 0) {
                this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ALREADY_REGISTERED).subscribe(trResTitle => {
                  this.translateService.getLanguageValue('You cannot add').subscribe(trResText1 => {
                    this.translateService.getLanguageValue('twice').subscribe(trResText2 => {
                      swal(
                        error.data.duplicateActiveAndReset[0] + ' ' + trResTitle,
                        trResText1 + ' ' +
                        error.data.duplicateActiveAndReset[0] +
                        ' ' + trResText2,
                        'warning'
                      ).then(data => {
                        this.goBack();
                      });
                    });
                  });
                });
              } else if (error.data.duplicatePendingVerification.length !== 0) {
                this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.EMAIL_ALREADY_BEEN_SENT_TO).subscribe(trResTitle => {
                  this.translateService.getLanguageValue('Please ask').subscribe(trResText1 => {
                    this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.TO_CLICK_ON_THE_ACTIVATION_LINK).subscribe(trResText2 => {
                      swal(
                        trResTitle + ' ' +
                        error.data.duplicatePendingVerification[0],
                        trResText1 + ' ' +
                        error.data.duplicatePendingVerification[0] +
                        ' ' + trResText2,
                        'warning'
                      ).then(data => {
                        this.goBack();
                      });
                    });
                  });
                });
              } else if (error.data.errorSendingEmailTo.length !== 0) {
                this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.SOMETHING_WENT_WRONG).subscribe(trResTitle => {
                  this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.THE_EMAIL_WAS_NOT_SENT_TO).subscribe(trResText1 => {
                    swal(
                      trResTitle,
                      trResText1 + ' ' +
                      error.data.errorSendingEmailTo[0],
                      'warning'
                    ).then(data => {
                      this.goBack();
                    });
                  });
                });
              } else if (error.data.registeredPendingVerification.length !== 0) {
                this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.VERIFICATION_LINK_SENT_VIA_EMAIL).subscribe(trResTitle => {
                  this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ASK_TO_CLICK_THE_LINK_TO_ACTIVATE_THE_ACCOUNT).subscribe(trResText1 => {
                    swal(
                      trResTitle,
                      trResText1,
                      'warning'
                    ).then(data => {
                      this.goBack();
                    });
                  });
                });
              }
            }
          } else {
            this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.SOMETHING_WENT_WRONG).subscribe(trResTitle => {
              swal(trResTitle, '', 'warning');
            });
          }
        }
      ));
    } else {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.FILL_UP_ALL_FIELDS_AS_MENTIONED_BELOW).subscribe(trResTitle => {
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_FILL_UP_ALL_FIELDS_WITH_VALID_DATE +
          MESSAGECONSTANTS.ALERT_MESSAGES.EMAIL_INPUT_SHOULD_BE_AN_EMAIL_AND_4_CONTACT_IT_SHOULD_BE_NUMBER).subscribe(trResText => {
            swal(
              trResTitle,
              trResText,
              'warning'
            );
          });
      });
    }
  }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }

}
