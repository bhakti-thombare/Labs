// core imports
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Location } from '@angular/common';

//3rd party imports
import swal from 'sweetalert2';

// app imports
import { HttpService } from '@app/services/http-service';
import { TranslationService } from '@services/translation/translation.service';
import { OnlyFewLettersPipe } from '@pipes/only-few-letters.pipe';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';
@Component({
  selector: 'app-invite-people',
  templateUrl: './invite-people.component.html',
  styleUrls: ['./invite-people.component.css'],
  providers: [OnlyFewLettersPipe]
})
export class InvitePeopleComponent implements OnInit, AfterViewInit {

  constructor(private location: Location, private http: HttpService, private translateService: TranslationService, private onlyFewLetters: OnlyFewLettersPipe) { }
  emails = [];
  role: any;
  placeholderMessage;
  disableSubmit = false;
  ngOnInit() {
    this.role = 'Field agent';
  }

  ngAfterViewInit() {
    $('.ng2-tag-input').css('border', 'none');
    $('tag-input-form').css('width', '100%');
    $('.ng2-tag-input__text-input').css('width', '100%');
    this.translateService.getLanguageValue('Enter emails to invite').subscribe(res => {
      $('.ng2-tag-input__text-input').attr('placeholder', res);
    });
    if (window.innerWidth <= 414) {
      $('.select-role').css('width', '67%');
      $('.select-role').css('margin-left', '20px');
      $('.img-container').toggleClass('col-sm-3');
      $('.input-container').toggleClass('col-sm-9');
      $('.input-container').css('width', '70%');
      $('.input-container').css('margin-left', '12px');
      $('.role-dropdown').css('margin-top', '-70px');
      $('.open-dd').toggleClass('dropdown-toggle');
      $('.open-dd').toggleClass('roletoggler');
      $('.role-dropdown').css('right', '0px');
      $('.wrap-textarea>img').css('margin-left', '4px');
      $('.wrap-textarea').css('height', '300%');
      $('.invite-button-options').css('margin-top', '150px');
      $('.invite-button').toggleClass('width-25');
    }
  }

  goBack() {
    this.location.back();
  }

  toggleRole(role2toggle) {
    console.log(role2toggle);
    this.role = role2toggle;
  }

  submit(form) {
    /* let reg = new RegExp("(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*"); */
    if (form.value.emails.length > 0) {
      this.disableSubmit = true;
      let reqObj = {};
      reqObj = {
        'roleId': this.role === 'Field agent' ? '3' : '2',
        /* "password": form.value.password, */
        'emails': []
      };
      let len = form.value.emails.length;
      form.value.emails.forEach(email => {
        reqObj['emails'].push(email.value);
        len--;
        if (len === 0) {
          this.http.SecurePost('/user/bulkRegistration', reqObj).subscribe(res => {
            const dupActRes = res.data.duplicateActiveAndReset.length !== 0 ? res.data.duplicateActiveAndReset.join(', ') : undefined;
            const errSendEmail = res.data.errorSendingEmailTo.length !== 0 ? res.data.errorSendingEmailTo.join(', ') : undefined;
            const dupActUser = res.data.duplicateActiveUser.length !== 0 ? res.data.duplicateActiveUser.join(', ') : undefined;
            const dupPenVer = res.data.duplicatePendingVerification.length !== 0 ?
              res.data.duplicatePendingVerification.join(', ') : undefined;
            const dupInactNotRes = res.data.duplicateInActiveAndNotReset.length !== 0 ?
              res.data.duplicateInActiveAndNotReset.join(', ') : undefined;
            const regPenVer = res.data.registeredPendingVerification.legth !== 0 ?
              res.data.registeredPendingVerification.join(', ') : undefined;

            let regPenVerMsg;
            let dupPenVerMsg;
            let dupActUserMsg;
            let errSendEmailMsg;
            let dupActResMsg;
            let dupInactNotResMsg;
            this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.VERIFIED_AND_EMAIL_SENT_SUCCESSFULLY).subscribe(message => {
              regPenVerMsg = regPenVer ? regPenVer + ' ' + message + '.<br/><br/>' : '';
            });
            this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.HAS_NOT_BEEN_ACTIVATED).subscribe(message => {
              dupPenVerMsg = dupPenVer ? dupPenVer + ' ' + message + '.<br/><br/>' : '';
            });
            this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ALREADY_ACTIVATED_PLEASE_ASK_TO_LOGIN).subscribe(message => {
              dupActUserMsg = dupActUser ? dupActUser + ' ' + message + '.<br/><br/>' : '';
            });
            this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.CANNOT_BE_VERIFIED_NOT_PRESENT_IN_SES_STACK).subscribe(message => {
              errSendEmailMsg = errSendEmail ? errSendEmail + ' ' + message + '.<br/><br/>' : '';
            });
            this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.HAVE_ALREADY_BEEN_ACTIVATED_PASSWORD_NEEDS_TO_BE_RESET +
              'Please ask to reset password').subscribe(message => {
                dupActResMsg = dupActRes ? dupActRes +
                  ' ' + message + '.<br/><br/>' : '';
              });
            this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.HAVE_ALREADY_BEEN_VERIFIED_BUT_ARE_NOT_ACTIVATED +
              'Awaiting activation').subscribe(message => {
                dupInactNotResMsg = dupInactNotRes ?
                  dupInactNotRes + ' ' + message + '.<br/><br/>' : '';
              });

            swal({
              type: 'info',
              html: regPenVerMsg + dupPenVerMsg + dupActUserMsg + errSendEmailMsg + dupActResMsg + dupInactNotResMsg,
              showCloseButton: true
            }).then(() => {
              this.disableSubmit = false;
              form.reset();
            });
          }, err => {
            this.translateService.getLanguageValue('Database Error').subscribe(message => {
              swal(message,
                '',
                'error');
            });
            this.disableSubmit = false;
          });
        }
      });
    } else {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ALL_FIELDS_ARE_MANDATORY).subscribe(messageTitle => {
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_FILL_UP_ALL_FIELDS).subscribe(messageText => {
          swal(
            messageTitle,
            messageText,
            'warning'
          );
        });
      });
    }
  }

}
