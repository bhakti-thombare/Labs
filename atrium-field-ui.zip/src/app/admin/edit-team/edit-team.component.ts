// core imports
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common';

// 3rd party imports
import 'rxjs/add/operator/map';
import swal from 'sweetalert2';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';

// app imports
import { HttpService } from '@app/services/http-service';
import { TranslationService } from '@services/translation/translation.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

let fieldAgent = [];
@Component({
  selector: 'app-edit-team',
  templateUrl: './edit-team.component.html',
  styleUrls: ['./edit-team.component.css']
})
export class EditTeamComponent implements OnInit, AfterViewInit {

  submitDisabled = true;
  fieldAgentNotSelected = true;
  mainSubmitDisable = false;
  supervisor = {
    selectedFieldAgent: '',
    supervisorName: '',
    fieldAgents: [],
    searchData: ''
  };

  userId;
  teamId;
  fieldAgents = [];
  users = [];

  private myForm;

  formatter = (result: string) => result.toUpperCase();

  searchFieldAgent = (text$: Observable<string>) =>
    text$
      .debounceTime(200)
      .distinctUntilChanged()
      .map(
        term =>
          term === ''
            ? []
            : fieldAgent
              .filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1)
              .slice(0, 10)
      )

  constructor(
    public router: Router,
    public http: HttpService,
    public route: ActivatedRoute,
    public location: Location,
    public translateService: TranslationService
  ) {
    this.route.params.subscribe(params => {
      this.userId = params.id;
    });
  }

  ngOnInit() {
    this.myForm = new FormGroup({
      supervisorSelected: new FormControl('', Validators.required),
      fieldAgentSelected: new FormControl('', Validators.required),
      searchData: new FormControl('', Validators.required)
    });
    this.getUser();
  }

  ngAfterViewInit() {
    $('.ng2-tag-input__text-input').css('display', 'none');

    if (window.innerWidth <= 414) {
      $('.invite-button').toggleClass('float-right');
      $('.add-button').toggleClass('mr-2');
      $('.add-button').css('margin-right', '0');
      $('.search-input').css('margin-top', '20px');
      $('.search-input').css('margin-bottom', '20px');
      $('.search-input').css('width', '100%');
    }
  }

  getUser() {
    this.http.SecureGet('/ref/getAllUsers?id=' + this.userId).subscribe(res => {
      if (res.data.users[0].roleId === 2 && res.data.users[0].isActive && !res.data.users[0].resetPassword) {
        this.http.SecureGet('/ref/getAllTeams?withMembers=true&supervisorId=' + this.userId).subscribe(teamres => {
          this.teamId = teamres.data[0].id;
          const resObj = teamres.data[0];
          const supervisor = teamres.data[0].supervisor;
          this.supervisor.supervisorName = supervisor.firstName + ' ' + supervisor.lastName;
          if (resObj.members !== undefined) {
            let len: number = resObj.members.length;
            resObj.members.forEach(mem => {
              const fullName = mem.firstName + ' ' + mem.lastName;
              this.supervisor.fieldAgents.push(fullName);
              len--;
              if (len === 0) {
                this.fieldAgentArrayFiller();
              }
            });
          } else {
            this.fieldAgentArrayFiller();
          }
        }, err => {
        });
      } else {
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ACTIVATE_THIS_SUPERVISOR_TO_ACCESS_HIS_TEAM).subscribe(resTitle => {
          this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.ACTIVATE_THIS_SUPERVISOR_TO_ACCESS_THE_TEAM).subscribe(resText => {
            swal({
              title: resTitle,
              text: resText
            }).then(() => {
              this.location.back();
            });
          });
        });
      }
    }, err => {
    });
  }

  addToAgentsArray() {
    if (
      this.supervisor.selectedFieldAgent !== '' &&
      this.supervisor.supervisorName !== ''
    ) {
      if (!this.supervisor.fieldAgents.includes(this.supervisor.selectedFieldAgent)
        && fieldAgent.includes(this.supervisor.selectedFieldAgent)) {
        this.supervisor.fieldAgents.push(this.supervisor.selectedFieldAgent);
        this.submitDisabled = false;
        this.swapMembersInBuckets(this.supervisor.selectedFieldAgent);
      } else {
        this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_VALID_FIELD_AGENT).subscribe(message => {
          swal(message, '', 'warning');
        });
      }
      this.supervisor.selectedFieldAgent = '';
    } else if (
      this.supervisor.supervisorName === '' &&
      this.supervisor.selectedFieldAgent !== ''
    ) {
      this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_SUPERVISOR).subscribe(message => {
        swal(message, '', 'warning');
      });
    }
  }

  onFieldAgentRemoved(e) {
    this.submitDisabled = false;
    if (this.supervisor.fieldAgents.length === 0) {
      this.submitDisabled = true;
    }
    this.swapMembersInBuckets(e);
  }

  swapMembersInBuckets(faName) {
    if (fieldAgent.includes(faName)) {
      const i = fieldAgent.indexOf(faName);
      fieldAgent.splice(i, 1);
    } else if (!fieldAgent.includes(faName)) {
      fieldAgent.push(faName);
    }
  }

  fieldAgentArrayFiller() {
    fieldAgent = [];
    this.fieldAgents = [];
    this.http.SecureGet('/ref/getAllUsers').subscribe(res => {
      this.users = res.data.users;
      this.users.forEach(user => {
        if (user.roleId === 3 && user.isActive && !user.resetPassword) {
          const fullName = user.firstName + ' ' + user.lastName;
          this.fieldAgents.push(user);
          if (!this.supervisor.fieldAgents.includes(fullName)) {
            fieldAgent.push(fullName);
          }
        }
      });
    });
  }

  submitTeam(form) {
    this.mainSubmitDisable = true;
    const agents = this.supervisor.fieldAgents;
    const faIds = [];
    if (agents.length !== 0) {
      let len = this.fieldAgents.length;
      this.fieldAgents.forEach(fa => {
        const fullName = fa.firstName + ' ' + fa.lastName;
        agents.forEach(agent => {
          if (agent === fullName) {
            faIds.push(fa.userId);
          }
        });
        len--;
        if (len === 0) {
          this.http.SecurePost('/team/updateTeam', { teamId: this.teamId, teamMembers: faIds }).subscribe(res => {
            this.translateService.getLanguageValue(MESSAGECONSTANTS.ALERT_MESSAGES.TEAM_UPDATED_SUCCESSFULLY).subscribe(message => {
              swal(message, '', 'success').then(() => {
                this.location.back();
              }).catch(err => {
                this.location.back();
              });
            });
          }, err => {
          });

        }
      });
    } else {
      this.translateService.getLanguageValue('').subscribe(message => {
        swal(message, '', 'warning');
      });
    }
  }

  reset() {
    this.supervisor.selectedFieldAgent = '';
    let len = this.supervisor.fieldAgents.length;
    this.submitDisabled = true;
    this.supervisor.fieldAgents.forEach(fa => {
      this.swapMembersInBuckets(fa);
      len--;
      if (len === 0) {
        this.supervisor.fieldAgents = [];
      }
    });
  }

  goBack() {
    this.location.back();
  }

  watchFieldAgent(e) {
    if (fieldAgent.includes(e)) {
      this.fieldAgentNotSelected = false;
    } else {
      this.fieldAgentNotSelected = true;
    }
  }

}
