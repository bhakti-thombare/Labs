// Third party imports
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';


/**
 * @description BroadcastEvent
 *
 * @interface BroadcastEvent
 */
interface BroadcastEvent {
  key: any;
  data?: any;
}

/**
 * @description Broadcaster
 * @export
 * @class Broadcaster
 */
export class Broadcaster {
  public _eventBus: Subject<BroadcastEvent>;


  /**
   *Creates an instance of Broadcaster.
   * @memberof Broadcaster
   */
  constructor() {
    this._eventBus = new Subject<BroadcastEvent>();
  }
  /**
   *@description broadcasts messages though rxJs Subject
   * This is used when showing the menu or the loader event
   * The broadcaster - broadcats the message
   *
   * @param {*} key
   * @param {*} [data]
   * @memberof Broadcaster
   */
  broadcast(key: any, data?: any) {
    this._eventBus.next({ key, data });
  }
  /**
   *@description return observable sequence
   * This is used when showing the menu or the loader event
   * Action is performed when event is triggerred
   * @template T
   * @param {*} key
   * @returns {Observable<T>}
   * @memberof Broadcaster
   */
  on<T>(key: any): Observable<T> {
    return this._eventBus.asObservable()
      .filter(event => event.key === key)
      .map(event => <T>event.data);
  }
}
