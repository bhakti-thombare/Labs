// Core imports
import { Injectable } from '@angular/core';

// Third party imports
import { Observable } from 'rxjs/Observable';

// Application imports
import { Broadcaster } from './broadcaster';

@Injectable()
export class MenuLoadEvent {

  /**
   * Creates an instance of MenuLoadEvent.
   * @param {Broadcaster} broadcaster
   * @memberof MenuLoadEvent
   */
  constructor(private broadcaster: Broadcaster) { }


  /**
   * @description fire method for Menu
   * @param {Boolean} data
   * @memberof MenuLoadEvent
   */
  fire(data: Boolean): void {
    this.broadcaster.broadcast(MenuLoadEvent, data);
  }


  /**
   * @description on method for menu showing
   * @returns {Observable<Boolean>}
   * @memberof MenuLoadEvent
   */
  on(): Observable<Boolean> {
    return this.broadcaster.on<Boolean>(MenuLoadEvent);
  }
}

@Injectable()
export class LoaderEvent {

  /**
   * Creates an instance of LoaderEvent.
   * @param {Broadcaster} broadcaster
   * @memberof LoaderEvent
   */
  constructor(private broadcaster: Broadcaster) {}

  /**
   * @description fire method for showing loader
   * @param {Boolean} data
   * @memberof LoaderEvent
   */
  fire(data: Boolean): void {
    this.broadcaster.broadcast(LoaderEvent, data);
  }


  /**
   * @description on method for loader event action
   * @returns {Observable<Boolean>}
   * @memberof LoaderEvent
   */
  on(): Observable<Boolean> {
    return this.broadcaster.on<Boolean>(LoaderEvent);
  }
}
