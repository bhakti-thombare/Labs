// core imports
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

// 3rd party imports
import 'rxjs/add/operator/map';
import swal from 'sweetalert2';

import { HttpService } from '@app/services/http-service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css']
})
export class ForgotComponent implements OnInit {
  private user = {};
  private disableSubmit = false;
  private myForm: FormGroup;
  constructor(public router: Router, public http: HttpService, private location: Location) { }

  ngOnInit() {
    this.myForm = new FormGroup({
      'email': new FormControl('', Validators.required)
    });
  }

  forgot(form) {
    console.log(form.valid);
    if (form.valid) {
      this.disableSubmit = true;
      this.http.Post('/user/forgotPassword', form.value).subscribe(data => {
        swal(
          MESSAGECONSTANTS.ALERT_MESSAGES.VERIFICATION_CODE_SENT_TO_REGISTERED_EMAIL,
          '',
          'success'
        ).then(() => {
          this.router.navigate(['/verification/' + form.value.email]);
        });
      }, err => {
        swal(
          MESSAGECONSTANTS.ALERT_MESSAGES.INVALID_EMAIL,
          MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ENTER_A_VALID_EMAIL,
          'error'
        );
        this.disableSubmit = false;
      });
    }
    /*  else {
       swal(
         'Fill up the required fields!...',
         'Please fill up all the fields.',
         'error'
       );
       this.disableSubmit = false;
     } */
    /* this.router.navigate(['/admin']); */
  }
  goBack() {
    this.location.back();
  }
}
