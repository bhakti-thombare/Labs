export interface CheckpointDaoInterface {
    id?: string;
    checkpointName?: string;
    index: number;
}

export interface LanguageInterface {
    id?: string;
    name: string;
    description?: string;
}

export interface AlertOptions {
    title: string;
    text: string;
    type: string;
    outsideClick: boolean;
    showCancelBtn: boolean;
    confirmBtnText: string;
    cancelBtnText: string;
}
