import { Routes } from '@angular/router';


import { AuthGaurdService } from '@services/auth-guard/auth-gaurd.service';
import { SupervisorAuthGuardService } from '@services/supervisor-auth-guard/supervisor-auth-guard.service';
import { AuthGuard2Service } from '@services/auth-guard2/auth-guard2.service';
import { FieldAgentGuardService } from '@services/field-agent-guard/field-agent-guard.service';
import { OtaComponent } from '@app/ota/ota.component';
import { LoginComponent } from '@app/login/login.component';
import { ForgotComponent } from '@app/forgot/forgot.component';
import { AdminComponent } from '@app/admin/admin.component';
import { VerificationComponent } from '@app/verification/verification.component';
import { VerificationMessageComponent } from '@app/verification-message/verification-message.component';
import { SupervisorComponent } from '@app/supervisor/supervisor.component';
import { FieldagentComponent } from '@app/fieldagent/fieldagent.component';

/* The paths below have two same appearances:-
    1. Redirect paths are all the possibilities that should redirect to a specific path.
    2. Specific paths that should occur only once in routing modules in overall application. This may contain direct component references or may contain the module to be redirected to.
*/

export const AppRoutes: Routes = [{
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
}, {
    path: 'login',
    redirectTo: 'login',
    pathMatch: 'full'
}, {
    path: 'verifyAccount/:id',
    redirectTo: 'verifyAccount/:id',
    pathMatch: 'full'
},
{
    path: 'admin',
    loadChildren: './admin/admin.module#AdminModule',
    canActivate: [AuthGaurdService]
    // component: AdminComponent,
    // children: [{
    //     path: 'admin',
    // }],
    // canActivate: [AuthGaurdService]
},
{
    path: 'supervisor',
    //component: SupervisorComponent,
    loadChildren: './supervisor/supervisor.module#SupervisorModule',
    // children: [{
    //     path: 'supervisor',
    //     loadChildren: './supervisor/supervisor.module#SupervisorModule'
    // }],
    // canActivate: [SupervisorAuthGuardService]
},
{
    // path: '',
    // component: FieldagentComponent,
    // children: [{
        path: 'fieldagent',
        loadChildren: './fieldagent/fieldagent.module#FieldagentModule'
    //}],
    //canActivate: [FieldAgentGuardService]
},
{
    path: 'login',
    component: LoginComponent,
    canActivate: [AuthGuard2Service]
},
{
    path: 'verifyAccount/:id',
    component: VerificationMessageComponent
},
{
    path: 'forgot',
    component: ForgotComponent,
    canActivate: [AuthGuard2Service]
},
{
    path: 'verification/:email',
    component: VerificationComponent,
    canActivate: [AuthGuard2Service]
}, {
    path: 'ota/index',
    component: OtaComponent
}];
