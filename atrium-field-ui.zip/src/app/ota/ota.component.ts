import { Component, OnInit } from '@angular/core';
import { environment } from "environments/environment";
import { ApiService } from '@app/services/apiServices/api.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-ota',
  templateUrl: './ota.component.html',
  styleUrls: ['./ota.component.css']
})
export class OtaComponent implements OnInit {
  url: string = environment.otaUrl;
  itmsLink: string;
  ipadUrl: any;
  constructor(private apiService: ApiService,
    private sanitizer:DomSanitizer) { }
  ngOnInit() {
    this.apiService.ipadApi(this.url).subscribe((res) => {
      this.ipadUrl = this.sanitizer.bypassSecurityTrustUrl(res.data);
      console.log(this.ipadUrl);
    });
  }
  // getUrl() {
  //   return "itms-services:'/'/?action=download-manifest&url="+ this.ipadUrl;
  //   // console.log(window.location.href);
  // }
}
