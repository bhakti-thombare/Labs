import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { EventService } from '@services/events/event.service';
import { UtilityFunctions } from '@app/shared/utility-functions';
import { Subscription } from 'rxjs/Subscription';
import { LoaderEvent } from '@app/core/message-event';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.css']
})
export class LoaderComponent implements OnInit, AfterViewInit, OnDestroy {
  private utilityFunctions = new UtilityFunctions();
  private subscriptions: Subscription[] = [];
  // flag to show laoder
  public showLoaderValue : Boolean = false;
  status: boolean;
  message = 'processing';
  loader: boolean;
  constructor(public _event: EventService,private loaderEvent: LoaderEvent) { }

  ngOnInit() {
    this.subscriptions.push(this.loaderEvent.on()
    // this event handles the showing and hiding the loader
      .subscribe(message => {
        if (message) {
          this.showLoaderValue = true;
        } else {
          this.showLoaderValue = false;
        }
      }));
  }

  ngAfterViewInit() {
    this._event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'showLoader') {
          this.showLoader();
        } else if (message.eventName === 'hideLoader') {
          this.hideLoader();
          this.message = 'processing';
        }
      }
    });

    this._event.currentMessage.subscribe(message => {
      if (message && message.eventName !== 'default') {
        if (message.eventName === 'hideScroll') {
          $('html').css('overflow-y', 'hidden');
        } else if (message.eventName === 'showScroll') {
          $('html').css('overflow-y', 'scroll');
        } else if (message.eventName === 'changeLoaderMessage') {
          this.message = message.data;
        }
        if (message.eventName === 'showLoader') {
          this.showLoader();
        } else if (message.eventName === 'hideLoader') {
          this.hideLoader();
          this.message = 'processing';
        }
      }
    });
  }

  showLoader() {
    this.status = true;
    this._event.broadcast({ eventName: 'hideScroll', data: '' });
  }

  hideLoader() {
    this.status = false;
    this._event.broadcast({ eventName: 'showScroll', data: '' });
  }

  changeMessage(newMessage) {
    this.message = newMessage;
  }

  ngOnDestroy() {
    this.utilityFunctions.unSubscribeSubscriptions(this.subscriptions);
  }

}
