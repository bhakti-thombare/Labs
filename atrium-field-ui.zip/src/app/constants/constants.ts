import { environment } from 'environments/environment';
export class ApiConstants {
    public static get LOCAL_URL(): string { return 'http://10.30.15.42:8080'; }
    public static get PULL_API(): string { return 'https://dppublishapi.analytics.brussels/dev/geo/getGeo'; }
    public static get PRESIGNED_URL(): string { return environment.getPosDetailsByQuartierApi; }
    public static get BASE_URL(): string { return environment.api; }

}

export class DataConstants {
    public static get MONTHS(): string[] {
        return ['January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ]
    };
    public static get MAPBOX_ACCESS_TOKEN(): string { return environment.mapbox.accessToken; }
}

export class statuses {
    /* Status Types */
    public static get DONE(): number { return 1; }
    public static get INPROGRESS(): number { return 2; }
    public static get YETTOASSIGN(): number { return 3; }
    public static get PENDING(): number { return 4; }
    public static get YETTOSTART(): number { return 6; }
    public static get INREVIEW(): number { return 7; }
    public static get GIVEUP(): number { return 8; }
    public static get OVERDUE(): number { return 9; }
    public static get REASSIGNED(): number { return 10; }
    public static get INVALID(): number { return 11; }
    public static get GIVENUP(): number { return 12; }
    public static get YETTOVALIDATE(): number { return 13; }
    public static get VALID(): number { return 14; }
}

export class missionTypes {
    /* Mission Types */
    public static get CUSTOMER_SURVEY_TYPE_ID(): number { return 4; }
    public static get STANDS_SURVEY_TYPE_ID(): number { return 7; }
    public static get MARKET_SURVEY_TYPE_ID(): number { return 1; }
    public static get PEDESTRIAN_FLOW_SURVEY_TYPE_ID(): number { return 3; }
    public static get POS_POI_TYPE_ID(): number { return 2; }
}

export class MissionProgressDetails {
    public static MCQINDEX: Array<any> = [5, 8, 11];
}
export class Globals {
    public static BUSY_DATES: Array<any> = [];
    public static TEMP: Array<any> = [];
    public static Existing_ZonesBackup: Array<any> = [];
    public static VALID_POPUP_TRASLATORS: Array<any> = ["title", "text", "cancelButtonText", "confirmButtonText"];
    public static get MISSION_SUBTYPES_BOTH(): Array<any> { return [{ name: 'Points of sale only', id: 5 }, { name: 'Points of sale & Checkpoints', id: 6 }] };
    public static get MISSION_SUBTYPES_STOERS(): Array<any> { return [{ name: 'Stores only', id: 5 }] };
    public static campaignStartDate: string = '';
    public static campaignEndDate: string = '';
}
