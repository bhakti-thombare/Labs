export class APICONSTANTS {
  public static REF = {
    REF_KEY: '/ref',
    GET_ALL_CHECKPOINTS: '/getAllCheckpoints',
    GET_REF_LANGUAGE: '/getRefLanguage',
    GET_ALL_ROLES: '/getAllRoles',
    GET_ALL_MISSIONS: '/getAllMissions',
    GET_ALL_AGENTS: '/calendar/agents',
    GET_CALENDAR_INFO: '/calendar/info',
    GET_MISSIONS:'/missions',
    GET_REF_MISSION_TYPE: '/getRefMissionType',
    GET_MISSION_DATES: '/getMissionDates',
    GET_ALL_CAMPAIGNS: '/getAllCampaigns',
    GET_ALL_CIRCUITS: '/getAllCircuits',
    GET_ALL_UNASSIGNED_USERS: '/getAllUnassignedUsers',
    GET_ALL_UNASSIGNED_USERS_POS: '/getAllUnassignedUsersPos',
    GET_ALL_ZONES: '/getAllZones',
    GET_ALL_MARKETS: '/getAllZones',
    GET_ALL_USERS: '/getAllUsers',
    GET_MISSIONS_BY_CAMPAIGN_ID: '/getMissionsByCampaignId',
    GET_ALL_QUARTIERS: '/getAllQuartiers',
    GET_ALL_POS_MISSIONS: '/getAllPosMissions',
    CHECK_POS_USER_AVAILABILITY: '/checkPosUserAvailability',
    GET_PEDESTRIAN_MISSIONS: '/getPedestrianMissions',
    GET_PEDESTRIAN_CIRCUITS: '/getPedestrianCircuits',
    GET_MARKET_ZONE:'/market/zones',
    GET_MISSION_NAME:'/mission/name',
    GET_UNAVAILABLE_USER:'/user/unavailability',
    REMOVE_UNAVAILABLE_USER:'/user/unavailability/remove',
    GET_UNAVAILABLE_DATE:'/user/unavailability/dates'
  };

  public static MISSION = {
    MISSION_KEY: '/mission',
    GET_USER_MISSION_DETAILS: '/getUserMissionDetails',
    EDIT_MISSION: '/editMission',
    ASSIGN_MISSION: '/assignMission',
    CHANGE_MISSION_DATE: '/changeMissionDate',
    ADD_MISSION: '/addMission',
    UPDATE_MISSION: '/updateMission',
    MISSION_PROGRESS_REPORT: '/missionProgressReport',
    SURVEY_MISSION_PROGRESS_REPORT: '/surveyMissionProgressReport',
    STANDS_MISSION_MPD:'/standsMissionMpd',
    USER_SURVEY_REPORT: '/userSurveyReport',
    STAND_MISSION_INFO:'/standsMissionInfo',
    APPROVE_MISSION: '/approveMission',
    REASSIGN_MISSION: '/reAssignMission',
    GET_INFOSHEET: '/pos/getPosInfoSheet',
    DELETE_MISSION:'/delete',
    EVALUATE:'/evaluate'
  };

  public static POS = {
    POS_KEY: '/pos',
    GET_COORDINATES: '/getCordinates',
    MAP_QUARTIER: '/mapQuartier',
    MAP_POS: '/mapPos',
    MAP_POS_CHECKPOINTS: '/mapPosCheckpoints',
    ASSIGN_POS_MISSION: '/assignPosMission',
    GET_POS_EDIT_MISSION_PAGE: '/getPosEditMissionPage',
    GET_POS_MPD_CARDS: '/posMpdCards',
    GET_POS_MPD: '/getPosMpd',
    GET_POS_CHECKPOINTS: '/getPosCheckpoints',
    UPDATE_POS_CHECKPOINT_STATUS: '/updatePosCheckpointStatus',
    APPROVE_POS_MISSION: '/approvePosMission',
    RE_ASSIGN_POS_MISSION: '/reAssignPosMission',
    REJECTED_POS: '/getPosRejectedCount',
    UPDATED_POS_STATUS: '/updatePosStatus',
    REASSIGN:'/reassign'
  };

  public static USER = {
    USER_KEY: '/user',
    UPDATE_USER: '/updateUser',
    LOGIN: '/login'
  };

  public static ZONE = {
    ZONE_KEY: '/zone',
    ADD_ZONE: '/addZone'
  };

  public static MARKET = {
    MARKET_KEY: '/market',
    ADD_MARKET: '/zone'
  };

  public static SURVEY = {
    SURVEY_KEY: '/survey',
    UPDATE_USER_SURVEY: '/updateUserSurvey'
  };

  public static CIRCUIT = {
    CIRCUIT_KEY: '/circuit',
    ADD_CIRCUIT: '/addCircuit'
  };

  public static LOCATION = {
    GET_LOCATIONS_TYPE:'/dropdown/getLocationTypes',
    GET_LOCATIONS: '/location',
    GET_DETAILS: '/details'
  };

  public static IPAD={
    GET_URL:'/ipadAppUrl'
  }

  /* This is for UAT */
  public static GET_POS_DETAILS_BY_QUARTIER =
  '/pos/v2/getPosDetailsByQuartier';
  // 'https://7rx5mcoa32.execute-api.eu-central-1.amazonaws.com/dev/pos/v2/getPosDetailsByQuartier';
    // 'https://bzwgmiv6i9.execute-api.eu-central-1.amazonaws.com/dev/pos/getPosDetailsByQuartier';

  // This is the Production URL Updated Dt01072019
  // public static GET_POS_DETAILS_BY_QUARTIER =
    // 'https://7rx5mcoa32.execute-api.eu-central-1.amazonaws.com/dev/pos/getPosDetailsByQuartier';
}
