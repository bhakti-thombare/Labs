export class CONSTANTSVALUES {
    public static VALUES = {
        'LIST_DATE_FORMAT': 'DD/MM/YYYY',
        'LIST_MPD_FORMAT': 'DD/MM/YYYY',
        'LIST_TIME_FORMAT': 'hh:mm'
      };
}