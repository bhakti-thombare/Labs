import { TestBed, inject } from '@angular/core/testing';

import { CampaignSummaryService } from './campaign-summary.service';

describe('CampaignSummaryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CampaignSummaryService]
    });
  });

  it('should be created', inject([CampaignSummaryService], (service: CampaignSummaryService) => {
    expect(service).toBeTruthy();
  }));
});
