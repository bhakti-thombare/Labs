import { TestBed, inject } from '@angular/core/testing';

import { SupervisorAuthGuardService } from './supervisor-auth-guard.service';

describe('SupervisorAuthGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SupervisorAuthGuardService]
    });
  });

  it('should be created', inject([SupervisorAuthGuardService], (service: SupervisorAuthGuardService) => {
    expect(service).toBeTruthy();
  }));
});
