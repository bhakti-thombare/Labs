import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';

@Injectable()
export class SupervisorAuthGuardService {

  constructor(private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    let user = JSON.parse(localStorage.getItem('user-data'));
    let sessionObj = JSON.parse(sessionStorage.getItem('percentageWithDegrees'));

    // console.log('SUB-ROUTE :',route.url)

    if (user && sessionObj && user.roleId == 2) {
      return true;
    } else if (user && user.roleId == 2) {
      if (user.resetProfile && user.isActive) {
        if (state.url == '/supervisor/profile') {
          return true;
        } else {
          this.router.navigate(['/login']);
          return false;
        }
      } else if (!user.resetProfile && user.isActive) {
        return true;
      }
    } else if (user && user.roleId == 3) {
      if (user.resetProfile && user.isActive) {
        if (state.url == '/fieldagent/profile') {
          return true;
        } else {
          this.router.navigate(['/login']);
          return false;
        }
      } else if (!user.resetProfile && user.isActive) {
        this.router.navigate(['/fieldagent']);
      }
    } else if (user) {
      this.router.navigate(['/admin']);
    } else {
      this.router.navigate(['/login']);
    }
  }

}
