import { Injectable } from '@angular/core';

@Injectable()
export class InitialsService {

  constructor() { }
  public fetch(firstName, lastName) {
    return firstName.charAt(0) + lastName.charAt(0);
  }
}
