// core imports
import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';

// 3rd party imports
import { Observable } from 'rxjs/Observable';
import swal from 'sweetalert2';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';

// app imports
import { environment } from 'environments/environment';
import { UTILS } from '@app/services/global-utility.service';
import { ApiConstants } from '@app/constants/constants';
import { EventService } from '@app/services/events/event.service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

@Injectable()

export class HttpService {

  headers;
  BASE_URL = ApiConstants.BASE_URL;
  PULL_API = ApiConstants.PULL_API;
  PRESIGNED_URL = ApiConstants.PRESIGNED_URL;

  constructor(private http: Http, private event: EventService) {
    this.headers = new Headers();
    this.headers.append('content-type', 'application/json');
  }

  public Get(url) {
    return this.http.get(this.BASE_URL + url, {
      headers: this.headers, withCredentials: true
    }).map(res => res.json());
  }

  public Post(url, data) {
    return this.http.post(this.BASE_URL + url, data, {
      headers: this.headers, withCredentials: true
    }).map(res => res.json());
  }

  public Put(url, data) {
    return this.http.put(this.BASE_URL + url, data, {
      headers: this.headers, withCredentials: true
    }).map(res => res.json());
  }

  public Delete(url) {
    return this.http.delete(this.BASE_URL + url, {
      headers: this.headers, withCredentials: true
    }).map(res => res.json());
  }

  public setHeaders(headers: Headers, value, id) {
    headers.append('Authorization', value);
    headers.append('userId', id);
  }

  public setRefreshHeaders(headers: Headers, value, id) {
    headers.append('refreshToken', value);
    headers.append('userId', id);
  }

  private handleError<T>(result?: T) {
    return (error: any): Observable<T> => {
      console.error(error);
      return of(result as T);
    };
  }

  public refreshGet(url) {
    const user = JSON.parse(localStorage.getItem('user-data'));
    const headers = new Headers();
    this.setRefreshHeaders(headers, user.refreshToken, user.userId);
    return this.http.get(this.BASE_URL + url, {
      headers: headers, withCredentials: true
    }).map(res => {
      const json = res.json() as any;

      if (json.responseMessage === 'invalidRefreshToken') {
        swal({
          title: MESSAGECONSTANTS.ALERT_MESSAGES.SESSION_EXPIRED,
          text: MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_LOGIN_AGAIN,
          type: 'warning',
          allowOutsideClick: false
        }).then(action => {
          localStorage.clear();
          sessionStorage.clear();
          window.location.reload();
        });
      }
      return json;
    });

  }

  public SecureGet(url) {
    const user = JSON.parse(localStorage.getItem('user-data'));
    const headers = new Headers();
    this.setHeaders(headers, user.accessToken, user.userId);
    return this.http.get(this.BASE_URL + url, {
      headers: headers, withCredentials: true
    }).map(res => {
      const json = res.json() as any;
      if (json.responseMessage === 'invalidToken') {
        this.event.broadcast({ eventName: 'hideLoader', data: '' });
        swal({
          title: MESSAGECONSTANTS.ALERT_MESSAGES.SESSION_EXPIRED,
          text: MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_LOGIN_AGAIN,
          type: 'warning',
          allowOutsideClick: false
        }).then(action => {
          localStorage.clear();
          sessionStorage.clear();
          window.location.reload();
        });
      } else if (json.responseMessage === 'tokenExpired') {
        this.event.broadcast({ eventName: 'hideLoader', data: '' });
        this.refreshGet('/user/refreshToken').subscribe(refreshResponse => {
          const user1 = JSON.parse(localStorage.getItem('user-data'));
          user1.accessToken = refreshResponse.signInData.accesstoken;
          user1.refreshToken = refreshResponse.signInData.refreshtoken;
          localStorage.removeItem('user-data');
          localStorage.setItem('user-data', JSON.stringify(user1));
          window.location.reload();
        }, refreshError => {
          localStorage.clear();
          sessionStorage.clear();
          window.location.reload();
        });
      }

      return json;
    });
  }

  public SecureGet1(url) {
    return this.http.get(this.BASE_URL + url).map(res => {
      const json = res.json() as any;
      return json;
    });
  }

  public SecurePost(url, data) {
    const user = JSON.parse(localStorage.getItem('user-data'));
    const headers = new Headers();
    this.setHeaders(headers, user.accessToken, user.userId);
    return this.http.post(this.BASE_URL + url, data, {
      headers: headers, withCredentials: true
    }).map(res => {
      const json = res.json() as any;

      if (json.responseMessage === 'invalidToken') {
        this.event.broadcast({ eventName: 'hideLoader', data: '' });
        swal({
          title: MESSAGECONSTANTS.ALERT_MESSAGES.SESSION_EXPIRED,
          text: MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_LOGIN_AGAIN,
          type: 'warning',
          allowOutsideClick: false
        }).then(action => {
          localStorage.clear();
          sessionStorage.clear();
          window.location.reload();
        });
      } else if (json.responseMessage === 'tokenExpired') {
        this.event.broadcast({ eventName: 'hideLoader', data: '' });
        this.refreshGet('/user/refreshToken').subscribe(refreshResponse => {
          const user1 = JSON.parse(localStorage.getItem('user-data'));
          user1.accessToken = refreshResponse.signInData.accessToken;
          user1.refreshToken = refreshResponse.signInData.refreshToken;
          localStorage.removeItem('user-data');
          localStorage.setItem('user-data', JSON.stringify(user1));
          window.location.reload();
        }, refreshError => {
          localStorage.clear();
          sessionStorage.clear();
          window.location.reload();
        });
      }

      return json;
    });
  }

  public securePostByMulitpart(url, data: any): Observable<any> {
    const user = JSON.parse(localStorage.getItem('user-data'));
    const headers = new Headers();
    this.setHeaders(headers, user.accessToken, user.userId);
    return this.http.post(this.BASE_URL + url, data, {
      headers: this.headers
    })
      .map(res => res)
      .catch(err => err || "Server Error");
  }

  public SecurePut(url, data) {
    const user = JSON.parse(localStorage.getItem('user-data'));
    const headers = new Headers();
    this.setHeaders(headers, user.accessToken, user.userId);
    return this.http.put(this.BASE_URL + url, data, {
      headers: headers, withCredentials: true
    }).map(res => {
      const json = res.json() as any;

      if (json.responseMessage === 'invalidToken') {
        this.event.broadcast({ eventName: 'hideLoader', data: '' });
        swal({
          title: MESSAGECONSTANTS.ALERT_MESSAGES.SESSION_EXPIRED,
          text: MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_LOGIN_AGAIN,
          type: 'warning',
          allowOutsideClick: false
        }).then(action => {
          localStorage.clear();
          sessionStorage.clear();
          window.location.reload();
        });
      } else if (json.responseMessage === 'tokenExpired') {
        this.event.broadcast({ eventName: 'hideLoader', data: '' });
        this.refreshGet('/user/refreshToken').subscribe(refreshResponse => {
          const user1 = JSON.parse(localStorage.getItem('user-data'));
          user1.accessToken = refreshResponse.signInData.accessToken;
          user1.refreshToken = refreshResponse.signInData.refreshToken;
          localStorage.removeItem('user-data');
          localStorage.setItem('user-data', JSON.stringify(user));
          window.location.reload();
        }, refreshError => {
          localStorage.clear();
          sessionStorage.clear();
          window.location.reload();
        });
      }

      return json;
    });
  }

  public SecureDelete(url) {
    const user = JSON.parse(localStorage.getItem('user-data'));
    const headers = new Headers();
    this.setHeaders(headers, user.accessToken, user.userId);
    return this.http.delete(this.BASE_URL + url, {
      headers: headers, withCredentials: true
    }).map(res => {
      const json = res.json() as any;

      if (json.responseMessage === 'invalidToken') {
        this.event.broadcast({ eventName: 'hideLoader', data: '' });
        swal({
          title: MESSAGECONSTANTS.ALERT_MESSAGES.SESSION_EXPIRED,
          text: MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_LOGIN_AGAIN,
          type: 'warning',
          allowOutsideClick: false
        }).then(action => {
          localStorage.clear();
          sessionStorage.clear();
          window.location.reload();
        });
      } else if (json.responseMessage === 'tokenExpired') {
        this.event.broadcast({ eventName: 'hideLoader', data: '' });
        this.refreshGet('/user/refreshToken').subscribe(refreshResponse => {
          const user1 = JSON.parse(localStorage.getItem('user-data'));
          user1.accessToken = refreshResponse.signInData.accessToken;
          user1.refreshToken = refreshResponse.signInData.refreshToken;
          localStorage.removeItem('user-data');
          localStorage.setItem('user-data', JSON.stringify(user1));
          window.location.reload();
        }, refreshError => {
          localStorage.clear();
          sessionStorage.clear();
          window.location.reload();
        });
      }

      return json;
    });
  }

  public pullCountry() {
    const headers = new Headers();
    headers.append('Authorization', '354901b3-91ae-5a82-808c-9d1ea4fca53f');
    return this.http.get(this.PULL_API, {
      headers: headers
    }).map(res => {
      const json = res.json() as any;
      return json;
    });
  }

  public pullRegion(country) {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', '354901b3-91ae-5a82-808c-9d1ea4fca53f');
    return this.http.get(this.PULL_API + '?offset=1&page_lim=5000&country=' + country, {
      headers: headers
    }).map(res => {
      const json = res.json() as any;
      return json;
    });
  }

  public pullCommune(region) {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', '354901b3-91ae-5a82-808c-9d1ea4fca53f');
    return this.http.get(this.PULL_API + '?offset=1&page_lim=5000&region=' + region, {
      headers: headers
    }).map(res => {
      const json = res.json() as any;
      return json;
    });
  }

  public pullPostalCode(commune) {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', '354901b3-91ae-5a82-808c-9d1ea4fca53f');
    return this.http.get(this.PULL_API + '?offset=1&page_lim=5000&commune=' + commune, {
      headers: headers
    }).map(res => {
      const json = res.json() as any;
      return json;
    });
  }

  public pullStreet(postalCode) {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', '354901b3-91ae-5a82-808c-9d1ea4fca53f');
    return this.http.get(this.PULL_API + '?offset=1&page_lim=5000&postalcode=' + postalCode, {
      headers: headers
    }).map(res => {
      const json = res.json() as any;
      return json;
    });
  }

  public pullAdrn(postalCode, street) {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', '354901b3-91ae-5a82-808c-9d1ea4fca53f');
    return this.http.get(this.PULL_API + '?offset=1&page_lim=5000&postalcode=' + postalCode + '&street=' + street, {
      headers: headers
    }).map(res => {
      const json = res.json() as any;
      return json;
    });
  }

  public pullAdptId(postalCode, street, adrn) {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', '354901b3-91ae-5a82-808c-9d1ea4fca53f');
    return this.http.get(this.PULL_API + '?offset=1&page_lim=5000&postalcode=' + postalCode + '&street=' + street + '&adrn=' + adrn, {
      headers: headers
    }).map(res => {
      const json = res.json() as any;
      return json;
    });
  }

  public pullAdptIdDetails(adptid) {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', '354901b3-91ae-5a82-808c-9d1ea4fca53f');
    return this.http.get(this.PULL_API + '?adptid=' + adptid, {
      headers: headers
    }).map(res => {
      const json = res.json() as any;
      return json;
    });
  }

  public Pull(url, reqParams) {
    const headers = new Headers();
    headers.append('Authorization', '8e7282bc-84c6-5ca1-82e2-bca693170c0b');
    return this.http.get(`${this.PRESIGNED_URL}${url}?${UTILS.getRequestParams(reqParams)}`, { headers: headers }).map(res => res.json());
  }

  public Post1(url) {
    const headers = new Headers();
    this.setHeaders(headers,environment.Pull_Access_Key,'');
    return this.http.post(url, '', {
      headers: headers, withCredentials: true
    }).map(res => {
      const json = res.json() as any;
      return json;
    });
  }
}
