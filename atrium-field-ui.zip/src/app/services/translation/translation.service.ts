// core imports
import { Injectable } from '@angular/core';

// 3rd party imports
import swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';

// app imports
import { AlertOptions } from '@app/interfaces/interface';

@Injectable()
export class TranslationService {

  constructor(public translate: TranslateService) { }

  getLanguageValue(key) {
    return this.translate.get(key).map(res => {
      return res;
    });
  }
  translateAndPop(sweetAlertOptions) {
    return swal({
      title: sweetAlertOptions.title,
      text: sweetAlertOptions.text,
      type: sweetAlertOptions.type,
      allowOutsideClick: sweetAlertOptions.outsideClick,
      showCancelButton: sweetAlertOptions.showCancelBtn,
      confirmButtonText: sweetAlertOptions.confirmBtnText,
      cancelButtonText: sweetAlertOptions.cancelBtnText
    });
  }
  public changeLanguage(preferredLanguage) {
    let lang;
    if (preferredLanguage === 3) lang = 'en';
    if (preferredLanguage === 2) lang = 'nl';
    if (preferredLanguage === 1) lang = 'fr';
    this.translate.setDefaultLang(lang);
    this.translate.reloadLang(lang);
  }

  public setLanguagePreff(lang: string) { this.translate.use(lang); }

  translateMessageObject(sweetAlertObj: AlertOptions, cb) {
    let responseObject = sweetAlertObj;
    if (sweetAlertObj.title !== '') {
      this.getLanguageValue(sweetAlertObj.title).subscribe((title) => {
        responseObject.title = title;
        if (sweetAlertObj.text !== '') {
          this.getLanguageValue(sweetAlertObj.text).subscribe((text) => {
            responseObject.text = text;
            if (sweetAlertObj.confirmBtnText !== '') {
              this.getLanguageValue(sweetAlertObj.confirmBtnText).subscribe((confirmBtnText) => {
                responseObject.confirmBtnText = confirmBtnText;
                if (sweetAlertObj.cancelBtnText !== '') {
                  this.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
                    responseObject.cancelBtnText = cancelBtnText;
                    cb(responseObject);
                  });
                } else {
                  cb(responseObject);
                }
              });
            } else if (sweetAlertObj.cancelBtnText !== '') {
              this.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
                responseObject.cancelBtnText = cancelBtnText;
                cb(responseObject);
              });
            } else {
              cb(responseObject);
            }
          });
        } else if (sweetAlertObj.confirmBtnText !== '') {
          this.getLanguageValue(sweetAlertObj.confirmBtnText).subscribe((confirmBtnText) => {
            responseObject.confirmBtnText = confirmBtnText;
            if (sweetAlertObj.cancelBtnText !== '') {
              this.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
                responseObject.cancelBtnText = cancelBtnText;
                cb(responseObject);
              });
            } else {
              cb(responseObject);
            }
          });
        } else if (sweetAlertObj.cancelBtnText !== '') {
          this.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
            responseObject.cancelBtnText = cancelBtnText;
            cb(responseObject);
          });
        } else {
          cb(responseObject);
        }
      });
    } else if (sweetAlertObj.text !== '') {
      this.getLanguageValue(sweetAlertObj.text).subscribe((text) => {
        responseObject.text = text;
        if (sweetAlertObj.confirmBtnText !== '') {
          this.getLanguageValue(sweetAlertObj.confirmBtnText).subscribe((confirmBtnText) => {
            responseObject.confirmBtnText = confirmBtnText;
            if (sweetAlertObj.cancelBtnText !== '') {
              this.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
                responseObject.cancelBtnText = cancelBtnText;
                cb(responseObject);
              });
            } else {
              cb(responseObject);
            }
          });
        } else if (sweetAlertObj.cancelBtnText !== '') {
          this.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
            responseObject.cancelBtnText = cancelBtnText;
            cb(responseObject);
          });
        } else {
          cb(responseObject);
        }
      });
    } else if (sweetAlertObj.confirmBtnText !== '') {
      this.getLanguageValue(sweetAlertObj.confirmBtnText).subscribe((confirmBtnText) => {
        responseObject.confirmBtnText = confirmBtnText;
        if (sweetAlertObj.cancelBtnText !== '') {
          this.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
            responseObject.cancelBtnText = cancelBtnText;
            cb(responseObject);
          });
        } else {
          cb(responseObject);
        }
      });
    } else if (sweetAlertObj.cancelBtnText !== '') {
      this.getLanguageValue(sweetAlertObj.cancelBtnText).subscribe((cancelBtnText) => {
        responseObject.cancelBtnText = cancelBtnText;
      });
    } else {
      cb(responseObject);
    }
  }
}