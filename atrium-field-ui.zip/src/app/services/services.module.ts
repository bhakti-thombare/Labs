// core imports
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// app imports
import { ApiService } from '@app/services/apiServices/api.service';
import { GlobalUtility } from '@app/services/global-utility.service';
import { AuthGaurdService } from '@app/services/auth-guard/auth-gaurd.service';
import { AuthGuard2Service } from '@app/services/auth-guard2/auth-guard2.service';
import { CampaignSummaryService } from '@app/services/campaign-summary/campaign-summary.service';
import { EventService } from '@app/services/events/event.service';
import { FormGuardService } from '@app/services/form-guard/form-guard.service';
import { HttpService } from '@app/services/http-service';
import { InitialsService } from '@app/services/initials/initials.service';
import { SetCampaignDataService } from '@app/services/set-campaign-data/set-campaign-data.service';
import { SupervisorAuthGuardService } from '@app/services/supervisor-auth-guard/supervisor-auth-guard.service';
import { FieldAgentGuardService } from '@app/services/field-agent-guard/field-agent-guard.service';
import { TranslationService } from '@app/services/translation/translation.service';
import { LastSyncService } from '@app/services/pipe/last-sync.service';

@NgModule({
  imports: [
    CommonModule
  ],
  providers: [
    ApiService,
    AuthGaurdService,
    AuthGuard2Service,
    CampaignSummaryService,
    EventService,
    FormGuardService,
    HttpService,
    InitialsService,
    SetCampaignDataService,
    SupervisorAuthGuardService,
    FieldAgentGuardService,
    TranslationService,
    LastSyncService, GlobalUtility
  ],
})
export class ServicesModule { }
