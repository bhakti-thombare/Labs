import { Injectable, EventEmitter } from "@angular/core";
import { BehaviorSubject } from "rxjs/BehaviorSubject";

@Injectable()
export class EventService {
  private defaultMessage = { eventName: "default", data: "default message" };
  private messageSource = new BehaviorSubject(this.defaultMessage);
  currentMessage = this.messageSource.asObservable();

  public validationEditPOSEvent: EventEmitter<any> = new EventEmitter<any>();

  broadcast(message) {
    this.messageSource.next(message);
  }
  showLoader(data) {
    this.broadcast({ eventName: "showLoader", data: data });
  }
  hideLoader(data) {
    this.broadcast({ eventName: "hideLoader", data: data });
  }
}
