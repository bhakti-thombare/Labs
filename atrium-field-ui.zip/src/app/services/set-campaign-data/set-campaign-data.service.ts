// core imports
import { Injectable, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';

// 3rd party imports
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';

// app imports
import { HttpService } from '@app/services/http-service';

@Injectable()
export class SetCampaignDataService {
  _emitter = new EventEmitter();

  user;
  constructor(private http: HttpService, private router: Router) { }

  getCampaignData() {
    this.user = JSON.parse(localStorage.getItem('user-data'));
    this.http.SecureGet('/campaign/getCampaignOverview').subscribe(res => {
      console.log(res.data);
      let completePercentage;
      let completedDegrees;
      if (Math.round(parseInt(res.data.completePercentage, 10)) !== 0) {
        completePercentage = Math.round(parseInt(res.data.completePercentage, 10));
        completedDegrees = Math.round(completePercentage * 3.6);
      } else {
        completePercentage = Math.round(parseInt(res.data.unassignedPercentage, 10));
        completedDegrees = Math.round(completePercentage * 3.6);
      }
      let inProgressPercentage;
      let inProgressDegrees;
      if (Math.round(parseInt(res.data.inProgressPercentage, 10)) !== 0) {
        inProgressPercentage = Math.round(parseInt(res.data.inProgressPercentage, 10));
        inProgressDegrees = Math.round(inProgressPercentage * 3.6);
      } else {
        inProgressPercentage = Math.round(parseInt(res.data.unassignedPercentage, 10));
        inProgressDegrees = Math.round(inProgressPercentage * 3.6);
      }
      let pendingCampaignPercentage;
      let pendingCampaignDegrees;
      if (Math.round(parseInt(res.data.pendingCampaignPercentage, 10)) !== 0) {
        pendingCampaignPercentage = Math.round(parseInt(res.data.pendingCampaignPercentage, 10));
        pendingCampaignDegrees = Math.round(pendingCampaignPercentage * 3.6);
      } else {
        pendingCampaignPercentage = Math.round(parseInt(res.data.unassignedPercentage, 10));
        pendingCampaignDegrees = Math.round(pendingCampaignPercentage * 3.6);
      }
      if ((completedDegrees + inProgressDegrees + pendingCampaignDegrees) !== 360) {
        const remainingDegrees = 360 - (completedDegrees + inProgressDegrees + pendingCampaignDegrees);
        pendingCampaignDegrees = pendingCampaignDegrees + remainingDegrees;
      }
      if ((completePercentage + inProgressPercentage + pendingCampaignPercentage) !== 100) {
        const remainingPercentage = 100 - (completePercentage + inProgressPercentage + pendingCampaignPercentage);
        pendingCampaignPercentage = pendingCampaignPercentage + remainingPercentage;
      }
      let rightComplete;
      let leftComplete;
      let rightInProgress;
      let leftInProgress;
      let rightPending;
      let leftPending;
      if (completedDegrees > 180) {
        rightComplete = 180;
        leftComplete = completedDegrees - 180;
        sessionStorage.setItem('rightComplete', rightComplete);
        sessionStorage.setItem('leftComplete', leftComplete);
      } else {
        rightComplete = completedDegrees;
        leftComplete = 0;
        sessionStorage.setItem('rightComplete', rightComplete);
        sessionStorage.setItem('leftComplete', leftComplete);
      }
      if (inProgressDegrees > 180) {
        rightInProgress = 180;
        leftInProgress = inProgressDegrees - 180;
        sessionStorage.setItem('rightInProgress', rightInProgress);
        sessionStorage.setItem('leftInProgress', leftInProgress);
      } else {
        rightInProgress = inProgressDegrees;
        leftInProgress = 0;
        sessionStorage.setItem('rightInProgress', rightInProgress);
        sessionStorage.setItem('leftInProgress', leftInProgress);
      }
      if (pendingCampaignDegrees > 180) {
        rightPending = 180;
        leftPending = pendingCampaignDegrees - 180;
        sessionStorage.setItem('rightPending', rightPending);
        sessionStorage.setItem('leftPending', leftPending);
      } else {
        rightPending = pendingCampaignDegrees;
        leftPending = 0;
        sessionStorage.setItem('rightPending', rightPending);
        sessionStorage.setItem('leftPending', leftPending);
      }
      const setObjInLS = {
        percentages: {
          complete: completePercentage,
          inProgress: inProgressPercentage,
          pending: pendingCampaignPercentage
        },
        degrees: {
          complete: {
            right: rightComplete,
            left: leftComplete
          },
          inProgress: {
            right: rightInProgress,
            left: leftInProgress
          },
          pending: {
            right: rightPending,
            left: leftPending
          }
        }
      };
      sessionStorage.setItem('percentageWithDegrees', JSON.stringify(setObjInLS));

      if (this.user.roleId === 2) {
        setTimeout(() => {
          this.router.navigate(['/supervisor']);
        }, 200);
      } else {
        setTimeout(() => {
          this.router.navigate(['/admin']);
        }, 200);
      }
      return this._emitter.asObservable();
    }, err => {

      let completePercentage;
      let completedDegrees;

      completePercentage = 0;
      completedDegrees = 0;

      let inProgressPercentage;
      let inProgressDegrees;

      inProgressPercentage = 0;
      inProgressDegrees = 0;

      let pendingCampaignPercentage;
      let pendingCampaignDegrees;

      pendingCampaignPercentage = 0;
      pendingCampaignDegrees = 0;


      pendingCampaignDegrees = 0;


      pendingCampaignPercentage = 0;

      let rightComplete;
      let leftComplete;
      let rightInProgress;
      let leftInProgress;
      let rightPending;
      let leftPending;

      rightComplete = completedDegrees;
      leftComplete = 0;
      sessionStorage.setItem('rightComplete', rightComplete);
      sessionStorage.setItem('leftComplete', leftComplete);


      rightInProgress = inProgressDegrees;
      leftInProgress = 0;
      sessionStorage.setItem('rightInProgress', rightInProgress);
      sessionStorage.setItem('leftInProgress', leftInProgress);

      rightPending = pendingCampaignDegrees;
      leftPending = 0;
      sessionStorage.setItem('rightPending', rightPending);
      sessionStorage.setItem('leftPending', leftPending);

      const setObjInLS = {
        percentages: {
          complete: completePercentage,
          inProgress: inProgressPercentage,
          pending: pendingCampaignPercentage
        },
        degrees: {
          complete: {
            right: rightComplete,
            left: leftComplete
          },
          inProgress: {
            right: rightInProgress,
            left: leftInProgress
          },
          pending: {
            right: rightPending,
            left: leftPending
          }
        }
      };
      sessionStorage.setItem('percentageWithDegrees', JSON.stringify(setObjInLS));

      if (this.user.roleId === 2) {
        setTimeout(() => {
          this.router.navigate(['/supervisor']);
        }, 200);
      } else {
        setTimeout(() => {
          this.router.navigate(['/admin']);
        }, 200);
      }
      return this._emitter.asObservable();
    });
  }

}
