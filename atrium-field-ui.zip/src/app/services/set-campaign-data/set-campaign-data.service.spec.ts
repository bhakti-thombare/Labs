import { TestBed, inject } from '@angular/core/testing';

import { SetCampaignDataService } from './set-campaign-data.service';

describe('SetCampaignDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SetCampaignDataService]
    });
  });

  it('should be created', inject([SetCampaignDataService], (service: SetCampaignDataService) => {
    expect(service).toBeTruthy();
  }));
});
