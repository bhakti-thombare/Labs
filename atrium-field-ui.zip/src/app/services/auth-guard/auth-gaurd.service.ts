import { Injectable } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable()
export class AuthGaurdService {

  constructor(private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {

    let user = JSON.parse(localStorage.getItem('user-data'));
    let sessionObj = JSON.parse(sessionStorage.getItem('percentageWithDegrees'));
    if (user) {
      if (user.roleId === 2) {
        if (user.resetProfile && user.isActive) {
          if (state.url == '/admin/profile') {
            return true;
          } else {
            this.router.navigate(['/login']);
            return false;
          }
        } else if (!user.resetProfile && user.isActive) {
          this.router.navigate(['/supervisor']);
        }
      } else if (user.roleId === 3) {
        if (user.resetProfile && user.isActive) {
          if (state.url === '/fieldagent/profile') {
            return true;
          } else {
            this.router.navigate(['/login']);
            return false;
          }
        } else if (!user.resetProfile && user.isActive) {
          this.router.navigate(['/fieldagent']);
        }
      } else if (user && sessionObj) {
        return true;
      } else if (user) {
        if (user.resetProfile && user.isActive) {
          if (state.url == '/admin/profile') {
            return true;
          } else {
            this.router.navigate(['/login']);
            return false;
          }
        } else if (!user.resetProfile && user.isActive) {
          return true;
        }
      }
    } else {
      this.router.navigate(['/login']);
    }
  }
}
