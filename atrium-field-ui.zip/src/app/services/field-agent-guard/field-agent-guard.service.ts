import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';

@Injectable()
export class FieldAgentGuardService {

  constructor(private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const user = JSON.parse(localStorage.getItem('user-data'));
    if (user && user.roleId === 3) {
      if (user.resetProfile && user.isActive) {
        if (state.url === '/fieldagent/profile') {
          return true;
        } else {
          this.router.navigate(['/login']);
          return false;
        }
      } else if (!user.resetProfile && user.isActive) {
        return true;
      }
      return true;
    }
  }
}

