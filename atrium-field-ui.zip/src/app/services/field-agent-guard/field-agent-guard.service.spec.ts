import { TestBed, inject } from '@angular/core/testing';

import { FieldAgentGuardService } from './field-agent-guard.service';

describe('FieldAgentGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FieldAgentGuardService]
    });
  });

  it('should be created', inject([FieldAgentGuardService], (service: FieldAgentGuardService) => {
    expect(service).toBeTruthy();
  }));
});
