export interface UnassignedUsersPos {
    startDate: string;
    endDate: string;
    shift: number;
    iterations: number;
    missionId: number;
}
export interface POSUserAvailability {
    startDate: string;
    endDate: string;
    userId: number;
    missionId: number;
}

export interface GetRefMissions {
    missionType : Array<number>,
    classic : boolean,
    market : boolean,
    prm : boolean,
    visits : boolean,
    agent : Array<number>,
    shift : Array<number>,
    missionStatus :  Array<number>,
    missionStartDate : string,
    missionEndDate : string,
    checkpoint:boolean;
}
export interface MapQuartier {
    mission: number;
    quartier: number;
    user: number;
    creationDate: string;
    updatedOn: string;
}

export interface AssignFA2POS {
    userId: number;
    missionId: number;
    campaignId: number;
    status: number;
    createdBy: number;
    updatedBy: number;
    creationDate: string;
    lastUpdatedOn: string;
    missionDates: Array<string>;
    shift:number;
    assignMission : boolean;
}

export interface UpdateMission {
    missionId: number,
    missionUpdatedById: number,
    subType: number,
    updateMission:Number
}

export interface UpdateMission {
    missionId: number;
    missionName: string;
    missionDescription: string;
    missionTypeId: number;
    missionCreationDate: string;
    missionStartDate: string;
    missionEndDate: string;
    missionCampaignId: number;
    missionStatusId: number;
    missionCreatedById: number;
    missionUpdatedById: number;
    missionEstimatedTime: number;
    missionIsArchived: boolean;
    missionCircuits: Array<any>;
    missionNumberOfCircuits: number;
    missionCircuitsToAdd: number;
    missionNumberOfCheckpoints: number;
    missionCheckpointsToAdd: number;
    missionZonesToAdd: number;
    subType: number;
    missionSubSection:1

}
export interface Assignments {
    assignmentId: number;
    userId: number;
    campaignId: number;
    missionId: number;
    circuitId: number;
    checkpointId: number;
    shiftId: number;
    startDate: string;
    endDate: string;
    iterations: number;
    status: number;
    createdBy: number;
    updatedBy: number;
    creationDate: string;
    lastUpdatedOn: string;
    zone: number;
}

export class MapPOS {
    id: number = null;
    name: string = null;
    latitude: string = null;
    longitude: string = null;
    adptId: number = null;
    shopType: number = null;
    chainCode: string = null;
    quartierName: string = null;
    quartier: string = null;
    vPosSk: number = null;
    posId: number = null;
    posOpenedByAtrium: string = null;
    posOpeningDate: string = null;
    posClosingDate: string = null;
    posLockProvider: string = null;
    posDateProvider: string = null;
    posNameProvider: string = null;
    posSurfaceId: number = null;
    posStatus: number = null;
    posCategory: number = null;
    posProducts: number = null;
    posNameFr: string = null;
    posNameNl: string = null;
    posNameEn: string = null;
    posChainNameFr: string = null;
    posChainNameNl: string = null;
    posChainNameEn: string = null;
    posDescriptionFr: string = null;
    posDescriptionNl: string = null;
    posDescriptionEn: string = null;
    posTaglineFr: string = null;
    posTaglineNl: string = null;
    posTaglineEn: string = null;
    posHistoryFr: string = null;
    posHistoryNl: string = null;
    posHistoryEn: string = null;
    posEmailPrimary: string = null;
    posEmailEecondary: string = null;
    posWebsitePrimary: string = null;
    posWebsiteSecondary: string = null;
    posPhone: string = null;
    posMobile: string = null;
    posFax: string = null;
    posCategory1: number = null;
    posCategory2: number = null;
    posCategory3: number = null;
    posType1: number = null;
    posType2: number = null;
    posType3: number = null;
    posPicMain: string = null;
    posPicLogo: string = null;
    posPicGallery: string = null;
    posVideo: string = null;
    posRating: string = null;
    posPrice: string = null;
    posCusine: string = null;
    posAcceptsReservation: string = null;
    posReservationLink: string = null;
    posOpeningsMondayShift1: string = null;
    posOpeningsTuesdayShift1: string = null;
    posOpeningsWednesdayShift1: string = null;
    posOpeningsThursdayShift1: string = null;
    posOpeningsFridayShift1: string = null;
    posOpeningsSaturdayShift1: string = null;
    posOpeningsSundayShift1: string = null;
    posOpeningsMondayShift2: string = null;
    posClosingsTuesdayShift2: string = null;
    posClosingsWednesdayShift2: string = null;
    posClosingsThursdayShift2: string = null;
    posClosingsFridayShift2: string = null;
    posClosingsSaturdayShift2: string = null;
    posClosingsSundayShift2: string = null;
    posHolidays: string = null;
    vInsertedBy: string = null;
    vEffectiveFrom: string = null;
    vEffectiveTo: string = null;
    vMasterJobInstanceId: number = null;
    vActiveFlag: string = null;
    posLatitude: string = null;
    posLongitude: string = null;
    posLatitudeWgs84: string = null;
    posLongitudeWgs84: string = null;
    isArchived: number = null;
    mergedWith: number = null;
    dividedFrom: number = null;
    organic: number = null;
    vegan: number = null;
    hallal: number = null;
    fairTrade: number = null;
    circularEconomy: number = null;
    popUp: number = null;
    conceptStore: number = null;
    secondHand: number = null;
    discount: number = null;
    antiquarian: number = null;
    onSite: number = null;
    toGo: number = null;
    atm: number = null;
    showRoom: number = null;
    craft: number = null;
    days7: number = null;
    hours24: number = null;
    appointment: number = null;
    previousPosId: number = null;
    nextPosId: number = null;
    creationDate: string = null;
    lastUpdate: string = null;
    posType4: number = null;
    days77: number = null;
    featureId: number = null;
    
    
    nameVisible: string = null;
    numberVisible: string = null;
    buildingState: string = null;
    storefrontState: string = null;
    localState: string = null;
    division: string = null;
    sur_shop_surface: string = null;
    pos_main_entry_floor: string = null;
    pos_num_floor: string = null;
    
    parkingPresence: string = null;
    parkingSize: string = null;
    parkingPMR: string = null;
    slopeNone: string = null;
    slopeStreetDir: string = null;
    slopeFacadeDir: string = null;
    sidewalkState: string = null;
    sidewalkWidth: string = null;
    sidewalkNarrow: string = null;
    sidewalkConstr: string = null;
    sidewalkElement: string = null;
    
    
    pos_days_77: string = null;
    pos_hours_2424: string = null;
    pos_mon_fri_shift_1: string = null;
    pos_mon_fri_break: string = null;
    pos_mon_fri_appointment: string = null;
    pos_sat_shift_1: string = null;
    pos_sat_break: string = null;
    pos_sat_appointment: string = null;
    pos_sun_shift_1: string = null;
    pos_sun_break: string = null;
    pos_sun_appointment: string = null;
    pos_d2d_mon_shift_1: string = null;
    pos_d2d_mon_break: string = null;
    pos_d2d_mon_appointment: string = null;
    pos_d2d_tue_shift_1: string = null;
    pos_d2d_tue_break: string = null;
    pos_d2d_tue_appointment: string = null;
    pos_d2d_wed_shift_1: string = null;
    pos_d2d_wed_break: string = null;
    pos_d2d_wed_appointment: string = null;
    pos_d2d_thu_shift_1: string = null;
    pos_d2d_thu_break: string = null;
    pos_d2d_thu_appointment: string = null;
    pos_d2d_fri_shift_1: string = null;
    pos_d2d_fri_break: string = null;
    pos_d2d_fri_appointment: string = null;
    pos_d2d_sat_shift_1: string = null;
    pos_d2d_sat_break: string = null;
    pos_d2d_sat_appointment: string = null;
    pos_d2d_sun_shift_1: string = null;
    pos_d2d_sun_break: string = null;
    pos_d2d_sun_appointment: string = null;
    pos_d2d_mon_no_working: string = null;
    pos_d2d_tue_no_working: string = null;
    pos_d2d_wedno_working: string = null;
    pos_d2d_thu_no_working: string = null;
    pos_d2d_fri_no_working: string = null;
    pos_d2d_sat_no_working: string = null;
    pos_d2d_sun_no_working: string = null;
    pos_mon_fri_no_working: string = null;
    pos_sat_no_working: string = null;
    pos_sun_no_working: string = null;
    
    accessCustom: string = null;
    entranceStreet: string = null;
    entranceState: string = null;
    entranceSlope: string = null;
    entranceDoor: string = null;
    entranceWidth: string = null;
    
    counterVisible: string = null;
    counterHeight: string = null;
    alleysWidth: string = null;
    alleysGround: string = null;
    alleysHeight: string = null;
    restArea: string = null;
    
    floorsPresence: string = null;
    floorsStairs: string = null;
    floorsEscalator: string = null;
    floorsElevator: string = null;
    floorsRamp: string = null;
    floorsOther: string = null;
    restroomPresence: string = null;
    restroomGround: string = null;
    restroomEscalator: string = null;
    restroomElevator: string = null;
    restroomRamp: string = null;
    restroomOther: string = null;
    restroomSink: string = null;
    
    socialFacebook: string = null;
    socialInstagram: string = null;
    socialYoutube: string = null;
    socialTwitter: string = null;
    socialLinkedin: string = null;
    socialOther: string = null;
    socialNo: string = null;
    socialNotDisclose: string = null;
    phoneNumber: string = null;
    phoneNo: string = null;
    phoneNotDisclose: string = null;
    mailAdress: string = null;
    mailNo: string = null;
    mailNotDisclose: string = null;
    websiteAdress: string = null;
    websiteNo: string = null;
    websiteNotDisclose: string = null;
    contactOk: string = null;
    contactSex: string = null;
    contactFirstName: string = null;
    contactLastName: string = null;
    
    paymentCash: string = null;
    paymentBankcard: string = null;
    paymentCreditcard: string = null;
    paymentSmartphone: string = null;
    paymentGiftvouchers: string = null;
    paymentMealvouchers: string = null;
    paymentLocalCurrency: string = null;
    paymentOther: string = null;
    paymentNotDisclose: string = null;
    sellOnline: string = null;
    sellDelivery: string = null;
    surfCustomSize: string = null;
    surfCustomNotRelevant: string = null;
    surfCustomNotDisclose: string = null;
    surfTotalSize: string = null;
    surfTotalNo: string = null;
    surfTotalNotDisclose: string = null;
    surfStock: string = null;
    surfStockSize: string = null;
    surfStockGround: string = null;
    surfStockBasement: string = null;
    surfStockUpstairs: string = null;
    surfStockOtherLocal: string = null;
    
    histSameLocal: string = null;
    yearOpen: string = null;
    yearOpenNotDisclose: string = null;
    yearCreation: string = null;
    yearCreationNotDisclose: string = null;
    occupancy: string = null;
    businessType: string = null;
    shopAssociation: string = null;
    
    isShopOpen: string = null;
    isOwnerAvailable: string = null;
    lastMissionTypeClassic: string = null;
    lastMissionTypePrm: string = null;
    lastMissionTypeVisit: string = null;
    lastClassicMissionDate: string = null;
    lastPrmMissionDate: string = null;
    lastVisitMissionDate: string = null;
    isComplete: string = null;
}

export interface MapCheckpoints {
    id: number;
    xCordinate: string;
    yCordinate: string;
    pnNameFr: string;
    pnNameDu: string;
    pnNameEn: string;
    muNatCod: number;
    muNameFr: string;
    muNameDu: string;
    muNameEn: string;
    mdrc: number;
    nameFr: string;
    nod: string;
    nodNom: string;
    baroNom: string;
    checkpointFlag: number;
    insertedBy: string;
    creationDate: string;
    lastUpdatedOn: string;
}