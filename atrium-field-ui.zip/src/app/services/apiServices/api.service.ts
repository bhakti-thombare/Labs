import { Injectable } from '@angular/core';

// app imports
import { HttpService } from '@app/services/http-service';
import { UTILS } from '@app/services/global-utility.service';
import { UnassignedUsersPos, MapQuartier, AssignFA2POS, UpdateMission, MapPOS, MapCheckpoints, POSUserAvailability, GetRefMissions } from "@app/services/apiServices/reqBodies";
import { APICONSTANTS } from '@app/constants/api-constants';

@Injectable()
export class ApiService {

  constructor(public http: HttpService) { }

  /* User API's */
  updateUser(profile) { return this.http.SecurePost(`${APICONSTANTS.USER.USER_KEY}${APICONSTANTS.USER.UPDATE_USER}`, profile); }
  login(loginData) { return this.http.Post(`${APICONSTANTS.USER.USER_KEY}${APICONSTANTS.USER.LOGIN}`, loginData); }
  /* User API's */

  /* Mission API's */
  getUserMissionDetails(reqParams: any) { return this.http.SecureGet(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.GET_USER_MISSION_DETAILS}?${UTILS.getRequestParams(reqParams)}`); }
  editMission(obj: any, reqParams: any) { return this.http.SecurePost(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.EDIT_MISSION}?${UTILS.getRequestParams(reqParams)}`, obj); }
  assignCustomerSurvey(req) { return this.http.SecurePost(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.ASSIGN_MISSION}`, req); }
  changeMissionDate(req) { return this.http.SecurePost(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.CHANGE_MISSION_DATE}`, req); }
  addMission(req, reqParams: any) { return this.http.SecurePost(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.ADD_MISSION}?${UTILS.getRequestParams(reqParams)}`, req); }
  updateMission(req, reqParams: any) { return this.http.SecurePost(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.UPDATE_MISSION}?${UTILS.getRequestParams(reqParams)}`, req); }
  /* Mission API's */

  /* Ref API's */
  getCheckpointWithAdptid(adptid, cb) { this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_CHECKPOINTS}?adptId=` + adptid).subscribe(res => { cb(200, res); }, err => { cb(400, err); }); }
  getLanguages(id?: string) { return this.http.SecureGet(id ? `${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_REF_LANGUAGE}?id=` + id : `${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_REF_LANGUAGE}`); }
  getRoles(id?: string) { return this.http.SecureGet(id ? `${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_ROLES}?roleId=` + id : `${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_ROLES}`); }
  getMissions(id?) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_MISSIONS}` + id ? '?id=' + id : ''); }
  getMissionsCreatedBy(userId) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_MISSIONS}?createdBy=` + userId); }
  getMissionTypes() { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_REF_MISSION_TYPE}`); }
  getShiftWiseUsedMissionDates(currentDate, missionType,shift) {console.log("hello",shift);
   return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_MISSION_DATES}?currentDate=` + currentDate + '&missionType=' + missionType + '&shift=' + shift); }

  getUsedMissionDates(currentDate, missionType) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_MISSION_DATES}?currentDate=` + currentDate + '&missionType=' + missionType); }
  getUsedMissionDatesObject(reqParams) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_MISSION_DATES}?` + UTILS.getRequestParams(reqParams)); }
  getMissionsCreatedByOfMissionType(user, id) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_MISSIONS}?createdBy=` + user + '&missionType=' + id); }
  getAllMissions(reqParams: any) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_MISSIONS}?` + UTILS.getRequestParams(reqParams)); }
  getLocations(reqParams: any) { return this.http.SecureGet(`${APICONSTANTS.LOCATION.GET_LOCATIONS}?` + UTILS.getRequestParams(reqParams)); }
  getLocationDetails(reqParams: any) { return this.http.SecureGet(`${APICONSTANTS.LOCATION.GET_LOCATIONS}${APICONSTANTS.LOCATION.GET_DETAILS}?` + UTILS.getRequestParams(reqParams)); }
  getLocationType(reqParams: any) { return this.http.SecureGet(`${APICONSTANTS.LOCATION.GET_LOCATIONS_TYPE}?` + UTILS.getRequestParams(reqParams)); }
  getAllCampaigns(reqParams: any) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_CAMPAIGNS}?` + UTILS.getRequestParams(reqParams)); }
 
  getMarketZone(userId)
  {
    return this.http.SecureGet(`${APICONSTANTS.REF.GET_MARKET_ZONE}`);
  }

  getMissionName(name){
    return this.http.SecureGet(`${APICONSTANTS.REF.GET_MISSION_NAME}?missionName=` +name); 
  }

  getUnavailableDate(id) {
    return this.http.SecureGet(`${APICONSTANTS.REF.GET_UNAVAILABLE_DATE}?agent=` +id);
  }

  
  getUserCampaigns(userId) { 
    
    return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_CAMPAIGNS}?assignedTo=` + userId); }
  getAllCircuitsWithCheckpoints(bool: boolean) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_CIRCUITS}?withCheckpoints=` + bool); }
  getUnassignedUsers(reqObj) { return this.http.SecurePost(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_UNASSIGNED_USERS}`, reqObj); }
  getAllUnassignedUsersPos(reqObj: UnassignedUsersPos) { return this.http.SecurePost(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_UNASSIGNED_USERS_POS}`, reqObj); }
  getZones() { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_ZONES}`); }
  getAllZones(reqParams) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_ZONES}?` + UTILS.getRequestParams(reqParams)); }
  getAllUsers(reqParams) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_USERS}?` + UTILS.getRequestParams(reqParams)); }
  getMissionsByCampaignId(reqParams) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_MISSIONS_BY_CAMPAIGN_ID}?` + UTILS.getRequestParams(reqParams)); }
  getZone(id) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_ZONES}?id=` + id); }
  getAllQuartiers(reqParams) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_QUARTIERS}?` + UTILS.getRequestParams(reqParams)); }
  getAllPosMissions(reqParams: any) { return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_ALL_POS_MISSIONS}?${UTILS.getRequestParams(reqParams)}`); }
  checkPosUserAvailability(reqObj: POSUserAvailability) { return this.http.SecurePost(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.CHECK_POS_USER_AVAILABILITY}`, reqObj); }
  deleteLocation(reqParams: any) { return this.http.SecureDelete(`${APICONSTANTS.LOCATION.GET_LOCATIONS}?` + UTILS.getRequestParams(reqParams)); }
  deleteMission(reqParams: any) { return this.http.SecureDelete(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.DELETE_MISSION}?` + UTILS.getRequestParams(reqParams)); }
  getAgents(reqParams: any) {return this.http.SecureGet(`${APICONSTANTS.REF.GET_ALL_AGENTS}?`); }
  getCalendarInfo(reqParams: any) {return this.http.SecureGet(`${APICONSTANTS.REF.GET_CALENDAR_INFO}?` + UTILS.getRequestParams(reqParams));  }
  getUnavailableUser(reqParams: any) {return this.http.SecureGet(`${APICONSTANTS.REF.GET_UNAVAILABLE_USER}?` + UTILS.getRequestParams(reqParams));  }  
  postUnavailableUser(reqObj: any) { return this.http.SecurePost(`${APICONSTANTS.REF.GET_UNAVAILABLE_USER}`, reqObj); }
  deleteUnavailableUser(reqObj: any) { return this.http.SecurePost(`${APICONSTANTS.REF.REMOVE_UNAVAILABLE_USER}` , reqObj); }
  /* Ref API's */

  /* Circuit API's */
  addCircuit(data: FormData, reqUrl: any) { return this.http.securePostByMulitpart(`${APICONSTANTS.CIRCUIT.CIRCUIT_KEY}${APICONSTANTS.CIRCUIT.ADD_CIRCUIT}`, data); }
  /* Circuit API's */
 
  /* Market API's */
  addMarket(req) { return this.http.SecurePost(`${APICONSTANTS.MARKET.MARKET_KEY}${APICONSTANTS.MARKET.ADD_MARKET}`, req); }
  missionMarketMapping(req) { return this.http.SecurePost(`${APICONSTANTS.MARKET.MARKET_KEY}${APICONSTANTS.MARKET.ADD_MARKET}`, req); }
 /* MArket API's */

  /* Zone API's */
  missionZoneMapping(req) { return this.http.SecurePost(`${APICONSTANTS.ZONE.ZONE_KEY}${APICONSTANTS.ZONE.ADD_ZONE}`, req); }
  createZone(req) { return this.http.SecurePost(`${APICONSTANTS.ZONE.ZONE_KEY}${APICONSTANTS.ZONE.ADD_ZONE}`, req); }
  /* Zone API's */

  /* MissionLists API Starts */
  getMissionProgressReport(reqParams) {
    return this.http.SecureGet(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.MISSION_PROGRESS_REPORT}?${UTILS.getRequestParams(reqParams)}`);
  }
  /* MissionLists API Ends*/

  getSurveyMissionProgressReport(reqParams) {
    return this.http.SecureGet(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.SURVEY_MISSION_PROGRESS_REPORT}?${UTILS.getRequestParams(reqParams)}`);
  }
  getstandsMissionMpd(reqParams){
    return this.http.SecureGet(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.STANDS_MISSION_MPD}?${UTILS.getRequestParams(reqParams)}`);

  }
  getUserSurveyReport(reqParams) {
    return this.http.SecureGet(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.USER_SURVEY_REPORT}?${UTILS.getRequestParams(reqParams)}`);
  }
  getstandsMissionInfo(reqParams){
    return this.http.SecureGet(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.STAND_MISSION_INFO}?${UTILS.getRequestParams(reqParams)}`);

  }
  updateUserSurvey(reqParams, data) {
    return this.http.SecurePost(`${APICONSTANTS.SURVEY.SURVEY_KEY}${APICONSTANTS.SURVEY.UPDATE_USER_SURVEY}?${UTILS.getRequestParams(reqParams)}`, data);
  }
  getRefMissions(reqParams, data: GetRefMissions) {
     return this.http.SecurePost(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_MISSIONS}?${UTILS.getRequestParams(reqParams)}`,data);  
  }
  approveMission(reqParams, data) {
    return this.http.SecurePost(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.APPROVE_MISSION}?${UTILS.getRequestParams(reqParams)}`, data);
  }
  reAssignMission(reqParams, data) {
    return this.http.SecurePost(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.REASSIGN_MISSION}?${UTILS.getRequestParams(reqParams)}`, data);
  }
  /* MPD Customer Survey */

  posMpdCards(missionId: number) {
    return this.http.SecureGet(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.GET_POS_MPD_CARDS}?missionId=${missionId}`)
  }

  getPosMpd(missionId: number) {
    return this.http.SecureGet(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.GET_POS_MPD}?missionId=${missionId}`)
  }

  getInfoSheet(missionDetails) {
    console.log("missiondetails=",missionDetails);
    
    return this.http.SecureGet(`${APICONSTANTS.MISSION.GET_INFOSHEET}?missionId=${missionDetails.missionId}&quartierId=${missionDetails.quartierId}&posId=${missionDetails.posId}&id=${missionDetails.id}`)
  }

  getPosCheckpoints(missionId: number, quartierId: number, missionDuration: any) {
    return this.http.SecureGet(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.GET_POS_CHECKPOINTS}?missionId=${missionId}&quartierId=${quartierId}&missionDuration=${missionDuration}`);
  }

  updatePosCheckpointStatus(reqObj){
    return this.http.SecurePost(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.UPDATE_POS_CHECKPOINT_STATUS}`, reqObj);
  }

  approvePOSMission(reqObj) {
    return this.http.SecurePost(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.APPROVE_POS_MISSION}`, reqObj)
  }

  reAssignPosMission(reqObj) {
    return this.http.SecurePost(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.RE_ASSIGN_POS_MISSION}`, reqObj)
  }

  getPosRejectedCount(missionId: number) {
    return this.http.SecureGet(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.REJECTED_POS}?missionId=${missionId}`)
  }
  approveRejectInfoSheet(reqObj) {
    return this.http.SecurePost(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.UPDATED_POS_STATUS}`, reqObj);
  }

  getReassignMissionDetails(id){
    return this.http.SecureGet(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.REASSIGN}?missionId=${id}`);

  }

  getReassignCSMissionDetails(id){
    return this.http.SecureGet(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.POS.REASSIGN}?missionId=${id}`);

  }

  postReassignDetails(reqObj,id){
    return this.http.SecurePost(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.REASSIGN}?missionId=${id}`, reqObj).timeout(30000);

  }
  postCSReassignDetails(reqObj,id){
    return this.http.SecurePost(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.POS.REASSIGN}`, reqObj);

  }
  posEvaluate(reqObj){
    return this.http.SecurePut(`${APICONSTANTS.MISSION.MISSION_KEY}${APICONSTANTS.MISSION.EVALUATE}`, reqObj);

  }




  /* POS/POI */
  getQuartierCordinates(reqParams: any) { return this.http.SecureGet(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.GET_COORDINATES}?${UTILS.getRequestParams(reqParams)}`); }
  mapQuartier(reqParams, data: MapQuartier) {
    return this.http.SecurePost(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.MAP_QUARTIER}?${UTILS.getRequestParams(reqParams)}`, data);
  }
  mapPOS(reqParams, data: { quartierName: string, quartier: number, missionId: number, posDtos: Array<MapPOS> }) {
    return this.http.SecurePost(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.MAP_POS}?${UTILS.getRequestParams(reqParams)}`, data);
  }
  mapPosCheckpoints(reqParams, data: { missionId: number, dtos: Array<MapCheckpoints> }) {
    return this.http.SecurePost(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.MAP_POS_CHECKPOINTS}?${UTILS.getRequestParams(reqParams)}`, data);
  }
  assignPosMission(reqParams, data: AssignFA2POS) {
    return this.http.SecurePost(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.ASSIGN_POS_MISSION}?${UTILS.getRequestParams(reqParams)}`, data);
  }
  getPosEditMissionPage(reqParams) {
    return this.http.SecureGet(`${APICONSTANTS.POS.POS_KEY}${APICONSTANTS.POS.GET_POS_EDIT_MISSION_PAGE}?${UTILS.getRequestParams(reqParams)}`);
  }



  /**
   * getPedestrianMissions service
   * @returns
   * @memberof ApiService
   */
  getPedestrianMissions() {
    return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_PEDESTRIAN_MISSIONS}?withCircuits=false`)
  }


  /**
   * @returns
   * @memberof ApiService
   */
  getPedestrianCircuits() {
    return this.http.SecureGet(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.REF.GET_PEDESTRIAN_CIRCUITS}?withCheckpoints=false`)
  }

  /* POS/POI Ends */

  ipadApi(env: string) {
    return this.http.SecureGet1(`${APICONSTANTS.REF.REF_KEY}${APICONSTANTS.IPAD.GET_URL}?env=${env}`)
  }

  /* Atrium Analytics API's */
  getQuartiers(reqParams: any) {
    return this.http.Pull(
      APICONSTANTS.GET_POS_DETAILS_BY_QUARTIER,
          { "adt_quartier_ibsa": reqParams.quartierId });
  }
  /* Atrium Analytics API's */
}
