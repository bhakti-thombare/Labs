import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()
export class AuthGuard2Service {

  constructor(private router: Router) { }

  canActivate() {
    const user = localStorage.getItem('user-data');
    const sessionObj = sessionStorage.getItem('percentageWithDegrees');
    if (user && sessionObj) {
      if(JSON.parse(sessionStorage.getItem('role')) == 2){
        this.router.navigate(['/supervisor']);
        return false
      } else if (JSON.parse(sessionStorage.getItem('role')) == 1){
        this.router.navigate(['/admin/dashboard']);
      } else{
        return false;
      }
    } else if (user) {
      const jUser = JSON.parse(user);
      if (jUser.roleId === 3) {
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }
}
