// core imports
import { AssignFA2POS } from '@app/services/apiServices/reqBodies';
import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';

// 3rd party imports
import  { each, extend, contains } from "underscore";
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';

// app imports
import { UpdateMission } from '@app/services/apiServices/reqBodies';

declare var google: any;
@Injectable()
export class GlobalUtility {

  constructor() { }
  getDateFormat(d: any) { console.log('Inside constant', d); return `${d.year}-${(d.month < 10) ? '0' + d.month : d.month}-${(d.day < 10) ? '0' + d.day : d.day}`; }
}

export const UTILS = {
  getShiftMocks: () => {
    return [{ shiftName: 'Morning', timeRange: '10:00 - 12:30', startTime: '10:00', endTime: '12:30' }, { shiftName: 'Morning', timeRange: '12:30 - 14:30', startTime: '12:30', endTime: '14:30' }, { shiftName: 'Afternoon', timeRange: '14:30 - 16:30', startTime: '14:30', endTime: '16:30' }, { shiftName: 'Afternoon', timeRange: '16:30 - 19:00', startTime: '16:30', endTime: '19:00' },];
  },
  getRequestParams: (data) => {
    let urlParams = new URLSearchParams();
    each(data, (value, key, list) => {
      urlParams.append(key, value);
    });
    let reqParams = urlParams.toString();
    return reqParams;
  },
  getDatePickerDateFormat: (date: any) => {
    let d = new Date(date);
    return { "year": d.getFullYear(), "month": d.getMonth() + 1, "day": d.getDate() };
  },
  getDatePickerIntFormat: (date: NgbDate) => {
    return { "year": date.year.toString(), "month": `${(date.month < 10) ? '0' + date.month : date.month}`, "day": `${(date.day < 10) ? '0' + date.day : date.day}` };
  },
  extendKey: (obj, newObj) => {
    return extend(obj, newObj);
  },
  isNameExistList: (list, value) => {
    return contains(list, value);
  },
  getNumStr: (num: number) => { return (num < 10) ? '0' + num : num; },
  isMatch: (minDate, d1, endDate) => {
    let isValidMinDate = new Date(`${minDate.year}-${(minDate.month < 10) ? '0' + minDate.month : minDate.month}-${(minDate.day < 10) ? '0' + minDate.day : minDate.day} 00:00:00`);
    let isLTSelectedDate = new Date(`${d1.year}-${(d1.month < 10) ? '0' + d1.month : d1.month}-${(d1.day < 10) ? '0' + d1.day : d1.day} 00:00:00`);
    let isValidEndDate = new Date(endDate);
    return (isValidEndDate >= isLTSelectedDate && isLTSelectedDate >= isValidMinDate);
  },
  minDate: { day: new Date().getDate(), month: new Date().getMonth() + 1, year: new Date().getFullYear() },
  minDateReassign: () => {
    let result = new Date(new Date());
    result.setDate(result.getDate() + 7);
    return { day: result.getDate(), month: result.getMonth() + 1, year: result.getFullYear() };
  },
  maxDate: { day: new Date().getDate(), month: new Date().getMonth() + 1, year: new Date().getFullYear() },
  getDate_: (d: any) => { return (d) ? new Date(d.replace(/\s/g, "T")) : new Date(d); },
  getDateFormat: (d: any) => { return `${d.year}-${(d.month < 10) ? '0' + d.month : d.month}-${(d.day < 10) ? '0' + d.day : d.day} 00:00:00`; },
  getDateFormatWithoutZero: (d: any) => { return `${d.year}-${(d.month < 10) ? '0' + d.month : d.month}-${(d.day < 10) ? '0' + d.day : d.day}`; },
  getDateTimeFormat: (d: any) => { return `${d.year}-${(d.month < 10) ? '0' + d.month : d.month}-${(d.day < 10) ? '0' + d.day : d.day} 00:00:00`; },
  getDateFormatWithTime: (d: Date) => {
    return `${d.getFullYear()}-${UTILS.getNumStr(d.getMonth() + 1)}-${UTILS.getNumStr(d.getDate())} ${UTILS.getNumStr(d.getHours())}:${UTILS.getNumStr(d.getMinutes())}:${UTILS.getNumStr(d.getSeconds())}`;
  },
  getDateFormatWithoutTime: (d: Date) => {
    return `${d.getFullYear()}-${UTILS.getNumStr(d.getMonth() + 1)}-${UTILS.getNumStr(d.getDate())}`;
  },
  getDaysByDate(date1: Date, date2: Date) {
    var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
    var firstDate = date1;
    var secondDate = date2;
    var diffDays = Math.round(Math.abs((firstDate.getTime() - secondDate.getTime()) / (oneDay))) + 1;
    return diffDays;
  },
  async getDatesArrayByDates(date1: Date, date2: Date) {
    // const days = UTILS.getDaysByDate(date1, date2);
    let currentDate = date1;
    const dateArray: Array<any> = [];
    let length = 0;
    while (currentDate <= date2) {
      if (currentDate.getDay() == 0 || currentDate.getDay() == 6) length++;//remove this line after CR comes
      // if (currentDate.getDay() != 0 && currentDate.getDay() != 6)
      /* 
      This is future CR, only uncomment the above line of code and remove the comments.
      This is to make agents availables on weekends for pedestraing flow even though he is assigned to pos mission already.
      */

      dateArray.push(UTILS.getDateFormatWithoutTime(currentDate));
      currentDate.setDate(currentDate.getDate() + 1);
      if (currentDate > date2) {
        length = dateArray.length - length;
        return { dateArray, length };
      }
    }
  },
  getUpdateMissionBody() {
    return <UpdateMission>{
      missionId: null,
      missionName: null,
      missionDescription: null,
      missionTypeId: null,
      missionCreationDate: null,
      missionStartDate: null,
      missionEndDate: null,
      missionCampaignId: null,
      missionStatusId: null,
      missionCreatedById: null,
      missionUpdatedById: null,
      missionEstimatedTime: null,
      missionIsArchived: null,
      missionCircuits: null,
      missionNumberOfCircuits: null,
      missionCircuitsToAdd: null,
      missionNumberOfCheckpoints: null,
      missionCheckpointsToAdd: null,
      missionZonesToAdd: null,
      subType: null,
    }
  },
  getAssignmentsInitialization() {
    return <AssignFA2POS>{
      userId: null,
      missionId: null,
      campaignId: null,
      status: null,
      createdBy: null,
      updatedBy: null,
      creationDate: null,
      lastUpdatedOn: null,
      missionDates: null
    }
  },
  toCamelCase(str) {
    return str.split(' ').map(function (word, index) {
      // If it is the first word make sure to lowercase all the chars.
      if (index == 0) { return word.toLowerCase(); }
      // If it is not the first word only upper case the first char and lowercase the rest.
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    }).join('');
  },
  decamelize(str, separator) {
    separator = typeof separator === 'undefined' ? '_' : separator;
    return str
      .replace(/([a-z\d])([A-Z])/g, '$1' + separator + '$2')
      .replace(/([A-Z]+)([A-Z][a-z\d]+)/g, '$1' + separator + '$2')
      .toLowerCase();
  },
  isWeekEnd(date: Date) {
    const day = date.getDay();
    const isWeekend = (day != 0 && day != 6);
    return isWeekend;
  }
}