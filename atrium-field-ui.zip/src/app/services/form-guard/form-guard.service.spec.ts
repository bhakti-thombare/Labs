import { TestBed, inject } from '@angular/core/testing';

import { FormGuardService } from './form-guard.service';

describe('FormGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FormGuardService]
    });
  });

  it('should be created', inject([FormGuardService], (service: FormGuardService) => {
    expect(service).toBeTruthy();
  }));
});
