import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
@Injectable()
export class FormGuardService {

  constructor(private router: Router) { }

  canDeactivate(){
    let user = JSON.parse(localStorage.getItem('user-data'));
    if(user){
      if (!user.resetProfile && user.isActive) {
        return true;
      } else {
        return false;
      }
    }else{
      this.router.navigate(['/login']);
    }
  }

}
