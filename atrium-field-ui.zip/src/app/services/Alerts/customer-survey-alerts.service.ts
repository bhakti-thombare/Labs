import { TranslateService } from '@ngx-translate/core';
import { Injectable } from '@angular/core';
import swal from "sweetalert2";
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';
@Injectable()
export class CustomerSurveyAlertsService {

  constructor(public translate: TranslateService) { }

  zoneWithSameNameExistAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ZONE_WITH_THE_SAME_NAME_ALREADY_PRESENT),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DO_YOU_WANT_TO_USE_THE_EXISTING_ZONE) + '?',
      type: 'error', allowOutsideClick: false,
      confirmButtonClass: 'confirmBtnSwal', cancelButtonClass: 'confirmBtnSwal',
      cancelButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_CANCEL),
      confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_USE_EXISTING_ZONE),
      showCancelButton: true,
    });
  }
  campainIsAboutExpireAlert() { return swal({ title: `${this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CAMPAIGN_ABOUT_TO_EXPIRE)}`, text: `${this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_CONTACT_ADMIN)}`, type: "warning", allowOutsideClick: false, showCancelButton: false, confirmButtonText: this.translate.instant('Ok') }); }
  campainIsExpireAlert() { return swal({ title: `${this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CAMPAIGN_EXPIRED)}`, text: `${this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_CONTACT_ADMIN)}`, type: "warning", allowOutsideClick: false, showCancelButton: false, confirmButtonText: this.translate.instant('Ok') }); }
  doYouWantReassign() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DO_YOU_WANT_TO_REASSIGN_MISSION), text: '', type: 'warning', showCancelButton: true, confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_REASSIGN), cancelButtonText: this.translate.instant('No, cancel!') }); }
  missionDeatailsUpdateSuccessAlert() { return swal({ title: '', text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.MISSION_DETAILS_UPDATED_SUCCESSFULLY), type: "success" }) }
  somethingWentWrongAlert() { return swal({ title: this.translate.instant("Error !"), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.SOMETHING_WENT_WRONG), type: "error" }) }
  somethingWentWrongWhileUpdateAlert() { return swal({ title: this.translate.instant("Error !"), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.SOMETHING_WENT_WRONG_WHILE_UPDATING_MISSION), type: "error" }) }
  noAgentFound() { return swal({ title: this.translate.instant('No Field agents available'), text: this.translate.instant('Please change the mission date or  ask admin to add more field agents.'), type: "error" }) }
}
