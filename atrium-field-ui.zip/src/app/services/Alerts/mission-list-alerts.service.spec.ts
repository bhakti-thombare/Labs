import { TestBed, inject } from '@angular/core/testing';

import { MissionListAlertsService } from './mission-list-alerts.service';

describe('MissionListAlertsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MissionListAlertsService]
    });
  });

  it('should be created', inject([MissionListAlertsService], (service: MissionListAlertsService) => {
    expect(service).toBeTruthy();
  }));
});
