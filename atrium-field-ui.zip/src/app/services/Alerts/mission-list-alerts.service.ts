import { TranslateService } from '@ngx-translate/core';
import { Injectable } from '@angular/core';
import swal from 'sweetalert2';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

@Injectable()
export class MissionListAlertsService {

  constructor(public translate: TranslateService) { }

  /* Mission Lists Alerts */
  noRecordSyncedAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_REPORTS_GENERATED),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DATA_NOT_YET_SYNCED_FOR_THIS_MISSION),
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('Ok'),
      allowOutsideClick: true,
      showCancelButton: false
    });
  }

  noReportsGenerateAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_REPORTS_GENERATED),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DATA_NOT_YET_SYNCED_FOR_THIS_MISSION),
      type: 'warning', cancelButtonText: '',
      confirmButtonText: this.translate.instant('Ok'),
      allowOutsideClick: true, showCancelButton: false
    })
  }

  approveMpdAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.APPROVED_MPD_SUCCESSFULLY),
      type: 'success', cancelButtonText: '',
      allowOutsideClick: true, showCancelButton: false
    })
  }
  evaluateMpd() {
    return swal({
      title: this.translate.instant('Mission evaluated successfully'),
      type: 'success', cancelButtonText: '',
      allowOutsideClick: true, showCancelButton: false
    })
  }
  reassignMission() {
    return swal({
      title: this.translate.instant('Mission reassigned successfully'),
      type: 'success', cancelButtonText: '',
      allowOutsideClick: true, showCancelButton: false
    })
  }
  reassignMissionTimeout(){
    return swal({
      title: this.translate.instant('Reassign will take some time. Press OK and you will be redirected to Missions page. The reassigned mission will be available in less then 30 min.'),
      type: 'success', cancelButtonText: '',
      allowOutsideClick: false, showCancelButton: false
    })
  }
  campainIsExpireAlert() { return swal({ title: `${this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CAMPAIGN_EXPIRED)}`, text: `${this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CAMPAIGN_EXPIRED_TITLE)}`, type: "warning", allowOutsideClick: false, showCancelButton: false, confirmButtonText: this.translate.instant('Ok') }); }
  /* Mission Lists Alerts */
}
