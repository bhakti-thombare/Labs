import { TestBed, inject } from '@angular/core/testing';

import { PedestrainAlertsService } from './pedestrain-alerts.service';

describe('PedestrainAlertsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PedestrainAlertsService]
    });
  });

  it('should be created', inject([PedestrainAlertsService], (service: PedestrainAlertsService) => {
    expect(service).toBeTruthy();
  }));
});
