import { TranslateService } from '@ngx-translate/core';
import { Injectable } from '@angular/core';

// 3rd party imports
import swal from "sweetalert2";
import{ without, map} from "underscore";
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';
@Injectable()
export class PedestrainAlertsService {
  constructor(public translate: TranslateService) { }
  fileSizeShouldNotMT20MB() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.FILE_SIZE_SHOULD_NOT_BE_MORE_THAN_20MB), text: '', type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: true, showCancelButton: false }); }
  fileExtensionAlert() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.FILE_SHOULD_BE_JPG_JPEG_PNG_EXTENTION), text: '', type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: true, showCancelButton: false }); }
  campaignExpiredAlert() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CAMPAIGN_EXPIRED) + '.', text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_CONTACT_ADMIN_FOR_MORE_CAMPAIGNS) + '.', type: 'warning', allowOutsideClick: true, showCancelButton: false, confirmButtonText: this.translate.instant('OK'), cancelButtonText: '' }); }
  agentsNotFree() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_FIELDS_AGENT_FREE_MISSION_START_DATE), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ASK_ADMIN_TO_ADD_FIELDS_AGENT), type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  circuitAlreadyexistWithSameName() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CIRCUIT_ALREADY_EXISTS_WITH_NAME), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DO_YOU_WANT_TO_USE_THE_EXISTING_CIRCUIT), type: 'warning', cancelButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_CANCEL) + '!', confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_USE_IT), allowOutsideClick: false, showCancelButton: true }); }
  circuitAlreadyexistWithSame() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CIRCUIT_ALREADY_EXISTS_WITH_NAME),type: 'warning', allowOutsideClick: false, showCancelButton: true }); }
  nosubordinateCheckpoints() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CIRCUIT_DOES_NOT_HAVE_SUBORDINATE_CHECKPOINTS), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CHANGE_NAME_OF_CIRCUIT_IF_LOCATION_INTACT), type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  googleGeocoderError() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.GOOGLE_GEOCODING_ERROR), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DAILY_LIMIT_FOR_TODAY_REACHED_FOR_SEARCHING_LOCATION), type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: true, showCancelButton: false }); }
  removeOtherCheckpoints() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.OTHER_CHECKPOINTS_WILL_BE_REMOVED), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.FEATURE_NEEDS_TO_BE_KEPT_COMMON_AMONGST_CHECKPOINTS), type: 'warning', cancelButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_CANCEL) + '!', confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_REMOVE_OTHERS) + '!', allowOutsideClick: false, showCancelButton: false }); }
  toggleMission() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.SELECTED_PEDESTRIAN_SURVEY_MISSION), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_NOTE + MESSAGECONSTANTS.ALERT_MESSAGES.NOT_ABLE_TO_CREATE_CIRCUITS_MORE_THAN_ONE), type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_REMOVE_IT) + '!', allowOutsideClick: false, showCancelButton: true }); }
  addCircuitMissionAlert(missionName) { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ADD_CIRCUITS_TO + missionName + MESSAGECONSTANTS.ALERT_MESSAGES.CREATING_CHECKPOINTS_IN_THEM) + '.', text: '', type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  checkPointsMoreThan3() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.SELECTED_PEDESTRIAN_SURVEY_MISSION), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_NOTE + MESSAGECONSTANTS.ALERT_MESSAGES.SELECT_MISSION_NOT_BE_ABLE + MESSAGECONSTANTS.ALERT_MESSAGES.CHECKPOINTS_MORE_THAN_THREE_WILL_BE_REMOVED) + '.', type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_REMOVE_IT) + '!', allowOutsideClick: false, showCancelButton: true }); }
  alreadyFieldAgentsusedAssignment() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.FIELD_AGENT_USED_IN_ASSIGNMENT), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_ANOTHER_FIELD_AGENT), type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  missionCreatedSuccessAlert() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.MISSION_CREATED_SUCCESSFULLY), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_CREATE_CIRCUIT_FOR_THIS_MISSION), type: 'success', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  selectCampagin() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_CAMPAIGN), type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant('Ok'), allowOutsideClick: false, showCancelButton: false }); }  
  missionCreatedSuccessPOSAlert() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.MISSION_CREATED_SUCCESSFULLY), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_QUARTIER_FOR_MISSION), type: 'success', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  circuitCreatedSuccessAlert() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CIRCUIT_CREATED_SUCCESSFULLY), text: '', type: 'success', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  quartierAssignSuccessAlert() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.QUARTIER_ASSIGNED_SUCCESSFULLY), text: '', type: 'success', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  somethingWentWrong() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.SOMETHING_WENT_WRONG), text: '', type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  somethingWentWrongQuestion() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.SOMETHING_WENT_WRONG), text: '', type: 'question', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  checkPointsSuccessAlert() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CHECKPOINTS_CREATED_SUCCESSFULLY), text: '', type: 'success', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  assignmentSuccessAlert() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ASSIGNMENT_COMPLETED_SUCCESSFULLY), text: '', type: 'success', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  assignmentWaringAlert() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.SOMETHING_WENT_WRONG), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.SOMETHING_WENT_WRONG_OR_MORE_ASSIGNMENTS_NOT_SUCCESSFULLY_CREATED), type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: false, showCancelButton: false }); }
  postCodeNotAvailableAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.POSTAL_CODE_NOT_AVAILABLE),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_OTHER_OPTION),
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  streetsNotAvailableAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.STREETS_NOT_AVAILABLE),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_OTHER_OPTION),
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  adrnNotAvailableAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ADRN_NOT_AVAILABLE),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_OTHER_OPTION),
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  adptidsAlreadyExist() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ADPTIDS_ALREADY_PRESENT_IN_EXISTING_CIRCUIT),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DO_YOU_WANT_TO_USE_SAME_CIRCUIT) + '?',
      type: 'warning',
      cancelButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_I_WILL_CHANGE_IT) + '!',
      confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_USE_THE_EXISTING_CIRCUIT) + '!',
      allowOutsideClick: false,
      showCancelButton: true
    });
  }
  editCircuitAdptidsInAlreadyExist() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ADPTIDS_ALREADY_PRESENT_IN_EXISTING_CIRCUIT),
      type: 'warning',
      showConfirmButton:false,
      cancelButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_I_WILL_CHANGE_IT) + '!',
      allowOutsideClick: false,
      showCancelButton: true
    });
  }
  circuitMappedSuccessAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CIRCUIT_MAPPED_SUCCESSFULLY) + '!',
      text: '',
      type: 'success',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  sameCheckPointsNotAllowedAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_NOT_ABLE_TO_USE_SAME_CHECKPOINT),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_CHANGE_ADPTID_OF_CHECKPOINT) + '?',
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  adptidNotAvailable() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ADPTID_NOT_AVAILABLE),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_OTHER_OPTION),
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  datesMandatoryAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ALL_DATES_ARE_MANDATORY),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CHECKPOINTS_CANNOT_BE_ADDED_WITHOUT_CIRCUIT),
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  pleaseAddCircuitWarningAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ADD_CIRCUITS),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CHECKPOINTS_CANNOT_BE_ADDED_WITHOUT_CIRCUIT),
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  dateMandatoryAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DATE_MISSION_FIELDS_MANDATORY),
      text: '',
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  sameShiftCanNotAssigned() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.SAME_SHIFT_CANNOT_BE_ASSIGNED),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_ANOTHER_SHIFT),
      type: 'error',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  sameShiftIteration() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CANNOT_ASSIGN_SHIFT_TIMING_WITH_SAME_ITERATION_COUNT),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SELECT_ANOTHER_SHIFT),
      type: 'error',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  uniqueApdtId() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ENTER_VALID_ADPTID),
      text: '',
      type: 'warning',
      allowOutsideClick: true,
      cancelButtonText: '',
      showCancelButton: false,
      confirmButtonText: this.translate.instant('Ok')
    });
  }
  warningAlert(errorMessage) {
    return swal({
      title: '',
      text: '',
      html: this.splitAndAddBr(errorMessage),
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: true,
      showCancelButton: false
    });
  }
  splitAndAddBr(message) {
    let valArray = without(message.split('</br>'), "");
    return map(valArray, (i) => { return this.translate.instant(i) }).join('</br>');
  }
  needMoreCheckPoints() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NEED_MORE_CHECKPOINTS),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ADD_MORE_CHECKPOINTS),
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  combinationAlreadyAdptId() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.COMBINATION_ADPTIDS_ALREADY_EXISTS_WITH_CIRCUIT),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_CHANGE_AN_ADPTID_TO_CONTINUE),
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  conditionBeforeSubmit(message) {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_CHECK_THESE_CONDITIONS_B4_SUBMITTING),
      text: '',
      html: this.splitAndAddBr(message),
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant('OK'),
      allowOutsideClick: false,
      showCancelButton: false
    });
  }
  removeCircuitAlert() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ARE_YOU_SURE_U_WANT_TO_REMOVE_THIS_CIRCUIT) + '?',
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YOU_CANNOT_RETRIEVE_THIS_CIRCUIT_ONCE_DELETED),
      type: 'warning',
      cancelButtonText: '',
      confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_REMOVE_IT) + '!',
      allowOutsideClick: false,
      showCancelButton: true
    });
  }
  removeCheckPoints() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ARE_U_SURE_U_WANT_TO_REMOVE_THIS_CHECKPOINT) + '?',
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YOU_CANNOT_RETRIEVE_THIS_CHECKPOINT_ONCE_DELETED),
      type: 'warning',
      cancelButtonText: this.translate.instant('Cancel'),
      confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_REMOVE_IT) + '!',
      allowOutsideClick: false,
      showCancelButton: true
    });
  }
  changingDateRemoveAssignments() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CHANGING_MISSION_DATE_WILL_REMOVE_ALL_ASSIGNMENTS) + ".",
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ARE_YOU_SURE_TO_CHANGE_MISSION_DATE) + "?",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_CHANGE_IT) + '!',
      cancelButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_CANCEL),
      allowOutsideClick: false
    });
  }
  changeExistingCirtcuitandRemoveCheckpoints() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CHANGING_EXISTING_CIRCUIT_REMOVE_ALL_CHECKPOINTS_UNDER),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DO_YOU_WANT_TO_CHANGE_IT) + '?',
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_CHANGE_IT) + '!',
      cancelButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_CANCEL) + '!'
    });
  }
  circuitExistWithSameName(search) {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CIRCUIT_ALREADY_EXISTS_WITH_NAME + search),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DO_YOU_WANT_TO_USE_THE_EXISTING_CIRCUIT) + "?",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_USE_IT) + '!',
      cancelButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_CANCEL) + '!'
    });
  }
  removeCheckPointsAssociatedwithCircuit() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DO_YOU_WANT_TO_REMOVE_CHECKPOINTS_ASSOCIATED_WITH_THE_CIRCUIT) + '?',
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ONCE_REMOVED_YOU_WILL_NOT_BE_ABLE_TO_RECOVER_THEM_AGAIN) + '.',
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_REMOVE_THEM) + '!',
      cancelButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_CHANGE_CIRCUIT_ONLY) + '!'
    });
  }
  checkPontDeleteAlert() {
    return swal(this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CHECKPOINTS_DELETED_SUCCESSFULLY) + '.', '', 'success');
  }
  doChangeCircuit() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DO_YOU_WISH_TO_CHANGE_THE_CIRCUIT_TOO) + '?',
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CIRCUITS_GETS_CHANGED_CHECKPOINTS_WILL_REMOVED_AND_YOU_WILL_HAVE_TO_RESTRAIN_THE_CHECKPOINTS_AGAIN) + '.',
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_CHANGE_CIRCUIT) + '!',
      cancelButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_CHANGE_CHECKPOINTS_ONLY) + '!'
    });
  }
  googleDailylimitAlert() {
    return swal(this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.GOOGLE_GEOCODING_ERROR), this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.TODAYS_DAILY_LIMIT_REACHED_FOR_SEARCHING_A_LOCATION), 'warning');
  }
  inCaseChangesDeleted() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YOU_CHANGE_THIS_THE_DATA_WILL_BE_DELETED) + '.',
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_CONFIRM) + '.',
      allowOutsideClick: false,
      showCancelButton: true,
      confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_I_WILL_CHANGE_IT) + '.'
    });
  }
  dateMoreThanTodayAlert() {
    return swal(this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CHANGE_THE_MISSION_DATE) + 
            '.', this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.IT_SHOULD_BE_MORE_THAN_TODAY) + '.', 'warning');
  }
  noCircuits() {
    return swal(this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_CIRCUITS), this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ADD_CIRCUITS), 'warning');
  }
  searchMapImage(circuitMessages) {
    return swal(this.translate.instant(circuitMessages), this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_CHECK_IF_LOCATION_SEARCHED_fROM_MAP_AS_WELL_as_IMAGE_IS_ADDED) + '.', 'warning');
  }
  addMoreCheckpointAlert() {
    return swal(this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.MORE_CHECKPOINTS_NEEDED), this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ADD_CHECKPOINTS), 'warning');
  }
  checkPointUnique(checkpointMessages) {
    return swal(this.translate.instant(checkpointMessages), this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ADPTID_REQUIRED_PLEASE_CHECK_CHECKPOINT_NAME_IS_UNIQUE) + '.', 'warning');
  }
  searchLocationImage(checkpointMessages) {
    swal(this.translate.instant(checkpointMessages), this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_SEARCH_LOCATION_AT_CHECKPOINT_IN_MAP_AS_WELL) + '.', 'warning');
  }
  allFieldsMandatory() {
    return swal(this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.ALL_FIELDS_MANDATORY_IN_MISSION_FORM) + '.', '', 'warning');
  }
  doYouWantContinue(title) {
    return swal({
      title: this.translate.instant(title),
      text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.DO_YOU_WANT_TO_CONTINUE) + '.',
      type: 'warning',
      allowOutsideClick: false,
      showCancelButton: true,
      confirmButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.YES_DELETE_IT) + '!',
      cancelButtonText: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.NO_CANCEL) + '!',
    });
  }
  thanksAlert() {
    return swal(this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.THANK_YOU), this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CHECKPOINT_NOT_LOST), 'success');
  }
  missionUpdateSuccess() {
    return swal(this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.MISSION_UDPATED_SUCCESSFULLY), '', 'success');
  }
  locationUpdateSuccess() {
    return swal(this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.LOCATION_UDPATED_SUCCESSFULLY), '', 'success');
  }

  circuitMapSuccess() {
    return swal({
      title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.CIRCUITS_MAPPED_SUCCESSFULLY) + '!',
      type: 'success',
      allowOutsideClick: false
    });
  }

  /**ISSUE 920 */
  enterValidLocation() { return swal({ title: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.INVALID_LOCATION), text: this.translate.instant(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_ENTER_VALID_LOCATION), type: 'warning', cancelButtonText: '', confirmButtonText: this.translate.instant('OK'), allowOutsideClick: true, showCancelButton: false }); 
  }

}
