import { TestBed, inject } from '@angular/core/testing';

import { CustomerSurveyAlertsService } from './customer-survey-alerts.service';

describe('CustomerSurveyAlertsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CustomerSurveyAlertsService]
    });
  });

  it('should be created', inject([CustomerSurveyAlertsService], (service: CustomerSurveyAlertsService) => {
    expect(service).toBeTruthy();
  }));
});
