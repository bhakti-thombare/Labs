import { Injectable } from '@angular/core';
import { DataConstants } from '@app/constants/constants';
@Injectable()
export class LastSyncService {

  constructor() { }

  calculateLocalDateString(dateStr: string) {
    const date = dateStr.split(' ')[0];
    const time = dateStr.split(' ')[1];
    const day = parseInt(date.split('-')[2], 10);
    const month = parseInt(date.split('-')[1], 10);
    const year = parseInt(date.split('-')[0], 10);
    let hour = parseInt(time.split(':')[0], 10);
    const minute = parseInt(time.split(':')[1], 10);
    const second = parseInt(time.split(':')[2], 10);
    let pm = false;
    const localDateString = new Date(Date.UTC(year, month - 1, day, hour, minute, second));
    const monthNames = DataConstants.MONTHS;
    pm = localDateString.getHours() >= 12 ? true : false;
    let hours = localDateString.getHours() % 12;
    hours = hours ? hours : 12;
    const amPM = pm ? 'PM' : 'AM';
    return localDateString.getDate() + ' ' + monthNames[localDateString.getMonth()] + ' ' +
      localDateString.getFullYear() + ', ' + hours + ':' + localDateString.getMinutes() + ' ' + amPM;
  }

}
