import { TestBed, inject } from '@angular/core/testing';

import { LastSyncService } from './last-sync.service';

describe('LastSyncService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LastSyncService]
    });
  });

  it('should be created', inject([LastSyncService], (service: LastSyncService) => {
    expect(service).toBeTruthy();
  }));
});
