// core
import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

import { TranslateService } from '@ngx-translate/core';
import { StorageService } from './services/storage-service.service';

declare var google: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'app';

  /* Constructor:-
    1. Sets the default language as 'en'.
    2. Validates if sessionstorage includes the data and current route is destined to go to login page we force route the application to admin dashboard.
    3. If (2) does not hold true then another validation checks if the user resetprofile is true.
    4. If (3) holds true then we force route the application to respective profile page.
  */
  constructor(public location: Location, public router: Router, private translate: TranslateService, private storageService: StorageService) {

    translate.setDefaultLang('en');
    const user = JSON.parse(localStorage.getItem('user-data'));
    if (sessionStorage.getItem('percentageWithDegrees') && this.location.path() === '/login') {
      this.router.navigate(['/admin/dashboard']);
    } else if (user) {
      if (user.roleId === 3) {
        if (user.isActive && user.resetProfile) {
          this.router.navigate(['/fieldagent/profile']);
        } else if (user.isActive && !user.resetProfile) {
          this.router.navigate(['/fieldagent/dashboard']);
        }
      }
      this.getUserID();
    }
  }

  getUserID() {
    let userID = JSON.parse(this.storageService.getData('user-data'));
    this.storageService.setData('userId', userID.userId);
  }
  /* switchLanguage:-
    1. Global language switcher. Currently not used anywhere in the application
  */
  switchLanguage(language: string) {
    this.translate.use(language);
  }

  /* fetchurl:-
    1. Global route watcher. Currently not used anywhere in the application
  */
  fetchurl() {
    // console.log("router.url", this.router.url)
  }


  lat: number = 51.678418;
  lng: number = 7.809007;

  getAddress($event) {
    console.log($event)
    this.lat = $event.coords.lat;
    this.lng = $event.coords.lng;

    let api = new google.maps.Geocoder;
    api.geocode({ latLng: { lat: this.lat, lng: this.lng } },
      res => {
        console.log(res);
      });
  }
}
