// core
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

// 3rd party
import swal from 'sweetalert2';

// app
import { HttpService } from '@app/services/http-service';
import { MESSAGECONSTANTS } from '@app/constants/constant-messages';

@Component({
  selector: 'app-verification-message',
  templateUrl: './verification-message.component.html',
  styleUrls: ['./verification-message.component.css']
})
export class VerificationMessageComponent implements OnInit {

  private successMessage = 'loading';
  private disableSubmit = false;
  private successTitle = 'Welcome User!';
  private password = {};
  private myForm: FormGroup = new FormGroup({
    password: new FormControl('', [Validators.required, Validators.pattern('^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$')]),
    repeatPassword: new FormControl('', Validators.required)
  });
  private showButton = false;
  private email = '';
  private showPasswordFields = false;
  constructor(private http: HttpService, private route: ActivatedRoute, private router: Router) {
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.http.Post('/user/verifyRegistrationCode', { verificationCode: params.id }).subscribe(res => {
        this.successMessage = 'Verification completed successfully!!!!!';
        this.email = res.email;
        this.showButton = true;
        this.showPasswordFields = true;
      }, err => {
        this.successMessage = 'Verification link has expired. Please contact your administrator.';
        this.showButton = true;
        this.showPasswordFields = false;
      });
    });
  }

  setPassword(form) {
    if (form.valid && form.value.password === form.value.repeatPassword) {
      this.disableSubmit = true;
      console.log(form.value);
      this.http.Post('/user/setPasswordAndActivateAccount', { email: this.email, password: form.value.password }).subscribe(res => {
        console.log(res);
        swal(
          MESSAGECONSTANTS.ALERT_MESSAGES.YOUR_NEW_PASSWPRD_HAS_BEEN_SET,
          MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_LOGIN, 'success').then(data => {
          this.router.navigate(['/login']);
        });
      }, err => {
        swal(MESSAGECONSTANTS.ALERT_MESSAGES.SOMETHING_WENT_WRONG, '', 'error');
        this.disableSubmit = false;
      });
    } else if (!form.valid && form.value.password === form.value.repeatPassword) {
      swal(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_READ_CAREFULLY,
        MESSAGECONSTANTS.ALERT_MESSAGES.PASSWORD_MINIMUM_8_CHAR_REQUIRED,
        'question');
      this.disableSubmit = false;
    } else {
      swal(MESSAGECONSTANTS.ALERT_MESSAGES.PLEASE_READ_CAREFULLY,
        MESSAGECONSTANTS.ALERT_MESSAGES.BOTH_FIELDS_NEEDS_TO_BE__MANDATORY,
        'question');
      this.disableSubmit = false;
    }
  }

}
