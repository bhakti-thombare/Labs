// import axios from 'axios';
// import React,{useEffect, useState} from 'react';

// const Mainfunction = () =>{
//     const [data, setData]= useState({firstName:"",lastName:"",role:"", referrer:"",questionId:"",sum:""});
//     const [files,setFiles] = useState({files:""});
//     const [source, setSource] = useState({source:""});

//     const getData = () =>{
//         const url = "https://evening-brook-34199.herokuapp.com/application";
//         let response = axios.get(url);
//         console.log(response);
//         return response;
//     }

//     const postData = () =>{
//         const url = "https://evening-brook-34199.herokuapp.com/application";
//         let response = axios.post(url,data,{
//             headers:{'Content-Type': 'application/form-data'}
//         });
//         return response;

//     }

//     const save = () =>{
//         getData().then((resp)=>{
//             let id = resp.data.id;
//             console.log(id);
//             let numsArray = resp.data.nums;
//             console.log(numsArray);
//             var answer = numsArray.reduce(function(n1,n2){
//                 return n1+n2;
//             },0)
//             console.log(answer);
//             let data1 ={
//                 "applicant":{
//                     "firstName":"test",
//                     "lastName":"test"
//                 },
//                 "role":"test",
//                 "referrer":"test",
//                 "answer":{
//                     "questionId":id,
//                     "sum": answer
//                 }
//             }
//             console.log(data1);
//            var formData = new FormData();
//            formData.append("file", new Blob([files.file],{type:'application/octet-stream'}));
//            formData.append("source", source.source);
//            formData.append("application", new Blob([JSON.stringify(data1)],{type:'application/json'}));
//            console.log(resp.data);

//            postData(formData).then((resp)=>{
//                alert(resp.data.message)
//            }).catch((error)=>{
//                console.log(`Erro Occurred ${error}`);
//            })

//         }).catch((error)=>{
//             console.log(`Error Occurred ${error}`);
//         })
//         console.log(files);
//         console.log(source);

//     }

//     return(
//         <div className="container">
//             <h2>Register</h2>
//             <div className="form-group">
//                 <label>Resume</label>
//                 <input type="file" name="file1" className="form-control" onChange={(evt)=>setFiles({...files, files:evt.target.files[0]})} />
//             </div>
//             <div className="form-group">
//                 <label>Source Code</label>
//                 <input type="file" name="file2" className="form-control" onChange={(evt)=>setSource({...source, source:evt.target.files[0]})} />
//             </div>
//             <div className="form-group">
//                 <input type="button" value="Submit" className="btn btn-success" onClick={save}/>
//             </div>
//         </div>
//     );

// }

// export default Mainfunction;

// import { importDeclaration } from '@babel/types';
import axios from 'axios';
import React,{useEffect, useState} from 'react';

const Main = () =>{
    const [data, setData]= useState({firstName:"",lastName:"",role:"",referrer:"",questionId:"",sum:""});
    const [files, setFiles] = useState({files:""});
    const [source,setSource]= useState({source:""});

    const getArray = ()=>{
        const url = "https://evening-brook-34199.herokuapp.com/application";
        let response = axios.get(url);
        console.log(response);
        return response;

    }
    
    const postArray = ()=>{
        const url ="https://evening-brook-34199.herokuapp.com/application";
        let response = axios.post(url,data,{
            headers:{'Content-Type':'application/form-data'}
        });
        console.log(response);
        return response;

    }

    const save = () =>{
        getArray().then((resp)=>{
            let id = resp.data.id;
            console.log(id);
            numArray = resp.data.nums;
            console.log(numArray);
            var answer = numArray.reduce(function(n1,n2){
                return n1+n2;
            },0)
            console.log(answer);
            let data1 ={
                "applicant":{
                    "firstName":"test",
                    "lastName":"test",
                },
                "role":"test",
                "referrer":"test",
                "answer":{
                    "questionId":id,
                    "sum":answer
                }
            }
            console.log(data1);
            var fd = new FormData();
            fd.append("file", new Blob([files.file],{type:'application/octet-stream'}));
            fd.append("source", source.source);
            fd.append("application", new Blob([JSON.stringify(data1)],{type:'application/json'}));
            console.log(data.resp);

            postArray(formData).then((resp)=>{
                alert(resp.data.message);
            }).catch((error)=>{
                console.log(`Error ${error}`);
            });
        }).catch((error)=>{
            console.log(`Error ${error}`);
        })
        console.log(files);
        console.log(source);

    }

    return(
        <div className="container">
            <h2>Register</h2>
            <div className="form-group">
                <label>Resume</label>
                <input type="file" name="file1" className="form-control" onChange={(evt)=>setFiles({...files, files:evt.target.files[0]})} />
            </div>
            <div className="form-group">
                <label>Source Code</label>
                <input type="file" name="file2" className="form-control" onChange={(evt)=>setSource({...source, source:evt.target.files[0]})} />
            </div>
            <div className="form-group">
                <input type="button" value="submit" className="btn btn-success" onClick={save} />
            </div>
        </div>
    );
}

export default Main;