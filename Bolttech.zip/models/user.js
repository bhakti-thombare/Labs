const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('user', {
    firstName: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    lastName: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    role: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    referrer: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    questionId: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    answer: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    file1: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    file2: {
      type: DataTypes.STRING(100),
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'user',
    timestamps: false
  });
};
