import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import RegisterUser from './firstComponent/form';
import SignupForm from './register';
import MainContainerComponent from './../src/mainComponent';
import './../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Test from './testt';
// import First from './first';
import Apps from './new';
import DataFetch from './start';
import Fetch from './trial1';
import CustomHookComponet from './Hooks/customHookComponent';
import Book from './book';
import Trial3 from './trial3';

import First from './bolttech';
ReactDOM.render(
  <React.StrictMode>
<First/>


    {/* <App /> */}
    {/* <Book/> */}
  {/* <Test/> */}
  {/* <Trial/> -----books*/}
  {/* <Fetch/> */}
  {/* <CustomHookComponet/>/////////////////get not working  Error Ocured Error: Network Error */}
    {/* <RegisterUser/> ///////////////////////its working partially */}
    {/* <SignupForm/> */}

    {/* <DataFetch/> */}
    {/* <Apps/>   */}
    {/* <MainContainerComponent/> */}
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
