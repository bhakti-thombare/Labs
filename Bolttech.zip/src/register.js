import React from "react";
import {useState} from 'react';
const SignupForm = ()=>{
    const [firstName,setFirstName]=useState("")
    const [lastName,setLastName]=useState("")
    const [role,setRole]=useState("")
    const [referrer,setReferrer]=useState("")
    const [questionId,setQuestionId]=useState("")
    const [answer,setAnswer]=useState("")
    const [file1,setFile1]=useState("")
    const [file2,setFile2]=useState("")

    function signUp(){
        let users={firstName,lastName,role,referrer,questionId,answer,file1,file2}
        console.log(users);
    }
    
    
    return(
        // <div>Signup Form</div>
        <div className="container col-sm-6 offset-sm-3">   
            <h2 className="title">Create Account</h2> 
            <div className="form-group">
                <label>FirstName</label>
                <input type="text" value={firstName} onChange={(evt)=>setFirstName(evt.target.value)} className="form-control" placeholder="First Name" />
            </div> 
            <div className="form-group">
                <label>LastName</label>
                <input type="text" value={lastName} onChange={(evt)=>setLastName(evt.target.value)} className="form-control" placeholder="Last Name" />
            </div>   
            <div className="form-group">
                <label>Role</label>
                <input type="text" value={role} onChange={(evt)=>setRole(evt.target.value)} className="form-control" placeholder="Role" />
            </div> 
            <div className="form-group">
                <label>Referrer</label>
                <input type="text" value={referrer} onChange={(evt)=>setReferrer(evt.target.value)} className="form-control" placeholder="Referrer" />
            </div>   
            <div className="form-group">
                <label>Question Id</label>
                <input type="text" value={questionId} onChange={(evt)=>setQuestionId(evt.target.value)} className="form-control" placeholder="Question Id" />
            </div>   
            <div className="form-group">
                <label>Answer</label>
                <input type="text" value={answer} onChange={(evt)=>setAnswer(evt.target.value)} className="form-control" placeholder="Answer" />
            </div>  
            <div className="form-group">
                <label>File1</label>
                <input type="file" value={file1} onChange={(evt)=>setFile1(evt.target.value)} className="form-control" placeholder="File1" />
            </div>   
            <div className="form-group">
                <label>File2</label>
                <input type="file" value={file2} onChange={(evt)=>setFile2(evt.target.value)} className="form-control" placeholder="File2" />
            </div>  
            <br/>
            <div className="form-group offset-sm-5">
                <button onClick={signUp} className="btn btn-success">Register</button>
                
            </div>    
        </div>
    );
};

export  default SignupForm;