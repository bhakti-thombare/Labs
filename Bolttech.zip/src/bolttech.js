import axios from 'axios';
import React, {useEffect, useState} from 'react';

const First = () =>{
    const [data,setData] = useState({id:0,email:"",first_name:"",last_name:"",avatar:""});

    const getData = () =>{
        const url = "https://reqres.in/api/users";
        let res = axios.get(url);
        console.log(res);
        return res;

    }

    const postData = () =>{
        const url = "https://reqres.in/api/users";
        let res = axios.post(url,data);
        console.log(res);
        return res;
    }

    return(
        <div className="container">
            <h2>Register</h2>
            <div className="form-group">
                <label>Email</label>
                <input type="text" value={data.email} name="email" className="form-control"  onChange={(evt)=>setData({...data, email:evt.target.value})} />
            </div>
            <div className="form-group">
                <label>First Name</label>
                <input type="text" value={data.first_name} name="first_name" className="form-control"  onChange={(evt)=>setData({...data, first_name:evt.target.value})} />
            </div>
            <div className="form-group">
                <label>Last Name</label>
                <input type="text" value={data.last_name} name="last_name" className="form-control"  onChange={(evt)=>setData({...data, last_name:evt.target.value})} />
            </div>
            <div className="form-group">
                <label>Avatar</label>
                <input type="file" value={data.avatar} name="avatar" className="form-control"  onChange={(evt)=>setData({...data, avatar:evt.target.value})} />
            </div>
            <div className="form-group">
                <input type="button" value="get" className="btn btn-warning" onClick={getData} />
                <input type="button" value="post" className="btn btn-success" onClick={postData} />
            </div>
        </div>
    );
}

export default First;