import React, { useEffect, useState } from 'react'

import RegistertHttpService from './../service/commonService';

const RegisterUser = () => {
   const serv = new RegistertHttpService('https://evening-brook-34199.herokuapp.com/application');   
   const [user, setUser] = useState({ firstName: '', lastName: '', role: '', referrer: '', questionId: 0, 
   answer: 0, file1:'',file2:'' });

   const get=()=>{
       console.log(user);
       serv.getData(user).then((response)=>{
        
        setUser(response.data);
           console.log(response.data);
       })
   }
   

    const save = () => {
        // console.log(this.data);
        console.log(user);
        serv.postData(user)
            .then((response) => {

                setUser(response.data);
            }).catch((error) => {
                console.log(`Eror ocured ${error}`);
            });
    };
    return (
        <div>

            <div>
                <div className="container" >
                    <div className="col-md-6" >
                        

                            <h1>Register</h1>
                            <div className="container">
                                <div className="form-group">
                                    <input className="form-control" name="firstName" type="text" placeholder="First Name" onChange={(evt) => setUser({ ...user, firstName: evt.target.value })} className="form-control" /><br />
                                </div>
                                <div className="form-group">
                                    <input name="lastName" type="text" placeholder="Last Name" onChange={(evt) => setUser({ ...user, lastName: evt.target.value })} className="form-control" /><br />
                                </div>
                                <div className="form-group">
                                    <input name="role" type="text" placeholder="Role" onChange={(evt) => setUser({ ...user, role: evt.target.value })} className="form-control" /><br />
                                </div>
                                <div className="form-group">
                                    <input name="referrer" type="text" placeholder="Referrer" onChange={(evt) => setUser({ ...user, referrer: evt.target.value })} className="form-control" /><br />
                                </div>
                                <div className="form-group">
                                    <input name="questionId" type="text" placeholder="Question Id" onChange={(evt) => setUser({ ...user, questionId: evt.target.value })} className="form-control" /><br />
                                </div>
                                <div className="form-group">
                                    <input name="answer" type="text" placeholder="Answer" onChange={(evt) => setUser({ ...user, answer: evt.target.value })} className="form-control" /><br />
                                </div>
                                <div className="form-group">
                                    <input name="Resume" type="file"  placeholder="Upload file1" onChange={(evt) => setUser({ ...user, file1: evt.target.value })} className="form-control" /><br />
                                </div>
                                <div className="form-group">
                                    <input name="Code Zip" type="file"  placeholder="Upload file2" onChange={(evt) => setUser({ ...user, file2: evt.target.value })} className="form-control" /><br />
                                </div>
                                <div className="form-group">
                                    <button type="submit" value="Sign me up!" className="inputButton inputButton btn btn-info" onClick={save}>Register</button>
                                    <button type="submit" value="Get!" className="inputButton btn btn-light" onClick={get}>Get</button>
                                </div>
                            
                        </div>
                    </div>  
                </div>
            </div>
        </div>

    );



}

export default RegisterUser;