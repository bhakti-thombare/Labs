import React from 'react';
import axios from 'axios';
import { Component } from 'react';
class Test extends Component{

        state ={
            loading: true,
            array: null,
    }

        

    async componentDidMount(){  
        const url = "https://evening-brook-34199.herokuapp.com/application";
        const response = await fetch('https://evening-brook-34199.herokuapp.com/application')
        .then(response => response.json())
        .then(data => console.log('QuestionId: '+data.id+ ' &&& ' + 'nums: '+data.nums),
            );
                
               
              
              
                //  localStorage.setItem('Storage', JSON.stringify(response));
                // dispatch(addUser(response.data))
        
        // console.log(response.json());
    
        // console.log(response.type);
        // console.log(response.url);
        // const data = await response.json();
        // this.setState({array:data.rows[0], loading:false});
        // this.setState({array:data, loading:false});
        // console.log(data[0]);

    }



    render(){
    
        return(
            <div>
                List of Array Elements   
            </div>
            
        );
    }
}

export default Test;





// import React from 'react';
// import axios from 'axios';
// import { Component } from 'react';
// class Test extends Component{
//     constructor(props){
//         super(props)
//         this.state ={
//             // id:0,
//             posts:[]
//         }
//     }

//     componentDidMount(){
//         axios.get("https://evening-brook-34199.herokuapp.com/application")
//       
       
//         .then(response=>{
//             // this.setState({posts:response.data});
//             console.log(response);
//         })
//         .catch(error=>{
//             console.log(error);
//         })

//     }


//     render(){
    
//         return(
//             <div>
//                 List of Array Elements
              
//             </div>
//         );
//     }
// }

// export default Test;


// import React from 'react';
// import { Component } from 'react';
// import './App.css';
// export default class Test extends Component{
//     constructor(){
//         super();
//         this.state={
//             data:true
//         }
//     }
    // componentDidMount(){
    //     let  url ="https://evening-brook-34199.herokuapp.com/application";
    //     fetch(url,{
    //         method:'GET',
    //         headers:{
    //             'Accept':'application/json',
    //             'Content-Type':'application/json',
    //             'Access-Control-Allow-Origin': '*',
    //             'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept'
    //         }
    //     }).then((result)=>{
    //         result.json().then((resp)=>{
    //             console.log(resp);
    //         })
    //     })
    // }
//     render(){
//         return(
//             <div>
//                 <h3>GET API</h3>
//             </div>
//         );
//     }

// }

// async function fetchdata(){
//     try{
//         const result = await axios.get("https://evening-brook-34199.herokuapp.com/application")
//         console.log(result.data);
//     }catch(error){
//         console.log(error);
//     }
// }
// import React, { Component } from 'react';
 