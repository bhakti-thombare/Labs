import React from 'react';
import Axios from 'axios';

// import  CommonService from './service/commonService';
// import { useEffect, useState } from 'react';
function Fetch(){
    // const serv = new CommonService('https://evening-brook-34199.herokuapp.com/application'); 
    // const [user, setUser] = useState({ firstName: '', lastName: '', role: '', referrer: '', questionId: 0, 
    // answer: 0, file1:'',file2:'' });
    const getData = ()=>{
        Axios.get("https://evening-brook-34199.herokuapp.com/application",{
            headers:{
                'Access-Control-Allow-Headers' :'*',
                'Access-Control-Allow-Origin': '*',
               'Access-Control-Allow-Methods':'POST, GET, OPTIONS, DELETE, PUT', 
        
            }
        }).then(
            (response)=>{
                console.log(response);
            }
        );
    };

    // const save = () => {
    //     // console.log(this.data);
    //     console.log(user);
    //     serv.postData(user)
    //         .then((response) => {

    //             setUser(response.data);
    //         }).catch((error) => {
    //             console.log(`Eror ocured ${error}`);
    //         });
    // };
    
    return(
        <div>
            Hello <button onClick={getData}> Click Me</button>
         </div>

    );
}
export default Fetch;