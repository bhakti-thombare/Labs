import React,{useState,useEffect} from 'react';
import axios from 'axios';
function DataFetch(){
    const [data,setPosts]= useState([])
    useEffect(()=>{
        axios.get('https://evening-brook-34199.herokuapp.com/application',{
            
            headers:{
                'Content-Type': 'application/json',    
                'Authorization': 'my-auth-token',    
                'Access-Control-Allow-Origin': '*',    
                'Access-Control-Allow-Credentials': 'true',    
                'Access- Control - Allow - Methods': 'GET, POST, OPTIONS',    
                // 'Access- Control - Allow - Headers' : 'Origin, Content - Type, Accept'    
            }
        })
        .then(res=>{
            console.log(res);
        })
        .catch(err=>{
            console.log(err);
        })
        console.log(data);
    })
    return(
        <div>
            <ul>
                {
                    data.map(post=><li key={post.id}>{post.nums}</li>)
                }
            </ul>

        </div>
    )
}

export default DataFetch;