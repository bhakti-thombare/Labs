import React from 'react';
import {Route, Link,Redirect, Switch} from 'react-router-dom';

// import ListProductComponent from './listproducts';
// import ListCategoryComponent from './listcategory';

// import ListSubCategoriesComponent from './listsubcategory';

// import ProductHookComponent from './../Hooks/producthookcomponent';
// // import ProductAPIComponent from './../components/ProductsAPI/products';
// import CategoryAPIComponent from './../components/CategoryAPI/categoryapi';
// import SubCategoryAPIComponent from './../components/CategoryAPI/subcategoryapi';
// import LoginComponent from './logincomponent';
// import RegisterComponent from './registercomponent';
import RegisterUser from './firstComponent/form';
import SignupForm from './register';

const MainContainerComponent=()=>{
 const storage =localStorage.getItem('localStorage');
 console.log(storage);

//  const logout=()=>{
//      localStorage.clear();
//  }

//  const login=()=>{
//      if(storage === null){
//        return <tr>
//         <td>
//             <Link to="/login" >Login</Link>
//             </td>
//         </tr>
//      }
//      if(storage != null ){
//         <Redirect to="/login"></Redirect>
//      }
//  }
//  const storageFunc=()=>{
     
//      if(storage != null){
//          return <tr>   
//             <td>
//                 <Link to="/createproducts">Create Products</Link>
//             </td>
//             <td>
//                 <Link to="/listproducts">Product List</Link>
//             </td>
//             {/* <td>
//                 <Link to="/createcategories">Create Categories </Link>
//             </td>
//             <td>
//                 <Link to="/createsubcategories">Create Sub Categories</Link>
//             </td> */}
//             <td>
//                 <button className="btn btn-danger">
//                     <Link to="/login" onClick={logout}>Logout</Link>
//                 </button><span>   </span>
//                 {/* <button className="btn btn-warning">
//                     <Link to="/register">Register</Link>
//                 </button> */}
//             </td>
//          </tr>
//      }
//      if(storage === null){
//         <Redirect to="/login"></Redirect>
//          console.log('Localstorage is null');
//      }
    
//  }


 
    return (   

    <div className="container">
    <h1>E-Commerse App</h1>
    
      <Switch>
        <Route exact path="/register" component={RegisterUser}></Route>
         <Route exact path="/sum" component={SignupForm}></Route>
        

        <Redirect to="/"></Redirect>
      </Switch>      
    </div>
    );

};

export default MainContainerComponent;
