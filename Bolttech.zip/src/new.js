import React, { useEffect, useState } from 'react'

const Apps = () => {
  const [data, setData] = useState(null)
  const fetchURL = "https://evening-brook-34199.herokuapp.com/application"
  const getData = () =>
    fetch(`${fetchURL}/id`,{
         method:'GET',
            headers:{
                'Content-Type':'application/json',
                'Access-Control-Allow-Origin': '*',
               ' Access-Control-Allow-Methods':' POST, GET, OPTIONS',   
            }
    })
      .then((res) => res.json())

  useEffect(() => {
    getData().then((data) => setData(data))
  }, [])

  return (
    <div>
      {data?.map((item) => 
        <ul>
          <li>{item.title}</li>
        </ul>
      )}
    </div>
  )
}

export default Apps;