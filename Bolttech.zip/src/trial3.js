import React, { useState, useEffect } from "react";
// import "./App.css";
import axios from "axios";
const gitHubUrl = "https://evening-brook-34199.herokuapp.com/application";

function Trial3() {
  const [userData, setUserData] = useState({});

  useEffect(() => {
    getGitHubUserWithFetch();
  }, []);

  const getGitHubUserWithFetch = async () => {
//        const response = await fetch(gitHubUrl);
//   const jsonData = await response.json();
//   setUserData(jsonData);
const response = await axios.get(gitHubUrl);
setUserData(response.data);
console.log(response.data);
console.log(response.data.id);
console.log(response.data.nums);
  };

  return (
    <div>
      <header className="App-header">
        <h2>GitHub User Data</h2>
      </header>
      <div className="container">
        <h5 className="info-item">{userData.id}</h5>
        <h5 className="info-item">{userData.nums}</h5>
        
      </div>
    </div>
  );
}

export default Trial3;