// // import axios from 'axios';
// // import React,{useEffect, useState} from 'react';

// // const Mainfunction = () =>{

// //     const [data,setData] = useState({firstName:"",lastName:"",role:"",referrer:"",questionId:"",sum:""});
// //     const [files,setFiles] = useState({files:""});
// //     const [source,setSource] = useState({source:""});

// //     const getArray = () =>{
// //         const url = "https://evening-brook-34199.herokuapp.com/application";
// //         let response = axios.get(url);
// //         console.log(response);
// //         return response;

// //     }

// //     const postArray = () =>{
// //         const url = "https://evening-brook-34199.herokuapp.com/application";
// //         let response = axios.post(url,data,{
// //             headers:{
// //                 'Content-Type':'application/form-data'
// //             }
// //         });
// //         console.log(response);
// //         return response;
// //     }

// //     const save = () =>{
// //         getArray().then((resp)=>{
// //             let id = resp.data.id;
// //             console.log(id);
// //             let numArray = resp.data.nums;
// //             console.log(numArray);
// //             var answer = numArray.reduce(function(n1,n2){
// //                 return n1+ n2
// //             },0);
// //             console.log(answer);
// //             let data1={
// //                 "applicant": {
// //                     "firstName": "$firstName",
// //                     "lastName": "$lastName"
// //                 },
// //                 "role": "$role",
// //                 "referrer": "$referrer",
// //                 "answer": {
// //                     "questionId": id,
// //                     "sum": answer
// //                 }
// //             }
// //             console.log(data1);
// //             var formData = new FormData();
// //             formData.append("file", new Blob([files.file],{type:'application/octet-stream'}))
// //             formData.append("source", source.source);
// //             formData.append("application", new Blob([JSON.stringify(data1)],{type:'application/json'}))
// //             console.log(resp.data);

// //             postArray(formData).then((resp)=>{
// //                 alert(resp.data.message)
// //             }).catch((error)=>{
// //                 console.log(`Error ${error}`);
// //             });
// //         }).catch((error)=>{
// //             console.log(`Error ${error}`);
// //         });
// //         console.log(files);
// //         console.log(source);
// //     }

// //     return(
// //         <div className="container">
// //             <h2>Register</h2>
// //             <div className="form-group">
// //                 <label>Resume</label>
// //                 <input type="file" name="file1" className="form-control" onChange={(evt)=>setFiles({...files, files:evt.target.files[0]})} />
// //             </div>
// //             <div className="form-group">
// //                 <label>Source Code</label>
// //                 <input type="file" name="file2" className="form-control" onChange={(evt)=>setSource({...source, source:evt.target.files[0]})} />
// //             </div>
// //             <div className="form-group">
// //                 <input type="button" value="submit" className="btn btn-success" onClick={save} />
// //             </div>
// //         </div>
// //     );

// // }

// // export default Mainfunction;

// import axios from 'axios';
// import React,{useEffect, useState} from 'react'

// const Mains=()=>{
//     const [data,setData] = useState({id:0,email:"",first_name:"",last_name:"",avatar:""});

//     const get=()=>{
//         const url = "https://reqres.in/api/users";
//         let res = axios.get(url);
//         return res;

//     }
//     const post=()=>{
//         const url = "https://reqres.in/api/users";
//         let res = axios.post(url,data)
//         return res;

//     }

//     return(
//         <div className="container">
//             <h2>Register</h2>
//             <div className="form-group">
//                 <label>Email</label>
//                 <input type="text" name="email" value={data.email} className="form-control" onChange={(evt)=>setData({...data, email:evt.target.value})} />
//             </div>
//             <div className="form-group">
//                 <label>First Name</label>
//                 <input type="text" name="first_name" value={data.first_name} className="form-control" onChange={(evt)=>setData({...data, first_name:evt.target.value})} />
//             </div>
//             <div className="form-group">
//                 <label>Last Name</label>
//                 <input type="text" name="last_name" value={data.last_name} className="form-control" onChange={(evt)=>setData({...data, last_name:evt.target.value})} />
//             </div>
//             <div className="form-group">
//                 <label>Avatar</label>
//                 <input type="text" name="avatar" value={data.avatar} className="form-control" onChange={(evt)=>setData({...data, avatar:evt.target.value})} />
//             </div>
//             <div className="form-group">
//                 <input type="button" value="Get" className="btn btn-warning" onClick={get} />
//                 <input type="button" value="Post" className="btn btn-success" onClick={post} />
//             </div>
//         </div>
//     );
// }

// export default Mains;

// import axios from 'axios';
// import React,{useEffect,useState} from 'react';

// const Mainfunction = () =>{

//     const [data, setData] = useState({id:0,email:"",first_name:"",last_name:"", avatar:""});

//     const getArray = ()=>{
//         const url = "https://reqres.in/api/users";
//         let response = axios.get(url);
//         console.log(response);
//         return response;

//     }
//     const postArray = () =>{
//         const url ="https://reqres.in/api/users";
//         let response = axios.post(url,data);
//         console.log(response);
//         return response;
//     }

//     return(
//         <div className="container">
//             <h2>Register</h2>
//             <div className="form-group">
//                 <label>Email</label>
//                 <input type="text" name="email" value={data.email} className="form-control" onChange={(evt)=>setData({...data, email:evt.target.value})} />
//             </div>
//             <div className="form-group">
//                 <label>First Name</label>
//                 <input type="text" name="first_name" value={data.first_name} className="form-control" onChange={(evt)=>setData({...data, first_name:evt.target.value})} />
//             </div>
//             <div className="form-group">
//                 <label>Last Name</label>
//                 <input type="text" name="last_name" value={data.last_name} className="form-control" onChange={(evt)=>setData({...data, last_name:evt.target.value})} />
//             </div>
//             <div className="form-group">
//                 <label>Avatar</label>
//                 <input type="file" name="avatar" value={data.avatar} className="form-control" onChange={(evt)=>setData({...data, avatar:evt.target.value})} />
//             </div>
//             <div  className="form-group">
//                 <input type="button" name="Get" className="btn btn-warning"  onClick={getArray} />
//                 <input  type="button" name="Post" className="btn btn-success"  onClick={postArray}/>
//             </div>
//         </div>
//     );
// }
//export default Mainfunction;

import axios from 'axios';
import React, {useEffect, useState} from 'react';

const Mainfunction = ()=>{

    const [data,setData] = useState({firstName:"",lastName:"",role:"",referrer:"", questionId:"",sum:""});
    const [files,setFiles]= useState({files:""});
    const [source, setSource]=useState({source:""});

    const getArray = () =>{
        const url = "https://evening-brook-34199.herokuapp.com/application";
        let response = axios.get(url);
        console.log(response);
        return response;

    }

    const postArray = () =>{
        const url = "https://evening-brook-34199.herokuapp.com/application";
        let response = axios.post(url,data,{
            headers:{'Content-Type':'application/form-data'}
        });
        console.log(response);
        return response;
    }

    const save = ()=>{
        getArray().then((resp)=>{
            let id = resp.data.id;
            console.log(id);
            let numArray = resp.data.nums;
            console.log(numArray);
            var answer = numArray.reduce(function(n1,n2){
                return n1+ n2;
            },0)
            console.log(answer);
            let data1 ={
                "applicant":{
                    "firstName":"test",
                    "lastName":"test",
                },
                "role":"test",
                "referrer":"test",
                "answer":{
                    "questionId":id,
                    "sum": answer
                }
            }
            console.log(data1);
            var formData = new FormData();
            formData.append("file", new Blob([files.file],{type: 'application/octet-stream'}));
            formData.append("source", source.source);
            formData.append("application", new Blob([JSON.stringify(data1)], {type:'application/json'}))
            console.log(data.resp);

            postArray(formData).then((resp)=>{
                alert(data.resp.message);
            }).catch((error)=>{
                console.log(`Error ${error}`);
            })
        }).catch((error)=>{
            console.log(`Error ${error}`);
        })

    }

    return(
        <div className="container">
            <h2>Register</h2>
            <div className="form-group">
                <label>Resume</label>
                <input type="file" name="file1" className="form-control" onChange={(evt)=>setFiles({...files, files:evt.target.files[0]})} />
            </div>
            <div className="form-group">
                <label>Source Code</label>
                <input type="file" name="file2" className="form-control" onChange={(evt)=>setSource({...source, source:evt.target.files[0]})} />
            </div>
            <div className="form-control">
                <input type="button" value="Submit" className="btn btn-primary" onClick={save} />
            </div>
        </div>
    );
    
}

export default Mainfunction;