import axios from 'axios';
import React, { useEffect, useState } from 'react'


const FirstAPI = () => {
    const [data, setData] = useState({ firstName: "", lastName: "", role: "", referrer: "", questionId: "", sum: "" });
    const [files, setFile] = useState({ files: "" });
    const [source, setSource] = useState({ source: "" });


    const getData = () => {
        const url = "https://evening-brook-34199.herokuapp.com/application";
        let response = axios.get(url);
        return response;
    }

    const postData = (data) => {
        const url = "https://evening-brook-34199.herokuapp.com/application";
        let response = axios.post(url, data, {
            headers: {
                'Content-Type': 'multipart/form-data'

            }
        });
        return response;
    }


    const save = () => {
        getData().then((resp) => {
            let value= resp.data.nums
            console.log(value);
           
            var sum = value.reduce(function(a, b){
                return a + b;
            }, 0);
            
            console.log(sum);
            
            
            let data1 = {
                "applicant": {
                    "firstName": "Test",
                    "lastName": "Test"
                },
                "role": "Test",
                "referrer": "Test",
                "answer": {
                    "questionId": resp.data.id,
                    "sum": sum
                }
               

            }
            
            console.log(data1);
            var formData = new FormData();
            formData.append("file", new Blob([files.file], { type: "application/octet-stream" }));
            formData.append("source", source.source);
            formData.append("application", new Blob([JSON.stringify(data1)], { type: "application/json" }));
            console.log(resp.data)
            
            postData(formData).then((resp) => {
                alert(resp.data.message)
            }).catch((error) => {
                console.log(`Error Occured ${error}`);
            });

        }).catch((error) => {
            console.log(`Error Occured ${error}`);
        });



        console.log(files);
        console.log(source);


    };



    return (
        <div className="container">
            <h2>Register</h2>
            <div className="form-group">
                <label>Resume</label>
                <input type="file" name="file1" onChange={(evt) => setFile({ ...files, files: evt.target.files[0] })}
                    className="form-control" />
            </div>

            <div className="form-group">
                <label>Source Code</label>
                <input type="file" name="file2" onChange={(evt) => setSource({ ...source, source: evt.target.files[0] })}
                    className="form-control" />
            </div>


            <div className="form-group">
                <input type="button" value="Save" className="btn btn-success"
                    onClick={save} />
            </div>
            <br />

            <hr />


        </div>

    );

}

export default FirstAPI;