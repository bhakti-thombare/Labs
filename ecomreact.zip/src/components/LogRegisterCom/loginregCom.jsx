
import React, { useEffect, useState } from 'react'

import RegistertHttpService from './../../services/catservice';

const RegisterUser=()=>{
    const serv = new RegistertHttpService('http://localhost:9008/api/app/register');
   // const servInrole = new RegistertHttpService('http://localhost:9008/api/userinrole/');
    
    const [userReg, setUser] = useState({RowId:0,UserName:'',Password:'',EmailAddress:''});
    

    const clear=()=>{
        setUser({RowId:0,UserName:'',Password:'',EmailAddress:''});
        //props.history.push("/");
    };

    const save=()=>{
        
         serv.postData(userReg)
         .then((response)=>{

            setUser(response.data.record);
            
            clear()
        }).catch((error)=>{
            console.log(`Eror ocured ${error}`);
        });
    };
return(
<div>
<nav className="navbar navbar-inverse">
  
</nav>


  
<div>
<div className="container" >
    <div className="col-md-6" >
        <div id="logbox"  >
            
                <h1>Create an Account</h1>
                <input name="UserName" type="text" placeholder="User Name" onChange={(evt)=> setUser({...userReg, UserName:evt.target.value})}  className="form-control"/><br/>
				 <input name="EmailAddress" type="email" placeholder="Email address" onChange={(evt)=> setUser({...userReg, EmailAddress:evt.target.value})}  className="form-control"/><br/>
                <input name="Password" type="password" placeholder="Choose a password" required="required"  onChange={(evt)=> setUser({...userReg, Password:evt.target.value})}  className="form-control"/><br/>
                <input name="Password2" type="password" placeholder="Confirm password" required="required"  className="form-control"/><br/>
                <button type="submit" value="Sign me up!" className="inputButton inputButton btn btn-info" onClick={save}>Register Me..!</button>
                <button type="submit" value="Sign me up!" className="inputButton btn btn-light" onClick={clear}>Clear</button>



            
        </div>
    </div>
  


</div>
</div>
</div>

);



}

export default RegisterUser;