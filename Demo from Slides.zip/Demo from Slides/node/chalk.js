const chalk = require("chalk");
const logUpdate = require("log-update");

const outputs = [chalk.red("Buzz!"), chalk.blue("Fizz!")];

let sw = 0;
setInterval(() =>{
    sw == 0 ? (sw =1) :(sw =0);
    logUpdate(outputs[sw]);
},1000)
