const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('product', {
    RowId: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      unique: "RowId"
    },
    ProductId: {
      type: DataTypes.STRING(20),
      allowNull: false,
      primaryKey: true
    },
    ProductName: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    Product_Price: {
      type: DataTypes.DECIMAL(10,2),
      allowNull: false
    },
    ProductDescription: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    CategoryId: {
      type: DataTypes.STRING(20),
      allowNull: false,
      references: {
        model: 'category',
        key: 'CategoryId'
      }
    },
    SubCategoryId: {
      type: DataTypes.STRING(20),
      allowNull: false,
      references: {
        model: 'subcategories',
        key: 'SubCategoryId'
      }
    },
    ManufacturerId: {
      type: DataTypes.STRING(20),
      allowNull: false,
      references: {
        model: 'manufacturer',
        key: 'ManufacturerId'
      }
    },
    VendorId: {
      type: DataTypes.STRING(20),
      allowNull: false,
      references: {
        model: 'vendor',
        key: 'VendorId'
      }
    }
  }, {
    sequelize,
    tableName: 'product',
    timestamps: false,
    indexes: [
      {
        name: "PRIMARY",
        unique: true,
        using: "BTREE",
        fields: [
          { name: "ProductId" },
        ]
      },
      {
        name: "RowId",
        unique: true,
        using: "BTREE",
        fields: [
          { name: "RowId" },
        ]
      },
      {
        name: "fk_CategoryId_in_product_table",
        using: "BTREE",
        fields: [
          { name: "CategoryId" },
        ]
      },
      {
        name: "fk_SubCategoryId_in_product_table",
        using: "BTREE",
        fields: [
          { name: "SubCategoryId" },
        ]
      },
      {
        name: "fk_ManufacturerId_in_product_table",
        using: "BTREE",
        fields: [
          { name: "ManufacturerId" },
        ]
      },
      {
        name: "fk_VendorId_in_product_table",
        using: "BTREE",
        fields: [
          { name: "VendorId" },
        ]
      },
    ]
  });
};
