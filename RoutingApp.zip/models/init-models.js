var DataTypes = require("sequelize").DataTypes;
var _category = require("./category");
var _customer = require("./customer");
var _dispatch = require("./dispatch");
var _errormessage = require("./errormessage");
var _imagepath = require("./imagepath");
var _manufacturer = require("./manufacturer");
var _orderitem = require("./orderitem");
var _orders = require("./orders");
var _payment = require("./payment");
var _product = require("./product");
var _rolemaster = require("./rolemaster");
var _subcategories = require("./subcategories");
var _userinrole = require("./userinrole");
var _userlogininfo = require("./userlogininfo");
var _usermaster = require("./usermaster");
var _vendor = require("./vendor");

function initModels(sequelize) {
  var category = _category(sequelize, DataTypes);
  var customer = _customer(sequelize, DataTypes);
  var dispatch = _dispatch(sequelize, DataTypes);
  var errormessage = _errormessage(sequelize, DataTypes);
  var imagepath = _imagepath(sequelize, DataTypes);
  var manufacturer = _manufacturer(sequelize, DataTypes);
  var orderitem = _orderitem(sequelize, DataTypes);
  var orders = _orders(sequelize, DataTypes);
  var payment = _payment(sequelize, DataTypes);
  var product = _product(sequelize, DataTypes);
  var rolemaster = _rolemaster(sequelize, DataTypes);
  var subcategories = _subcategories(sequelize, DataTypes);
  var userinrole = _userinrole(sequelize, DataTypes);
  var userlogininfo = _userlogininfo(sequelize, DataTypes);
  var usermaster = _usermaster(sequelize, DataTypes);
  var vendor = _vendor(sequelize, DataTypes);

  manufacturer.belongsTo(category, { as: "Category", foreignKey: "CategoryId"});
  category.hasMany(manufacturer, { as: "manufacturers", foreignKey: "CategoryId"});
  product.belongsTo(category, { as: "Category", foreignKey: "CategoryId"});
  category.hasMany(product, { as: "products", foreignKey: "CategoryId"});
  subcategories.belongsTo(category, { as: "Category", foreignKey: "CategoryId"});
  category.hasMany(subcategories, { as: "subcategories", foreignKey: "CategoryId"});
  orders.belongsTo(customer, { as: "Customer", foreignKey: "CustomerId"});
  customer.hasMany(orders, { as: "orders", foreignKey: "CustomerId"});
  product.belongsTo(manufacturer, { as: "Manufacturer", foreignKey: "ManufacturerId"});
  manufacturer.hasMany(product, { as: "products", foreignKey: "ManufacturerId"});
  dispatch.belongsTo(orders, { as: "Order", foreignKey: "OrderId"});
  orders.hasMany(dispatch, { as: "dispatches", foreignKey: "OrderId"});
  orderitem.belongsTo(orders, { as: "Order", foreignKey: "OrderId"});
  orders.hasMany(orderitem, { as: "orderitems", foreignKey: "OrderId"});
  payment.belongsTo(orders, { as: "Order", foreignKey: "OrderId"});
  orders.hasMany(payment, { as: "payments", foreignKey: "OrderId"});
  imagepath.belongsTo(product, { as: "Product", foreignKey: "ProductId"});
  product.hasMany(imagepath, { as: "imagepaths", foreignKey: "ProductId"});
  orderitem.belongsTo(product, { as: "Product", foreignKey: "ProductId"});
  product.hasMany(orderitem, { as: "orderitems", foreignKey: "ProductId"});
  product.belongsTo(subcategories, { as: "SubCategory", foreignKey: "SubCategoryId"});
  subcategories.hasMany(product, { as: "products", foreignKey: "SubCategoryId"});
  userinrole.belongsTo(usermaster, { as: "UserName_usermaster", foreignKey: "UserName"});
  usermaster.hasMany(userinrole, { as: "userinroles", foreignKey: "UserName"});
  product.belongsTo(vendor, { as: "Vendor", foreignKey: "VendorId"});
  vendor.hasMany(product, { as: "products", foreignKey: "VendorId"});

  return {
    category,
    customer,
    dispatch,
    errormessage,
    imagepath,
    manufacturer,
    orderitem,
    orders,
    payment,
    product,
    rolemaster,
    subcategories,
    userinrole,
    userlogininfo,
    usermaster,
    vendor,
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
