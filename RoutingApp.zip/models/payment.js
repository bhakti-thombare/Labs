const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('payment', {
    RowId: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      unique: "RowId"
    },
    PaymentId: {
      type: DataTypes.STRING(20),
      allowNull: false,
      primaryKey: true
    },
    OrderId: {
      type: DataTypes.STRING(20),
      allowNull: false,
      references: {
        model: 'orders',
        key: 'OrderId'
      }
    },
    Transaction_Date: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    Transaction_Status: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    Paid_by: {
      type: DataTypes.STRING(20),
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'payment',
    timestamps: false,
    indexes: [
      {
        name: "PRIMARY",
        unique: true,
        using: "BTREE",
        fields: [
          { name: "PaymentId" },
        ]
      },
      {
        name: "RowId",
        unique: true,
        using: "BTREE",
        fields: [
          { name: "RowId" },
        ]
      },
      {
        name: "fk_OrderId_in_payment_table",
        using: "BTREE",
        fields: [
          { name: "OrderId" },
        ]
      },
    ]
  });
};
