const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('orderitem', {
    RowId: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      unique: "RowId"
    },
    OrderItemId: {
      type: DataTypes.STRING(20),
      allowNull: false,
      primaryKey: true
    },
    OrderItemName: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    OrderId: {
      type: DataTypes.STRING(20),
      allowNull: false,
      references: {
        model: 'orders',
        key: 'OrderId'
      }
    },
    ProductId: {
      type: DataTypes.STRING(20),
      allowNull: false,
      references: {
        model: 'product',
        key: 'ProductId'
      }
    },
    ProductPrice: {
      type: DataTypes.DECIMAL(10,2),
      allowNull: false
    },
    Tax_calculated: {
      type: DataTypes.DECIMAL(10,2),
      allowNull: true
    },
    Quantity: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    Total_Price: {
      type: DataTypes.DECIMAL(10,2),
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'orderitem',
    timestamps: false,
    indexes: [
      {
        name: "PRIMARY",
        unique: true,
        using: "BTREE",
        fields: [
          { name: "OrderItemId" },
        ]
      },
      {
        name: "RowId",
        unique: true,
        using: "BTREE",
        fields: [
          { name: "RowId" },
        ]
      },
      {
        name: "fk_OrderId_in_orderitem_table",
        using: "BTREE",
        fields: [
          { name: "OrderId" },
        ]
      },
      {
        name: "fk_ProductId_in_orderitem_table",
        using: "BTREE",
        fields: [
          { name: "ProductId" },
        ]
      },
    ]
  });
};
