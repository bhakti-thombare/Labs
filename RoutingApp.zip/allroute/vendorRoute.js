const express = require('express');
const cors = require('cors');
const Dal = require('./../dal/Ecomdal');

let instance = express();

instance.use(express.urlencoded({extended:false}));
instance.use(express.json());
instance.use(cors());

let vendorObj = new Dal('vendor');


instance.get('/api/vendor', vendorObj.getAllData);
instance.get('/api/vendor/:id', vendorObj.getAllDataById);
instance.post('/api/vendor/', vendorObj.createRecord);
instance.put('/api/vendor/:id', vendorObj.UpdateRecord);
instance.delete('/api/vendor/:id', vendorObj.DeleteById);


instance.listen(9012,()=>{
    console.log('server started on port 9012');
});