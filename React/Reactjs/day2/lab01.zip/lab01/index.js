// ReactDOM.render(<h2>Hi, Welcome To Blazeclan</h2>,document.getElementById("root"))

// const root = ReactDOM.createRoot(document.getElementById("root"))
// root.render(<h1>Hello Clans!!</h1>)

ReactDOM.createRoot(document.getElementById("root")).render(<h1>Welcome to React!!</h1>)