import { Component, OnInit, ViewChildren, ElementRef, QueryList } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { SetupService } from '../setup.service';
import { TreeModule } from 'primeng/tree';
import * as _ from 'lodash';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { UserinfoService } from 'src/app/configuration/userinfo.service';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';
import { SuggestionService } from 'src/app/suggestion/suggestion.service';


@Component({
  selector: 'app-subcommittee',
  templateUrl: './subcommittee.component.html',
  styleUrls: ['./subcommittee.component.css']
})
export class SubcommitteeComponent implements OnInit {
  selectedCoordinators: any = [];
  selectedLeaders: any = [];
  cols: any[];
  selectedLeaderIds: any;
  selectedCoordinatorIds: any;
  subCommitteeLeaderLists: any = [];
  subCommitteeCoordinatorLists: any = [];
  subcommittees = [];
  paginationDetails: any;
  submitted: Boolean = false;
  subComitteeNames = [];
  // status:Boolean=false;
  displayAddSubCommitteeDialog: Boolean;
  displayUpdateSubCommitteeDialog: Boolean;
  addSubCommitteeform: FormGroup;
  updateSubCommitteeData: any;
  totalSubCommittees: any;
  updateSubCommitteeform: FormGroup;
  subCommitteeLeaders = [];
  subCommitteeCoordinators = [];
  updatedLeaderSel = [];
  updatedCoordinatorSel = [];
  uniqList = [];
  uniqCoList = [];
  dropdowns: any[];
  leaderDropdowns: any[];
  CoOrdinatorDropdowns: any[];
  selectedSubCommitteeLeaders: [];
  selectedSubCommitteeCoOrdinators: [];
  update = false;
  dropdownSettings = {};
  dropdownSettingsCoord = {};
  dropdownSettingsName = {};
  files = [];
  loading = true;
  subCommitteeLoading = false;
  nameLoading = false;
  leaderLoading = false;
  coOrdinatorLoading = false;
  searchForm: FormGroup;
  searchCommittee = false;
  alreadyCreated = false;


  constructor(private formBuilder: FormBuilder, private setupService: SetupService,
    private userInfo: UserinfoService, private msAdalService: MsAdalAngular6Service, private messageService: MessageService,
    private excelService: ExcelService,
    private suggestionService: SuggestionService) { }

  ngOnInit() {
    // this.getSubCommitteeCoordinatorList();
    // this.getSubCommitteeLeadersList();
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm = this.formBuilder.group({
      userName: ['', Validators.required]
    });
    this.getSubCommitteesColumns();
    this.getSubCommittees(this.paginationDetails);
    this.initializeAddSubCommitteeForm();
    this.initializeUpdateSubCommitteeForm();
    this.getSubCommitteeNames();
    this.getTotalNumberOfSubCommittee();
    this.getSubCommitteeLeadersList();
    this.getSubCommitteeCoordinatorList();
    this.dropSettings();
    // const userId = this.msAdalService.userInfo.userName.split('@')[0];
    // this.getUserInfo(userId);
  }

  dropSettings() {
    this.dropdownSettings = {
      singleSelection: false,
      text: 'Choose Sub Committee Leader',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsCoord = {
      singleSelection: false,
      text: 'Choose Sub Committee Co-ordinator',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsName = {
      singleSelection: true,
      text: 'Choose Sub Committee Name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };
  }

  search() {
    this.searchCommittee = true;
    this.setupService.get(`Admin/SearchFromName/${this.paginationDetails.pageNumber}/${this.paginationDetails.pageSize}?queryString=${this.searchForm.value.userName}&searchFor=subcommittee`)
      .subscribe(res => {
        console.log(res);
        this.totalSubCommittees = res.item1;
        this.subcommittees = res.item2;
      });
  }

  reset() {
    this.searchCommittee = false;
    const pagination = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm.reset();
    this.getTotalNumberOfSubCommittee();
    this.getSubCommittees(pagination);
  }

  OnSubcommitteeNameSelect(e) {
    console.log(e);
    let subcommittees = [];
    if (!this.update) {
      this.setupService.getSubCommittees({ pageNumber: -1, pageSize: -1 })
        .subscribe(res => {
          console.log(res);
          subcommittees = res;
          const index = _.findIndex(subcommittees, (d) => d['subcommitteeNameTitle'] === e.id);
          if (index != -1) {
            this.setupService.getSubCommitteeById(subcommittees[index].id)
              .subscribe(res => {
                console.log(res);
                if (res['status'] == true) {
                  this.alreadyCreated = true;
                } else {
                  this.alreadyCreated = false;
                }
              });
          }
        });
    }
  }


  onSubCommitteePageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };

    if (this.searchCommittee) {
      this.search();
    } else {
      console.log('------Pagination Details After Page Change-----', this.paginationDetails);
      this.getSubCommittees(this.paginationDetails);
    }
  }

  /* onStatusChange(value){
    this.status=value;
  } */




  initializeAddSubCommitteeForm() {
    this.addSubCommitteeform = this.formBuilder.group({
      subcommitteeNameTitle: [null, Validators.required],
      subcommitteeLeaderName: [null],
      subCommitteeCoOrdinator: [null],
      status: [true],


    });
  }
  initializeUpdateSubCommitteeForm() {
    this.updateSubCommitteeform = this.formBuilder.group({
      subcommitteeNameTitle: [null, Validators.required],
      subcommitteeLeaderName: [null, Validators.required],
      subCommitteeCoOrdinator: [null, Validators.required],
      status: [],

    });
  }

  updateSubCommittee(subCommittee) {

    const subcommitteeData = this.updateSubCommitteeform.value;
    subcommitteeData.id = subCommittee.id;


    const idLeaderArr = [];
    for (let i = 0; i < this.updatedLeaderSel.length; i++) {
      idLeaderArr[i] = '' + this.updatedLeaderSel[i];
    }
    subcommitteeData.subcommitteeLeaderName = idLeaderArr;



    const idCoOrdinatorArr = [];
    for (let i = 0; i < this.updatedCoordinatorSel.length; i++) {
      idCoOrdinatorArr[i] = '' + this.updatedCoordinatorSel[i];
    }
    subcommitteeData.subCommitteeCoOrdinator = idCoOrdinatorArr;


    this.setupService.updateSubCommittee(subcommitteeData).subscribe((res: any[]) => {

      this.displayAddSubCommitteeDialog = false;
      this.update = false;
      this.getSubCommittees(this.paginationDetails);
      console.log('SubCommittee Updated Successfully');
    },
      err => {
        console.log('Error occured in update Sub-Committee:', err);
        this.update = false;
      });
  }

  get formFields() { return this.addSubCommitteeform.controls; }

  addSubCommittee() {
    this.submitted = true;
    this.loading = true;
    if (this.addSubCommitteeform.invalid) {
      this.loading = false;
      return this.addSubCommitteeform.value.actionPerformed = 'null';
    } else {

      if (this.update) {
        const subcommitteeData = this.addSubCommitteeform.value;
        console.log('subcommitteeData', subcommitteeData);
        subcommitteeData.id = this.updateSubCommitteeData.id;

        const leaderData = this.addSubCommitteeform.controls.subcommitteeLeaderName.value;
        console.log('leaderData', leaderData);
        const idLeaderArr = [];
        if (subcommitteeData.subcommitteeLeaderName != null) {
          for (let i = 0; i < leaderData.length; i++) {
            idLeaderArr[i] = '' + leaderData[i].id;
          }
          subcommitteeData.subcommitteeLeaderName = idLeaderArr;
        }


        const coordinatorData = this.addSubCommitteeform.controls.subCommitteeCoOrdinator.value;
        console.log('coordinatorData', coordinatorData);
        const idCoOrdinatorArr = [];
        if (coordinatorData != null) {
          for (let i = 0; i < coordinatorData.length; i++) {
            idCoOrdinatorArr[i] = '' + coordinatorData[i].id;
          }
          subcommitteeData.subCommitteeCoOrdinator = idCoOrdinatorArr;
        }

        subcommitteeData.subcommitteeNameTitle = subcommitteeData.subcommitteeNameTitle[0].itemName;
        subcommitteeData.unitId = '' + sessionStorage.getItem('unitId');

        this.setupService.updateSubCommittee(subcommitteeData).subscribe((res: any[]) => {
          this.displayAddSubCommitteeDialog = false;
          this.update = false;
          this.setupService.get(`SubCommittee/GetSubcommitteeWithTitle/${subcommitteeData.unitId}/${subcommitteeData.subcommitteeNameTitle}`)
            .subscribe(res1 => {
              console.log(res1);

              for (let i = 0; i < res1.length; i++) {
                res1[i].unitId = sessionStorage.getItem('unitId')
              }
              // const updateLeaderObj = {
              //   'id': 547,
              //   'teamLeader': '',
              //   'teamId': '',
              //   'unitId': sessionStorage.getItem('unitId'),
              //   'subComitteeModuleName': res1.subComitteeModuleName,
              //   'subcommitteeNameTitle': res1.subcommitteeNameTitle,
              //   'subCommitteeCoOrdinator': res1.subCommitteeCoOrdinator,
              //   'subcommitteeLeaderName': res1.subcommitteeLeaderName
              // }
              this.setupService.teamActivitiesPost(`updateLeadersFromMaster`, res1)
                .subscribe(res2 => {
                  console.log(res2);
                });
                this.suggestionService.teamActivitiesPost(`suggestion/updateLeadersFromMaster`, res1)
                .subscribe(res2 => {
                  console.log(res2);
                });
            });
          this.getSubCommittees(this.paginationDetails);
          console.log('SubCommittee Updated Successfully');
          this.loading = false;
          this.messageService.add({ severity: 'success', summary: `Sub-committee`, detail: 'updated Successfully' });
        },
          err => {
            this.loading = false;
            console.log('Error occured in update Sub-Committee:', err);
            this.update = false;
          });
      } else {
        const subData = this.addSubCommitteeform.value;
        const idArray = [];
        if (subData.subcommitteeLeaderName != null) {
          for (let i = 0; i < subData.subcommitteeLeaderName.length; i++) {
            idArray[i] = '' + subData.subcommitteeLeaderName[i].id;
          }
          subData.subcommitteeLeaderName = idArray;
        }


        const coOrdinatorIdArray = [];
        if (subData.subCommitteeCoOrdinator != null) {
          for (let i = 0; i < subData.subCommitteeCoOrdinator.length; i++) {
            coOrdinatorIdArray[i] = '' + subData.subCommitteeCoOrdinator[i].id;
          }
          subData.subCommitteeCoOrdinator = coOrdinatorIdArray;
        }

        subData.subcommitteeNameTitle = subData.subcommitteeNameTitle[0].itemName;
        subData.unitId = '' + sessionStorage.getItem('unitId');

        this.setupService.addSubCommittee(subData).subscribe((res: any[]) => {
          this.addSubCommitteeform.value.actionPerformed = 'submit';
          this.displayAddSubCommitteeDialog = false;
          this.getSubCommittees(this.paginationDetails);
          this.getTotalNumberOfSubCommittee();
          this.loading = false;
          this.messageService.add({ severity: 'success', summary: `Sub-committee`, detail: 'added Successfully' });
          console.log('SubCommittee Saved Successfully');
        }, err => {
          this.loading = false;
          console.log('Error occured in add SubCommittee:', err);
        });
      }
    }

  }

  getSubCommitteeById(id) {
    this.setupService.getSubCommitteeById(id).subscribe((res: any) => {
      this.updateSubCommitteeData = res;
      console.log('this.updateSubCommitteeData', this.updateSubCommitteeData);
      const subcommitteeLeaderName = res.subcommitteeLeaderName;
      const selectedLeader = [];
      const subCommitteeCoOrdinator = res.subCommitteeCoOrdinator;
      const selectedCoordinator = [];
      console.log(subcommitteeLeaderName);
      this.addSubCommitteeform.patchValue({
        status: res.status
      });
      // const indexRole = _.findIndex(this.subComitteeNames, (d) => d === res.subcommitteeNameTitle);

      if (subcommitteeLeaderName != null) {
        for (let i = 0; i < subcommitteeLeaderName.length; i++) {
          const index = _.findIndex(this.subCommitteeLeaderLists, (d) => d['itemName'] === subcommitteeLeaderName[i]);
          console.log(index);
          if (index != -1) {
            selectedLeader.push(this.subCommitteeLeaderLists[index]);
          }
        }


        this.addSubCommitteeform.patchValue({
          subcommitteeLeaderName: selectedLeader
        });

      }

      if (subCommitteeCoOrdinator != null) {
        for (let i = 0; i < subCommitteeCoOrdinator.length; i++) {
          const index = _.findIndex(this.subCommitteeCoordinatorLists, (d) => d['itemName'] === subCommitteeCoOrdinator[i]);
          console.log(index);
          if (index != -1) {
            selectedCoordinator.push(this.subCommitteeCoordinatorLists[index]);
          }
        }
        this.addSubCommitteeform.patchValue({
          subCommitteeCoOrdinator: selectedCoordinator
        });
      }

      const selectedTitle = [];
      const indexTitle = _.findIndex(this.subComitteeNames, (d) => d['itemName'] === this.updateSubCommitteeData.subcommitteeNameTitle);
      console.log(indexTitle);
      if (indexTitle != -1) {
        selectedTitle.push(this.subComitteeNames[indexTitle]);
      }

      this.addSubCommitteeform.patchValue({
        subcommitteeNameTitle: selectedTitle
      });
    });
  }
  getSubCommitteeNames() {
    this.nameLoading = true;
    this.setupService.getSubCommitteeNames().subscribe((res: any[]) => {
      console.log('res', res);
      // this.subComitteeNames = res;

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index], id: res[index] });
      }

      console.log('newData', newData);
      this.subComitteeNames = this.subComitteeNames.concat(newData);
      console.log('----SubCommittees-----', this.subComitteeNames);
      this.nameLoading = false;
      this.loadOninit();
    }, err => {
      console.log('error occured in SubCommittees');
      this.nameLoading = false;
      this.loadOninit();
    }
    );
  }
  getTotalNumberOfSubCommittee() {
    this.setupService.getTotalNumberOfSubCommittee().subscribe((data) => {
      this.totalSubCommittees = data;
      console.log('------------total SubCommittees---------', this.totalSubCommittees);
    }
    );
  }

  /* --------------------------------------SubCommitte Leader List------------------- */

  getSubCommitteeLeadersList() {
    this.leaderLoading = true;
    this.setupService.getSubCommitteeLeadersList().subscribe((res: any[]) => {
      // this.subCommitteeLeaders = data.slice(0,10);
      console.log('res', res);
      this.dropdowns = res;
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({ itemName: element.userName, id: element.id });
          this.files.push({ label: element.subcommitteeLeaderName });
        }
      }

      this.subCommitteeLeaderLists = this.subCommitteeLeaderLists.concat(newData);
      this.leaderLoading = false;
      this.loadOninit();
    },
      err => {
        console.log('Error occured in get Subcommitte Leaders List:', err);
        this.leaderLoading = false;
        this.loadOninit();
      });

  }
  /* -----------------------------------SubCommitte Coordinator List------------------------------- */
  getSubCommitteeCoordinatorList() {
    this.coOrdinatorLoading = true;
    this.setupService.getSubCommitteeCoordinatorList().subscribe((res: any[]) => {
      console.log('res', res);
      this.CoOrdinatorDropdowns = res;
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({ itemName: element.userName, id: element.id });
        }
      }

      this.subCommitteeCoordinatorLists = this.subCommitteeCoordinatorLists.concat(newData);
      this.coOrdinatorLoading = false;
      this.loadOninit();
    },
      err => {
        console.log('Error occured in get Subcommitte coordinator List:', err);
      });

  }

  getSubCommitteesColumns() {
    this.cols = [
      { field: 'id', header: 'ID' },
      { field: 'subcommitteeNameTitle', header: 'Sub-Committee Name' },
      { field: 'subcommitteeLeaderName', header: 'Sub-Committee Leader' },
      { field: 'subCommitteeCoOrdinator', header: 'Sub-Committee Coordinator' },
      { field: 'action', header: 'Actions' },
      { field: 'status', header: 'Status' }
    ];
  }

  getSubCommittees(paginationDetails) {
    this.subCommitteeLoading = true;
    this.searchCommittee = false;
    this.setupService.getSubCommittees(paginationDetails).subscribe((res: any[]) => {
      this.subcommittees = res;
      this.subCommitteeLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in get functions:', err);
      this.subCommitteeLoading = false;
      this.loadOninit();
    });
  }

  showAddSubCommitteeDialog() {
    this.displayAddSubCommitteeDialog = true;
    this.submitted = false;
    this.initializeAddSubCommitteeForm();
    // this.status=false;
  }

  cancelAddSubCommitteeDialog() {
    this.displayAddSubCommitteeDialog = false;
    this.addSubCommitteeform.reset();
    this.update = false;
    this.alreadyCreated = false;
    //  this.status=false;


  }
  showUpdateSubCommitteeDialog(id: any) {
    this.getSubCommitteeById(id);
    this.submitted = false;
    this.displayAddSubCommitteeDialog = true;
    this.update = true;
  }
  cancelUpdateSubCommitteeDialog() {
    this.displayAddSubCommitteeDialog = false;
  }

  selectLeader(e) {
    console.log(e);
    this.selectedLeaderIds = e.value;
  }

  selectCoOrdinator(e) {
    console.log(e);
    this.selectedCoordinatorIds = e.value;
  }

  updateSelectLeader(e) {
    console.log(e);
    this.updatedLeaderSel.push(e.itemValue);
    console.log(this.updatedLeaderSel);

  }

  getUserInfo(userId) {
    this.setupService
      .getWithParam('RpmMapping/GetRpmMappingForEmployee/username', userId)
      .subscribe((res: any) => {
        console.log('res', res);
        // this.kaizenService.storeUnitId(res.item2.unitId);
        this.userInfo.roleName = res.item1;
        this.userInfo.userData = res.item2;
        // this.loggedInData = res.item2;
        // this.GetRoleBasedData();
        console.log(this.userInfo.userData.unitId);
      }, (err) => {
        console.log('err', err);
      });
  }

  updateSelectCoOrdinator(e) {
    console.log(e);
    this.updatedCoordinatorSel.push(e.itemValue);
    console.log(this.updatedCoordinatorSel);
  }

  loadOninit() {
    if (!this.subCommitteeLoading && !this.nameLoading && !this.leaderLoading && !this.coOrdinatorLoading) {
      this.loading = false;
    }
  }

  exportAsXLSX() {
    if (this.subcommittees.length > 0) {
      this.excelService.exportAsExcelFile(this.subcommittees, 'sample');
    }
  }

}


