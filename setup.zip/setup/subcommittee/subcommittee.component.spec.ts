import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubcommitteeComponent } from './subcommittee.component';

describe('SubcommitteeComponent', () => {
  let component: SubcommitteeComponent;
  let fixture: ComponentFixture<SubcommitteeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SubcommitteeComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubcommitteeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
