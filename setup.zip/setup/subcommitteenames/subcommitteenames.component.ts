import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-subcommitteenames',
  templateUrl: './subcommitteenames.component.html',
  styleUrls: ['./subcommitteenames.component.css']
})
export class SubcommitteenamesComponent implements OnInit {
  cols: any = [];
  committees: any = [];
  paginationDetails: any;
  // status:Boolean=false;
  submitted: Boolean = false;
  updateMasterSubCommitteesNamesData: any;
  totalMasterSubCommitteeNames: any;
  addSubCommitteeNamesForm: FormGroup;
  updateSubCommitteeNamesForm: FormGroup;
  displayAddSubCommitteeNamesDialog: Boolean;
  displayUpdateSubCommitteeNamesDialog: Boolean;
  isPowerUser: boolean = false;
  constructor(private fb: FormBuilder, private setupService: SetupService
    , private messageService: MessageService) { }

  ngOnInit() {
    this.getUserRole();
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.getTotalCountOfMasterSubCommitteesNames();
    this.getSubCommitteesColumns();
    this.getMasterSubCommittees(this.paginationDetails);
    this.initializeAddSubCommitteeNames();
    this.initializeUpdateFunctionNames();
  }
  initializeAddSubCommitteeNames() {
    this.addSubCommitteeNamesForm = this.fb.group({
      subcommitteeNameTitle: ['', Validators.required],
      status: [true, Validators.required],
    });
  }
  getUserRole() {
    let userRole = sessionStorage.getItem('userRole');
    if (userRole == 'Power User') {
      this.isPowerUser = true;
    }
    this.getSubCommitteesColumns();

  }

  initializeUpdateFunctionNames() {
    this.updateSubCommitteeNamesForm = this.fb.group({
      subcommitteeNameTitle: ['', Validators.required],
      status: [null, Validators.required],

    });
  }

  onSubCommitteeNamesPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows,
    };
    console.log('-------------------pagination Details-----------------', this.paginationDetails);
    this.getMasterSubCommittees(this.paginationDetails);

  }

  get formFields() { return this.addSubCommitteeNamesForm.controls; }

  get editFormFields() { return this.updateSubCommitteeNamesForm.controls; }

  addMasterSubCommitteeNames() {
    this.submitted = true;
    if (this.addSubCommitteeNamesForm.invalid) {
      return this.addSubCommitteeNamesForm.value.actionPerformed = null;
    } else {
      let addSubCommitteeNameData = this.addSubCommitteeNamesForm.value;
      // addSubCommitteeNameData.status=this.status;
      this.setupService.addMasterSubCommitteeNames(addSubCommitteeNameData).subscribe((res: any[]) => {
        this.addSubCommitteeNamesForm.value.actionPerformed = 'Submit';

        this.displayAddSubCommitteeNamesDialog = false;
        // this.status=false;
        this.getTotalCountOfMasterSubCommitteesNames();
        this.getMasterSubCommittees(this.paginationDetails);
        this.messageService.add({ severity: 'success', summary: `Sub-committee`, detail: 'added Successfully' });
        console.log('Add Sub Committee Names Successfully');
      }, err => {
        console.log('Error occured in add Sub Committee:', err);
      });
    }
  }


  /* Update Suvb Committees */
  updateMasterSubCommitteeNames(subCommittee) {
    this.submitted = true;
    if (this.updateSubCommitteeNamesForm.invalid) {
      return this.updateSubCommitteeNamesForm.value.actionPerformed = 'null';
    } else {
      let subCommitteeNamesData = this.updateSubCommitteeNamesForm.value;
      subCommitteeNamesData.id = subCommittee.id;
      this.setupService.updateMasterSubCommitteeNames(subCommitteeNamesData).subscribe((res: any[]) => {
        this.displayUpdateSubCommitteeNamesDialog = false;
        this.getMasterSubCommittees(this.paginationDetails);
        this.messageService.add({ severity: 'success', summary: `Sub-committee`, detail: 'updated Successfully' });
        console.log('Sub Committee Names Updated Successfully');
      }, err => {
        console.log('Error occured in update Sub Committee Names:', err);
      });
    }
  }


  getSubCommitteesColumns() {

    if (sessionStorage.getItem('userRole') != "Power User") {
      this.cols = [
        { field: 'subcommitteeNameTitle', header: 'Sub-Committee Name' },
        { field: 'action', header: 'Actions' },
        { field: 'status', header: 'Status' }

      ]
    } else {
      this.cols = [
        { field: 'subcommitteeNameTitle', header: 'Sub-Committee Name' },

        { field: 'status', header: 'Status' }
      ];

    }
  }

  getMasterSubCommittees(paginationDetails) {
    this.setupService.getMasterSubCommittees(paginationDetails).subscribe((res: any[]) => {
      this.committees = res;
    }, err => {
      console.log('Error occured in get function names:', err);
    });
  }

  /* --------------------------------------Get Name Master Sub-Committee Total Count----------------------------*/
  getTotalCountOfMasterSubCommitteesNames() {
    this.setupService.getTotalCountOfMasterSubCommitteesNames().subscribe((data) => {
      this.totalMasterSubCommitteeNames = data;
      console.log('---------------Total Count Of Master Subcommitte Names----------', this.totalMasterSubCommitteeNames);
    }, err => {
      console.log('error in Total County Of MAsterr Subcommitte Names', err);
    });
  }

  /* --------------------------------------------------Get Name Master Sub-Committee By Id ----------------------*/
  getMasterSubCommitteesNamesById(id) {
    this.setupService.getMasterSubCommitteesNamesById(id).subscribe((res: any[]) => {
      this.updateMasterSubCommitteesNamesData = res;
      console.log('-----Id Of Functin Names', this.updateMasterSubCommitteesNamesData);
    }, err => {
      console.log('error in id of function Names', err);
    });
  }

  cancelAddSubComitteeNamesDialog() {
    this.displayAddSubCommitteeNamesDialog = false;
    this.submitted = false;
    this.addSubCommitteeNamesForm.controls['subcommitteeNameTitle'].reset()
  }

  showAddSubComitteeNamesDialog() {
    this.displayAddSubCommitteeNamesDialog = true;
    this.submitted = false;
    this.addSubCommitteeNamesForm.controls['subcommitteeNameTitle'].reset()
  }

  cancelUpdateSubComitteeDialog() {
    this.displayUpdateSubCommitteeNamesDialog = false;
    this.updateSubCommitteeNamesForm.reset();
  }

  showUpdateSubComitteeDialog(id: any) {
    this.submitted = false;
    this.getMasterSubCommitteesNamesById(id);
    this.displayUpdateSubCommitteeNamesDialog = true;
  }
}
