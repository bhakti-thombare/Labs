import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubcommitteenamesComponent } from './subcommitteenames.component';

describe('SubcommitteenamesComponent', () => {
  let component: SubcommitteenamesComponent;
  let fixture: ComponentFixture<SubcommitteenamesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SubcommitteenamesComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubcommitteenamesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
