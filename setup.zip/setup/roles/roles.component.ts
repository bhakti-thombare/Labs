import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { MessageService } from 'primeng/api';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { KaizenService } from 'src/app/kaizen/kaizen.service';
import { ExcelService } from 'src/app/shared/excel.service';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})
export class RolesComponent implements OnInit {
  cols: any = [];
  roles: any = [];
  totalRoles: any;
  updateRoleData: any;
  displayAddRoleDialog: Boolean;
  displayUpdateRoleDialog: Boolean;
  addRoleForm: FormGroup;
  submitted: Boolean = false;
  status: Boolean = false;
  updateRoleForm: FormGroup;
  paginationDetails: any;
  update = false;
  loading = true;
  userRole: any;
  isPowerUser = true;
  systemLevel: any;
  constructor(private fb: FormBuilder, private setupService: SetupService,
    private messageService: MessageService,
    private msAdalService: MsAdalAngular6Service,
    private kaizenService: KaizenService,
    private excelService: ExcelService) { }

  ngOnInit() {
    this.getUserRole();
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };


    this.getRoles(this.paginationDetails);
    this.initializeAddRoleForm();
    this.initializeUpdateRoleForm();
    this.getTotalNumberOfRoles();
    // this.getRoleColumns();
  }

  get formFields() { return this.addRoleForm.controls; }

  get editFormFields() { return this.updateRoleForm.controls; }


  onRolePageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    console.log('----pagination details----------', this.paginationDetails);
    this.getRoles(this.paginationDetails);
  }

  onStatusChange(value) {
    this.status = value;
  }

  onSystemLevelChange(value) {
    this.systemLevel = value;
  }
  getUserRole() {
    const userId = this.msAdalService.userInfo.userName.split('@')[0];
    this.getUserInfo(userId);
  }

  getUserInfo(userId) {
    this.kaizenService
      .getWithParam(
        'RpmMapping/GetRpmMappingForEmployee/username',
        userId,
        'admin'
      )
      .subscribe((res: any) => {
        this.userRole = res.item1;
        console.log('res 111111', res.item1);
        if (this.userRole == 'Power User') {
          this.isPowerUser = false;
        }
        this.getRoleColumns();
      });
  }



  initializeAddRoleForm() {
    this.addRoleForm = this.fb.group({
      roleName: ['', Validators.required],

    });
  }
  initializeUpdateRoleForm() {
    this.updateRoleForm = this.fb.group({
      roleName: ['', Validators.required],

    });
  }
  /* -------------------------------------------------Add Role -------------------------------------------------------*/
  addRole() {
    this.submitted = true;
    this.loading = true;
    if (this.addRoleForm.invalid) {
      this.loading = false;
      return this.addRoleForm.value.actionPerformed = 'null';
    } else {
      if (this.update) {
        const roleData = this.addRoleForm.value;
        roleData.RoleId = this.updateRoleData.roleId;
        roleData.status = this.status;
        roleData.SystemLevel = this.systemLevel;
        this.setupService.updateRole(roleData).subscribe((res: any[]) => {
          this.update = false;
          this.displayAddRoleDialog = false;
          this.getRoles(this.paginationDetails);
          this.loading = false;
          this.messageService.add({ severity: 'success', summary: `Role`, detail: 'updated Successfully' });
          console.log('Role Updated Successfully');
        }, err => {
          this.loading = false;
          console.log('Error occured in update role:', err);
        });

      } else {
        const roleData = this.addRoleForm.value;
        roleData.status = this.status;
        roleData.SystemLevel = this.systemLevel;
        this.setupService.addRole(roleData).subscribe((res: any[]) => {
          this.displayAddRoleDialog = false;
          this.getTotalNumberOfRoles();
          this.getRoles(this.paginationDetails);
          this.loading = false;
          this.messageService.add({ severity: 'success', summary: `Role`, detail: 'added Successfully' });
          console.log('Role Saved Successfulluy');
        }, err => {
          this.loading = false;
          console.log('Error occured in add role:', err);
        });
      }
    }

  }
  /* -----------------------------------------------------Update Role -------------------------------------------------*/
  // updateRole(role) {
  //   this.submitted = true;
  //   if (this.updateRoleForm.invalid) {
  //     return this.updateRoleForm.value.actionPerformed = 'null';
  //   } else {
  //     let roleData = this.updateRoleForm.value;
  //     roleData.RoleId = role.roleId;
  //     roleData.status = this.status;
  //     this.setupService.updateRole(roleData).subscribe((res: any[]) => {
  //       this.update = false;
  //       this.displayAddRoleDialog = false;
  //       this.getRoles(this.paginationDetails);
  //       console.log('Role Updated Successfully');
  //     }, err => {
  //       console.log('Error occured in update role:', err);
  //     });
  //   }
  // }



  getRoleColumns() {
    if (this.userRole != 'Power User') {
      this.cols = [
        { field: 'roleName', header: 'Role' },
        { field: 'action', header: 'Actions' },
        { field: 'status', header: 'Status' }
      ];
    } else {
      this.cols = [
        { field: 'roleName', header: 'Role' },
        { field: 'status', header: 'Status' }
      ];

    }


  }

  /* ---------------------------------------------------Get Roles----------------------------- */
  getRoles(paginationDetails) {
    this.setupService.getRoles(paginationDetails).subscribe((res: any[]) => {
      this.roles = res;
      console.log('---roles---', res);
      this.loading = false;
    }, err => {
      console.log('Error occured in get roles:', err);
      this.loading = false;
    });
  }


  /* ---------------------------------------------------------Get Total No Of Roles------------------------- */
  getTotalNumberOfRoles() {
    this.setupService.getTotalNumberOfRoles().subscribe((data) => {
      this.totalRoles = data;
      console.log('---------------Number of Roles-------', this.totalRoles);
    });
  }
  /* -----------------------------------------------------------Get Role By Id-------------------------------- */
  getRoleById(id) {
    this.setupService.getRoleById(id).subscribe((res: any) => {
      this.updateRoleData = res;
      this.addRoleForm.patchValue(res);
      this.status = res.status;
      this.systemLevel = res.systemLevel;
      console.log('--------------role details-------', this.updateRoleData);
    }, err => {
      console.log('error in the role id status', err);
    });
  }




  cancelAddRoleDialog() {
    this.displayAddRoleDialog = false;
    this.addRoleForm.reset();
    this.submitted = false;
    this.update = false;

  }

  showAddRoleDialog() {
    this.displayAddRoleDialog = true;
    this.submitted = false;
    this.status = false;

  }

  cancelUpdateRoleDialog() {
    this.displayAddRoleDialog = false;
    this.updateRoleForm.reset();
  }

  showUpdateRoleDialog(id: any) {
    this.submitted = false;
    this.getRoleById(id);
    this.update = true;
    this.displayAddRoleDialog = true;
  }

  exportAsXLSX() {
    if (this.roles.length > 0) {
      this.excelService.exportAsExcelFile(this.roles, 'sample');
    }
  }

}
