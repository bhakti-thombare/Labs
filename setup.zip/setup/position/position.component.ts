import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';

@Component({
  selector: 'app-position',
  templateUrl: './position.component.html',
  styleUrls: ['./position.component.css']
})
export class PositionComponent implements OnInit {
  cols: any = [];
  status: Boolean = false;
  submitted: Boolean = false;
  paginationDetails: any;
  positions: any = [];
  positionAddForm: FormGroup;
  updatePositionForm: FormGroup;
  displayAddPositionDialog: Boolean;
  totalPosition: any;
  displayUpdatePositionDialog: Boolean;
  updatePositionData: any;
  update = false;
  loading = true;
  isPowerUser:boolean=false;

  constructor(private fb: FormBuilder, private setupService: SetupService, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {
    this.getUserRole()
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    
    this.getPositions(this.paginationDetails);
    this.initializeAddPositionForm();
    this.getTotalNumberOfPosition();
    this.initializeUpdatePositionForm();
  }
  getUserRole(){
    let userRole= sessionStorage.getItem('userRole');
    if(userRole=="Power User"){
      this.isPowerUser=true;
    }
    this.getPositionColumns();

  }

  onPositionPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows,
    };
    console.log('-------------pagination Details-----------', this.paginationDetails);
    this.getPositions(this.paginationDetails);
  }

  onStatusChange(value) {
    this.status = value;
  }

  get formFields() { return this.positionAddForm.controls; }


  get editFormFields() { return this.updatePositionForm.controls; }

  initializeAddPositionForm() {
    this.positionAddForm = this.fb.group({
      positionName: ['', Validators.required],
    });
  }



  initializeUpdatePositionForm() {
    this.updatePositionForm = this.fb.group({
      positionName: ['', Validators.required],
    });
  }
  /* -----------------------------------------------------Add position --------------------------------------------------*/
  addPosition() {
    this.submitted = true;
    this.loading = true;
    if (this.positionAddForm.invalid) {
      this.loading = false;
      return this.positionAddForm.value.actionPerformed = null;
    } else {
      if (this.update) {
        const positionData = this.positionAddForm.value;
        positionData.PositionId = this.updatePositionData.positionId;
        positionData.status = this.status;
        this.setupService.updatePosition(positionData).subscribe((res: any[]) => {
          this.updatePositionForm.value.actionPerformed = 'submit';
          this.displayAddPositionDialog = false;
          this.update = false;
          this.getPositions(this.paginationDetails);
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `Position`, detail: 'updated Successfully'});
          console.log('Position Updated Successfulluy');
        }, err => {
          this.loading = false;
          console.log('Error occured in update position:', err);
        });
      } else {
        const positionData = this.positionAddForm.value;
        positionData.status = this.status;
        this.setupService.addPosition(positionData).subscribe((res: any[]) => {
          this.positionAddForm.value.actionPerformed = 'Submit';
          this.displayAddPositionDialog = false;
          this.status = false;
          this.getTotalNumberOfPosition();
          this.getPositions(this.paginationDetails);
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `Postion`, detail: 'added Successfully'});
          console.log('Position Saved Successfulluy');
        }, err => {
          this.loading = false;
          console.log('Error occured in add position:', err);
        });
      }
    }
  }
  /* -------------------------------------------------------Update Position -------------------------------------*/

  // updatePosition(position) {
  //   this.submitted = true;
  //   if (this.updatePositionForm.invalid) {
  //     return this.updatePositionForm.value.actionPerformed = null;
  //   }
  //   else {
  //     let positionData = this.updatePositionForm.value;
  //     positionData.PositionId = position.positionId;
  //     positionData.status = this.status;
  //     this.setupService.updatePosition(positionData).subscribe((res: any[]) => {
  //       this.updatePositionForm.value.actionPerformed = 'submit';
  //       this.displayAddPositionDialog = false;
  //       this.update = false;
  //       this.getPositions(this.paginationDetails);
  //       console.log('Position Updated Successfulluy');
  //     }, err => {
  //       console.log('Error occured in update position:', err);
  //     })
  //   }
  // }

  getPositionColumns() {
    if(sessionStorage.getItem('userRole')!='Power User'){
      this.cols = [
        { field: 'positionName', header: 'Position' },
        { field: 'action', header: 'Action' },
        { field: 'status', header: 'Status' },
      ];
    }else{
      this.cols = [
        { field: 'positionName', header: 'Position' },
       
        { field: 'status', header: 'Status' },
      ];
    }
    
  }


  /* ----------------------------------------------------Get Position----------------------------------- */
  getPositions(paginationDetails) {
    this.setupService.getPositions(paginationDetails).subscribe((res: any[]) => {
      this.positions = res;
      this.loading = false;
    }, err => {
      console.log('Error occured in get positions:', err);
      this.loading = false;
    });
  }


  /* ----------------------------------------------------Get Position Count------------------------------- */
  getTotalNumberOfPosition() {
    this.setupService.getTotalNumberOfPosition().subscribe((data) => {
      this.totalPosition = data;
      console.log('--------------Fet Number Of Position------------', this.totalPosition);
    });
  }


  /* ----------------------------------------------Get Position By ID--------------------------- */
  getPositionById(positionId) {
    this.setupService.getPositionById(positionId).subscribe((res: any[]) => {
      this.updatePositionData = res;
      this.positionAddForm.patchValue(res);
      this.status = this.updatePositionData.status;
      console.log('Data To Be Updated', this.updatePositionData);
    }, err => {
    });
  }



  showAddPositionDialog() {
    this.displayAddPositionDialog = true;
    this.positionAddForm.reset();
    this.submitted = false;
    this.status = false;

  }

  cancelAddPositionDialog() {
    this.displayAddPositionDialog = false;
    this.positionAddForm.reset();
    this.status = false;
    this.update = false;

  }

  showUpdatePositionDialog(positionId: any) {
    this.submitted = false;
    this.getPositionById(positionId);
    this.displayAddPositionDialog = true;
    this.update = true;
  }

  cancelUpdatePositionDialog() {
    this.displayAddPositionDialog = false;
    this.updatePositionForm.reset();
  }

  exportAsXLSX() {
    if (this.positions.length > 0) {
      this.excelService.exportAsExcelFile(this.positions, 'sample');
    }
  }
}
