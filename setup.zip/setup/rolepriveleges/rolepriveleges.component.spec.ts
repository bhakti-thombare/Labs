import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RoleprivelegesComponent } from './rolepriveleges.component';

describe('RoleprivelegesComponent', () => {
  let component: RoleprivelegesComponent;
  let fixture: ComponentFixture<RoleprivelegesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RoleprivelegesComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoleprivelegesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
