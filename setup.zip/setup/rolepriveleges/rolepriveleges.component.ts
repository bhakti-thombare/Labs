import { Component, OnInit } from '@angular/core';
import { SetupService } from '../setup.service';
import * as _ from 'lodash';
import { MessageService } from 'primeng/api';
import { UserinfoService } from 'src/app/configuration/userinfo.service';
import { Item } from 'angular2-multiselect-dropdown';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { KaizenService } from 'src/app/kaizen/kaizen.service';

@Component({
  selector: 'app-rolepriveleges',
  templateUrl: './rolepriveleges.component.html',
  styleUrls: ['./rolepriveleges.component.css'],
})
export class RoleprivelegesComponent implements OnInit {
  roles = [];
  rpMapping = [];
  privileges = [];
  role: any;
  roleName: any;
  dropdownSettings = {};
  selectedRole: any;
  userRole: any;

  constructor(
    private setupService: SetupService,
    private messageService: MessageService,
    private userinfo: UserinfoService,
    private msAdalService: MsAdalAngular6Service,
    private kaizenService: KaizenService
  ) {}

  ngOnInit() {
    this.getLoginUserRole();
    this.getRoles();
    this.dropSettings();
  }

  dropSettings() {
    this.dropdownSettings = {
      singleSelection: true,
      text: 'Choose Role',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100,
    };
  }

  //  Get Login userRole for showing dropdown sa per role
  getLoginUserRole() {
    // const userId = this.msAdalService.userInfo.userName.split('@')[0];
    // this.getUserInfo(userId);
    // this.userinfo.roleName;
    // debugger;
    this.userRole = sessionStorage.getItem('userRole')
  }
  getUserInfo(userId) {
    this.kaizenService
      .getWithParam(
        'RpmMapping/GetRpmMappingForEmployee/username',
        userId,
        'admin'
      )
      .subscribe((res: any) => {
        this.userRole = res.item1;
        console.log('res', res.item1);
      });
  }

  getRoles() {
    this.setupService
      .getRoles({ pageNumber: -1, pageSize: -1 })
      .subscribe((res) => {
        console.log('Role as Per Data', res);
        console.log(this.userinfo.roleName);
        // this.roles = res;
        const newData = [];
        for (let index = 0; index < res.length; index++) {
          newData.push({
            itemName: res[index].roleName,
            id: res[index].roleId,
          });
        }
        if (this.userRole == 'Power User') {
          newData.splice(2, 2);
        }

        console.log(newData);

        this.roles = this.roles.concat(newData);
        console.log('this.roles', this.roles);
      });
  }

  updateMapping() {
    this.setupService
      .updateMapping(this.rpMapping, this.role)
      .subscribe((res) => {
        console.log(res);
        this.messageService.add({severity: 'success', summary: `Role Privileges`, detail: 'Updated Successfully'});
        this.getMappingByRole();
      });
  }

  selectRole(e) {
    console.log(e);
    this.selectedRole = [e];
    // const id = e.target.value;
    this.role = e.id;
    const roleIndex = _.findIndex(this.roles, (d) => d.id == this.role);

    this.roleName = this.roles[roleIndex].itemName;

    this.getMappingByRole();
  }

  getMappingByRole() {
    this.setupService.getRpmMappingByRole(this.role).subscribe((res) => {
      console.log('res', res);
      this.rpMapping = res;
      this.privileges = res.privileges;
    });
  }

  checkboxChange(e, i) {
    const key = e.target.value;
    console.log(e);
    console.log(i);
    this.rpMapping[i].privilegeStatus[key] = e.target.checked;
    console.log(this.rpMapping[i]);
  }
}
