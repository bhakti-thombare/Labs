import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { SetupService } from '../setup.service';
import * as _ from 'lodash';
import { UserinfoService } from 'src/app/configuration/userinfo.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';


@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {
  cols: any = [];
  departments: any = [];
  hodListDropdown: any = [];
  displayDepartmentDialog: Boolean;
  displayEditDepartmentDialog: Boolean;
  addDepartmentForm: FormGroup;
  updatedHodSel = [];
  // status:Boolean=false;
  updateDepartmentForm: FormGroup;
  paginationDetails: any;
  submitted: Boolean = false;
  selectedIds: any;
  totalDepartments: any;
  updateDepartmentData: any;
  selectedDepartmentHods: [];
  functionNames: any[];
  departmentNames = [];
  departmentFunctionNames = [];
  uniqList = [];
  dropdowns: any[];
  update = false;
  dropdownSettings: {};
  dropdownSettingsName = {};
  dropdownSettingsFunction = {};
  loading = true;
  departmentLoading = false;
  nameLoading = false;
  hodLoading = false;
  functionLoading = false;
  searchForm: FormGroup;
  searchDepartment = false;
  alreadyCreated = false;


  constructor(private fb: FormBuilder, private setupService: SetupService,
    private userInfo: UserinfoService, private msAdalService: MsAdalAngular6Service, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm = this.fb.group({
      userName: ['', Validators.required]
    });
    this.initializeAddDepartmentForm();
    this.initializeUpdateDepartmentForm();
    this.getDepartmentColumns();
    this.getDepartments(this.paginationDetails);
    this.getTotalNumberOfDepartments();
    this.getDepartmentNames();
    this.getDepartmentHod();
    this.getFunctionNamesForDepartment();
    this.dropSettings();
    // const userId = this.msAdalService.userInfo.userName.split('@')[0];
    // this.getUserInfo(userId);

  }

  dropSettings() {
    this.dropdownSettings = {
      singleSelection: false,
      text: 'Choose HOD',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsName = {
      singleSelection: true,
      text: 'Choose Department Name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsFunction = {
      singleSelection: true,
      text: 'Choose Function Name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };
  }

  search() {
    this.searchDepartment = true;
    this.setupService.get(`Admin/SearchFromName/${this.paginationDetails.pageNumber}/${this.paginationDetails.pageSize}?queryString=${this.searchForm.value.userName}&searchFor=department`)
      .subscribe(res => {
        console.log(res);
        this.totalDepartments = res.item1;
        this.departments = res.item2;
      });
  }

  reset() {

    this.searchDepartment = false;
    const pagination = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm.reset();
    this.getTotalNumberOfDepartments();
    this.getDepartments(pagination);
  }

  // Get kaizens on page change
  onDepartmentPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    if (this.searchDepartment) {
      this.search();
    } else {
      console.log('------Pagination Details After Page Change-----', this.paginationDetails);
      this.getDepartments(this.paginationDetails);
    }
  }

  /* onStatusChange(value){
    this.status=value;
  } */

  get formFields() { return this.addDepartmentForm.controls; }

  get editFormFields() { return this.updateDepartmentForm.controls; }



  getDepartmentNames() {
    this.nameLoading = true;
    this.setupService.getDepartmentNames().subscribe((res: any[]) => {
      // this.departmentNames = res;

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index], id: res[index] });
      }

      console.log('newData', newData);
      this.departmentNames = this.departmentNames.concat(newData);

      console.log('----departments Levels----', this.departmentNames);
      this.nameLoading = false;
      this.loadOninit();

    }, err => {
      console.log('Error occured in get departments:', err);
      this.nameLoading = false;
      this.loadOninit();
    });
  }

  getFunctionNamesForDepartment() {
    this.functionLoading = true;
    this.setupService.getFunctionsNamesForDepartment().subscribe((res: any[]) => {

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index].functionName, id: res[index].id });
      }

      this.departmentFunctionNames = this.departmentFunctionNames.concat(newData);
      console.log('------------Function Names--------', this.departmentFunctionNames);
      this.functionLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Eror occured in get Function Names', err);
      this.functionLoading = false;
      this.loadOninit();
    });
  }

  OnDepartmentNameSelect(e) {
    console.log(e);
    let departments = [];
    if (!this.update) {
      this.setupService.getDepartments({pageNumber: -1, pageSize: -1})
      .subscribe(res => {
        console.log(res);
        departments = res;
      console.log(departments);
      const index = _.findIndex(departments, (d) => d['departmentName'] === e.id);
      console.log('index', index);

      if (index != -1) {
        this.setupService.getDepartmentById(departments[index].id)
          .subscribe(res => {
            console.log(res);
            if (res['status'] == true) {
              this.alreadyCreated = true;
            } else {
              this.alreadyCreated = false;
            }
          });
      }
    });
    }
  }

  getDepartmentHod() {
    this.hodLoading = true;
    this.setupService.getDepartmentHod().subscribe((res: any[]) => {
      console.log('res', res);
      this.dropdowns = res;
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({ itemName: element.userName, id: element.id });
        }
      }

      this.hodListDropdown = this.hodListDropdown.concat(newData);
      console.log('this.hodListDropdown', this.hodListDropdown);
      this.hodLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in getDepartmentHod:', err);
      this.hodLoading = false;
      this.loadOninit();
    });
  }
  /*
    onSelectdepartment(functionname: string, isChecked: boolean) {
      const teamMembersArray = <FormArray>this.addDepartmentForm.controls.functionNames;
      if (isChecked) {
        teamMembersArray.push(new FormControl(functionname));
      } else {
        let index = teamMembersArray.controls.findIndex(x => x.value == functionname)
        teamMembersArray.removeAt(index);
      }
    } */

  getDepartmentById(id) {
    this.setupService.getDepartmentById(id).subscribe((res: any) => {
      this.updateDepartmentData = res;
      this.addDepartmentForm.patchValue({
        status: res.status
      });
      const hod = res.hod;
      console.log(hod);
      const selectedHod = [];

      this.selectedDepartmentHods = res.hod;
      if (hod != null) {
        for (let i = 0; i < hod.length; i++) {
          const index = _.findIndex(this.hodListDropdown, (d) => d['itemName'] === hod[i]);
          console.log(index);
          if (index != -1) {
            selectedHod.push(this.hodListDropdown[index]);
          }
        }
      }

      const selectedName = [];
      const selectedFunction = [];

      const indexName = _.findIndex(this.departmentNames, (d) => d['itemName'] === this.updateDepartmentData.departmentName);
      console.log(indexName);
      selectedName.push(this.departmentNames[indexName]);

      const indexFunction = _.findIndex(this.departmentFunctionNames, (d) => d['id'] == this.updateDepartmentData.functionId);
      console.log(indexFunction);
      if (indexFunction != -1) {
        selectedFunction.push(this.departmentFunctionNames[indexFunction]);
        console.log('selectedName', selectedName);
        this.addDepartmentForm.patchValue({
          functionId: selectedFunction
        });
      }



      this.addDepartmentForm.patchValue({
        hod: selectedHod,
        departmentName: selectedName
      });

      console.log('----Department Details----', this.updateDepartmentData);

    }, err => {
      console.log('Error occured in get getDepartmentById:', err);
    });
  }

  getUserInfo(userId) {
    this.setupService
      .getWithParam('RpmMapping/GetRpmMappingForEmployee/username', userId)
      .subscribe((res: any) => {
        console.log('res', res);
        // this.kaizenService.storeUnitId(res.item2.unitId);
        this.userInfo.roleName = res.item1;
        this.userInfo.userData = res.item2;
        // this.loggedInData = res.item2;
        // this.GetRoleBasedData();
        console.log(this.userInfo.userData.unitId);
      }, (err) => {
        console.log('err', err);
      });
  }

  initializeAddDepartmentForm() {
    this.addDepartmentForm = this.fb.group({
      departmentName: [null, Validators.required],
      hod: [null],
      functionId: [null, Validators.required],
      status: [true],
    });
  }


  initializeUpdateDepartmentForm() {
    this.updateDepartmentForm = this.fb.group({
      departmentName: [null, Validators.required],
      hod: [null, Validators.required],
      function: [null, Validators.required],
      status: [null]
    });
  }

  cancelAddDepartment() {
    this.displayDepartmentDialog = false;
    this.addDepartmentForm.reset();
    this.submitted = false;
    this.alreadyCreated = false;
    // this.status = false;

  }

  cancelUpdateDepartment() {
    this.displayDepartmentDialog = false;
    this.updateDepartmentForm.reset();
  }


  getDepartmentColumns() {
    this.cols = [
      { field: 'id', header: 'ID' },
      { field: 'departmentName', header: 'Department Name' },
      { field: 'hod', header: 'HOD' },
      { field: 'function', header: 'Function' },
      { field: 'action', header: 'Actions' },
      { field: 'status', header: 'Status' }
    ];
  }
  getDepartments(paginationDetails) {
    this.departmentLoading = true;
    this.searchDepartment = false;
    this.setupService.getDepartments(paginationDetails).subscribe((res: any[]) => {
      this.departments = res;
      this.departmentLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in get departments:', err);
      this.departmentLoading = false;
      this.loadOninit();
    });
  }

  getTotalNumberOfDepartments() {
    this.setupService
      .getTotalNumberOfdepartments()
      .subscribe((data) => {
        this.totalDepartments = data;
        console.log('-----totalDepartments-----', this.totalDepartments);

      });
  }



  addDepartment() {

    console.log(this.addDepartmentForm.value);

    this.submitted = true;

    if (this.addDepartmentForm.invalid) {
      this.loading = false;
      return this.addDepartmentForm.value.actionPerformed = null;

    } else {
      this.loading = true;
      if (this.update) {
        const departmentData = this.addDepartmentForm.value;
        departmentData.id = this.updateDepartmentData.id;

        const idArr = [];
        if (departmentData.hod != null) {
          for (let i = 0; i < departmentData.hod.length; i++) {
            idArr[i] = '' + departmentData.hod[i].id;
          }
          departmentData.hod = idArr;
        }
        departmentData.departmentName = departmentData.departmentName[0].id;
        departmentData.functionId = '' + departmentData.functionId[0].id;
        departmentData.unitId = '' + sessionStorage.getItem('unitId');


        // departmentData.status=this.status;
        this.setupService.updateDepartment(departmentData).subscribe((res: any[]) => {
          // this.status=false;
          this.displayDepartmentDialog = false;
          this.getTotalNumberOfDepartments();
          this.update = false;
          this.getDepartments(this.paginationDetails);
          console.log('Department Updated Successfully');
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `${departmentData.departmentName}`, detail: 'Updated Successfully'});
        }, err => {
          this.loading = false;
          console.log('Error occured in update department:', err);
        });
      } else {
        const departmentData = this.addDepartmentForm.value;
        // departmentData.status=this.status;
        // const hodArray = departmentData.hod;
        const idArr = [];
        if (departmentData.hod != null) {
          for (let i = 0; i < departmentData.hod.length; i++) {
            idArr[i] = '' + departmentData.hod[i].id;
          }
          departmentData.hod = idArr;
          departmentData.departmentName = departmentData.departmentName[0].id;
          departmentData.functionId = '' + departmentData.functionId[0].id;
          departmentData.unitId = '' + sessionStorage.getItem('unitId');
        }
        // delete departmentData.hod;
        /* departmentData.hod = hodArray.map(value=> value.userName);
        departmentData.hodEmailId = hodArray.map(value=> value.emailId);
        departmentData.hodaccount = hodArray.map(value=> value.accountName); */

        console.log(departmentData);
        // departmentData.hodEmailId = this.addDepartmentForm.value.hod.emailId;
        this.setupService.addDepartment(departmentData).subscribe((res: any[]) => {
          // this.status=false;
          this.displayDepartmentDialog = false;
          this.getTotalNumberOfDepartments();
          this.getDepartments(this.paginationDetails);
          console.log('Department Saved Successfully');
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `${departmentData.departmentName}`, detail: 'Updated Successfully'});
        }, err => {
          this.loading = false;
          console.log('Error occured in add department:', err);
        });
      }
    }

  }

  updateDepartment(department) {
    this.submitted = true;
    if (this.updateDepartmentForm.invalid) {
      return this.updateDepartmentForm.value.invalid = 'null';
    } else {
      const departmentData = this.updateDepartmentForm.value;
      departmentData.id = department.id;

      const idArr = [];
      for (let i = 0; i < this.updatedHodSel.length; i++) {
        idArr[i] = '' + this.updatedHodSel[i];
      }
      departmentData.hod = idArr;


      // departmentData.status=this.status;
      this.setupService.updateDepartment(departmentData).subscribe((res: any[]) => {
        // this.status=false;
        this.displayDepartmentDialog = false;
        this.getTotalNumberOfDepartments();
        this.getDepartments(this.paginationDetails);
        console.log('Department Updated Successfully');
      }, err => {
        console.log('Error occured in update department:', err);
      });
    }
  }

  showAddDepartmentDialog() {
    this.displayDepartmentDialog = true;
    // this.status=false;
    // this.addDepartmentForm.reset();
    this.initializeAddDepartmentForm();
    this.submitted = false;
  }
  showUpdateDepartmentDialog(id: any) {
    this.getDepartmentById(id);
    this.submitted = false;
    this.update = true;
    this.displayDepartmentDialog = true;

  }
  select(e) {
    console.log(e);
    this.selectedIds = e.value;
  }

  updateSelect(e) {
    console.log(e);
    this.updatedHodSel.push(e.itemValue);
    console.log(this.updatedHodSel);
  }

  loadOninit() {
    if (!this.departmentLoading && !this.nameLoading && !this.hodLoading && !this.functionLoading) {
      this.loading = false;
    }
  }

  exportAsXLSX() {
    if (this.departments.length > 0) {
      this.excelService.exportAsExcelFile(this.departments, 'sample');
    }
  }
}
