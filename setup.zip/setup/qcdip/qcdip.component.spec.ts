import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QcdipComponent } from './qcdip.component';

describe('QcdipComponent', () => {
  let component: QcdipComponent;
  let fixture: ComponentFixture<QcdipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QcdipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QcdipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
