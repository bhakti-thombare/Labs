import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { UserinfoService } from 'src/app/configuration/userinfo.service';
import { SetupService } from '../setup.service';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import Swal from 'sweetalert2';
import { TableModule, Table } from 'primeng/table';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-qcdip',
  templateUrl: './qcdip.component.html',
  styleUrls: ['./qcdip.component.css']
})
export class QcdipComponent implements OnInit {
  cols: any = [];
  qcDipParameter: any = [];
  qcDipParameterMaster: any = [];
  getAllQCDIPData: any = [];
  existingcheckedMasterData: any = [];
  displayAddQCDipDialog: Boolean;
  displayUpdateQCDipDialog: Boolean;
  addQCDipForm: FormGroup;
  teamDropdownForm: FormGroup;
  paginationDetails: any;

  totalQCDip: any[];
  totalQCDipMaster: any[];

  updateQCDipData: any;
  updateQCDipForm: FormGroup;
  submitted: Boolean = false;
  showDeletePopup: Boolean = false;
  isChecked: any = [];
  importDailog = false;
  deleteRowId: any;

  source = [];
  parameterType = [];
  unitOfMeasurement = [];
  target = [];
  ytdFormula = [];
  btnAddQCDIP = false;
  selectedrowId: any;
  adduploadFile: FormGroup;
  isManual = true;
  isOtherParamter = false;
  isMandatory = true;
  getExcelFile;
  allselectedCheckedBox;
  notRangeSelectedFlag = false;
  rangeSelectedFlag = false;
  rowSelected = [];
  rowSelectedMaster = [];
  unitId;
  loading = true;
  update = false;
  loggedInUser;
  createdBy;
  teamId;
  rowPos = [];
  sourceFilter: any;
  parameterTypeFilter: any;

  isApprovedFlag: Boolean = false;

  qcdipReadStatus = false;
  qcdipCreateStatus = false;
  qcdipUpdateStatus = false;
  qcdipDeleteStatus = false;

  isMasterData = true;
  isUnitData = false;

  unitWiseTeam: any;
  selectedTeamId: any = null;
  teamDropDownDisabled = false;

  //@ViewChild('fileInput') fileInput: ElementRef;

  constructor(
    private formBuilder: FormBuilder,
    private setupService: SetupService,
    private userInfo: UserinfoService,
    private router: Router,
    private msAdalService: MsAdalAngular6Service,
    private messageService: MessageService) { }

  ngOnInit() {
    const userId = this.msAdalService.userInfo.userName.split('@')[0];
    this.loggedInUser = userId;
    this.getUserInfo(userId);
    this.source = ["Confluence", "MySetu", "Manual", "SAP"];
    this.sourceFilter = [
      { label: "Confluence", value: "Confluence" },
      { label: "MySetu", value: "MySetu" },
      { label: "Manual", value: "Manual" },
      { label: "SAP", value: "SAP" },
    ];

    this.parameterType = [
      { "id": "1", "value": "Environment" },
      { "id": "2", "value": "Quality" },
      { "id": "3", "value": "Other Parameter" },
      { "id": "4", "value": "Safety" },
      { "id": "5", "value": "Health" },
      { "id": "6", "value": "Productivity" },
      { "id": "7", "value": "Delivery" },
      { "id": "8", "value": "Innovation" },
      { "id": "9", "value": "Cost" },
    ];

    this.parameterTypeFilter = [
      { label: "Environment", value: "Environment" },
      { label: "Quality", value: "Quality" },
      { label: "Other Parameter", value: "Other Parameter" },
      { label: "Safety", value: "Safety" },
      { label: "Health", value: "Health" },
      { label: "Productivity", value: "Productivity" },
      { label: "Delivery", value: "Delivery" },
      { label: "Innovation", value: "Innovation" },
      { label: "Cost", value: "Cost" },
    ];
    this.target = [">", "<", ">=", "<=", "=", "range"];
    this.ytdFormula = ["Sum", "Average"];

    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.initializeAddQCDipForm();
    this.getQCDipColumns();
    // this.getTotalNumberOfQCDip();
    // this.getQCDip(this.paginationDetails);

    this.adduploadFile = this.formBuilder.group({
      excelFile: [null, [Validators.required]]
    });

    this.setupService.getQCDIPUOM().subscribe(res => {
      this.unitOfMeasurement = res;
    })


    this.teamDropdownForm.controls.unitSelect.valueChanges.subscribe(value => {
      value ? this.teamDropdownForm.controls.master.disable() : this.teamDropdownForm.controls.master.enable();
    });
    console.log("Changes to check");
  }

  getUserInfo(userId) {
    this.setupService
      .getWithParam('RpmMapping/GetRpmMappingForEmployee/username', userId)
      .subscribe((res: any) => {
        console.log('res', res);
        const unitId = sessionStorage.getItem('unitId');
        const index = _.findIndex(res, (d) => d['item2'].unitId == unitId)
        this.unitId = res[index].item2.unitId;
        this.teamId = res[index].item2.teamId;

        this.userInfo.roleName = res[index].item1;
        this.userInfo.userData = res[index].item2;
        this.userInfo.userAccess = res[index].item3;

        this.getMappings();
        // debugger;
        //const getQCDIPModule = this.userInfo.userAccess.filter((res: any) => res.moduleId == 27);
        //this.isApprovedFlag = getQCDIPModule[0].privilegeStatus.Approve;

      }, (err) => {
        console.log('err', err);
      });
  }

  onQcdipBoxClick(e) {
    if (e.target.checked) {
      this.teamDropDownDisabled = true
      console.log('this.teamDropDownDisabled', this.teamDropDownDisabled)
      this.selectedTeamId = 0
    } else {
      this.teamDropDownDisabled = false
      this.selectedTeamId = sessionStorage.getItem('teamId')
    }

  }

  getMappings() {
    console.log(sessionStorage.getItem('UserInfo'));
    const accessList = this.userInfo.userAccess;
    console.log('accessList', accessList);
    const moduleIndex = _.findIndex(accessList, (d) => d['moduleName'] == 'QCDIPModule');
    console.log('moduleIndex', moduleIndex);

    this.qcdipReadStatus = accessList[moduleIndex].privilegeStatus.Read;
    console.log('qcdipReadStatus', this.qcdipReadStatus);
    if (!this.qcdipReadStatus) {
      Swal.fire('Please contact your system Administrator as the privileges may be insufficient');
      this.router.navigate(['/dashboard']);
    } else {
      this.qcdipCreateStatus = accessList[moduleIndex].privilegeStatus.Create;
      this.qcdipUpdateStatus = accessList[moduleIndex].privilegeStatus.Update;
      this.qcdipDeleteStatus = accessList[moduleIndex].privilegeStatus.Delete;

      this.setupService.getTeam(this.unitId).subscribe((res: any[]) => {
        this.unitWiseTeam = res;
      })
      this.setupService.getAllQCDIPData(this.unitId, this.teamId).subscribe((res: any[]) => {
        this.getAllQCDIPData = res;
        this.getTotalNumberOfQCDip();
        this.getQCDip(this.paginationDetails);
        //this.getQCDipMaster(this.paginationDetails);
        //this.getTotalNumberOfQCDipMaster();
      })


      //this.filterOpl(this.paginationDetails);
      // if (this.msAdalService.isAuthenticated) {
      //   this.GetRoleBasedData();
      // } else {
      //   this.GetRoleBasedDataWorkMan();
      // }
      this.loading = false;
    }
  }

  /* Pagination */
  onQCDipPageChange(event) {
    this.loading = true;
    this.isChecked = [];
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    console.log('------Pagination Details After Page Change-----', this.paginationDetails);
    this.getQCDip(this.paginationDetails);
  }
  onQCDipPageChangeMaster(event) {
    this.loading = true;
    this.isChecked = [];
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    console.log('------Pagination Details After Page Change-----', this.paginationDetails);
    this.getQCDipMaster(this.paginationDetails);
  }

  get formFields() { return this.addQCDipForm.controls; }

  get editFormFields() { return this.addQCDipForm.controls; }

  /* Initialize the QcDip Form */
  initializeAddQCDipForm() {
    this.addQCDipForm = this.formBuilder.group({
      source: [null, Validators.required],
      parameterType: [null, Validators.required],
      otherSystemId: [null, Validators.required],
      parameter: [null, Validators.required],
      unitOfMeasurement: [null, Validators.required],
      target: [null, Validators.required],
      targetInp1: [null],
      targetInp2: [null],
      weightage: [null],
      maxMarks: [null],
      ytdFormula: [null, Validators.required],
    });

    this.teamDropdownForm = this.formBuilder.group({
      unitSelect: [null],
      master: [null],
      unit: [null],
    });
  }

  /* Submit Add QCDIP Form */
  submitAddQCDipParameter() {
    this.submitted = true;
    let d = new Date();
    if (this.addQCDipForm.invalid) {
      return this.addQCDipForm.value.actionPerformed = 'null';
    } else {
      this.loading = true;
      if (this.btnAddQCDIP) {
        console.log("add");
        const qcDipData = this.addQCDipForm.value;
        //qcDipData.target == 'range' ? qcDipData.target + " " + this.addQCDipForm.get('targetInp1').value + " " + this.addQCDipForm.get('targetInp2').value : qcDipData.target + " " + this.addQCDipForm.get('targetInp1').value,
        let obj = {
          Id: 0,
          Target: qcDipData.target == null ? qcDipData.target : (qcDipData.target == 'range' ? qcDipData.target + " " + String(this.addQCDipForm.get('targetInp1').value).trim() + " " + String(this.addQCDipForm.get('targetInp2').value).trim() : qcDipData.target + " " + String(this.addQCDipForm.get('targetInp1').value).trim()),
          Weightage: parseInt(qcDipData.weightage),
          Source: qcDipData.source,
          ParameterType: qcDipData.parameterType.value,
          ParameterId: qcDipData.otherSystemId,
          MaxMarks: parseInt(qcDipData.maxMarks),
          //PtypeId: qcDipData.parameterType.id,
          UnitId: parseInt(this.unitId),
          TeamId: parseInt(this.teamId),
          ParameterTypeName: "",
          YtdFormula: qcDipData.ytdFormula,
          UnitOfMeasurement: qcDipData.unitOfMeasurement != null ? qcDipData.unitOfMeasurement.uom : qcDipData.unitOfMeasurement,
          ParameterTitle: qcDipData.parameter,
          CreatedBy: this.loggedInUser
        }

        this.setupService.createQCDIPParameterMaster(obj).subscribe((res: any[]) => {
          this.displayAddQCDipDialog = false;
          this.getTotalNumberOfQCDip();
          this.isMandatory = true;
          this.isManual = true;
          this.notRangeSelectedFlag = false;
          this.rangeSelectedFlag = false;
          this.messageService.add({ severity: 'success', summary: 'Created Successfully', detail: 'Created Parameter Successfully' });
          this.getQCDip(this.paginationDetails);
          console.log('createQCDIPParameter Saved Successfully');
        }, err => {
          console.log('Error occured in Create QCDIP:', err);
          this.messageService.add({ severity: 'error', summary: 'Create Failed', detail: 'Create Failed' });
        });
      }
      else {
        this.loading = true;
        console.log("update");
        const qcDipUpdateData = this.addQCDipForm.value;
        let obj = {
          id: this.selectedrowId,
          target: qcDipUpdateData.target == null ? qcDipUpdateData.target : (qcDipUpdateData.target == 'range' ? qcDipUpdateData.target + " " + String(this.addQCDipForm.get('targetInp1').value).trim() + " " + String(this.addQCDipForm.get('targetInp2').value).trim() : qcDipUpdateData.target + " " + String(this.addQCDipForm.get('targetInp1').value).trim()),
          weightage: parseInt(qcDipUpdateData.weightage),
          source: qcDipUpdateData.source,
          parameterType: qcDipUpdateData.parameterType.value,
          parameterId: qcDipUpdateData.otherSystemId,
          maxMarks: parseInt(qcDipUpdateData.maxMarks),
          //ptypeId: qcDipUpdateData.parameterType.id,
          unitId: parseInt(this.unitId),
          teamId: parseInt(this.teamId),
          parameterTypeName: "",
          ytdFormula: qcDipUpdateData.ytdFormula,
          unitOfMeasurement: qcDipUpdateData.unitOfMeasurement != null ? qcDipUpdateData.unitOfMeasurement.uom : qcDipUpdateData.unitOfMeasurement,
          parameterTitle: qcDipUpdateData.parameter,
          createdBy: this.createdBy,
          modifiedBy: this.loggedInUser,
          modified: d.getFullYear() + "-" + (d.getMonth() < 10 ? "0" + d.getMonth() : d.getMonth()) + "-" + (d.getDate() < 10 ? "0" + d.getDate() : d.getDate()),
          created: d.getFullYear() + "-" + (d.getMonth() < 10 ? "0" + d.getMonth() : d.getMonth()) + "-" + (d.getDate() < 10 ? "0" + d.getDate() : d.getDate())
        }
        if (!this.isMasterData) {
          this.setupService.updateQCDIPParameterMaster(obj).subscribe((res: any) => {
            this.getTotalNumberOfQCDipMaster();
            this.displayAddQCDipDialog = false;
            this.isMandatory = true;
            this.isManual = true;
            this.notRangeSelectedFlag = false;
            this.rangeSelectedFlag = false;
            this.messageService.add({ severity: 'success', summary: 'Update Successfully', detail: 'Updated Parameter Successfully' });
            this.getQCDipMaster(this.paginationDetails);
          }, err => {
            this.messageService.add({ severity: 'error', summary: 'Update Failed', detail: 'Update Failed' });
          });
        } else {
          this.setupService.updateQCDIPParameter(obj).subscribe((res: any) => {
            this.getTotalNumberOfQCDip();
            this.displayAddQCDipDialog = false;
            this.isMandatory = true;
            this.isManual = true;
            this.notRangeSelectedFlag = false;
            this.rangeSelectedFlag = false;
            this.messageService.add({ severity: 'success', summary: 'Update Successfully', detail: 'Updated Parameter Successfully' });
            this.getQCDip(this.paginationDetails);
          }, err => {
            this.messageService.add({ severity: 'error', summary: 'Update Failed', detail: 'Update Failed' });
          })
        }
      }
    }
  }

  /* Get QCDIP Column */
  getQCDipColumns() {
    this.cols = [
      { field: 'source', header: 'Source' },
      { field: 'parameterType', header: 'Parameter Type' },
      { field: 'parameterId', header: 'Parameter ID' },
      { field: 'parameterTitle', header: 'Parameter' },
      { field: 'target', header: 'Target' },
      { field: 'weightage', header: 'Weightage' },
      // { field: 'maxMarks', header: 'Max Marks' },
      // { field: 'id', header: 'ID' },
      { field: 'ytdFormula', header: 'YTD Formula' },
      { field: 'actions', header: 'Actions' }
    ];
  }

  /* Get QCDip */
  getQCDip(paginationDetails) {
    this.setupService.getQCDIPParameters(this.paginationDetails, this.unitId, this.teamId).subscribe((res: any[]) => {
      this.qcDipParameter = res;
      this.qcDipParameter.forEach(res => {
        if (res.target != null) {
          if (res.target.indexOf('range') != -1) {
            res.range = true;
            let slice1 = res.target.split(' ').slice(0, 1);
            let slice2 = res.target.split(' ').slice(1, 3);
            slice2.splice(1, 0, '-');
            let newSlice = slice1.concat(slice2).join(' ');
            res.rangeHyphen = newSlice;
          } else {
            res.range = false;
          }
        } else {
          res.range = false;
        }
      });

      this.rowSelected = this.qcDipParameter.filter(res => res.ptypeId != "" && res.ptypeId != null);
      this.loading = false;
    }, err => {
      console.log('Error occured in get QcDip:', err);
    });
  }
  getQCDipMaster(paginationDetails) {
    
    this.setupService.getQCDIPParametersMaster(this.paginationDetails).subscribe((res: any[]) => {
      this.qcDipParameterMaster = res;
      console.log('this.qcDipParameterMaster', this.qcDipParameterMaster)
      this.qcDipParameterMaster.forEach(res => {
        if (res.target != null) {
          if (res.target.indexOf('range') != -1) {
            res.range = true;
            let slice1 = res.target.split(' ').slice(0, 1);
            let slice2 = res.target.split(' ').slice(1, 3);
            slice2.splice(1, 0, '-');
            let newSlice = slice1.concat(slice2).join(' ');
            res.rangeHyphen = newSlice;
          } else {
            res.range = false;
          }
        } else {
          res.range = false;
        }
      });

      if (this.getAllQCDIPData.length > 0) {
        var result = this.qcDipParameterMaster.filter(master => {
          
          // filter out (!) items in result2
          return this.getAllQCDIPData.some(unit => {
            console.log('this.getAllQCDIPData', this.getAllQCDIPData)
            return master.parameterId == unit.parameterId && master.parameterType == unit.parameterType && master.source == unit.source && master.parameterTitle == unit.parameterTitle;          // assumes unique id
          });
        });
        console.log('result', result)
        // this.rowSelectedMaster = result.filter(res => res.parameterTypeName != "" && res.parameterTypeName != null);
        this.rowSelectedMaster = result
        console.log('this.rowSelectedMaster', this.rowSelectedMaster)
        this.rowSelectedMaster.map(res => res.ischeckboxSelected = true);
        this.existingcheckedMasterData = _.cloneDeep(this.rowSelectedMaster);

      }
      this.loading = false;
    }, err => {
      console.log('Error occured in get QcDip:', err);
    });
  }

  /* Get QcDip by id */
  getQcDipById(id) {
    this.setupService.getQCDIPParametersById(id).subscribe((res: any) => {
      this.addQCDipForm.patchValue(res);
      this.selectedrowId = res.id;
      this.createdBy = res.createdBy;
      const index = _.findIndex(this.parameterType, (d) => d.value == res.parameterType);
      const uomIndex = _.findIndex(this.unitOfMeasurement, (d) => d.uom == res.unitOfMeasurement);

      if (index == 2) {
        this.isOtherParamter = true;
        this.isMandatory = false;
        this.isManual = false;
        //this.addQCDipForm.controls["maxMarks"].setValidators([Validators.required]);
        this.addQCDipForm.controls["source"].clearValidators();
        this.addQCDipForm.controls["otherSystemId"].clearValidators();
        this.addQCDipForm.controls["parameter"].clearValidators();
        this.addQCDipForm.controls["unitOfMeasurement"].clearValidators();
        this.addQCDipForm.controls["ytdFormula"].clearValidators();

        //this.addQCDipForm.controls["maxMarks"].updateValueAndValidity();
        this.addQCDipForm.controls["source"].updateValueAndValidity();
        this.addQCDipForm.controls["otherSystemId"].updateValueAndValidity();
        this.addQCDipForm.controls["parameter"].updateValueAndValidity();
        this.addQCDipForm.controls["unitOfMeasurement"].updateValueAndValidity();
        this.addQCDipForm.controls["ytdFormula"].updateValueAndValidity();
      }

      let splitTarget;
      if (res.target != null) {
        splitTarget = res.target.split(' ');
        if (splitTarget.length > 0) {
          if (splitTarget[0] == 'range') {
            this.rangeSelectedFlag = true;
          } else {
            this.notRangeSelectedFlag = true;
          }
        }
      }

      this.addQCDipForm.patchValue(
        {
          otherSystemId: res.parameterId,
          parameter: res.parameterTitle,
          parameterType: this.parameterType[index],
          unitOfMeasurement: this.unitOfMeasurement[uomIndex],
          target: splitTarget != undefined ? splitTarget[0] : res.target,
          targetInp1: splitTarget != undefined ? splitTarget[1] : "",
          targetInp2: splitTarget != undefined ? splitTarget[2] : ""
        }
      );
      if (splitTarget[2] == undefined) {
        this.addQCDipForm.get('targetInp2').setValidators([]);
        this.addQCDipForm.get('targetInp2').updateValueAndValidity();
      }
      this.loading = false;

    }, err => {
      console.log('Error occured in get getQCDIPById:', err);
    });
  }

  getQcDipByIdMaster(id) {
    this.setupService.getQCDIPParametersByIdMaster(id).subscribe((res: any) => {
      this.addQCDipForm.patchValue(res);
      this.selectedrowId = res.id;
      this.createdBy = res.createdBy;
      const index = _.findIndex(this.parameterType, (d) => d.value == res.parameterType);
      const uomIndex = _.findIndex(this.unitOfMeasurement, (d) => d.uom == res.unitOfMeasurement);

      if (index == 2) {
        this.isOtherParamter = true;
        this.isMandatory = false;
        this.isManual = false;
        //this.addQCDipForm.controls["maxMarks"].setValidators([Validators.required]);
        this.addQCDipForm.controls["source"].clearValidators();
        this.addQCDipForm.controls["otherSystemId"].clearValidators();
        this.addQCDipForm.controls["parameter"].clearValidators();
        this.addQCDipForm.controls["unitOfMeasurement"].clearValidators();
        this.addQCDipForm.controls["ytdFormula"].clearValidators();

        //this.addQCDipForm.controls["maxMarks"].updateValueAndValidity();
        this.addQCDipForm.controls["source"].updateValueAndValidity();
        this.addQCDipForm.controls["otherSystemId"].updateValueAndValidity();
        this.addQCDipForm.controls["parameter"].updateValueAndValidity();
        this.addQCDipForm.controls["unitOfMeasurement"].updateValueAndValidity();
        this.addQCDipForm.controls["ytdFormula"].updateValueAndValidity();
      }

      let splitTarget;
      if (res.target != null) {
        splitTarget = res.target.split(' ');
        if (splitTarget.length > 0) {
          if (splitTarget[0] == 'range') {
            this.rangeSelectedFlag = true;
          } else {
            this.notRangeSelectedFlag = true;
          }
        }
      }

      this.addQCDipForm.patchValue(
        {
          otherSystemId: res.parameterId,
          parameter: res.parameterTitle,
          parameterType: this.parameterType[index],
          unitOfMeasurement: this.unitOfMeasurement[uomIndex],
          target: splitTarget != undefined ? splitTarget[0] : res.target,
          targetInp1: splitTarget != undefined ? splitTarget[1] : "",
          targetInp2: splitTarget != undefined ? splitTarget[2] : ""
        }
      );
      if (splitTarget !=undefined) {
        if (splitTarget[2] == undefined) {
          this.addQCDipForm.get('targetInp2').setValidators([]);
          this.addQCDipForm.get('targetInp2').updateValueAndValidity();
        }
      }
      this.loading = false;

    }, err => {
      console.log('Error occured in get getQCDIPById:', err);
    });
  }

  /* Get Total number of QCDip */
  getTotalNumberOfQCDip() {
    this.setupService
      .getAllQCDIPParameterCount(this.unitId, this.teamId)
      .subscribe((data) => {
        this.totalQCDip = data;
        console.log('-----totalQCDIP-----', this.totalQCDip);
      });
  }
  getTotalNumberOfQCDipMaster() {
    console.log(this.teamDropDownDisabled);
    
    if(this.teamDropDownDisabled) {
      this.teamId = 0
    }
    this.setupService
      .getAllQCDIPParameterCountMaster()
      .subscribe((data) => {
        this.totalQCDipMaster = data;
        console.log('-----totalQCDipMaster-----', this.totalQCDipMaster);
      });
  }

  changeTarget(event) {
    if (event.target.value == "range") {
      this.rangeSelectedFlag = true;
      this.addQCDipForm.get('targetInp1').setValidators([Validators.required]);
      this.addQCDipForm.get('targetInp2').setValidators([Validators.required]);

      this.addQCDipForm.get('targetInp1').updateValueAndValidity();
      this.addQCDipForm.get('targetInp2').updateValueAndValidity();
      this.notRangeSelectedFlag = false;
    } else {
      this.rangeSelectedFlag = false;
      this.notRangeSelectedFlag = true;
      this.addQCDipForm.get('targetInp1').setValidators([Validators.required]);
      this.addQCDipForm.get('targetInp1').updateValueAndValidity();
      this.addQCDipForm.get('targetInp2').setValidators([]);
      this.addQCDipForm.get('targetInp2').updateValueAndValidity();
    }
  }

  /* Cancel  */
  cancelAddQCDipDialog() {
    this.isMandatory = true;
    this.addQCDipForm.reset();
    this.displayAddQCDipDialog = false;
    this.submitted = false;
    this.rangeSelectedFlag = false;
    this.notRangeSelectedFlag = false;
  }

  /* Show the Dialog Box */
  showAddQCDipDialog() {
    this.update = false;
    this.btnAddQCDIP = true;
    this.displayAddQCDipDialog = true;
    this.submitted = false;
    this.initializeAddQCDipForm();
  }

  showUpdateQCDipDialog(id: any) {
    this.update = true;
    this.loading = true;
    this.btnAddQCDIP = false;
    this.getQcDipById(id);
    this.submitted = false;
    this.displayAddQCDipDialog = true;
  }

  showUpdateQCDipDialogMaster(id: any) {
    this.update = true;
    this.loading = true;
    this.btnAddQCDIP = false;
    this.getQcDipByIdMaster(id);
    this.submitted = false;
    this.displayAddQCDipDialog = true;
  }

  deleteSelectedRow(item) {
    this.deleteRowId = item;
    Swal.fire({
      title: 'Do you want to delete?',
      //text: "You won't be able to revert this!",
      //icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        this.loading = true;
        this.setupService.deleteQCDIPParametersById(this.deleteRowId).subscribe(res => {
          if (res) {
            this.messageService.add({ severity: 'success', summary: 'Delete Successfully', detail: 'Delete Successfully' });
            this.getQCDip(this.paginationDetails);
          }
        }, err => {
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: 'Failed' });
        })
      }
    })

    //this.showDeletePopup = true;
  }

  // confirmDelete(){
  //   this.loading = true;
  //   this.setupService.deleteQCDIPParametersById(this.deleteRowId).subscribe(res=>{
  //     if(res){
  //       this.messageService.add({ severity: 'success', summary: 'Delete Successfully', detail: 'Delete Successfully' });  
  //       this.showDeletePopup = false;
  //       this.getQCDip(this.paginationDetails);
  //       // const removeIndex = this.qcDipParameter.findIndex((response:any) => response.id == this.deleteRowId);
  //       // this.qcDipParameter.splice(removeIndex,1);
  //     }
  //   },err=>{
  //       this.messageService.add({ severity: 'error', summary: 'Failed', detail: 'Failed' });  
  //   })
  // }

  // cancelDelete(){
  //   this.showDeletePopup = false;
  // }

  checkboxChecked(event, selected, rows, rowIndex) {
    this.isChecked = rows.selection;
    if (selected.checked == false) {
      let ptypeData = this.qcDipParameter.filter(res => res.ptypeId != null && res.ptypeId != '');
      this.rowSelected = ptypeData;
    }
  }
  checkboxCheckedMaster(event, selected, rows, rowIndex) {
    this.isChecked = rows.selection;
    if (selected.checked == false) {
      // let ptypeData = this.qcDipParameterMaster.filter(res => res.ptypeId != null && res.ptypeId != '');
      // this.rowSelectedMaster = ptypeData;
      var result = this.qcDipParameterMaster.filter(master => {
        // filter out (!) items in result2
        return this.getAllQCDIPData.some(unit => {
          return master.parameterId == unit.parameterId && master.parameterType == unit.parameterType && master.source == unit.source && master.parameterTitle == unit.parameterTitle;          // assumes unique id
        });
      });
      this.rowSelectedMaster = result.filter(res => res.parameterTypeName != "" && res.parameterTypeName != null);
    }
  }

  submitTableData() {
    if (this.userInfo.roleName == "Super Admin") {
      if (this.teamDropDownDisabled) {
        if (this.selectedTeamId == null) {
          this.selectedTeamId = 0
        }
      }
      // if (this.selectedTeamId !=null){
      if (this.teamDropDownDisabled || this.selectedTeamId) {
        this.loading = true;
        let selectedRow = this.rowSelected;
        selectedRow.map(res => {
          res.teamId = this.selectedTeamId;
          let data = this.parameterType.find(item => item.value == res.parameterType);
          res.ptypeId = data.id;
        });

        this.setupService.submitQCDIPParameter(selectedRow).subscribe(res => {
          this.loading = false;
          //this.rowSelected = [];
          this.isChecked = this.rowSelected;
          this.messageService.add({ severity: 'success', summary: 'Submit Successfully', detail: 'Submit Successfully' });
        }, (err) => {
          this.messageService.add({ severity: 'error', summary: 'Submit Failed', detail: 'Submit Failed' });
        })
      } else {
        Swal.fire("Please select team.");
      }
      // }else{
      //   
      // }
      // if (!this.teamDropDownDisabled) {
        
      // }
    } else {
      this.loading = true;
      let selectedRow = this.rowSelected;
      selectedRow.map(res => {
        let data = this.parameterType.find(item => item.value == res.parameterType);
        res.ptypeId = data.id;
      });

      console.log("Inside else");
      

      this.setupService.submitQCDIPParameter(selectedRow).subscribe(res => {
        this.loading = false;
        //this.rowSelected = [];
        this.isChecked = this.rowSelected;
        this.messageService.add({ severity: 'success', summary: 'Submit Successfully', detail: 'Submit Successfully' });
      }, (err) => {
        this.messageService.add({ severity: 'error', summary: 'Submit Failed', detail: 'Submit Failed' });
      })
    }
  }

  submitTableMasterData() {
    if (this.userInfo.roleName == "Super Admin") {
      console.log("submitTableMasterData");
      
      if (this.teamDropDownDisabled) {
        if (this.selectedTeamId == null) {
          this.selectedTeamId = 0
        }
      }
      if (this.teamDropDownDisabled || this.selectedTeamId) {
        let existingChecked = this.existingcheckedMasterData;
        let selectedRow = this.rowSelectedMaster;
        var result = this.rowSelectedMaster.filter(master => {
          // filter out (!) items in result2
          return !existingChecked.some(unit => {
            return master.id == unit.id;
          });
        });

        if(result.every(res => res.target != null) == true){
          let obj = result.map(res => {
            return {
              Id: 0,
              Target: res.target,
              Weightage: parseInt(res.weightage),
              Source: res.source,
              ParameterType: res.parameterType,
              ParameterId: res.parameterId,
              MaxMarks: parseInt(res.maxMarks),
              //PtypeId: qcDipData.parameterType.id,
              UnitId: parseInt(this.unitId),
              TeamId: parseInt(this.teamDropDownDisabled == true ? this.teamId : this.selectedTeamId),
              ParameterTypeName: res.parameterType,
              YtdFormula: res.ytdFormula,
              UnitOfMeasurement: res.unitOfMeasurement,
              ParameterTitle: res.parameterTitle,
              CreatedBy: this.loggedInUser
            }
          });
  
          this.setupService.createQCDIPParameter(obj).subscribe((res: any[]) => {
            this.messageService.add({ severity: 'success', summary: 'Successfully', detail: 'Parameter added successfully to current unit.' });
          }, err => {
            this.messageService.add({ severity: 'error', summary: 'Failed', detail: 'Failed' });
          });
        } else{
          Swal.fire("Please enter target.");
        }

      } else {
        Swal.fire("Please select team.");
      }
    } else {
      if (this.teamDropDownDisabled || this.selectedTeamId) {
        let existingChecked = this.existingcheckedMasterData;
        let selectedRow = this.rowSelectedMaster;
        var result = this.rowSelectedMaster.filter(master => {
          // filter out (!) items in result2
          return !existingChecked.some(unit => {
            return master.id == unit.id;
          });
        });
  
        if (result.every(res => res.target != null) == true) {
          let obj = result.map(res => {
            return {
              Id: 0,
              Target: res.target,
              Weightage: parseInt(res.weightage),
              Source: res.source,
              ParameterType: res.parameterType,
              ParameterId: res.parameterId,
              MaxMarks: parseInt(res.maxMarks),
              //PtypeId: qcDipData.parameterType.id,
              UnitId: parseInt(this.unitId),
              TeamId: parseInt(this.teamDropDownDisabled == true ? this.teamId : this.selectedTeamId),
              ParameterTypeName: res.parameterType,
              YtdFormula: res.ytdFormula,
              UnitOfMeasurement: res.unitOfMeasurement,
              ParameterTitle: res.parameterTitle,
              CreatedBy: this.loggedInUser
            }
          });
    
          this.setupService.createQCDIPParameter(obj).subscribe((res: any[]) => {
            this.messageService.add({ severity: 'success', summary: 'Successfully', detail: 'Parameter added successfully to current unit.' });
          }, err => {
            this.messageService.add({ severity: 'error', summary: 'Failed', detail: 'Failed' });
          });
        } else {
          Swal.fire("Please enter target.");
        }
      }
      else{
        Swal.fire("Please select team.");
      }
    }
  }

  showImport() {
    this.importDailog = true;
  }
  hideImport() {
    this.importDailog = false;
    this.adduploadFile.reset();
    //this.fileInput.nativeElement.value = "";
  }
  fileUpload(event) {
    var validExts = new Array(".xlsx", ".xls");
    var fileExt = event.target.value;
    fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
    if (validExts.indexOf(fileExt) < 0) {
      Swal.fire("Invalid file selected, valid files are of " +
        validExts.toString() + " types.");
      event.target.value = "";
      this.adduploadFile.get('excelFile').setValue("");
      return false;
    }
    else {
      this.getExcelFile = event.target.files[0];
      this.adduploadFile.get('excelFile').setValue(this.getExcelFile);
      console.log('event', event.target.files[0]);
      return true;
    }
  }

  importFile() {
    this.loading = true;
    //const inputEl: HTMLInputElement = this.getExcelFile.nativeElement;
    let frmData = new FormData();
    frmData.append("FilePath", this.adduploadFile.get('excelFile').value);
    this.setupService.uploadParameterList(frmData).subscribe(res => {
      console.log("file Resonse", res);
    });
    setTimeout(() => {
      this.importDailog = false;
      this.adduploadFile.reset();
      this.getQCDip(this.paginationDetails);
    }, 2000)
  }

  sourceChangAction(event) {
    let value = this.addQCDipForm.controls["source"].value;
    if (value == "Manual") {
      this.isManual = false;
      this.addQCDipForm.controls["otherSystemId"].clearValidators();
      this.addQCDipForm.controls["otherSystemId"].updateValueAndValidity();

      // this.addQCDipForm.controls["ytdFormula"].setValidators([Validators.required]);
      // this.addQCDipForm.controls["ytdFormula"].updateValueAndValidity();
    } else {
      this.isManual = true;
      this.addQCDipForm.controls["otherSystemId"].setValidators([Validators.required]);
      this.addQCDipForm.controls["otherSystemId"].updateValueAndValidity();

      // this.addQCDipForm.controls["ytdFormula"].setValidators([]);
      // this.addQCDipForm.controls["ytdFormula"].updateValueAndValidity();
      if (this.addQCDipForm.controls["parameterType"].value != null) {
        if (this.addQCDipForm.controls["parameterType"].value.value == "Other Parameter") {
          this.isManual = false;
          this.addQCDipForm.controls["otherSystemId"].clearValidators();
          this.addQCDipForm.controls["otherSystemId"].updateValueAndValidity();
        }
      }
    }
  }

  parameterTypeChangAction(event) {
    let value = this.addQCDipForm.controls["parameterType"].value;
    if (value.value == "Other Parameter") {
      this.isOtherParamter = true;
      this.isMandatory = false;
      this.isManual = false;
      //this.addQCDipForm.controls["maxMarks"].setValidators([Validators.required]);
      this.addQCDipForm.controls["source"].clearValidators();
      this.addQCDipForm.controls["otherSystemId"].clearValidators();
      this.addQCDipForm.controls["parameter"].clearValidators();
      this.addQCDipForm.controls["unitOfMeasurement"].clearValidators();
      this.addQCDipForm.controls["ytdFormula"].clearValidators();

      //this.addQCDipForm.controls["maxMarks"].updateValueAndValidity();
      this.addQCDipForm.controls["source"].updateValueAndValidity();
      this.addQCDipForm.controls["otherSystemId"].updateValueAndValidity();
      this.addQCDipForm.controls["parameter"].updateValueAndValidity();
      this.addQCDipForm.controls["unitOfMeasurement"].updateValueAndValidity();
      this.addQCDipForm.controls["ytdFormula"].updateValueAndValidity();
    } else {
      this.isOtherParamter = false;
      this.isMandatory = true;
      this.addQCDipForm.controls["maxMarks"].clearValidators();
      this.addQCDipForm.controls["source"].setValidators([Validators.required]);
      if (this.addQCDipForm.controls["source"].value == "Manual") {
        this.addQCDipForm.controls["otherSystemId"].clearValidators();
        this.addQCDipForm.controls["otherSystemId"].updateValueAndValidity();
      } else {
        this.isManual = true;
        this.addQCDipForm.controls["otherSystemId"].setValidators([Validators.required]);
        this.addQCDipForm.controls["otherSystemId"].updateValueAndValidity();
      }

      this.addQCDipForm.controls["parameter"].setValidators([Validators.required]);
      this.addQCDipForm.controls["unitOfMeasurement"].setValidators([Validators.required]);
      this.addQCDipForm.controls["ytdFormula"].setValidators([Validators.required]);

      this.addQCDipForm.controls["maxMarks"].updateValueAndValidity();
      this.addQCDipForm.controls["source"].updateValueAndValidity();
      this.addQCDipForm.controls["otherSystemId"].updateValueAndValidity();
      this.addQCDipForm.controls["parameter"].updateValueAndValidity();
      this.addQCDipForm.controls["unitOfMeasurement"].updateValueAndValidity();
      this.addQCDipForm.controls["ytdFormula"].updateValueAndValidity();
    }
  }

  showData(type) {
    this.teamDropDownDisabled = false;
    this.teamDropdownForm.get('unitSelect').reset();
    this.teamDropdownForm.get('master').reset();
    if (type == "Master") {
      this.loading = true;
      this.paginationDetails = {
        pageNumber: 0,
        pageSize: 5
      };
      this.isMasterData = false;
      this.isUnitData = true;
      this.teamId = this.userInfo.userData.teamId;
      //let selectedTeamId;
      if (this.teamDropdownForm.value.master == undefined) {
        this.selectedTeamId = 0;
      } else {
        this.selectedTeamId = this.teamDropdownForm.value.master.id;
      }

      this.setupService.getAllQCDIPData(this.unitId, this.selectedTeamId).subscribe((res: any[]) => {
        this.getAllQCDIPData = res;
        this.getQCDipMaster(this.paginationDetails);
        this.getTotalNumberOfQCDipMaster();
      })
    } else {
      this.loading = true;
      this.paginationDetails = {
        pageNumber: 0,
        pageSize: 5
      };
      if (this.teamDropdownForm.value.unit == null) {
        this.teamId = this.userInfo.userData.teamId;
      } else {
        this.teamId = this.teamDropdownForm.value.unit.id;
      }
      this.setupService.getAllQCDIPData(this.unitId, this.userInfo.userData.teamId).subscribe((res: any[]) => {
        this.getAllQCDIPData = res;
        this.getTotalNumberOfQCDip();
        this.getQCDip(this.paginationDetails);
        this.isMasterData = true;
        this.isUnitData = false;
      })
    }
  }

  changeTeam(event, type) {
    this.selectedTeamId = this.unitWiseTeam[event.target.selectedIndex - 1].id;
    if (type == "Unit") {
      this.loading = true;
      this.paginationDetails = {
        pageNumber: 0,
        pageSize: 5
      };
      this.teamId = this.selectedTeamId;

      this.setupService
        .getAllQCDIPParameterCount(this.unitId, this.selectedTeamId)
        .subscribe((data) => {
          this.totalQCDip = data;
          console.log('-----totalQCDIP-----', this.totalQCDip);
        });

      this.setupService.getQCDIPParameters(this.paginationDetails, this.unitId, this.selectedTeamId).subscribe((res: any[]) => {
        this.qcDipParameter = res;
        this.qcDipParameter.forEach(res => {
          if (res.target != null) {
            if (res.target.indexOf('range') != -1) {
              res.range = true;
              let slice1 = res.target.split(' ').slice(0, 1);
              let slice2 = res.target.split(' ').slice(1, 3);
              slice2.splice(1, 0, '-');
              let newSlice = slice1.concat(slice2).join(' ');
              res.rangeHyphen = newSlice;
            } else {
              res.range = false;
            }
          } else {
            res.range = false;
          }
        });

        this.rowSelected = this.qcDipParameter.filter(res => res.ptypeId != "" && res.ptypeId != null);
        this.loading = false;
      }, err => {
        console.log('Error occured in get QcDip:', err);
      });
    }
  }

  acceptNumeric(event) {
    console.log('keycode', event.charCode);
    var key;
    key = event.charCode;  //  
    return ((key > 45 && key < 58));
  }
}
