import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import * as _ from 'lodash';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { UserinfoService } from 'src/app/configuration/userinfo.service';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';

@Component({
  selector: 'app-area',
  templateUrl: './area.component.html',
  styleUrls: ['./area.component.css']
})
export class AreaComponent implements OnInit {
  cols: any = [];
  areas: any = [];
  totalAreas: any[];
  submitted: Boolean = false;
  status: Boolean = false;
  unitsNames = [];
  updateAreaData: any;
  displayAddAreaDialog: Boolean;
  paginationDetails: any;
  displayUpdateAreaDialog: Boolean;
  addAreaForm: FormGroup;
  updateAreaForm: FormGroup;
  sectionNames = [];
  update = false;
  dropdownSettingsUnit = {};
  dropdownSettingsSection = {};
  loading = true;
  areaLoading = false;
  unitLoading = false;
  sectionLoading = false;
  searchForm: FormGroup;
  searchArea = false;
  constructor(private fb: FormBuilder, private setupService: SetupService,
    private userInfo: UserinfoService, private msAdalService: MsAdalAngular6Service, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm = this.fb.group({
      userName: ['', Validators.required]
    });
    this.getAreaColumns();
    this.getAreas(this.paginationDetails);
    this.initializeAddAreaForm();
    this.initializeUpdateAreaForm();
    this.getTotalNumberOfAreas();
    this.getunitNames();
    this.getSectionNames();
    this.dropSettings();
    // const userId = this.msAdalService.userInfo.userName.split('@')[0];
    // this.getUserInfo(userId);
  }

  dropSettings() {
    this.dropdownSettingsUnit = {
      singleSelection: true,
      text: 'Choose Unit',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100,
      disabled: true
    };

    this.dropdownSettingsSection = {
      singleSelection: true,
      text: 'Choose Section',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };
  }

  get formFields() { return this.addAreaForm.controls; }

  get editFormFields() { return this.updateAreaForm.controls; }

  getUserInfo(userId) {
    this.setupService
      .getWithParam('RpmMapping/GetRpmMappingForEmployee/username', userId)
      .subscribe((res: any) => {
        console.log('res', res);
        // this.kaizenService.storeUnitId(res.item2.unitId);
        this.userInfo.roleName = res.item1;
        this.userInfo.userData = res.item2;
        // this.loggedInData = res.item2;
        // this.GetRoleBasedData();
        console.log(this.userInfo.userData.unitId);
      }, (err) => {
        console.log('err', err);
      });
  }

  search() {
    this.searchArea = true;
    this.setupService.get(`Admin/SearchFromName/${this.paginationDetails.pageNumber}/${this.paginationDetails.pageSize}?queryString=${this.searchForm.value.userName}&searchFor=area`)
    .subscribe(res => {
        console.log(res);
        this.totalAreas = res.item1;
        this.areas = res.item2;
      });
  }


  onAreaPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    if (this.searchArea) {
      this.search();
    } else {
      console.log('-------------pagination Details of Area-------', this.paginationDetails);
      this.getAreas(this.paginationDetails);
    }
  }
  onStatusChange(value) {
    this.status = value;
  }

  initializeAddAreaForm() {
    this.addAreaForm = this.fb.group({
      unitid: ['', Validators.required],
      areaName: ['', Validators.required],
      sectionid: ['', Validators.required]



    });
  }
  initializeUpdateAreaForm() {
    this.updateAreaForm = this.fb.group({
      unit: ['', Validators.required],
      areaName: ['', Validators.required],

    });
  }

  /*------------------------------------------------- Add Area---------------------------------------------- */
  addArea() {
    this.submitted = true;
    this.loading = true;

    if (this.addAreaForm.invalid) {
      this.loading = false;
      return this.addAreaForm.value.actionPerformed = 'null';
    } else {

      if (this.update) {
        const areaData = this.addAreaForm.value;
        areaData.AreaId = this.updateAreaData.areaId;
        areaData.unitid = +this.addAreaForm.controls.unitid.value[0].id;
        areaData.sectionid = +this.addAreaForm.controls.sectionid.value[0].id;
        areaData.status = this.status;
        // areaData.unitId = this.userInfo.userData.unitId;
        this.setupService.updateArea(areaData).subscribe((res: any[]) => {
          this.displayAddAreaDialog = false;
          this.getAreas(this.paginationDetails);
          this.update = false;
          console.log('Area Updated Successfully');
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `${areaData.areaName}`, detail: 'Updated Successfully'});
        }, err => {
          this.loading = false;
          console.log('Error occured in update area:', err);
        });
      } else {
        const areaData = this.addAreaForm.value;
        areaData.status = this.status;
        console.log('areaData', areaData);
        areaData.sectionid = +this.addAreaForm.controls.sectionid.value[0].id;
        areaData.unitid = +this.addAreaForm.controls.unitid.value[0].id;
        // areaData.unitId = this.userInfo.userData.unitId;
        this.setupService.addArea(areaData).subscribe((res: any[]) => {
          this.displayAddAreaDialog = false;
          this.status = false;
          console.log('Area Saved Successfully');
          this.getTotalNumberOfAreas();
          this.getAreas(this.paginationDetails);
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `${areaData.areaName}`, detail: 'created Successfully'});
        }, err => {
          this.loading = false;
          console.log('Error occured in add area:', err);
        });
      }
    }

  }

  /*------------------------------------------------- Update Area ----------------------------------------------------*/
  updateArea(area) {
    this.submitted = true;
    if (this.updateAreaForm.invalid) {
      return this.updateAreaForm.value.actionPerformed = 'null';
    } else {
      const areaData = this.addAreaForm.value;
      areaData.AreaId = area.areaId;
      areaData.status = this.status;
      this.setupService.updateArea(areaData).subscribe((res: any[]) => {
        this.displayAddAreaDialog = false;
        this.getAreas(this.paginationDetails);
        console.log('Area Updated Successfully');
      }, err => {
        console.log('Error occured in update area:', err);
      });
    }
  }

  getAreaColumns() {
    this.cols = [
      { field: 'unit', header: 'Unit' },
      { field: 'section', header: 'Section' },
      { field: 'areaName', header: 'Area' },
      { field: 'action', header: 'Actions' },
      { field: 'status', header: 'Status' },
    ];
  }
  /* ------------------------------------Get Areas------------------------------------------------- */
  getAreas(paginationDetails) {
    this.areaLoading = true;
    this.setupService.getAreas(paginationDetails).subscribe((res: any[]) => {
      this.areas = res;
      console.log('Get All Areas', this.areas);
      this.areaLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in get areas:', err);
      this.areaLoading = false;
      this.loadOninit();
    });

  }
  /* -------------------------------------------Get Total Area Pagination Count--------------------------------- */
  getTotalNumberOfAreas() {
    this.setupService.getTotalNumberOfAreas().subscribe((data) => {
      this.totalAreas = data;
      console.log('------------Get Total Count------', this.totalAreas);
    });
  }
  /* ---------------------------------------------Get Area By id--------------------------------------------------- */
  getAreaById(id) {
    this.setupService.getAreaById(id).subscribe((res: any) => {
      this.updateAreaData = res;
      this.addAreaForm.patchValue(res);

      const selectedSection = [];
      const selectedUnit = [];
      const indexSection = _.findIndex(this.sectionNames, (d) => d['id'] == this.updateAreaData.sectionId);
      console.log(indexSection);
      if (indexSection != -1) {
        selectedSection.push(this.sectionNames[indexSection]);
        this.addAreaForm.patchValue({
          sectionid: selectedSection
        });
      }

      const indexUnit = _.findIndex(this.unitsNames, (d) => d['id'] == this.updateAreaData.unitId);
      console.log(indexUnit);
      if (indexUnit != -1) {
        selectedUnit.push(this.unitsNames[indexUnit]);
        this.addAreaForm.patchValue({
          unitid: selectedUnit,
        });
      }
      // console.log('selectedName', selectedName);
      this.status = res.status;
      // this.addAreaForm.patchValue({
      //   unitid: selectedUnit,
      //   sectionid: selectedSection
      // });
      console.log('area Details', this.updateAreaData);
    });
  }

  /* ----------------------------------------------Get <unit name> for Area--------------------------------------  */
  getunitNames() {
    this.unitLoading = true;
    this.setupService.getUnitNameId().subscribe((res: any[]) => {
      // this.unitsNames = res;

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index].unitName, id: res[index].id });
      }

      console.log('newData', newData);
      this.unitsNames = this.unitsNames.concat(newData);
      console.log('Get Unit Names', this.unitsNames);
      this.unitLoading = false;
      this.loadOninit();
    }, err => {
      this.unitLoading = false;
      this.loadOninit();
    });
  }

  getSectionNames() {
    this.sectionLoading = true;
    this.setupService.getSectionNameId()
      .subscribe(res => {
        console.log('res', res);
        // this.sectionNames = res;

        const newData = [];
        for (let index = 0; index < res.length; index++) {
          newData.push({ itemName: res[index].sectionNameTitle, id: res[index].id });
        }

        console.log('newData', newData);
        this.sectionNames = this.sectionNames.concat(newData);
        this.sectionLoading = false;
        this.loadOninit();
      }, err => {
        this.sectionLoading = false;
        this.loadOninit();
      });
  }
  cancelAddAreaDialog() {
    this.displayAddAreaDialog = false;
    this.addAreaForm.reset();
    this.status = false;
    this.update = false;

  }

  showAddAreaDialog() {
    this.displayAddAreaDialog = true;
    this.submitted = false;
    this.addAreaForm.reset();
    this.addAreaForm.patchValue({
      unitid: [{itemName: sessionStorage.getItem('unit'), id: sessionStorage.getItem('unitId')}]
    });
    this.status = false;
  }


  cancelUpdateAreaDialog() {
    this.displayAddAreaDialog = false;
    this.updateAreaForm.reset();
  }

  showUpdateAreaDialog(id: any) {
    this.submitted = false;
    this.getAreaById(id);
    this.update = true;
    this.displayAddAreaDialog = true;
  }

  reset() {

    this.searchArea = false;
    const pagination = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm.reset();
    this.getTotalNumberOfAreas();
    this.getAreas(pagination);
  }

  loadOninit() {
    if (!this.areaLoading && !this.unitLoading && !this.sectionLoading) {
      this.loading = false;
    }
  }

  exportAsXLSX() {
    if (this.areas.length > 0) {
      this.excelService.exportAsExcelFile(this.areas, 'sample');
    }
  }
}
