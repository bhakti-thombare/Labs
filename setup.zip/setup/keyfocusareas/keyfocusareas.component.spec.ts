import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KeyfocusareasComponent } from './keyfocusareas.component';

describe('KeyfocusareasComponent', () => {
  let component: KeyfocusareasComponent;
  let fixture: ComponentFixture<KeyfocusareasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [KeyfocusareasComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KeyfocusareasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
