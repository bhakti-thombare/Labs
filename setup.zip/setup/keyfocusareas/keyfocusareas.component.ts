import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-keyfocusareas',
  templateUrl: './keyfocusareas.component.html',
  styleUrls: ['./keyfocusareas.component.css']
})
export class KeyfocusareasComponent implements OnInit {
  cols: any = [];
  keys: any = [];
  keyFocusAreas: any[];
  totalKeyFocusAreas: any[];
  submitted: Boolean = false;
  status: Boolean = false;
  updateKeyFocusAreaData: any;
  displayAddKeyFocusAreasDialog: Boolean;
  displayUpdateKeyFocusAreasDialog: Boolean;
  addKeyFocusAreaForm: FormGroup;
  paginationDetails: any;
  updateKeyFocusAreaForm: FormGroup;
  loading = true;
  searchForm: FormGroup;
  searchKFA = false;
  constructor(private fb: FormBuilder, private setupService: SetupService, private messageService: MessageService) { }

  ngOnInit() {
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm = this.fb.group({
      userName: ['', Validators.required]
    });
    this.getTotalNumberOfKeyFocusAreas();
    this.getKeyFocusAreasColumns();
    this.getKeyFocusAreas(this.paginationDetails);
    this.initializeAddKeyFocusAreas();
    this.initializeUpdateKeyFocusArea();
  }

  get formFields() { return this.addKeyFocusAreaForm.controls; }

  get editFormFields() { return this.updateKeyFocusAreaForm.controls; }


  search() {
    this.searchKFA = true;
    this.setupService.get(`Admin/SearchFromName/${this.paginationDetails.pageNumber}/${this.paginationDetails.pageSize}?queryString=${this.searchForm.value.userName}&searchFor=KeyFocusArea`)
      .subscribe(res => {
        console.log(res);
        this.totalKeyFocusAreas = res.item1;
        this.keyFocusAreas = res.item2;
      });
  }


  onKeyFocusAreaPageChange(event) {

    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };

    if (this.searchKFA) {
      this.search();
    } else {
      console.log('pagination Details', this.paginationDetails),
      this.getKeyFocusAreas(this.paginationDetails);
    }
  }



  initializeAddKeyFocusAreas() {
    this.addKeyFocusAreaForm = this.fb.group({
      keyFocusAreaName: ['', Validators.required],
    });
  }

  initializeUpdateKeyFocusArea() {
    this.updateKeyFocusAreaForm = this.fb.group({
      keyFocusAreaName: ['', Validators.required],
    });
  }

  onStatusChange(value) {
    this.status = value;
  }

  /* --------------------------------------------Add Key Focus Area ------------------------------------------------*/
  addKeyFocusArea() {

    this.submitted = true;
    this.loading = true;
    if (this.addKeyFocusAreaForm.invalid) {
      this.loading = false;
      return this.addKeyFocusAreaForm.value.actionPerformed = null;
    } else {
      const addKeyFocusAreaData = this.addKeyFocusAreaForm.value;
      addKeyFocusAreaData.status = this.status;

      this.setupService.addKeyFocusArea(addKeyFocusAreaData).subscribe((res: any[]) => {
        this.addKeyFocusAreaForm.value.actionPerformed = 'Submit';

        this.displayAddKeyFocusAreasDialog = false;
        this.status = false;
        this.getTotalNumberOfKeyFocusAreas();
        this.messageService.add({severity: 'success', summary: `Key Focus Area`, detail: 'added Successfully'});
        this.getKeyFocusAreas(this.paginationDetails);
        this.loading = false;
        console.log('Key focus Area Saved Successfully');
      }, err => {
        this.loading = false;
        console.log('Error occured in add key focus area:', err);
      });
    }

  }

  /*-------------------------------------- Update Key Focus Area-------------------------------------------- */
  updateKeyFocusArea(keyFocusArea) {
    this.submitted = true;
    this.loading = true;
    if (this.updateKeyFocusAreaForm.invalid) {
      this.loading = false;
      return this.updateKeyFocusAreaForm.value.actionPerformed = null;
    } else {
      const KeyFocusAreaData = this.updateKeyFocusAreaForm.value;
      KeyFocusAreaData.id = keyFocusArea.id;
      KeyFocusAreaData.status = this.status;

      this.setupService.updateKeyFocusArea(KeyFocusAreaData).subscribe((res: any[]) => {
        this.displayUpdateKeyFocusAreasDialog = false;
        this.getKeyFocusAreas(this.paginationDetails);
        this.loading = false;
        this.messageService.add({severity: 'success', summary: `Key Focus Area`, detail: 'Updated Successfully'});
        console.log('Key Focus Area Updated Successfully');
      }, err => {
        this.loading = false;
        console.log('Error occured in Key Focus area:', err);
      });
    }
  }

  /* ---------------------------------------get Key Focus Area By Id------------------------------------------- */
  getKeyFocusAreaById(id) {
    this.setupService.getKeyFocusAreaById(id).subscribe((res: any) => {

      this.updateKeyFocusAreaData = res;
      console.log("-----------key Focus Area Id-----", this.updateKeyFocusAreaData);
    })
  }

  getKeyFocusAreasColumns() {
    this.cols = [
      { field: 'key_focus_area', header: 'Key Focus Area', width: '20%' },
      { field: 'action', header: 'Actions', width: '40%' },
      { field: 'status', header: 'Status', width: '100%' }
    ];
  }

  /* -------------------------------------Get Key Focus Area---------------------------------------- */
  getKeyFocusAreas(paginationDetails) {
    this.loading = true;
    this.searchKFA = false;
    this.setupService.getKeyFocusAreas(paginationDetails).subscribe((res: any[]) => {
      this.keyFocusAreas = res;
      console.log('get Key Focus Areas Details', this.keyFocusAreas);
      this.loading = false;
    }, err => {
      console.log('Error occured in get Key Focus areas:', err);
      this.loading = false;
    });

  }
  /* ----------------------------------------------Get Key Focus Area Count--------------------------------------- */
  getTotalNumberOfKeyFocusAreas() {
    this.setupService.getTotalNumberOfKeyFocusAreas().subscribe((data) => {
      this.totalKeyFocusAreas = data;
      console.log('Total Number of Key Focus Areas', this.totalKeyFocusAreas);
    });
  }
  /* ---------------------------------------------Get Key Focus Areas names--------------------------------------- */
  /*   getKeyFocusAreasNames(){
   this.setupService.getKeyFocusAreasNames().subscribe((res:any[])=>{
     this.keyFocusAreasNames=res;
     console.log("key Focus Area Names",this.keyFocusAreasNames);
   }),
   err=>{
     console.log("error in get key focus areas names",err)
   }
    } */

  cancelAddKeyFocusAreasDialog() {
    this.displayAddKeyFocusAreasDialog = false;
    this.addKeyFocusAreaForm.reset();
    this.status = false;
  }

  showAddKeyFocusAreasDialog() {
    this.displayAddKeyFocusAreasDialog = true;
    this.submitted = false;
    this.addKeyFocusAreaForm.reset();
    this.status = false;

  }


  cancelUpdateAddKeyFocusAreasDialog() {
    this.displayUpdateKeyFocusAreasDialog = false;
    this.updateKeyFocusAreaForm.reset();
  }

  showUpdateKeyFocusAreasDialog(id: any) {
    this.submitted = false;

    this.getKeyFocusAreaById(id)
    this.displayUpdateKeyFocusAreasDialog = true;
  }

}
