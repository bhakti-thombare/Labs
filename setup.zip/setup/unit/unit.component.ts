import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import * as _ from 'lodash';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';



@Component({
  selector: 'app-unit',
  templateUrl: './unit.component.html',
  styleUrls: ['./unit.component.css'],
})
export class UnitComponent implements OnInit {

  cols: any = [];
  units: any = [];
  updateUnitData: any;
  displayAddUnitDialog: Boolean;
  displayUpdateUnitDialog: Boolean;
  addUnitForm: FormGroup;
  updateUnitForm: FormGroup;
  unitDetails: any;
  selectedIds = [];
  selectedWcmIds = [];
  unitLevels: any = [];
  unitLocations: any = [];
  unitHeadsDropDown: any = [];
  unitWcmAdminDropDown: any = [];
  status = true;
  paginationDetails: any;
  totalUnits: any;
  submitted = false;
  update = false;
  dropdownSettings = {};
  dropdownSettingsWcm = {};
  dropdownSettingsLevel = {};
  dropdownSettingsLocation = {};
  loading = true;
  unitLoading = false;
  levelLoading = false;
  locationLoading = false;
  headLoading = false;
  adminLoading = false;
  searchForm: FormGroup;
  searchUnit = false;

  constructor(private fb: FormBuilder, private setupService: SetupService, private messageService: MessageService,
    private excelService: ExcelService) { }


  ngOnInit() {
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm = this.fb.group({
      userName: ['', Validators.required]
    });
    this.getUnitColumns();
    this.getUnits(this.paginationDetails);
    this.initializeAddUnit();
    this.initializeUpdateUnitForm();
    this.getUnitLevels();
    this.getUnitLocations();
    this.getTotalNumberOfUnits();
    this.getUnitHeads();
    this.getWcmAdmin();
    this.dropSettings();

  }

  dropSettings() {
    this.dropdownSettings = {
      singleSelection: false,
      text: 'Choose Unit Head',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      searchBy: ['itemName'],
      limitSelection: 100
    };

    this.dropdownSettingsWcm = {
      singleSelection: false,
      text: 'Choose Wcm Admin',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };
    this.dropdownSettingsLevel = {
      singleSelection: true,
      text: 'Choose Level',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsLocation = {
      singleSelection: true,
      text: 'Choose Location',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };
  }

  initializeAddUnit() {
    this.addUnitForm = this.fb.group({
      unitName: [null, Validators.required],
      unitCode: [null, Validators.required],
      level: [null, Validators.required],
      unitHead: [null, Validators.required],
      location: [null, Validators.required],
      sapUnitCode: [null, Validators.required],
      wcmAdminName: [null, Validators.required],
      status: [this.status],
    });
    console.log(this.addUnitForm.controls.status.value);

    console.log(this.status);

    const unitCode = this.addUnitForm.get('unitCode');
    const sapCode = this.addUnitForm.get('sapUnitCode');
    this.addUnitForm.valueChanges.subscribe(val => {
      sapCode.patchValue(unitCode.value, { emitEvent: false });
    });

    this.addUnitForm.patchValue({
      status: true
    });
  }

  initializeUpdateUnitForm() {
    this.updateUnitForm = this.fb.group({
      unitName: [null, Validators.required],
      unitCode: [null, Validators.required],
      level: [null, Validators.required],
      unitHead: [null, Validators.required],
      location: [null, Validators.required],
      sapUnitCode: [null, Validators.required],
      wcmAdminName: [null, Validators.required],
      // actions:['',Validators.required],
      status: [this.status],
    });
  }

  search() {
    this.searchUnit = true;
    this.setupService.get(`Admin/SearchFromName/${this.paginationDetails.pageNumber}/${this.paginationDetails.pageSize}?queryString=${this.searchForm.value.userName}&searchFor=Unit`)
      .subscribe(res => {
        console.log(res);
        this.totalUnits = res.item1;
        this.units = res.item2;
      });
  }

  reset() {
    this.searchUnit = false;
    const pagination = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm.reset();
    this.getTotalNumberOfUnits();
    this.getUnits(pagination);
  }

  /* Add Unit */
  addUnit() {
    console.log(this.addUnitForm.value);
    this.submitted = true;
    if (this.addUnitForm.invalid) {
      return;
    } else {
      if (this.update) {
        const unitData = this.addUnitForm.value;
        unitData.id = this.updateUnitData.id;
        console.log('----Updated data----', unitData);

        const idArr = [];
        for (let i = 0; i < this.addUnitForm.controls.unitHead.value.length; i++) {
          idArr[i] = '' + this.addUnitForm.controls.unitHead.value[i].id;
        }
        unitData.unitHead = idArr;

        const idWcmArr = [];
        for (let i = 0; i < this.addUnitForm.controls.wcmAdminName.value.length; i++) {
          idWcmArr[i] = '' + this.addUnitForm.controls.wcmAdminName.value[i].id;
        }
        unitData.wcmAdminName = idWcmArr;
        unitData.level = unitData.level[0].itemName;
        unitData.location = unitData.location[0].itemName;

        this.setupService.updateUnit(unitData).subscribe((res: any[]) => {
          this.displayAddUnitDialog = false;
          this.update = false;
          this.messageService.add({ severity: 'success', summary: `${this.addUnitForm.value.unitName}`, detail: 'Updated Successfully' });
          console.log('Unit Updated Successfully');
          this.getUnits(this.paginationDetails);
        }, err => {
          console.log('Error occured in update unit:', err);
          this.messageService.add({ severity: 'error', summary: `${this.addUnitForm.value.unitName}`, detail: 'Update Failed' });
        });
      } else {
        const unitData = this.addUnitForm.value;
        console.log(unitData);
        /*  const unitHeadArray=unitData.UnitHead;
         unitData.UnitHead=unitHeadArray.map(val=>val.userName);
        unitData.unitHeadEmailId=unitHeadArray.map(val=>val.emailId); */
        const idArr = [];
        if (unitData.unitHead != null) {
          if (unitData.unitHead.length > 0) {
            for (let i = 0; i < this.addUnitForm.controls.unitHead.value.length; i++) {
              idArr[i] = '' + this.addUnitForm.controls.unitHead.value[i].id;
            }
            unitData.unitHead = idArr;
          } else {
            unitData.unitHead = null;
          }
        }

        const idWcmArr = [];
        if (this.addUnitForm.controls.wcmAdminName.value != null) {
          for (let i = 0; i < this.addUnitForm.controls.wcmAdminName.value.length; i++) {
            idWcmArr[i] = '' + this.addUnitForm.controls.wcmAdminName.value[i].id;
          }
          unitData.wcmAdminName = idWcmArr;
        }

        unitData.level = unitData.level[0].itemName;
        unitData.location = unitData.location[0].itemName;

        this.setupService.addUnit(unitData).subscribe((res: any[]) => {
          this.displayAddUnitDialog = false;
          this.messageService.add({ severity: 'success', summary: `${this.addUnitForm.value.unitName}`, detail: 'Added Successfully' });
          this.getUnits(this.paginationDetails);
          this.getTotalNumberOfUnits();
          console.log('Unit Saved Successfully');
        }, err => {
          console.log('Error occured in add Unit:', err);
        });
      }
    }
  }

  /* Update unit */
  updateUnit(unit) {
    const unitData = this.updateUnitForm.value;
    unitData.id = unit.id;
    console.log('----Updated data----', unitData);

    this.setupService.updateUnit(unitData).subscribe((res: any[]) => {
      this.displayUpdateUnitDialog = false;
      this.update = false;
      console.log('Unit Updated Successfully');
      this.getUnits(this.paginationDetails);
    }, err => {
      console.log('Error occured in update unit:', err);
    });
  }


  getTotalNumberOfUnits() {
    this.setupService
      .getTotalNumberOfUnits()
      .subscribe((data) => {
        this.totalUnits = data;
        console.log('-----this.totalUnits-----', this.totalUnits);
      });
  }
  // Get kaizens on page change
  onUnitPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    if (this.searchUnit) {
      this.setupService.get(`Admin/SearchFromName/${this.paginationDetails.pageNumber}/${this.paginationDetails.pageSize}?queryString=${this.searchForm.value.userName}&searchFor=Unit`)
      .subscribe(res => {
        this.units = res.item2;
      });
    } else {
      this.getUnits(this.paginationDetails);
    }
    console.log('------Pagination Details After Page Change-----', this.paginationDetails);

  }

  getUnitColumns() {
    this.cols = [
      { field: 'id', header: 'ID' },
      { field: 'unitName', header: 'Unit Name' },
      { field: 'unitHead', header: 'Unit Head' },
      { field: 'location', header: 'Location' },
      { field: 'level', header: 'Level' },
      { field: 'wcmAdminName', header: 'WCM Admin' },
      { field: 'sapUnitCode', header: 'SAP Unit Code' },
      { field: 'actions', header: 'Actions' },
      { field: 'status', header: 'Status' },
    ];
  }

  get formFields() { return this.addUnitForm.controls; }

  getUnits(paginationDetails) {
    /*  this.paginationDetails = {
       pageNumber: 0,
       pageSize: 5
     } */
    this.unitLoading = true;
    this.searchUnit = false;
    this.setupService.getUnits(paginationDetails).subscribe((res: any[]) => {
      this.units = res;
      console.log('----Units----', this.units);
      this.unitLoading = false;
      this.loadOninit();

    }, err => {
      console.log('Error occured in get units:', err);
      this.unitLoading = false;
      this.loadOninit();
    });
  }

  getUnitLevels() {

    this.levelLoading = true;
    this.setupService.getUnitLevels().subscribe((res: any[]) => {
      console.log(res);
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index], id: res[index] });
      }
      console.log(newData);

      this.unitLevels = this.unitLevels.concat(newData);
      console.log('----Unit Levels----', this.unitLevels);
      const operIndex = _.findIndex(this.unitLevels, (d) => d['itemName'] == 'Operational Excellence');
      console.log('operIndex', operIndex);
      if (operIndex != -1) {
        this.addUnitForm.patchValue({
          level: [this.unitLevels[operIndex]]
        });
      }
      this.levelLoading = false;
      this.loadOninit();

    }, err => {
      console.log('Error occured in get units:', err);
      this.levelLoading = false;
      this.loadOninit();
    });
  }

  getUnitLocations() {
    this.locationLoading = true;
    this.setupService.getUnitLocations().subscribe((res: any[]) => {
      // console.log('----Unit Locations----', this.unitLocations);

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index], id: res[index] });
      }
      console.log(newData);

      this.unitLocations = this.unitLocations.concat(newData);
      this.locationLoading = false;
      this.loadOninit();

    }, err => {
      console.log('Error occured in get units:', err);
      this.locationLoading = false;
      this.loadOninit();
    });
  }


  /* ------------------------Get Unit Heads----------------- */
  getUnitHeads() {
    this.headLoading = true;
    this.setupService.getUnitHeads().subscribe((res: any[]) => {
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({ itemName: element.userName, id: element.id });

        }
      }

      this.unitHeadsDropDown = this.unitHeadsDropDown.concat(newData);
      this.headLoading = false;
      this.loadOninit();
      // for (const list of this.unitHeadsDropDown) {
      //   newData.push({ 'id': list['id'], 'itemName': list['id'], 'type': list['type'], 'description': list['description'] });
      // }
      // this.unitHeadsDropDown = this.unitHeadsDropDown.concat(newData);
      // console.log(Math.floor(Math.random() * this.unitHeadsDropDown.length));

    }, err => {
      this.headLoading = false;
      this.loadOninit();
    });
  }
  /* -------------------------Get Wcm Admin------------------ */
  getWcmAdmin() {
    this.adminLoading = true;
    this.setupService.getWcmAdmin().subscribe((res: any[]) => {
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({ itemName: element.userName, id: element.id });
        }
      }

      this.unitWcmAdminDropDown = this.unitWcmAdminDropDown.concat(newData);
      this.adminLoading = false;
      this.loadOninit();
    }, err => {
      this.adminLoading = false;
      this.loadOninit();
    });
  }
  showAddUnitDialog() {
    // this.addUnitForm.reset();
    this.displayAddUnitDialog = true;
    const operIndex = _.findIndex(this.unitLevels, (d) => d['itemName'] == 'Operational Excellence');
    console.log('operIndex', operIndex);
    if (operIndex != -1) {
      this.addUnitForm.patchValue({
        level: [this.unitLevels[operIndex]]
      });
    }
    this.update = false;
  }

  cancelAddUnitDialog() {
    this.displayAddUnitDialog = false;
    this.addUnitForm.reset();
    this.submitted = false;
    this.update = false;
  }

  showUpdateUnitDialog(id) {
    this.getUnitById(id);
    this.displayAddUnitDialog = true;
    this.updateUnitForm.reset();
    this.update = true;
  }

  cancelUpdateUnitDialog() {
    this.displayAddUnitDialog = false;
  }

  getUnitById(id) {
    this.setupService.getUnitById(id).subscribe((res: any) => {
      this.updateUnitData = res;
      console.log('this.updateUnitData', this.updateUnitData);
      console.log('res', res);
      // this.addUnitForm.patchValue(res);
      this.addUnitForm.patchValue({
        unitName: res.unitName,
        unitCode: res.unitCode,
        sapUnitCode: res.sapUnitCode,
        status: res.status
      });
      this.status = res.status;
      const selectedHead = [];
      const selectedAdmin = [];
      console.log('----Unit Details----', this.unitDetails);
      if (res.unitHead != null) {
        for (let i = 0; i < res.unitHead.length; i++) {
          const index = _.findIndex(this.unitHeadsDropDown, (d) => d['itemName'] === res.unitHead[i]);
          console.log(index);
          if (index != -1) {
            selectedHead.push(this.unitHeadsDropDown[index]);
          }
        }
      }

      if (res.wcmAdminName != null) {
        for (let i = 0; i < res.wcmAdminName.length; i++) {
          const index = _.findIndex(this.unitWcmAdminDropDown, (d) => d['itemName'] === res.wcmAdminName[i]);
          console.log(index);
          if (index != -1) {
            selectedAdmin.push(this.unitWcmAdminDropDown[index]);
          }
        }
      }

      const selectedLevel = [];
      const selectedLocation = [];
      const indexLevel = _.findIndex(this.unitLevels, (d) => d['itemName'] === res.level);
      console.log(indexLevel);
      if (indexLevel != -1) {
        selectedLevel.push(this.unitLevels[indexLevel]);
      }

      const indexLocation = _.findIndex(this.unitLocations, (d) => d['itemName'] === res.location);
      console.log(indexLocation);
      if (indexLocation != -1) {
        selectedLocation.push(this.unitLocations[indexLocation]);
      }

      this.addUnitForm.patchValue({
        unitHead: selectedHead,
        wcmAdminName: selectedAdmin,
        level: selectedLevel,
        location: selectedLocation
      });

    }, err => {
      console.log('Error occured in get getUnitById:', err);
    });
  }

  select(e) {
    console.log(e);
    this.selectedIds = e.value;
  }

  selectWCMAdmin(e) {
    console.log(e);
    this.selectedWcmIds = e.value;
  }

  loadOninit() {
    console.log('!this.unitLoading && !this.levelLoading && !this.locationLoading && !this.headLoading && !this.adminLoading', !this.unitLoading && !this.levelLoading && !this.locationLoading && !this.headLoading && !this.adminLoading);

    if (!this.unitLoading && !this.levelLoading && !this.locationLoading && !this.headLoading && !this.adminLoading) {
      this.loading = false;
    }
  }

  exportAsXLSX() {
    if (this.units.length > 0) {
      this.excelService.exportAsExcelFile(this.units, 'sample');
    }
  }

}
