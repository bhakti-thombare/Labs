import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';
@Component({
  selector: 'app-months',
  templateUrl: './months.component.html',
  styleUrls: ['./months.component.css']
})
export class MonthsComponent implements OnInit {
  cols: any = [];
  months: any = [];
  paginationDetails: any;
  submitted: Boolean = false;
  status: Boolean = false;
  totalMonth: any;
  updateMonthData: any;
  monthsNames: any[];
  displayMonthDialog: Boolean;
  displayUpdateMonthDialog: Boolean;
  addMonthForm: FormGroup;
  updateMonthForm: FormGroup;
  update = false;
  loading = true;
  constructor(private fb: FormBuilder, private setupService: SetupService, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.getTotalNumberOfMonth();
    this.getMonthColumns();
    this.getMonths(this.paginationDetails);
    this.initializeAddMonthForm();
    this.initializeUpdateMonthForm();
  }

  get formFields() { return this.addMonthForm.controls; }
  get editFormFields() { return this.updateMonthForm.controls; }



  /* -------------------------------onChange------------------------------ */
  onMonthPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    console.log('on Month Page change pagination details', this.paginationDetails);
    this.getMonths(this.paginationDetails);
  }

  onStatusChange(value) {
    this.status = value;
  }

  initializeAddMonthForm() {
    this.addMonthForm = this.fb.group({
      monthNameTitle: ['', Validators.required],
    });
  }


  initializeUpdateMonthForm() {
    this.updateMonthForm = this.fb.group({
      monthNameTitle: ['', Validators.required],
    });
  }


  /* ---------------------------------------------------Add Month----------------------------------------------- */
  addMonth() {
    this.submitted = true;
    this.loading = true;
    if (this.addMonthForm.invalid) {
      this.loading = false;
      return;
    } else {
      if (this.update) {
        const monthData = this.addMonthForm.value;
        monthData.id = this.updateMonthData.id;
        monthData.status = this.status;

        this.setupService.updateMonth(monthData).subscribe((res: any[]) => {
          this.displayMonthDialog = false;
          this.update = false;
          this.getMonths(this.paginationDetails);
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `Month`, detail: 'Updated Successfully'});
          console.log('Month Updated Successfully');
          console.log('Updated Data', monthData);
        }, err => {
          this.loading = false;
          console.log('Error occured in update month:', err);
        });
      } else {
        const monthData = this.addMonthForm.value;
        monthData.status = this.status;

        this.setupService.addMonth(monthData).subscribe((res: any[]) => {
          this.displayMonthDialog = false;
          this.status = false;
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `Month`, detail: 'added Successfully'});
          console.log('Month Saved Successfully');
          this.getTotalNumberOfMonth();
          this.getMonths(this.paginationDetails);
        }, err => {
          this.loading = false;
          console.log('Error occured in add month:', err);
        });
      }
    }
  }

  /* -------------------------------------------------Update Months------------------------------------------------------- */
  updateMonth(month) {
    this.submitted = true;

    if (this.updateMonthForm.invalid) {
      return this.updateMonthForm.value.actionPerformed = null;

    } else {
      const monthData = this.updateMonthForm.value;
      monthData.id = month.id;
      monthData.status = this.status;

      this.setupService.updateMonth(monthData).subscribe((res: any[]) => {
        this.displayMonthDialog = false;
        this.update = false;
        this.getMonths(this.paginationDetails);

        console.log('Month Updated Successfully');
        console.log('Updated Data', monthData);
      }, err => {
        console.log('Error occured in update month:', err);
      });
    }
  }


  /* ----------------------------Get Month Columns--------------------------------------------- */
  getMonthColumns() {
    this.cols = [
      { field: 'monthNameTitle', header: 'Month' },
      { field: 'action', header: 'Action' },
      { field: 'status', header: 'Status' }
    ];
  }
  /* ----------------------------------------Get months---------------------------------------- */
  getMonths(paginationDetails) {
    this.loading = true;
    this.setupService.getMonths(paginationDetails).subscribe((res: any[]) => {
      this.months = res;
      this.loading = false;
    }, err => {
      console.log('Error occured in get months:', err);
      this.loading = false;
    });

  }
  /* -------------------------------------------------Get Total no of month--------------------------------------- */
  getTotalNumberOfMonth() {
    this.setupService.getTotalNumberOfMonth().subscribe((data) => {
      this.totalMonth = data;
      console.log('total number of month count', this.totalMonth);

    });
  }
  /* ----------------------------------------------Get Month Names---------------------------------------- */
  /* getMonthsNames(){
    this.setupService.getMonthsNames().subscribe((res:any)=>{
      this.monthsNames=res;
     console.log('Months names of the month',this.monthsNames);
    });err=>{
      console.log('error in the months names',err);
    }
  } */

  /* -------------------------------------------Get Month By Id ------------------------------------------------*/
  getMonthById(id) {
    this.setupService.getMonthById(id).subscribe((res: any) => {
      this.updateMonthData = res;
      this.addMonthForm.patchValue(res);
      this.status = this.updateMonthData.status;
      console.log('get Month bY id', this.updateMonthData);
    }, err => {
      console.log('Error in get month by id', err);
    });
  }

  cancelAddMonthDialog() {
    this.displayMonthDialog = false;
    this.addMonthForm.reset();
    this.status = false;
    this.update = false;

  }

  showAddMonthDialog() {
    this.displayMonthDialog = true;
    this.addMonthForm.reset();
    this.submitted = false;
    this.status = false;
  }

  cancelUpdateMonthDialog() {
    this.displayMonthDialog = false;
    this.updateMonthForm.reset();
  }

  showUpdateMonthDialog(id: any) {
    this.submitted = false;
    this.update = true;
    this.getMonthById(id);
    this.displayMonthDialog = true;
  }

  exportAsXLSX() {
    if (this.months.length > 0) {
      this.excelService.exportAsExcelFile(this.months, 'sample');
    }
  }
}
