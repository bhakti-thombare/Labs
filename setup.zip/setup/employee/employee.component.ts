import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, AbstractControl } from '@angular/forms';
import { SetupService } from '../setup.service';
import { SelectItem } from 'primeng/api/selectitem';
import * as _ from 'lodash';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  appraisersListDropdown: any = [];
  selectedAppraisers: any[] = [];
  reviewersListDropdown: any = [];
  selectedReviewers: any[] = [];
  proficiencyLevelsListDropdown: any = [];
  selectedProficiencyLevels: any[] = [];
  userNameListDropdown: any[] = [];
  selectedUserNames: any[] = [];


  employeeDropdownsData: any = {};
  cols: any = [];
  employeeList: any = [];
  proficiencyLevels: any = [];
  employeeSubCommittees = [];
  employeeCategories: any;
  employeeUnits = [];
  employeeRoles = [];
  employeeTeams = [];
  employeeDepartment: any;
  scopeDepartmentAcrossUnit: any;
  employeeDepartments = [];
  totalEmployees: any;
  employees: any = [];
  displayAddEmployeeDialog: Boolean;
  displayUpdateEmployeeDialog: Boolean;
  addEmployeeForm: FormGroup;
  updateEmployeeForm: FormGroup;
  paginationDetails: any;
  employeePositions = [];
  updateEmployeeData: any;
  reviewers: any = [];
  appraisers: any = [];
  unitCode: any;
  loading = true;
  config = {
    displayKey: 'label',
    search: true, // true/false for the search functionlity defaults to false,
    height: 'auto',
    placeholder: 'Select',
    customComparator: () => { },
    limitTo: this.userNameListDropdown.length,
    moreText: 'more',
    noResultsFound: 'No results found!',
    searchPlaceholder: 'Search',
    searchOnKey: 'label'
  };
  uniqList: unknown[];
  selectedProficiencyLevel: any;
  update = false;
  importDailog = false;
  addEmployeeImport: FormGroup;
  searchForm: FormGroup;
  submitted = false;
  dropdownSettings = {};
  dropdownSettingsProf = {};
  dropdownSettingsUnit = {};
  dropdownSettingsDept = {};
  dropdownSettingsTeam = {};
  dropdownSettingsPos = {};
  dropdownSettingsRole = {};
  dropdownSettingsSub = {};
  dropdownSettingsRev = {};
  dropdownSettingsApp = {};
  dropdownSettingsSection = {};
  accountName: any;
  usedId = false;
  matchPass: boolean;
  listStatus = true;
  searchEmp = false;
  workId: any;
  appLoading = true;
  revLoading = true;
  getEmployeeLoading = true;
  unitLoading = true;
  posLoading = true;
  roleLoading = true;
  categoryLoading = true;
  nameLoading = true;
  proficiencyLoading = true;
  employeeSections = [];
  isSelected: any;
  hasChangePassword = false;
  token: string = "#$AdityaBirla!&*";
  encrypted: any = "";
  decrypted: string;
  request: string;
  response: string;
  exportEmployees: any;
  importFile: any;

  constructor(private fb: FormBuilder, private setupService: SetupService, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {
    this.addEmployeeImport = this.fb.group({
      excelFile: ''
    });

    this.searchForm = this.fb.group({
      userName: ['', Validators.required]
    });

    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
/*     this.getEmployeeDepartmentField();
 */    this.getEmployeeColumns();
       this.initializeAddEmployeeForm();
       this.dropSettings();
       this.initializeUpdateEmployeeForm();
    // this.getEmployees(this.paginationDetails);
       this.setupService.requestDataFromMultipleSources()
          .subscribe(res => {
            console.log(res);
            this.employees = res[0]
            this.totalEmployees = res[1]
            const newData = [];
            for (let index = 0; index < res[2].length; index++) {
              newData.push({ itemName: res[2][index].unitName, id: res[2][index].id });
            }
            console.log(newData);
            this.employeeUnits = this.employeeUnits.concat(newData);

            const newDataPos = [];
            for (let index = 0; index < res[3].length; index++) {
              newDataPos.push({ itemName: res[3][index].positionName, id: res[3][index].positionId });
            }
            console.log(newDataPos);

            this.employeePositions = this.employeePositions.concat(newDataPos);
            const newDataRole = [];
            for (let index = 0; index < res[4].length; index++) {
              newDataRole.push({ itemName: res[4][index].roleName, id: res[4][index].roleId });
            }
            this.employeeRoles = [];
            console.log(newDataRole);
            if (sessionStorage.getItem('userRole') == 'Power User') {
              newDataRole.splice(2, 2);
              this.employeeRoles = this.employeeRoles.concat(newDataRole);
            } else {
              this.employeeRoles = this.employeeRoles.concat(newDataRole);
            }

            this.employeeCategories = res[5]
            for (let index = 0; index < res[6].length; index++) {
              const element = res[6][index];
              if (element.userName) {
                this.userNameListDropdown.push({ itemName: element.userName, id: element.id });
              }
            }
            const newDataProf = [];
            for (let index = 0; index < res[7].length; index++) {
              const element = res[7][index];
              if (element.proficiencyLevelName) {
                newDataProf.push({ itemName: element.proficiencyLevelName, id: element.proficiencyLevelId });
              }
            }
            this.proficiencyLevelsListDropdown = this.proficiencyLevelsListDropdown.concat(newDataProf);
            this.loading = false
          })


    // this.getEmployeeTotalCount();
    // this.getEmployeeUnitField();
    // this.getPositionOfEmployee();
    // // this.getSubCommittee();
    // this.getRoleOfEmployee();
    // this.getEmployeeCategoryOfEmployee();
    // this.getEmployeeNames();
    // this.getProficiencyLevels();
    // this.getSections();
  }

  dropSettings() {
    this.dropdownSettings = {
      singleSelection: true,
      text: 'Choose Unit Head',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsSection = {
      singleSelection: true,
      text: 'Choose Section',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsRev = {
      singleSelection: true,
      text: 'Choose Reviewer',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsApp = {
      singleSelection: true,
      text: 'Choose Appraiser',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsProf = {
      singleSelection: false,
      text: 'Choose Proficiency Level',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsUnit = {
      singleSelection: true,
      text: 'Choose Unit',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100,
      disabled: true
    };

    this.dropdownSettingsDept = {
      singleSelection: true,
      text: 'Choose Department',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsTeam = {
      singleSelection: true,
      text: 'Choose Team',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsSub = {
      singleSelection: true,
      text: 'Choose Sub Committee',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsPos = {
      singleSelection: true,
      text: 'Choose Position',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsRole = {
      singleSelection: true,
      text: 'Choose Role',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };
  }

  initializeAddEmployeeForm() {
    this.addEmployeeForm = this.fb.group({
      unitId: [null, Validators.required],
      departmentId: [null, Validators.required],
      sectionId: [null, Validators.required],
      teamId: [null, Validators.required],
      subCommitteeId: [null],
      mobileNo: ['', [Validators.min(1000000000), Validators.required, Validators.max(9999999999)]],
      appraisers: [null, Validators.required],
      reviewers: [null, Validators.required],
      employeeCategory: ['Wageboard', Validators.required],
      id: [null, Validators.required],
      proficiencyLevels: [null, Validators.required],
      position: [null, Validators.required],
      role: [null, Validators.required],
      emailId: [null, Validators.required],
      loginId: [null, Validators.required],
      passwords: this.fb.group({
        password: ['', [Validators.required]],
        confirmPassword: ['', [Validators.required]],
      }, { validator: this.passwordConfirming }),
      status: [true],
    });
  }

  passwordConfirming(c: AbstractControl): { invalid: boolean } {
    if (c.get('password').value !== c.get('confirmPassword').value) {
      return { invalid: true };
    }
  }

  initializeUpdateEmployeeForm() {
    this.updateEmployeeForm = this.fb.group({
      unitId: [null, Validators.required],
      departmentId: [null, Validators.required],
      sectionId: [null, Validators.required],
      teamId: [null, Validators.required],
      subCommitteeId: [null],
      mobileNo: ['', [Validators.min(1000000000), Validators.required, Validators.max(9999999999)]],
      appraisers: [null, Validators.required],
      reviewers: [null, Validators.required],
      employeeCategory: [null, Validators.required],
      id: [null, Validators.required],
      proficiencyLevels: [null, Validators.required],
      position: [null, Validators.required],
      role: [null, Validators.required],
      emailId: ['', Validators.required],
      loginId: [''],
      passwords: this.fb.group({
        password: ['', [Validators.required]],
        confirmPassword: ['', [Validators.required]],
      }, { validator: this.passwordConfirming }),
      status: [false, Validators.required],
    });
  }

  encryptUsingAES256(employeeData, password) {
    let _key = CryptoJS.enc.Utf8.parse(this.token);
    let _iv = CryptoJS.enc.Utf8.parse(this.token);
    let encrypted = CryptoJS.AES.encrypt(
      JSON.stringify(password), _key, {
      keySize: 16,
      iv: _iv,
      mode: CryptoJS.mode.ECB,
      padding: CryptoJS.pad.Pkcs7
    });
    this.encrypted = encrypted.toString();
    employeeData.password = this.encrypted;
  }

  get formFields() { return this.addEmployeeForm.controls; }

  get updateFormFields() { return this.updateEmployeeForm.controls; }


  onSelectProficiencyLevel(proficiencyLevel: string, isChecked: boolean) {
    const proficiencyLevelsArray = <FormArray>this.addEmployeeForm.controls.proficiencyLevels;
    if (isChecked) {
      proficiencyLevelsArray.push(new FormControl(proficiencyLevel));
    } else {
      // tslint:disable-next-line: triple-equals
      const index = proficiencyLevelsArray.controls.findIndex(x => x.value == proficiencyLevel);
      proficiencyLevelsArray.removeAt(index);
    }
  }


  onEmployeePageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows,
    };
    console.log('--------------pagination details-----', this.paginationDetails);
    if (this.listStatus) {
      if (this.searchEmp) {
        this.setupService.getEmployeeSearch(this.paginationDetails, this.searchForm.value)
          .subscribe(res => {
            this.employees = res.item2;
          });
      } else {
        this.getEmployees(this.paginationDetails);
      }
    } else {
      if (this.searchEmp) {
        this.setupService.getWorkManEmployeeSearch(this.paginationDetails, this.searchForm.value)
          .subscribe(res => {
            this.employees = res.item2;
          });
      } else {
        this.setupService.getWorkManEmployees(this.paginationDetails)
          .subscribe(res => {
            this.employees = res;
          });
      }
    }
  }




  /* Add Employee */
  addEmployee() {
    this.loading = true;
    this.submitted = true;

    if (this.addEmployeeForm.invalid) {
      this.loading = false;
      console.log('this.addEmployeeForm', this.addEmployeeForm);
      return;
    } else {
      const proficiencyLevels = [];

      for (let i = 0; i < this.addEmployeeForm.controls.proficiencyLevels.value.length; i++) {
        proficiencyLevels[i] = '' + this.addEmployeeForm.controls.proficiencyLevels.value[i].id;
      }

      console.log('this.addEmployeeForm.value', this.addEmployeeForm.value);

      const employeeData: any = {};
      console.log('-----this.addEmployeeForm.value----', this.addEmployeeForm.value);
      console.log('-----this.employeeDropdownsData----', this.employeeDropdownsData);


      if (this.update) {
        this.updateEmployeeForm.patchValue({
          appraisers: ['' + this.updateEmployeeForm.controls.appraisers.value[0].id],
          reviewers: ['' + this.updateEmployeeForm.controls.reviewers.value[0].id],
          proficiencyLevels: proficiencyLevels,
          unitId: '' + this.updateEmployeeForm.controls.unitId.value,
          // id: [+this.updateEmployeeForm.controls.id.value[0].id]
        });
        employeeData.status = this.updateEmployeeForm.value.status;
        employeeData.proficiencyLevels = this.updateEmployeeForm.value.proficiencyLevels;
        employeeData.employeeCategory = this.updateEmployeeForm.value.employeeCategory;
        // employeeData.accountName = this.accountName;
        employeeData.appraisers = this.updateEmployeeForm.value.appraisers;
        employeeData.reviewers = this.updateEmployeeForm.value.reviewers;
        employeeData.mobileNo = this.updateEmployeeForm.value.mobileNo;

        employeeData.unitId = this.updateEmployeeForm.value.unitId;
        employeeData.departmentId = this.updateEmployeeForm.value.departmentId;
        employeeData.subcommitteeId = this.updateEmployeeForm.value.subcommitteeId;
        employeeData.teamId = this.updateEmployeeForm.value.teamId;
        employeeData.positionId = this.updateEmployeeForm.value.positionId;
        employeeData.roleId = this.updateEmployeeForm.value.roleId;

        employeeData.unit = this.employeeDropdownsData.unit;
        employeeData.department = this.employeeDropdownsData.department;
        employeeData.subCommitteeNameTitle = this.employeeDropdownsData.subCommitteeNameTitle;
        employeeData.team = this.employeeDropdownsData.team;
        employeeData.position = '' + this.updateEmployeeForm.value.position;
        employeeData.role = '' + this.updateEmployeeForm.value.role;
        employeeData.id = this.updateEmployeeForm.value.id;
        this.setupService.updateEmployee(employeeData).subscribe((res: any[]) => {
          this.displayAddEmployeeDialog = false;
          this.getEmployeeTotalCount();
          this.getEmployees(this.paginationDetails);
          this.update = false;
          this.submitted = false;
          this.loading = false;
          console.log('Employee Updated Successfully');
        }, err => {
          console.log('Error occured in update Employee:', err);
        });
      } else {
        // this.addEmployeeForm.patchValue({
        //   appraisers: ['' + this.addEmployeeForm.controls.appraisers.value[0].id],
        //   reviewers: ['' + this.addEmployeeForm.controls.reviewers.value[0].id],
        //   proficiencyLevels: proficiencyLevels,
        //   // unitId: '' + this.addEmployeeForm.controls.unitId.value,
        //   // id: [+this.addEmployeeForm.controls.id.value[0].id],
        //   departmentId: '' + this.addEmployeeForm.controls.departmentId.value[0].id,
        //   teamId: '' + this.addEmployeeForm.controls.teamId.value[0].id,
        // });
        employeeData.status = this.addEmployeeForm.value.status;
        employeeData.proficiencyLevels = proficiencyLevels;
        employeeData.employeeCategory = this.addEmployeeForm.value.employeeCategory;
        // employeeData.accountName = this.accountName;
        employeeData.appraisers = ['' + this.addEmployeeForm.controls.appraisers.value[0].id];
        employeeData.reviewers = ['' + this.addEmployeeForm.controls.reviewers.value[0].id];
        employeeData.mobileNo = '' + this.addEmployeeForm.value.mobileNo;

        employeeData.unitId = '' + this.addEmployeeForm.value.unitId[0].id;
        employeeData.sectionId = '' + this.addEmployeeForm.value.sectionId[0].id;
        employeeData.departmentId = '' + this.addEmployeeForm.controls.departmentId.value[0].id;
        // console.log('this.addEmployeeForm.value.subCommitteeId[0].id', this.addEmployeeForm.value.subCommitteeId[0].id);
        if (this.addEmployeeForm.value.subCommitteeId != null) {
          if (this.addEmployeeForm.value.subCommitteeId.length > 0) {
          employeeData.subcommitteeId = '' + this.addEmployeeForm.value.subCommitteeId[0].id;
          }
        }
        employeeData.teamId = '' + this.addEmployeeForm.controls.teamId.value[0].id;
        employeeData.positionId = this.addEmployeeForm.value.positionId;
        employeeData.roleId = this.addEmployeeForm.value.roleId;
        employeeData.userName = this.addEmployeeForm.value.id;
        console.log('this.addEmployeeForm.value.id', this.addEmployeeForm.value.id);

        employeeData.unit = this.employeeDropdownsData.unit;
        employeeData.department = this.employeeDropdownsData.department;
        employeeData.subCommitteeNameTitle = this.employeeDropdownsData.subCommitteeNameTitle;
        employeeData.team = this.employeeDropdownsData.team;
        employeeData.position = '' + this.addEmployeeForm.value.position[0].id;
        employeeData.role = '' + this.addEmployeeForm.value.role[0].id;
        // this.addEmployeeForm.controls.passwords.setValidators(Validators.required);
        console.log('this.addEmployeeForm.controls.passwords[\'password\']', this.addEmployeeForm.get(['passwords', 'password']).value);
        employeeData.password = this.addEmployeeForm.get(['passwords', 'password']).value;
        this.encryptUsingAES256(employeeData, employeeData.password);
        employeeData.loginId = this.addEmployeeForm.controls.loginId.value;
        employeeData.emailId = this.addEmployeeForm.controls.emailId.value;
        this.setupService.createWorkmanEmployee(employeeData).subscribe((resp: any[]) => {
          console.log('Employee Saved Successfully');
          this.displayAddEmployeeDialog = false;
          this.loading = false;
          this.setupService.getWorkManEmployeeTotalCount().subscribe((data) => {
            this.totalEmployees = data;
            this.submitted = false;
            this.messageService.add({ severity: 'success', summary: `Employee`, detail: 'created Successfully' });
            console.log('-----------Total EMployeee-----------', this.totalEmployees);
          });
          this.setupService.getWorkManEmployees(this.paginationDetails)
            .subscribe(res => {
              this.employees = res;
            });
          this.addEmployeeForm.reset();
        }, err => {
          console.log('Error occured in add department:', err);
          this.loading = false;
          this.messageService.add({ severity: 'fa', summary: `${employeeData.userName}`, detail: 'created Successfully' });
        });
      }
    }

  }

  /* Update Employee */
  updateEmployee(employee) {
    console.log(this.submitted);
    console.log(this.updateEmployeeForm.get('loginId').errors);
    this.loading = true;
    this.submitted = true;
    if (this.updateEmployeeForm.value.passwords.password == "" && this.updateEmployeeForm.value.passwords.confirmPassword == "") {
      //this.updateEmployeeForm.controls["passwords"].clearValidators();
      //this.updateEmployeeForm.controls["passwords"].updateValueAndValidity();      
      this.updateEmployeeForm.get(['passwords', 'password']).clearValidators();
      this.updateEmployeeForm.get(['passwords', 'password']).updateValueAndValidity();
      this.updateEmployeeForm.get(['passwords', 'confirmPassword']).clearValidators();
      this.updateEmployeeForm.get(['passwords', 'confirmPassword']).updateValueAndValidity();
    } else {
      //this.updateEmployeeForm.controls["passwords"].setValidators([Validators.required]);
      //this.updateEmployeeForm.controls["passwords"].updateValueAndValidity();
      this.updateEmployeeForm.get(['passwords', 'password']).setValidators([Validators.required]);
      this.updateEmployeeForm.get(['passwords', 'password']).updateValueAndValidity();
      this.updateEmployeeForm.get(['passwords', 'confirmPassword']).setValidators([Validators.required]);
      this.updateEmployeeForm.get(['passwords', 'confirmPassword']).updateValueAndValidity();
    }
    if (this.updateEmployeeForm.invalid) {
      console.log('this.updateEmployeeForm', this.updateEmployeeForm.value);
      this.loading = false;
      return;
    }
    const proficiencyLevels = [];

    for (let i = 0; i < this.updateEmployeeForm.controls.proficiencyLevels.value.length; i++) {
      proficiencyLevels[i] = '' + this.updateEmployeeForm.controls.proficiencyLevels.value[i].id;
    }

    console.log('this.updateEmployeeForm.value', this.updateEmployeeForm.value);

    const employeeData: any = {};
    console.log('-----this.updateEmployeeForm.value----', this.updateEmployeeForm.value);
    console.log('-----this.employeeDropdownsData----', this.employeeDropdownsData);
    if (this.listStatus) {
      this.updateEmployeeForm.patchValue({
        id: [+this.updateEmployeeForm.controls.id.value[0].id]
      });
    } else {
      // this.updateEmployeeForm.patchValue({
      //   id: [+this.workId]
      // });
    }
    // this.updateEmployeeForm.patchValue({
    //   appraisers: ['' + this.updateEmployeeForm.controls.appraisers.value[0].id],
    //   reviewers: ['' + this.updateEmployeeForm.controls.reviewers.value[0].id],
    //   proficiencyLevels: proficiencyLevels,
    //   departmentId: '' + this.updateEmployeeForm.controls.departmentId.value[0].id,
    //   teamId: '' + this.updateEmployeeForm.controls.teamId.value[0].id,
    // });
    employeeData.status = this.updateEmployeeForm.value.status;
    employeeData.proficiencyLevels = proficiencyLevels;
    employeeData.employeeCategory = this.updateEmployeeForm.value.employeeCategory;
    // employeeData.accountName = this.accountName;
    employeeData.appraisers = ['' + this.updateEmployeeForm.controls.appraisers.value[0].id];
    employeeData.reviewers = ['' + this.updateEmployeeForm.controls.reviewers.value[0].id];
    employeeData.mobileNo = '' + this.updateEmployeeForm.value.mobileNo;
    employeeData.unitId = '' + this.updateEmployeeForm.value.unitId[0].id;
    const unit = this.updateEmployeeForm.value.unitId[0].itemName;
    employeeData.departmentId = '' + this.updateEmployeeForm.controls.departmentId.value[0].id;
    if (this.updateEmployeeForm.value.subCommitteeId != null) {
      if (this.updateEmployeeForm.value.subCommitteeId.length > 0) {
        employeeData.subcommitteeId = '' + this.updateEmployeeForm.value.subCommitteeId[0].id;
      }
    } else {
      employeeData.subcommitteeId = null;
    }
    employeeData.teamId = '' + this.updateEmployeeForm.controls.teamId.value[0].id;
    employeeData.positionId = this.updateEmployeeForm.value.positionId;
    employeeData.roleId = this.updateEmployeeForm.value.roleId;
    employeeData.status = this.updateEmployeeForm.value.status;
    employeeData.sectionId = '' + this.updateEmployeeForm.value.sectionId[0].id;

      // employeeData.unit = this.employeeDropdownsData.unit;
      // employeeData.department = this.employeeDropdownsData.department;
      // employeeData.subCommitteeNameTitle = this.employeeDropdownsData.subCommitteeNameTitle;
      // employeeData.team = this.employeeDropdownsData.team;
      employeeData.position = '' + this.updateEmployeeForm.value.position[0].id;
    console.log('this.updateEmployeeForm.value.position', this.updateEmployeeForm.value.position);
    employeeData.role = '' + this.updateEmployeeForm.value.role[0].id;
    employeeData.id = this.updateEmployeeForm.value.id;
    employeeData.emailId = this.updateEmployeeForm.value.emailId;
    console.log('employeeData', employeeData);
    if (this.listStatus) {
      if (this.updateEmployeeForm.value.passwords.password == "" && this.updateEmployeeForm.value.passwords.confirmPassword == "") {
        employeeData.password = this.updateEmployeeForm.get(['passwords', 'password']).value;
        this.encryptUsingAES256(employeeData, employeeData.password);
      }
      employeeData.isSelected = this.isSelected;
      this.setupService.updateEmployee(employeeData).subscribe((res: any[]) => {
        this.displayAddEmployeeDialog = false;
        sessionStorage.setItem('unitId', employeeData.unitId);
        sessionStorage.setItem('unit', unit);
        this.getEmployeeTotalCount();
        this.getEmployees(this.paginationDetails);
        this.update = false;
        this.submitted = false;
        this.loading = false;
        //  Swal.fire('Employee Updated Successfully')
        console.log('Employee Updated Successfully');
        this.getEmployeeCategoryOfEmployee();
        this.messageService.add({ severity: 'success', summary: `Employee`, detail: 'updated Successfully' });
      }, err => {
        console.log('Error occured in update Employee:', err);
        this.getEmployeeCategoryOfEmployee();
        this.loading = false;
      });
    } else {
      employeeData.userName = this.updateEmployeeForm.controls.id.value;
      employeeData.id = +this.workId;
      employeeData.password = this.updateEmployeeForm.get(['passwords', 'password']).value;
      this.encryptUsingAES256(employeeData, employeeData.password);
      this.setupService.updateWorkManEmployee(employeeData).subscribe((res: any[]) => {
        this.displayAddEmployeeDialog = false;
        this.setupService.getWorkManEmployeeTotalCount().subscribe((data) => {
          this.totalEmployees = data;
          console.log('-----------Total EMployeee-----------', this.totalEmployees);
        });
        this.setupService.getWorkManEmployees(this.paginationDetails)
          .subscribe(res1 => {
            this.employees = res1;
          });
        this.update = false;
        this.submitted = false;
        this.messageService.add({ severity: 'success', summary: `Workmen Employee`, detail: 'updated Successfully' });
        this.loading = false;
        console.log('Employee Updated Successfully');
        this.updateEmployeeForm.get(['passwords', 'password']).reset();
        this.updateEmployeeForm.get(['passwords', 'confirmPassword']).reset();
      }, err => {
        console.log('Error occured in update Employee:', err);
        this.loading = false;
      });
    }
  }

  public findInvalidControls() {
    const invalid = [];
    const controls = this.updateEmployeeForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        invalid.push(name);
      }
    }
    return invalid;
  }

  getEmployeeColumns() {
    this.cols = [
      { field: 'id', header: 'ID' },
      { field: 'userName', header: 'Employee Name' },
      { field: 'unit', header: 'Unit' },
      { field: 'team', header: 'Team' },
      { field: 'section', header: 'Section' },
      { field: 'department', header: 'Department' },
      { field: 'subCommittee', header: 'Sub-Committee' },
      { field: 'mobileNo', header: 'Mobile Number' },
      { field: 'action', header: 'Actions' },
      { field: 'status', header: 'Status' }
    ];
  }
  getEmployees(paginationDetails) {
    this.getEmployeeLoading = true;
    this.setupService.getEmployees(paginationDetails).subscribe((res: any[]) => {
      this.employees = res;
      this.getEmployeeLoading = false;
      this.loadOninit();
    }, err => {
      this.getEmployeeLoading = false;
      this.loadOninit();
      console.log('Error occured in get employees:', err);
    });
  }

  getReviewers(unitCode) {
    this.revLoading = true;
    this.setupService.getReviewers(unitCode).subscribe((res: any[]) => {
      const newData = [];
      this.reviewersListDropdown = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({ itemName: element.userName, id: element.id });
        }
      }
      this.reviewersListDropdown = [];
      this.reviewersListDropdown = this.reviewersListDropdown.concat(newData);
      this.revLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in get reviewers:', err);
      this.revLoading = false;
      this.loadOninit();
    });
  }

  getAppraisers(unitCode) {
    // this.appLoading = true;
    this.setupService.getAppraisers(unitCode).subscribe((res: any[]) => {
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({ itemName: element.userName, id: element.id });
        }
      }

      this.appraisersListDropdown = this.appraisersListDropdown.concat(newData);
      this.appLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in get appraisers:', err);
      this.appLoading = false;
      this.loadOninit();
    });
  }


  getProficiencyLevels() {
    this.proficiencyLoading = true;
    this.setupService.getProficiencyLevels().subscribe((res: any[]) => {
      // this.proficiencyLevels = res.slice(0, 10);
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.proficiencyLevelName) {
          newData.push({ itemName: element.proficiencyLevelName, id: element.proficiencyLevelId });
        }
      }

      this.proficiencyLevelsListDropdown = this.proficiencyLevelsListDropdown.concat(newData);
      this.proficiencyLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in getProficiencyLevels:', err);
      this.proficiencyLoading = false;
      this.loadOninit();
    });
  }

  /* --------------------------------Get Employee Total Count---------------- */
  getEmployeeTotalCount() {
    this.setupService.getEmployeeTotalCount().subscribe((data) => {
      this.totalEmployees = data;
      console.log('-----------Total EMployeee-----------', this.totalEmployees);
    });
  }

  /* ----------------------------------------Get EMployee <unit> field--------------- */
  getEmployeeUnitField() {
    this.unitLoading = true;
    this.setupService.getEmployeeUnitField().subscribe((res: any[]) => {
      // this.employeeUnits = res;

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index].unitName, id: res[index].id });
      }
      console.log(newData);

      this.employeeUnits = this.employeeUnits.concat(newData);
      this.unitLoading = false;
      this.loadOninit();
      console.log('--------------Get Unit Field for Employee', this.employeeUnits);
    }, err => {
      this.unitLoading = false;
      this.loadOninit();
    });
  }



  onChangeUnit(event) {
    if (event) {

      const index = event.target.selectedIndex - 1;
      this.employeeDropdownsData.unit = this.employeeUnits[index].unitName;
      this.employeeDropdownsData.unitId = this.employeeUnits[index].id;
      this.getDepartmentByUnit(this.employeeUnits[index].id);
      this.getEmployeeTeamByUnit(this.employeeUnits[index].id);
      this.getAppraisers(this.employeeUnits[index].id);
      this.getReviewers(this.employeeUnits[index].id);
    }
  }

  onChangeDepartment(event) {
    if (event) {
      const index = event.target.selectedIndex - 1;
      this.employeeDropdownsData.department = this.employeeDepartments[index].departmentName;
      this.employeeDropdownsData.departmentId = this.employeeDepartments[index].id;
    }
  }

  onChangeTeam(event) {
    if (event) {
      const index = event.target.selectedIndex - 1;
      this.employeeDropdownsData.team = this.employeeTeams[index].teamName;
      this.employeeDropdownsData.teamId = this.employeeTeams[index].id;
    }
  }
  onChangeSubCommittee(event) {
    if (event) {
      const index = event.target.selectedIndex - 1;
      this.employeeDropdownsData.subCommitteeNameTitle = this.employeeSubCommittees[index].subcommitteeNameTitle;
      this.employeeDropdownsData.subcommitteeId = this.employeeSubCommittees[index].id;
    }
  }
  onChangePosition(event) {
    if (event) {
      const index = event.target.selectedIndex - 1;
      this.employeeDropdownsData.position = this.employeePositions[index].positionName;
      this.employeeDropdownsData.positionId = this.employeePositions[index].positionId;
    }
  }
  onChangeRole(event) {
    if (event) {
      const index = event.target.selectedIndex - 1;
      this.employeeDropdownsData.role = this.employeeRoles[index].roleName;
      this.employeeDropdownsData.roleId = this.employeeRoles[index].roleId;
    }
  }

  /* ------------------------------------Get Department By Unit---------------------------- */

  getDepartmentByUnit(unitCode) {

    this.setupService.getDepartmentByUnit(unitCode).subscribe((res: any[]) => {
      console.log('*********Department By Unit received in unit', res);

      // this.employeeDepartments = res;
      this.employeeDepartments = [];

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index].departmentName, id: res[index].id });
      }
      console.log(newData);

      this.employeeDepartments = this.employeeDepartments.concat(newData);
      console.log('this.employeeDepartments', this.employeeDepartments);

    });
  }

  /* ---------------------------------------get team By unit---------------------------------- */

  getEmployeeTeamByUnit(unitCode) {
    this.setupService.getEmployeeTeamByUnit(unitCode).subscribe((res: any[]) => {
      console.log('----Team By Ubit Received in unit', res);
      if (res) {
        // this.employeeTeams = res;
        this.employeeTeams = [];

        const newData = [];
        for (let index = 0; index < res.length; index++) {
          newData.push({ itemName: res[index].teamName, id: res[index].id });
        }
        console.log(newData);

        this.employeeTeams = this.employeeTeams.concat(newData);
      }
    });
  }

  getList(status) {
    this.listStatus = status;
    console.log(status);
    this.searchEmp = false;
    this.searchForm.reset();
    if (status) {
      this.getEmployeeTotalCount();
      this.getEmployees(this.paginationDetails);
    } else {
      this.setupService.getWorkManEmployeeTotalCount().subscribe((data) => {
        this.totalEmployees = data;
        console.log('-----------Total EMployeee-----------', this.totalEmployees);
      });
      this.setupService.getWorkManEmployees(this.paginationDetails)
        .subscribe(res => {
          this.employees = res;
        });
    }
  }

  /* ---------------------------------------get Sub Committee By unit---------------------------------- */


  getSubCommittee(unitCode) {
    this.setupService.getSubCommitteeByUnit(unitCode).subscribe((res: any[]) => {
      // this.setupService.getSubCommitteeByUnit(unitCode).subscribe((res: any[]) => {
      console.log('--------SubCommittee By Unit Received in Unit', res);
      if (res) {
        // this.employeeSubCommittees = res;
        this.employeeSubCommittees = [];

        const newData = [];
        for (let index = 0; index < res.length; index++) {
          newData.push({ itemName: res[index].subcommitteeNameTitle, id: res[index].id });
        }
        console.log(newData);

        this.employeeSubCommittees = this.employeeSubCommittees.concat(newData);
      }
    });
  }


  /* -------------------------------------get Position By Ubit--------------------- */
  getPositionOfEmployee() {
    this.posLoading = true;
    this.setupService.getPositionOfEmployee().subscribe((res: any[]) => {
      // this.employeePositions = res;

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index].positionName, id: res[index].positionId });
      }
      console.log(newData);

      this.employeePositions = this.employeePositions.concat(newData);
      this.posLoading = false;
      this.loadOninit();
      console.log('---------------position field of employeee---------', this.employeePositions);
    }, err => {
      this.posLoading = false;
      this.loadOninit();
    });
  }

  /* ------------------------------------get ROle By Employeeee--------------------------------------- */
  getRoleOfEmployee() {
    this.roleLoading = true;
    this.setupService.getRoleOfEmployee().subscribe((res: any[]) => {
      // this.employeeRoles = res;

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index].roleName, id: res[index].roleId });
      }
      this.employeeRoles = [];
      console.log(newData);
      if (sessionStorage.getItem('userRole') == 'Power User') {
        newData.splice(2, 2);
        this.employeeRoles = this.employeeRoles.concat(newData);
      } else {
        this.employeeRoles = this.employeeRoles.concat(newData);
      }
      this.roleLoading = false;
      this.loadOninit();
      console.log('--------------------Role Field of Employeee', this.employeeRoles);
    }, err => {
      this.roleLoading = false;
      this.loadOninit();
    });
  }


  /* ------------------------------------Get Employee category by Employeee----------------------------- */
  getEmployeeCategoryOfEmployee() {
    this.categoryLoading = true;
    this.setupService.getEmployeeCategoryOfEmployee().subscribe((res: any[]) => {
      this.employeeCategories = res;
      this.categoryLoading = false;
      this.loadOninit();
      console.log('-------------------------Employee Category of employee', this.employeeCategories);
    }, err => {
      this.categoryLoading = false;
      this.loadOninit();
    });
  }


  getEmployeeNames() {
    this.nameLoading = true;
    this.setupService.getEmployeeNames().subscribe((res: any[]) => {
      // this.employeeList = res.slice(0, 10);
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          this.userNameListDropdown.push({ itemName: element.userName, id: element.id });
        }
      }
      this.nameLoading = false;
      this.loadOninit();
      console.log('-----------------Employee List--------', this.employeeList);
    }, err => {
      this.nameLoading = false;
      this.loadOninit();
    });
  }

  onChangeEmployee(event) {
    console.log('-----event----', event);
  }

  onEmployeeSelect(e) {
    console.log(e);
    this.getEmployeeDataById(e.id);
  }

  search() {
    this.searchEmp = true;
    if (this.listStatus) {
      console.log(this.searchForm.value);
      this.setupService.getEmployeeSearch(this.paginationDetails, this.searchForm.value)
        .subscribe(res => {
          console.log(res);
          this.totalEmployees = res.item1;
          this.employees = res.item2;
        });
    } else {
      this.setupService.getWorkManEmployeeSearch(this.paginationDetails, this.searchForm.value)
        .subscribe(res => {
          console.log(res);
          this.totalEmployees = res.item1;
          this.employees = res.item2;
        });
    }
  }

  getEmployeeDataById(id) {
    console.log('this.listStatus', this.listStatus);
    if (this.listStatus) {
      this.setupService.getEmployeeDataById(id).subscribe((res: any) => {
        this.updateEmployeeData = res;
        this.workId = res.id;
        this.isSelected = res.isSelected;
        this.updateEmployeeForm.patchValue({
          employeeCategory: res.employeeCategory,
          emailId: res.emailId,
          mobileNo: res.mobileNo,
          status: res.status,
          loginId: res.userName[0]
        });

        // const indexSub = _.findIndex(this.employeeSubCommittees, (d) => d['id'] == this.updateEmployeeData.subCommitteeId);
        // console.log('this.updateEmployeeData.unitId', this.updateEmployeeData.subCommitteeId);
        // console.log('unit Dept', indexSub);
        // // tslint:disable-next-line: triple-equals
        // if (indexSub != -1) {
        //   this.updateEmployeeForm.patchValue({
        //     subCommitteeId: [this.employeeSubCommittees[indexSub]]
        //   });
        // } else {
        //   this.updateEmployeeForm.patchValue({
        //     subCommitteeId: null
        //   });
        // }

        // tslint:disable-next-line:triple-equals
        const indexUnit = _.findIndex(this.employeeUnits, (d) => d['id'] == this.updateEmployeeData.unitId);

        // tslint:disable-next-line:triple-equals
        if (indexUnit != -1) {
          this.updateEmployeeForm.patchValue({
            unitId: [this.employeeUnits[indexUnit]],
          });
        } else {
          this.updateEmployeeForm.patchValue({
            unitId: null,
          });
        }
        console.log('this.updateEmployeeData', this.updateEmployeeData);
        this.unitCode = res.unitId;
        this.patchValues(this.unitCode);

        console.log('Inside employee');

        // this.addEmployeeForm.patchValue()

        const proficiencyLevel = res.proficiencyLevels;
        const appraiser = res.appraisers;
        const reviewer = res.reviewers;
        const reviewerId = [];
        // const appraiserId = [];
        const selectedId = [];
        const dpDowns = [...this.proficiencyLevelsListDropdown];

        // tslint:disable-next-line:triple-equals
        const indexPosition = _.findIndex(this.employeePositions, (d) => d['itemName'] == this.updateEmployeeData.position);
        console.log('indexPosition', indexPosition);
        // tslint:disable-next-line:triple-equals
        if (indexPosition != -1) {
          this.updateEmployeeForm.patchValue({
            position: [this.employeePositions[indexPosition]]
          });
        } else {
          this.updateEmployeeForm.patchValue({
            position: null
          });
        }
        // tslint:disable-next-line:triple-equals
        const indexRole = _.findIndex(this.employeeRoles, (d) => d['itemName'] == res.role);
        // tslint:disable-next-line:triple-equals
        if (indexRole != -1) {
          this.updateEmployeeForm.patchValue({
            role: [this.employeeRoles[indexRole]]
          });
        } else {
          this.updateEmployeeForm.patchValue({
            role: null
          });
        }
        this.accountName = res.accountName;
        this.selectedProficiencyLevel = res.proficiencyLevels;
        if (proficiencyLevel != null) {
          for (let i = 0; i < proficiencyLevel.length; i++) {
            const index = _.findIndex(this.proficiencyLevelsListDropdown, (d) => d['itemName'] === proficiencyLevel[i]);
            console.log(index);
            if (index != -1) {
              selectedId.push(this.proficiencyLevelsListDropdown[index]);
            }
          }
          if (selectedId.length > 0) {
            this.updateEmployeeForm.patchValue({
              proficiencyLevels: selectedId
            });
          } else {
            this.updateEmployeeForm.patchValue({
              proficiencyLevels: null
            });
          }
        }
        // tslint:disable-next-line:triple-equals
        const idIndex = _.findIndex(this.userNameListDropdown, (d) => d.id == res.id[0]);
        console.log('idIndex', idIndex);
        // if (appraiser != null) {
        //   for (let i = 0; i < appraiser.length; i++) {
        //     const index = _.findIndex(this.appraisersListDropdown, (d) => d['itemName'] === appraiser[i]);
        //     console.log('appraiser', index);
        //     appraiserId.push(this.appraisersListDropdown[index]);
        //   }
        //   this.updateEmployeeForm.patchValue({
        //     appraisers: appraiserId
        //   });
        // }


        // if (reviewer != null) {
        //   for (let i = 0; i < reviewer.length; i++) {
        //     const index = _.findIndex(this.reviewersListDropdown, (d) => d['itemName'] === reviewer[i]);
        //     console.log('reviewer', index);
        //     reviewerId.push(this.reviewersListDropdown[index]);
        //   }
        //   this.updateEmployeeForm.patchValue({
        //     reviewers: reviewerId
        //   });
        // }

        this.updateEmployeeForm.patchValue({
          id: [this.userNameListDropdown[idIndex]]
        });
        // console.log('------------get updateEmployeeData', this.uniqList);
      });
    } else {
      this.setupService.getWorkManEmployeeDataById(id).subscribe((res: any) => {
        this.updateEmployeeData = res;
        this.workId = res.id;
        console.log('this.updateEmployeeData', this.updateEmployeeData);
        this.updateEmployeeForm.patchValue({
          employeeCategory: 'Wageboard',
          id: res.userName,
          mobileNo: res.mobileNo,
          emailId: res.emailId,
          status: res.status,
          loginId: res.userName
        });

        const indexSub = _.findIndex(this.employeeSubCommittees, (d) => d['id'] == this.updateEmployeeData.subCommitteeId);
        console.log('this.updateEmployeeData.unitId', this.updateEmployeeData.subCommitteeId);
        console.log('unit Dept', indexSub);
        // tslint:disable-next-line: triple-equals
        // if (indexSub != -1) {
        //   this.updateEmployeeForm.patchValue({
        //     subCommitteeId: [this.employeeSubCommittees[indexSub]]
        //   });
        // } else {
        //   this.updateEmployeeForm.patchValue({
        //     subCommitteeId: null
        //   });
        // }

        const indexSection = _.findIndex(this.employeeSections, (d) => d['id'] == this.updateEmployeeData.sectionId);
        console.log('indexSection', indexSection);

        if (indexSection != -1) {
          this.updateEmployeeForm.patchValue({
            sectionId: [this.employeeSections[indexSection]],
          });
        } else {
          this.updateEmployeeForm.patchValue({
            sectionId: null
          });
        }
        this.unitCode = res.unitId;
        this.patchValues(this.unitCode);
        // this.getDepartmentByUnit(this.unitCode);
        // this.getEmployeeTeamByUnit(this.unitCode);
        // this.getSubCommittee(this.unitCode);
        // this.addEmployeeForm.patchValue()

        console.log('this.employeePositions', this.employeePositions);
        // tslint:disable-next-line: triple-equals
        const indexPosition = _.findIndex(this.employeePositions, (d) => d['itemName'] == this.updateEmployeeData.position);
        // tslint:disable-next-line: triple-equals
        if (indexPosition != -1) {
          this.updateEmployeeForm.patchValue({
            position: [this.employeePositions[indexPosition]]
          });
        } else {
          this.updateEmployeeForm.patchValue({
            position: null
          });
        }
        console.log('this.employeeRoles', this.employeeRoles);
        const indexRole = _.findIndex(this.employeeRoles, (d) => d['itemName'] == res.role);
        console.log('indexRole', indexRole);
        if (indexRole != -1) {
          this.updateEmployeeForm.patchValue({
            role: [this.employeeRoles[indexRole]]
          });
        } else {
          this.updateEmployeeForm.patchValue({
            role: null
          });
        }

        const proficiencyLevel = res.proficiencyLevels;
        const appraiser = res.appraisers;
        const reviewer = res.reviewers;
        const reviewerId = [];
        const appraiserId = [];
        const selectedId = [];
        const dpDowns = [...this.proficiencyLevelsListDropdown];

        // const indexPosition = _.findIndex(this.employeePositions, (d) => d['itemName'] === res.position);
        // console.log('indexPosition', indexPosition);
        // if (indexPosition != -1) {
        //   this.updateEmployeeForm.patchValue({
        //     position: [this.employeePositions[indexPosition]]
        //   });
        // }
        console.log('this.employeeRoles', this.employeeRoles);
        // const indexRole = _.findIndex(this.employeeRoles, (d) => d['itemName'] === res.role);
        this.accountName = res.accountName;
        console.log('appraiser', appraiser);
        console.log('reviewer', reviewer);
        this.selectedProficiencyLevel = res.proficiencyLevels;
        console.log('this.proficiencyLevelsListDropdown', this.proficiencyLevelsListDropdown);
        if (proficiencyLevel != null) {
          for (let i = 0; i < proficiencyLevel.length; i++) {
            const index = _.findIndex(this.proficiencyLevelsListDropdown, (d) => d['itemName'] === proficiencyLevel[i]);
            console.log(index);
            if (index != -1) {
              selectedId.push(this.proficiencyLevelsListDropdown[index]);
            }
          }
          if (selectedId.length > 0) {
            this.updateEmployeeForm.patchValue({
              proficiencyLevels: selectedId,
            });
          } else {
            this.updateEmployeeForm.patchValue({
              proficiencyLevels: null,
            });
          }
        }
        // tslint:disable-next-line: triple-equals
        const idIndex = _.findIndex(this.userNameListDropdown, (d) => d.id == res.id[0]);
        console.log(idIndex);


        console.log('this.appraisersListDropdown', this.appraisersListDropdown);

        // if (reviewer != null) {
        //   for (let i = 0; i < reviewer.length; i++) {
        //     const index = _.findIndex(this.reviewersListDropdown, (d) => d['itemName'] === reviewer[i]);
        //     console.log('reviewer', index);
        //     reviewerId.push(this.reviewersListDropdown[index]);
        //   }
        // }
        // tslint:disable-next-line: triple-equals
        const indexUnit = _.findIndex(this.employeeUnits, (d) => d['id'] == this.updateEmployeeData.unitId);
        console.log('this.updateEmployeeData.unitId', this.updateEmployeeData.unitId);
        console.log('unit Index', indexUnit);

        console.log('indexRole', indexRole);

        console.log('this.userNameListDropdown[idIndex]', this.userNameListDropdown[idIndex]);

        this.updateEmployeeForm.patchValue({
          unitId: [this.employeeUnits[indexUnit]],
          // appraisers: appraiserId,
          // reviewers: reviewerId,
          // departmentId: res.departmentId
        });
        console.log(this.addEmployeeForm.value);

        console.log('this.proficiencyLevelsListDropdown', this.proficiencyLevelsListDropdown);
        // console.log('------------get updateEmployeeData', this.uniqList);
      });
    }

  }

  checkLoginId() {
    this.setupService.GetWorkmanEmployeeLoginIds()
      .subscribe(res => {
        console.log(res);
        const usedLogin = res.filter(login => login != null).map(login => login.toLowerCase());
        console.log('usedLogin', usedLogin)
        //  usedLogin =  _.mapValues(usedLogin, _.method('toLowerCase'));
        // for (let i = 0; i < usedLogin.length; i++) {
        //   if (usedLogin[i] != null) {
        //     usedLogin[i] = usedLogin[i].toLowerCase();
        //   }
        // }
        console.log(usedLogin);
        const loginId = this.addEmployeeForm.controls.loginId.value.toLowerCase();
        console.log('loginId', loginId);
        usedLogin.includes(loginId) ? this.usedId = true : this.usedId = false
        if (this.usedId) {
          this.addEmployeeForm.patchValue({
            loginId: null
          })
        }
        // // tslint:disable-next-line: triple-equals
        // const index = _.findIndex(usedLogin, (d) => d == loginId);
        // console.log(index);
        // // tslint:disable-next-line: triple-equals
        // if (index == -1) {
        //   this.usedId = false;
        // } else {
        //   this.usedId = true;
        // }

        
      });
  }

  cancelAddEmployeeDialog() {
    this.displayAddEmployeeDialog = false;
    this.addEmployeeForm.reset();
    this.update = false;
  }

  showAddEmployeeDialog() {
    this.displayAddEmployeeDialog = true;
    this.update = false;
    this.getEmployeeCategoryOfEmployee();
    // document.getElementById('form').scrollTop = 0;
    const currentUnit = { itemName: sessionStorage.getItem('unit'), id: sessionStorage.getItem('unitId') };
    this.addEmployeeForm.reset();
    this.addEmployeeForm.patchValue({
      employeeCategory: 'Wageboard',
      unitId: [currentUnit]
    });
    this.getDepartmentByUnit(currentUnit.id);
    this.getEmployeeTeamByUnit(currentUnit.id);
    this.getSubCommittee(currentUnit.id);
    this.getSectionByUnit(currentUnit.id);
    this.getAppraisers(currentUnit.id);
    this.getReviewers(currentUnit.id);
  }

  cancelUpdateEmployeeDialog() {
    this.displayAddEmployeeDialog = false;
    this.hasChangePassword = false;
    this.updateEmployeeForm.reset();
  }

  showUpdateEmployeeDialog(updateEmployeeData) {
    this.hasChangePassword = false;
    console.log('this.listStatus', this.listStatus);
    console.log('this.update', this.update);
    this.update = true;
    if (this.listStatus && this.update) {
      const staffIndex = _.findIndex(this.employeeCategories, (d) => d['employeeCategory'] == 'Wageboard');
      console.log('staffIndex', staffIndex);
      if (staffIndex != -1) {
        this.employeeCategories.splice(staffIndex, 1);
      }
    }
    this.getEmployeeDataById(updateEmployeeData.id);
    this.displayAddEmployeeDialog = true;
  }

  showImport() {
    this.importDailog = true;
  }
  hideImport() {
    this.importDailog = false;
  }
  addEmployeeViaImport() {
    console.log(this.addEmployeeImport.value);
    const formdata = new FormData()
    formdata.append('FilePath', this.importFile)

    this.setupService.fileUploadPost('Employee/UploadEmployeeProfiles', formdata)
      .subscribe(res => {
        console.log(res);
        this.importDailog = false

        if (this.listStatus) {

          this.setupService.getEmployees({ pageNumber: 0, pageSize: 5 })
            .subscribe(res => {
              this.exportEmployees = res;
            })
        } else {
          this.setupService.getWorkManEmployees({ pageNumber: 0, pageSize: 5 })
            .subscribe(res => {
              this.exportEmployees = res;
            });
        }
      })
  }

  fileUpload(event) {
    console.log('event', event.target.files[0]);
    this.importFile = event.target.files[0]
  }

  patchValues(unitCode) {
    this.setupService.getDepartmentByUnit(unitCode).subscribe((res: any[]) => {
      console.log('*********Department By Unit received in unit', res);
      this.employeeDepartments = [];
      // this.employeeDepartments = res;
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index].departmentName, id: res[index].id });
      }
      console.log(newData);
      this.employeeDepartments = this.employeeDepartments.concat(newData);
      // tslint:disable-next-line: triple-equals
      const indexDept = _.findIndex(this.employeeDepartments, (d) => d['id'] == this.updateEmployeeData.departmentId);
      console.log('this.updateEmployeeData.departmentId', this.updateEmployeeData.departmentId);
      console.log('unit Dept', indexDept);
      // tslint:disable-next-line: triple-equals
      if (indexDept != -1) {
        this.updateEmployeeForm.patchValue({
          departmentId: [this.employeeDepartments[indexDept]]
        });
      } else {
        this.updateEmployeeForm.patchValue({
          departmentId: null
        });
      }

      console.log('this.employeeDepartments', this.employeeDepartments);
    });
    this.setupService.getEmployeeTeamByUnit(unitCode).subscribe((res: any[]) => {
      console.log('----Team By Ubit Received in unit', res);
      if (res) {
        // this.employeeTeams = res;
        this.employeeTeams = [];
        const newData = [];
        for (let index = 0; index < res.length; index++) {
          newData.push({ itemName: res[index].teamName, id: res[index].id });
        }
        console.log(newData);
        this.employeeTeams = this.employeeTeams.concat(newData);
        // tslint:disable-next-line: triple-equals
        const indexTeam = _.findIndex(this.employeeTeams, (d) => d['id'] == this.updateEmployeeData.teamId);
        console.log('this.updateEmployeeData.unitId', this.updateEmployeeData.teamId);
        console.log('unit Dept', indexTeam);
        // tslint:disable-next-line: triple-equals
        if (indexTeam != -1) {
          this.updateEmployeeForm.patchValue({
            teamId: [this.employeeTeams[indexTeam]]
          });
        } else {
          this.updateEmployeeForm.patchValue({
            teamId: null
          });
        }
      }
    });
    this.setupService.getSubCommitteeByUnit(unitCode).subscribe((res: any[]) => {
      // console.log('--------SubCommittee By Unit Received in Unit', res);
      if (res) {
        // this.employeeSubCommittees = res;
        this.employeeSubCommittees = [];
        const newData = [];
        for (let index = 0; index < res.length; index++) {
          newData.push({ itemName: res[index].subcommitteeNameTitle, id: res[index].id });
        }
        console.log(newData);
        this.employeeSubCommittees = this.employeeSubCommittees.concat(newData);
        // tslint:disable-next-line: triple-equals
        const indexSub = _.findIndex(this.employeeSubCommittees, (d) => d['id'] == this.updateEmployeeData.subCommitteeId);
        console.log('this.updateEmployeeData.unitId', this.updateEmployeeData.subCommitteeId);
        console.log('unit Dept', indexSub);
        // tslint:disable-next-line: triple-equals
        if (indexSub != -1) {
          this.updateEmployeeForm.patchValue({
            subCommitteeId: [this.employeeSubCommittees[indexSub]]
          });
        } else {
          this.updateEmployeeForm.patchValue({
            subCommitteeId: null
          });
        }
      }
    });

    this.setupService.getSectionsByUnit(unitCode)
      .subscribe(res => {
        console.log(res);
        this.employeeSections = [];
        const newData = [];
        for (let index = 0; index < res.length; index++) {
          newData.push({ itemName: res[index].sectionNameTitle, id: res[index].id });
        }
        console.log(newData);
        this.employeeSections = this.employeeSections.concat(newData);
        const indexSec = _.findIndex(this.employeeSections, (d) => d['id'] == this.updateEmployeeData.sectionId);
        console.log('this.updateEmployeeData.unitId', this.updateEmployeeData.sectionId);
        console.log('unit Section', indexSec);
        // tslint:disable-next-line: triple-equals
        if (indexSec != -1) {
          console.log('this.employeeSections[indexSec]', this.employeeSections[indexSec]);
          this.updateEmployeeForm.patchValue({
            sectionId: [this.employeeSections[indexSec]]
          });
        } else {
          this.updateEmployeeForm.patchValue({
            sectionId: null
          });
        }
      });
    this.setupService.getAppraisers(unitCode).subscribe((res: any[]) => {
      const newData = [];
      this.appraisersListDropdown = [];
      console.log(this.updateEmployeeData);
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({ itemName: element.userName, id: element.id });
        }
      }
      this.appraisersListDropdown = this.appraisersListDropdown.concat(newData);
      const appraiserId = [];
      if (this.updateEmployeeData.appraisers != null) {
        for (let i = 0; i < this.updateEmployeeData.appraisers.length; i++) {
          const index = _.findIndex(this.appraisersListDropdown, (d) => d['itemName'] === this.updateEmployeeData.appraisers[i]);
          console.log('appraiser', index);
          if (index != -1) {
            appraiserId.push(this.appraisersListDropdown[index]);
          }
        }
        console.log(appraiserId);
        if (appraiserId.length > 0) {
          this.updateEmployeeForm.patchValue({
            appraisers: appraiserId
          });
        } else {
          this.updateEmployeeForm.patchValue({
            appraisers: null
          });
        }
      }



      this.appLoading = false;
      // this.loadOninit();
    }, err => {
      console.log('Error occured in get appraisers:', err);
      this.appLoading = false;
      // this.loadOninit();
    });

    this.setupService.getReviewers(unitCode).subscribe((res: any[]) => {
      const newData = [];
      this.reviewersListDropdown = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({ itemName: element.userName, id: element.id });
        }
      }
      this.reviewersListDropdown = this.reviewersListDropdown.concat(newData);
      this.revLoading = false;
      const reviewerId = [];
      if (this.updateEmployeeData.reviewers != null) {
        for (let i = 0; i < this.updateEmployeeData.reviewers.length; i++) {
          const index = _.findIndex(this.reviewersListDropdown, (d) => d['itemName'] === this.updateEmployeeData.reviewers[i]);
          console.log('reviewer', index);
          if (index != -1) {
            reviewerId.push(this.reviewersListDropdown[index]);
          }
        }
        if (reviewerId.length > 0) {
          this.updateEmployeeForm.patchValue({
            reviewers: reviewerId
          });
        } else {
          this.updateEmployeeForm.patchValue({
            reviewers: null
          });
        }
      }
    });
  }
  selectUnit(e) {
    console.log(e);
    this.patchValues(e.id);
  }

  unitSelect(e) {

    this.getDepartmentByUnit(e.id);
    this.getEmployeeTeamByUnit(e.id);
    this.getSubCommittee(e.id);
    this.getSectionByUnit(e.id);
    this.getAppraisers(e.id);
    this.getReviewers(e.id);
  }

  loadOninit() {
    console.log('this.appLoading', this.appLoading);
    console.log('this.revLoading', this.revLoading);
    console.log('this.getEmployeeLoading', this.getEmployeeLoading);
    console.log('this.unitLoading', this.unitLoading);
    console.log('this.posLoading', this.posLoading);
    console.log('this.roleLoading', this.roleLoading);
    console.log('this.categoryLoading', this.categoryLoading);
    console.log('this.nameLoading', this.nameLoading);
    console.log('this.proficiencyLoading', this.proficiencyLoading);
    console.log('!(this.getEmployeeLoading && this.unitLoading && this.posLoading && this.roleLoading && this.categoryLoading && this.nameLoading && this.proficiencyLoading)', !this.appLoading && !this.revLoading && !this.getEmployeeLoading && !this.unitLoading && !this.posLoading && !this.roleLoading && !this.categoryLoading && !this.nameLoading && !this.proficiencyLoading);
    if (!this.getEmployeeLoading && !this.unitLoading && !this.posLoading && !this.roleLoading && !this.categoryLoading && !this.nameLoading && !this.proficiencyLoading) {

      this.loading = false;
    }
  }

  getSectionByUnit(id) {
    this.setupService.getSectionsByUnit(id)
      .subscribe(res => {
        console.log(res);
        this.employeeSections = [];
        const newData = [];
        for (let index = 0; index < res.length; index++) {
          newData.push({ itemName: res[index].sectionNameTitle, id: res[index].id });
        }
        console.log(newData);
        this.employeeSections = this.employeeSections.concat(newData);
      });
  }
  changePwd() {
    this.hasChangePassword = !this.hasChangePassword;
  }


  exportAsXLSX() {
    console.log('this.listStatus', this.listStatus)
    if (this.listStatus) {

      this.setupService.getEmployees({ pageNumber: -1, pageSize: -1 })
        .subscribe(res => {
          res.forEach(data => { 
            data.accountName = String(data.accountName);
            data.id = String(data.id);
            data.userName = String(data.userName);
            delete data.isGroup;
            delete data.roleId;
            delete data.proficiencyLevels;
          });
          this.exportEmployees = res;
          this.exportEmployee()
        })
    } else {
      this.setupService.getWorkManEmployees({ pageNumber: -1, pageSize: -1 })
        .subscribe(res => {
          res.forEach(data => {
            data.appraisers = String(data.appraisers);
            data.reviewers = String(data.reviewers);
            delete data.proficiencyLevels;
            delete data.password;
            delete data.modified;
            delete data.modifiedBy;
            delete data.created;
            delete data.createdBy;
            delete data.titleTitle;
          });
          this.exportEmployees = res;
          this.exportEmployee()
        });
    }

  }

  exportEmployee() {
    if (this.exportEmployees.length > 0) {
      this.excelService.exportAsExcelFile(this.exportEmployees, 'sample');
    }
  }
}
