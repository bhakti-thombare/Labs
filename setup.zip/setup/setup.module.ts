import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SetupRoutingModule } from './setup-routing.module';
// components
import { SetuphomeComponent } from './setuphome/setuphome.component';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { AreaComponent } from './area/area.component';
import { UnitComponent } from './unit/unit.component';
import { TeamComponent } from './team/team.component';
import { SubcommitteeComponent } from './subcommittee/subcommittee.component';
import { SubcommitteenamesComponent } from './subcommitteenames/subcommitteenames.component';
import { SectionsComponent } from './sections/sections.component';
import { SectionnamesComponent } from './sectionnames/sectionnames.component';
import { RolesComponent } from './roles/roles.component';
import { RoleprivelegesComponent } from './rolepriveleges/rolepriveleges.component';
import { ProficiencylevelComponent } from './proficiencylevel/proficiencylevel.component';
import { PositionComponent } from './position/position.component';
import { MonthsComponent } from './months/months.component';
import { KeyfocusareasComponent } from './keyfocusareas/keyfocusareas.component';
import { ImprovementareaComponent } from './improvementarea/improvementarea.component';
import { FunctionComponent } from './function/function.component';
import { FunctionnamesComponent } from './functionnames/functionnames.component';
import { FinancialyearsComponent } from './financialyears/financialyears.component';
import { EvaluatorComponent } from './evaluator/evaluator.component';
import { EvaluationscoringparametersComponent } from './evaluationscoringparameters/evaluationscoringparameters.component';
import { EquipmentComponent } from './equipment/equipment.component';
import { EmployeecategoryComponent } from './employeecategory/employeecategory.component';
import { EmployeeComponent } from './employee/employee.component';
import { DepartmentnamesComponent } from './departmentnames/departmentnames.component';
import { DepartmentComponent } from './department/department.component';
import { QcdipComponent } from './qcdip/qcdip.component';
// prime ng
import { TableModule } from 'primeng/table';
import { CalendarModule } from 'primeng/calendar';
import { PaginatorModule } from 'primeng/paginator';
import { MegaMenuModule } from 'primeng/megamenu';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { DialogModule } from 'primeng/dialog';
import { MultiSelectModule } from 'primeng/multiselect';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { TreeModule } from 'primeng/tree';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import {ToastModule} from 'primeng/toast';
// import { LoaderComponent } from '../shared/components/loader/loader.component';
import { SharedModule } from '../shared/shared.module';

// Reactive
import { ReactiveFormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { AssignUnitsComponent } from './assign-units/assign-units.component';
import { SlaMasterComponent } from './sla-master/sla-master.component';
import { BehaviouralServiceComponent } from './behavioural-service/behavioural-service.component';
import { ConfigurationListComponent } from './configuration-list/configuration-list.component';
@NgModule({
  declarations: [
    SetuphomeComponent,
    AreaComponent,
   // AngularMultiSelectModule,
    TeamComponent,
    UnitComponent,
    FunctionnamesComponent,
    FunctionComponent,
    SubcommitteeComponent,
    FinancialyearsComponent,
    EvaluatorComponent,
    EvaluationscoringparametersComponent,
    EquipmentComponent,
    EmployeecategoryComponent,
    EmployeeComponent,
    DepartmentnamesComponent,
    DepartmentComponent,
    SubcommitteenamesComponent,
    SectionsComponent,
    SectionnamesComponent,
    RolesComponent,
    RoleprivelegesComponent,
    ProficiencylevelComponent,
    PositionComponent,
    MonthsComponent,
    KeyfocusareasComponent,
    ImprovementareaComponent,
    QcdipComponent,
    AssignUnitsComponent,
    SlaMasterComponent,
    BehaviouralServiceComponent,
    ConfigurationListComponent
  ],
  imports: [
    CommonModule,
    SetupRoutingModule,
    ReactiveFormsModule,
    SelectDropDownModule,
    // primeng
    TableModule,
    CalendarModule,
    PaginatorModule,
    MegaMenuModule,
    OverlayPanelModule,
    DialogModule,
    MultiSelectModule,
    AngularMultiSelectModule,
    TreeModule,
    ProgressSpinnerModule,
    ToastModule,
    SharedModule
    // LoaderComponent
  ],
  providers: [MessageService]
})
export class SetupModule { }
