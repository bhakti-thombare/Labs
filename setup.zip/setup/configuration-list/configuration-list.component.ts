import { Component, OnInit } from '@angular/core';
import { SetupService } from '../setup.service';

@Component({
  selector: 'app-configuration-list',
  templateUrl: './configuration-list.component.html',
  styleUrls: ['./configuration-list.component.css']
})
export class ConfigurationListComponent implements OnInit {
  cols = [];
  configurationList = [];
  loading = false;

  constructor(private setupService: SetupService) { }

  ngOnInit() {
    this.getListColumns()
    this.getConfigurationList()
  }

  getListColumns() {
    this.cols = [
      { field: 'unit', header: 'Unit' },
      { field: 'departmentName', header: 'Department Name' },
      { field: 'lowerLimit', header: 'Lower Limit' },
      { field: 'upperLimit', header: 'Upper Limit' },
    ];
  }

  getConfigurationList() {
    this.loading = true;
    this.setupService.get('ConfigurationList/GetConfigurationLists/-1/-1')
    .subscribe(res => {
      this.configurationList = res;
      this.loading = false;
    })
  }

}
