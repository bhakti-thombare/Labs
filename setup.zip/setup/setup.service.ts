import { Injectable } from '@angular/core';
import { forkJoin, Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, shareReplay, tap } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { getBaseUrlConfigurationAdmin, getBaseUrlConfigurationQCDIP } from '../configuration/configuration';
import { UserinfoService } from '../configuration/userinfo.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' })
};
@Injectable({
  providedIn: 'root'
})
export class SetupService {

  unitId;
  headers = new HttpHeaders();
  baseURL = environment.adminUrl;
  baseURLQCDIP = environment.qcDipUrl;
  financialYearsUrl = `${environment.adminUrl}FinancialYear/GetFinancialYears/-1/-1`

  financialYear$ = this.http.get<any[]>(this.financialYearsUrl)
    .pipe(
      shareReplay(1),
      catchError(this.handleError)
    );



  constructor(private http: HttpClient,
    private userInfo: UserinfoService,
    private msAdalService: MsAdalAngular6Service) {
    if (this.msAdalService.isAuthenticated) {
      this.unitId = sessionStorage.getItem('unitId');
    }
  }

  getDepartments(paginationDetails: any) {
    const url = `${this.baseURL}Department/getDepartments/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(departments => console.log('-----Fetched all Departments------', departments)),
        catchError(this.handleError('getDepartments', []))
      );
  }

  addDepartment(department: any): Observable<any> {
    console.log('--------Add Department data in service:------', department);
    const url = `${this.baseURL}Department/CreateDepartment`;
    return this.http.post<any>(url, JSON.stringify(department), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      catchError(this.handleError<any>('addDepartment'))
    );
  }

  updateDepartment(department: any): Observable<any> {
    const url = `${this.baseURL}Department/updateDepartment`;
    return this.http.put(url, JSON.stringify(department), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Department----------------`)),
      catchError(this.handleError<any>('updateDepartment'))
    );
  }

  /* ----------------------Get Function Lists for Department-------------------------------- */
  /* getFunctionLists():Observable<any> {
    const url = `${this.baseURL}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Function lsist count for department----')),
      catchError(this.handleError<any>('----Get all Function lsist count for department----'))
    );
  } */
  getFunctionsNamesForDepartment(): Observable<any> {
    const url = `${this.baseURL}function/getfunctions/-1/-1`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Function lsist count for department----')),
      catchError(this.handleError<any>('----Get all Function lsist count for department----'))
    );
  }





  /* Add Unit */
  addUnit(unitData: any): Observable<any> {
    console.log('----Add Unit data in service----', unitData);
    const url = `${this.baseURL}Unit/CreateUnit`;
    return this.http.post<any>(url, unitData, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((unit: any) => console.log(`--------Add Unit`)),
      catchError(this.handleError<any>('CreateUnit'))
    );
  }

  /* ------------------------------------------Get Unit Heads--------------------------------------- */
  getUnitHeads(): Observable<any> {
    const url = `${this.baseURL}unit/getunithead`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(unitHeadss => console.log('-----Fetched all unit  Headssss------', unitHeadss)),
      catchError(this.handleError('getUnits', []))
    );
  }
  /* -----------------------------------------Get Wcm Admin------------------------------------ */
  getWcmAdmin(): Observable<any> {
    const url = `${this.baseURL}unit/getwcmadmin`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(unitWcmAdmin => console.log('--------------Fetched All unit Wcm Admin------', unitWcmAdmin)),
      catchError(this.handleError('getWcmAdmin', []))

    );
  }

  // Get units count for pagination
  getTotalNumberOfUnits(): Observable<any> {
    const url = `${this.baseURL}unit/getunitcount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all unit count----')),
      catchError(this.handleError<any>('-----Get all unit count----'))
    );
  }

  getTotalNumberOfdepartments(): Observable<any> {
    const url = `${this.baseURL}department/getdepartmentcount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all unit count----')),
      catchError(this.handleError<any>('-----Get all unit count----'))
    );
  }
  /* Get Unit */
  getUnits(paginationDetails: any): Observable<any[]> {
    const url = `${this.baseURL}unit/getUnits/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;

    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(units => console.log('-----Fetched all units------', units)),
        catchError(this.handleError('getUnits', []))
      );

  }

  /* Get Unit */
  getUnitLevels(): Observable<any[]> {
    const url = `${this.baseURL}unit/GetLevels`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(units => console.log('-----Fetched all units------', units)),
        catchError(this.handleError('getUnits', []))
      );

  }

  getDepartmentNames(): Observable<any[]> {
    const url = `${this.baseURL}Department/GetDepartmentNameMasterList`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(units => console.log('-----Fetched all DepartmentNames------', units)),
        catchError(this.handleError('getUnits', []))
      );

  }

  getDepartmentHod(): Observable<any[]> {
    const url = `${this.baseURL}department/GetHOD`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(hod => console.log('-----Fetched all Department  HOD------', hod)),
        catchError(this.handleError('getUnits', []))
      );

  }

  /* Get Unit */
  getUnitLocations(): Observable<any[]> {
    const url = `${this.baseURL}unit/GetLocations`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(units => console.log('-----Fetched all units------', units)),
        catchError(this.handleError('getUnits', []))
      );

  }
  /* Get Unit */
  getUnitById(id: any): Observable<any> {
    const url = `${this.baseURL}unit/getUnitById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(units => console.log('-----Fetched all units------', units)),
        catchError(this.handleError('getUnits', []))
      );
  }

  getDepartmentById(id: any): Observable<any> {
    const url = `${this.baseURL}department/getDepartmentById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(units => console.log('-----Fetched all units------', units)),
        catchError(this.handleError('getUnits', []))
      );
  }


  /* Update Unit */
  updateUnit(units: any): Observable<any> {
    const url = `${this.baseURL}unit/updateUnit`;
    return this.http.put(url, JSON.stringify(units), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    })
      .pipe(
        catchError(this.handleError<any>('updateUnit'))
      );
  }


  // ----------------------Akshay code------------------------

  /* Get Function By Id */
  getFunctionById(id: any): Observable<any> {
    const url = `${this.baseURL}function/getFunctionById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(functions => console.log('-----Fetched all Function------', functions)),
        catchError(this.handleError('getFunctions', []))
      );
  }



  /*  Get Function */
  getFunctions(paginationDetails: any) {
    const url = `${this.baseURL}Function/GetFunctions/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(functions => console.log('-----Fetched all Departments------', functions)),
        catchError(this.handleError('getFunctions', []))
      );

  }

  /* ---------------------------------------------Get Function Heads By List---------------------- */
  getFunctionHeadList(): Observable<any[]> {
    const url = `${this.baseURL}function/getfunctionHeads`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(functionHeads => console.log('-----Fetched all Function Heads------', functionHeads)),
        catchError(this.handleError('getFunctionHeadList', []))
      );

  }

  getUserInfo(userId) {
    this.getWithParam('RpmMapping/GetRpmMappingForEmployee/username', userId)
      .subscribe((res: any) => {
        console.log('res', res);
        // this.kaizenService.storeUnitId(res.item2.unitId);
        this.userInfo.roleName = res.item1;
        this.userInfo.userData = res.item2;
        this.unitId = sessionStorage.getItem('unitId');
        // sessionStorage.setItem('unitId', '' + this.unitId);
        console.log(sessionStorage.getItem('unitId'));
        // localStorage.setItem('info', '' + this.userInfo.roleName);
        // console.log('this.userInfo.roleName', this.userInfo.roleName);
        // // this.loggedInData = res.item2;
        // this.userInfo.roleId = res.item2.id;
        // this.userInfo.userAccess = res.item3;
        // this.isSetupTrue();
        // console.log('this.userInfo.roleId', this.userInfo.userData);
        // if (this.userInfo.roleId === null) {
        //   this.authorizedUser = false;
        //   const dataObj = {
        //     UserName: this.username,
        //     EmailId: this.msAdalService.userInfo.userName,
        //     AccountName: `abgplanet\\${userId}`
        //   };
        //   this.registerUser(dataObj);
        //   this.loading = false;
        // } else {
        //   // this.sendUserData(id, this.userInfo.userData.teamId, this.userInfo.roleId, this.userInfo.userData.unitId);
        //   this.authorizedUser = true;
        //   this.loading = false;
        // }
        // // tslint:disable-next-line: triple-equals
        // if (this.userInfo.userData.status) {
        //   this.authorizedUser = true;
        //   this.loading = false;
        // } else {
        //   this.authorizedUser = false;
        // }
        // this.loading = false;
        console.log('unitId', this.unitId);
        this.headers = new HttpHeaders();
        this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`);

      }, (err) => {
        console.log('err', err);
        // this.loading = false;
      });

  }


  /* code for function <function name > dropdown */
  getFunctionsNames(): Observable<any[]> {
    const url = `${this.baseURL}Function/GetFunctionNameMasterList`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(functions => console.log('-----Fetched all units------', functions)),
        catchError(this.handleError('getFunctions', []))
      );

  }



  /* Add Function */
  addFunction(functionData: any): Observable<any> {
    console.log('----Add Function data in service----', functionData);
    const url = `${this.baseURL}Function/CreateFunction`;
    return this.http.post<any>(url, functionData, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      catchError(this.handleError<any>('addFunction'))
    );
  }



  /* Update Function */
  updateFunction(functions: any): Observable<any> {
    const url = `${this.baseURL}Function/UpdateFunction`;
    return this.http.put(url, JSON.stringify(functions), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Functions----------------`)),
      catchError(this.handleError<any>('updateFunction '))
    );
  }

  /* Get toatal no of functions */
  getTotalNumberOffunctions(): Observable<any> {
    const url = `${this.baseURL}function/getfunctioncount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all function count----')),
      catchError(this.handleError<any>('-----Get all function count----'))
    );
  }
  /* --------------------------------Function Code Ends------------------------------------------------------------ */


  /* --------------------------------Sub-Committee code Starts------------------------------ */



  /* Get SubCommittee */
  getSubCommittees(paginationDetails: any) {
    const url = `${this.baseURL}SubCommittee/GetSubCommittees/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(subcommittees => console.log('-----Fetched all SubCommittes------', subcommittees)),
        catchError(this.handleError('getsubcommittees', []))
      );

  }

  /* Get <SubCommitte> name field  */
  getSubCommitteeNames(): Observable<any[]> {
    const url = `${this.baseURL}SubCommittee/GetSubCommitteeNameMasterList`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(subcommittees => console.log('-----Fetched all SubCommittees------', subcommittees)),
        catchError(this.handleError('getSubCommitteeNames', []))
      );

  }

  /* Get SubCommittee By id */
  getSubCommitteeById(id): Observable<any[]> {
    const url = `${this.baseURL}SubCommittee/GetSubCommitteeById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(subCommittees => console.log('-----Fetched all Sub Committees------', subCommittees)),
        catchError(this.handleError('getSubCommitteeById', []))
      );
  }

  /* Get total no of subCommittees */
  getTotalNumberOfSubCommittee(): Observable<any> {
    const url = `${this.baseURL}SubCommittee/GetSubCommitteeCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all function count----')),
      catchError(this.handleError<any>('-----Get all function count----'))
    );
  }


  /* Add SubCommitee */
  addSubCommittee(subcommittee: any): Observable<any> {
    console.log('--------Add SubCommittee data in service:------', subcommittee);
    const url = `${this.baseURL}SubCommittee/CreateSubCommittee`;
    return this.http.post<any>(url, subcommittee, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      catchError(this.handleError<any>('addSubCommittee'))
    );
  }

  /* Update SubCommitee */
  updateSubCommittee(subcommittee): Observable<any> {
    const url = `${this.baseURL}SubCommittee/UpdateSubCommittee`;
    return this.http.put(url, JSON.stringify(subcommittee), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated SubCommitee----------------`)),
      catchError(this.handleError<any>('updateSubCommittee'))
    );
  }


  getSubCommitteeLeadersList(): Observable<any> {
    const url = `${this.baseURL}subcommittee/getSubCommitteeLeaders `;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(lists => console.log('-----getSubCommitteeLeadersList------', lists)),
      catchError(this.handleError('getSubCommitteeLeadersList', []))
    );
  }

  getSubCommitteeCoordinatorList(): Observable<any> {
    const url = `${this.baseURL}subcommittee/getSubCommitteeCoordinators`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(lists => console.log('-----getSubCommitteeCoordinators List------', lists)),
      catchError(this.handleError('getSubCommitteeCoordinators List', []))
    );
  }





  /* -----------------------------------------SubCommittee Ends---------------------------------------------------------- */



  /* ------------------------------------------Team Begins-------------------------------------------------------------- */


  /* -------------------------------------------Add Team----------------------------------------------------------------- */
  addTeam(team: any): Observable<any> {
    console.log('--------Add Team data in service:------', team);
    const url = `${this.baseURL}Team/CreateTeam`;
    return this.http.post<any>(url, team, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      catchError(this.handleError<any>('addTeam'))
    );
  }

  /*----------------------------------------- Get Teams---------------------------------------------------------------- */
  getTeams(paginationDetails) {
    const url = `${this.baseURL}Team/GetTeams/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(teams => console.log('-----Fetched all Teams------', teams)),
        catchError(this.handleError('getTeams', []))
      );
  }
  /* -----------------------------------------Get Team By Id---------------------------------------------------------------- */
  getTeamById(id): Observable<any> {
    const url = `${this.baseURL}Team/GetTeamById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(teams => console.log('-----Fetched all Team by id------', teams)),
        catchError(this.handleError('getTeamById', []))
      );
  }

  /* --------------------------------------get Team facilitator Hod Lists---------------------------------------- */
  getFacilitatorHoD(): Observable<any> {
    const url = `${this.baseURL}team/getfacilitatorhods`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(teamFacilitator => console.log('-----Fetched all Team Facilitator Lists------', teamFacilitator)),
        catchError(this.handleError('getFacilitatorHoD', []))
      );
  }
  /* ------------------------------------------Get Team Leader Lists----------------------------------------- */
  getTeamLeaderLists(): Observable<any> {
    const url = `${this.baseURL}team/getteamleader`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(teamLeader => console.log('-----Fetched all Team Leader Lists------', teamLeader)),
        catchError(this.handleError('getTeamLeaderLists', []))
      );
  }
  /* --------------------------------------------Get TEam Leader Mentor Fh------------------------------------ */
  getMentorFH(): Observable<any> {
    const url = `${this.baseURL}team/GetMentorFh`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(teamMentor => console.log('-----Fetched all Team Mentor Fh Lists------', teamMentor)),
        catchError(this.handleError('getMentorFH', []))
      );
  }

  /*---------------------------------------- Get Total Number Teams------------------------------------------------------ */
  getTotalNumberOfTeamCount(): Observable<any> {
    const url = `${this.baseURL}Team/GetTeamCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Team count----')),
      catchError(this.handleError<any>('-----Get all Team count----'))
    );

  }
  /* ----------------------------------------Update Team--------------------------------------------------------------------- */
  updateTeam(team): Observable<any> {
    const url = `${this.baseURL}Team/UpdateTeam`;
    return this.http.put(url, JSON.stringify(team), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Team----------------`)),
      catchError(this.handleError<any>('updateTeam'))
    );
  }

  /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Team Ends!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */


  /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Section Begins!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */

  /*----------------------------------- Add Section --------------------------------------*/
  addSection(section: any): Observable<any> {
    console.log('--------Add Section data in service:------', section);
    const url = `${this.baseURL}Section/CreateSection`;
    return this.http.post<any>(url, JSON.stringify(section), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      catchError(this.handleError<any>('addSection'))
    );
  }
  /* ----------------------------------------Get Section------------------------------------------------ */
  getSections(paginationDetails) {
    const url = `${this.baseURL}Section/GetSections/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(sections => console.log('-----Fetched all Sections------', sections)),
        catchError(this.handleError('getSections', []))
      );
  }
  /*------------------------------------- Update Section-------------------------------------------------- */
  updateSection(section): Observable<any> {
    const url = `${this.baseURL}Section/UpdateSection`;
    return this.http.put(url, JSON.stringify(section), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Section----------------`)),
      catchError(this.handleError<any>('updateSection'))
    );
  }

  getDepartmentNameId() {
    const url = `${this.baseURL}department/GetdepartmentidName`;
    return this.http.get(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(_ => console.log(`--------Updated Section----------------`)),
      catchError(this.handleError<any>('updateSection'))
    );
  }

  getTeamNameId() {
    const url = `${this.baseURL}team/GetTeamIdName`;
    return this.http.get(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(_ => console.log(`--------Updated Section----------------`)),
      catchError(this.handleError<any>('updateSection'))
    );
  }

  /* ------------------------------------Get Total Number Of Sections-------------------------------------------- */
  getTotalNumberOfSection(): Observable<any> {
    const url = `${this.baseURL}Section/GetSectionCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Section count----')),
      catchError(this.handleError<any>('-----Get all Section count----'))
    );
  }
  /* -----------------------------------------Get <Sections NAmes>------------------------------------ */
  getSectionsNames(): Observable<any> {
    const url = `${this.baseURL}Section/GetSectionNameMasterList`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(sectionNames => console.log('-----Fetched all SubCommittees------', sectionNames)),
      catchError(this.handleError('getSectionsNames', []))
    );
  }

  getSectionsNameId(): Observable<any> {
    const url = `${this.baseURL}Section/GetSectionNameId`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(sectionNames => console.log('-----Fetched all SubCommittees------', sectionNames)),
      catchError(this.handleError('getSectionsNames', []))
    );
  }
  /* ----------------------------------------Get Section SH Lists--------------------- */
  getShList(): Observable<any> {
    const url = `${this.baseURL}section/getsectionhead`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(res => console.log('-----Get all SH LISTS ----', res)),
      catchError(this.handleError<any>('-----Get all SH Lists ----'))
    );
  }
  /* ----------------------------------------Get Sections <Department Names>---------------------------------- */
  getSectionDepartmentNames(): Observable<any> {
    const url = `${this.baseURL}Section/GetDepartments`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(departmentNames => console.log('-----Fetched all Department Names------', departmentNames)),
      catchError(this.handleError('getSectionDepartmentNames', []))
    );
  }

  /* ----------------------------------------Get Sections <Team>-------------------------------------- */
  getSectionTeamNames(): Observable<any> {
    const url = `${this.baseURL}Section/GetTeams`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(sectionNames => console.log('-----Fetched all Department Names------', sectionNames)),
      catchError(this.handleError('getSectionTeamNames', []))
    );
  }

  /* ----------------------------------------Get Section By Id -----------------------------------------------*/
  getSectionById(id): Observable<any> {
    const url = `${this.baseURL}Section/GetSectionById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(sections => console.log('-----Fetched all Department Names------', sections)),
      catchError(this.handleError('getSectionById', []))
    );
  }

  /* ----!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Section Ends!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!------------------------------ */
  /* Employee */

  /* Add Employee */
  addEmployee(employeeData: any): Observable<any> {
    console.log('--------Add Employee data in service:------', employeeData);
    const url = `${this.baseURL}employee/createemployee`;
    return this.http.post<any>(url, employeeData, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((employee: any) => console.log(`--------Employee with employee id`, employee)),
      catchError(this.handleError<any>('addEmployee'))
    );
  }
  getEmployees(paginationDetails) {
    const url = `${this.baseURL}Employee/GetEmployees/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(employees => console.log('-----Fetched all Employees------', employees)),
        catchError(this.handleError('getEmployees', []))
      );
  }

  getWorkManEmployees(paginationDetails) {
    const url = `${this.baseURL}WorkmanEmployee/GetWorkmanEmployees/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(employees => console.log('-----Fetched all Employees------', employees)),
        catchError(this.handleError('getEmployees', []))
      );
  }

  /* -------------------------------Get Employee by Id------------------------------ */
  getEmployeeById(id): Observable<any> {
    const url = `${this.baseURL}Employee/GetEmployees/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeesId => console.log('-----Fetched  Employees id------', employeesId)),
      catchError(this.handleError('getEmployeeById', []))
    );
  }

  GetWorkmanEmployeeLoginIds() {
    const url = `${this.baseURL}WorkmanEmployee/GetWorkmanEmployeeLoginIds`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeesId => console.log('-----Fetched  Employees Login id------', employeesId)),
      catchError(this.handleError('getEmployeeById', []))
    );
  }

  createWorkmanEmployee(data) {
    const url = `${this.baseURL}WorkmanEmployee/CreateWorkmanEmployee`;
    return this.http.post<any>(url, data, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeesId => console.log('-----Fetched  Employees Login id------', employeesId)),
      catchError(this.handleError('getEmployeeById', []))
    );
  }





  /* ----------------------Get Employee Total Count------------------ */
  getEmployeeTotalCount(): Observable<any> {
    const url = `${this.baseURL}Employee/GetEmployeeCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Employee count----')),
      catchError(this.handleError<any>('-----Get all Employee count----'))
    );
  }

  getWorkManEmployeeTotalCount(): Observable<any> {
    const url = `${this.baseURL}workmanemployee/GetWorkmanEmployeeCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Employee count----')),
      catchError(this.handleError<any>('-----Get all Employee count----'))
    );
  }

  getEmployeeSearch(paginationDetails, data) {
    const url = `${this.baseURL}Employee/GetEmployeeByUserName/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.post<any>(url, data, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeesUnit => console.log('-----Fetched all Employees Unit------', employeesUnit)),
      catchError(this.handleError('getEmployeeUnitField', []))
    );
  }

  getWorkManEmployeeSearch(paginationDetails, data) {
    const url = `${this.baseURL}workmanemployee/GetWorkmanEmployeeByUserName/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.post<any>(url, data, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeesUnit => console.log('-----Fetched all Employees Unit------', employeesUnit)),
      catchError(this.handleError('getEmployeeUnitField', []))
    );
  }

  getSectionsByUnit(unitcode: any): Observable<any> {
    const url = `${this.baseURL}section/getSectionByUnit/${unitcode}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      catchError(this.handleError<any>('-----getSectionsByUnit----'))
    );
  }



  /* -------------------------Get Employee Unit Field--------------------------------- */
  getEmployeeUnitField(): Observable<any> {
    const url = `${this.baseURL}unit/Getunits/-1/-1`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeesUnit => console.log('-----Fetched all Employees Unit------', employeesUnit)),
      catchError(this.handleError('getEmployeeUnitField', []))
    );
  }


  getDepartmentByUnit(unitCode: any): Observable<any> {
    const url = `${this.baseURL}department/Getdepartmentbyunit/${unitCode}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeesDepartment => console.log('-----Fetched all Employees department------', employeesDepartment)),
      catchError(this.handleError('getDepartmentByUnit', []))
    );
  }

  getEmployeeTeamByUnit(unitCode: any): Observable<any> {
    const url = `${this.baseURL}team/GetTeambyunit/${unitCode}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeesTeam => console.log('-----Fetched all Employees Team------', employeesTeam)),
      catchError(this.handleError('getEmployeeTeamByUnit', []))
    );
  }

  getSubCommitteeByUnit(unitCode: any): Observable<any> {
    const url = `${this.baseURL}SUBCOMMITTEE/getSUBCOMMITTEEbyunit/${unitCode}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeesSubCommittee => console.log('-----Fetched all Employees Team------', employeesSubCommittee)),
      catchError(this.handleError('getSubCommitteeByUnit', []))
    );
  }




  /* ---------------------------get Employee Department Field-------------- */
  /* getEmployeeDepartmentField(): Observable<any> {
    const url = `${this.baseURL}department/Getdepartments/-1/-1`;
    return this.http.get<any>(url).pipe(
      tap(employeesDepartment => console.log('-----Fetched all Employees Department------', employeesDepartment)),
      catchError(this.handleError('getEmployeeDepartmentField', []))
    );
  } */



  /* ------------------- Get EMployee Position field--------------------------------*/
  getPositionOfEmployee(): Observable<any> {
    const url = `${this.baseURL}position/getpositions/-1/-1`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeesPosition => console.log('-----Fetched all Employees Position------', employeesPosition)),
      catchError(this.handleError('getPositionOfEmployee', []))
    );
  }

  /* --------------------Get EMployee Role Field------------------------------- */
  getRoleOfEmployee(): Observable<any> {
    const url = `${this.baseURL}role/getroles/-1/-1`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeesRole => console.log('-----Fetched all Employees Position------', employeesRole)),
      catchError(this.handleError('getRoleOfEmployee', []))
    );
  }

  /* -----------------Get EMployee Catefgory Of Employee Field--------------------- */
  getEmployeeCategoryOfEmployee(): Observable<any> {
    const url = `${this.baseURL}employeecategory/getemployeecategorys/-1/-1`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeesCategory => console.log('-----Fetched all Employees Employee Category------', employeesCategory)),
      catchError(this.handleError('getEmployeeCategoryOfEmployee', []))
    );
  }

  /* Update Employeee */
  updateEmployee(employeeData): Observable<any> {
    const url = `${this.baseURL}Employee/updateEmployee`;
    return this.http.put(url, JSON.stringify(employeeData), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Employee----------------`)),
      catchError(this.handleError<any>('updateEmployee'))
    );
  }

  updateWorkManEmployee(employeeData): Observable<any> {
    const url = `${this.baseURL}workmanemployee/updateWorkManEmployee`;
    return this.http.put(url, JSON.stringify(employeeData), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Employee----------------`)),
      catchError(this.handleError<any>('updateEmployee'))
    );
  }


  /*----------------------------------------------- Add Evaluator ----------------------------------------*/
  addEvaluator(evaluatorData: any): Observable<any> {
    console.log('--------Add Evaluator data in service:------', evaluatorData);
    const url = `${this.baseURL}evaluator/createevaluator`;
    return this.http.post<any>(url, evaluatorData, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      catchError(this.handleError<any>('addEvaluator'))
    );
  }


  /* -----------------------------Get EValuator NAme List---------------- */
  getEvaluatorName(): Observable<any> {
    const url = `${this.baseURL}evaluator/getevaluatornames`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(evaluators => console.log('-----Fetched all Evaluators------', evaluators)),
      catchError(this.handleError('getEvaluatorName', []))
    );
  }

  /* get Evaluator */
  getEvaluators(paginationDetails): Observable<any> {
    const url = `${this.baseURL}evaluator/getevaluators/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(evaluators => console.log('-----Fetched all Evaluators------', evaluators)),
        catchError(this.handleError('getEvaluators', []))
      );
  }
  getTotalNumberOfEvaluators(): Observable<any> {
    const url = `${this.baseURL}evaluator/GetevaluatorCount`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(evaluatorsCount => console.log('-----Fetched all Evaluators count------', evaluatorsCount)),
        catchError(this.handleError('getTotalNumberOfEvaluators', []))
      );
  }
  /* --------------------------------------Evaluator Module------------------------------------- */
  getEvaluatorModule(): Observable<any> {
    const url = `${this.baseURL}proficiencylevel/getproficiencylevels/-1/-1`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(evaluatorsModule => console.log('-----Fetched all Evaluators Module------', evaluatorsModule)),
        catchError(this.handleError('getEvaluatorModule', []))
      );
  }

  getEvaluatorById(id) {
    const url = `${this.baseURL}evaluator/GetEvaluatorById/${id}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(evaluatorsModule => console.log('-----Fetched all Evaluators Module------', evaluatorsModule)),
        catchError(this.handleError('getEvaluatorModule', []))
      );
  }

  testAPI(data) {
    const url = 'http://utcl-confluence-sfc-dev.centralindia.cloudapp.azure.com:8081/TestAPI';
    return this.http.post<any[]>(url, data);

  }











  /* Update Evaluator */
  updateEvaluator(evaluator): Observable<any> {
    const url = `${this.baseURL}evaluator/updateEvaluator`;
    return this.http.put(url, evaluator, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(_ => console.log(`--------Updated Evaluator----------------`)),
      catchError(this.handleError<any>('updateEvaluator'))
    );
  }

  /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Area Begins!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */



  /*--------------------------------------------------- Add Area----------------------------------------------------- */
  addArea(area: any): Observable<any> {
    console.log('--------Add Area data in service:------', area);
    const url = `${this.baseURL}Area/CreateArea`;
    return this.http.post<any>(url, area, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      catchError(this.handleError<any>('addArea'))
    );
  }
  /*------------------------------------------------- get Area------------------------------------------------------ */
  getAreas(paginationDetails) {
    const url = `${this.baseURL}Area/GetAreas/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(areas => console.log('-----Fetched all areas------', areas)),
        catchError(this.handleError('getAreas', []))
      );
  }

  getSectionNameId() {
    const url = `${this.baseURL}section/getsectionnameid`;
    return this.http.get(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(_ => console.log(`--------Updated Section----------------`)),
      catchError(this.handleError<any>('updateSection'))
    );
  }

  getUnitNameId() {
    const url = `${this.baseURL}unit/GetUnitNameId`;
    return this.http.get(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(_ => console.log(`--------Updated Section----------------`)),
      catchError(this.handleError<any>('updateSection'))
    );
  }

  /* ----------------------------------------------Get Total Number Of Areas-------------------------------------- */
  getTotalNumberOfAreas(): Observable<any> {
    const url = `${this.baseURL}Area/GetAreaCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Area count----')),
      catchError(this.handleError<any>('-----Get all Area count----'))
    );
  }

  /* ------------------------------------------------Get Area By id------------------------------------ */
  getAreaById(id): Observable<any> {
    const url = `${this.baseURL}Area/GetAreaById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(areas => console.log('-----Fetched all Department Names------', areas)),
      catchError(this.handleError('getAreaById', []))
    );
  }
  /* -----------------------------------------------Get <unit name> for area------------------------------ */
  getunitNames(): Observable<any> {
    const url = `${this.baseURL}Unit/GetUnits/-1/-1`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(unitsNames => console.log('-----Fetched all unitNames------', unitsNames)),
      catchError(this.handleError('getunitNames', []))
    );
  }



  /*------------------------------------------------ Update Area------------------------------------------ */
  updateArea(area): Observable<any> {
    const url = `${this.baseURL}Area/UpdateArea`;
    return this.http.put(url, JSON.stringify(area), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Area----------------`)),
      catchError(this.handleError<any>('updateArea'))
    );
  }


  /* add Equipment */
  addEquipment(equipmentData: any): Observable<any> {
    console.log('--------Add Equipment data in service:------', equipmentData);
    const url = `${this.baseURL}equipment/CreateEquipment`;
    return this.http.post<any>(url, equipmentData, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((equipment: any) => console.log(`--------Equipment with equipment id`)),
      catchError(this.handleError<any>('addEquipment'))
    );
  }
  /* ----------------------------------------------get Equipment -------------------------------*/
  getEquipments(paginationDetails) {
    const url = `${this.baseURL}equipment/GetEquipments/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;

    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(equipments => console.log('-----Fetched all equipments------', equipments)),
        catchError(this.handleError('getEquipments', []))
      );
  }

  getReviewers(unitId) {
    const url = `${this.baseURL}employee/getreviewer?unitId=${unitId}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(reviewers => console.log('-----Fetched all reviewers------', reviewers)),
        catchError(this.handleError('getReviewers', []))
      );
  }

  getAppraisers(unitId) {
    const url = `${this.baseURL}employee/getappraiser?unitId=${unitId}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(appraisers => console.log('-----Fetched all appraisers------', appraisers)),
        catchError(this.handleError('getAppraisers', []))
      );
  }


  getProficiencyLevels() {
    const url = `${this.baseURL}proficiencylevel/GetProficiencyLevels/-1/-1`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(levels => console.log('-----getProficiencyLevels------', levels)),
        catchError(this.handleError('getProficiencyLevels', []))
      );
  }

  getEmployeeNames() {
    const url = `${this.baseURL}employee/GetEmployeeName`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(appraisers => console.log('-----getEmployeeNames------', appraisers)),
        catchError(this.handleError('getEmployeeNames', []))
      );
  }

  getEmployeeNameByUnit(id) {
    const url = `${this.baseURL}employee/GetEmployeeName?unitId=${id}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(appraisers => console.log('-----getEmployeeNames------', appraisers)),
        catchError(this.handleError('getEmployeeNames', []))
      );
  }

  /* -----------------------Get Total no of Equipments------------ */
  getTotalNumberOfEquipments(): Observable<any> {
    const url = `${this.baseURL}equipment/GetEquipmentCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Equipments count----')),
      catchError(this.handleError<any>('-----Get all Equipments count----'))
    );
  }


  /* -------------------------------GEt <areasnames> of the equipments------------------ */
  getAreasNamesOfEquipment(): Observable<any> {
    const url = `${this.baseURL}area/getareas/-1/-1`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(areaNames => console.log('-----Fetched all areaNames------', areaNames)),
      catchError(this.handleError('getAreasNamesOfEquipment', []))
    );
  }

  /* ---------------------------------------Get Equipment By sno---------------------------------- */
  getEquipmentById(sno: any): Observable<any> {
    const url = `${this.baseURL}equipment/GetEquipmentById/${sno}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(equipment => console.log('-----Fetched all Equipment Names------', equipment)),
      catchError(this.handleError('getEquipmentById', []))
    );
  }

  /* update Equipment */
  updateEquipment(equipment): Observable<any> {
    const url = `${this.baseURL}equipment/updateEquipment`;
    return this.http.put(url, equipment, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(_ => console.log(`--------Updated Equipment----------------`)),
      catchError(this.handleError<any>('updateEquipment'))
    );
  }

  /* -----------------------------------------------------Add ROle --------------------------------*/
  addRole(role: any): Observable<any> {
    console.log('--------Add Role data in service:------', role);
    const url = `${this.baseURL}Role/CreateRole`;
    return this.http.post<any>(url, role, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      catchError(this.handleError<any>('addRole'))
    );
  }

  /* --------------------------------------------------------Get Roles--------------------------------------- */

  getRoles(paginationDetails) {
    const url = `${this.baseURL}Role/GetRoles/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(roles => console.log('-----Fetched all roles------', roles)),
        catchError(this.handleError('getRoles', []))
      );
  }
  /* ----------------------------------Get Total Number Of Roles--------------- */
  getTotalNumberOfRoles(): Observable<any> {
    const url = `${this.baseURL}Role/GetRoleCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Role count----')),
      catchError(this.handleError<any>('-----Get all Role count----'))
    );
  }
  /* ----------------------------------Get Role By Id------------------------------------------------ */
  getRoleById(id: any): Observable<any> {
    const url = `${this.baseURL}Role/GetRoleById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(roles => console.log('-----Fetched all ROle Names------', roles)),
      catchError(this.handleError('getRoleById', []))
    );
  }


  /* --------------------------------Update Role ---------------------------------------------------*/
  updateRole(role: any): Observable<any> {
    const url = `${this.baseURL}Role/UpdateRole`;
    return this.http.put(url, JSON.stringify(role), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Role----------------`)),
      catchError(this.handleError<any>('updateRole'))
    );
  }














  /* Add Proficiency Level */
  addProficiency(proficiency: any): Observable<any> {
    console.log('--------Add Proficiency data in service:------', proficiency);
    const url = `${this.baseURL}Proficiencylevel/CreateProficiencyLevel`;
    return this.http.post<any>(url, proficiency, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((role: any) => console.log(`--------proficiency with Department id`)),
      catchError(this.handleError<any>('addProficiency'))
    );
  }

  getProficiencies(paginationDetails) {
    const url = `${this.baseURL}Proficiencylevel/GetProficiencyLevels/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(proficiency => console.log('-----Fetched all Proficiency------', proficiency)),
        catchError(this.handleError('getProficiency', []))
      );
  }

  /* -----------------------get Proficiency total COunt------------- */
  getProficiencyTotalCount(): Observable<any> {
    const url = `${this.baseURL}Proficiencylevel/GetProficiencyLevelCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Proficiency count----')),
      catchError(this.handleError<any>('-----Get all Proficiency count----'))
    );
  }

  /* --------------------Get Proficiency By Id-------  */
  getProficiencyLevelById(proficiencyLevelId): Observable<any> {
    const url = `${this.baseURL}Proficiencylevel/GetProficiencyLevelById/${proficiencyLevelId}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(proficiency => console.log('-----Fetched all Proficiency Level Names------', proficiency)),
      catchError(this.handleError('getProficiencyLevelById', []))
    );
  }

  updateProficiency(proficiency): Observable<any> {
    const url = `${this.baseURL}Proficiencylevel/UpdateProficiencyLevel`;
    return this.http.put(url, proficiency, httpOptions).pipe(
      tap(_ => console.log(`--------Updated Proficiency----------------`)),
      catchError(this.handleError<any>('updateProficiency'))
    );
  }


  /*------------------------------------------------Add Position--------------------------------------- */
  addPosition(positionData: any): Observable<any> {
    console.log('--------Add Position data in service:------', positionData);
    const url = `${this.baseURL}position/CreatePosition`;
    return this.http.post<any>(url, positionData).pipe(
      tap((role: any) => console.log(`--------position with position id`)),
      catchError(this.handleError<any>('addPosition'))
    );
  }
  /* ----------------------------------------GEt Position------------------------- */

  getPositions(paginationDetails) {
    const url = `${this.baseURL}position/GetPositions/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(position => console.log('-----Fetched all Position------', position)),
        catchError(this.handleError('getPosition', []))
      );
  }
  /* ------------------------------------Ge Total Count Of Position--------------- */
  getTotalNumberOfPosition(): Observable<any> {
    const url = `${this.baseURL}Position/GetPositionCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Position count----')),
      catchError(this.handleError<any>('-----Get all Position count----'))
    );
  }

  /* -------------------------------Get Posiiton By Id----------------------- */
  getPositionById(positionId): Observable<any> {
    const url = `${this.baseURL}Position/GetPositionById/${positionId}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(position => console.log('-----Fetched all ROle Names------', position)),
      catchError(this.handleError('getRoleById', []))
    );
  }





  /* -------------------------------------------------Update position---------------------------------------- */
  updatePosition(positionData): Observable<any> {
    const url = `${this.baseURL}Position/UpdatePosition`;
    return this.http.put(url, JSON.stringify(positionData), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Position----------------`)),
      catchError(this.handleError<any>('updatePosition'))
    );
  }

  /* -----------------------------------------Add Improvement Area---------------------------------------------- */
  addImprovementArea(improvement_area: any): Observable<any> {
    console.log('--------Add Improvement Area data in service:------', improvement_area);
    const url = `${this.baseURL}improvementarea/CreateImprovementArea`;
    return this.http.post<any>(url, improvement_area, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((role: any) => console.log(`--------improvement_area with Department id`)),
      catchError(this.handleError<any>('addImprovementArea'))
    );
  }

  getImprovementArea(paginationDetails) {
    const url = `${this.baseURL}improvementarea/GetImprovementAreas/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(improvement_area => console.log('-----Fetched all Improvement Area------', improvement_area)),
        catchError(this.handleError('getImprovementArea', []))
      );
  }
  /* -----------------------------get Total Count Of Improvement Area---------------- */
  getTotalImprovementAreaCount(): Observable<any> {
    const url = `${this.baseURL}improvementarea/GetImprovementAreaCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Improvement Area count----')),
      catchError(this.handleError<any>('-----Get all Improvement count----'))
    );
  }


  /* -------------------------------------Get Improvement Area By Id------------ */
  getImprovementAreaById(id): Observable<any> {
    const url = `${this.baseURL}improvementarea/GetImprovementAreaById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(improvementArea => console.log('-----Fetched all Improvement Area Names------', improvementArea)),
      catchError(this.handleError('getImprovementAreaById', []))
    );
  }
  /*---------------------------------------- Update Improvement Area--------------------------------------- */
  updateImprovementArea(improvement_area): Observable<any> {
    const url = `${this.baseURL}improvementarea/updateImprovementArea`;
    return this.http.put(url, improvement_area, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(_ => console.log(`--------Updated Improvement Area----------------`)),
      catchError(this.handleError<any>('updateImprovementArea'))
    );
  }


  /* ----------------------------------Employee Category------------------------------- */

  /* -------------------------------------Add Employee Category --------------------------------------------------*/
  addEmployeeCategory(employee_category: any): Observable<any> {
    console.log('--------Add Employee Category data in service:------', employee_category);
    const url = `${this.baseURL}employeecategory/CreateEmployeeCategory`;
    return this.http.post<any>(url, employee_category, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((role: any) => console.log(`--------employee_category with Department id`)),
      catchError(this.handleError<any>('addEmployeeCategory'))
    );
  }
  /* -------------------------------------------GEt Employee Category -------------------------------------*/
  getEmployeeCategory(paginationDetails) {
    const url = `${this.baseURL}employeecategory/GetEmployeeCategorys/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(employee_category => console.log('-------Fetched all Employee Category--', employee_category)),
        catchError(this.handleError('getEmployeeCategory', []))
      );
  }

  /* -------------------------------------------Get Employe Category By Id------------------ */
  getEmployeeCategoryById(employeeCategoryId): Observable<any> {
    const url = `${this.baseURL}employeecategory/GetEmployeeCategoryById/${employeeCategoryId}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(employeeCategory => console.log('-----Fetched all Improvement Area Names------', employeeCategory)),
      catchError(this.handleError('getEmployeeCategoryById', []))
    );
  }

  /* --------------------------------Get Employye Category Total Count------------------------ */
  getTotalNumberOfEmployeeCategory(): Observable<any> {
    const url = `${this.baseURL}employeecategory/GetEmployeeCategoryCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Employee Category count----')),
      catchError(this.handleError<any>('-----Get all Employee Category count----'))
    );
  }

  /* -------------------------------------Update EMployee Category------------------------------------------------ */
  updateEmployeeCategory(EmployeeCategoryData): Observable<any> {
    const url = `${this.baseURL}employeecategory/UpdateEmployeeCategory`;
    return this.http.put(url, JSON.stringify(EmployeeCategoryData), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Employee Category----------------`)),
      catchError(this.handleError<any>('updateEmployeeCategory'))
    );
  }

  /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Financial Year Begins!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */

  /* ----------------------------Add Financial Year ----------------------------------------------------*/
  addFinancialYear(financial_year: any): Observable<any> {
    console.log('--------Add Financial Year data in service:------', financial_year);
    const url = `${this.baseURL}FinancialYear/CreateFinancialYear`;
    return this.http.post<any>(url, financial_year, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      catchError(this.handleError<any>('addFinancialYear'))
    );
  }
  /* ----------------------------Get Financial Year------------------------------------------------------------- */

  /* GEt Financial Year */
  getFinancialYears(paginationDetails) {
    const url = `${this.baseURL}FinancialYear/GetFinancialYears/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(financial_year => console.log('-------Fetched all  FInancial Year--', financial_year)),
        catchError(this.handleError('getFinancialYears', []))
      );
  }
  /* -----------------------------------Get Total Financial Year-------------------------------------------------- */
  getTotalNumberFinancialYearCount(): Observable<any> {
    const url = `${this.baseURL}FinancialYear/GetFinancialYearCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Finanncial Year count----')),
      catchError(this.handleError<any>('-----Get all Financial Year count----'))
    );
  }
  /* ------------------------------------Get Financial Year By Id-------------------------------------------------- */
  getFinancialYearById(id): Observable<any> {
    const url = `${this.baseURL}FinancialYear/GetFinancialYearById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(financialYears => console.log('-----Fetched all units------', financialYears)),
      catchError(this.handleError('getFinancialYears', []))
    );
  }
  /*------------------------------ Update Financial Year --------------------------------------------------------*/
  updateFinancialYear(financial_year): Observable<any> {
    const url = `${this.baseURL}FinancialYear/updateFinancialYear`;
    return this.http.put(url, JSON.stringify(financial_year), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Financial Year Category----------------`)),
      catchError(this.handleError<any>('updateFinancialYear'))
    );
  }
  /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!End Financial Year!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */




  /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Month Begins!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */



  /* ---------------------------------------------Add Month ---------------------------------------------------------*/
  addMonth(month: any): Observable<any> {
    console.log('--------Add Month data in service:------', month);
    const url = `${this.baseURL}MonthNames/CreateMonthNames`;
    return this.http.post<any>(url, month, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      catchError(this.handleError<any>('addMonth'))
    );
  }
  /*------------------------------------------- GEt Months -----------------------------------------------------------*/
  getMonths(paginationDetails) {
    const url = `${this.baseURL}MonthNames/GetMonthNames/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(month => console.log('-------Fetched all Month Category--', month)),
        catchError(this.handleError('getMonths', []))
      );
  }
  /* ---------------------------------------Get Total Number Of Month---------------------------------- */
  getTotalNumberOfMonth(): Observable<any> {
    const url = `${this.baseURL}MonthNames/GetMonthNamesCount`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Month Year count----')),
      catchError(this.handleError<any>('-----Get all Month Year count----'))
    );
  }
  /* ---------------------------------------Get <monthNames> input field------------------------------------ */
  /* getMonthsNames(): Observable<any> {
    const url = `${this.baseURL}MonthNames/GetMonths`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }) .pipe(
      tap(monthnames => console.log('-----Fetched all monthsNames------', monthnames)),
      catchError(this.handleError('getMonthsNames', []))
    );
  } */
  /* --------------------------------------------Get Month By Id------------------------------------------------ */
  getMonthById(id): Observable<any> {
    const url = `${this.baseURL}MonthNames/GetMonthNamesById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(month => console.log('-----Fetched all Month by id------', month)),
      catchError(this.handleError('getMonthById', []))
    );
  }

  getEmployeeDataById(id: any): Observable<any> {
    const url = `${this.baseURL}employee/getEmployeeById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(month => console.log('-----getEmployeeDataById------', month)),
      catchError(this.handleError('getEmployeeDataById', []))
    );
  }

  getWorkManEmployeeDataById(id: any): Observable<any> {
    const url = `${this.baseURL}WorkmanEmployee/GetWorkmanEmployeeById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(month => console.log('-----getEmployeeDataById------', month)),
      catchError(this.handleError('getEmployeeDataById', []))
    );
  }


  /*--------------------------------------- ----Update Month--------------------------------------------------------- */
  updateMonth(month: any): Observable<any> {
    const url = `${this.baseURL}MonthNames/UpdateMonthNames`;
    return this.http.put(url, JSON.stringify(month), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Month Category----------------`)),
      catchError(this.handleError<any>('updateMonth'))
    );
  }
  /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Add key Focus Area Begins!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */



  /* ----------------------------------------Add Key Focus Area------------------------------------------------------- */
  addKeyFocusArea(keyFocusArea: any): Observable<any> {
    console.log('--------Add Key Focus Area data in service:------', keyFocusArea);
    const url = `${this.baseURL}keyfocusarea/createKeyFocusArea`;
    return this.http.post<any>(url, JSON.stringify(keyFocusArea), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      catchError(this.handleError<any>('addKeyFocusArea'))
    );
  }
  /* -------------------------------------Get Key Focus Area -----------------------------------------------------------*/
  getKeyFocusAreas(paginationDetails) {
    const url = `${this.baseURL}KeyFocusArea/GetKeyFocusAreas/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(keyFocusArea => console.log('-------Fetched all Key Focus Area--', keyFocusArea)),
        catchError(this.handleError('getKeyFocusArea', []))
      );
  }

  /*----------------------------------- Get Key Focus Area Total Count---------------------------------------------- */
  getTotalNumberOfKeyFocusAreas(): Observable<any> {
    const url = `${this.baseURL}KeyFocusArea/GetKeyFocusAreaCount`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Key Focus Area  count----')),
      catchError(this.handleError<any>('-----Get all Key Focus Area count----'))
    );
  }

  /* --------------------------------------Get Key Focus Area By Id----------------------------------------------- */
  getKeyFocusAreaById(id): Observable<any> {
    const url = `${this.baseURL}KeyFocusArea/GetKeyFocusAreaById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(keyFocusArea => console.log('-----Fetched all Key Focus Area by id------', keyFocusArea)),
      catchError(this.handleError('getKeyFocusAreaById', []))
    );
  }





  /* ------------------------------------Get Keyy Focus Areas Names---------------------------------------------------- */
  /* getKeyFocusAreasNames(): Observable<any> {
    const url = `${this.baseURL}KeyFocusArea/GetKeyFocusAreaNames`;
    return  this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(keyfocusareanames => console.log('-----Fetched all keyfocusareanames------', keyfocusareanames)),
      catchError(this.handleError('getKeyFocusAreasNames', []))
    );
  } */









  /* Update Key Focus Area */
  updateKeyFocusArea(keyFocusArea): Observable<any> {
    const url = `${this.baseURL}KeyFocusArea/updateKeyFocusArea`;
    return this.http.put(url, keyFocusArea, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(_ => console.log(`--------Updated Key Focus Area Category----------------`)),
      catchError(this.handleError<any>('updateKeyFocusArea'))
    );
  }


  /*------------------------------------ Name Master Function Names--------------- */

  getMasterFunctionsNames(paginationDetails): Observable<any> {
    const url = `${this.baseURL}Function/GetFunctionNameMasterValues/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(functionNamess => console.log('-------Fetched all FunctionNames--', functionNamess)),
      catchError(this.handleError('getMasterFunctionsNames', []))
    );
  }
  getMasterFunctionNamesById(id): Observable<any> {
    const url = `${this.baseURL}function/GetFunctionNameById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(getMasterFunctionNames => console.log('-----Fetched all Key Focus Area by id------', getMasterFunctionNames)),
      catchError(this.handleError('getMasterFunctionNamesById', []))
    );
  }


  /* ------------------------------Name Mastre Total Count Function Names --------------*/
  getTotalCountOfMasterFunctionnames(): Observable<any> {
    const url = `${this.baseURL}Function/GetFunctionNameMasterListCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Master Total Count count----')),
      catchError(this.handleError<any>('-----Get all Master   count----'))
    );
  }

  /*-------------------------------------- Add Function names */
  addFunctionNames(functionNames: any): Observable<any> {
    console.log('---Add Function Names in service', functionNames);
    const url = `${this.baseURL}Function/CreateFunctionName`;
    return this.http.post<any>(url, functionNames, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      catchError(this.handleError<any>('addFunctionNames'))
    );
  }


  /*-------------------------------------------------- Update Function Names */

  updateMasterFunctionNames(functionNamesData): Observable<any> {
    const url = `${this.baseURL}Function/UpdateFunctionName`;
    return this.http.put(url, JSON.stringify(functionNamesData), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Function Names Category----------------`)),
      catchError(this.handleError<any>('updateMasterFunctionNames'))
    );
  }
  /* --------------------------------------------Name Master Sub-committe Begins----------------------------- */
  /* Add Sub Committee */
  addMasterSubCommitteeNames(addSubCommitteeNameData: any): Observable<any> {
    console.log('---Add Sub Committe Names in service', addSubCommitteeNameData);
    const url = `${this.baseURL}SubCommittee/CreateSubCommitteeName`;
    return this.http.post<any>(url, addSubCommitteeNameData, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((subCommitteeNames: any) => console.log(`--------Sub Committee names with Department id`)),
      catchError(this.handleError<any>('addSubCommitteeNAmes'))
    );
  }
  /* -----------------------------------------get Sub Commitee names */
  getMasterSubCommittees(paginationDetails) {
    const url = `${this.baseURL}SubCommittee/GetSubCommitteeNameMasterValues/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(subCommitteeNames => console.log('-------Fetched Sub-Committee Names--', subCommitteeNames)),
        catchError(this.handleError('getSubCommitteeNames', []))
      );
  }

  /* ---------------------------------------------get Total Count SubCommitte Names--------- */
  getTotalCountOfMasterSubCommitteesNames(): Observable<any> {
    const url = `${this.baseURL}SubCommittee/GetSubCommitteeNameMasterListCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Master Total SubCommitte Names----')),
      catchError(this.handleError<any>('-----Get all Master  SubCommitte Names count----'))
    );
  }

  /* -----------------------Get Sub-Committe By Id------------- */
  getMasterSubCommitteesNamesById(id): Observable<any> {
    const url = `${this.baseURL}SubCommittee/GetSubCommitteeNameById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(getMasterSubCommitteesNames => console.log('-----Fetched all Sub Committee by id------', getMasterSubCommitteesNames)),
      catchError(this.handleError('getMasterSubCommitteesNamesById', []))
    );
  }

  /* Update Sub Committe Names */
  updateMasterSubCommitteeNames(subCommitteeNamesData): Observable<any> {
    const url = `${this.baseURL}SubCommittee/UpdateSubCommitteeName`;
    return this.http.put(url, JSON.stringify(subCommitteeNamesData), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Sub Committee Names Category----------------`)),
      catchError(this.handleError<any>('updateSubCommitteeNames'))
    );
  }


  /* --------------------------------------------------Name Master Department names----------------- */

  /* ------------------------------------get Name Master Department Names -------------------------------*/
  getMasterDepartmentNames(paginationDetails): Observable<any> {
    const url = `${this.baseURL}Department/GetDepartmentNameMasterValues/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(departmentNamess => console.log('-------Fetched all DepartmentNames--', departmentNamess)),
      catchError(this.handleError('getMasterDepartmentNames', []))
    );
  }

  /* -------------------------------------get Total Count Names master Department Names------------------------ */
  getTotalMasterDepartmentNamesCount(): Observable<any> {
    const url = `${this.baseURL}Department/GetDepartmentNameMasterListCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Name Master Total Count count----')),
      catchError(this.handleError<any>('-----Get all Name Master   count----'))
    );
  }

  /* ---------------------------------------Add Name Master Department Names ----------------------------------------------------*/
  addMasterDepartmentNames(departmentName: any): Observable<any> {
    console.log('Add Department Names in service', departmentName);
    const url = `${this.baseURL}Department/CreateDepartmentName`;
    return this.http.post<any>(url, departmentName, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((subCommitteeNames: any) => console.log(`--------Department names with Department id`)),
      catchError(this.handleError<any>('addDepartmentNames'))
    );
  }

  /* -------------------------------------------Get Name Master Department Names--------------------- */
  getMasterDepartmentNameById(id): Observable<any> {
    const url = `${this.baseURL}department/GetDepartmentNameById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(getMasterDepartmentNames => console.log('-----Fetched allDepartment names  by id------', getMasterDepartmentNames)),
      catchError(this.handleError('getMasterDepartmentNameById', []))
    );
  }

  /* ----------------------------------------Update Master Department Names --------------------------------------*/
  updateMasterDepartmentNames(departmentNamesData): Observable<any> {
    const url = `${this.baseURL}Department/UpdateDepartmentName`;
    return this.http.put(url, JSON.stringify(departmentNamesData), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated  Department Names Category----------------`)),
      catchError(this.handleError<any>('updateMasterDepartmentNames'))
    );
  }









  /* Add Section Names */
  addMasterSectionNames(addSectionNameData: any): Observable<any> {
    console.log('Add Section Names in service', addSectionNameData);
    const url = `${this.baseURL}section/CreateSectionName`;
    return this.http.post<any>(url, addSectionNameData, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((sectionNames: any) => console.log(`--------Section names with  id`)),
      catchError(this.handleError<any>('addMasterSectionNames'))
    );
  }

  /* ------------------------------------------------Get Section Names */
  getSectionNames(paginationDetails) {
    const url = `${this.baseURL}Section/GetSectionNameMasterValues/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(sectionNames => console.log('-------Fetched all Section Names--', sectionNames)),
        catchError(this.handleError('getSectionNames', []))
      );
  }
  /* -----------------------------------------------------Get Total No Of Section Names */
  getTotalNumberOfSectionNames(): Observable<any> {
    const url = `${this.baseURL}Section/GetSectionNameMasterListCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all Section Name Total Count count----')),
      catchError(this.handleError<any>('-----Get all Section Name   count----'))
    );
  }

  /* --------------------------------------------Get Section NAmes By Id------------- */
  getMasterSectionNamesById(id): Observable<any> {
    const url = `${this.baseURL}Section/GetSectionNameById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(sections => console.log('-----Fetched all Section Name By Id------', sections)),
      catchError(this.handleError('getMasterSectionNamesById', []))
    );
  }

  /* Update Section Names */
  updateMasterSectionNames(sectionNames): Observable<any> {
    const url = `${this.baseURL}section/UpdateSectionName`;
    return this.http.put(url, JSON.stringify(sectionNames), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated Section Names Category----------------`)),
      catchError(this.handleError<any>('updateSectionNames'))
    );
  }


  /* ---------------------------------Evaluation Scoring Parameters---------------------------- */
  getEvaluationScoringParameters(paginationDetails): Observable<any> {
    // tslint:disable-next-line: max-line-length
    const url = `${this.baseURL}kaizenevaluationscoringparameters/GetKaizenEvaluationScoringParameters/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(scoringParameter => console.log('-------Fetched all Scoring Parameters--', scoringParameter)),
      catchError(this.handleError('getEvaluationScoringParameters', []))
    );
  }

  /* -------------------------------Get Total COunt Of Evaluation Scoring Parameters-------- */
  getTotalNumberEvaluationScoringParameters(): Observable<any> {
    const url = `${this.baseURL}kaizenevaluationscoringparameters/GetKaizenEvaluationScoringParametersCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(totalScoringParameter => console.log('-------Fetched total Evaluation Scoring Parameters--', totalScoringParameter)),
      catchError(this.handleError('getTotalNumberEvaluationScoringParameters', []))
    );
  }

  /* -----------------------------------Get Parameter Lists--------------------------- */
  getParameters(type): Observable<any> {
    const url = `${this.baseURL}kaizenevaluationscoringparameters/GetKaizenEvaluationScoringParametersNames?savingType=${type}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(getParameter => console.log('-------Fetched total Evaluation Scoring Parameters--', getParameter)),
      catchError(this.handleError('getParameters', []))
    );
  }

  /* ------------------Get SubParameter Lists for Evauation Scoring Parameters----------------- */
  getSubParameters(): Observable<any> {
    const url = `${this.baseURL}kaizenevaluationscoringparameters/getkaizenevaluationscoringsubparameters`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(getParameter => console.log('-------Fetched total Evaluation Scoring Parameters--', getParameter)),
      catchError(this.handleError('getParameters', []))
    );
  }

  /* ------------------------------Add Evaluation Scoring Parameters----------------------- */
  addEvaluationScoringParameters(addEvaluationScoringParameterData: any): Observable<any> {
    console.log('--------Add EValuation Scoring Parameters ---------', addEvaluationScoringParameterData);
    const url = `${this.baseURL}KaizenEvaluationScoringParameters/CreateKaizenEvaluationScoringParameters`;
    return this.http.post<any>(url, addEvaluationScoringParameterData, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((sectionNames: any) => console.log(`--------Add EValuation Scoring Parameter names with `)),
      catchError(this.handleError<any>('addEvaluationScoringParameters'))
    );
  }
  /* -------------------------------Evaluation Scoring parameter by id----------- */
  getEvaluationScoringParameterById(id): Observable<any> {

    const url = `${this.baseURL}kaizenevaluationscoringparameters/GetKaizenEvaluationScoringParametersById/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(evaluationId => console.log('-----Fetched all Evaluation Scoring Parameter  By Id------', evaluationId)),
      catchError(this.handleError('getEvaluationScoringParameterById', []))
    );
  }


  /* ------------------------------------Update EValuation Scoring Parameters-------------------- */
  updateEvaluationScoringParameters(evaluationParameters): Observable<any> {
    const url = `${this.baseURL}KaizenEvaluationScoringParameters/UpdateKaizenEvaluationScoringParameters`;
    return this.http.put<any>(url, JSON.stringify(evaluationParameters), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Updated EValuation Scoring Parameters Category----------------`)),
      catchError(this.handleError<any>('updateEvaluationScoringParameters'))
    );
  }

  getRpmMappingByRole(id) {
    const url = `${this.baseURL}RpmMapping/GetRpmMappingForRole/${id}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(_ => console.log(`--------Updated EValuation Scoring Parameters Category----------------`)),
      catchError(this.handleError<any>('updateEvaluationScoringParameters'))
    );
  }

  updateMapping(data, id) {
    const url = `${this.baseURL}Rpmmapping/UpdateRpmMapping/${id}`;
    return this.http.put<any>(url, data).pipe(
      tap(_ => console.log(`--------Updated EValuation Scoring Parameters Category----------------`)),
      catchError(this.handleError<any>('updateEvaluationScoringParameters'))
    );
  }



  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  /* ------------------------------------QCDIP Screen-------------------- */
  getQCDIPParameters(paginationDetails: any, unitid, teamid) {
    const url = `${this.baseURLQCDIP}GetQCDIPParameters/${unitid}/${teamid}/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(getqcdip => console.log('-----Fetched all QCDIP Parameter------', getqcdip)),
        catchError(this.handleError('getQCDIP', []))
      );
  }

  getAllQCDIPData(unitid, teamid) {
    const url = `${this.baseURLQCDIP}GetQCDIPParameters/${unitid}/${teamid}/-1/-1`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(getqcdip => console.log('-----Fetched all QCDIP Parameter------', getqcdip)),
        catchError(this.handleError('getQCDIP', []))
      );
  }

  getTeam(unitid) {
    const url = `${this.baseURL}team/getTeamByUnit/${unitid}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(getqcdip => console.log('-----Fetched all team------', getqcdip)),
        catchError(this.handleError('getTeam', []))
      );
  }

  getQCDIPParametersMaster(paginationDetails: any) {
    const url = `${this.baseURLQCDIP}GetAllQCDIPMasterParameters/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(getqcdip => console.log('-----Fetched all QCDIP Parameter------', getqcdip)),
        catchError(this.handleError('getQCDIP', []))
      );
  }
  deleteQCDIPParametersById(rowId: any) {
    const url = `${this.baseURLQCDIP}DeleteQCDIPParametersById/${rowId}`;
    return this.http.delete<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(deletedRow => console.log('-----DeletedRow------', deletedRow)),
        catchError(this.handleError('deletedRow', []))
      );
  }
  createQCDIPParameter(data) {
    console.log('--------Create QCDIPParameter ---------');
    const url = `${this.baseURLQCDIP}CreateQCDIPParameter`;
    return this.http.post<any>(url, data, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((createQCDIP: any) => console.log(`--------Add CreateQCDIPParameter `, createQCDIP)),
      catchError(this.handleError<any>('CreateQCDIPParameter'))
    );
  }

  SubmitQCDIPMasterParameter(data) {
    const url = `${this.baseURLQCDIP}SubmitQCDIPMasterParameter`;
    return this.http.put(url, data, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(_ => console.log(`--------Updated QCDIP----------------`)),
      catchError(this.handleError<any>('updateQCDIP'))
    );
  }

  createQCDIPParameterMaster(data) {
    console.log('--------Create QCDIPParameter ---------');
    const url = `${this.baseURLQCDIP}CreateQCDIPMasterParameter`;
    return this.http.post<any>(url, data, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((createQCDIP: any) => console.log(`--------Add CreateQCDIPMasterParameter `, createQCDIP)),
      catchError(this.handleError<any>('CreateQCDIPMasterParameter'))
    );
  }

  getQCDIPParametersById(id) {
    const url = `${this.baseURLQCDIP}GetQCDIPParametersById/${id}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(getqcdip => console.log('-----getQCDIPParametersById------', getqcdip)),
        catchError(this.handleError('getQCDIPParametersById', []))
      );
  }
  getQCDIPParametersByIdMaster(id) {
    const url = `${this.baseURLQCDIP}GetQCDIPMasterParametersById/${id}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(getqcdip => console.log('-----getQCDIPParametersById------', getqcdip)),
        catchError(this.handleError('getQCDIPParametersById', []))
      );
  }

  updateQCDIPParameter(updateData) {
    const url = `${this.baseURLQCDIP}UpdateQCDIPParameter`;
    return this.http.put(url, updateData, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(_ => console.log(`--------Updated QCDIP----------------`)),
      catchError(this.handleError<any>('updateQCDIP'))
    );
  }

  updateQCDIPParameterMaster(updateData) {
    const url = `${this.baseURLQCDIP}UpdateQCDIPMasterParameter`;
    return this.http.put(url, updateData, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap(_ => console.log(`--------Updated QCDIP----------------`)),
      catchError(this.handleError<any>('updateQCDIP'))
    );
  }

  getAllQCDIPParameterCount(unitid, teamid): Observable<any> {
    const url = `${this.baseURLQCDIP}GetAllQCDIPParameterCount/${unitid}/${teamid}`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all QCDIP count----')),
      catchError(this.handleError<any>('-----Get all QCDIP count----'))
    );
  }
  getAllQCDIPParameterCountMaster(): Observable<any> {
    const url = `${this.baseURLQCDIP}GetAllQCDIPMasterParameterCount`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get all QCDIP count----')),
      catchError(this.handleError<any>('-----Get all QCDIP count----'))
    );
  }

  getQCDIPUOM(): Observable<any> {
    const url = `${this.baseURLQCDIP}GetQCDIPUOM`;
    return this.http.get<any>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      tap((res: any) => console.log('-----Get GetQCDIPUOM----')),
      catchError(this.handleError<any>('-----Get GetQCDIPUOM----'))
    );
  }

  uploadParameterList(data) {
    // const headers = new HttpHeaders();
    // headers.set('Accept', 'application/json');
    // headers.delete('Content-Type'); // mandate for accepting binary content
    //{ headers: headers }
    const url = `${this.baseURLQCDIP}UploadParameterList`;
    return this.http.post<any>(url, data, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(catchError(this.handleError));
  }

  submitQCDIPParameter(data) {
    const url = `${this.baseURLQCDIP}SubmitQCDIPParameter`;
    return this.http.put<any>(url, data, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(catchError(this.handleError));
  }

  get(url): Observable<any> {
    let baseUrl = '';
    baseUrl = environment.adminUrl;
    const appUrl = `${baseUrl}${url}`;
    return this.http.get<any>(appUrl, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    });
    // .pipe(catchError(this.handleError));
  }

  put(url, data): Observable<any> {
    let baseUrl = '';
    baseUrl = environment.adminUrl;
    const appUrl = `${baseUrl}${url}`;
    return this.http.put(appUrl, data, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    }).pipe(
      catchError(this.handleError<any>('Update Kaizen'))
    );
  }

  post(url, data): Observable<any> {
    let baseUrl = '';
    baseUrl = environment.adminUrl;
    const appUrl = `${baseUrl}${url}`;
    return this.http.post<any>(appUrl, data, httpOptions);
    // .pipe(catchError(this.handleError));
  }

  teamActivitiesPost(url, data): Observable<any> {
    let baseUrl = '';
    baseUrl = environment.kaizenUrl;
    const appUrl = `${baseUrl}${url}`;
    return this.http.post<any>(appUrl, data, httpOptions);
    // .pipe(catchError(this.handleError));
  }

  getWithParam(url, params): Observable<any> {
    let baseUrl = '';
    baseUrl = environment.adminUrl;
    const appUrl = `${baseUrl}${url}=${params}`;
    return this.http.get<any>(appUrl, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    });
  }
  getAllSlaData(paginationDetails, type, role, typeId) {
    let baseUrl = '';
    baseUrl = environment.slaurl;
    const url = `${baseUrl}/GetAllSLAServices/${paginationDetails.pageNumber}/${paginationDetails.pageSize}?type=${type}&role=${role}&typeid=${typeId}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(departments => console.log('-----Fetched all Sla------', departments)),
        catchError(this.handleError('Sla', []))
      );
  }
  getUom() {
    let baseUrl = '';
    baseUrl = environment.slaurl;
    const url = `${baseUrl}/GetUOMList/`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(departments => console.log('-----Fetched all Sla------', departments)),
        catchError(this.handleError('Get UOM data', []))
      );

  }
  addService(data, type) {
    let baseUrl = '';
    // let team= 'team'
    baseUrl = environment.slaurl;
    const appUrl = `${baseUrl}/CreateSLAService?type=${type}`;
    return this.http.post<any>(appUrl, data, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    });
  }

  submitSelectedSla(submissionList) {
    // debugger;
    let baseUrl = environment.slaurl;

    const url = `${baseUrl}/SubmitSLAService`;
    return this.http.put(url, JSON.stringify(submissionList), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Submit List----------------`)),
      catchError(this.handleError<any>('Submit List'))
    );
  }
  UpdateSLa(updateSla) {
    let baseUrl = environment.slaurl;

    const url = `${baseUrl}/UpdateSLAService`;
    return this.http.put(url, JSON.stringify(updateSla), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Update List----------------`)),
      catchError(this.handleError<any>('Update List'))
    );
  }
  getSlaCount(type, typeId) {
    let baseUrl = '';
    baseUrl = environment.slaurl;
    const url = `${baseUrl}/GetAllSLAServiceCount?type=${type}&typeid=${typeId}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(departments => console.log('-----Fetched all Sla------', departments)),
        catchError(this.handleError('Sla', []))
      );
  }
  addSlatoTeamActivity(data) {
    let baseUrl = environment.SLA;
    const appUrl = `${baseUrl}/CreateSLA`;
    return this.http.post<any>(appUrl, data, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    });
  }
  getAllBehaviorSla(paginationDetails) {
    let baseUrl = '';
    baseUrl = environment.slaurl;
    const url = `${baseUrl}/GetAllSLABehaviours/${paginationDetails.pageNumber}/${paginationDetails.pageSize}`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(departments => console.log('-----Fetched all Sla------', departments)),
        catchError(this.handleError('Sla', []))
      );

  }
  getAllBehaviorSlaCount() {

    let baseUrl = '';
    baseUrl = environment.slaurl;
    const url = `${baseUrl}/GetAllSLABehavioursCount`;
    return this.http.get<any[]>(url, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`)
    })
      .pipe(
        tap(departments => console.log('-----Fetched all Sla------', departments)),
        catchError(this.handleError('Sla', []))
      );
  }

  upsateBehavioralService(updateSla) {
    let baseUrl = environment.slaurl;

    const url = `${baseUrl}/UpdateSLABehavior`;
    return this.http.put(url, JSON.stringify(updateSla), {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Update List----------------`)),
      catchError(this.handleError<any>('Update List'))
    );
  }
  addServiceBe(data) {
    let baseUrl = '';
    // let team= 'team'
    baseUrl = environment.slaurl;
    const appUrl = `${baseUrl}/CreateSLABehavior`;
    return this.http.post<any>(appUrl, data, {
      headers: this.headers.set('unitId', `${'' + sessionStorage.getItem('unitId')}`).set('Content-Type', 'application/json')
    }).pipe(
      tap(_ => console.log(`--------Update List----------------`)),
      catchError(this.handleError<any>('Update List'))
    );;
  }

  fileUploadPost(url, fileUploadPayload) {
    let baseUrl = "";
    baseUrl = environment.adminUrl;
    const appUrl = `${baseUrl}${url}`;
    console.log("appUrl", appUrl);
    return this.http
      .post<any>(appUrl, fileUploadPayload)
      .pipe(catchError(this.handleError));
  }

  public requestDataFromMultipleSources(): Observable<any[]> {
    // let baseUrl = '';
    // baseUrl = environment.adminUrl;
    // let response1 = this.http.get(`${baseUrl}${requestUrl1}`);
    // let response2 = this.http.get(`${baseUrl}${requestUrl2}`);
    // let response3 = this.http.get(`${baseUrl}${requestUrl3}`);
    // let response4 = this.http.get(`${baseUrl}${requestUrl4}`);
    // let response5 = this.http.get(`${baseUrl}${requestUrl5}`);
    // let response6 = this.http.get(`${baseUrl}${requestUrl6}`);
    // let response7 = this.http.get(`${baseUrl}${requestUrl7}`);
    // let response8 = this.http.get(`${baseUrl}${requestUrl8}`);
    // Observable.forkJoin (RxJS 5) changes to just forkJoin() in RxJS 6
    return forkJoin([this.getEmployees({ pageNumber: 0, pageSize: 5 }), this.getEmployeeTotalCount(), this.getEmployeeUnitField(), this.getPositionOfEmployee(), this.getRoleOfEmployee(),
    this.getEmployeeCategoryOfEmployee(), this.getEmployeeNames(), this.getProficiencyLevels()]);
  }
}
