import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DepartmentnamesComponent } from './departmentnames.component';

describe('DepartmentnamesComponent', () => {
  let component: DepartmentnamesComponent;
  let fixture: ComponentFixture<DepartmentnamesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DepartmentnamesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DepartmentnamesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
