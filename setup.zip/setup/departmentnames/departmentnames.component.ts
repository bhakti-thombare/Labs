import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-departmentnames',
  templateUrl: './departmentnames.component.html',
  styleUrls: ['./departmentnames.component.css']
})
export class DepartmentnamesComponent implements OnInit {

  constructor(private fb: FormBuilder, private setupService: SetupService,
    private messageService: MessageService) { }
  cols: any = [];
  submitted: Boolean;
  // status:Boolean=false;
  paginationDetails: any;
  totalMasterDepartmentNames: any;
  updateMasterDepartmentNameById: any;
  departmentnames: any = [];
  addDepartmentNamesForm: FormGroup;
  updateDepartmentNamesForm: FormGroup;
  displayAddDepartmentNamesDialog: Boolean;
  isPowerUser = false;
  displayUpdateDepartmentNamesDialog: Boolean;
  ngOnInit() {
    this.getUserRole();
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5,
    }
    this.getTotalMasterDepartmentNamesCount();
    this.getDepartmentNamesColumns();
    this.getMasterDepartmentNames(this.paginationDetails);
    this.initializeAddDepartmentNames();
    this.initializeUpdateDepartmentNames();
  }
  initializeAddDepartmentNames() {
    this.addDepartmentNamesForm = this.fb.group({
      departmentName: ['', Validators.required],
      status: [true, Validators.required],
    });
  }
  getUserRole() {
    let userRole = sessionStorage.getItem('userRole');
    if (userRole == 'Power User') {
      this.isPowerUser = true;
    }
    this.getDepartmentNamesColumns();

  }
  initializeUpdateDepartmentNames() {
    this.updateDepartmentNamesForm = this.fb.group({
      departmentName: ['', Validators.required],
      status: [null, Validators.required],

    });
  }

  onDepartmentNamesPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    console.log('----Paginnation Details------', this.paginationDetails);
    this.getMasterDepartmentNames(this.paginationDetails);
  }

  /* ------------------------------------------------------Add Name Master Department Names---------- */
  addMasterDepartmentNames() {
    this.submitted = true;
    if (this.addDepartmentNamesForm.invalid) {
      return this.addDepartmentNamesForm.value.actionPerformed = null;

    } else {
      let addDepartmentNameData = this.addDepartmentNamesForm.value;
      this.setupService.addMasterDepartmentNames(addDepartmentNameData).subscribe((res: any[]) => {
        this.displayAddDepartmentNamesDialog = false;
        this.getTotalMasterDepartmentNamesCount();
        this.getMasterDepartmentNames(this.paginationDetails);
        console.log('Add Department Names Successfully')
        this.messageService.add({ severity: 'success', summary: `Department`, detail: 'added Successfully' });
      }, err => {
        console.log('Error occured in add Department:', err);
      });
    }
  }

  /* ------------------------------------------------Update Master Department Names --------------------------------------*/
  updateMasterDepartmentNames(masterDepartmentName) {
    this.submitted = true;
    if (this.updateDepartmentNamesForm.invalid) {
      this.updateDepartmentNamesForm.value.actionPerformed = null;
      return;
    } else {
      this.updateDepartmentNamesForm.value.actionPerformed = 'Submit';
      let departmentNamesData = this.updateDepartmentNamesForm.value;
      departmentNamesData.id = masterDepartmentName.id;
      this.setupService.updateMasterDepartmentNames(departmentNamesData).subscribe((res: any[]) => {
        this.displayUpdateDepartmentNamesDialog = false;
        this.getTotalMasterDepartmentNamesCount();
        this.getMasterDepartmentNames(this.paginationDetails);
        console.log('Department  Names Updated Successfully');
        this.messageService.add({ severity: 'success', summary: `Department`, detail: 'updated Successfully' });
      }, err => {
        console.log('Error occured in update Department Names:', err);
      })
    }
  }

  get formFields() { return this.addDepartmentNamesForm.controls; }

  get editFormFields() { return this.updateDepartmentNamesForm.controls; }

  getDepartmentNamesColumns() {
    if (sessionStorage.getItem('userRole') != 'Power User') {
      this.cols = [
        { field: 'departmentName', header: 'Department Name' },
        { field: 'action', header: 'Actions' },
        { field: 'status', header: 'Status' }

      ]
    } else {
      this.cols = [
        { field: 'departmentName', header: 'Department Name' },

        { field: 'status', header: 'Status' }

      ]
    }
  }
  /* ---------------------------------------Get Master Department Names--------------------------------------------- */
  getMasterDepartmentNames(paginationDetails) {
    this.setupService.getMasterDepartmentNames(paginationDetails).subscribe((res: any[]) => {
      this.departmentnames = res;
    }, err => {
      console.log("Error occured in get department names:", err);
    })
  }

  /* -----------------------------get Total Master Department Names ----------------------------------*/
  getTotalMasterDepartmentNamesCount() {
    this.setupService.getTotalMasterDepartmentNamesCount().subscribe((data) => {
      this.totalMasterDepartmentNames = data
      console.log("--------------Total Department Names Count-----", this.totalMasterDepartmentNames);
    }, err => {

    })
  }

  /* ---------------------------------get Master Department Names by Id-------------------------------------- */
  getMasterDepartmentNameById(id) {
    this.setupService.getMasterDepartmentNameById(id).subscribe((res: any) => {
      this.updateMasterDepartmentNameById = res;
      console.log("-----------Id of Department Names", this.updateMasterDepartmentNameById);
    }, err => {

    })
  }

  cancelAddDepartmentNamesDialog() {
    this.displayAddDepartmentNamesDialog = false;
    this.addDepartmentNamesForm.controls['departmentName'].reset();
  }

  cancelUpdateDepartmentNamesDialog() {
    this.displayUpdateDepartmentNamesDialog = false;
    this.updateDepartmentNamesForm.controls['departmentName'].reset();
  }

  showAddDepartmentNamesDialog() {
    this.displayAddDepartmentNamesDialog = true;
    //this.addDepartmentNamesForm.reset();
    this.submitted = false;
    //  this.status=false;
  }

  showUpdateDepartmentNamesDialog(id: any) {
    this.submitted = false;
    this.getMasterDepartmentNameById(id);
    this.displayUpdateDepartmentNamesDialog = true;
  }
}
