import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { SetupService } from '../setup.service';
import * as _ from 'lodash';
import { UserinfoService } from 'src/app/configuration/userinfo.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';


@Component({
  selector: 'app-sections',
  templateUrl: './sections.component.html',
  styleUrls: ['./sections.component.css']
})
export class SectionsComponent implements OnInit {
  teamMembersList: any = [];
  editTeamMembersList: any = [];
  shLevelDropDown: any = [];
  cols: any = [];
  dropdowns: any[];
  updatedHeadSel = [];
  selectedSectionHeads: [];
  sections: any = [];
  // status: Boolean = false;
  totalSections: any[];
  submitted = false;
  paginationDetails: any;
  SectionsNames = [];
  teamNames = [];
  selectedIds = [];
  uniqList = [];
  updateSectionData: any;
  departmentNames = [];
  displayAddSectionDialog: Boolean;
  displayUpdateSectionDialog: Boolean;
  addSectionForm: FormGroup;
  // shLists: any=[];
  updateSectionForm: FormGroup;
  update = false;
  dropdownSettings = {};
  dropdownSettingsTeam = {};
  dropdownSettingsName = {};
  dropdownSettingsDept = {};
  loading = true;
  sectionLoading = false;
  teamLoading = false;
  nameLoading = false;
  departmentLoading = false;
  shloading = false;
  searchForm: FormGroup;
  searchSection: boolean;
  alreadyCreated: boolean;

  constructor(private fb: FormBuilder, private setupService: SetupService,
    private userInfo: UserinfoService, private msAdalService: MsAdalAngular6Service, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm = this.fb.group({
      userName: ['', Validators.required]
    });
    this.getSectionColumns();
    this.getSection(this.paginationDetails);
    this.initializeAddSectionForm();
    this.initializeUpdateSectionForm();
    this.getSectionTeamNames();
    this.getSectionsNames();
    this.getTotalNumberOfSection();
    this.getSectionDepartmentNames();
    this.getShList();
    this.dropSettings();
    // const userId = this.msAdalService.userInfo.userName.split('@')[0];
    // this.getUserInfo(userId);
  }

  dropSettings() {
    this.dropdownSettings = {
      singleSelection: false,
      text: 'Choose Section head',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsTeam = {
      singleSelection: true,
      text: 'Choose Team',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsName = {
      singleSelection: true,
      text: 'Choose Section Name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsDept = {
      singleSelection: true,
      text: 'Choose Department',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };
  }

  initializeAddSectionForm() {
    this.addSectionForm = this.fb.group({
      sectionNameTitle: [null, Validators.required],
      departmentid: [null, Validators.required],
      teamid: [null, Validators.required],
      sh: [null, Validators.required],
      status: [true],
      // shLists: this.fb.array([]),


    });
  }

  search() {
    this.searchSection = true;
    this.setupService.get(`Admin/SearchFromName/${this.paginationDetails.pageNumber}/${this.paginationDetails.pageSize}?queryString=${this.searchForm.value.userName}&searchFor=section`)
      .subscribe(res => {
        console.log(res);
        this.totalSections = res.item1;
        this.sections = res.item2;
      });
  }

  reset() {
    this.searchSection = false;
    const pagination = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm.reset();
    this.getTotalNumberOfSection();
    this.getSection(pagination);
  }
  onSectionPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    if (this.searchSection) {
      this.search();
    } else {
      console.log('------Pagination Details After Page Change-----', this.paginationDetails);
      this.getSection(this.paginationDetails);
    }
    console.log('pagination Details After Page Change', this.paginationDetails);
    this.getSection(this.paginationDetails);

  }

  /*  onStatusChange(value) {
     this.status = value;
   } */

  get formFields() { return this.addSectionForm.controls; }

  get editFormFields() { return this.updateSectionForm.controls; }


  /* update */
  initializeUpdateSectionForm() {
    this.updateSectionForm = this.fb.group({
      sectionNameTitle: [null, Validators.required],
      department: [null, Validators.required],
      team: [null, Validators.required],
      sh: [null, Validators.required],
      status: [null],

      // shLists: this.fb.array([]),
      // shName: [null, Validators.required]
    });
  }

  getUserInfo(userId) {
    this.setupService
      .getWithParam('RpmMapping/GetRpmMappingForEmployee/username', userId)
      .subscribe((res: any) => {
        console.log('res', res);
        // this.kaizenService.storeUnitId(res.item2.unitId);
        this.userInfo.roleName = res.item1;
        this.userInfo.userData = res.item2;
        // this.loggedInData = res.item2;
        // this.GetRoleBasedData();
        console.log(this.userInfo.userData.unitId);
      }, (err) => {
        console.log('err', err);
      });
  }





  /*----------------------------------------------- Add Section -------------------------------------------------*/
  addSection() {
    this.submitted = true;
    this.loading = true;
    console.log('this.addSectionForm.value', this.addSectionForm.value);
    if (this.addSectionForm.invalid) {
      this.loading = false;
      return this.addSectionForm.value.actionPerform = 'null';
    } else {
      if (this.update) {
        const sectionData = this.addSectionForm.value;
        sectionData.id = this.updateSectionData.id;
        const shSelected = this.addSectionForm.controls.sh.value;
        const idArr = [];
        for (let i = 0; i < shSelected.length; i++) {
          idArr[i] = '' + shSelected[i].id;
        }
        sectionData.sh = idArr;
        sectionData.sectionNameTitle = sectionData.sectionNameTitle[0].itemName;
        sectionData.teamid = '' + sectionData.teamid[0].id;
        sectionData.departmentid = '' + sectionData.departmentid[0].id;
        sectionData.unitId = '' + sessionStorage.getItem('unitId');
        // sectionData.status = this.status;
        this.setupService.updateSection(sectionData).subscribe((res: any[]) => {
          this.displayAddSectionDialog = false;
          this.update = false;
          this.submitted = false;
          // this.status = false;
          this.getTotalNumberOfSection();
          this.getSection(this.paginationDetails);
          console.log('Section Updated Successfully');
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `Section`, detail: 'updated Successfully'});
        }, err => {
          this.loading = false;
          console.log('Error occured in section department:', err);
        });
      } else {
        const sectionData = this.addSectionForm.value;
        console.log('---sectionData----', sectionData);
        const shSelected = this.addSectionForm.controls.sh.value;

        // sectionData.status = this.status;
        // sectionData.sh=this.teamMembersList;
        /*  const sectionHeadArray=sectionData.sh;
         sectionData.sh=sectionHeadArray.map(value=>value.userName)
         sectionData.shEmailId=sectionHeadArray.map(value=>value.emailId)
       */
        const idArr = [];
        // functionData.functionHead = functionHeadArray.map(value => value.id);
        for (let i = 0; i < shSelected.length; i++) {
          idArr[i] = '' + shSelected[i].id;
        }
        sectionData.sh = idArr;
        sectionData.sectionNameTitle = sectionData.sectionNameTitle[0].itemName;
        sectionData.teamid = '' + sectionData.teamid[0].id;
        sectionData.departmentid = '' + sectionData.departmentid[0].id;
        sectionData.unitId = '' + sessionStorage.getItem('unitId');
        this.setupService.addSection(sectionData).subscribe((res: any[]) => {

          // this.status = false;
          this.getSection(this.paginationDetails);
          this.getTotalNumberOfSection();

          this.displayAddSectionDialog = false;
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `Section`, detail: 'added Successfully'});
          console.log('Section Saved Successfulluy');
        }, err => {
          this.loading = false;
          console.log('Error occured in add Section:', err);
        });
      }
    }
  }

  /* ---------------------------------Get Section By Id-------------------------------- */
  getSectionById(id) {
    this.setupService.getSectionById(id).subscribe((res: any) => {
      console.log('res', res);

      this.updateSectionData = res;
      this.addSectionForm.patchValue(res);
      const sh = res.sh;
      const selectedSh = [];
      console.log(sh);

      for (let i = 0; i < sh.length; i++) {
        const index = _.findIndex(this.shLevelDropDown, (d) => d['itemName'] === sh[i]);
        console.log(index);
        if (index != -1) {
          selectedSh.push(this.shLevelDropDown[index]);
        }
      }

      const selectedName = [];
      const selectedTeam = [];
      const selectedDept = [];


      const indexName = _.findIndex(this.SectionsNames, (d) => d['itemName'] === this.updateSectionData.sectionNameTitle);
      console.log(indexName);
      if (indexName != -1) {
        selectedName.push(this.SectionsNames[indexName]);
      }

      const indexDept = _.findIndex(this.departmentNames, (d) => d['id'] == this.updateSectionData.departmentId);
      console.log(indexDept);
      if (indexDept != -1) {
        selectedDept.push(this.departmentNames[indexDept]);
      }

      const indexTeam = _.findIndex(this.teamNames, (d) => d['id'] == this.updateSectionData.teamId);
      console.log(indexTeam);
      if (indexTeam != -1) {
        selectedTeam.push(this.teamNames[indexTeam]);
      }

      this.addSectionForm.patchValue({
        sh: selectedSh,
        departmentid: selectedDept,
        teamid: selectedTeam,
        sectionNameTitle: selectedName
      });
    }, err => {
      console.log('error occured in update Section', err);
    });

  }
  /* ------------------------------------------------------Update Section ---------------------------------------*/
  updateSection(section) {
    this.submitted = true;
    if (this.updateSectionForm.invalid) {
      return this.updateSectionForm.value.actionPerform = 'null';
    } else {
      const sectionData = this.updateSectionForm.value;
      sectionData.id = section.id;
      const idArr = [];
      for (let i = 0; i < this.updatedHeadSel.length; i++) {
        idArr[i] = '' + this.updatedHeadSel[i];
      }
      sectionData.sh = idArr;
      // sectionData.status = this.status;
      this.setupService.updateSection(sectionData).subscribe((res: any[]) => {
        this.displayAddSectionDialog = false;
        this.update = false;
        // this.status = false;
        this.getTotalNumberOfSection();
        this.getSection(this.paginationDetails);
        console.log('Section Updated Successfully');
      }, err => {
        console.log('Error occured in section department:', err);
      });
    }
  }




  getSectionColumns() {
    this.cols = [
      { field: 'id', header: 'ID' },
      { field: 'sectionNameTitle', header: 'Section Name' },
      { field: 'shName', header: 'Section Head' },
      { field: 'department', header: 'Department' },
      { field: 'team', header: 'Team' },
      { field: 'action', header: 'Actions' },
      { field: 'status', header: 'Status' }
    ];
  }
  /* -------------------------------------------Get Section--------------------------------------------------- */
  getSection(paginationDetails) {
    this.sectionLoading = true;
    this.setupService.getSections(paginationDetails).subscribe((res: any[]) => {
      this.sections = res;
      this.sectionLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in get sections:', err);
      this.sectionLoading = false;
      this.loadOninit();
    });
  }

  OnSectionNameSelect(e) {
    console.log(e);
    let sections = [];
    if (!this.update) {
      this.setupService.getSections({pageNumber: -1, pageSize: -1})
      .subscribe(res => {
        console.log(res);
        sections = res;
      console.log(sections);
      const index = _.findIndex(sections, (d) => d['sectionNameTitle'] === e.id);
      console.log('index', index);

      if (index != -1) {
        this.setupService.getSectionById(sections[index].id)
          .subscribe(res => {
            console.log(res);
            if (res['status'] == true) {
              this.alreadyCreated = true;
            } else {
              this.alreadyCreated = false;
            }
          });
      }
    });
    }
  }


  /* -------------------------------------Get Total No of Sections Count--------------------------------------- */
  getTotalNumberOfSection() {
    this.setupService.getTotalNumberOfSection().subscribe((data) => {
      this.totalSections = data;
      console.log('total sections', this.totalSections);
    });
  }

  /* -------------------------------------section Names------------------------------ */
  getSectionsNames() {
    this.nameLoading = true;
    this.setupService.getSectionsNames().subscribe((res: any) => {
      // this.SectionsNames = res;

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index], id: res[index] });
      }

      console.log('newData', newData);
      this.SectionsNames = this.SectionsNames.concat(newData);
      console.log('--------------Section NAmes-------', this.SectionsNames);
      this.nameLoading = false;
      this.loadOninit();
    }, err => {
      this.nameLoading = false;
      this.loadOninit();
    });
  }
  /* ----------------------------------Department Names--------------------------------- */
  getSectionDepartmentNames() {
    this.departmentLoading = true;
    this.setupService.getDepartmentNameId().subscribe((res: any) => {
      // this.departmentNames = res;

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index].departmentName, id: res[index].id });
      }

      console.log('newData', newData);
      this.departmentNames = this.departmentNames.concat(newData);
      console.log('------------------Department Names---------', this.departmentNames);
      this.departmentLoading = false;
      this.loadOninit();
    }, err => {
      this.departmentLoading = false;
      this.loadOninit();
    });
  }

  /* ------------------------------------Team Names----------------------------------------- */
  getSectionTeamNames() {
    this.teamLoading = true;
    this.setupService.getTeamNameId().subscribe((res: any) => {
      // this.teamNames = res;

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index].teamName, id: res[index].id });
      }

      console.log('newData', newData);
      this.teamNames = this.teamNames.concat(newData);
      console.log('------------------Section Names---------', this.teamNames);
      this.teamLoading = false;
      this.loadOninit();
    }, err => {
      this.teamLoading = false;
      this.loadOninit();
    });
  }

  /* ---------------------------------------SH----------------------------------------------------------------- */
  getShList() {
    this.shloading = true;
    this.setupService.getShList().subscribe((res: any[]) => {
      console.log('res', res);
      this.dropdowns = res;
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({ itemName: element.userName, id: element.id });
        }
      }

      this.shLevelDropDown = this.shLevelDropDown.concat(newData);
      this.shloading = false;
      this.loadOninit();
    }, err => {
      console.log('-----------error ocuured in get Sh Lists-', err);
      this.shloading = false;
      this.loadOninit();
    });
  }


  /*  onSelectSH(shlist: any, isChecked: Boolean) {
     const teamMembersArray = <FormArray>this.addSectionForm.controls.shLists;
     let teamMembersEmailIdList: any = [];
     if (isChecked) {
       teamMembersArray.push(new FormControl(shlist.emailId));
       teamMembersEmailIdList.push(shlist.emailId);
       this.shLists.filter(res =>
         shlist.userName == res.userName);
       this.teamMembersList.push(shlist.userName);
     } else {
       let index = teamMembersArray.controls.findIndex(x => x.value == shlist)
       teamMembersArray.removeAt(index);
       this.teamMembersList.splice(this.teamMembersList.indexOf(shlist.userName), 1);
       console.log('----- this.teamMembersList---', this.teamMembersList);
     }
   } */

  /* ----------------------------------------Edit SH------------------------------------------ */
  /* onSelectEditSH(shlist: any, isChecked: boolean) {
    const editTeamMembersArray = <FormArray>this.updateSectionForm.controls.shLists;
    let editTeamMembersEmailIdList: any = [];
    if (isChecked) {
      editTeamMembersArray.push(new FormControl(shlist.emailId));

      editTeamMembersEmailIdList.push(shlist.emailId);
      this.shLists.filter(res =>
        shlist.userName == res.userName);
      this.editTeamMembersList.push(shlist.userName);
    } else {
      let index = editTeamMembersArray.controls.findIndex(x => x.value == shlist)
      editTeamMembersArray.removeAt(index);
      this.editTeamMembersList.splice(this.editTeamMembersList.indexOf(shlist.userName), 1);
      console.log('----- this.editTeamMembersList---', this.editTeamMembersList);

    }
  } */







  cancelAddSectionDialog() {
    this.displayAddSectionDialog = false;
    this.addSectionForm.reset();
    // this.status = false;
    this.submitted = false;
    this.update = false;
    this.alreadyCreated = false;
  }

  showAddSectionDialog() {
    this.displayAddSectionDialog = true;
    // this.status = false;
    this.submitted = false;
    this.initializeAddSectionForm();
    //  this.addSectionForm.reset();

  }

  cancelUpdateSectionDialog() {
    this.displayAddSectionDialog = false;
    this.updateSectionForm.reset();
    this.update = false;

  }

  showUpdateSectionDialog(id: any) {
    this.getSectionById(id);
    this.updateSectionForm.reset();
    this.displayAddSectionDialog = true;
    this.update = true;
  }
  select(e) {
    console.log(e);
    this.selectedIds = e.value;
  }
  updateSelect(e) {
    console.log(e);
    this.updatedHeadSel.push(e.itemValue);
    console.log(this.updatedHeadSel);
  }

  loadOninit() {
  if (!this.sectionLoading && !this.teamLoading && !this.nameLoading && !this.departmentLoading && !this.shloading) {
    this.loading = false;
  }
  }

  exportAsXLSX() {
    if (this.sections.length > 0) {
      this.excelService.exportAsExcelFile(this.sections, 'sample');
    }
  }
}
