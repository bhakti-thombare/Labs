import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImprovementareaComponent } from './improvementarea.component';

describe('ImprovementareaComponent', () => {
  let component: ImprovementareaComponent;
  let fixture: ComponentFixture<ImprovementareaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ImprovementareaComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImprovementareaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
