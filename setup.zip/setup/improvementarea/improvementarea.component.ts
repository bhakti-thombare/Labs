import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';

@Component({
  selector: 'app-improvementarea',
  templateUrl: './improvementarea.component.html',
  styleUrls: ['./improvementarea.component.css']
})
export class ImprovementareaComponent implements OnInit {
  cols: any = [];
  status: Boolean = false;
  improvementareas: any = [];
  paginationDetails: any;
  submitted: Boolean = false;
  totalImprovementAreas: any[];
  addImprovementAreaForm: FormGroup;
  updateImprovementAreaForm: FormGroup;
  updateImprovementAreaById: any;
  displayAddImprovementAreaDialog: Boolean;
  displayUpdateImprovementAreaDialog: Boolean;
  update = false;
  loading = true;
  isPowerUser : boolean=false;
  constructor(private fb: FormBuilder, private setupService: SetupService, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {
    this.getUserRole()
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5,
    };
    this.getImprovementArea(this.paginationDetails);
    this.initializeAddImprovementAreaForm();
    this.initializeUpdateImprovementAreaForm();
    this.getTotalImprovementAreaCount();
  }

  getUserRole(){
    let userRole= sessionStorage.getItem('userRole');
    if(userRole=="Power User"){
      this.isPowerUser=true;
    }
    this.getImprovementAreaColumns();

  }
  initializeAddImprovementAreaForm() {
    this.addImprovementAreaForm = this.fb.group({
      area: ['', Validators.required],
    });
  }

  initializeUpdateImprovementAreaForm() {
    this.updateImprovementAreaForm = this.fb.group({
      area: ['', Validators.required],
    });
  }

  get formFields() { return this.addImprovementAreaForm.controls; }


  get editFormFields() { return this.updateImprovementAreaForm.controls; }

  onImprovementAreapageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows,
    };
    console.log('----------pagination details', this.paginationDetails);
    this.getImprovementArea(this.paginationDetails);
  }

  onStatusChange(value) {
    this.status = value;
  }





  // updateImprovementArea(improvementarea) {
  //   this.submitted = true;
  //   if (this.updateImprovementAreaForm.invalid) {
  //     return this.updateImprovementAreaForm.value.actionPerformed = null;
  //   }
  //   else {
  //     let updateImprovementAreaData = this.updateImprovementAreaForm.value;
  //     updateImprovementAreaData.id = improvementarea.id;
  //     updateImprovementAreaData.status = this.status;
  //     this.setupService.updateImprovementArea(updateImprovementAreaData).subscribe((res: any[]) => {
  //       this.updateImprovementAreaForm.value.actionPerformed = 'submit';
  //       this.displayAddImprovementAreaDialog = false;
  //       this.update = false;
  //       this.status = false;
  //       this.getTotalImprovementAreaCount();
  //       this.getImprovementArea(this.paginationDetails);
  //       console.log('Improvement Area Updated Successfulluy');
  //     }, err => {
  //       console.log('Error occured in update Improvement Area:', err);
  //     })
  //   }
  // }


  addImprovementArea() {
    this.submitted = true;
    this.loading = true;
    if (this.addImprovementAreaForm.invalid) {
      this.loading = false;
      return this.addImprovementAreaForm.value.actionPerformed = null;
    } else {
      if (this.update) {
        const updateImprovementAreaData = this.addImprovementAreaForm.value;
        updateImprovementAreaData.id = this.updateImprovementAreaById.id;
        updateImprovementAreaData.status = this.status;
        this.setupService.updateImprovementArea(updateImprovementAreaData).subscribe((res: any[]) => {
          this.updateImprovementAreaForm.value.actionPerformed = 'submit';
          this.displayAddImprovementAreaDialog = false;
          this.update = false;
          this.status = false;
          this.loading = false;
          this.getTotalImprovementAreaCount();
          this.getImprovementArea(this.paginationDetails);
          this.messageService.add({severity: 'success', summary: `Improvment Area`, detail: 'Updated Successfully'});
          console.log('Improvement Area Updated Successfulluy');
        }, err => {
          this.loading = false;
          console.log('Error occured in update Improvement Area:', err);
        });
      } else {
        const improvementAreaData = this.addImprovementAreaForm.value;
        improvementAreaData.status = this.status;
        this.setupService.addImprovementArea(improvementAreaData).subscribe((res: any[]) => {
          this.updateImprovementAreaForm.value.actionPerformed = 'submit';

          this.displayAddImprovementAreaDialog = false;
          this.status = false;
          this.loading = false;
          this.getTotalImprovementAreaCount();
          this.getImprovementArea(this.paginationDetails);
          this.messageService.add({severity: 'success', summary: `Improvement Area`, detail: 'added Successfully'});
          console.log('ImprovementArea added Successfulluy');
        }, err => {
          this.loading = false;
          console.log('Error occured in update ImprovementArea:', err);
        });
      }
    }
  }
  getImprovementAreaColumns() {
    if(sessionStorage.getItem('userRole')!="Power User"){
      this.cols = [
        { field: 'area', header: 'Improvement Area' },
        { field: 'action', header: 'Action' },
        { field: 'status', header: 'Status' },
      ];
    }else{
      this.cols = [
        { field: 'area', header: 'Improvement Area' },
      
        { field: 'status', header: 'Status' },
      ];
    }
   
  }

  getImprovementArea(paginationDetails) {
    this.setupService.getImprovementArea(paginationDetails).subscribe((res: any[]) => {
      this.improvementareas = res;
      this.loading = false;
    }, err => {
      console.log('Error occured in get improvementArea:', err);
      this.loading = false;
    });
  }
  /*  Getv Total Count Of Improvement Area----------- */
  getTotalImprovementAreaCount() {
    this.setupService.getTotalImprovementAreaCount().subscribe((data) => {
      this.totalImprovementAreas = data;
      console.log('--------------Improvement area------', this.totalImprovementAreas);
    }, err => {

    });
  }
  /* ---------------------------------Get Improvement Area by id----------------- */
  getImprovementAreaById(id) {
    this.setupService.getImprovementAreaById(id).subscribe((res: any) => {
      this.updateImprovementAreaById = res;
      this.addImprovementAreaForm.patchValue(res);
      this.status = res.status;
    }, err => {

    });
  }


  showAddImprovementAreaDialog() {
    this.displayAddImprovementAreaDialog = true;
    this.addImprovementAreaForm.reset();
    this.submitted = false;
    this.status = false;
  }

  cancelAddImprovementAreaDialog() {
    this.displayAddImprovementAreaDialog = false;
    this.status = false;
    this.addImprovementAreaForm.reset();
    this.update = false;
  }

  showUpdateImprovementAreaDialog(id: any) {
    this.submitted = false;
    this.getImprovementAreaById(id);
    this.displayAddImprovementAreaDialog = true;
    this.update = true;

  }

  cancelUpdateImprovementAreaDialog() {
    this.displayAddImprovementAreaDialog = false;
    this.updateImprovementAreaForm.reset();
  }

  exportAsXLSX() {
    if (this.improvementareas.length > 0) {
      this.excelService.exportAsExcelFile(this.improvementareas, 'sample');
    }
  }

}
