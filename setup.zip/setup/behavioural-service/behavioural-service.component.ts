import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { KaizenService } from 'src/app/kaizen/kaizen.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { MessageService } from 'primeng/api';
import * as _ from "lodash";
import { timeStamp } from 'console';


@Component({
  selector: 'app-behavioural-service',
  templateUrl: './behavioural-service.component.html',
  styleUrls: ['./behavioural-service.component.css']
})
export class BehaviouralServiceComponent implements OnInit {



  behavioralData:any=[];
  userAccountInfo: any;
  behavioralSubmisionList:any=[];
  addServiceForm:FormGroup;
  slaForm:FormGroup;
  cols:any=[];
  updateerviceForm:FormGroup
  isAddService:boolean=false;
  submitted;
  formFields;
  isUpdateService;
  updated;
  ;
  ;
  totalsla;
  loading;
  selectedServiceLeve
  uomlist;
  ;
  ;
  paginationDetails: any;
  
  constructor( private fb: FormBuilder,
    private setupService: SetupService,
    private kaizenService :KaizenService,
    private msAdalService : MsAdalAngular6Service,
    private messageService: MessageService) { }

  ngOnInit() {
    this.getBehavioralSColomns();
    this.updateerviceForm =this.fb.group({
      service:[null, Validators.required],
     
      id:[null]
    })
    this.slaForm=this.fb.group({
      DepartmentSla: [null],
      departments:[null],
      teams:[null]
      
    })
    this.addServiceForm =this.fb.group({
      service:[null, Validators.required]
      
    })
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    if (this.msAdalService.isAuthenticated) {
      const username = this.msAdalService.userInfo.userName.split("@")[0];
      this.getUserInfo(username);
    } else {
      //  this.getUserInfoById(localStorage.getItem('UserId'));
    }
    this.getCount()
    this.getAllBehaviorServices(this.paginationDetails)
  }
  getUserInfo(userId) {
    this.loading=true;
    this.kaizenService
      .getWithParam(
        "RpmMapping/GetRpmMappingForEmployee/username",
        userId,
        "admin"
      )
      .subscribe(
        (res: any) => {
          console.log("res", res);
          const unitId = sessionStorage.getItem("unitId");
          const index = _.findIndex(res, (d) => d["item2"].unitId == unitId);
          this.userAccountInfo= res[0]["item2"];
          this.loading=false;
      
        
        
        },
        (err) => {
          console.log("err", err);
        }
      );
  }
  getCount(){
    this.setupService.getAllBehaviorSlaCount().subscribe(
      res=>{
        this.totalsla=res
      }
     
    )
  }
  getAllBehaviorServices(paginationDetails){
      this.setupService.getAllBehaviorSla(paginationDetails).subscribe(

        res=>{
          this.behavioralData=res;
        }
      )
  }
  closeServiceUpdate(){
    this.isUpdateService=false;
  }
  showService(){
    this.isAddService=true;
  }
  closeService(){
    this.isAddService=true;
  }
  createdObj:any={}
  addservice(){
    if(this.addServiceForm.valid){
     
      this.createdObj.behaviorName=this.addServiceForm.value.service;
      // debugger;
         this.createdObj.createdBy=this.userAccountInfo.accountName[0];
        this.setupService.addServiceBe(this.createdObj).subscribe(
          res=>{
            this.isAddService=false;
            this.messageService.add({ severity: 'success', summary: 'Behaviour', detail: 'Behaviour Created  Successfully' });
          }
        )
    }
  }

  getBehavioralSColomns(){
    this.cols=[
      {field:'service',header:'Service'},
     
      {field:'Action',header:'Action'},
     
      
    ]
  }
  get updateformFields() {
    return this.updateerviceForm.controls;
  }
  onBehavioralPageChange(event){
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows,
    };
    this.getAllBehaviorServices(this.paginationDetails);
  }
  selectedObjForUpdate:any;
  getbehavioralforUpdate(rowData){
    this.isUpdateService=true;
    this.selectedObjForUpdate=rowData
    this.updateerviceForm.patchValue({
      service:rowData.behaviorName
    })
  }
  submitSelectedBeha(){

  }
  updateService(){
    if(this.updateerviceForm.valid){
    this.loading=true;
      this.selectedObjForUpdate.behaviorName= this.updateerviceForm.value.service;
      this.setupService.upsateBehavioralService(this.selectedObjForUpdate).subscribe(
        res=>{
          this.loading=false
          this.messageService.add({ severity: 'success', summary: 'Behaviour', detail: 'Behaviour Upadted  Successfully' });
          this.getCount();
          this.getAllBehaviorServices(this.paginationDetails);
        }
      )
    }
    

  }
  selectedForSubmission:boolean=false;
  submitAllSla(value){
    // debugger;
    if (value) {
      console.log('onAwardToAll clicked');
  
      for (let index = 0; index < this.behavioralData.length; index++) {
          const element = this.behavioralData[index];
        
          if (!element.isChecked) {
         
              this.behavioralSubmisionList.push(element.id);
  
          }
      }
      if (this.behavioralSubmisionList.length > 0) {
          this.selectedForSubmission = true;
      }
   
  }
  
  if (!value) {
      this.behavioralSubmisionList = null;
      this.behavioralSubmisionList = [];
      // tslint:disable-next-line: triple-equals
      if (this.behavioralSubmisionList.length == 0) {
          this.selectedForSubmission = false;
      }
  
  }
  
   }
}
