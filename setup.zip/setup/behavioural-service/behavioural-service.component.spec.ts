import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BehaviouralServiceComponent } from './behavioural-service.component';

describe('BehaviouralServiceComponent', () => {
  let component: BehaviouralServiceComponent;
  let fixture: ComponentFixture<BehaviouralServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BehaviouralServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BehaviouralServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
