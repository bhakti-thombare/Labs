import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { SetupService } from '../setup.service';
import * as _ from 'lodash';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';
@Component({
  selector: 'app-evaluationscoringparameters',
  templateUrl: './evaluationscoringparameters.component.html',
  styleUrls: ['./evaluationscoringparameters.component.css']
})
export class EvaluationscoringparametersComponent implements OnInit {
  cols: any = [];
  // status:number;
  savingType: Boolean;
  evaluations: any = [];
  totalEvaluationScoringParameters: any;
  submitted: Boolean = false;
  paginationDetails: any;
  // savingType:any;
  addEvaluationScoringForm: FormGroup;
  updateEvaluationScoringForm: FormGroup;
  displayAddEvaluationScoringDialog: Boolean;
  displayUpdateEvaluationScoringDialog: Boolean;
  getParameterLists: any[];
  getSubParameterLists: any[];
  // savingType :Boolean=true;
  updateEvaluationScoringParameterData: any;
  update = false;
  score = 0;
  // savingType:Boolean=true;
  // savingType:Boolean=true;
  selectedParametersArr = [];

  isPowerUser:boolean=false;

  constructor(private fb: FormBuilder, private setupService: SetupService, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {

    this.getUserRole();
    // this.addEvaluationScoringForm.savingType='1';
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    
    // this.getEvaluationScoringParameters(this.paginationDetails);
    this.initializeAddEvaluationScoringParametersForm();
    this.getTotalNumberEvaluationScoringParameters('Tangible');
    this.getParameters();
    this.getSubParameters();
    this.initializeUpdateEvaluationScoringParametersForm();
    //  this.isTangible();
    this.getList('Tangible');
  }

  get formFields() { return this.addEvaluationScoringForm.controls; }
  /* onSelectionChange(value) {
    this.savingType = value;
  } */
  getUserRole(){
    let userRole= sessionStorage.getItem('userRole');
    if(userRole=="Power User"){
      this.isPowerUser=true;
    }
    this.getEvaluationScoringParametersColumns();
  }

  initializeAddEvaluationScoringParametersForm() {
    this.addEvaluationScoringForm = this.fb.group({
      parameter: [null, Validators.required],
      subParameter: [null, Validators.required],
      weightage: [null, Validators.required],
      status: [true, Validators.required],


    });
  }

  initializeUpdateEvaluationScoringParametersForm() {
    this.updateEvaluationScoringForm = this.fb.group({
      Parameter: [null, Validators.required],
      SubParameter: [null, Validators.required],
      Weightage: [null, Validators.required],
      status: [null, Validators.required],



    });
  }
  onEvaluationScoringParameterPageChange(event) {

    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    console.log('---------Pagination Details--------', this.paginationDetails);
    this.setupService
    .get(`KaizenEvaluationScoringParameters/GetKaizenEvaluationScoringParameters/${this.paginationDetails.pageNumber}/${this.paginationDetails.pageSize}?savingtype=${this.savingType}`)
    .subscribe(res => {
      console.log(res);
      this.evaluations = res.item2;
      this.score = res.item1;
      const index = _.filter(res.item2, (d) => d['isSelected'] == true);
        console.log('index', index);
        // this.selectedParametersArr.push(res.item2[index]);
        for (let i = 0; i < index.length; i++) {
          const isPresent = _.findIndex(this.selectedParametersArr, (d) => d['id'] == index[i].id);
          if (isPresent == -1) {
            this.selectedParametersArr.push(index[i]);
          }
        }
      console.log('this.selectedParametersArr', this.selectedParametersArr);
    });
  }

  /* onItemChange(value){
    console.log(' Value is : ', value );
    this.savingType=value;
  } */



  isTangible() {
    if (this.addEvaluationScoringForm.value.savingType) {
      if (this.addEvaluationScoringForm.value.savingType == 'Tangible') {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }


  /* radioChangehandler(event:any){
    this.savingType=event.target.value;
  }
   */


  addEvaluationScoringParameters() {

    this.submitted = true;
    if (this.addEvaluationScoringForm.invalid) {
      return this.addEvaluationScoringForm.value.actionPerformed = 'null';
    } else {
      if (this.update) {
        const evaluationScoringParameterData = this.addEvaluationScoringForm.value;
        evaluationScoringParameterData.id = this.updateEvaluationScoringParameterData.id;
        this.setupService.updateEvaluationScoringParameters(evaluationScoringParameterData).subscribe((res: any) => {
          this.displayAddEvaluationScoringDialog = false;
          this.messageService.add({ severity: 'success', summary: `Evaluation scoring parameters`, detail: `updated successfully` });
          // this.getTotalNumberEvaluationScoringParameters();
          this.getEvaluationScoringParameters(this.paginationDetails);
          console.log('-----------EValuation Scorin');
        });
      } else {
        const addEvaluationScoringParameterData = this.addEvaluationScoringForm.value;
        addEvaluationScoringParameterData.savingType = this.savingType;

        this.setupService.addEvaluationScoringParameters(addEvaluationScoringParameterData)
          .subscribe((res: any[]) => {
            this.displayAddEvaluationScoringDialog = false;
            this.getEvaluationScoringParameters(this.paginationDetails);
            // this.getTotalNumberEvaluationScoringParameters();
            console.log('-----------Evaluator Scoring Parameters Added Successfully--------');

          }, err => {
            console.log('--------error occured in add Evaluation Scoring Parameters', err);
          });
      }
    }
  }

  updateEvaluationScoringParameters(evaluationParameters) {
    this.submitted = true;
    if (this.updateEvaluationScoringForm.invalid) {
      return this.updateEvaluationScoringForm.value.actionPerformed = 'null';
    } else {
      const evaluationScoringParameterData = this.updateEvaluationScoringForm.value;
      evaluationScoringParameterData.id = evaluationParameters.id;
      this.setupService.updateEvaluationScoringParameters(evaluationScoringParameterData).subscribe((res: any) => {
        this.displayUpdateEvaluationScoringDialog = false;
        // this.getTotalNumberEvaluationScoringParameters();
        this.getEvaluationScoringParameters(this.paginationDetails);
        console.log('-----------EValuation Scorin');
      });
    }
  }


  getEvaluationScoringParametersColumns() {
    if(sessionStorage.getItem('userRole')!='Power User'){
      this.cols = [
        { field: 'parameter', header: 'Parameter' },
        { field: 'subParameter', header: 'Sub-Parameter' },
        { field: 'weightage', header: 'Weightage' },
        { field: 'action', header: 'Actions' },
        { field: 'status', header: 'Status' },
      ];
    }else{
      this.cols = [
        { field: 'parameter', header: 'Parameter' },
        { field: 'subParameter', header: 'Sub-Parameter' },
        { field: 'weightage', header: 'Weightage' },
       
        { field: 'status', header: 'Status' },
      ];
    }
  
  }
  getEvaluationScoringParameters(paginationDetails) {

    this.setupService.getEvaluationScoringParameters(paginationDetails).subscribe((res: any[]) => {
      this.evaluations = res;
    }, err => {
      console.log('Error occured in get Evaluation Scoring Parameters:', err);
    });
  }

  getTotalNumberEvaluationScoringParameters(status) {
    this.setupService.get(`KaizenEvaluationScoringParameters/GetKaizenEvaluationScoringParametersCount?savingtype=${status}`).subscribe((data) => {
      this.totalEvaluationScoringParameters = data;
      console.log('--------totalEvaluationScoringParameters--------', this.totalEvaluationScoringParameters);
    });
  }

  /* -------------------------------------Get Parameters-------------------------------------------- */
  getParameters() {
    this.setupService.getParameters(this.savingType).subscribe((res: any[]) => {
      this.getParameterLists = res;
      console.log('------------------Get Parameter lists-----------', this.getParameterLists);
    });
  }
  /* ------------------------------------Get SubParameters -------------------------------------------------*/
  getSubParameters() {
    this.setupService.getSubParameters().subscribe((res: any[]) => {
      this.getSubParameterLists = res;
      console.log('-----------------------------getSubParameterLists----------', this.getSubParameterLists);
    });
  }

  getEvaluationScoringParameterById(id) {

    this.setupService.getEvaluationScoringParameterById(id).subscribe((res: any) => {
      this.addEvaluationScoringForm.patchValue(res);
      console.log('----res-----', res);

      this.updateEvaluationScoringParameterData = res;
      console.log('------------Evaluation Scoring Parameters By Id--------', this.updateEvaluationScoringParameterData);
    });
  }











  cancelAddEvaluationScoringParametersDialog() {
    this.displayAddEvaluationScoringDialog = false;
    /* this.addAreaForm.reset(); */
    this.initializeAddEvaluationScoringParametersForm();

  }

  showAddEvaluationScoringParametersDialog() {
    this.displayAddEvaluationScoringDialog = true;
    this.submitted = false;
    this.initializeAddEvaluationScoringParametersForm();


  }
  cancelUpdateEvaluationScoringParametersDialog() {
    this.displayAddEvaluationScoringDialog = false;
    /* this.addAreaForm.reset(); */
    this.update = false;
  }

  showUpdateEvaluationScoringParametersDialog(id: any) {
    this.displayAddEvaluationScoringDialog = true;
    this.update = true;
    this.getEvaluationScoringParameterById(id);

  }

  getList(type) {
    this.savingType = type;
    this.getTotalNumberEvaluationScoringParameters(this.savingType);
    this.setupService
    .get(`KaizenEvaluationScoringParameters/GetKaizenEvaluationScoringParameters/${this.paginationDetails.pageNumber}/${this.paginationDetails.pageSize}?savingtype=${type}`)
    .subscribe(res => {
      console.log(res);
      this.evaluations = res.item2;
      this.score = res.item1;
      console.log('res.item2', res.item2);
        const index = _.filter(res.item2, (d) => d['isSelected'] == true);
        console.log('index', index);
        // this.selectedParametersArr.push(res.item2[index]);
        for (let i = 0; i < index.length; i++) {
          this.selectedParametersArr.push(index[i]);
        }
      console.log('this.selectedParametersArr', this.selectedParametersArr);
    });
  }

  checkTotalWeightage(rowData) {
    console.log(rowData);
    if (rowData.isSelected == true) {
      this.score = this.score - rowData.weightage;
      console.log('this.score', this.score);
      rowData.isSelected = false;
      const index = _.findIndex(this.selectedParametersArr, (d) => d['id'] == rowData.id);
      this.selectedParametersArr[index].isSelected = false;
    } else {
      const tempScore = this.score + rowData.weightage;
      console.log('tempScore', tempScore);
      if (tempScore > 100) {
        rowData.isSelected = false;
        const index = _.findIndex(this.evaluations, (d) => d['id'] == rowData.id);
        this.evaluations[index].isSelected = false;
        event.preventDefault();
        this.messageService.add({severity: 'warn', summary: `Total weightage should not be greater than 100`, detail: `Current Total Weightage: ${tempScore}`});
        console.log('Total Weight greater than 100');
      } else {
        this.score += rowData.weightage;
        rowData.isSelected = true;
        this.selectedParametersArr.push(rowData);
        console.log('this.selectedParametersArr', this.selectedParametersArr);
      }
    }
  }

  sendCheckedParams() {
    this.setupService.put(`kaizenevaluationscoringparameters/UpdateKaizenEvaluationScoringParametersMultiple`, this.selectedParametersArr)
      .subscribe(res => {
        this.messageService.add({ severity: 'success', summary: `Parameters`, detail: `saved successfully` });
        console.log(res);
      });
  }

  exportAsXLSX() {
    if (this.evaluations.length > 0) {
      this.excelService.exportAsExcelFile(this.evaluations, 'sample');
    }
  }
}
