import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EvaluationscoringparametersComponent } from './evaluationscoringparameters.component';

describe('EvaluationscoringparametersComponent', () => {
  let component: EvaluationscoringparametersComponent;
  let fixture: ComponentFixture<EvaluationscoringparametersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EvaluationscoringparametersComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EvaluationscoringparametersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
