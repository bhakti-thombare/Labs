import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import Swal from 'sweetalert2'
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-sectionnames',
  templateUrl: './sectionnames.component.html',
  styleUrls: ['./sectionnames.component.css']
})
export class SectionnamesComponent implements OnInit {

  cols: any = [];
  sectionnames: any = [];
  totalSectionNames: any;
  submitted: Boolean = false;
  // status: Boolean = false;
  isPowerUser:boolean=false;
  updateMasterSectionNamesData: any;
  paginationDetails: any;
  addSectionNamesForm: FormGroup;
  updateSectionNamesForm: FormGroup;
  displayAddSectionNamesDialog: Boolean;
  displayUpdateSectionNamesDialog: Boolean;
  constructor(private fb: FormBuilder, private setupService: SetupService,
              private messageService: MessageService) { }

  ngOnInit() {
    this.getUserRole();
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5,
    }
    this.getSectionNamesColumns();
    this.getSectionNames(this.paginationDetails);
    this.initializeAddSectionNames();
    this.initializeUpdateSectionNames();
    this.getTotalNumberOfSectionNames();
  }

  initializeAddSectionNames() {
    this.addSectionNamesForm = this.fb.group({
      sectionNameTitle: [null, Validators.required],
      status: [true, Validators.required],

    });
  }
  getUserRole(){
    let userRole= sessionStorage.getItem('userRole');
    if(userRole=="Power User"){
      this.isPowerUser=true;
    }
    this.getSectionNamesColumns();

  }

  initializeUpdateSectionNames() {
    this.updateSectionNamesForm = this.fb.group({
      sectionNameTitle: [null, Validators.required],
      status: [null, Validators.required],
    });
  }

  onSectionNamesPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    }
    console.log('-----------Pagination Details', this.paginationDetails);
    this.getSectionNames(this.paginationDetails);
  }

  get formFields() { return this.addSectionNamesForm.controls; }

  get editFormFields() { return this.updateSectionNamesForm.controls; }

  /* Add Section Names */
  addMasterSectionNames() {
    this.submitted = true;
    if (this.addSectionNamesForm.invalid) {
      return this.addSectionNamesForm.value.actionPerformed = null;
    } else {
      let addSectionNameData = this.addSectionNamesForm.value;
      this.setupService.addMasterSectionNames(addSectionNameData).subscribe((res: any[]) => {
        this.displayAddSectionNamesDialog = false;
        this.getTotalNumberOfSectionNames();
        this.getSectionNames(this.paginationDetails);
        this.messageService.add({ severity: 'success', summary: `Section`, detail: 'added Successfully' });
      }, err => {
        console.log('Error occured in add Section:', err)
      });
    }
  }
  /* Update Section Names */
  updateMasterSectionNames(sectionNames) {
    this.submitted = true;
    if (this.updateSectionNamesForm.invalid) {
      return this.updateSectionNamesForm.value.actionPerformed = null;
    } else {
      this.updateSectionNamesForm.value.actionPerformed = 'Submit';

      let sectionNamesData = this.updateSectionNamesForm.value;
      sectionNamesData.id = sectionNames.id;
      // sectionNamesData.status = this.status;

      this.setupService.updateMasterSectionNames(sectionNamesData).subscribe((res: any[]) => {
        this.displayUpdateSectionNamesDialog = false;
        this.getTotalNumberOfSectionNames();
        this.getSectionNames(this.paginationDetails);
        this.messageService.add({ severity: 'success', summary: `Section`, detail: 'updated Successfully' });
        console.log('Section  Names Updated Successfully');
/*     Swal.fire('Section Names Updated Successfully', '', 'success')
 */  }, err => {
        console.log('Error occured in update Section Names:', err);
      })
    }
  }


  getSectionNamesColumns() {
    if(sessionStorage.getItem('userRole')!="Power User"){
    this.cols = [
      { field: 'sectionNameTitle', header: 'Section Name' },
      { field: 'action', header: 'Actions' },
      { field: 'status', header: 'Status' }
    ];
  }else{
    this.cols = [
      { field: 'sectionNameTitle', header: 'Section Name' },
    
      { field: 'status', header: 'Status' }
    ];
  }
}

  getSectionNames(paginationDetails) {
    this.setupService.getSectionNames(paginationDetails).subscribe((res: any[]) => {
      this.sectionnames = res;
    }, err => {
      console.log('Error occured in get section names:', err);
    })
  }

  /* -------------------------------------Get Total COunt Of Section Names------------------------- */
  getTotalNumberOfSectionNames() {
    this.setupService.getTotalNumberOfSectionNames().subscribe((data) => {
      this.totalSectionNames = data;
      console.log('-----------total Count Of Section NAmes', this.totalSectionNames)
    })
  }


  /* --------------------------------------Get Section Names By Id------------------------------ */
  getMasterSectionNamesById(id) {
    this.setupService.getMasterSectionNamesById(id).subscribe((res: any) => {
      console.log('----res-----', res);
      this.updateMasterSectionNamesData = res;
      console.log('------------Section Names By Id--------', this.updateMasterSectionNamesData);
    })
  }

  cancelAddSectionNamesDialog() {
    this.displayAddSectionNamesDialog = false;
    this.addSectionNamesForm.controls['sectionNameTitle'].reset()
  }

  showAddSectionNamesDialog() {
    this.displayAddSectionNamesDialog = true;
    this.submitted = false;
    this.initializeAddSectionNames();
  }

  cancelUpdateSectionNamesDialog() {
    this.displayUpdateSectionNamesDialog = false;
  }

  showUpdateSectionNamesDialog(id: any) {
    this.displayUpdateSectionNamesDialog = true;
    this.submitted = false;
    this.getMasterSectionNamesById(id);
  }
}
