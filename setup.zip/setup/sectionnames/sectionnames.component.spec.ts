import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SectionnamesComponent } from './sectionnames.component';

describe('SectionnamesComponent', () => {
  let component: SectionnamesComponent;
  let fixture: ComponentFixture<SectionnamesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SectionnamesComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SectionnamesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
