import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { MessageService } from 'primeng/api';


@Component({
  selector: 'app-functionnames',
  templateUrl: './functionnames.component.html',
  styleUrls: ['./functionnames.component.css']
})
export class FunctionnamesComponent implements OnInit {
  cols: any = [];
  paginationDetails: any;
  // status: Boolean = false;
  submitted: Boolean = false;
  functions: any = [];
  totalMasterFunctionnames: any;
  updateMasterFunctionNamesData: any;
  addFunctionNamesForm: FormGroup;
  updateFunctionNamesForm: FormGroup;
  displayAddFunctionNamesDialog: Boolean;
  displayUpdateFunctionNamesDialog: Boolean;
  isPowerUser = false;
  constructor(private fb: FormBuilder, private setupService: SetupService,
              private messageService: MessageService) { }

  ngOnInit() {
    this.getUserRole()
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    }
    this.getTotalCountOfMasterFunctionnames();

    this.getMasterFunctionsNames(this.paginationDetails);
    this.initializeAddFunctionNames();
    this.initializeUpdateFunctionNames();
  }
  getUserRole() {
    let userRole = sessionStorage.getItem('userRole');
    if (userRole == "Power User") {
      this.isPowerUser = true;
    }
    this.getFunctionColumns();

  }

  onFunctionNamesPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows,
    };
    console.log("-------------------pagination Details-----------------", this.paginationDetails);
    this.getMasterFunctionsNames(this.paginationDetails);
  }

  initializeAddFunctionNames() {
    this.addFunctionNamesForm = this.fb.group({
      functionName: [null, Validators.required],
      status: [true, Validators.required],
    });
  }

  initializeUpdateFunctionNames() {
    this.updateFunctionNamesForm = this.fb.group({
      functionName: [null, Validators.required],
      status: [null, Validators.required],

    });
  }
  addFunctionNames() {
    this.submitted = true;
    if (this.addFunctionNamesForm.invalid) {

      return this.addFunctionNamesForm.value.actionPerformed = null;
    } else {

      let addFunctionNameData = this.addFunctionNamesForm.value;
      // addFunctionNameData.status = this.status;
      this.setupService.addFunctionNames(addFunctionNameData).subscribe((res: any[]) => {
        this.addFunctionNamesForm.value.actionPerformed = 'Submit';

        this.displayAddFunctionNamesDialog = false;
        // this.status = false;
        this.getTotalCountOfMasterFunctionnames();
        this.getMasterFunctionsNames(this.paginationDetails);
        console.log('Add Function Names Successfully')
        this.messageService.add({ severity: 'success', summary: `Function`, detail: 'added Successfully' });
      }, err => {
        console.log('Error occured in add area:', err);
      })
    }
  }
  /* Update FunctionNames*/
  updateMasterFunctionNames(functionNames) {
    this.submitted = true;
    if (this.updateFunctionNamesForm.invalid) {
      this.updateFunctionNamesForm.value.actionPerformed = null;
      return;
    } else {
      this.updateFunctionNamesForm.value.actionPerformed = 'Submit';
      let functionNamesData = this.updateFunctionNamesForm.value;
      functionNamesData.id = functionNames.id;
      //  functionNamesData.status = this.status;
      this.setupService.updateMasterFunctionNames(functionNamesData).subscribe((res: any[]) => {
        this.displayUpdateFunctionNamesDialog = false;
        //  this.status = false;

        this.getTotalCountOfMasterFunctionnames();
        this.getMasterFunctionsNames(this.paginationDetails);
        console.log('Function Names Updated Successfully');
        this.messageService.add({ severity: 'success', summary: `Function`, detail: 'updated Successfully' });
      }, err => {
        console.log('Error occured in update Function Names:', err);
      })
    }
  }
  get formFields() { return this.addFunctionNamesForm.controls; }

  get editFormFields() { return this.updateFunctionNamesForm.controls; }


  getFunctionColumns() {
    if (sessionStorage.getItem('userRole') != "Power User") {
      this.cols = [
        { field: 'functionName', header: 'Function Name' },
        { field: 'action', header: 'Actions' },
        { field: 'status', header: 'Status' }

      ]
    } else {
      this.cols = [
        { field: 'functionName', header: 'Function Name' },

        { field: 'status', header: 'Status' }

      ]
    }

  }
  /* -------------------------------------------getMasterFunctionsNames---------------------------------- */
  getMasterFunctionsNames(paginationDetails) {
    this.setupService.getMasterFunctionsNames(paginationDetails).subscribe((res: any[]) => {
      this.functions = res;
    }, err => {
      console.log("Error occured in get function names:", err);
    })
  }

  /* --------------------------------------------Get Total Count of MasterFunctionsNames  ------------*/
  getTotalCountOfMasterFunctionnames() {
    this.setupService.getTotalCountOfMasterFunctionnames().subscribe((data) => {
      this.totalMasterFunctionnames = data;
      console.log("---------------Total Count Of Master Function Names----------", this.totalMasterFunctionnames);
    }), err => {
      console.log("error in Total County Of MAsterr function Names", err);
    }
  }


  /* ---------------------------------Get Function NAmes By Id */
  getMasterFunctionNamesById(id) {
    this.setupService.getMasterFunctionNamesById(id).subscribe((res: any[]) => {
      this.updateMasterFunctionNamesData = res;
      console.log("-----Id Of Functin Names", this.updateMasterFunctionNamesData);
    }), err => {
      console.log("error in id of function Names", err);
    }
  }

  cancelAddFunctionNamesDialog() {
    this.displayAddFunctionNamesDialog = false;
    this.addFunctionNamesForm.controls['functionName'].reset();
  }

  cancelUpdateFunctionNamesDialog() {
    this.displayUpdateFunctionNamesDialog = false;
    this.updateFunctionNamesForm.controls['functionName'].reset();
  }

  showAddFunctionNamesDialog() {
    this.displayAddFunctionNamesDialog = true;
    this.submitted = false;
  }

  showUpdateFunctionNamesDialog(id: any) {
    this.displayUpdateFunctionNamesDialog = true;
    this.getMasterFunctionNamesById(id);
    this.submitted = false;
  }
}
