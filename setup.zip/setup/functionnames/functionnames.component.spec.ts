import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FunctionnamesComponent } from './functionnames.component';

describe('FunctionnamesComponent', () => {
  let component: FunctionnamesComponent;
  let fixture: ComponentFixture<FunctionnamesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FunctionnamesComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FunctionnamesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
