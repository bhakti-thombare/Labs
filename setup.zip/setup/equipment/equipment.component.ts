import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import * as _ from 'lodash';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';

@Component({
  selector: 'app-equipment',
  templateUrl: './equipment.component.html',
  styleUrls: ['./equipment.component.css']
})
export class EquipmentComponent implements OnInit {
  equipments: any = [];
  cols: any = [];
  areasNames = [];
  submitted: Boolean = false;

  addEquipmentForm: FormGroup;
  totalEquipments: any;
  updateEquipmentData: any;
  displayAddEquipmentDialog: Boolean;
  displayUpdateEquipmentDialog: Boolean;
  updateEquipmentForm: FormGroup;
  paginationDetails: any;
  update = false;
  dropdownSettings = {};
  loading = true;
  areaLoading = false;
  equipmentLoading = false;
  searchForm: FormGroup;
  searchEquipment = false;

  constructor(private fb: FormBuilder, private setupService: SetupService, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm = this.fb.group({
      userName: ['', Validators.required]
    });
    this.getEquipmentColumns();
    this.getAreasNamesOfEquipment();
    this.getTotalNumberOfEquipments();
    this.getEquipments(this.paginationDetails);
    this.initializeAddEquipmentForm();
    this.initializeUpdateEquipmentForm();
    this.dropSettings();
  }

  dropSettings() {
    this.dropdownSettings = {
      singleSelection: true,
      text: 'Choose Area Name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class-example',
      enableSearchFilter: true,
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };
  }

  search() {
    this.searchEquipment = true;
    this.setupService.get(`Admin/SearchFromName/${this.paginationDetails.pageNumber}/${this.paginationDetails.pageSize}?queryString=${this.searchForm.value.userName}&searchFor=equipment`)
      .subscribe(res => {
        console.log(res);
        this.totalEquipments = res.item1;
        this.equipments = res.item2;
      });
  }

  reset() {
    this.searchEquipment = false;
    const pagination = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm.reset();
    this.getTotalNumberOfEquipments();
    this.getEquipments(pagination);
  }

  onEquipmentpageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    if (this.searchEquipment) {
      this.search();
    } else {
      console.log('----------Pagination details-------', this.paginationDetails);
    this.getEquipments(this.paginationDetails);
    }
  }

  initializeAddEquipmentForm() {
    this.addEquipmentForm = this.fb.group({
      area: ['', Validators.required],
      eqptNo: ['', Validators.required],
      status: [false, Validators.required]

    });
  }

  get formFields() { return this.addEquipmentForm.controls; }

  get editFormFields() { return this.updateEquipmentForm.controls; }




  initializeUpdateEquipmentForm() {
    this.updateEquipmentForm = this.fb.group({
      area: ['', Validators.required],
      eqptNo: ['', Validators.required],
      status: ['', Validators.required]

    });
  }


  /*---------------------------------------------------- Add Equipment-------------------------------------------- */
  addEquipment() {
    this.submitted = true;
    this.loading = true;

    if (this.addEquipmentForm.invalid) {
      this.loading = false;
      return this.addEquipmentForm.value.actionPerformed = null;
    } else {
      if (this.update) {
        const equipmentData = this.addEquipmentForm.value;
        equipmentData.sno = this.updateEquipmentData.sno;
        equipmentData.area = '' + this.addEquipmentForm.value.area[0].id;
        equipmentData.unit = '' + this.updateEquipmentData.unit;
        // equipmentData.status = this.addEquipmentForm.value.status;
        this.setupService.updateEquipment(equipmentData).subscribe((res: any[]) => {
          this.displayAddEquipmentDialog = false;
          this.update = false;
          this.loading = false;
          this.getEquipments(this.paginationDetails);
          this.messageService.add({severity: 'success', summary: `${equipmentData.eqptNo}`, detail: 'updated Successfully'});
          console.log('Equipment Updated Successfully');
        }, err => {
          this.update = false;
          this.loading = false;
          console.log('Error occured in update equipment:', err);
        });
      } else {
        const equipmentData = {'areaId': 0, 'description': '', 'eqptNo': '', 'status': false};
        equipmentData.areaId = +this.addEquipmentForm.value.area[0].id;
        equipmentData.description = this.addEquipmentForm.controls.eqptNo.value;
        equipmentData.status = this.addEquipmentForm.controls.status.value;
        equipmentData.eqptNo = this.addEquipmentForm.controls.eqptNo.value;
        this.setupService.addEquipment(equipmentData).subscribe((res: any[]) => {
          this.displayAddEquipmentDialog = false;
          console.log('Equipment Saved Successfully');
          this.getTotalNumberOfEquipments();
          this.getEquipments(this.paginationDetails);
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `${equipmentData.description}`, detail: 'created Successfully'});
        }, err => {
          this.update = false;
          this.loading = false;
          console.log('Error occured in add equipment:', err);
        });
      }
    }

  }
  /* ------------------------------------------------------Update Equipment ------------------------------------------*/
  // updateEquipment(equipmentss) {
  //   this.submitted = true;
  //   if (this.updateEquipmentForm.invalid) {
  //     return this.updateEquipmentForm.value.actionPerformed = 'null';
  //   } else {
  //     let equipmentData = this.addEquipmentForm.value;
  //     equipmentData.sno = equipmentss.sno;
  //     this.setupService.updateEquipment(equipmentData).subscribe((res: any[]) => {
  //       this.displayAddEquipmentDialog = false;
  //       this.getEquipments(this.paginationDetails);
  //       console.log('Equipment Updated Successfully');
  //     }, err => {
  //       console.log('Error occured in update equipment:', err);
  //     })
  //   }
  // }

  /* -----------------------------------------------Get Equipment Columns -----------------------*/
  getEquipmentColumns() {
    this.cols = [
      { field: 'eqptNo', header: 'Equipment' },
      { field: 'action', header: 'Actions' },
      { field: 'status', header: 'Status' }
    ];
  }
  /* ----------------------Get Equipments---------------------------- */


  getEquipments(paginationDetails) {
    this.equipmentLoading = true;
    this.searchEquipment = false;
    this.setupService.getEquipments(paginationDetails).subscribe((res: any[]) => {
      this.equipments = res;
      this.equipmentLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in get equipments:', err);
      this.equipmentLoading = false;
      this.loadOninit();
    });

  }

  /* ------------------GEt Total Number Of Equipments---------------------- */
  getTotalNumberOfEquipments() {
    this.setupService.getTotalNumberOfEquipments().subscribe((data) => {
      this.totalEquipments = data;
      console.log('---------------Number Of Equipment Count------', this.totalEquipments);
    });
  }


  /* --------------------------Get <areaname>------------------------------------ */
  getAreasNamesOfEquipment() {
    this.setupService.getAreasNamesOfEquipment().subscribe((res: any[]) => {
      // this.areasNames = res;
      this.areaLoading = true;
      this.areasNames = [];
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.areaName) {
          newData.push({ itemName: element.areaName, id: element.areaId });
        }
      }

      this.areasNames = this.areasNames.concat(newData);
      console.log('get areas names of equipment', this.areasNames);
      this.areaLoading = false;
      this.loadOninit();
    }, err => {
      console.log('error in get Areas Names', err);
      this.areaLoading = false;
      this.loadOninit();

    });
  }

  /* ---------------------------------Get Equipment By Id-------------------------------------- */
  getEquipmentById(sno) {
    this.setupService.getEquipmentById(sno).subscribe((res: any[]) => {
      this.updateEquipmentData = res[0];
      // this.addEquipmentForm.patchValue(res[0]);
      if (res[0].area != null) {
        const indexArea = _.findIndex(this.areasNames, (e) => e.itemName.toLowerCase() === res[0].area.toLowerCase());
        this.addEquipmentForm.patchValue({
          area: [this.areasNames[indexArea]],
          eqptNo: res[0].description,
          status: res[0].status
        });
      }
      // this.addEquipmentForm.patchValue({
      //   eqptNo: this.updateEquipmentData.eqptNo
      // });
      console.log('Id of the Equipment', this.updateEquipmentData);
    });
  }

  cancelAddEquipmentDialog() {
    this.displayAddEquipmentDialog = false;
    this.addEquipmentForm.reset();
    this.submitted = false;
    this.update = false;

  }

  showAddEquipmentDialog() {
    this.displayAddEquipmentDialog = true;
    this.addEquipmentForm.reset();

    this.submitted = false;

  }



  cancelUpdateEquipmentDialog() {
    this.displayAddEquipmentDialog = false;
    this.addEquipmentForm.reset();
    this.submitted = false;

  }
  showUpdateEquipmentDialog(sno: any) {
    console.log('Inside update dialog');
    this.getEquipmentById(sno);
    this.displayAddEquipmentDialog = true;
    this.update = true;
    this.submitted = false;
  }

  loadOninit() {
  if (!this.areaLoading && !this.equipmentLoading) {
    this.loading = false;
  }
  }

  exportAsXLSX() {
    if (this.equipments.length > 0) {
      this.excelService.exportAsExcelFile(this.equipments, 'sample');
    }
  }
}
