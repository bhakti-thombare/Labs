import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { SetupService } from '../setup.service';
import * as _ from 'lodash';
import { UserinfoService } from 'src/app/configuration/userinfo.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';
import { SuggestionService } from 'src/app/suggestion/suggestion.service';

@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.css']
})
export class TeamComponent implements OnInit {
  cols: any = [];
  teams: any = [];
  teamLeaderLists: any[];
  paginationDetails: any;
  totalTeams: any;
  submitted: Boolean = false;

  updateTeamData: any;
  displayAddTeamDialog: Boolean;
  addTeamForm: FormGroup;
  updateTeamForm: FormGroup;
  // status:any;
  teamFacilitatorHod: any[];
  displayUpdateTeamDialog: Boolean;
  teamLeaderListDropdown: any = [];
  facilitatorHodListDropdown: any = [];
  mentorFhListsDropDown: any = [];
  update = false;
  status = false;
  dropdownSettings = {};
  dropdownSettingsHod = {};
  dropdownSettingsFh = {};
  loading = true;
  teamLoading = false;
  leaderLoading = false;
  hodLoading = false;
  fhLoading = false;
  searchForm: FormGroup;
  searchTeam = false;
  constructor(private fb: FormBuilder,
    private setupService: SetupService, private userInfo: UserinfoService, private msAdalService: MsAdalAngular6Service,
    private messageService: MessageService,
    private excelService: ExcelService,
    private suggestionService: SuggestionService) { }

  ngOnInit() {
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm = this.fb.group({
      userName: ['', Validators.required]
    });
    this.getTeamColumns();
    this.getTeams(this.paginationDetails);
    this.initializeAddTeamForm();
    this.initializeUpdateTeamForm();
    this.getTotalNumberOfTeamCount();
    this.getTeamLeaderLists();
    this.getFacilitatorHoD();
    this.getMentorFH();
    this.dropSettings();
    // const userId = this.msAdalService.userInfo.userName.split('@')[0];
    // this.getUserInfo(userId);
  }

  dropSettings() {
    this.dropdownSettings = {
      singleSelection: false,
      text: 'Select Team Leader',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsHod = {
      singleSelection: false,
      text: 'Select Facilitator HOD',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsFh = {
      singleSelection: false,
      text: 'Select Mentor FH',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };
  }

  initializeAddTeamForm() {
    this.addTeamForm = this.fb.group({
      teamName: [null, Validators.required],
      teamCode: [null, Validators.required],
      teamLeader: [null, Validators.required],
      facilitatorHods: [null],
      mentorFh: [null],
      status: [true],
      // teamLeaderLists: this.fb.array([]),
      //  teamFacilitatorHod: this.fb.array([]),

    });
  }
  initializeUpdateTeamForm() {
    this.updateTeamForm = this.fb.group({
      teamName: [null, Validators.required],
      teamCode: [null, Validators.required],
      teamLeader: [null, Validators.required],
      facilitatorHods: [null, Validators.required],
      mentorFh: [null, Validators.required],
      status: [null]

    });
  }

  search() {
    this.searchTeam = true;
    this.setupService.get(`Admin/SearchFromName/${this.paginationDetails.pageNumber}/${this.paginationDetails.pageSize}?queryString=${this.searchForm.value.userName}&searchFor=Team`)
      .subscribe(res => {
        console.log(res);
        this.totalTeams = res.item1;
        this.teams = res.item2;
      });
  }

  reset() {
    this.searchTeam = false;
    const pagination = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm.reset();
    this.getTotalNumberOfTeamCount();
    this.getTeams(pagination);
  }

  onTeamPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    if (this.searchTeam) {
      this.search();
    } else {
      console.log('pagination Details after page change', this.paginationDetails);
      this.getTeams(this.paginationDetails);
    }
  }


  get formFields() { return this.addTeamForm.controls; }

  get editFormFields() { return this.updateTeamForm.controls; }


  /* ----------------------------------------Add Team------------------------------------------------------------ */

  addTeam() {
    this.submitted = true;
    this.loading = true;
    if (this.addTeamForm.invalid) {
      this.loading = false;
      return this.addTeamForm.value.actionPerformed = 'null';
    } else {
      if (this.update) {
        const teamData = this.addTeamForm.value;
        teamData.id = this.updateTeamData.id;

        const teamLeaderArr = [];
        const hodArr = [];
        const mentorArr = [];

        for (let i = 0; i < this.addTeamForm.controls.teamLeader.value.length; i++) {
          teamLeaderArr[i] = '' + this.addTeamForm.controls.teamLeader.value[i].id;
        }

        if (teamData.facilitatorHods != null) {
          if (teamData.facilitatorHods.length == 0) {
            teamData.facilitatorHods = null;
          } else {
            for (let i = 0; i < this.addTeamForm.controls.facilitatorHods.value.length; i++) {
              hodArr[i] = '' + this.addTeamForm.controls.facilitatorHods.value[i].id;
            }
            teamData.facilitatorHods = hodArr;
          }
        }

        if (teamData.mentorFh != null) {
          if (teamData.mentorFh.length == 0) {
            teamData.mentorFh = null;
          } else {
            for (let i = 0; i < this.addTeamForm.controls.mentorFh.value.length; i++) {
              mentorArr[i] = '' + this.addTeamForm.controls.mentorFh.value[i].id;
            }
            teamData.mentorFh = mentorArr;
          }
        }

        teamData.teamLeader = teamLeaderArr;
        teamData.unitId = '' + sessionStorage.getItem('unitId');
        this.setupService.updateTeam(teamData).subscribe((res: any[]) => {
          this.displayAddTeamDialog = false;
          this.update = false;
          this.status = false;
          const updateLeadersFromMasterObj = [{
            'teamLeader': res['teamLeader'],
            'teamId': teamData.id.toString(),
            'unitId': sessionStorage.getItem('unitId')
          }];
          this.setupService.teamActivitiesPost(`updateLeadersFromMaster`, updateLeadersFromMasterObj)
            .subscribe(res2 => {
              console.log(res2);
            });
          this.suggestionService.teamActivitiesPost(`suggestion/updateLeadersFromMaster`, updateLeadersFromMasterObj)
            .subscribe(res2 => {
              console.log(res2);
            });
          this.getTeams(this.paginationDetails);
          this.loading = false;
          this.messageService.add({ severity: 'success', summary: `Team`, detail: 'updated Successfully' });
          console.log('Team Updated Successfully');
        }, err => {
          this.loading = false;
          console.log('Error occured in update Team:', err);
          this.update = false;
        });
      } else {
        const teamData = this.addTeamForm.value;
        /*  let filteredData: any = this.teamFacilitatorHod.filter(res =>
           this.addTeamForm.value.facilitatorHods == res.userName)[0];
           teamData.functionHeadEmailId = filteredData.emailId; */

        const teamLeaderArr = [];
        const hodArr = [];
        const mentorArr = [];

        for (let i = 0; i < this.addTeamForm.controls.teamLeader.value.length; i++) {
          teamLeaderArr[i] = '' + this.addTeamForm.controls.teamLeader.value[i].id;
        }

        if (teamData.facilitatorHods != null) {
          if (teamData.facilitatorHods.length == 0) {
            teamData.facilitatorHods = null;
          } else {
            for (let i = 0; i < this.addTeamForm.controls.facilitatorHods.value.length; i++) {
              hodArr[i] = '' + this.addTeamForm.controls.facilitatorHods.value[i].id;
            }
            teamData.facilitatorHods = hodArr;
          }
        }

        if (teamData.mentorFh != null) {
          if (teamData.mentorFh.length == 0) {
            teamData.mentorFh = null;
          } else {
            for (let i = 0; i < this.addTeamForm.controls.mentorFh.value.length; i++) {
              mentorArr[i] = '' + this.addTeamForm.controls.mentorFh.value[i].id;
            }
            teamData.mentorFh = mentorArr;
          }
        }

        teamData.teamLeader = teamLeaderArr;
        teamData.unitId = '' + sessionStorage.getItem('unitId');

        this.setupService.addTeam(teamData).subscribe((res: any[]) => {
          this.displayAddTeamDialog = false;
          this.status = false;
          this.getTeams(this.paginationDetails);
          this.getTotalNumberOfTeamCount();
          this.loading = false;
          this.messageService.add({ severity: 'success', summary: `Team`, detail: 'added Successfully' });
          console.log('Team Saved Successfulluy');
        }, err => {
          this.loading = false;
          console.log('Error occured in add Team:', err);
        });
      }

    }

  }
  /* ---------------------------------------------Update Team------------------------------------- */
  updateTeam(team) {
    this.submitted = true;
    if (this.updateTeamForm.invalid) {
      return this.addTeamForm.value.invalid = null;
    } else {
      const teamData = this.updateTeamForm.value;
      teamData.id = team.id;
      this.setupService.updateTeam(teamData).subscribe((res: any[]) => {
        this.displayAddTeamDialog = false;
        this.update = false;
        this.getTeams(this.paginationDetails);
        console.log('Team Updated Successfully');
      }, err => {
        console.log('Error occured in update Team:', err);
        this.update = false;
      });
    }
  }



  /* -----------------------------------Get Team Columns----------------------------------------- */

  getTeamColumns() {
    this.cols = [
      { field: 'id', header: 'ID' },
      { field: 'teamCode', header: 'Team Code' },
      { field: 'teamName', header: 'Team Name' },
      { field: 'teamLeader', header: 'Team Leader' },
      { field: 'facilitatorHods', header: 'Facilitator HOD' },
      { field: 'mentorFh', header: 'Mentor FH' },
      { field: 'action', header: 'Action' },
      { field: 'status', header: 'Status' }
    ];
  }
  /*------------------------------------------- Get Teams------------------------------------------ */
  getTeams(paginationDetails) {
    this.teamLoading = true;
    this.searchTeam = false;
    this.setupService.getTeams(paginationDetails).subscribe((res: any[]) => {
      this.teams = res;
      this.teamLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in get Teams:', err);
      this.teamLoading = false;
      this.loadOninit();
    });
  }

  /* ------------------------Get Total no of team Count------------------------------------- */
  getTotalNumberOfTeamCount() {
    this.setupService.getTotalNumberOfTeamCount().subscribe((data) => {
      this.totalTeams = data;
      console.log('------------totalteams---------------', this.totalTeams);
    });
  }
  /* --------------------------------Get Team By Id---------------------------------------------------------------------- */
  getTeamById(id) {

    this.setupService.getTeamById(id).subscribe((res: any) => {
      this.updateTeamData = res;
      console.log('---Update Team Data---', this.updateTeamData);
      const leaderData = res.teamLeader;
      this.status = res.status;
      const selectedLeader = [];
      const hodData = res.facilitatorHods;
      const selectedHod = [];
      const mentorData = res.mentorFh;
      const selectedMentor = [];
      this.addTeamForm.patchValue({
        status: res.status
      });

      console.log('hodData', hodData);
      console.log('this.teamLeaderListDropdown', this.teamLeaderListDropdown);

      for (let i = 0; i < leaderData.length; i++) {
        const index = _.findIndex(this.teamLeaderListDropdown, (d) => d['itemName'] === leaderData[i]);
        console.log(index);
        if (index != -1) {
          selectedLeader.push(this.teamLeaderListDropdown[index]);
        }
      }

      if (hodData != null) {
        for (let i = 0; i < hodData.length; i++) {
          const index = _.findIndex(this.facilitatorHodListDropdown, (d) => d['itemName'] == hodData[i]);
          // const numHod = +hodData[i];
          if (index == -1) {
            selectedHod.push(+hodData[i]);
          } else {
            console.log(index);
            selectedHod.push(this.facilitatorHodListDropdown[index]);
          }
        }
      }

      if (mentorData != null) {
        for (let i = 0; i < mentorData.length; i++) {
          const index = _.findIndex(this.facilitatorHodListDropdown, (d) => d['itemName'] === mentorData[i]);
          console.log(index);
          if (index != -1) {
            selectedMentor.push(this.facilitatorHodListDropdown[index]);
          }
        }
      }

      this.addTeamForm.patchValue({
        teamLeader: selectedLeader,
        facilitatorHods: selectedHod,
        mentorFh: selectedMentor,
        teamName: res.teamName,
        teamCode: res.teamCode
      });
    }, err => {
      console.log('Error occured in get getTeamById', err)
    });
  }

  /* ------------------------------------------------------Get Team Leader Lists-------------------------------------- */
  getTeamLeaderLists() {
    this.leaderLoading = true;
    this.setupService.getTeamLeaderLists().subscribe((res: any[]) => {
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.accountName) {
          newData.push({
            itemName: element.userName,
            id: element.id
          });
        }
      }

      this.teamLeaderListDropdown = this.teamLeaderListDropdown.concat(newData);
      this.leaderLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in getTeamLeaderLists:', err);
      this.leaderLoading = false;
      this.loadOninit();
    });
  }

  getUserInfo(userId) {
    this.setupService
      .getWithParam('RpmMapping/GetRpmMappingForEmployee/username', userId)
      .subscribe((res: any) => {
        console.log('res', res);
        // this.kaizenService.storeUnitId(res.item2.unitId);
        this.userInfo.roleName = res.item1;
        this.userInfo.userData = res.item2;
        // this.loggedInData = res.item2;
        // this.GetRoleBasedData();
        console.log(this.userInfo.userData.unitId);
      }, (err) => {
        console.log('err', err);
      });
  }

  /*  onSelectLeaderList(teamLeader: string, isChecked: boolean) {
     const teamMembersArray = <FormArray>this.addTeamForm.controls.teamLeaderLists;
     if (isChecked) {
         teamMembersArray.push(new FormControl(teamLeader));
     } else {
         let index = teamMembersArray.controls.findIndex(x => x.value == teamLeader)
         teamMembersArray.removeAt(index);
     }
 } */
  /* ----------------------------------------------------------Get Facilitator HOd's Lists-------------- */
  getFacilitatorHoD() {
    this.hodLoading = true;
    this.setupService.getFacilitatorHoD().subscribe((res: any[]) => {
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({
            itemName: element.userName, id: element.id
          });
        }
      }

      this.facilitatorHodListDropdown = this.facilitatorHodListDropdown.concat(newData);
      this.hodLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in getDepartmentHod:', err);
      this.hodLoading = false;
      this.loadOninit();
    });
  }

  getMentorFH() {
    this.fhLoading = true;
    this.setupService.getMentorFH().subscribe((res: any[]) => {
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          this.mentorFhListsDropDown.push({
            label: element.userName, value: { userName: element.userName, emailId: element.emailId }
          });
        }
      }
      this.fhLoading = false;
      this.loadOninit();
    }, err => {
      this.fhLoading = false;
      this.loadOninit();
    });
  }










  /* onSelectFacilitatorList(teamFacilitator: string, isChecked: boolean) {
    const teamMembersArray = <FormArray>this.addTeamForm.controls.teamFacilitatorHod;
    if (isChecked) {
        teamMembersArray.push(new FormControl(teamFacilitator));
    } else {
        let index = teamMembersArray.controls.findIndex(x => x.value == teamFacilitator)
        teamMembersArray.removeAt(index);
    }
  } */




  cancelAddTeamDialog() {
    this.displayAddTeamDialog = false;
    this.submitted = false;
    this.update = false;
    this.status = false;
    this.addTeamForm.reset();

  }

  showAddTeamDialog() {
    this.displayAddTeamDialog = true;
    this.submitted = false;

    // this.addTeamForm.reset();
    this.initializeAddTeamForm();
  }

  cancelUpdateTeamDialog() {
    this.displayAddTeamDialog = false;
    this.submitted = false;
    this.addTeamForm.reset();
  }

  showUpdateTeamDialog(id: any) {
    this.getTeamById(id);
    this.displayAddTeamDialog = true;
    this.update = true;
  }

  loadOninit() {
    if (!this.teamLoading && !this.leaderLoading && !this.hodLoading && !this.fhLoading) {
      this.loading = false;
    }
  }

  exportAsXLSX() {
    if (this.teams.length > 0) {
      this.excelService.exportAsExcelFile(this.teams, 'sample');
    }
  }
}
