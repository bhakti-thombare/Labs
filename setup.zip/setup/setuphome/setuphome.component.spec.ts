import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SetuphomeComponent } from './setuphome.component';

describe('SetuphomeComponent', () => {
  let component: SetuphomeComponent;
  let fixture: ComponentFixture<SetuphomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetuphomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetuphomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
