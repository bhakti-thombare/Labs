import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-setuphome',
  templateUrl: './setuphome.component.html',
  styleUrls: ['./setuphome.component.css']
})
export class SetuphomeComponent implements OnInit {
  role: string;

  constructor() {
    this.role = sessionStorage.getItem('userRole');
    console.log('this.role', this.role);
   }

  ngOnInit() {
  }

}
