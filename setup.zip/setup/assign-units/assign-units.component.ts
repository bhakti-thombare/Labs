import { Component, OnInit } from '@angular/core';
import { SetupService } from '../setup.service';
import * as _ from 'lodash';
import { MessageService } from 'primeng/api';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-assign-units',
  templateUrl: './assign-units.component.html',
  styleUrls: ['./assign-units.component.css']
})
export class AssignUnitsComponent implements OnInit {

  dropdownSettings = {};
  userNameListDropdown = [];
  units = [];
  roles = [];
  selectedUnits = [];
  isEmployeeSelected = false;
  employeeId: any;
  sendUnits = [];
  isVisible = false;
  selectedEmployee = [];
  selectedUnit = [];
  employeeDetails: any;
  dropdownSettingsUnit = {};
  unitsTop = [];

  constructor(private setupService: SetupService,
              private messageService: MessageService) { }

  ngOnInit() {
    this.dropSettings();
    this.getEmployeeNames();
    this.getUnits();
    this.getRoles();
  }

  dropSettings() {
    this.dropdownSettings = {
      singleSelection: true,
      text: 'Choose Employee',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsUnit = {
      singleSelection: true,
      text: 'Choose Unit',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };
  }

  getEmployeeNames() {
    this.setupService.getEmployeeNames().subscribe((res: any[]) => {
      console.log('res', res);
      // this.employeeList = res.slice(0, 10);

      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index].userName, id: res[index].id });
      }
      console.log(newData);

      this.userNameListDropdown = this.userNameListDropdown.concat(newData);
      // for (let index = 0; index < res.length; index++) {
      //   const element = res[index];
      //   if (element.userName) {
      //     this.userNameListDropdown.push({ itemName: element.userName, id: element.id });
      //   }
      // }
      // console.log('-----------------Employee List--------', this.employeeList);
    }, err => {
    });
  }

  getUnits() {
    const paginationDetails = {
      pageNumber: -1,
      pageSize: -1
    };
    this.setupService.getUnits(paginationDetails).subscribe((res: any[]) => {
      const newData = [];
        for (let index = 0; index < res.length; index++) {
          newData.push({ itemName: res[index].unitName, id: res[index].id });
        }
        console.log(newData);

        this.unitsTop = this.unitsTop.concat(newData);
      this.units = res;
      for (let i = 0; i < this.units.length; i++) {
        this.units[i].isSelected = false;
        this.units[i].role = null;
        // this.units[i].unitId = this.units[i].id;
      }
      console.log('----Units----', this.units);
    }, err => {
      console.log('Error occured in get units:', err);
    });
  }

  getRoles() {
    this.setupService.getRoles({ pageNumber: -1, pageSize: -1 })
      .subscribe(res => {
        console.log(res);
        // this.roles = res;
        const newData = [];
        for (let index = 0; index < res.length; index++) {
          newData.push({ itemName: res[index].roleName, id: res[index].roleId });
        }
        console.log(newData);

        this.roles = this.roles.concat(newData);
        console.log('this.roles', this.roles);
      });
  }

  assign() {
    Swal.fire({
      title: 'Do you want to assign to more than one unit?',
      //text: 'Once submitted cannot be modified.',
      showCancelButton: true,
      confirmButtonText: 'OK',
      cancelButtonText: 'Cancel'
    }).then((result) => {
      if (result.value) {
        this.sendUnits = _.filter(this.units, (d) => d['isSelected'] == true);
        for (let i = 0; i < this.units.length; i++) {
          this.units[i].unitId = this.units[i].id;
          this.units[i].id = this.employeeDetails.id;
        }

        // for (let i = 0; i < this.selectedUnits.length; i++) {
        //   if (this.selectedUnits[i] != undefined) {
        //     this.sendUnits.push(this.selectedUnits[i]);
        //   }
        // }
        console.log('this.sendUnits', this.sendUnits);
        this.setupService.post(`Employee/MapUnitsToEmployee`, this.units)
          .subscribe(res => {
            console.log(res);
            this.messageService.add({ severity: 'success', summary: `Units`, detail: '' });
          }, (err) => {
            if (err.status == 200) {
              this.messageService.add({ severity: 'success', summary: `Units`, detail: 'Assigned Successfully' });
            }
          });

        this.checkGroup();
      } else {
        Swal.close();
      }
    })
  }

  onSelect(i, e, id) {
    console.log(i, e.target.value);

    if (e.target.checked) {
      this.units[i].isSelected = true;
      // console.log(id);
      // this.selectedUnits[i] = { unit: e.target.value, unitId: id, id: this.employeeId };
      // console.log(this.selectedUnits);
    } else if (!e.target.checked) {
      this.units[i].isSelected = false;
    }

    // console.log(this.selectedUnits);
  }

  getEmployeeByUnit(id) {
    this.setupService.getEmployeeNameByUnit(id)
    .subscribe(res => {
      this.userNameListDropdown = []
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        newData.push({ itemName: res[index].userName, id: res[index].id });
      }
      console.log(newData);

      this.userNameListDropdown = this.userNameListDropdown.concat(newData);

    })
  }

  selectUnit(e) {
    console.log('e', e)
    this.selectedEmployee = [];
    this.units.forEach(res => {
      res.isSelected = false;
    });
    
    this.getEmployeeByUnit(e.id)

  }

  selectRole(i, e) {
    console.log(i, e);
    this.units[i].role = e.target.value;
    // this.selectedUnits[i].role = e.target.value;
    // console.log('this.selectedUnits', this.selectedUnits);
  }

  selectEmployee(e) {
    console.log(e);
    this.employeeId = e.id;
    this.getAssignedUnits(this.employeeId);
    this.isEmployeeSelected = true;
  }

  getAssignedUnits(id) {
    this.employeeDetails = "";
    this.units.forEach(res=>{
      res.isSelected = false;
    });

    this.setupService.get(`Employee/GetEmployeeDataFromMapping/${id}`)
      .subscribe(res => {
        this.employeeDetails = res.item1;
        console.log('this.employeeDetails', this.employeeDetails);
        console.log(res.item2);
        // for (let i = 0; i < this.units.length; i++) {
        //   this.units[i].accountName = this.employeeDetails.accountName;
        //   this.units[i].id = this.employeeDetails.id;
        // }
         for (let i = 0; i < res.item2.length; i++) {
          const index = _.findIndex(this.units, (d) => d['id'] == res.item2[i].unitId);
          if (index != -1) {
            this.units[index].isSelected = res.item2[i].isSelected;
            this.units[index].role = res.item2[i].role;
            // this.units[index].accountName = this.employeeDetails.accountName;
          }
        }
        console.log(this.units);
      });
  }

  checkGroup() {
    this.selectedUnits.forEach(element => {
      if (element.role == undefined) {
        this.isVisible = true;
        return false;
      } else {
        this.isVisible = false;
      }
    });

    // for (const unit of this.selectedUnits) {
    //   console.log(unit.role);
    //   if (unit.role == undefined) {
    //     this.isVisible = true;
    //     return false;
    //   } else {
    //       this.isVisible = false;
    //   }
    // }
  }

}
