import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';

@Component({
  selector: 'app-employeecategory',
  templateUrl: './employeecategory.component.html',
  styleUrls: ['./employeecategory.component.css']
})
export class EmployeecategoryComponent implements OnInit {
  cols: any = [];
  employees: any = [];
  status: Boolean = false;
  submitted: Boolean = false;
  updateEmployeeCategoryData: any;
  updateEmployeeCategoryIdData: any;
  addEmployeeCategoryForm: FormGroup;
  updateEmployeeCategoryForm: FormGroup;
  displayAddEmployeeCategoryDialog: Boolean;
  totalEmployeesCategory: any;
  paginationDetails: any;
  displayUpdateEmployeeCategoryDialog: Boolean;
  update = false;
  loading = true;
  constructor(private fb: FormBuilder, private setupService: SetupService, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {

    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.getEmployeeCategoryColumns();
    this.getTotalNumberOfEmployeeCategory();
    this.getEmployeeCategory(this.paginationDetails);
    this.initializeAddEmployeeCategory();
    this.initializeUpdateEmployeeCAtegory();
  }

  get formFields() { return this.addEmployeeCategoryForm.controls; }

  get editFormFields() { return this.updateEmployeeCategoryForm.controls; }



  initializeAddEmployeeCategory() {
    this.addEmployeeCategoryForm = this.fb.group({
      employeeCategory: ['', Validators.required],
    });
  }

  onEmployeeCategoryPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    console.log('pagination Details For Employee Category', this.paginationDetails);
    this.getEmployeeCategory(this.paginationDetails);
  }

  onStatusChange(value) {
    this.status = value;
  }




  initializeUpdateEmployeeCAtegory() {
    this.updateEmployeeCategoryForm = this.fb.group({
      employeeCategory: ['', Validators.required],
    });
  }


  /* ----------------------------------------------------------Add Employee Category ------------------------------------*/
  addEmployeeCategory() {
    this.submitted = true;
    this.loading = true;
    if (this.addEmployeeCategoryForm.invalid) {
      this.loading = false;
      return this.addEmployeeCategoryForm.value.actionPerformed = null;
    } else {
      if (this.update) {
        const EmployeeCategoryData = this.addEmployeeCategoryForm.value;
        EmployeeCategoryData.EmployeeCategoryId = this.updateEmployeeCategoryIdData.employeeCategoryId;
        EmployeeCategoryData.status = this.status;
        this.setupService.updateEmployeeCategory(EmployeeCategoryData).subscribe((res: any[]) => {
          this.displayAddEmployeeCategoryDialog = false;
          this.update = false;
          this.status = false;
          this.loading = false;
          this.getTotalNumberOfEmployeeCategory();
          this.getEmployeeCategory(this.paginationDetails);
          this.messageService.add({severity: 'success', summary: `${EmployeeCategoryData.employeeCategory}`, detail: 'updated Successfully'});
          console.log('Employee Category Updated Successfulluy');
        }, err => {
          console.log('Error occured in update Employee Category:', err);
          this.loading = false;
        });
      } else {
        const employeeCategoryData = this.addEmployeeCategoryForm.value;
        employeeCategoryData.status = this.status;
        this.setupService.addEmployeeCategory(employeeCategoryData).subscribe((res: any[]) => {
          this.displayAddEmployeeCategoryDialog = false;
          this.status = false;
          this.getEmployeeCategory(this.paginationDetails);
          this.getTotalNumberOfEmployeeCategory();
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `${employeeCategoryData.employeeCategory}`, detail: 'created Successfully'});
          console.log('Employee Category Saved Successfully');
        }, err => {
          console.log('Error occured in add Employee Category', err);
          this.loading = false;
        });
      }

    }
  }

  /*--------------------------------- Update Employee Category ------------------------------*/
  // updateEmployeeCategory(employeeCategory) {
  //   this.submitted = true;
  //   if (this.updateEmployeeCategoryForm.invalid) {
  //     return this.updateEmployeeCategoryForm.value.actionPerformed = null;

  //   }
  //   else {
  //     let EmployeeCategoryData = this.updateEmployeeCategoryForm.value;
  //     EmployeeCategoryData.EmployeeCategoryId = employeeCategory.employeeCategoryId;
  //     EmployeeCategoryData.status = this.status;
  //     this.setupService.updateEmployeeCategory(EmployeeCategoryData).subscribe((res: any[]) => {
  //       this.displayAddEmployeeCategoryDialog = false;
  //       this.update = false;
  //       this.status = false;
  //       this.getTotalNumberOfEmployeeCategory();
  //       this.getEmployeeCategory(this.paginationDetails);
  //       console.log('Employee Category Updated Successfulluy');
  //     }, err => {
  //       console.log('Error occured in update Employee Category:', err);
  //     })
  //   }
  // }


  getEmployeeCategoryColumns() {
    this.cols = [
      { field: 'employeeCategory', header: 'Employee Category' },
      { field: 'actions', header: 'Actions' },
      { field: 'status', header: 'Status' }
    ];
  }
  /* --------------------------------------------Get Employee Category----------------------------------------- */
  getEmployeeCategory(paginationDetails) {

    this.setupService.getEmployeeCategory(paginationDetails).subscribe((res: any[]) => {
      this.employees = res;
      this.loading = false;
    }, err => {
      console.log('Error occured in get employee category:', err);
      this.loading = false;
    });
  }

  /* ------------------------------------------Get Total No Of Employee Category--------------------------------------------- */
  getTotalNumberOfEmployeeCategory() {
    this.setupService.getTotalNumberOfEmployeeCategory().subscribe((data) => {
      this.totalEmployeesCategory = data;
      console.log('-------Employee Count--------', this.totalEmployeesCategory);
    }, err => {
      console.log('error in total Number Of Employee', err);
    });
  }


  /* ---------------------------------------get Employee Category By Id---------------------------------------- */

  getEmployeeCategoryById(employeeCategoryId) {

    this.setupService.getEmployeeCategoryById(employeeCategoryId).subscribe((res: any) => {

      this.updateEmployeeCategoryIdData = res;
      this.addEmployeeCategoryForm.patchValue(res);
      this.status = res.status;
      console.log('-------------Employe Category Id-------', this.updateEmployeeCategoryIdData);
    }, err => {
      console.log('error in Id of Employee category', err);
    });
  }



  showAddEmployeeCategory() {
    this.displayAddEmployeeCategoryDialog = true;
    this.addEmployeeCategoryForm.reset();
    this.submitted = false;
    this.status = false;

  }

  cancelAddEmployeeCategory() {
    this.displayAddEmployeeCategoryDialog = false;
    this.addEmployeeCategoryForm.reset();
    this.update = false;
    this.status = false;
  }

  showUpdateEmployeeCategory(employeeCategoryId: any) {
    this.submitted = false;
    this.getEmployeeCategoryById(employeeCategoryId);
    this.displayAddEmployeeCategoryDialog = true;
    this.update = true;
  }

  cancelUpdateEmployeeCategory() {

    this.displayAddEmployeeCategoryDialog = false;
    this.updateEmployeeCategoryForm.reset();
  }

  exportAsXLSX() {
    if (this.employees.length > 0) {
      this.excelService.exportAsExcelFile(this.employees, 'sample');
    }
  }

}
