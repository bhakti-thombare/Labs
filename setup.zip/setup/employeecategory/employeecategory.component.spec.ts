import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeecategoryComponent } from './employeecategory.component';

describe('EmployeecategoryComponent', () => {
  let component: EmployeecategoryComponent;
  let fixture: ComponentFixture<EmployeecategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EmployeecategoryComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeecategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
