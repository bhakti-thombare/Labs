import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { KaizenService } from 'src/app/kaizen/kaizen.service';
import * as _ from "lodash";
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { MessageService } from 'primeng/api';
import { element } from 'protractor';

@Component({
  selector: 'app-sla-master',
  templateUrl: './sla-master.component.html',
  styleUrls: ['./sla-master.component.css'],
  providers:[MessageService]
})
export class SlaMasterComponent implements OnInit {

  isAddService :boolean= false;
  slaForm:FormGroup;
  updated:boolean= false;
  updateerviceForm:FormGroup
  isUpdateService:boolean=false;
  addServiceForm:FormGroup
  departmentList:any=[];
  uomlist:any=[];
  submitted:boolean=false;
  paginationDetails: any;
  slaData:any=[];
  cols:any=[];
  slaSubmisionList:any=[];
  addsericeDailog:boolean=false;
  selectedForSubmission:boolean=false;
  loading:boolean=false;
  userAccountInfo: any;
  added:boolean=false;
  selectedType:any;
  selectedTypeId:any;
  isTeam:boolean=false;
  isDeparment:boolean=false
  DataForUpdate:any;
  totalsla;
  constructor(
    private fb: FormBuilder,
    private setupService: SetupService,
    private kaizenService :KaizenService,
    private msAdalService : MsAdalAngular6Service,
    private messageService: MessageService

    
  ) { }

  ngOnInit() {
    this.getSLAcolomns();
    this.slaForm=this.fb.group({
      DepartmentSla: [null,Validators.required],
      departments:[null],
      teams:[null]
      
    })
    this.addServiceForm =this.fb.group({
      service:[null, Validators.required],
      uom:[null, Validators.required]
    })

    this.updateerviceForm =this.fb.group({
      service:[null, Validators.required],
      uom:[null, Validators.required],
      id:[null]
    })
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    if (this.msAdalService.isAuthenticated) {
      const username = this.msAdalService.userInfo.userName.split("@")[0];
      this.getUserInfo(username);
    } else {
      //  this.getUserInfoById(localStorage.getItem('UserId'));
    }
   // this.getAllSlaData(this.paginationDetails);
    this.getUomDta();
 //   this.getUserInfo();
  }

  getSlaCount(){
    this.setupService.getSlaCount(this.selectedType,this.selectedTypeId).subscribe(
      res=>{
        this.totalsla=res;
      }
    )
  }
  onChnageType(){
    this.slaData=[];
    this.deparmentError=false;
    this.teamError=false;
    if(this.slaForm.value.DepartmentSla=="DepartmentSla"){
      this.selectedType= 'department'
      this.isDeparment=true;
      
      this.isTeam=false;
      // const dep = this.slaForm.get('departments');
      // if(this.slaForm.get('teams')){
      //   this.slaForm.get('teams').setValidators([null]);
      // }
      
      //  dep.setValidators([Validators.required]);
      this.slaForm.patchValue({
        teams:null
      })
   //   this.selectedTypeId= this.userAccountInfo.departmentId;
    }else{
      this.isDeparment=false;
      this.isTeam=true;
      this.selectedType= 'team';
    //  if( this.slaForm.get('departments')){
    //   this.slaForm.get('departments').setValidators([null]);
    //  }
    //   const tem = this.slaForm.get('teams');
    //     tem.setValidators([Validators.required]);
      // 
      this.slaForm.patchValue({
        departments:null
      })
    //  this.selectedTypeId= this.userAccountInfo.teamId;
    }
    //this.getAllSlaData(this.paginationDetails);
  }
  onchnageTeam(event){
    this.selectedTypeId =event.target.value;
    this.departmentId=null;
    this.departmentName=null;
    this.teamError=null;
    this.teamId=this.selectedTypeId;
    this.teamName=this.teamlist.filter(a=>a.id==+this.teamId)[0].teamName;
    this.getSlaCount();
    this.getAllSlaData(this.paginationDetails);
  }
  departmentId;
  departmentName;
  teamId;
  teamName;
  onchnageDepartment(event){
    this.selectedTypeId =event.target.value;
    this.departmentId=this.selectedTypeId;
    this.departmentName=this.departmentList.filter(a=>a.id==+this.departmentId)[0].departmentName;
    this.deparmentError=null;
    this.teamId=null;
    this.teamName=null;
    this.getSlaCount();
    this.getAllSlaData(this.paginationDetails)
    

  }
  getSLAcolomns(){
    this.cols=[
      {field:'service',header:'Service'},
      {field:'UOM',header:'UOM'},
      {field:'Action',header:'Action'},
     
      
    ]
  }
  onSLaPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows,
    };
    this.getAllSlaData(this.paginationDetails);
  }
  get formFields() {
    return this.addServiceForm.controls;
  }
  get updateformFields() {
    return this.updateerviceForm.controls;
  }
  get formFieldsSla() {
    return this.slaForm.controls;
  }

  getUserInfo(userId) {
    this.loading=true;
    this.kaizenService
      .getWithParam(
        "RpmMapping/GetRpmMappingForEmployee/username",
        userId,
        "admin"
      )
      .subscribe(
        (res: any) => {
          console.log("res", res);
          const unitId = sessionStorage.getItem("unitId");
          const index = _.findIndex(res, (d) => d["item2"].unitId == unitId);
          this.userAccountInfo= res[0]["item2"];
          
      
          this.getDepartmentsByUnit(unitId);
          this.getEmployeeTeamByUnit(unitId)
        
        },
        (err) => {
          console.log("err", err);
        }
      );
  }
  getDepartmentsByUnit(id) {
    this.kaizenService
      .get(`department/getDepartmentByUnit/${id}`, "admin")
      .subscribe((res) => {
        this.departmentList = res;
        this.loading=false;
        //this.DepartmentId=res.id
      });
  }
  getdepartments(){

  }
  showService(){
  //  debugger;
    this.added=true;
    if(this.slaForm.value.DepartmentSla=="DepartmentSla"){
      if(!this.slaForm.value.departments){
         this.deparmentError=true;
         this.teamError=false;
         return
      }
    }else{

      if(this.slaForm.value.DepartmentSla=="TeamSla")
      if(!this.slaForm.value.teams){
        this.deparmentError=false;
        this.teamError=true;
        return
     }
    }
  
    if(this.slaForm.valid){
      this.isAddService=true;
    }
   
  }
   getUomDta(){
     this.setupService.getUom().subscribe(
       res=>{
        this.uomlist=res;
       }
     )
   }
   teamlist:any=[];
   getEmployeeTeamByUnit(unitId){
     this.setupService.getEmployeeTeamByUnit(unitId).subscribe(
       res=>{
        this.teamlist= res;
       },
       error=>{

       }
     )
   }
  getAllSlaData(paginationDetails){
   this.loading=true;
    const userRole = sessionStorage.getItem("userRole").split(" ").join("-"); 
    this.setupService.getAllSlaData(paginationDetails,this.selectedType,userRole,this.selectedTypeId).subscribe(
      res=>{
          this.slaData= res;
          this.loading=false;
          
      },
      error=>{

      }
    )

  }
  isSelectedForSubmission() {
    return true;
}
 submitAllSla(value){
  
  if (value) {
    console.log('onAwardToAll clicked');

    for (let index = 0; index < this.slaData.length; index++) {
        const element = this.slaData[index];
      
        if (!element.isChecked) {
       
            this.slaSubmisionList.push(element.id);

        }
    }
    if (this.slaSubmisionList.length > 0) {
        this.selectedForSubmission = true;
    }
 
}


if (!value) {
    this.slaSubmisionList = null;
    this.slaSubmisionList = [];
    // tslint:disable-next-line: triple-equals
    if (this.slaSubmisionList.length == 0) {
        this.selectedForSubmission = false;
    }

}

 } 

 singleSlaSelected(value, rowData){
  // debugger;
  if (value) {
    console.log('onAwardToAll clicked');

    for (let index = 0; index < this.slaData.length; index++) {
        const element = this.slaData[index];
      
        if (element.id==rowData.id) {
       
            this.slaSubmisionList.push(element.id);

        }
    }
    if (this.slaSubmisionList.length > 0) {
       // this.selectedForSubmission = true;
    }
 
}


if (!value) {
  //  this.slaSubmisionList = null;
    // this.slaSubmisionList = [];
    for (let index = 0; index < this.slaData.length; index++) {
      const element = this.slaData[index];
    
      if (element.id==rowData.id) {
     
          this.slaSubmisionList.splice( this.slaSubmisionList.indexOf(rowData.id),1);

      }
  }
   

}

 }
 selectedSla(rowData){
   ;
  if(!rowData.isChecked){
    this.slaSubmisionList.push(rowData.id);
  }else{
   let p= this.slaSubmisionList.findIndex(rowData.id)
  }
  //if()
  


 }
 submitSelectedSla(){
 // debugger;
  if(this.slaSubmisionList.length >0){
    this.loading=true;
    this.setupService.submitSelectedSla(this.slaSubmisionList).subscribe(
      res=>{
       // this.slaSubmisionList=[];
        this.addSLAtoTeamActivity(res);
        //this.loading=false;
        this.messageService.add({ severity: 'success', summary: 'SLA', detail: 'SLA Submitted  Successfully' });
        this.getSlaCount();
        this.getAllSlaData(this.paginationDetails);
      },
      error=>{

      }
    )
  }
 }

 deparmentError:boolean=false;
 teamError:boolean=false;
 addservice(){
  this.submitted=true;
    if(this.addServiceForm.valid){

    // let data={
    // "Service" : "RR test",
  	// "Uom" : "%",
	  // "SupplierDepartmentId" : null,
	  // "SupplierDepartment" : null,
	  // "SupplierDepartmentHod" : null,
	  // "SupplierTeamId" : "110", 
	  // "SupplierTeam" : null,
	  // "SupplierTeamLeader" : null,
	  // "FiscalYear" : 9,
	  // "IsChecked" : true,
	  // "CreatedBy" : "abgplanet\\utclmfg.cloudsupportl"
    // }
  let data;
  data={
    Service : this.addServiceForm.value.service,
    Uom: this.uomlist.filter(a=>a.id==this.addServiceForm.value.uom)[0].uom ,
    SupplierDepartmentId: this.departmentId,
    SupplierDepartment:this.departmentName,
    IsChecked:false,
    CreatedBy:this.userAccountInfo.accountName[0],
    SupplierTeamId:this.teamId,
    SupplierTeam:this.teamName,
    SupplierTeamLeader:null,
    //FiscalYear:9
  }
    // if(this.slaForm.value.DepartmentSla=="DepartmentSla"){
    //    data={
    //     Service : this.addServiceForm.value.service,
    //     Uom: this.addServiceForm.value.uom,
    //    // SupplierDepartmentId: this.sele,
    //     SupplierDepartment:this.userAccountInfo.department,
    //     IsChecked:false,
    //     CreatedBy:this.userAccountInfo.accountName[0],
    //     SupplierTeamId:null,
    //     SupplierTeam:null,
    //     SupplierTeamLeader:null,
    //     FiscalYear:9
    //     }
    // }else{
    //   data={
    //     Service : this.addServiceForm.value.service,
    //     Uom: this.addServiceForm.value.uom,
    //     SupplierDepartmentId: null,
    //     SupplierDepartment:null,
    //     IsChecked:false,
    //     CreatedBy:this.userAccountInfo.accountName[0],
    //     SupplierTeamId:this.userAccountInfo.team,
    //     SupplierTeam:this.userAccountInfo.teamId,
    //     SupplierTeamLeader:null,
    //     FiscalYear:9
    //     }
    // }
    let type= this.departmentId?'department':'team';
   this.loading=true;
    this.setupService.addService(data,type).subscribe(
      res=>{
        this.isAddService=false;
        this.messageService.add({ severity: 'success', summary: 'SLA', detail: 'SLA Created  Successfully' });
       // this.addSLAtoTeamActivity(data,type);
       this.addServiceForm.patchValue({
        service:null,
        uom:null
       })
        this.getSlaCount();
        this.getAllSlaData(this.paginationDetails);
        this.loading=false;
      }
    )
  }
 }
 addSLAtoTeamActivity(data){
 //  debugger;
   this.setupService.addSlatoTeamActivity(data).subscribe(
     res=>{
       this.loading=false;
       this.messageService.add({ severity: 'success', summary: 'SLA', detail: 'SLA Submitted Successfully' });
     }
   )
 }
 updateService(){
  this.updated=true;
  this.DataForUpdate;
 // debugger;
 //let t= this.uomlist.filter(a=>a.uom==this.updateerviceForm.value.uom)[0].uom;
  if(this.updateerviceForm.valid){
    let data;
    this.DataForUpdate.service=this.updateerviceForm.value.service;
    this.DataForUpdate.uom= this.uomlist.filter(a=>a.uom==this.updateerviceForm.value.uom)[0].uom
  // data={
  //   SLANo:this.updateerviceForm.value.id,
  //   Service : this.updateerviceForm.value.service,
  //   Uom: this.uomlist.filter(a=>a.uom==this.updateerviceForm.value.uom)[0].uom,
  //   SupplierDepartmentId: this.departmentId,
  //   SupplierDepartment:this.departmentName,
  //   IsChecked:false,
  //   CreatedBy:this.userAccountInfo.accountName[0],
  //   SupplierTeamId:this.teamId,
  //   SupplierTeam:this.teamName,
  //   SupplierTeamLeader:null,
  //   FiscalYear:9
  // }
  let type= this.departmentId?'department':'team';
  this.loading=true;
    this.setupService.UpdateSLa(this.DataForUpdate).subscribe(
      res=>{
        this.isUpdateService=false;
        this.messageService.add({ severity: 'success', summary: 'SLA', detail: 'SLA Updated  Successfully' });
        this.getSlaCount();
        this.getAllSlaData(this.paginationDetails);
        this.loading=false;
      }
    )
  
  }
 }
 getSlaForUpdate(selectedSla){
   this.loading= true;
   this.isUpdateService=true;
   this.DataForUpdate=selectedSla
   this.updateerviceForm.patchValue({
    service:selectedSla.service,
    uom:selectedSla.uom,
    id:selectedSla.id
   })
this.loading=false;
  
 }
 closeService(){
   this.isAddService=false;
   this.submitted=false;
   this.addServiceForm.patchValue({
    service:null,
    uom:null
  })
 }
 closeServiceUpdate(){
   this.isUpdateService=false;
   this.updateerviceForm.patchValue({
    service:null,
    uom:null
   })
 }

}
