import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import * as _ from 'lodash';
import { UserinfoService } from 'src/app/configuration/userinfo.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';
@Component({
  selector: 'app-function',
  templateUrl: './function.component.html',
  styleUrls: ['./function.component.css'],
})
export class FunctionComponent implements OnInit {
  cols: any = [];
  functionHeadDropDownLists: any = [];
  functions: any = [];
  functionsNames: any = [];
  displayAddFunctionDialog: Boolean;
  // status: Boolean = false;
  displayUpdateFunctionDialog: Boolean;
  addFunctionForm: FormGroup;
  paginationDetails: any;
  selectedFunctionHeads: any[] = [];

  totalFunctions: any[];
  updateFunctionData: any;
  updateFunctionForm: FormGroup;
  submitted: Boolean = false;
  functionHeads = [];
  emailID = [];
  selectedIds: any;
  dropdowns: any[];
  updatedHeadSel = [];
  uniqList = [];
  update = false;
  dropdownSettings = {};
  dropdownSettingsFn = {};
  loading = true;
  functionLoading = false;
  headLoading = false;
  nameLoading = false;
  searchForm: FormGroup;
  searchFunction = false;
  alreadyCreated = false;

  constructor(private formBuilder: FormBuilder, private setupService: SetupService,
    private userInfo: UserinfoService, private msAdalService: MsAdalAngular6Service, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {

    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm = this.formBuilder.group({
      userName: ['', Validators.required]
    });
    this.getTotalNumberOfFunctions();
    this.initializeAddFunctionForm();
    this.initializeUpdateFunctionForm();
    this.getFunctionColumns();
    this.getFunctions(this.paginationDetails);
    this.getFunctionsNames();
    this.getFunctionHeadList();
    this.dropSettings();
    // const userId = this.msAdalService.userInfo.userName.split('@')[0];
    // this.getUserInfo(userId);
  }

  search() {
    this.searchFunction = true;
    this.setupService.
    get(`Admin/SearchFromName/${this.paginationDetails.pageNumber}/${this.paginationDetails.pageSize}?queryString=${this.searchForm.value.userName}&searchFor=Function`)
      .subscribe(res => {
        console.log(res);
        this.totalFunctions = res.item1;
        this.functions = res.item2;
      });
  }

  reset() {
    this.searchFunction = false;
    const pagination = {
      pageNumber: 0,
      pageSize: 5
    };
    this.searchForm.reset();
    this.getTotalNumberOfFunctions();
    this.getFunctions(pagination);
  }

  /* Pagination */
  onFunctionPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    if (this.searchFunction) {
      this.search();
    } else {
      console.log('------Pagination Details After Page Change-----', this.paginationDetails);
      this.getFunctions(this.paginationDetails);
    }
  }

  dropSettings() {
    this.dropdownSettings = {
      singleSelection: false,
      text: 'Choose Function Head',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsFn = {
      singleSelection: true,
      text: 'Choose Function Name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };
  }


  /*  onStatusChange(value) {
     this.status = value;
   } */

  get formFields() { return this.addFunctionForm.controls; }

  get editFormFields() { return this.updateFunctionForm.controls; }

  /* Initialize the function Form */
  initializeAddFunctionForm() {
    this.addFunctionForm = this.formBuilder.group({
      functionName: [null, Validators.required],
      functionHead: [null],
      status: [true]
    });
  }
  /* Initialize the Update Function form */
  initializeUpdateFunctionForm() {
    this.updateFunctionForm = this.formBuilder.group({
      functionName: [null, Validators.required],
      functionHead: [null],
      status: [null]

    });
  }
  /* Submit Add function Form */
  addFunction() {
    this.submitted = true;
    this.loading = true;

    if (this.addFunctionForm.invalid) {
      this.loading = false;
      return this.addFunctionForm.value.actionPerformed = 'null';
    } else {

      if (this.update) {
        //  this.updateFunctionForm.value.actionPerformed = 'Submit';

        const updateFunctionData = this.addFunctionForm.value;
        updateFunctionData.id = this.updateFunctionData.id;
        const functionName = updateFunctionData.functionName[0].itemName;
        const idArr = [];

        if (updateFunctionData.functionHead != null) {
          for (let i = 0; i < updateFunctionData.functionHead.length; i++) {
            idArr[i] = '' + updateFunctionData.functionHead[i].id;
          }
          updateFunctionData.functionHead = idArr;
        }

        updateFunctionData.functionName = functionName;
        updateFunctionData.unitId = '' + sessionStorage.getItem('unitId');

        // const functionHeadArray = updateFunctionData.functionHead;
        // updateFunctionData.functionHead = functionHeadArray.map(value => value.userName);
        // updateFunctionData.functionHeadEmailId = functionHeadArray.map(value => value.emailId);
        // updateFunctionData.status = this.status;
        /* let filteredData: any = this.functionHeads.filter(res =>
          this.updateFunctionForm.value.functionHead == res.userName)[0];
          updateFunctionData.functionHeadEmailId = filteredData.emailId; */
        this.setupService.updateFunction(updateFunctionData).subscribe((res: any[]) => {
          this.displayAddFunctionDialog = false;
          // this.status = false;

          this.getTotalNumberOfFunctions();
          this.getFunctions(this.paginationDetails);
          console.log('function Updated Successfulluy');
          this.update = false;
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `${functionName}`, detail: 'Updated Successfully'});
        }, err => {
          this.loading = false;
          this.update = false;
          console.log('Error occured in update function:', err);
        });
      } else {
        const functionData = this.addFunctionForm.value;
        // functionData.status = this.status;

        /* let filteredData: any = this.functionHeads.filter(res =>
          this.addFunctionForm.value.functionHead == res.userName)[0];
        functionData.functionHeadEmailId = filteredData.emailId; */

        const functionHeadArray = functionData.functionHead;
        const functionName = functionData.functionName[0].itemName;
        console.log('functionData.functionName', functionData.functionName);
        console.log('functionHeadArray', functionHeadArray);
        const idArr = [];
        // functionData.functionHead = functionHeadArray.map(value => value.id);
        if (functionHeadArray != null) {
          for (let i = 0; i < functionHeadArray.length; i++) {
            idArr[i] = '' + functionHeadArray[i].id;
          }

          functionData.functionHead = idArr;
        } else {
          functionData.functionHead = functionHeadArray;
        }
        // functionData.functionHeadEmailId = functionHeadArray.map(value => value.emailId);
        functionData.functionName = functionName;
        functionData.unitId = '' + sessionStorage.getItem('unitId');

        this.setupService.addFunction(functionData).subscribe((res: any[]) => {
          this.displayAddFunctionDialog = false;
          // this.status = false;
          this.getTotalNumberOfFunctions();
          this.getFunctions(this.paginationDetails);
          console.log('Function Saved Successfully');
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `${functionName}`, detail: 'created Successfully'});
        }, err => {
          this.loading = false;
          console.log('Error occured in add Function:', err);
        });
      }
    }

  }

  OnFunctionNameSelect(e) {
    console.log(e);
    let functions = [];
    if (!this.update) {
      this.setupService.getFunctions({pageNumber: -1, pageSize: -1})
      .subscribe(res => {
        console.log(res);
        functions = res;
      const index = _.findIndex(functions, (d) => d['functionName'] === e.id);

      if (index != -1) {
        this.setupService.getFunctionById(functions[index].id)
          .subscribe(res => {
            console.log(res);
            if (res['status'] == true) {
              this.alreadyCreated = true;
            } else {
              this.alreadyCreated = false;
            }
          });
      }
    });
    }
  }

  /* Submit Update Function Form */
  updateFunction(functions) {
    this.submitted = true;
    if (this.updateFunctionForm.invalid) {
      return this.updateFunctionForm.value.invalid = null;
    } else {
      //  this.updateFunctionForm.value.actionPerformed = 'Submit';

      const updateFunctionData = this.updateFunctionForm.value;
      updateFunctionData.id = functions.id;
      const idArr = [];
      for (let i = 0; i < updateFunctionData.functionHead.length; i++) {
        idArr[i] = '' + updateFunctionData.functionHead[i];
      }
      updateFunctionData.functionHead = idArr;

      // const functionHeadArray = updateFunctionData.functionHead;
      // updateFunctionData.functionHead = functionHeadArray.map(value => value.userName);
      // updateFunctionData.functionHeadEmailId = functionHeadArray.map(value => value.emailId);
      // updateFunctionData.status = this.status;
      /* let filteredData: any = this.functionHeads.filter(res =>
        this.updateFunctionForm.value.functionHead == res.userName)[0];
        updateFunctionData.functionHeadEmailId = filteredData.emailId; */
      this.setupService.updateFunction(updateFunctionData).subscribe((res: any[]) => {
        this.displayAddFunctionDialog = false;
        // this.status = false;

        this.getTotalNumberOfFunctions();
        this.getFunctions(this.paginationDetails);
        console.log('function Updated Successfulluy');
        this.update = false;
      }, err => {
        this.update = false;
        console.log('Error occured in update function:', err);
      });
    }
  }

  /* Get Functions */
  getFunctionColumns() {
    this.cols = [
      { field: 'id', header: 'ID' },
      { field: 'functionName', header: 'Function Name' },
      { field: 'functionHead', header: 'Function Head' },
      { field: 'action', header: 'Action' },
      { field: 'status', header: 'Status' }
    ];
  }
  /* ------------------------------------------------------Get Function Head list------------------------------ */
  getFunctionHeadList() {
    this.headLoading = true;
    this.setupService.getFunctionHeadList().subscribe((res: any[]) => {
      console.log('res', res);
      this.dropdowns = res;
      console.log('this.dropdowns', this.dropdowns);
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({ itemName: element.userName, id: element.id });
          // this.functionHeadDropDownLists.push({ label: element.userName, value: element.userName })
        }
      }

      this.functionHeadDropDownLists = this.functionHeadDropDownLists.concat(newData);
      this.headLoading = false;
      this.loadOninit();
    }, err => {
      this.headLoading = false;
      this.loadOninit();
    });
  }

  /* Get Functions */
  getFunctions(paginationDetails) {
    this.functionLoading = true;
    this.searchFunction = false;
    this.setupService.getFunctions(this.paginationDetails).subscribe((res: any[]) => {
      this.functions = res;
      this.functionLoading = false;
      this.loadOninit();

    }, err => {
      console.log('Error occured in get functions:', err);
      this.functionLoading = false;
      this.loadOninit();
    });
  }
  /* Get Function by id */
  getFunctionById(id) {
    this.setupService.getFunctionById(id).subscribe((res: any) => {
      console.log('res', res);
      this.updateFunctionData = res;
      const selectedHeads = [];
      // this.addFunctionForm.patchValue(res);
      this.addFunctionForm.patchValue({
        status: res.status
      });

      if (this.updateFunctionData.functionHead != null) {
        for (let i = 0; i < this.updateFunctionData.functionHead.length; i++) {
          const index = _.findIndex(this.functionHeadDropDownLists, (d) => d['itemName'] === this.updateFunctionData.functionHead[i]);
          console.log(index);
          if (index != -1) {
            selectedHeads.push(this.functionHeadDropDownLists[index]);
          }
        }
        console.log(selectedHeads);
        this.addFunctionForm.patchValue({
          functionHead: selectedHeads
        });
      }

      const selectedName = [];
        const index = _.findIndex(this.functionsNames, (d) => d['itemName'] === this.updateFunctionData.functionName);
        console.log(index);
        selectedName.push(this.functionsNames[index]);
        this.addFunctionForm.patchValue({
          functionName: selectedName
        });
    });
  }
  /* Get Total number of Functions */
  getTotalNumberOfFunctions() {
    this.setupService
      .getTotalNumberOffunctions()
      .subscribe((data) => {
        this.totalFunctions = data;
        console.log('-----totalDepartments-----', this.totalFunctions);

      });
  }


  /* Get Function Name dropdown */
  getFunctionsNames() {
    this.nameLoading = true;
    this.setupService.getFunctionsNames().subscribe((res: any[]) => {

      const newData = [];
      for (let index = 0; index < res.length; index++) {
          newData.push({ itemName: res[index], id: res[index] });
          // this.functionHeadDropDownLists.push({ label: element.userName, value: element.userName })
      }
      console.log(newData);

      this.functionsNames = this.functionsNames.concat(newData);

      console.log('----Functions Names Levels----', this.functionsNames);
      this.nameLoading = false;
      this.loadOninit();

    }, err => {
      console.log('Error occured in get functions name:', err);
    });
  }

  getUserInfo(userId) {
    this.setupService
      .getWithParam('RpmMapping/GetRpmMappingForEmployee/username', userId)
      .subscribe((res: any) => {
        console.log('res', res);
        // this.kaizenService.storeUnitId(res.item2.unitId);
        this.userInfo.roleName = res.item1;
        this.userInfo.userData = res.item2;
        // this.loggedInData = res.item2;
        // this.GetRoleBasedData();
        console.log(this.userInfo.userData.unitId);
      }, (err) => {
        console.log('err', err);
      });
  }



  /* Cancel  */
  cancelAddFunctionDialog() {
    this.displayAddFunctionDialog = false;
    this.addFunctionForm.reset();
    this.submitted = false;
    // this.status = false;
    this.update = false;
    this.alreadyCreated = false;
    this.addFunctionForm.reset();
  }

  cancelUpdateFunctionDialog() {
    this.displayAddFunctionDialog = false;
    // this.functionHeadDropDownLists = []
    this.updateFunctionForm.reset();
    this.submitted = false;

  }
  /* Show the Dialog Box */

  showFunctionDialog() {
    this.displayAddFunctionDialog = true;
    this.submitted = false;
    this.initializeAddFunctionForm();
    // this.status = false;
  }
  showUpdateFunctionDialog(id: any) {
    this.getFunctionById(id);
    // this.updateFunctionForm.reset();
    this.submitted = false;
    this.displayAddFunctionDialog = true;
    this.update = true;
    // this.initializeUpdateFunctionForm();
  }


  select(e) {
    console.log(e);
    this.selectedIds = e.value;
  }

  updateSelect(e) {
    console.log(e);
    if (typeof e.itemValue === 'number') {
      const removedIndex = _.findIndex(this.updatedHeadSel, (d) => d == e.itemValue);
      if (removedIndex !== -1) {
        this.updatedHeadSel.splice(removedIndex, 1);
      } else {
        this.updatedHeadSel.push(e.itemValue);
      }
    } else {
      console.log('itemValue Type', typeof e.itemValue === 'number');
      const index = _.findIndex(this.dropdowns, (d) => d.userName == e.itemValue);
      console.log(index);
      if (index !== -1) {
        console.log(this.dropdowns[index].id);
        const indexVal = this.dropdowns[index].id;
        const removedIndex = _.findIndex(this.updatedHeadSel, (d) => d == indexVal);
        console.log(removedIndex);
        if (removedIndex !== -1) {
          this.updatedHeadSel.splice(removedIndex, 1);
        } else {
          this.updatedHeadSel.push(this.dropdowns[index].id);
        }
      } else {
        const removedIndex = _.findIndex(this.updatedHeadSel, (d) => d == e.itemValue);
        if (removedIndex == -1) {
          this.updatedHeadSel.push(e.itemValue);
        }
      }
    }
    // this.updatedHeadSel.push(this.dropdowns[index].id)
    //  this.updatedHeadSel.push(e.itemValue)
    console.log(this.updatedHeadSel);

  }

  loadOninit() {
  if (!this.functionLoading && !this.headLoading && !this.nameLoading) {
    this.loading = false;
  }
  }

  exportAsXLSX() {
    if (this.functions.length > 0) {
      this.excelService.exportAsExcelFile(this.functions, 'sample');
    }
  }


}
