import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProficiencylevelComponent } from './proficiencylevel.component';

describe('ProficiencylevelComponent', () => {
  let component: ProficiencylevelComponent;
  let fixture: ComponentFixture<ProficiencylevelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ProficiencylevelComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProficiencylevelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
