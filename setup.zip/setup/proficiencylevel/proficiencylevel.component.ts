import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';
@Component({
  selector: 'app-proficiencylevel',
  templateUrl: './proficiencylevel.component.html',
  styleUrls: ['./proficiencylevel.component.css']
})
export class ProficiencylevelComponent implements OnInit {
  cols: any = [];
  proficiencies: any = [];
  addProficiencyDialog: Boolean;
  submitted: Boolean = false;
  status: Boolean = true;
  updateProficiencyDialog: Boolean;
  totalProficiencyLevel: any;
  paginationDetails: any;
  updateProficiencyLevelData: any;
  addProficiencyForm: FormGroup;
  updateProficiencyForm: FormGroup;
  update = false;
  loading = true;
  isPowerUser:boolean=false;
  constructor(private fb: FormBuilder, private setupService: SetupService, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {

    this.getUserRole()
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
   
    this.getProficiencies(this.paginationDetails);
    this.initializeAddProficiencyForm();
    this.initializeUpdateProficiencyForm();
    this.getProficiencyTotalCount();
  }

  get formFields() { return this.addProficiencyForm.controls; }

  get editFormFields() { return this.updateProficiencyForm.controls; }


  getUserRole(){
    let userRole= sessionStorage.getItem('userRole');
    if(userRole=="Power User"){
      this.isPowerUser=true;
    }
    this.getProficiencyColumns();

  }


  initializeAddProficiencyForm() {
    this.addProficiencyForm = this.fb.group({
      proficiencyLevelName: ['', Validators.required],
      status: [true, Validators.compose([])]
    });
  }

  onProficiencyLevelPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows,
    };
    console.log('--------------pagination Details---------');
    this.getProficiencies(this.paginationDetails);
  }

  onStatusChange(value) {
    this.status = value;
  }
  initializeUpdateProficiencyForm() {
    this.updateProficiencyForm = this.fb.group({
      proficiencyLevelName: ['', Validators.required],
      // status:[true,Validators.required]

    });
  }

  addProficiency() {
    this.submitted = true;
    this.loading = true;
    if (this.addProficiencyForm.invalid) {
      this.loading = false;
      return this.addProficiencyForm.value.actionPerformed = null;
    } else {
      if (this.update) {
        const proficiencyData = this.addProficiencyForm.value;

        proficiencyData.ProficiencyLevelId = this.updateProficiencyLevelData.proficiencyLevelId;
        proficiencyData.status = this.status;
        this.setupService.updateProficiency(proficiencyData).subscribe((res: any[]) => {
          this.addProficiencyDialog = false;
          this.status = true;
          this.update = false;
          this.getProficiencyTotalCount();
          this.getProficiencies(this.paginationDetails);
          console.log('Proficiency Updated Successfulluy');
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `Proficiency Level`, detail: 'updated Successfully'});
        }, err => {
          this.loading = false;
          console.log('Error occured in proficiency department:', err);
        });
      } else {
        const proficiencyData = this.addProficiencyForm.value;
        proficiencyData.status = this.status;
        this.setupService.addProficiency(proficiencyData).subscribe((res: any[]) => {
          this.addProficiencyDialog = false;
          this.getProficiencyTotalCount();
          this.getProficiencies(this.paginationDetails);
          console.log('Proficiency Saved Successfully');
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `Proficiency Level`, detail: 'added Successfully'});
        }, err => {
          this.loading = false;
          console.log('Error occured in add department:', err);
        });
      }
    }
  }

  /* update Proficiency */
  // updateProficiency(proficiencyLevel) {
  //   this.submitted = true;

  //   if (this.updateProficiencyForm.invalid) {
  //     return this.updateProficiencyForm.value.actionPerformed = null;
  //   }
  //   let proficiencyData = this.updateProficiencyForm.value;

  //   proficiencyData.ProficiencyLevelId = proficiencyLevel.proficiencyLevelId;
  //   proficiencyData.status = this.status;
  //   this.setupService.updateProficiency(proficiencyData).subscribe((res: any[]) => {
  //     this.addProficiencyDialog = false;
  //     this.status = true;
  //     this.update = false;
  //     this.getProficiencyTotalCount();
  //     this.getProficiencies(this.paginationDetails);
  //     console.log('Proficiency Updated Successfulluy');
  //   }, err => {
  //     console.log('Error occured in proficiency department:', err);
  //   })
  // }

  getProficiencyColumns() {
    if(sessionStorage.getItem('userRole')!="Power User"){
    this.cols = [
      { field: 'proficiencyLevelName', header: 'Proficiency Level' },
      { field: 'action', header: 'Action' },
      { field: 'status', header: 'Status' }
    ];
  }
  else{
    this.cols = [
      { field: 'proficiencyLevelName', header: 'Proficiency Level' },
    
      { field: 'status', header: 'Status' }
    ];
  }
  }

  getProficiencies(paginationDetails) {

    this.setupService.getProficiencies(paginationDetails).subscribe((res: any[]) => {
      this.proficiencies = res;
      this.loading = false;
    }, err => {
      console.log('Error occured in get departments:', err);
      this.loading = false;
    });
  }

  /* ------------------------GEt Proficiency total COunt--------------------- */
  getProficiencyTotalCount() {
    this.setupService.getProficiencyTotalCount().subscribe((data) => {
      this.totalProficiencyLevel = data;
      console.log('---------pagination Details--------', this.totalProficiencyLevel);
    },
      err => { });
  }

  /* -------------------Get proficiency Level By Id */
  getProficiencyLevelById(proficiencyLevelId) {
    this.setupService.getProficiencyLevelById(proficiencyLevelId).subscribe((res: any[]) => {

      this.updateProficiencyLevelData = res;
      this.addProficiencyForm.patchValue(res);
      this.status = this.updateProficiencyLevelData.status;

    }, err => {

    });
  }


  showAddProficiencyDialog() {
    this.addProficiencyDialog = true;
    this.addProficiencyForm.reset();
    this.submitted = false;
    this.status = true;
    this.update = false;
  }

  cancelAddProficiencyDialog() {
    this.addProficiencyDialog = false;
    this.addProficiencyForm.reset();
    this.status = true;
    this.update = false;
  }
  showUpdateProficiencyDialog(proficiencyLevelId: any) {
    this.submitted = false;
    this.getProficiencyLevelById(proficiencyLevelId);
    this.addProficiencyDialog = true;
    this.status = true;
    this.update = true;
  }
  cancelUpdateProficiencyDialog() {

    this.addProficiencyDialog = false;
    this.updateProficiencyForm.reset();
  }

  exportAsXLSX() {
    if (this.proficiencies.length > 0) {
      this.excelService.exportAsExcelFile(this.proficiencies, 'sample');
    }
  }
}
