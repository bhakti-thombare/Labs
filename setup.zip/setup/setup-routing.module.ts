import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SetuphomeComponent } from './setuphome/setuphome.component';

import { AreaComponent } from './area/area.component';
import { UnitComponent } from './unit/unit.component';
import { TeamComponent } from './team/team.component';
import { SubcommitteeComponent } from './subcommittee/subcommittee.component';
import { SubcommitteenamesComponent } from './subcommitteenames/subcommitteenames.component';
import { SectionsComponent } from './sections/sections.component';
import { SectionnamesComponent } from './sectionnames/sectionnames.component';
import { RolesComponent } from './roles/roles.component';
import { RoleprivelegesComponent } from './rolepriveleges/rolepriveleges.component';
import { ProficiencylevelComponent } from './proficiencylevel/proficiencylevel.component';
import { PositionComponent } from './position/position.component';
import { MonthsComponent } from './months/months.component';
import { KeyfocusareasComponent } from './keyfocusareas/keyfocusareas.component';
import { ImprovementareaComponent } from './improvementarea/improvementarea.component';
import { FunctionComponent } from './function/function.component';
import { FunctionnamesComponent } from './functionnames/functionnames.component';
import { FinancialyearsComponent } from './financialyears/financialyears.component';
import { EvaluatorComponent } from './evaluator/evaluator.component';
import { EvaluationscoringparametersComponent } from './evaluationscoringparameters/evaluationscoringparameters.component';
import { EquipmentComponent } from './equipment/equipment.component';
import { EmployeecategoryComponent } from './employeecategory/employeecategory.component';
import { EmployeeComponent } from './employee/employee.component';
import { DepartmentnamesComponent } from './departmentnames/departmentnames.component';
import { DepartmentComponent } from './department/department.component';
import { QcdipComponent } from './qcdip/qcdip.component';
import { AssignUnitsComponent } from './assign-units/assign-units.component';
import{ SlaMasterComponent} from './sla-master/sla-master.component'
import { BehaviouralServiceComponent } from './behavioural-service/behavioural-service.component';
import { ConfigurationListComponent } from './configuration-list/configuration-list.component';


const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: '',
    children: [
      { path: 'home', component: SetuphomeComponent },
      { path: 'area', component: AreaComponent },
      { path: 'unit', component: UnitComponent },
      { path: 'team', component: TeamComponent },
      { path: 'subcommittee', component: SubcommitteeComponent },
      { path: 'subcommittee-names', component: SubcommitteenamesComponent },
      { path: 'sections', component: SectionsComponent },
      { path: 'section-names', component: SectionnamesComponent },
      { path: 'roles', component: RolesComponent },
      { path: 'roles-priveleges', component: RoleprivelegesComponent },
      { path: 'proficiency-level', component: ProficiencylevelComponent },
      { path: 'position', component: PositionComponent },
      { path: 'months', component: MonthsComponent },
      { path: 'keyfocus-area', component: KeyfocusareasComponent },
      { path: 'improvement-area', component: ImprovementareaComponent },
      { path: 'function', component: FunctionComponent },
      { path: 'function-names', component: FunctionnamesComponent },
      { path: 'financial-years', component: FinancialyearsComponent },
      { path: 'evaluator', component: EvaluatorComponent },
      { path: 'evaluation-scoring-parameters', component: EvaluationscoringparametersComponent },
      { path: 'equipment', component: EquipmentComponent },
      { path: 'employee-category', component: EmployeecategoryComponent },
      { path: 'employee', component: EmployeeComponent },
      { path: 'department-names', component: DepartmentnamesComponent },
      { path: 'department', component: DepartmentComponent },
      { path: 'qcdip-parameters', component: QcdipComponent },
      { path: 'assign-units', component: AssignUnitsComponent},
      { path: 'sla-master', component: SlaMasterComponent},
      {path:'behavioural-service',component:BehaviouralServiceComponent},
      {path:'configuration-list',component:ConfigurationListComponent}
    ]
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SetupRoutingModule { }
