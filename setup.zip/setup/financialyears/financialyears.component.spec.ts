import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialyearsComponent } from './financialyears.component';

describe('FinancialyearsComponent', () => {
  let component: FinancialyearsComponent;
  let fixture: ComponentFixture<FinancialyearsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FinancialyearsComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialyearsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
