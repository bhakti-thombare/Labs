import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';
@Component({
  selector: 'app-financialyears',
  templateUrl: './financialyears.component.html',
  styleUrls: ['./financialyears.component.css']
})
export class FinancialyearsComponent implements OnInit {
  cols: any = [];
  financials: any = [];
  submitted = false;
  status = false;
  displayAddFinancialDialog: Boolean;
  displayUpdateFinancialDialog: Boolean;
  totalFinancialYear: any[];
  paginationDetails: any;
  updateFinancialYearData: any;
  addFinancialYearForm: FormGroup;
  updateFinancialYearForm: FormGroup;
  update = false;
  loading = true;
  constructor(private fb: FormBuilder, private setupService: SetupService, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.getFinancialYearColumns();
    this.getFinancialsYears(this.paginationDetails);
    this.initializeAddFinancialYearForm();
    this.initializeUpdateFinancialYearForm();
    this.getTotalNumberFinancialYearCount();
  }

  onFinancialYearPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    console.log('get the Financial Year Pagination Details', this.paginationDetails);
    this.getFinancialsYears(this.paginationDetails);
  }
  onStatusChange(value) {
    this.status = value;
  }



  get formFields() { return this.addFinancialYearForm.controls; }

  get editFormFields() { return this.updateFinancialYearForm.controls; }



  initializeAddFinancialYearForm() {
    this.addFinancialYearForm = this.fb.group({
      financialYearTitle: ['', Validators.required],

    });
  }

  initializeUpdateFinancialYearForm() {
    this.updateFinancialYearForm = this.fb.group({
      financialYearTitle: ['', Validators.required],
    });
  }



  /* -------------------------------------------------Add Financial Year------------------------------------------------ */
  addFinancialYear() {
    this.submitted = true;
    this.loading = true;

    if (this.addFinancialYearForm.invalid) {
      this.loading = false;
      return this.addFinancialYearForm.value.actionPerformed = null;
    } else {
      if (this.update) {
        const financialYearData = this.addFinancialYearForm.value;
        financialYearData.id = this.updateFinancialYearData.id;
        financialYearData.status = this.status;

        this.setupService.updateFinancialYear(financialYearData).subscribe((res: any[]) => {
          this.updateFinancialYearForm.value.actionPerformed = 'submit';
          this.loading = false;
          this.displayAddFinancialDialog = false;
          this.getFinancialsYears(this.paginationDetails);
          console.log('Financial year Updated Successfully');
          this.messageService.add({severity: 'success', summary: `Financial Year`, detail: 'updated Successfully'});
        }, err => {
          console.log('Error occured in financial year:', err);
          this.loading = false;
        });
      } else {
        const financialYearData = this.addFinancialYearForm.value;
        financialYearData.status = this.status;

        this.setupService.addFinancialYear(financialYearData).subscribe((res: any[]) => {
          this.addFinancialYearForm.value.actionPerformed = 'Submit';

          this.displayAddFinancialDialog = false;
          this.status = false;
          this.loading = false;
          console.log('Fianancial Year Saved Successfully');
          this.getTotalNumberFinancialYearCount();
          this.getFinancialsYears(this.paginationDetails);
          this.messageService.add({severity: 'success', summary: `Financial Year`, detail: 'created Successfully'});
        }, err => {
          this.loading = false;
          console.log('Error occured in add fianancial year:', err);
        });
      }
    }

  }
  /* ---------------------------------------------Update Financial Year----------------------------------------------- */
  updateFinancialYear(financialYear) {
    this.submitted = true;
    if (this.updateFinancialYearForm.invalid) {
      return this.updateFinancialYearForm.value.actionPerformed = null;
    } else {
      const financialYearData = this.updateFinancialYearForm.value;
      financialYearData.id = financialYear.id;
      financialYearData.status = this.status;

      this.setupService.updateFinancialYear(financialYearData).subscribe((res: any[]) => {
        this.updateFinancialYearForm.value.actionPerformed = 'submit';
        this.update = false;

        this.displayAddFinancialDialog = false;
        this.getFinancialsYears(this.paginationDetails);
        console.log('Financial year Updated Successfully');
      }, err => {
        console.log('Error occured in financial year:', err);
      });
    }
  }

  getFinancialYearColumns() {
    this.cols = [
      { field: 'financialYearTitle', header: 'Financial Year' },
      { field: 'action', header: 'Actions' },
      { field: 'status', header: 'Status' }
    ];
  }
  /* -------------------------------------Get Financial Years---------------------------------- */
  getFinancialsYears(paginationDetails) {
    this.loading = true;
    this.setupService.getFinancialYears(paginationDetails).subscribe((res: any[]) => {
      this.financials = res;
      console.log('Get the Financial Years Details', this.financials);
      this.loading = false;
    }, err => {
      console.log('error in the get Financial Years', err);
      this.loading = false;
    });
  }
  /* ---------------------------------------------Get Financial year Count---------------------------------- */
  getTotalNumberFinancialYearCount() {
    this.setupService.getTotalNumberFinancialYearCount().subscribe((data) => {
      this.totalFinancialYear = data;
      console.log('-----------Total Financial Years', this.totalFinancialYear);
    });
  }
  /*--------------------------------------------- Get Financial Year By Id------------------------------------- */
  getFinancialYearById(id) {
    this.setupService.getFinancialYearById(id).subscribe((res: any) => {
      this.updateFinancialYearData = res;
      this.addFinancialYearForm.patchValue(res);
      this.status = res.status;
      console.log('Financial Year Details', this.updateFinancialYearData);
    });
  }
  cancelAddFinancialDialog() {
    this.displayAddFinancialDialog = false;
    this.addFinancialYearForm.reset();
    this.status = false;
    this.update = false;
  }

  showAddFinancialDialog() {
    this.displayAddFinancialDialog = true;
    this.submitted = false;
    this.status = false;
    this.addFinancialYearForm.reset();



  }

  cancelUpdateFinancialDialog() {
    this.update = false;
    this.displayAddFinancialDialog = false;
    this.updateFinancialYearForm.reset();
  }

  showUpdateFinancialDialog(id: any) {
    this.submitted = false;
    this.getFinancialYearById(id);
    this.update = true;
    this.displayAddFinancialDialog = true;
  }

  exportAsXLSX() {
    if (this.financials.length > 0) {
      this.excelService.exportAsExcelFile(this.financials, 'sample');
    }
  }
}
