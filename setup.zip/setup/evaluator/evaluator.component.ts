import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SetupService } from '../setup.service';
import * as _ from 'lodash';
import { MessageService } from 'primeng/api';
import { ExcelService } from 'src/app/shared/excel.service';

@Component({
  selector: 'app-evaluator',
  templateUrl: './evaluator.component.html',
  styleUrls: ['./evaluator.component.css']
})
export class EvaluatorComponent implements OnInit {
  cols: any = [];
  evaluators: any = [];
  evaluatorNameListDropDown: any = [];
  paginationDetails: any;
  displayAddEvaluatorDialog: Boolean;
  displayUpdateEvaluatorDialog: Boolean;
  addEvaluatorForm: FormGroup;
  totalEvaluators: any;
  updateEvaluatorForm: FormGroup;
  evaluatorNameLists: any;
  moduleList: any = [];
  selectedIds = [];
  dropdowns: any[];
  update = false;
  submitted = false;
  dropdownSettings = {};
  dropdownSettingsMod = {};
  status = false;
  evaluatorId: any;
  loading = true;
  evaluatorLoading = false;
  moduleLoading = false;
  nameLoading = false;


  constructor(private fb: FormBuilder, private setupService: SetupService, private messageService: MessageService,
    private excelService: ExcelService) { }

  ngOnInit() {
    this.paginationDetails = {
      pageNumber: 0,
      pageSize: 5
    };
    this.getEvaluatorColumns();
    this.getEvaluators(this.paginationDetails);
    this.initializeAddEvaluatorForm();
    this.getTotalNumberOfEvaluators();
    this.initializeUpdateEvaluatorForm();
    this.getEvaluatorModule();
    this.getEvaluatorName();
    this.dropSettings();
  }

  dropSettings() {
    this.dropdownSettings = {
      singleSelection: true,
      text: 'Choose Evaluator Name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };

    this.dropdownSettingsMod = {
      singleSelection: false,
      text: 'Choose Module',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class-example',
      lazyLoading: true,
      badgeShowLimit: 4,
      limitSelection: 100
    };
  }

  onEvaluatorPageChange(event) {
    this.paginationDetails = {
      pageNumber: event.page,
      pageSize: event.rows
    };
    console.log('------Pagination Details After Page Change-----', this.paginationDetails);
    this.getEvaluators(this.paginationDetails);
  }




  initializeAddEvaluatorForm() {
    this.addEvaluatorForm = this.fb.group({
      employeeId: [null, Validators.required],
      moduleId: [null, Validators.required],
      status: [true, Validators.required],
    });
  }

  initializeUpdateEvaluatorForm() {
    this.updateEvaluatorForm = this.fb.group({
      evaluatorName: [null, Validators.required],
      moduleName: [null, Validators.required],
      status: [null, Validators.required],
    });
  }

  get formFields() { return this.addEvaluatorForm.controls; }

  /* Add Evaluator */
  addEvaluator() {
    this.submitted = true;
    this.loading = true;
    if (this.addEvaluatorForm.invalid) {
      this.loading = false;
      return;
    } else {
      if (this.update) {
        const evaluatorData = this.addEvaluatorForm.value;
        let idArr = 0;
        // has been changed from string to int;
        for (let i = 0; i < this.addEvaluatorForm.controls.employeeId.value.length; i++) {
          idArr = this.addEvaluatorForm.controls.employeeId.value[i].id;
          console.log('this.addEvaluatorForm.controls.employeeId.value[i]', this.addEvaluatorForm.controls.employeeId.value[i]);
        }
        evaluatorData.employeeId = idArr;
        evaluatorData['evaluatorId'] = this.evaluatorId;
        console.log('evaluatorData', evaluatorData);
        console.log('this.evaluatorId', this.evaluatorId);

        const moduleArr = [];
        // if (this.status == null) {
        //   evaluatorData.status = false;
        // } else {
        //   evaluatorData.status = this.status;
        // }

        for (let i = 0; i < this.addEvaluatorForm.controls.moduleId.value.length; i++) {
          moduleArr[i] = '' + this.addEvaluatorForm.controls.moduleId.value[i].id;
        }
        evaluatorData.moduleId = moduleArr;
        this.setupService.updateEvaluator(evaluatorData).subscribe((res: any[]) => {
          console.log('Evaluator Updated Successfulluy');
          this.update = false;
          this.getEvaluators(this.paginationDetails);
          this.displayAddEvaluatorDialog = false;
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `Evaluator`, detail: 'updated Successfully'});
        }, err => {
          this.displayAddEvaluatorDialog = false;
          this.loading = false;
          console.log('Error occured in update evaluator:', err);
        });
      } else {
        const evaluatorData = this.addEvaluatorForm.value;
        console.log('this.addEvaluatorForm.value', this.addEvaluatorForm.value);
        const idArr = [];
        for (let i = 0; i < this.addEvaluatorForm.controls.employeeId.value.length; i++) {
          idArr[i] = '' + this.addEvaluatorForm.controls.employeeId.value[i].id;
          console.log('this.addEvaluatorForm.controls.employeeId.value[i]', this.addEvaluatorForm.controls.employeeId.value[i]);
        }
        evaluatorData.employeeId = idArr;

        const moduleArr = [];

        for (let i = 0; i < this.addEvaluatorForm.controls.moduleId.value.length; i++) {
          moduleArr[i] = '' + this.addEvaluatorForm.controls.moduleId.value[i].id;
        }
        evaluatorData.moduleId = moduleArr;
        evaluatorData.status = this.status;
        console.log(this.status);


        this.setupService.addEvaluator(evaluatorData).subscribe((res: any[]) => {
          this.displayAddEvaluatorDialog = false;
          this.submitted = false;
          this.getEvaluators(this.paginationDetails);
          this.getTotalNumberOfEvaluators();
          this.loading = false;
          this.messageService.add({severity: 'success', summary: `Evaluator`, detail: 'created Successfully'});
          console.log('Evaluator Saved Successfully');
        }, err => {
          this.loading = false;
          console.log('Error occured in add Evaluator:', err);
        });
      }
    }

  }

  /* Update Evaluator */
  updateEvaluator() {
    const evaluatorData = this.updateEvaluatorForm.value;
    this.setupService.updateEvaluator(evaluatorData).subscribe((res: any[]) => {
      console.log('Evaluator Updated Successfulluy');
      this.update = true;
    }, err => {
      console.log('Error occured in update evaluator:', err);
    });
  }


  getEvaluatorColumns() {
    this.cols = [
      { field: 'evaluatorName', header: 'Evaluator Name' },
      { field: 'module', header: 'Module' },
      { field: 'action', header: 'Action' },
      { field: 'status', header: 'Status' }
    ];
  }
  getEvaluators(paginationDetails) {
    this.evaluatorLoading = true;
    this.setupService.getEvaluators(paginationDetails).subscribe((res: any[]) => {
      this.evaluators = res;
      this.evaluatorLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in get evaluators:', err);
      this.evaluatorLoading = false;
      this.loadOninit();
    });
  }

  getTotalNumberOfEvaluators() {
    this.setupService
      .getTotalNumberOfEvaluators()
      .subscribe((data) => {
        this.totalEvaluators = data;
        console.log('-----totalEvaluators-----', this.totalEvaluators);
      });
  }

  getEvaluatorModule() {
    this.moduleLoading = true;
    this.setupService.getEvaluatorModule().subscribe((res: any) => {
      // this.moduleList = res;
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.proficiencyLevelName) {
          newData.push({ itemName: element.proficiencyLevelName, id: element.proficiencyLevelId });
        }
      }

      this.moduleList = this.moduleList.concat(newData);
      console.log('----------this.evaluator modulelist---------------', this.moduleList);
      this.moduleLoading = false;
      this.loadOninit();
    }, err => {
      this.moduleLoading = false;
      this.loadOninit();
    });
  }
  getEvaluatorName() {
    this.nameLoading = true;
    this.setupService.getEvaluatorName().subscribe((res: any[]) => {
      console.log('res', res);
      this.dropdowns = res;
      const newData = [];
      for (let index = 0; index < res.length; index++) {
        const element = res[index];
        if (element.userName) {
          newData.push({ itemName: element.userName, id: element.id });
        }
      }

      this.evaluatorNameListDropDown = this.evaluatorNameListDropDown.concat(newData);
      this.nameLoading = false;
      this.loadOninit();
    }, err => {
      console.log('Error occured in getEValuatorNames:', err);
      this.nameLoading = false;
      this.loadOninit();
    });
  }

  getEvaluatorById(id) {
    this.setupService.getEvaluatorById(id)
      .subscribe(res => {
        console.log('res', res);
        this.addEvaluatorForm.patchValue(res);
        const moduleId = res['moduleId'];
        const intModule = [];
        const employeeId = res['employeeId'];
        this.evaluatorId = res['evaluatorId'];
        console.log('employeeId', employeeId);
        const evalIndex = _.findIndex(this.evaluatorNameListDropDown, (d) => d['id'] == employeeId);
        if (evalIndex != -1) {
          this.addEvaluatorForm.patchValue({
            employeeId: [this.evaluatorNameListDropDown[evalIndex]]
          });
        } else {
          this.addEvaluatorForm.patchValue({
            employeeId: []
          });
        }
        console.log('evalIndex', evalIndex);

        for (let i = 0; i < moduleId.length; i++) {
          const index = _.findIndex(this.moduleList, (d) => d['id'] == moduleId[i]);
          if (index != -1) {
            intModule[i] = this.moduleList[index];
          }
        }
        this.status = res['status'];
        this.addEvaluatorForm.patchValue({
          moduleId: intModule
        });

      });
  }

  cancelAddEvaluatorDialog() {
    this.displayAddEvaluatorDialog = false;
    this.initializeAddEvaluatorForm();
    this.update = false;
  }

  showAddEvaluatorDialog() {
    this.displayAddEvaluatorDialog = true;
  }

  cancelUpdateEvaluatorDialog() {
    this.displayAddEvaluatorDialog = false;
    this.updateEvaluatorForm.reset();
  }

  showUpdateEvaluatorDialog(id) {
    console.log(id);
    this.displayAddEvaluatorDialog = true;
    this.getEvaluatorById(id);
    this.update = true;
  }
  select(e) {
    console.log(e);
    this.selectedIds = e.value;
  }

  selectEval(e) {
    console.log(e);
  }

  loadOninit() {
    if (!this.evaluatorLoading && !this.moduleLoading && !this.nameLoading) {
      this.loading = false;
    }
  }

  exportAsXLSX() {
    if (this.evaluators.length > 0) {
      this.excelService.exportAsExcelFile(this.evaluators, 'sample');
    }
  }
}
