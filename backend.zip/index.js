const express = require('express');
const bodyparser = require('body-parser');
const cors = require('cors');
const mysql = require('mysql2');

const app = express();

app.use(cors());
app.use(bodyparser.json());

//database connection
const db = mysql.createConnection({
  host:'localhost',
  user:'root',
  password:'root',
  database:'simpledb',
  port:4306
});

//check db connection
db.connect(err=>{
    if(err) {console.log(err, 'DB Error');}
    console.log('Connected to database..');
})

//get all data
app.get('/user',(req,res)=>{
    console.log('Get Users..');
    let qry = `select * from user`;
    db.query(qry,(err,result)=>{
        if(err)
        {
            console.log(err,'Errors');
        }

        if(result.length > 0){
            res.send({
                message:'All Users Data',
                data: result
            });
        }
    });
});

//get single data
app.get('/user/:id',(req,res)=>{
    console.log('Get Single data');
    console.log(req.params.id,'getid==>');

    let gID = req.params.id;
    let qry = `select * from user where id = ${gID}`;
    db.query(qry,(err,result)=>{
        if(err) {console.log(err);}
        if(result.length > 0)
        {
            res.send({
                message:'get single data',
                data:result
            });
        }
        else
        {
            res.send({
                message:'data not found'
            });
        }
    });
});

//create data
app.post('/user',(req,res)=>{
    console.log('Post Data');
    console.log(req.body,'createdata');

    let fullName = req.body.fullname;
    let eMail = req.body.email;
    let mb = req.body.mobile;

    let qry = `insert into user(fullname,email,mobile)
                values('${fullName}','${eMail}','${mb}')`;

    console.log(qry,'qry');

    db.query(qry,(err,result)=>{
        
        if(err){console.log(err);}
        console.log(result,'result')

        // if(result.length > 0)
        // {
        //     res.send({
        //         message:'data inserted'
        //     });
        // }else
        // {
        //     res.send({
        //         message: 'wrong...'
        //     })
        // }
        res.send({
            message:'data inserted',
        });
    });
});


//update single data
app.put('/user/:id',(req,res)=>{
    console.log(req.body,'updatedata');

    let gID = req.params.id;
    let fullName = req.body.fullname;
    let eMail = req.body.email;
    let mb = req.body.mobile;

    let qry = `update user set fullname =' ${fullName}', email = '${eMail}', mobile = '${mb}'
                where id = ${gID}`;
    
    db.query(qry,(err,result)=>{
        if(err){console.log(err);}

        res.send({
            message:'data updated'
        });
    });
})

// delete single data
app.delete('/user/:id',(req,res)=>{
    let qID = req.params.id;

    let qry =`delete from user where id = '${qID}'`;
    db.query(qry,(err,result)=>{
        if(err) {console.log(err);}

        res.send(
            {
                message:'data deleted'
            }
        )

    });
});

app.listen(3000, ()=>{
    console.log("Server Running...");
});
