export const environment = {
  production: true,
  siteKey: '6LfTIeUUAAAAALQ5WCR7Ttadie4i_onv4ca51MOD',
  baseUrl: '',
  apiUrl: 'https://v2api.analytics.brussels/prod'
};
