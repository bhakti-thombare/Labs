import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AboutUsEditFormComponent } from './about-us-edit-form/about-us-edit-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { AutosizeModule } from 'ngx-autosize';
import { TagManagementFormComponent } from './tag-management-form/tag-management-form.component';
import { SharedModule } from '../shared/shared.module';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { FileUploadModule } from 'ng2-file-upload';
import { LandingEditFormComponent } from './landing-edit-form/landing-edit-form.component';
import { DashboardSidebarComponent } from './dashboard-sidebar/dashboard-sidebar.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { UserListComponent } from './user-list/user-list.component';
import { UserAddFormComponent } from './user-add-form/user-add-form.component';
import { UserEditFormComponent } from './user-edit-form/user-edit-form.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { UserAccountFormComponent } from './account/user-account-form/user-account-form.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { SharedContentComponent } from './shared-content/shared-content.component';
import { FavoriteContentComponent } from './favorite-content/favorite-content.component';
import { DraftContentComponent } from './draft-content/draft-content.component';
import { PrivateContentComponent } from './private-content/private-content.component';
import { GuidedTourModule, GuidedTourService } from 'ngx-guided-tour';


@NgModule({
  declarations: [
    DashboardComponent,
    AboutUsEditFormComponent,
    TagManagementFormComponent,
    LandingEditFormComponent,
    DashboardSidebarComponent,
    UserListComponent,
    UserAddFormComponent,
    UserEditFormComponent,
    UserAccountFormComponent,
    UserDashboardComponent,
    SharedContentComponent,
    FavoriteContentComponent,
    DraftContentComponent,
    PrivateContentComponent],
  imports: [
    // AutosizeModule,
    SharedModule,
    FormsModule,
    ModalModule.forRoot(),
    PopoverModule.forRoot(),
    FileUploadModule,
    BsDropdownModule.forRoot(),
    BsDatepickerModule.forRoot(),
    ReactiveFormsModule,
    CommonModule,
    GuidedTourModule,
    NgSelectModule,
    UserRoutingModule
  ],
  providers: [GuidedTourService]
})
export class UserModule { }
