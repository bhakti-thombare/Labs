import { Component, OnInit, Output, EventEmitter, Input, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from 'src/app/core/services/auth.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GeneralService } from '../shared/general.service';
import { NotificationService } from 'src/app/core/services/notification.service';
declare var JSEncrypt: any;
@Component({
  selector: 'ab-user-edit-form',
  templateUrl: './user-edit-form.component.html',
  styleUrls: ['./user-edit-form.component.scss']
})
export class UserEditFormComponent implements OnInit, OnChanges {
  @Output() closeEvent: EventEmitter<any> = new EventEmitter<any>();
  @Input() userData: any;
  userTypes = ['Private', 'Public'];
  privateUserForm: FormGroup;
  selectedAccessType: any;
  currentUser: any;
  encrypt: any;
  @Output() updateSuccessful: EventEmitter<any> = new EventEmitter<any>();
  constructor(
    private formBuilder: FormBuilder,
    private utilityService: UtilityService,
    private authService: AuthService,
    private generalService: GeneralService,
    private notificationService: NotificationService) { }

  ngOnInit() {
    this.loadUser();
    // this.buildForm();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  buildForm() {
    this.privateUserForm = this.formBuilder.group({
      tableauUsername: [null, Validators.required],
      tableauPassword: [null, Validators.required],
    });
  }

  setAccessType(value) {
    if (value.toLowerCase().includes('private') || value.toLowerCase().includes('champion')) {
      this.selectedAccessType = 'Private';
      this.setPrivateUserForm();
    } else if (value.toLowerCase().includes('public')) {

      this.selectedAccessType = 'Public';
    }
    // console.log('value', value);
    // console.log('this.selectedAccessType', this.selectedAccessType);
  }

  setPrivateUserForm() {
    if (this.userData && this.userData.tableau) {
      this.privateUserForm.patchValue({
        tableauUsername: this.userData.tableau.userName,
        tableauPassword: this.userData.tableau.password
      });
    }
  }

  ngOnChanges() {
    this.buildForm();
    if (this.userData) {
      this.setAccessType(this.userData.profileType);
    }
  }

  closeModal() {
    this.closeEvent.emit(true);
  }

  submit() {
    // console.log(this.selectedAccessType);
    // console.log(this.privateUserForm.value);
    let data: any;
    this.encrypt = new JSEncrypt();
    this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
    let userRole = '';
    if (this.userData.profileType.includes('champion')) {
      userRole = 'champion';
    } else {
      userRole = this.userData.profileType.split('_')[1];
    }
    data = {
      email: this.userData.email, // this.encrypt.encrypt(this.userData.email),
      fullName: this.userData.fullName,
      id: this.userData.id,
      profileType: userRole === 'champion' ? userRole : `${this.selectedAccessType.toLowerCase()}_${userRole}`,
      tableau: this.selectedAccessType === 'Private' ? {
        password: this.encrypt.encrypt(this.privateUserForm.value.tableauPassword),
        userName: this.encrypt.encrypt(this.privateUserForm.value.tableauUsername)
      } : null,
      languageCode: this.currentUser.language,
      roleCode: this.currentUser.role,
      userId: this.currentUser.id
    };
    data = this.utilityService.removeEmptyStringAndTrim(data);
    // console.log('data', data);
    this.generalService.updateUserByAdmin(data).subscribe(res => {
      this.updateSuccessful.emit(true);
      // this.notificationService.showSuccess('User updated successfully');
      this.utilityService.showTranslatedNotificationMessage('NotificationMessages.User.UserUpdated', 'SUCCESS');
    });
  }

}
