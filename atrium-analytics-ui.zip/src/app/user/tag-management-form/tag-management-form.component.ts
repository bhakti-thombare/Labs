import { Component, OnInit, ViewChild } from '@angular/core';
import { GeneralService } from '../shared/general.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { NotificationService } from 'src/app/core/services/notification.service';
import { NgSelectConfig } from '@ng-select/ng-select';
import * as _ from 'lodash';
import { Router } from '@angular/router';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { UtilityService } from 'src/app/core/services/utility.service';
@Component({
  selector: 'ab-tag-management-form',
  templateUrl: './tag-management-form.component.html',
  styleUrls: ['./tag-management-form.component.scss']
})
export class TagManagementFormComponent implements OnInit {
  currentUser: any;

  categories = ['Type',
    'Theme',
    'Keyword',
    'Scale',
    'Year',
    'Update state',
    'Data source',
    'Confidentiality'];
  SelectCategoryValue: string;
  selectedCategory: any;
  selectedTag: any;
  enTag: any;
  frTag: any;
  nlTag: any;
  selectedLanguage = '';
  tags: any[] = [];
  page = 0;
  size = 6;
  reachedTableBottom: any;
  totalElements: number;
  totalPages: any;
  tempCategories: any[];
  isLastTagPage: any;
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  tagTableMessage: string;
  tagUpdateMessage: string;
  tagDeletMessage: string;
  tagAddSuccessMessage: string;
  tagUpdateSuccessMessage: string;
  tagDeleteSuccessMessage: string;
  tagUpateTitle: string;
  tagDeleteTitle: string;
  langMandatoryText: string;
  selectCategoryText: string;

  constructor(
    private utilityService: UtilityService,
    private translate: TranslateService,
    private router: Router,
    private generalService: GeneralService,
    private authService: AuthService,
    private notificationService: NotificationService, private config: NgSelectConfig) { }
  ngOnInit() {
    this.loadUser();
    this.selectedLanguage = localStorage.getItem('language');
    this.setTagMessage(this.selectedLanguage);
    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      // console.log('event', event);
      // console.log('this.selectedCategory', this.selectedCategory);
      this.selectedLanguage = event.lang;
      this.createTemporaryCategories();
      this.getTags(this.page);
      this.setTagMessage(this.selectedLanguage);
    });
  }

  loadUser() {
    this.authService.currentUser$.subscribe((user: any) => {
      this.currentUser = user;
      // console.log('user', user)
      this.getAllCategories();
      this.getTags(this.page);
    });
  }

  setCategory(category) {
    this.changeCategory(category);
  }

  changeCategory(category:any){
    this.selectedCategory = this.categories.filter((element: any) => element.categoryId === category.categoryId)[0];
    if (this.selectedCategory) {
      this.clearSelectedTags();
      this.tags = [];
      this.page = 0;
      this.getTags(this.page);
      this.setTagMessage(this.selectedLanguage);
    }
  }

  setTagMessage(lang) {
    switch (lang) {
      case 'en':
        if (this.selectedCategory && this.selectedCategory.enCategoryName.toLowerCase() === 'type') {
          this.tagTableMessage = 'Tags of \'Type\' category cannot be deleted.';
        } else {
          this.tagTableMessage = 'Modify or delete the selected tag.';
        }
        this.tagUpdateMessage = 'Are you sure you want to modify this tag on all the vizualisations and reports ?';
        this.tagDeletMessage = 'Are you sure you want to delete this tag on all the vizualisations and reports ? ';
        this.tagAddSuccessMessage = 'Tag added successfully.';
        this.tagUpdateSuccessMessage = 'Tag updated successfully.';
        this.tagDeleteSuccessMessage = 'Tag deleted successfully.';
        this.tagUpateTitle = 'Tag update';
        this.tagDeleteTitle = 'Tag delete';
        this.langMandatoryText = 'Please fill in the fields in three languages.';
        this.selectCategoryText = 'Please select category.';
        break;
      case 'fr':
        if (this.selectedCategory && this.selectedCategory.enCategoryName.toLowerCase() === 'type') {
          this.tagTableMessage = 'Tags de la catégorie \'Type\' ne peuvent pas être supprimés.';
        } else {
          this.tagTableMessage = 'Modifiez ou supprimez le tag sélectionné ';
        }
        this.tagUpdateMessage = 'Êtes-vous sûr de vouloir modifier ce tag sur tou(tes)s les visualisations et rapports ?';
        this.tagDeletMessage = 'Êtes-vous sûre de vouloir supprimer ce tag sur tou(te)s les visualisations et rapports ?';
        this.tagAddSuccessMessage = 'Tag ajouté avec succès.';
        this.tagUpdateSuccessMessage = 'Tag mis à jour avec succès.';
        this.tagDeleteSuccessMessage = 'Tag supprimé avec succès.';
        this.tagUpateTitle = 'Mettre à jour Tag';
        this.tagDeleteTitle = 'Supprimer Tag';
        this.langMandatoryText = 'Veuillez remplir les champs en trois langues.';
        this.selectCategoryText = 'Sélectionnez une catégorie.';
        break;
      case 'nl':
        if (this.selectedCategory && this.selectedCategory.enCategoryName.toLowerCase() === 'type') {
          this.tagTableMessage = 'Tags van de categorie \'Type\' kunnen niet worden verwijderd.';
        } else {
          this.tagTableMessage = 'Wijzig of verwijder de geselecteerde tag';
        }
        this.tagUpdateMessage = 'Weet u zeker dat u deze tag op alle visualisaties en rapporten wilt wijzigen?';
        this.tagDeletMessage = 'Weet u zeker dat u deze tag wilt verwijderen voor alle visualisaties en rapporten?';
        this.tagAddSuccessMessage = 'Tag succesvol toegevoegd.';
        this.tagUpdateSuccessMessage = 'Tag succesvol bijgewerkt.';
        this.tagDeleteSuccessMessage = 'Tag succesvol verwijderd.';
        this.tagUpateTitle = 'Tag bijwerken';
        this.tagDeleteTitle = 'Tag verwijderen';
        this.langMandatoryText = 'Gelieve de velden in drie talen in te vullen.';
        this.selectCategoryText = 'Selecteer een categorie.';
        break;
    }
  }

  setTag(tag) {
    if (this.selectedTag && this.selectedTag.tagId === tag.tagId) {
      // console.log('this.selectedTag', this.selectedTag);
      this.selectedTag = undefined;
      this.enTag = '';
      this.frTag = '';
      this.nlTag = '';
    } else {
      this.selectedTag = tag;
      // console.log('this.selectedTag', this.selectedTag);
      this.enTag = this.selectedTag.enTagName;
      this.frTag = this.selectedTag.frTagName;
      this.nlTag = this.selectedTag.nlTagName;
    }

  }

  getAllCategories() {
    const data = {
      roleCode: this.currentUser.role,
      languageCode: this.getLanguage(this.currentUser.language),
      userId: this.currentUser.id,
    };
    this.generalService.getAllCategories(data).subscribe((res: any) => {
      // console.log('res', res);
      // if (res.message === 'Get all categories successful!') {
      this.categories = res.value.content;
      this.createTemporaryCategories();
      // }
    });
  }

  createTemporaryCategories() {
    const catArray = [];
    this.categories.forEach((element: any) => {
      if (this.selectedCategory) {
        this.SelectCategoryValue = this.selectedCategory[this.selectedLanguage + 'CategoryName'];
      }
      catArray.push({ categoryId: element.categoryId, value: element[this.selectedLanguage + 'CategoryName'] });
    });
    this.tempCategories = [...catArray];
  }
  getTags(pageNumber: any) {
    if (this.selectedCategory) {
      const data = {
        roleCode: this.currentUser.role,
        languageCode: this.getLanguage(this.currentUser.language),
        userId: this.currentUser.id,
        categoryId: this.selectedCategory.categoryId
      };
      const queryParams = { size: 6, page: pageNumber };
      this.generalService.getTagsByCategory(data, queryParams).subscribe((res: any) => {
        // if (res.message === 'Get all tags successful!') {
        this.totalElements = res.value.totalElements;
        this.totalPages = res.value.totalPages;
        this.isLastTagPage = res.value.last;
        if (!this.tags.length) {
          this.tags = res.value.content;
        } else {
          this.tags = this.tags.concat(res.value.content);
        }
        const uniqTags = _.orderBy(
          _.uniqBy(this.tags, 'tagId'),
          [tag => tag[this.selectedLanguage + 'TagName'].trim().toLowerCase()],
          ['asc']
        );
        this.tags = uniqTags;
        // console.log('this.tags', this.tags);
        // }
      });
    }
  }

  addTag() {
    if (this.selectedCategory) {
      if (this.enTag && this.frTag && this.nlTag) {
        const tagData = {
          categoryId: this.selectedCategory.categoryId,
          enTagName: this.enTag,
          frTagName: this.frTag,
          nlTagName: this.nlTag,
          languageCode: this.getLanguage(this.currentUser.language),
          roleCode: this.currentUser.role,
          userId: this.currentUser.id
        };
        // console.log('tagData', tagData);
        this.generalService.addTag(tagData).subscribe(res => {
          // if (res.message === 'Get add tags successful!') {
          this.changeCategory(this.selectedCategory);
          // this.getTags(this.page);
          // this.clearSelectedTags();
          // this.notificationService.showSuccess(this.tagAddSuccessMessage);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Tag.TagAdded', 'SUCCESS');

          // }
        });
      } else {
        this.utilityService.showTranslatedNotificationMessage('NotificationMessages.General.ThreeLangMandatory', 'ERROR');
        // this.notificationService.showError(this.langMandatoryText);
      }
    } else {
      // this.notificationService.showError(this.selectCategoryText);
      this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Tag.SelectCategory', 'ERROR');

    }
  }

  updateTag() {
    if (this.enTag && this.frTag && this.nlTag) {
      this.genericConfirm.show({
        headlineText: this.tagUpateTitle,
        notConfirmText: 'NOTEXT',
        confirmText: 'YESTEXT',
        text: this.tagUpdateMessage,
        callback: (result) => {
          // this.deleteAdjustment(adjustment);
          if (result) {
            if (this.selectedTag) {
              const tagData = {
                categoryId: this.selectedCategory.categoryId,
                enTagName: this.enTag,
                frTagName: this.frTag,
                nlTagName: this.nlTag,
                languageCode: this.getLanguage(this.currentUser.language),
                roleCode: this.currentUser.role,
                tagId: this.selectedTag.tagId,
                userId: this.currentUser.id
              };
              this.generalService.updateTag(tagData).subscribe(res => {
                this.tags.forEach(tag => {
                  if (tag.tagId === this.selectedTag.tagId) {
                    tag.frTagName = this.frTag;
                    tag.enTagName = this.enTag;
                    tag.nlTagName = this.nlTag;
                  }
                });
                // console.log('res', res);
                if (res.message === 'Get update tags successful!') {
                  // this.page = 0;
                  this.getTags(this.page);
                  this.clearSelectedTags();
                  // this.notificationService.showSuccess(this.tagUpdateSuccessMessage);
                  this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Tag.TagUpdated', 'SUCCESS');
                }
              });
              // console.log('tagData', tagData);
            }
          }
        }
      });
    } else {
      // this.notificationService.showError(this.langMandatoryText);
      this.utilityService.showTranslatedNotificationMessage('NotificationMessages.General.ThreeLangMandatory', 'ERROR');
    }
  }

  deleteTag() {
    this.genericConfirm.show({
      headlineText: this.tagDeleteTitle,
      notConfirmText: 'NOTEXT',
      confirmText: 'YESTEXT',
      text: this.tagDeletMessage,
      callback: (result) => {
        if (result) {
          if (this.selectedTag) {
            const tagData = {
              languageCode: this.getLanguage(this.currentUser.language),
              roleCode: this.currentUser.role,
              tagId: this.selectedTag.tagId,
              userId: this.currentUser.id
            };
            this.generalService.deleteTag(tagData).subscribe(res => {
              // if (res.message === 'Tag deleted successfully') {
              this.getTags(this.page);
              const index = this.tags.indexOf(this.selectedTag);
              if (index !== -1) { this.tags.splice(index, 1); }
              this.clearSelectedTags();
              // this.notificationService.showSuccess(this.tagDeleteSuccessMessage);
              this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Tag.TagDeleted', 'SUCCESS');
              // }

            });
            // console.log('tagData', tagData);
          }
        }
      }
    });
  }

  clearSelectedTags() {
    this.enTag = '';
    this.frTag = '';
    this.nlTag = '';
    this.selectedTag = undefined;
  }


  getLanguage(lang: any) {
    switch (lang) {
      case 'en':
        return 'English';
      case 'fr':
        return 'French';
      case 'nl':
        return 'Dutch';
    }
  }

  onScroll(event) {
    // if (event.target.scrollHeight - event.target.scrollTop === event.target.clientHeight) {
      console.log("height", event.target.scrollHeight);
      if (this.tags.length < this.totalElements) {
        if (!this.isLastTagPage) {
          // console.log('this.page', this.page);
          this.page = this.page + 1;
          this.getTags(this.page);
          // alert('bttom');}
        }
      }
    // }

  }

  returnToDashboard() {
    this.router.navigateByUrl('/user/dashboard');
  }

}
