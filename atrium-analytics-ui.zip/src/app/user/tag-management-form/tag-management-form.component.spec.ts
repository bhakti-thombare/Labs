import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TagManagementFormComponent } from './tag-management-form.component';

describe('TagManagementFormComponent', () => {
  let component: TagManagementFormComponent;
  let fixture: ComponentFixture<TagManagementFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TagManagementFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TagManagementFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
