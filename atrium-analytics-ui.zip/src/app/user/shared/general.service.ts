import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  constructor(private restService: RestService) { }
  apiUrl = environment.apiUrl;
  // tag management api calls
  getAllCategories(body: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/category/all`, body, null, true);
  }

  getTagsByCategory(body: any, queryParams: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/tag/category`, body, queryParams, true);
  }

  addTag(body: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/tag`, body, null, true);
  }

  updateTag(body: any) {
    return this.restService.put(`${this.apiUrl}/v2/api/tag`, body, null, true);
  }

  deleteTag(body: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/tag/delete`, body, null, true);
  }

  // landing edit calls

  getLandingData() {
    return this.restService.fetch(`${environment.apiUrl}/v2/api/landing`, undefined, true);
  }

  updateLandingData(body: any) {
    return this.restService.put(`${environment.apiUrl}/v2/api/landing`, body, null, true);
  }

  // about us edit calls

  getAboutUsData() {
    return this.restService.fetch(`${environment.apiUrl}/v2/api/about-us`, undefined, true);
  }

  updateAboutUsData(body: any) {
    return this.restService.put(`${environment.apiUrl}/v2/api/about-us`, body, null, true);
  }

  // user calls champion/hubster/subsriber


  // add user by admin
  addUser(body: any) {
    return this.restService.post(`${environment.apiUrl}/v2/api/user`, body, undefined, true);
  }

  // get user list for admin
  getUsers(body: any, queryParams: any) {
    return this.restService.post(`${environment.apiUrl}/v2/api/user/admin/all`, body, queryParams, true);
  }

  // update user profile by admin
  updateUserByAdmin(body: any) {
    return this.restService.put(`${environment.apiUrl}/v2/api/user/admin/profile`, body, undefined, true);
  }

  // delete user profile
  deleteUser(body: any) {
    return this.restService.put(`${environment.apiUrl}/v2/api/user/delete`, body, undefined, true);
  }

  // update user profile
  updateUser(body: any) {
    return this.restService.put(`${environment.apiUrl}/v2/api/user`, body, undefined, true);
  }

  // shared content
  sharedElements(body: any, queryParams) {
    return this.restService.post(`${environment.apiUrl}/v2/api/dashboard/invited`, body, queryParams, true);
  }

  // favorite content
  favoriteElements(body: any, queryParams) {
    return this.restService.post(`${environment.apiUrl}/v2/api/dashboard/favorite`, body, queryParams, true);
  }

  // get user count
  getUserCount(body: any) {
    return this.restService.post(`${environment.apiUrl}/v2/api/dashboard/users`, body, undefined, true);
  }

  // draft-content
  draftElements(body: any, queryParams) {
    return this.restService.post(`${environment.apiUrl}/v2/api/dashboard/draft-elements`, body, queryParams, true);
  }

  // private products
  privateElements(body: any, queryParams) {
    return this.restService.post(`${environment.apiUrl}/v2/api/dashboard/private-products`, body, queryParams, true);
  }

  // update tutorial flags specific to user
  updateTutorialFlags(body: any, queryParams) {
    return this.restService.put(`${this.apiUrl}/v2/api/user/tutorial`, body, queryParams, true);
  }


}
