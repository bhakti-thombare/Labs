import { Component, OnInit, EventEmitter, Output, ChangeDetectorRef, OnDestroy, Renderer2 } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { AuthService } from 'src/app/core/services/auth.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GeneralService } from '../shared/general.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { LanguageTranslateService } from 'src/app/core/services/language-translate.service';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { LoaderService } from 'src/app/core/services/loader.service';
import { Subscription } from 'rxjs';
declare var JSEncrypt: any;
@Component({
  selector: 'ab-user-add-form',
  templateUrl: './user-add-form.component.html',
  styleUrls: ['./user-add-form.component.scss']
})
export class UserAddFormComponent implements OnInit, OnDestroy {
  @Output() closeEvent: EventEmitter<any> = new EventEmitter<any>();
  accessType = 'private';
  encrypt: any;
  userRoles = [];
  selectedUserType: any;
  privateUserForm: FormGroup;
  publicUserForm: FormGroup;
  currentUser: any;
  // tslint:disable-next-line: max-line-length
  emailAddressPattern = new RegExp(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
  multipleEmailAddressPattern = new RegExp(/^(\s?[^\s,]+@[^\s,]+\.[^\s,]+\s?,)*(\s?[^\s,]+@[^\s,]+\.[^\s,]+)$/);
  userCount = 0;
  param: { userCount: number; };
  selectedLanguage: string;
  subscription: Subscription;
  constructor(
    private loaderService: LoaderService,
    private renderer: Renderer2,
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private generalService: GeneralService,
    private notificationService: NotificationService,
    private utilityService: UtilityService,
    private ref: ChangeDetectorRef,
    private languageChangeSubscription: LanguageTranslateService,
    private translate: TranslateService) { }

  ngOnInit() {
    this.param = { userCount: this.userCount };
    this.loadUser();
    this.buildForm();
    this.selectedLanguage = localStorage.getItem('language');
    this.selectedLanguage === 'en' ? this.userRoles = ['Hubster', 'Subscriber', 'Champion'] :
      this.selectedLanguage === 'fr' ? this.userRoles = ['Hubster', 'Inscrit', 'Champion'] :
        this.userRoles = ['Hubster', 'Lid', 'Champion'];
    this.selectedUserType = this.userRoles[0];
    document.body.style.overflow = 'hidden';
    this.languageChangeSubscription = this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.selectedLanguage === 'en' ? this.userRoles = ['Hubster', 'Subscriber', 'Champion'] :
        this.selectedLanguage === 'fr' ? this.userRoles = ['Hubster', 'Inscrit', 'Champion'] :
          this.userRoles = ['Hubster', 'Lid', 'Champion'];
    });
    this.subscription = this.loaderService.isLoading.subscribe((v) => {
      // console.log(v);
      if (this) { this.renderer.setStyle(document.body, 'overflow', 'hidden'); }
    });
  }

  loadUser() {
    this.authService.currentUser$.subscribe((user: any) => {
      if (user) {
        this.currentUser = user;
      }
    });
  }

  buildForm() {
    this.privateUserForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(this.emailAddressPattern)]],
      tableauUsername: ['', Validators.required],
      tableauPassword: ['', Validators.required],
    });
    this.publicUserForm = this.formBuilder.group({
      emailAddresses: ['', [Validators.required, Validators.pattern(this.multipleEmailAddressPattern)]]
    });
    this.publicUserForm.get('emailAddresses').valueChanges.subscribe((emails: string) => {
      if (emails) {
        // console.log('emails trimed', emails.trim().split(','));
        if (emails.trim().split(',').length > 1 && this.publicUserForm.get('emailAddresses').valid) {
          this.userCount = emails.split(',').filter(email => email).length;
        } else if (emails.trim().split(',').length === 1 && emails.match(this.emailAddressPattern)) {
          this.userCount = 1;
        } else if (!emails.length) {
          this.userCount = 0;
        }
      } else if (!emails.length) {
        this.userCount = 0;
      }
      this.ref.detectChanges();
      // console.log('this.param.userCount', this.userCount);
    });
  }
  setUserType(event) {
    this.selectedUserType = this.utilityService.titleCase(event.toLowerCase());
    if (event.toLowerCase() === 'champion') { this.accessType = 'private'; }
  }
  closeModal() {
    this.closeEvent.emit(true);
  }


  submit() {
    let data;
    // console.log('data', data);
    this.encrypt = new JSEncrypt();
    this.encrypt.setPublicKey(localStorage.getItem('publicKey'));

    if (this.accessType === 'private') {
      const emails = [];
      this.privateUserForm.value.email.split(',').forEach(item => {
        emails.push(this.encrypt.encrypt(item));
      });
      const selectedUserType = this.selectedUserType.toLowerCase();
      data = {
        email: emails,
        roleCode: this.currentUser.role,
        tableau: {
          userName: this.encrypt.encrypt(this.privateUserForm.value.tableauUsername.trim()),
          password: this.encrypt.encrypt(this.privateUserForm.value.tableauPassword)
        },
        userId: this.currentUser.id,
        languageCode: this.currentUser.language,
        userRoleCode: selectedUserType === 'champion' ?
          selectedUserType :
          ((selectedUserType === 'subscriber' || selectedUserType === 'inscrit' || selectedUserType === 'lid') ?
            this.accessType + '_' + 'subscriber' : this.accessType + '_' + selectedUserType)
      };
    }

    if (this.accessType === 'public') {
      const emails = [];
      this.publicUserForm.value.emailAddresses.split(',').forEach(item => {
        const toBeEncrypt = item.trim();
        emails.push(this.encrypt.encrypt(toBeEncrypt));
      });
      const selectedUserType = this.selectedUserType.toLowerCase();
      data = {
        email: emails,
        userId: this.currentUser.id,
        languageCode: this.currentUser.language,
        roleCode: this.currentUser.role,
        userRoleCode: selectedUserType === 'champion' ?
          selectedUserType :
          ((selectedUserType === 'subscriber' || selectedUserType === 'inscrit' || selectedUserType === 'lid') ?
            this.accessType + '_' + 'subscriber' : this.accessType + '_' + selectedUserType)
      };
    }

    this.generalService.addUser(data).subscribe(res => {
      // this.notificationService.showSuccess('Invitation has been sent successfully');
      this.utilityService.showTranslatedNotificationMessage('NotificationMessages.User.UserInvited', 'SUCCESS');
      this.closeModal();
    });

  }

  ngOnDestroy() {
    document.body.style.overflow = 'unset';
    this.subscription.unsubscribe();
  }

  titleCase(str) {
    return this.utilityService.titleCase(str);
  }


}
