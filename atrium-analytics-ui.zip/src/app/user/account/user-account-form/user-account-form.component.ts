import { Component, OnInit, ViewChild } from '@angular/core';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from 'src/app/core/services/auth.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GeneralService } from '../../shared/general.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { TranslateService } from '@ngx-translate/core';
import { Cookie } from 'src/app/core/services/cookie';
import { Router } from '@angular/router';
declare var JSEncrypt: any;
@Component({
  selector: 'ab-user-account-form',
  templateUrl: './user-account-form.component.html',
  styleUrls: ['./user-account-form.component.scss']
})
export class UserAccountFormComponent implements OnInit {
  userAccountForm: FormGroup;
  userPasswordForm: FormGroup;
  bsConfig: any;
  activeTab = 1;
  activeSideTitle = 'personal';
  countries = [
    { name: 'Belgium', code: 'BE' },
    { name: 'Afghanistan', code: 'AF' },
    { name: 'Åland Islands', code: 'AX' },
    { name: 'Albania', code: 'AL' },
    { name: 'Algeria', code: 'DZ' },
    { name: 'American Samoa', code: 'AS' },
    { name: 'AndorrA', code: 'AD' },
    { name: 'Angola', code: 'AO' },
    { name: 'Anguilla', code: 'AI' },
    { name: 'Antarctica', code: 'AQ' },
    { name: 'Antigua and Barbuda', code: 'AG' },
    { name: 'Argentina', code: 'AR' },
    { name: 'Armenia', code: 'AM' },
    { name: 'Aruba', code: 'AW' },
    { name: 'Australia', code: 'AU' },
    { name: 'Austria', code: 'AT' },
    { name: 'Azerbaijan', code: 'AZ' },
    { name: 'Bahamas', code: 'BS' },
    { name: 'Bahrain', code: 'BH' },
    { name: 'Bangladesh', code: 'BD' },
    { name: 'Barbados', code: 'BB' },
    { name: 'Belarus', code: 'BY' },
    { name: 'Belgium', code: 'BE' },
    { name: 'Belize', code: 'BZ' },
    { name: 'Benin', code: 'BJ' },
    { name: 'Bermuda', code: 'BM' },
    { name: 'Bhutan', code: 'BT' },
    { name: 'Bolivia', code: 'BO' },
    { name: 'Bosnia and Herzegovina', code: 'BA' },
    { name: 'Botswana', code: 'BW' },
    { name: 'Bouvet Island', code: 'BV' },
    { name: 'Brazil', code: 'BR' },
    { name: 'British Indian Ocean Territory', code: 'IO' },
    { name: 'Brunei Darussalam', code: 'BN' },
    { name: 'Bulgaria', code: 'BG' },
    { name: 'Burkina Faso', code: 'BF' },
    { name: 'Burundi', code: 'BI' },
    { name: 'Cambodia', code: 'KH' },
    { name: 'Cameroon', code: 'CM' },
    { name: 'Canada', code: 'CA' },
    { name: 'Cape Verde', code: 'CV' },
    { name: 'Cayman Islands', code: 'KY' },
    { name: 'Central African Republic', code: 'CF' },
    { name: 'Chad', code: 'TD' },
    { name: 'Chile', code: 'CL' },
    { name: 'China', code: 'CN' },
    { name: 'Christmas Island', code: 'CX' },
    { name: 'Cocos (Keeling) Islands', code: 'CC' },
    { name: 'Colombia', code: 'CO' },
    { name: 'Comoros', code: 'KM' },
    { name: 'Congo', code: 'CG' },
    { name: 'Congo, The Democratic Republic of the', code: 'CD' },
    { name: 'Cook Islands', code: 'CK' },
    { name: 'Costa Rica', code: 'CR' },
    { name: 'Cote D\'Ivoire', code: 'CI' },
    { name: 'Croatia', code: 'HR' },
    { name: 'Cuba', code: 'CU' },
    { name: 'Cyprus', code: 'CY' },
    { name: 'Czech Republic', code: 'CZ' },
    { name: 'Denmark', code: 'DK' },
    { name: 'Djibouti', code: 'DJ' },
    { name: 'Dominica', code: 'DM' },
    { name: 'Dominican Republic', code: 'DO' },
    { name: 'Ecuador', code: 'EC' },
    { name: 'Egypt', code: 'EG' },
    { name: 'El Salvador', code: 'SV' },
    { name: 'Equatorial Guinea', code: 'GQ' },
    { name: 'Eritrea', code: 'ER' },
    { name: 'Estonia', code: 'EE' },
    { name: 'Ethiopia', code: 'ET' },
    { name: 'Falkland Islands (Malvinas)', code: 'FK' },
    { name: 'Faroe Islands', code: 'FO' },
    { name: 'Fiji', code: 'FJ' },
    { name: 'Finland', code: 'FI' },
    { name: 'France', code: 'FR' },
    { name: 'French Guiana', code: 'GF' },
    { name: 'French Polynesia', code: 'PF' },
    { name: 'French Southern Territories', code: 'TF' },
    { name: 'Gabon', code: 'GA' },
    { name: 'Gambia', code: 'GM' },
    { name: 'Georgia', code: 'GE' },
    { name: 'Germany', code: 'DE' },
    { name: 'Ghana', code: 'GH' },
    { name: 'Gibraltar', code: 'GI' },
    { name: 'Greece', code: 'GR' },
    { name: 'Greenland', code: 'GL' },
    { name: 'Grenada', code: 'GD' },
    { name: 'Guadeloupe', code: 'GP' },
    { name: 'Guam', code: 'GU' },
    { name: 'Guatemala', code: 'GT' },
    { name: 'Guernsey', code: 'GG' },
    { name: 'Guinea', code: 'GN' },
    { name: 'Guinea-Bissau', code: 'GW' },
    { name: 'Guyana', code: 'GY' },
    { name: 'Haiti', code: 'HT' },
    { name: 'Heard Island and Mcdonald Islands', code: 'HM' },
    { name: 'Holy See (Vatican City State)', code: 'VA' },
    { name: 'Honduras', code: 'HN' },
    { name: 'Hong Kong', code: 'HK' },
    { name: 'Hungary', code: 'HU' },
    { name: 'Iceland', code: 'IS' },
    { name: 'India', code: 'IN' },
    { name: 'Indonesia', code: 'ID' },
    { name: 'Iran, Islamic Republic Of', code: 'IR' },
    { name: 'Iraq', code: 'IQ' },
    { name: 'Ireland', code: 'IE' },
    { name: 'Isle of Man', code: 'IM' },
    { name: 'Israel', code: 'IL' },
    { name: 'Italy', code: 'IT' },
    { name: 'Jamaica', code: 'JM' },
    { name: 'Japan', code: 'JP' },
    { name: 'Jersey', code: 'JE' },
    { name: 'Jordan', code: 'JO' },
    { name: 'Kazakhstan', code: 'KZ' },
    { name: 'Kenya', code: 'KE' },
    { name: 'Kiribati', code: 'KI' },
    { name: 'Korea, Democratic People\'S Republic of', code: 'KP' },
    { name: 'Korea, Republic of', code: 'KR' },
    { name: 'Kuwait', code: 'KW' },
    { name: 'Kyrgyzstan', code: 'KG' },
    { name: 'Lao People\'S Democratic Republic', code: 'LA' },
    { name: 'Latvia', code: 'LV' },
    { name: 'Lebanon', code: 'LB' },
    { name: 'Lesotho', code: 'LS' },
    { name: 'Liberia', code: 'LR' },
    { name: 'Libyan Arab Jamahiriya', code: 'LY' },
    { name: 'Liechtenstein', code: 'LI' },
    { name: 'Lithuania', code: 'LT' },
    { name: 'Luxembourg', code: 'LU' },
    { name: 'Macao', code: 'MO' },
    { name: 'Macedonia, The Former Yugoslav Republic of', code: 'MK' },
    { name: 'Madagascar', code: 'MG' },
    { name: 'Malawi', code: 'MW' },
    { name: 'Malaysia', code: 'MY' },
    { name: 'Maldives', code: 'MV' },
    { name: 'Mali', code: 'ML' },
    { name: 'Malta', code: 'MT' },
    { name: 'Marshall Islands', code: 'MH' },
    { name: 'Martinique', code: 'MQ' },
    { name: 'Mauritania', code: 'MR' },
    { name: 'Mauritius', code: 'MU' },
    { name: 'Mayotte', code: 'YT' },
    { name: 'Mexico', code: 'MX' },
    { name: 'Micronesia, Federated States of', code: 'FM' },
    { name: 'Moldova, Republic of', code: 'MD' },
    { name: 'Monaco', code: 'MC' },
    { name: 'Mongolia', code: 'MN' },
    { name: 'Montserrat', code: 'MS' },
    { name: 'Morocco', code: 'MA' },
    { name: 'Mozambique', code: 'MZ' },
    { name: 'Myanmar', code: 'MM' },
    { name: 'Namibia', code: 'NA' },
    { name: 'Nauru', code: 'NR' },
    { name: 'Nepal', code: 'NP' },
    { name: 'Netherlands', code: 'NL' },
    { name: 'Netherlands Antilles', code: 'AN' },
    { name: 'New Caledonia', code: 'NC' },
    { name: 'New Zealand', code: 'NZ' },
    { name: 'Nicaragua', code: 'NI' },
    { name: 'Niger', code: 'NE' },
    { name: 'Nigeria', code: 'NG' },
    { name: 'Niue', code: 'NU' },
    { name: 'Norfolk Island', code: 'NF' },
    { name: 'Northern Mariana Islands', code: 'MP' },
    { name: 'Norway', code: 'NO' },
    { name: 'Oman', code: 'OM' },
    { name: 'Pakistan', code: 'PK' },
    { name: 'Palau', code: 'PW' },
    { name: 'Palestinian Territory, Occupied', code: 'PS' },
    { name: 'Panama', code: 'PA' },
    { name: 'Papua New Guinea', code: 'PG' },
    { name: 'Paraguay', code: 'PY' },
    { name: 'Peru', code: 'PE' },
    { name: 'Philippines', code: 'PH' },
    { name: 'Pitcairn', code: 'PN' },
    { name: 'Poland', code: 'PL' },
    { name: 'Portugal', code: 'PT' },
    { name: 'Puerto Rico', code: 'PR' },
    { name: 'Qatar', code: 'QA' },
    { name: 'Reunion', code: 'RE' },
    { name: 'Romania', code: 'RO' },
    { name: 'Russian Federation', code: 'RU' },
    { name: 'RWANDA', code: 'RW' },
    { name: 'Saint Helena', code: 'SH' },
    { name: 'Saint Kitts and Nevis', code: 'KN' },
    { name: 'Saint Lucia', code: 'LC' },
    { name: 'Saint Pierre and Miquelon', code: 'PM' },
    { name: 'Saint Vincent and the Grenadines', code: 'VC' },
    { name: 'Samoa', code: 'WS' },
    { name: 'San Marino', code: 'SM' },
    { name: 'Sao Tome and Principe', code: 'ST' },
    { name: 'Saudi Arabia', code: 'SA' },
    { name: 'Senegal', code: 'SN' },
    { name: 'Serbia and Montenegro', code: 'CS' },
    { name: 'Seychelles', code: 'SC' },
    { name: 'Sierra Leone', code: 'SL' },
    { name: 'Singapore', code: 'SG' },
    { name: 'Slovakia', code: 'SK' },
    { name: 'Slovenia', code: 'SI' },
    { name: 'Solomon Islands', code: 'SB' },
    { name: 'Somalia', code: 'SO' },
    { name: 'South Africa', code: 'ZA' },
    { name: 'South Georgia and the South Sandwich Islands', code: 'GS' },
    { name: 'Spain', code: 'ES' },
    { name: 'Sri Lanka', code: 'LK' },
    { name: 'Sudan', code: 'SD' },
    { name: 'Suriname', code: 'SR' },
    { name: 'Svalbard and Jan Mayen', code: 'SJ' },
    { name: 'Swaziland', code: 'SZ' },
    { name: 'Sweden', code: 'SE' },
    { name: 'Switzerland', code: 'CH' },
    { name: 'Syrian Arab Republic', code: 'SY' },
    { name: 'Taiwan, Province of China', code: 'TW' },
    { name: 'Tajikistan', code: 'TJ' },
    { name: 'Tanzania, United Republic of', code: 'TZ' },
    { name: 'Thailand', code: 'TH' },
    { name: 'Timor-Leste', code: 'TL' },
    { name: 'Togo', code: 'TG' },
    { name: 'Tokelau', code: 'TK' },
    { name: 'Tonga', code: 'TO' },
    { name: 'Trinidad and Tobago', code: 'TT' },
    { name: 'Tunisia', code: 'TN' },
    { name: 'Turkey', code: 'TR' },
    { name: 'Turkmenistan', code: 'TM' },
    { name: 'Turks and Caicos Islands', code: 'TC' },
    { name: 'Tuvalu', code: 'TV' },
    { name: 'Uganda', code: 'UG' },
    { name: 'Ukraine', code: 'UA' },
    { name: 'United Arab Emirates', code: 'AE' },
    { name: 'United Kingdom', code: 'GB' },
    { name: 'United States', code: 'US' },
    { name: 'United States Minor Outlying Islands', code: 'UM' },
    { name: 'Uruguay', code: 'UY' },
    { name: 'Uzbekistan', code: 'UZ' },
    { name: 'Vanuatu', code: 'VU' },
    { name: 'Venezuela', code: 'VE' },
    { name: 'Viet Nam', code: 'VN' },
    { name: 'Virgin Islands, British', code: 'VG' },
    { name: 'Virgin Islands, U.S.', code: 'VI' },
    { name: 'Wallis and Futuna', code: 'WF' },
    { name: 'Western Sahara', code: 'EH' },
    { name: 'Yemen', code: 'YE' },
    { name: 'Zambia', code: 'ZM' },
    { name: 'Zimbabwe', code: 'ZW' }
  ];
  industryList = [
    { code: 'accounting', title: 'Comptabilité' },
    { code: 'airline', title: 'Compagnies aériennes/Aviation' },
    { code: 'altDisputeResol', title: 'Résolution alternative des conflits' },
    { code: 'alternativeMed', title: 'Médecine alternative' },
    { code: 'animation', title: 'Animation ' },
    { code: 'apparel', title: 'Habillement/Mode' },
    { code: 'architecture', title: 'Architecture/Planification' },
    { code: 'arts', title: 'Arts/Artisanat' },
    { code: 'automative', title: 'Automobile' },
    { code: 'aviation', title: 'Aviation/Aérospatial' },
    { code: 'banking', title: 'Banque/Hypothèque' },
    { code: 'biotech', title: 'Biotechnologies/Technologies vertes' },
    { code: 'broascast', title: 'Médias audiovisuels' },
    { code: 'buildingMaterials', title: 'Matériaux de construction' },
    { code: 'businessSupp', title: 'Fournitures et équipements destinés aux entreprises' },
    { code: 'capitalMarkets', title: 'Marchés de capitaux/Fonds spéculatifs/Capital-investissement' },
    { code: 'chemicals', title: 'Produits chimiques' },
    { code: 'civicSocial', title: 'Administration civique/Organisation sociale' },
    { code: 'civilEng', title: 'Génie civil' },
    { code: 'comercialRealEst', title: 'Immobilier commercial' },
    { code: 'compGames', title: 'Jeux informatiques' },
    { code: 'compHardware', title: 'Matériel informatique' },
    { code: 'compNetwkng', title: 'Réseaux informatiques' },
    { code: 'compSftEng', title: 'Logiciels/Ingénierie informatique' },
    { code: 'compNtwSec', title: 'Sécurité informatique et des réseaux' },
    { code: 'construction', title: 'Construction' },
    { code: 'consumerElec', title: 'Produits électroniques grand public' },
    { code: 'consumerGoods', title: 'Biens de consommation' },
    { code: 'consumerServ', title: 'Services aux consommateurs' },
    { code: 'cosmetics', title: 'Cosmétiques' },
    { code: 'dairy', title: 'Produits laitiers' },
    { code: 'defence', title: 'Défense/Aéronautique' },
    { code: 'design', title: 'Design' },
    { code: 'elearning', title: 'E-Learning' },
    { code: 'eduMgmt', title: 'Gestion de l’éducation' },
    { code: 'electrical', title: 'Fabrication d’appareils électriques/électroniques' },
    { code: 'entertainment', title: 'Divertissement/Production cinématographique' },
    { code: 'environmentalService', title: 'Services environnementaux' },
    { code: 'eventsServices', title: 'Événementiel' },
    { code: 'executiveOff', title: 'Bureau exécutif' },
    { code: 'facServices', title: 'Services liés aux installations et équipements' },
    { code: 'farming', title: 'Agriculture' },
    { code: 'financialServ', title: 'Services financiers' },
    { code: 'fineArt', title: 'Beaux-Arts' },
    { code: 'fishery', title: 'Pêche' },
    { code: 'foodProd', title: 'Production alimentaire' },
    { code: 'foodBev', title: 'Nourriture/Boissons' },
    { code: 'fundraising', title: 'Collecte de fonds' },
    { code: 'furniture', title: 'Ameublement' },
    { code: 'gambling', title: 'Jeux de hasard/Casinos' },
    { code: 'glass', title: 'Verre/Céramique/Béton' },
    { code: 'govAdmin', title: 'Administration publique' },
    { code: 'govRel', title: 'Relations gouvernementales' },
    { code: 'graphicDesign', title: 'Graphisme/Conception de sites Internet' },
    { code: 'health', title: 'Santé/Activité physique' },
    { code: 'higherEdu', title: 'Enseignement supérieur/universitaire' },
    { code: 'hospitalCare', title: 'Hôpital/Soins de santé' },
    { code: 'hospitality', title: 'Hôtellerie' },
    { code: 'hr', title: 'Ressources humaines' },
    { code: 'importExp', title: 'Import/Export' },
    { code: 'individualServ', title: 'Services aux particuliers et aux familles' },
    { code: 'industrialAutomation', title: 'Automatisation industrielle' },
    { code: 'infoServices', title: 'Services d’information' },
    { code: 'infoTech', title: 'Technologies de l’information' },
    { code: 'insurance', title: 'Assurances' },
    { code: 'internationalAffr', title: 'Affaires internationales' },
    { code: 'law', title: 'Droit/Cabinet d’avocats' },
    { code: 'legalServ', title: 'Services juridiques' },
    { code: 'legislativeOff', title: 'Bureau législatif' },
    { code: 'leisureTravel', title: 'Loisirs/Voyages' },
    { code: 'library', title: 'Bibliothèque' },
    { code: 'logistics', title: 'Logistique/Approvisionnement' },
    { code: 'luxuryGoods', title: 'Produits de luxe/Joaillerie' },
    { code: 'machinery', title: 'Machines' },
    { code: 'mgmtConsulting', title: 'Conseil en gestion' },
    { code: 'maitime', title: 'Maritime' },
    { code: 'marketResearch', title: 'Études de marché' },
    { code: 'marketSales', title: 'Marketing/Publicité/Ventes' },
    { code: 'mechEng', title: 'Génie mécanique ou industriel' },
    { code: 'medicalEquip', title: 'Équipement médical' },
    { code: 'medicinalPrac', title: 'Pratique médicale' },
    { code: 'museums', title: 'Musées/Institutions' },
    { code: 'music', title: 'Musique' },
    { code: 'nanotechnology', title: 'Nanotechnologies' },
    { code: 'newspapers', title: 'Journaux/Journalisme' },
    { code: 'volunteering', title: 'Volontariat/Bénévolat' },
    { code: 'oilEngergy', title: 'Pétrole/Énergie/Solaire/Technologies vertes' },
    { code: 'onlinePublish', title: 'Publication en ligne' },
    { code: 'otherIndustry', title: 'Autre secteur' },
    { code: 'outsourcing', title: 'Externalisation/délocalisation' },
    { code: 'pkgDelivery', title: 'Livraison de colis et de fret' },
    { code: 'packaging', title: 'Emballages/Conteneurs' },
    { code: 'paperProducts', title: 'Papier/Produits forestiers' },
    { code: 'performingArts', title: 'Arts de la scène' },
    { code: 'pharamceuticals', title: 'Produits pharmaceutiques' },
    { code: 'philanthropy', title: 'Philanthropie' },
    { code: 'photography', title: 'Photographie' },
    { code: 'plastics', title: 'Plastiques' },
    { code: 'politicalOrganization', title: 'Organisation politique' },
    { code: 'primaryEdu', title: 'Enseignement primaire/secondaire' },
    { code: 'printig', title: 'Imprimerie' },
    { code: 'profTraining', title: 'Formation professionnelle' },
    { code: 'programDev', title: 'Élaboration de programmes' },
    { code: 'publicRelPR', title: 'Relations publiques' },
    { code: 'publicSafety', title: 'Sécurité publique' },
    { code: 'publishingIndustry', title: 'Édition' },
    { code: 'railroadManufacture', title: 'Construction ferroviaire' },
    { code: 'ranching', title: 'Élevage' },
    { code: 'realEstate', title: 'Biens immobiliers/hypothèques' },
    { code: 'recreational', title: 'Installations/services récréatifs' },
    { code: 'religiousInst', title: 'Institutions religieuses' },
    { code: 'renewable', title: 'Énergies renouvelables/Environnement' },
    { code: 'researchIndustry', title: 'Recherche' },
    { code: 'retaurants', title: 'Restauration' },
    { code: 'retailIndustry', title: 'Vente au détail' },
    { code: 'securityInvestigations', title: 'Sécurité/Enquêtes' },
    { code: 'semiconductors', title: 'Semi-conducteurs' },
    { code: 'shipbuilding', title: 'Construction navale' },
    { code: 'sportsGoods', title: 'Articles de sport' },
    { code: 'sports', title: 'Sports' },
    { code: 'staffing', title: 'Personnel/Recrutement' },
    { code: 'superMarkets', title: 'Supermarchés' },
    { code: 'telecommunications', title: 'Télécommunications' },
    { code: 'textiles', title: 'Textiles' },
    { code: 'thinkTanks', title: 'Groupes de réflexion' },
    { code: 'tobacco', title: 'Tabac' },
    { code: 'tranlation', title: 'Traduction/Localisation' },
    { code: 'transportation', title: 'Transport' },
    { code: 'utilites', title: 'Services publics' },
    { code: 'venture', title: 'Capital-risque' },
    { code: 'vet', title: 'Vétérinaire' },
    { code: 'warehousing', title: 'Entreposage' },
    { code: 'wholesale', title: 'Vente en gros' },
    { code: 'wine', title: 'Vins/Spiritueux' },
    { code: 'wireliess', title: 'Technologies sans fil' },
    { code: 'writing', title: 'Rédaction/Édition' }
  ];
  jobTitles = [
    { title: 'Employee', code: 'Employee' },
    { title: 'Looking for a job', code: 'LookingJob' },
    { title: 'Entrepreneur', code: 'Entrepreneur' },
    { title: 'Student', code: 'Student' },
    { title: 'Young Graduate', code: 'YoungGraduate' },
    { title: 'Manager', code: 'Manager' },
    { title: 'Member of a merchant association', code: 'MerchantAssociation' },
    { title: 'Member of a residents\' association', code: 'ResidentOrAssociation' },
    { title: 'Partner', code: 'Partner' },
    { title: 'CEO', code: 'CEO' },
    { title: 'Trainee', code: 'Trainee' },
    { title: 'Other', code: 'Other' },
    // { title: 'Programmer', code: 'Programmer' },
    // { title: 'Solutions Architect', code: 'SA' },
    // { title: 'Database Developer', code: 'DBA' },
    // { title: 'Accountant', code: 'Accountant' },
    // { title: 'Payroll Officer', code: 'PayrollOfficer' },
    // { title: 'Accounts Clerk', code: 'AccountClerk' },
    // { title: 'Analyst', code: 'Analyst' },
    // { title: 'Financial Controller', code: 'FinancialController' },
    // { title: 'Recruitment Consultant', code: 'RecruitmentConsultant' },
    // { title: 'Change Management', code: 'ChangeManagement' },
    // { title: 'Industrial Relations', code: 'IndustrialRelations' },
    // { title: 'Market Researcher', code: 'MarketResearcher' },
    // { title: 'Marketing Manager', code: 'MarketingManager' },
    // { title: 'Marketing Co-ordinator', code: 'MarketingCoordinator' }

  ];
  currentUser: any;
  encrypt: any;
  param: any = {};
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  selectedLanguage: string;
  deleteModalTitle: string;
  deleletAreYouSureText: string;
  deleteYesText: string;
  deleteNoText: string;
  disableDeleteButton = false;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private utilityService: UtilityService,
    private translate: TranslateService,
    private notificationService: NotificationService,
    private router: Router,
    private generalService: GeneralService) { }

  ngOnInit() {
    this.buildForms();
    this.bsConfig = Object.assign({}, { containerClass: 'theme-blue', dateInputFormat: 'YYYY-DD-MM' });
    this.loadUser();
    this.selectedLanguage = localStorage.getItem('language');
    this.translate.onLangChange.subscribe(event => {
      this.selectedLanguage = event.lang;
      this.setDeleteMessages();
    });
    this.setDeleteMessages();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      if (user) {
        this.currentUser = user;
        if (this.currentUser.role === 'admin' || this.currentUser.role === 'champion') {
          this.disableDeleteButton = true;
        } else {
          this.disableDeleteButton = false;
        }
        this.setUserAccountData();
        // console.log('setUserAccountData', 'setUserAccountData');
      }
    });
  }

  buildForms() {
    this.userAccountForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      dateOfBirth: ['', Validators.required],
      gender: ['', Validators.required],
      phoneNumber: ['', Validators.required],
      email: ['', Validators.required],
      language: ['', Validators.required],
      country: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      zipCode: ['', Validators.required],
      address: ['', Validators.required],
      companyName: ['', Validators.required],
      industry: ['', Validators.required],
      jobTitle: ['', Validators.required]
    });
    this.userPasswordForm = this.formBuilder.group({
      oldPassword: ['', Validators.required],
      newPassword: ['', Validators.required],
      confirmNewPassword: ['', Validators.required]
    }, {
      validator: this.MustMatch('newPassword', 'confirmNewPassword')
    });

    this.userPasswordForm.get('newPassword').valueChanges.subscribe(value => {
      if (value) {
        this.param.strength = this.getPasswordStrength(value);
      }
    });
  }

  setUserAccountData() {

    if (this.currentUser.jobTitle === 'Looking for a job') {
      this.currentUser.jobTitle = 'LookingJob';
    }

    if (this.currentUser.jobTitle === 'Young Graduate') {
      this.currentUser.jobTitle = 'YoungGraduate';
    }

    if (this.currentUser.jobTitle === 'Member of a merchant association') {
      this.currentUser.jobTitle = 'MerchantAssociation';
    }

    if (this.currentUser.jobTitle === 'Member of a residents\' association') {
      this.currentUser.jobTitle = 'ResidentOrAssociation';
    }

    this.userAccountForm.patchValue({
      firstName: this.currentUser.firstName,
      lastName: this.currentUser.lastName,
      dateOfBirth: this.currentUser.dateOfBirth,
      gender: this.currentUser.gender,
      phoneNumber: this.currentUser.phoneNumber,
      email: this.currentUser.rawEmail,
      language: this.currentUser.language,
      country: this.currentUser.country,
      city: this.currentUser.city,
      state: this.currentUser.state,
      zipCode: this.currentUser.zipCode,
      address: this.currentUser.address,
      companyName: this.currentUser.companyName,
      industry: this.currentUser.industry,
      jobTitle: this.currentUser.jobTitle,
    });
  }
  onSectionSelect(value, id) {
    this.activeSideTitle = value;
    document.getElementById(id).scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
  }

  submit() {
    this.encrypt = new JSEncrypt();
    this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
    if (this.activeTab === 1) {
      let data = this.userAccountForm.value;
      data.role = this.currentUser.role;
      data.languageCode = this.currentUser.language; // data.language;
      data.roleCode = this.currentUser.role;
      data.userId = this.currentUser.id;
      data.id = this.currentUser.id;
      if (data.jobTitle === 'LookingJob') {
        data.jobTitle = 'Looking for a job';
      }

      if (data.jobTitle === 'YoungGraduate') {
        data.jobTitle = 'Young Graduate';
      }

      if (data.jobTitle === 'MerchantAssociation') {
        data.jobTitle = 'Member of a merchant association';
      }

      if (data.jobTitle === 'ResidentOrAssociation') {
        data.jobTitle = 'Member of a residents\' association';
      }
      data = this.utilityService.removeEmptyStringAndTrim(data);
      // console.log('data', data);
      // console.log(this.userAccountForm.value);
      this.generalService.updateUser(this.utilityService.removeEmptyStringAndTrim(data)).subscribe(res => {
        // console.log('res', res);
        // this.notificationService.showSuccess('Update successful.');
        this.utilityService.showTranslatedNotificationMessage('NotificationMessages.User.UserUpdated', 'SUCCESS');
        this.authService.updateCurrentUser(data);
      });
    } else if (this.activeTab === 2) {
      // console.log(this.userPasswordForm.value);
      if (this.userPasswordForm.valid) {
        let data = {
          oldPassword: this.encrypt.encrypt(this.userPasswordForm.value.oldPassword),
          newPassword: this.encrypt.encrypt(this.userPasswordForm.value.newPassword)
        };
        data = this.utilityService.removeEmptyStringAndTrim(data);
        this.authService.resetPassword(data).subscribe(res => {
          // this.notificationService.showSuccess('Password changed.');
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.User.UserPasswordChanged', 'SUCCESS');
          // console.log('res', res);
        });
      } else {
        // this.notificationService.showError('Please fill all details');
        this.utilityService.showTranslatedNotificationMessage('NotificationMessages.General.AllFieldsMandatory', 'ERROR');
      }
    }
  }

  // custom validator to check that two fields match
  MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        // return if another validator has already found an error on the matchingControl
        return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }

  onDelete(item?: any, user?: any) {
    this.genericConfirm.show({
      headlineText: this.deleteModalTitle,
      notConfirmText: this.deleteNoText,
      text: this.deleletAreYouSureText,
      confirmText: this.deleteYesText,
      callback: (result: any) => {
        // console.log('result', result);
        if (result) {
          const data = {
            roleCode: this.currentUser.role,
            languageCode: this.currentUser.language,
            userId: this.currentUser.id,
            id: this.currentUser.id
          };
          this.generalService.deleteUser(data).subscribe(res => {
            this.encrypt = new JSEncrypt();
            this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
            const userName = this.encrypt.encrypt(this.currentUser.rawEmail);
            // this.authService.logout(userName).subscribe((res2: any) => {
            //   window.location.href = '/';
            // });
            this.clearAllLocalData();
            // this.router.navigateByUrl('/');
            window.location.href = '/';
            // this.notificationService.showSuccess('User deleted successfully.');
            this.utilityService.showTranslatedNotificationMessage('NotificationMessages.User.UserDeleted', 'SUCCESS');

          });
        } else {
          // console.log('do not delete user');
        }
      }
    });
  }
  setDeleteMessages() {
    switch (this.selectedLanguage) {
      case 'en':
        this.deleteModalTitle = 'Delete account';
        this.deleletAreYouSureText = 'Are you sure you want to delete your account ?';
        this.deleteYesText = 'Yes';
        this.deleteNoText = 'No';
        break;
      case 'fr':
        this.deleteModalTitle = 'Supprimer compte';
        this.deleletAreYouSureText = 'Êtes-vous sûr de vouloir supprimer votre compte ? ';
        this.deleteYesText = 'Oui';
        this.deleteNoText = 'Non';
        break;
      case 'nl':
        this.deleteModalTitle = 'Verwijderen account';
        this.deleletAreYouSureText = 'Weet u zeker dat u uw account wilt verwijderen?';
        this.deleteYesText = 'Ja';
        this.deleteNoText = 'Nee';
        break;
    }
  }
  clearAllLocalData() {
    localStorage.clear();
    Cookie.deleteAll();
  }

  get firstName() {
    return this.userAccountForm.get('firstName');
  }

  get lastName() {
    return this.userAccountForm.get('lastName');
  }

  get language() {
    return this.userAccountForm.get('language');
  }

  getPasswordStrength(password: string) {

    // Must have capital letter, numbers and lowercase letters
    const strongRegex = new RegExp('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$', 'g');

    // Must have either capitals and lowercase letters or lowercase and numbers
    const mediumRegex = new RegExp('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$', 'g');
    // ((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|

    // Must be at least 6 characters long
    const okRegex = new RegExp('^(?=.*?[a-z]).{8,}$', 'g');

    if (okRegex.test(password) === false) {
      // If ok regex doesn't match the password
      // console.log('If ok regex doesn\'t match the password111');
      return 'Weak';
    } else if (strongRegex.test(password)) {
      // If reg ex matches strong password
      return 'Strong';
    } else if (mediumRegex.test(password)) {
      // If medium password matches the reg ex
      return 'Medium';
    } else {
      // console.log('If ok regex doesn\'t match the password');
      // If password is ok
      return 'Weak';
    }

  }

}
