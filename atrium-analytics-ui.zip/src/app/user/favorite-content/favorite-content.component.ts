import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { GeneralService } from 'src/app/user/shared/general.service';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { SharedDataServiceService } from 'src/app/core/services/shared-data-service.service';
import { Subscription } from 'rxjs';
@Component({
  selector: 'ab-favorite-content',
  templateUrl: './favorite-content.component.html',
  styleUrls: ['./favorite-content.component.scss'],
})
export class FavoriteContentComponent implements OnInit {
  constructor(
    private authService: AuthService,
    private generalService: GeneralService,
    private translate: TranslateService,
    private router: Router,
    private sharedData: SharedDataServiceService
  ) {}
  element = [];
  userBody;
  sharedContent = [];
  selectedLanguage;
  languageIndex;
  loader = false;
  delta = 2;
  currentPage = 1;
  pageSize = 7;
  total: number;
  totalPages = 2;
  activePage = 0;
  languageChangeSubscription: Subscription;


  loadUser() {
    this.authService.currentUser$.subscribe((user) => {
      this.userBody = {
        languageCode: user.language,
        roleCode: user.role,
        userId: user.id,
        dashboardLanguage: this.selectedLanguage
      };
    });
  }
  loadFavoriteContent(page) {
    this.userBody.dashboardLanguage = this.selectedLanguage;
    this.loader = true;
    this.sharedContent = [];
    this.element = [];
    this.generalService
      .favoriteElements(this.userBody, {
        size: 7,
        page: page - 1,
        loader: true,
      })
      .subscribe(
        (res) => {
          this.loader = false;
          this.total = res.value.totalElements;

          this.sharedContent = res.value.content;
          this.getElement();
        },
        (err: any) => {
          if (err.status === 400) {
          }
          this.loader = false;
        }
      );
  }
  getElement() {
    this.sharedContent.forEach((element) => {
      // tslint:disable-next-line: one-variable-per-declaration
      let date, title;
      const date1 = element.createdDate;
      const date2 = element.modifiedDate;
      if (date1 > date2) {
        title = 'CDate';
        date = date1;
      } else if (date1 === date2) {
        title = 'CDate';
        date = date1;
      } else {
        title = 'LDate';
        date = date2;
      }
      // tslint:disable-next-line: no-string-literal
      element.elementInfo['title'] = title;

      // tslint:disable-next-line: no-string-literal
      element.elementInfo['date'] = date;
      // tslint:disable-next-line: no-string-literal
      element.elementInfo['type'] = element.elementType;
      // tslint:disable-next-line: no-string-literal
      element.elementInfo['elementId'] = element.elementId;

      // tslint:disable-next-line: no-string-literal
      element.elementInfo['usersCount'] = element.usersCount;
      // tslint:disable-next-line: no-string-literal
      element.elementInfo['productType'] = element.productType;


      this.element.push(element.elementInfo);
      this.element.forEach((ele) => {
        ele.lang = ele.findIndex((x) => x.language.toLowerCase() === this.selectedLanguage);
      });
    });
  }
  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }
  onPageChange(event: { page: number }) {
    this.activePage = event.page;
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth',
    });
    this.currentPage = event.page;

    this.loadFavoriteContent(event.page);
    // // this.searchTerm = '';
  }
  goToPage(type, id) {
    if (this.activePage === 0) {
      this.sharedData.currentPage = this.sharedData.currentPage;
    } else {
      this.sharedData.currentPage = this.activePage;
    }
    if (type === 'viz' || type === 'visualisation') {
      // this.sharedData.currentPage = this.activePage;
      this.router.navigate([
        `/library/viz-details/${id}`,
        { previousUrl: 'favorite-content' },
      ]);
    }
    if (type === 'product'|| type === 'report') {
      // this.sharedData.currentPage = this.activePage;

      this.router.navigate([
        `/library/product-details/${id}`,
        { previousUrl: 'favorite-content' },
      ]);
    }
  }
  loadContent() {
    if (this.sharedData.currentPage !== 0) {
      this.currentPage = this.sharedData.currentPage;
      this.loadFavoriteContent(this.currentPage);
    } else {
      this.loadFavoriteContent(1);
    }
  }
  ngOnInit() {
    this.selectedLanguage = localStorage.getItem('language');
    this.loadUser();
    this.languageIndex =
      this.selectedLanguage === 'en'
        ? 0
        : this.selectedLanguage === 'fr'
        ? 1
        : 2;
    this.loadContent();
    this.languageChangeSubscription = this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.currentPage = 1;
      this.sharedData.currentPage = 0;
      this.selectedLanguage = event.lang;
      this.languageIndex =
        this.selectedLanguage === 'en'
          ? 0
          : this.selectedLanguage === 'fr'
          ? 1
          : 2;
      if (this.router.url === '/user/dashboard/favorite-content') {
            this.loadContent();

          }
      // this.productRecords = true;
      // this.vizRecords = true;
      // this.setMessage(this.selectedLanguage);
    });
  }
  // tslint:disable-next-line: use-lifecycle-interface
  ngOnDestroy() {

    if (this.languageChangeSubscription) {
      this.languageChangeSubscription.unsubscribe();
    }
  }
}
