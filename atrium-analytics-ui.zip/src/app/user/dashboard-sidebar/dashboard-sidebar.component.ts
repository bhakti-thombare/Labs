import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { SharedDataServiceService } from 'src/app/core/services/shared-data-service.service';
import { Router, NavigationEnd } from '@angular/router';
import * as _ from 'lodash' ;
@Component({
  selector: 'ab-dashboard-sidebar',
  templateUrl: './dashboard-sidebar.component.html',
  styleUrls: ['./dashboard-sidebar.component.scss'],
})
export class DashboardSidebarComponent implements OnInit {
  menuList = [];
  selectedId: number;
  currentUser: any;
  checkAdminRole = false;
  constructor(
    private authService: AuthService,
    private sharedData: SharedDataServiceService,
    private router: Router
  ) {}
  menuDashboard;

  selectedOption(title) {
    this.sharedData.currentPage = 0;
    this.menuList.forEach((menu) => {
      menu.activeFlag = false;
      if (title === menu.title) {
        menu.activeFlag = true;
      }
    });
  }
  ngOnInit() {
    this.router.events.subscribe((val) => {
      if (val instanceof NavigationEnd) {
        window.location.href.includes('favorite')
          ? (this.menuDashboard = 'Favorites')
          : window.location.href.includes('shared')
          ? (this.menuDashboard = 'SharedContent')
          : window.location.href.includes('draft')
          ? (this.menuDashboard = 'Drafts')
          : window.location.href.includes('user-list')
          ? (this.menuDashboard = 'UserManagement')
          : window.location.href.includes('tags')
          ? (this.menuDashboard = 'TagManagement')
          : window.location.href.includes('private')
          ? (this.menuDashboard = 'PrivateProducts')
          : (this.menuDashboard = 'Dashboard');

        this.menuList.forEach((menu) => {
          if (this.menuDashboard === menu.title) {
            menu.activeFlag = true;
          } else {
            menu.activeFlag = false;
          }
        });
      }
    });
    this.loadUser();
    window.location.href.includes('favorite')
      ? (this.menuDashboard = 'Favorites')
      : window.location.href.includes('shared')
      ? (this.menuDashboard = 'SharedContent')
      : window.location.href.includes('draft')
      ? (this.menuDashboard = 'Drafts')
      : window.location.href.includes('user-list')
      ? (this.menuDashboard = 'UserManagement')
      : window.location.href.includes('tags')
      ? (this.menuDashboard = 'TagManagement')
      : window.location.href.includes('private')
      ? (this.menuDashboard = 'PrivateProducts')
      : (this.menuDashboard = 'Dashboard');

    this.menuList.forEach((menu) => {
      if (this.menuDashboard === menu.title) {
        menu.activeFlag = true;
      }
    });
  }

  loadUser() {
    this.authService.currentUser$.subscribe((user) => {
      this.currentUser = user;
      if (this.currentUser.role === 'admin') {
        this.checkAdminRole = true;
        this.menuList.push(
          { title: 'Dashboard', route: '/user/dashboard', activeFlag: false },
          {
            title: 'Favorites',
            route: '/user/dashboard/favorite-content',
            activeFlag: false,
          },
          {
            title: 'SharedContent',
            route: '/user/dashboard/shared-content',
            activeFlag: false,
          },
          {
            title: 'Drafts',
            route: '/user/dashboard/draft-content',
            activeFlag: false,
          },
          {
            title: 'PrivateProducts',
            route: '/user/dashboard/private-product',
            activeFlag: false,
          },
          {
            title: 'UserManagement',
            route: '/user/dashboard/user-list',
            activeFlag: false,
          },
          {
            title: 'TagManagement',
            route: '/user/dashboard/tags',
            activeFlag: false,
          }
        );
      } else if (this.currentUser.role === 'champion') {
        this.menuList.push(
          { title: 'Dashboard', route: '/user/dashboard', activeFlag: false },
          {
            title: 'Favorites',
            route: '/user/dashboard/favorite-content',
            activeFlag: false,
          },
          {
            title: 'SharedContent',
            route: '/user/dashboard/shared-content',
            activeFlag: false,
          },
          {
            title: 'PrivateProducts',
            route: '/user/dashboard/private-product',
            activeFlag: false,
          },
          {
            title: 'Drafts',
            route: '/user/dashboard/draft-content',
            activeFlag: false,
          }
        );
      } else if (
        this.currentUser.role === 'private_hubster' ||
        this.currentUser.role === 'private_subscriber'
      ) {
        this.menuList.push(
          { title: 'Dashboard', route: '/user/dashboard', activeFlag: false },
          {
            title: 'Favorites',
            route: '/user/dashboard/favorite-content',
            activeFlag: false,
          },
          {
            title: 'SharedContent',
            route: '/user/dashboard/shared-content',
            activeFlag: false,
          }
        );
      } else if (
        this.currentUser.role === 'public_subscriber' ||
        this.currentUser.role === 'public_hubster'
      ) {
        this.menuList.push(
          { title: 'Dashboard', route: '/user/dashboard', activeFlag: false },
          {
            title: 'Favorites',
            route: '/user/dashboard/favorite-content',
            activeFlag: false,
          },
          {
            title: 'SharedContent',
            route: '/user/dashboard/shared-content',
            activeFlag: false,
          }
        );
      }
      this.menuList = _.uniqBy(this.menuList, 'title');
    });
  }
}
