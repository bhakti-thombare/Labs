import { Component, OnInit, ViewRef, ChangeDetectorRef, AfterViewChecked, AfterViewInit } from '@angular/core';
import { Cookie } from 'src/app/core/services/cookie';
import { Orientation, GuidedTour, GuidedTourService, TourStep } from 'ngx-guided-tour';
import { LoaderService } from 'src/app/core/services/loader.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { GeneralService } from '../shared/general.service';

@Component({
  selector: 'ab-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, AfterViewInit {
  messageObject: { HSDashboardTutorialText: { Step1: string; Step2: string; Step3: string; }; };
  selectedLanguage = localStorage.getItem('language');
  guidedTour: GuidedTour;
  currentUser: any;
  tutorialCalled = true;
  observer: MutationObserver;

  constructor(
    private generalService: GeneralService,
    private authService: AuthService,
    private router: Router,
    private loaderService: LoaderService,
    private cdRef: ChangeDetectorRef,
    private utilityService: UtilityService,
    private guidedTourService: GuidedTourService,
    private translate: TranslateService
  ) { }

  ngOnInit() {
    this.loadUser();
    this.setTourMessages ();
    this.translate.onLangChange.subscribe(event => {
      this.selectedLanguage = event.lang;
      this.setTourMessages();
    });
    this.utilityService.startTour.subscribe(res => {
      if (res) {
        if (this.router.url.toString().includes('/user/dashboard')) { this.startTour(); }
      }
    });

    this.observer = new MutationObserver((dom) => {
      // console.log('dom', dom)
      if (document.getElementsByClassName('HSD-1').length) {
        // console.log('document.getElementById(\'HSD-1\')', document.getElementsByClassName('HSD-1')[0])
        // console.log('document.getElementById(\'HSD-1\')', document.getElementsByClassName('HSD-1')[0].parentElement.parentElement);
        const tourblock = document.getElementsByClassName('HSD-1')[0].parentElement.parentElement;
        tourblock.style.top = '-24px';
        tourblock.style.left = '25px';
      }
      if (document.getElementsByClassName('HSD-2').length) {
        // console.log('document.getElementById(\'HSD-2\')', document.getElementsByClassName('HSD-2')[0])
        // console.log('document.getElementById(\'HSD-2\')', document.getElementsByClassName('HSD-2')[0].parentElement.parentElement);
        const tourblock = document.getElementsByClassName('HSD-2')[0].parentElement.parentElement;
        tourblock.style.top = 'unset';
        tourblock.style.left = '25px';
      }
      if (document.getElementsByClassName('HSD-3').length) {
        // console.log('document.getElementById(\'HSD-3\')', document.getElementsByClassName('HSD-3')[0])
        // console.log('document.getElementById(\'HSD-3\')', document.getElementsByClassName('HSD-3')[0].parentElement.parentElement);
        const tourblock = document.getElementsByClassName('HSD-3')[0].parentElement.parentElement;
        tourblock.style.top = 'unset';
        tourblock.style.left = '25px';
      }
    });
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }
  ngAfterViewInit() {
    if (this.cdRef && !(this.cdRef as ViewRef).destroyed) {
      this.cdRef.detectChanges();
    }
    // this.startTour();
    this.loaderService.isLoading.subscribe(v => {
      if (!v) {
        if (this.currentUser) {
          if (this.currentUser.role !== 'admin' && this.currentUser.role !== 'champion') {
            if (this.currentUser.tutorialDashboard) {
              const data = {
                tutorialDashboard: false,
                tutorialLibrary: this.currentUser.tutorialLibrary,
                tutorialProduct: this.currentUser.tutorialProduct
              };
              if (this.tutorialCalled) {
                const queryParams = {
                  loader: true
                };
                this.tutorialCalled = false;
                this.generalService.updateTutorialFlags(data, queryParams).subscribe(res => {
                  this.currentUser.tutorialDashboard = false;
                  this.authService.updateCurrentUser(this.currentUser);
                });
              }
              this.startTour();
            }
          }
        } else {
          this.setCookieForHSDashboardTutorial();
        }
      }
    });
  }

  startTour() {
    // console.log('Starting the tour for product');
    this.observer.observe(document.getElementsByTagName('ngx-guided-tour')[0], { subtree: true, characterData: true, childList: true });
    const tourSteps: TourStep[] = [
      {
        selector: '.HSDashboard-step-one',
        content: `<p class="HSD-1">
        ${this.messageObject.HSDashboardTutorialText.Step1}
        <p>`,
        orientation: Orientation.Right,
        skipStep: false,
        // scrollAdjustment: -1000
      },
      {
        selector: '.HSDashboard-step-two',
        content: `<p class="HSD-2">${this.messageObject.HSDashboardTutorialText.Step2}</p>`,
        orientation: Orientation.Right,
        skipStep: false,
      },
      {
        selector: '.HSDashboard-step-three',
        content: `<p class="HSD-3">${this.messageObject.HSDashboardTutorialText.Step3}</p>`,
        orientation: Orientation.Right,
        skipStep: false,
        // scrollAdjustment: 1000
      }

    ];
    this.guidedTour = {
      tourId: 'user-dashboard',
      useOrb: false,
      steps: tourSteps,
      skipCallback: () => {
        this.utilityService.startTour.next(false);
        this.observer.disconnect();
        // this.observer = undefined;
      },
      completeCallback: () => {
        this.utilityService.startTour.next(false);
        this.observer.disconnect();
        // this.observer = undefined;
        // console.log('this.observer', this.observer)
      },
      preventBackdropFromAdvancing: true,
    };
    // console.log('starting tour')
    this.guidedTourService.startTour(this.guidedTour);
    if (this.cdRef && !(this.cdRef as ViewRef).destroyed) {
      this.cdRef.detectChanges();
      this.cdRef.detectChanges();
    }
  }

  setTourMessages() {
    if (this.selectedLanguage === 'en') {
      this.messageObject = {
        HSDashboardTutorialText: {
          Step1: 'Access your account and modify your personal information.',
          Step2: 'Find here reports and vizualisations that were shared with you. This section can be empty.',
          Step3: 'Find here reports and vizualisations you have saved. This section can be empty.'
        }
      };
    }
    if (this.selectedLanguage === 'nl') {
      this.messageObject = {
        HSDashboardTutorialText: {
          Step1: 'Ga naar uw account en pas uw persoonlijke gegevens aan.',
          Step2: 'Hier vindt u de rapporten en visualisaties die met u zijn gedeeld. Deze sectie kan leeg zijn.',
          Step3: 'Hier vindt u de rapporten en visualisaties die u heeft opgeslagen. Deze sectie kan leeg zijn.'
        }
      };
    }
    if (this.selectedLanguage === 'fr') {
      this.messageObject = {
        HSDashboardTutorialText: {
          Step1: 'Accédez à votre compte et modifiez vos informations personnelles.',
          Step2: `Trouvez les rapports et les visualisations qui ont été partagés avec vous. Cette section peut être vide.`,
          Step3: `Trouvez les rapports et les visualisations que vous avez sauvegardés. Cette section peut être vide.`,
        }
      };
    }
  }
  setCookieForHSDashboardTutorial() {
    if (!Cookie.get('HSDashboard_page_visited')) {
      this.startTour();
      Cookie.set('HSDashboard_page_visited',
        'yes',
        new Date(new Date().setFullYear(new Date().getFullYear() + 10)),
        '/',
        Cookie.get('_host'));

    }
  }

}
