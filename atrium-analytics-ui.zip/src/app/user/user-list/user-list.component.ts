import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { AuthService } from 'src/app/core/services/auth.service';
import { GeneralService } from '../shared/general.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { FormControl } from '@angular/forms';
import { distinctUntilChanged, switchMap, tap, filter, retry, retryWhen, catchError, debounceTime, takeUntil } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';

@Component({
  selector: 'ab-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {
  modalRef: any;
  selectedSortingParam = 'first_name';
  isSortSelected: boolean;
  currentPage = 1;
  pageSize = 15;
  total = 140;
  delta = 2;
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  userData: any;
  totalPages: number;
  currentUser: any;
  userList: any;
  sortingOrder = 'asc';
  searchTerm: FormControl;
  searchColumn = 'first_name';
  loader = false;
  selectedLanguage: string;
  deleteModalTitle: string;
  deleletAreYouSureText: string;
  deleteYesText: string;
  deleteNoText: string;
  updateModalTitle: string;
  showPagination = true;

  constructor(
    private utilityService: UtilityService,
    private modalService: BsModalService,
    private translate: TranslateService,
    private authService: AuthService,
    private generalService: GeneralService,
    private notificationService: NotificationService,
    private modalService2: BsModalService) { }

  ngOnInit() {
    this.searchTerm = new FormControl();
    this.loadUser();
    this.listenChangesOnSearchTerm();
    this.selectedLanguage = localStorage.getItem('language');
    this.translate.onLangChange.subscribe(event => {
      this.selectedLanguage = event.lang;
      this.setDeleteMessages();
      this.setUpdateMessages();
    });
    this.setDeleteMessages();
    this.setUpdateMessages();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      this.getUserList();
    });
  }

  setDeleteMessages() {
    switch (this.selectedLanguage) {
      case 'en':
        this.deleteModalTitle = 'User delete';
        this.deleletAreYouSureText = 'Are you sure you want to delete that user ?';
        this.deleteYesText = 'Yes';
        this.deleteNoText = 'No';
        break;
      case 'fr':
        this.deleteModalTitle = 'Utilisateur supprimer';
        this.deleletAreYouSureText = 'Êtes-vous sûr de vouloir supprimer cet utilisateur ?';
        this.deleteYesText = 'Oui';
        this.deleteNoText = 'Non';
        break;
      case 'nl':
        this.deleteModalTitle = 'Gebruiker verwijderen';
        this.deleletAreYouSureText = 'Weet u zeker dat u deze gebruiker wilt verwijderen?';
        this.deleteYesText = 'Ja';
        this.deleteNoText = 'Nee';
        break;
    }
  }
  setUpdateMessages() {
    switch (this.selectedLanguage) {
      case 'en':
        this.updateModalTitle = 'User update';
        break;
      case 'fr':
        this.updateModalTitle = 'Utilisateur mettre à jour';
        break;
      case 'nl':
        this.updateModalTitle = 'Gebruiker bijwerken';
        break;
    }
  }
  listenChangesOnSearchTerm() {
    this.searchTerm.valueChanges
      .pipe(
        distinctUntilChanged(),
        debounceTime(150),
        filter(searchTerm => searchTerm.length >= 2 || !searchTerm.length),
        switchMap(searchTerm => this.getUserListBySearch().pipe(
          takeUntil(this.searchTerm.valueChanges),
          catchError(err => {
            return of(err);
          })
        ))
      )
      .subscribe(res => {
        this.processResults(res);
      }, (err: any) => {
        if (err.status === 400) {
        }
        this.loader = false;
        this.showPagination = false;
      });
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {
      animated: true,
      backdrop: 'static',
      keyboard: false,
      class: 'custom-width overflow-modal-custom'
    });
  }

  openEditModal(template, user) {
    this.userData = user;
    this.modalRef = this.modalService2.show(template, {
      animated: true,
      // backdrop: 'static',
      keyboard: true,
      // class: 'custom-width'
    });
  }

  closeModal() {
    this.modalRef.hide();
  }

  handleSorting(value: string) {
    this.isSortSelected = this.selectedSortingParam !== value ? true : !this.isSortSelected;
    this.selectedSortingParam = value;
    this.sortingOrder = this.sortingOrder === 'asc' ? 'desc' : 'asc';
    this.currentPage = 1;
    this.getUserList();
  }


  onDelete(item: any, user: any) {
    this.genericConfirm.show({
      headlineText: this.deleteModalTitle,
      notConfirmText: this.deleteNoText,
      text: this.deleletAreYouSureText,
      confirmText: this.deleteYesText,
      callback: (result: any) => {
        // console.log('result', result);
        if (result) {
          const data = {
            roleCode: this.currentUser.role,
            languageCode: this.currentUser.language,
            userId: this.currentUser.id,
            id: user.id
          };
          this.generalService.deleteUser(data).subscribe(res => {
            this.getUserList();
            // this.notificationService.showSuccess('User deleted successfully.');
            this.utilityService.showTranslatedNotificationMessage('NotificationMessages.User.UserDeleted', 'SUCCESS');
          });
        } else {
          // console.log('do not delete user');
        }
      }
    });
  }

  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {
    // console.log(event);
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getUserList();
  }


  getUserListBySearch() {
    this.loader = true;
    return this.getUsers();
  }

  getUserList() {
    this.loader = true;
    this.getUsers().subscribe(res => {
      this.processResults(res);
    }, (err: any) => {
      if (err.status === 400) {
      }
      this.loader = false;
      this.showPagination = false;
    });
  }

  getUsers() {
    // console.log('this.searchTerm.value', this.searchTerm.value);
    const data = {
      roleCode: this.currentUser.role,
      languageCode: this.currentUser.language,
      userId: this.currentUser.id
    };
    const queryParams = {
      sort: this.selectedSortingParam + ',' + this.sortingOrder,
      page: this.currentPage - 1,
      size: this.pageSize || 3,
      search: this.searchColumn + (this.searchTerm.value ? ',' + this.searchTerm.value : ''),
      loader: true
    };
    return this.generalService.getUsers(data, queryParams);
  }

  processResults(res: any) {
    // console.log(res);
    this.loader = false;
    if (res.hasOwnProperty('error')) {
      this.listenChangesOnSearchTerm();
      if (res.error.status !== 404) {
        throw res;
      }
      if (res.error.status === 404) {
        // console.log('res.error.status', res.error.status);
        this.showPagination = false; this.loader = false;
      }
      this.userList = [];
      this.total = 1;
    } else {
      this.userList = res.value.content;
      // console.log('3 / res.totalElements', res.value.totalElements);
      this.total = parseInt(res.value.totalElements, 10);
      this.showPagination = true;
    }
  }

}
