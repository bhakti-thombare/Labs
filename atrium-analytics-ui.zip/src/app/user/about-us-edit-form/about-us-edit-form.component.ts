import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { NotificationService } from 'src/app/core/services/notification.service';
import { FileUploader, FileLikeObject } from 'ng2-file-upload';
import { GeneralService } from '../shared/general.service';
import { from } from 'rxjs';
import { Router } from '@angular/router';
import { UtilityService } from 'src/app/core/services/utility.service';

@Component({
  selector: 'ab-about-us-edit-form',
  templateUrl: './about-us-edit-form.component.html',
  styleUrls: ['./about-us-edit-form.component.scss']
})
export class AboutUsEditFormComponent implements OnInit {
  selectedLanguageTab: any;
  rawAboutUsData: any;
  imageWidth: number;
  imageHeight: number;
  frCompleted = false;
  nlCompleted = false;
  enCompleted = false;
  isValid: boolean;
  @ViewChild('uploadEl1', { static: true }) uploadElRef1: ElementRef;
  @ViewChild('uploadEl2', { static: true }) uploadElRef2: ElementRef;
  @ViewChild('uploadEl3', { static: true }) uploadElRef3: ElementRef;
  @ViewChild('uploadEl4', { static: true }) uploadElRef4: ElementRef;


  constructor(
    private router: Router,
    private utilityService: UtilityService,
    private formBuilder: FormBuilder,
    private notificationService: NotificationService,
    private generalService: GeneralService) { }

  public uploader: FileUploader = new FileUploader({
    // url: URL,
    // disableMultipart:true
  });

  section1Form: FormGroup;

  section2Form: FormGroup;

  section3Form: FormGroup;

  section4Form: FormGroup;

  section5Form: FormGroup;

  subSection: FormArray;

  aboutUsData = {
    imageSection: [
      {
        sectionId: 1,
        sectionImage: ''
      },
      {
        sectionId: 2,
        sectionImage: ''
      },
      {
        sectionId: 3,
        sectionImage: ''
      },
      {
        sectionId: 4,
        sectionImage: ''
      }
    ],
    languages: [
      {
        language: 'en',
        section: [
          {
            sectionId: 1,
            title: '',
            subtitle: '',
            description: ''
          },
          {
            sectionId: 2,
            title: '',
            subtitle: '',
            description: ''
          },
          {
            sectionId: 4,
            title: '',
            subtitle: '',
            description: ''
          }
        ],
        multipleDescriptionSection: {
          sectionId: 5,
          title: '',
          subtitle: '',
          sectionDescriptionTitleOne: '',
          sectionDescriptionOne: '',
          sectionDescriptionTitleTwo: '',
          sectionDescriptionTwo: '',
          sectionDescriptionTitleThree: '',
          sectionDescriptionThree: '',
          sectionDescriptionTitleFour: '',
          sectionDescriptionFour: ''
        }
      },
      {
        language: 'fr',
        section: [
          {
            sectionId: 1,
            title: '',
            subtitle: '',
            description: ''
          },
          {
            sectionId: 2,
            title: '',
            subtitle: '',
            description: ''
          },
          {
            sectionId: 4,
            title: '',
            subtitle: '',
            description: ''
          }
        ],
        multipleDescriptionSection: {
          sectionId: 5,
          title: '',
          subtitle: '',
          sectionDescriptionTitleOne: '',
          sectionDescriptionOne: '',
          sectionDescriptionTitleTwo: '',
          sectionDescriptionTwo: '',
          sectionDescriptionTitleThree: '',
          sectionDescriptionThree: '',
          sectionDescriptionTitleFour: '',
          sectionDescriptionFour: ''
        }
      },
      {
        language: 'nl',
        section: [
          {
            sectionId: 1,
            title: '',
            subtitle: '',
            description: ''
          },
          {
            sectionId: 2,
            title: '',
            subtitle: '',
            description: ''
          },
          {
            sectionId: 4,
            title: '',
            subtitle: '',
            description: ''
          }
        ],
        multipleDescriptionSection: {
          sectionId: 5,
          title: '',
          subtitle: '',
          sectionDescriptionTitleOne: '',
          sectionDescriptionOne: '',
          sectionDescriptionTitleTwo: '',
          sectionDescriptionTwo: '',
          sectionDescriptionTitleThree: '',
          sectionDescriptionThree: '',
          sectionDescriptionTitleFour: '',
          sectionDescriptionFour: ''
        }
      }
    ]
  };

  ngOnInit() {
    this.buildForms();
    // this.listenFormChanges();
    this.getAboutUsData();
  }

  buildForms() {
    this.section1Form = this.formBuilder.group({
      title: ['', Validators.required],
      subtitle: ['', Validators.required],
      description: ['', Validators.required],
      image: ['']
    });

    this.section2Form = this.formBuilder.group({
      title: ['', Validators.required],
      subtitle: ['', Validators.required],
      description: ['', Validators.required],
      image: ['']
    });

    this.section3Form = this.formBuilder.group({
      image: ['']
    });

    this.section4Form = this.formBuilder.group({
      title: ['', Validators.required],
      subtitle: ['', Validators.required],
      description: ['', Validators.required],
      image: ['']
    });

    this.section5Form = this.formBuilder.group({
      title: ['', Validators.required],
      subtitle: ['', Validators.required],
      subSection: this.formBuilder.array([])
    });
    [1, 2, 3, 4].forEach(i => {
      this.addItem();
    });

  }

  addItem(): void {
    this.subSection = this.section5Form.get('subSection') as FormArray;
    this.subSection.push(this.buildSubSectionForm());
  }

  buildSubSectionForm() {
    return this.formBuilder.group({
      title: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  onCancel() {
    this.router.navigateByUrl('/user/dashboard');
  }

  onSubmit() {
    if (this.checkValidity()) {
      // console.log(this.aboutUsData);
      const data = { ...this.aboutUsData };
      data.imageSection = data.imageSection.filter(item => item.sectionImage);
      this.generalService.updateAboutUsData(data).subscribe(res => {
        // console.log('res', res);
        // this.notificationService.showSuccess('Update successful!');
        this.utilityService.showTranslatedNotificationMessage('NotificationMessages.AboutUs.Updated', 'SUCCESS');

      });
    } else {
      // this.notificationService.showError('Please fill all details');
      this.utilityService.showTranslatedNotificationMessage('NotificationMessages.General.ThreeLangMandatory', 'ERROR');

    }
  }

  fileOverBase(event) {
    // console.log('event', event);
  }
  onFileSelected(refEvent, event, section) {
    // console.log('refEvent', refEvent)
    // this.onChange(refEvent);
    // console.log('event', event)
    if (event && event[0]) {
      switch (section) {
        case 1:
          this.validateImage(event[0], 10, 550, 425).subscribe(res => {

            if (res) { this.getImageAsDataUrl(event[0], this.section1Form); }
          });
          break;
        case 2:
          this.validateImage(event[0], 10, 550, 425).subscribe(res => {
            if (res) { this.getImageAsDataUrl(event[0], this.section2Form); }
          });
          break;
        case 3:
          // console.log('assigning0');
          this.validateImage(event[0], 10, 1440, 504).subscribe(res => {
            // console.log('assigning1');
            if (res) { this.getImageAsDataUrl(event[0], this.section3Form); }
          });
          break;
        case 4:
          this.validateImage(event[0], 10, 550, 425).subscribe(res => {
            if (res) { this.getImageAsDataUrl(event[0], this.section4Form); }
          });
          break;
      }
    }
  }
  getAboutUsData() {
    this.generalService.getAboutUsData().subscribe((res: any) => {
      this.rawAboutUsData = { ...res.value };
      this.selectedLanguageTab = 'fr';
      // this.setAboutUsData();
      ['en', 'nl', 'fr'].forEach((lang) => { this.selectedLanguageTab = lang; this.setAboutUsData(); });
      this.listenFormChanges();
    });
  }

  setAboutUsData() {
    // section 1
    const section1 = this.rawAboutUsData.languages
      .filter(item => item.language.toLowerCase() === this.selectedLanguageTab)[0].section
      .filter(item => item.sectionId === 1)[0];
    const imageSection1 = this.rawAboutUsData.imageSection
      .filter(item => item.sectionId === 1)[0];

    // section 2
    const section2 = this.rawAboutUsData.languages
      .filter(item => item.language.toLowerCase() === this.selectedLanguageTab)[0].section
      .filter(item => item.sectionId === 2)[0];
    const imageSection2 = this.rawAboutUsData.imageSection
      .filter(item => item.sectionId === 2)[0];
    // section 3
    const section3 = this.rawAboutUsData.languages
      .filter(item => item.language.toLowerCase() === this.selectedLanguageTab)[0].section
      .filter(item => item.sectionId === 3)[0];
    const imageSection3 = this.rawAboutUsData.imageSection
      .filter(item => item.sectionId === 3)[0];

    // section 4
    const section4 = this.rawAboutUsData.languages
      .filter(item => item.language.toLowerCase() === this.selectedLanguageTab)[0].section
      .filter(item => item.sectionId === 4)[0];
    const imageSection4 = this.rawAboutUsData.imageSection
      .filter(item => item.sectionId === 4)[0];

    // section 5
    const numbers = ['Zero', 'One', 'Two', 'Three', 'Four'];
    const section5 = this.rawAboutUsData.languages
      .filter(item => item.language.toLowerCase() === this.selectedLanguageTab)[0].multipleDescriptionSection;
    const subSections = [];
    [1, 2, 3, 4].forEach(element => {
      const data = {
        title: section5['sectionDescriptionTitle' + numbers[element]],
        description: section5['sectionDescription' + numbers[element]],
      };
      subSections.push(data);
    });

    Object.assign(this.aboutUsData.languages
      .filter(item => item.language.toLowerCase() === this.selectedLanguageTab)[0].section
      .filter(item => item.sectionId === 1)[0], section1);
    this.section1Form.patchValue({
      title: section1.title,
      subtitle: section1.subtitle,
      description: section1.description,
      image: imageSection1.sectionImage
    }, { emitEvent: false });

    Object.assign(this.aboutUsData.languages
      .filter(item =>
        item.language.toLowerCase() === this.selectedLanguageTab)[0].section
      .filter(item => item.sectionId === 2)[0], section2);
    this.section2Form.patchValue({
      title: section2.title,
      subtitle: section2.subtitle,
      description: section2.description,
      image: imageSection2.sectionImage
    }, { emitEvent: false });
    this.section3Form.patchValue({
      image: imageSection3.sectionImage
    }, { emitEvent: false });

    Object.assign(this.aboutUsData.languages
      .filter(item => item.language.toLowerCase() === this.selectedLanguageTab)[0].section
      .filter(item => item.sectionId === 4)[0], section4);
    this.section4Form.patchValue({
      title: section4.title,
      subtitle: section4.subtitle,
      description: section4.description,
      image: imageSection4.sectionImage
    }, { emitEvent: false });

    Object.assign(this.aboutUsData.languages
      .filter(item => item.language.toLowerCase() === this.selectedLanguageTab)[0].multipleDescriptionSection, section5);
    this.section5Form.patchValue({
      title: section5.title,
      subtitle: section5.subtitle,
      subSection: subSections
    }, { emitEvent: false });
    this.checkFrCompleteness();
    this.checkNlCompleteness();
    this.checkEnCompleteness();

  }

  listenFormChanges() {
    this.section1Form.valueChanges.subscribe(form => {
      const index = this.rawAboutUsData.languages.findIndex(item => item.language.toLowerCase() === this.selectedLanguageTab);
      const index2 = this.aboutUsData.languages.findIndex(item => item.language.toLowerCase() === this.selectedLanguageTab);

      this.aboutUsData.languages[index2].section.filter(item => item.sectionId === 1)[0].title = form.title;
      this.aboutUsData.languages[index2].section.filter(item => item.sectionId === 1)[0].subtitle = form.subtitle;
      this.aboutUsData.languages[index2].section.filter(item => item.sectionId === 1)[0].description = form.description;
      if (!form.image.includes('https://')) {
        this.aboutUsData.imageSection.filter(item => item.sectionId === 1)[0].sectionImage = form.image;
      }


      this.rawAboutUsData.languages[index].section.filter(item => item.sectionId === 1)[0].title = form.title;
      this.rawAboutUsData.languages[index].section.filter(item => item.sectionId === 1)[0].subtitle = form.subtitle;
      this.rawAboutUsData.languages[index].section.filter(item => item.sectionId === 1)[0].description = form.description;
      this.rawAboutUsData.imageSection.filter(item => item.sectionId === 1)[0].sectionImage = form.image;


      this.checkFrCompleteness();
      this.checkNlCompleteness();
      this.checkEnCompleteness();
    });
    // section 3
    this.section3Form.valueChanges.subscribe(form => {
      if (!form.image.includes('https://')) {
        this.aboutUsData.imageSection.filter(item => item.sectionId === 3)[0].sectionImage = form.image;
      }
      this.rawAboutUsData.imageSection.filter(item => item.sectionId === 3)[0].sectionImage = form.image;
    });

    // section 2
    this.section2Form.valueChanges.subscribe(form => {
      const index = this.rawAboutUsData.languages.findIndex(item => item.language.toLowerCase() === this.selectedLanguageTab);
      const index2 = this.aboutUsData.languages.findIndex(item => item.language.toLowerCase() === this.selectedLanguageTab);

      this.aboutUsData.languages[index2].section.filter(item => item.sectionId === 2)[0].title = form.title;
      this.aboutUsData.languages[index2].section.filter(item => item.sectionId === 2)[0].subtitle = form.subtitle;
      this.aboutUsData.languages[index2].section.filter(item => item.sectionId === 2)[0].description = form.description;
      if (!form.image.includes('https://')) {
        this.aboutUsData.imageSection.filter(item => item.sectionId === 2)[0].sectionImage = form.image;
      }


      this.rawAboutUsData.languages[index].section.filter(item => item.sectionId === 2)[0].title = form.title;
      this.rawAboutUsData.languages[index].section.filter(item => item.sectionId === 2)[0].subtitle = form.subtitle;
      this.rawAboutUsData.languages[index].section.filter(item => item.sectionId === 2)[0].description = form.description;
      this.rawAboutUsData.imageSection.filter(item => item.sectionId === 2)[0].sectionImage = form.image;


      this.checkFrCompleteness();
      this.checkNlCompleteness();
      this.checkEnCompleteness();
    });
    // section4
    this.section4Form.valueChanges.subscribe(form => {
      const index = this.rawAboutUsData.languages.findIndex(item => item.language.toLowerCase() === this.selectedLanguageTab);
      const index2 = this.aboutUsData.languages.findIndex(item => item.language.toLowerCase() === this.selectedLanguageTab);

      this.aboutUsData.languages[index2].section.filter(item => item.sectionId === 4)[0].title = form.title;
      this.aboutUsData.languages[index2].section.filter(item => item.sectionId === 4)[0].subtitle = form.subtitle;
      this.aboutUsData.languages[index2].section.filter(item => item.sectionId === 4)[0].description = form.description;
      if (!form.image.includes('https://')) {
        this.aboutUsData.imageSection.filter(item => item.sectionId === 4)[0].sectionImage = form.image;
      }


      this.rawAboutUsData.languages[index].section.filter(item => item.sectionId === 4)[0].title = form.title;
      this.rawAboutUsData.languages[index].section.filter(item => item.sectionId === 4)[0].subtitle = form.subtitle;
      this.rawAboutUsData.languages[index].section.filter(item => item.sectionId === 4)[0].description = form.description;
      this.rawAboutUsData.imageSection.filter(item => item.sectionId === 4)[0].sectionImage = form.image;


      this.checkFrCompleteness();
      this.checkNlCompleteness();
      this.checkEnCompleteness();
    });
    // section5
    this.section5Form.valueChanges.subscribe(form => {
      const index = this.rawAboutUsData.languages.findIndex(item => item.language.toLowerCase() === this.selectedLanguageTab);
      const index2 = this.aboutUsData.languages.findIndex(item => item.language.toLowerCase() === this.selectedLanguageTab);

      this.aboutUsData.languages[index2].multipleDescriptionSection.title = form.title;
      this.aboutUsData.languages[index2].multipleDescriptionSection.subtitle = form.subtitle;
      // this.aboutUsData.languages[index2].section.filter(item => item.sectionId === 5)[0].description = form.description;
      // this.aboutUsData.imageSection.filter(item => item.sectionId === 5)[0].sectionImage = form.image;

      this.rawAboutUsData.languages[index].multipleDescriptionSection.title = form.title;
      this.rawAboutUsData.languages[index].multipleDescriptionSection.subtitle = form.subtitle;
      // this.rawAboutUsData.languages[index].section.filter(item => item.sectionId === 5)[0].description = form.description;
      const numbers = ['Zero', 'One', 'Two', 'Three', 'Four'];
      [1, 2, 3, 4].forEach(element => {
        this.aboutUsData.languages[index2].multipleDescriptionSection['sectionDescriptionTitle' + numbers[element]] =
          form.subSection[element - 1].title;
        this.aboutUsData.languages[index2].multipleDescriptionSection['sectionDescription' + numbers[element]] =
          form.subSection[element - 1].description;


        this.rawAboutUsData.languages[index2].multipleDescriptionSection['sectionDescriptionTitle' + numbers[element]] =
          form.subSection[element - 1].title;
        this.rawAboutUsData.languages[index2].multipleDescriptionSection['sectionDescription' + numbers[element]] =
          form.subSection[element - 1].description;
      });

      this.checkFrCompleteness();
      this.checkNlCompleteness();
      this.checkEnCompleteness();

    });

  }

  switchLangauageTab(lang) {
    this.selectedLanguageTab = lang;
    this.setAboutUsData();
  }

  getImageAsDataUrl(file: any, sectionForm: FormGroup, index?: any) {
    const reader = new FileReader();
    let imageAsDataUrl: any = '';
    reader.addEventListener(
      'load',
      () => {
        const img = new Image();
        img.onload = () => {
          this.imageWidth = img.width;
          this.imageHeight = img.height;
        };
        // convert image file to base64 string
        const imageData = reader.result;
        imageAsDataUrl = imageData.toString();
        if (sectionForm) {
          // console.log('assigning3');
          sectionForm.controls.image.setValue(imageAsDataUrl);
        }
        // return imageAsDataUrl;
      },
      false
    );
    if (file) {
      reader.readAsDataURL(file);
    }
  }

  validateImage(fileUpload, maxSize, maxWidth, maxHeight) {
    return from(new Promise((resolve, reject) => {
      if (fileUpload.type.includes('image/')) {
        if (fileUpload.size >= maxSize * 1000 * 1000) {
          // this.notificationService.showError(`File size more than 10mb is not allowed`);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.AboutUs.FileSizeValidate', 'ERROR');
          resolve(false);
        }
        // reader.readAsDataURL(fileUpload);
        this.getBase64(fileUpload).subscribe((res: any) => {
          if (res.imageHeight > maxHeight || res.imageWidth > maxWidth) {
            // this.notificationService.showError('Height and Width must not exceed the given values.');
            this.utilityService.showTranslatedNotificationMessage('NotificationMessages.AboutUs.ImageDimensionValidate', 'ERROR');
            resolve(false);
          } else {
            // console.log('assigning2');
            resolve(true);
          }
        });
      } else {
        // this.notificationService.showError('File type should be image.');
        this.utilityService.showTranslatedNotificationMessage('NotificationMessages.AboutUs.FileTypeImage', 'ERROR');
        resolve(false);
      }
    }));
  }

  getBase64(file) {
    return from(new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.getImageDimension(reader.result).subscribe(res => {
          resolve(res);
        });
      };
      reader.onerror = error => reject(error);
    }));
  }

  getImageDimension(base64) {
    return from(new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => { resolve({ imageHeight: img.height, imageWidth: img.width }); };
      img.src = base64.toString();
    }));
  }
  checkValidity() {
    let validForm = true;
    this.aboutUsData.languages.forEach(element => {
      element.section.forEach(section => {
        if (!section.title || !section.subtitle || !section.description) {
          validForm = false;
        }
      });
      Object.keys(element.multipleDescriptionSection).forEach(key => {
        if (key !== 'sectionId') {
          if (!element.multipleDescriptionSection[key]) {
            validForm = false;
          }
        }
      });
    });
    return validForm;
  }

  checkFrCompleteness() { this.frCompleted = this.checkCompleteness('fr'); }
  checkNlCompleteness() { this.nlCompleted = this.checkCompleteness('nl'); }
  checkEnCompleteness() { this.enCompleted = this.checkCompleteness('en'); }

  checkCompleteness(lang: string) {
    let validForm = true;
    const index = this.aboutUsData.languages.findIndex(item => item.language.toLowerCase() === lang);
    this.aboutUsData.languages[index].section.forEach(element => {
      if (!element.title || !element.subtitle || !element.description) {
        validForm = false;
      }
    });
    Object.keys(this.aboutUsData.languages[index].multipleDescriptionSection).forEach(key => {
      if (key !== 'sectionId') {
        if (!this.aboutUsData.languages[index].multipleDescriptionSection[key]) {
          validForm = false;
        }
      }
    });
    return validForm;
  }

  // ngAfterViewInit() {
  //   this.uploader.onAfterAddingFile = (item => {
  // console.log('item', item)
  //     this.uploadElRef1.nativeElement.value = '';
  //   });
  //   this.uploader.onAfterAddingFile = (item => {
  // console.log('item', item)
  //     this.uploadElRef2.nativeElement.value = '';
  //   });
  //   this.uploader.onAfterAddingFile = (item => {
  // console.log('item', item)
  //     this.uploadElRef3.nativeElement.value = '';
  //   });
  //   this.uploader.onAfterAddingFile = (item => {
  // console.log('item', item)
  //     this.uploadElRef4.nativeElement.value = '';
  //   });
  // }

  // onChange(event: any): void {
  //   event.srcElement.value = "";
  // }
}
