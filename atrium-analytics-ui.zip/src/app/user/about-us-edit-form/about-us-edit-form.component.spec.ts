import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutUsEditFormComponent } from './about-us-edit-form.component';

describe('AboutUsEditFormComponent', () => {
  let component: AboutUsEditFormComponent;
  let fixture: ComponentFixture<AboutUsEditFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutUsEditFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutUsEditFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
