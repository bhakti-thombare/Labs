import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { FileUploader } from 'ng2-file-upload';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GeneralService } from '../shared/general.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { from } from 'rxjs';
import { Router } from '@angular/router';
import { PopoverDirective } from 'ngx-bootstrap/popover';
import { UtilityService } from 'src/app/core/services/utility.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'ab-landing-edit-form',
  templateUrl: './landing-edit-form.component.html',
  styleUrls: ['./landing-edit-form.component.scss'],
  // tslint:disable-next-line: no-host-metadata-property
  // host: {
  //   '(document:click)': 'onClick()',
  // }
})
export class LandingEditFormComponent implements OnInit {

  section1Form: FormGroup;
  section2Form: FormGroup;
  section3Form: FormGroup;
  section4Form: FormGroup;
  section5Form: FormGroup;
  frCompleted = false;
  nlCompleted = false;
  enCompleted = false;
  discoverBrussels: any = {
    id: 1,
    imageDto: {
      id: 1,
      imageUrl: '',
      updateFlag: false,
    },
    landingSectionDetailDtos: [
      {
        id: 1,
        languageCode: 'en',
        title: '',
        subTitle: null,
        description: '',
      },
      {
        id: 2,
        languageCode: 'fr',
        title: '',
        subTitle: null,
        description: '',
      },
      {
        id: 3,
        languageCode: 'nl',
        title: '',
        subTitle: null,
        description: '',
      },
    ],
  };
  hubBrussels = {
    id: 6,
    imageDto: {
      id: 6,
      imageUrl: '',
      updateFlag: false,
    },
    landingSectionDetailDtos: [
      {
        id: 16,
        languageCode: 'en',
        title: '',
        subTitle: null,
        description: '',
      },
      {
        id: 17,
        languageCode: 'fr',
        title: '',
        subTitle: null,
        description: '',
      },
      {
        id: 18,
        languageCode: 'nl',
        title: '',
        subTitle: null,
        description: '',
      },
    ],
  };
  keywords: any = {
    id: 1,
    subSection1: {
      id: 2,
      imageDto: {
        id: 2,
        imageUrl: '',
        updateFlag: false,
      },
      landingSectionDetailDtos: [
        {
          id: 4,
          languageCode: 'en',
          title: '',
          subTitle: null,
          description: '',
        },
        {
          id: 5,
          languageCode: 'fr',
          title: '',
          subTitle: null,
          description: '',
        },
        {
          id: 6,
          languageCode: 'nl',
          title: '',
          subTitle: null,
          description: '',
        },
      ],
    },
    subSection2: {
      id: 3,
      imageDto: {
        id: 3,
        imageUrl: '',
        updateFlag: false,
      },
      landingSectionDetailDtos: [
        {
          id: 7,
          languageCode: 'en',
          title: '',
          subTitle: null,
          description: '',
        },
        {
          id: 8,
          languageCode: 'fr',
          title: '',
          subTitle: null,
          description: '',
        },
        {
          id: 9,
          languageCode: 'nl',
          title: '',
          subTitle: null,
          description: '',
        },
      ],
    },
    subSection3: {
      id: 4,
      imageDto: {
        id: 4,
        imageUrl: '',
        updateFlag: false,
      },
      landingSectionDetailDtos: [
        {
          id: 10,
          languageCode: 'en',
          title: '',
          subTitle: null,
          description: '',
        },
        {
          id: 11,
          languageCode: 'fr',
          title: '',
          subTitle: null,
          description: '',
        },
        {
          id: 12,
          languageCode: 'nl',
          title: '',
          subTitle: null,
          description: '',
        },
      ],
    },
    subSection4: {
      id: 5,
      imageDto: {
        id: 5,
        imageUrl: '',
        updateFlag: false,
      },
      landingSectionDetailDtos: [
        {
          id: 13,
          languageCode: 'en',
          title: '',
          subTitle: null,
          description: '',
        },
        {
          id: 14,
          languageCode: 'fr',
          title: '',
          subTitle: null,
          description: '',
        },
        {
          id: 15,
          languageCode: 'nl',
          title: '',
          subTitle: null,
          description: '',
        },
      ],
    },
  };
  partners: any = {
    id: 1,
    imageUrl: '',
    landingSectionDetailDtos: [
      {
        id: 19,
        languageCode: 'en',
        title: '',
        subTitle: null,
        description: '',
      },
      {
        id: 20,
        languageCode: 'fr',
        title: '',
        subTitle: null,
        description: '',
      },
      {
        id: 21,
        languageCode: 'nl',
        title: '',
        subTitle: null,
        description: '',
      },
    ],
    federLogo: {
      id: 1,
      imageUrl: '',
      updateFlag: false
    },
    logos: [
      {
        id: 7,
        imageUrl: '',
        updateFlag: false
      },
      {
        id: 8,
        imageUrl: '',
        updateFlag: false
      },
      {
        id: 9,
        imageUrl: '',
        updateFlag: false
      },
      {
        id: 10,
        imageUrl: '',
        updateFlag: false
      },
      {
        id: 11,
        imageUrl: '',
        updateFlag: false
      },
      {
        id: 12,
        imageUrl: '',
        updateFlag: false
      },
      {
        id: 13,
        imageUrl: '',
        updateFlag: false
      },
      {
        id: 14,
        imageUrl: '',
        updateFlag: false
      },
      {
        id: 15,
        imageUrl: '',
        updateFlag: false
      },
      {
        id: 16,
        imageUrl: '',
        updateFlag: false
      },
      {
        id: 17,
        imageUrl: '',
        updateFlag: false
      }
    ]
  };
  selectedTabLanguage = 'fr';
  public uploader: FileUploader = new FileUploader({
    // url: URL,
    // disableMultipart:true
  });

  moreInfoData = [
    {
      title: 'Title1',
      description: 'Description1',
      image: 'assets/images/landing/more-info-logos/interrogate.svg',
    },
    {
      title: 'Title2',
      description: 'Description2',
      image: 'assets/images/landing/more-info-logos/analyze.svg',
    },
    {
      title: 'Title3',
      description: 'Description3',
      image: 'assets/images/landing/more-info-logos/download.svg',
    },
    {
      title: 'Title4',
      description: 'Description4',
      image: 'assets/images/landing/more-info-logos/share.svg',
    },
  ];

  footer = {
    id: 1,
    landingSectionDetailDtos: [
      {
        id: 1,
        languageCode: 'en',
        contact: '',
        termsAndConditions: '',
      },
      {
        id: 2,
        languageCode: 'fr',
        contact: '',
        termsAndConditions: '',
      },
      {
        id: 3,
        languageCode: 'nl',
        contact: '',
        termsAndConditions: '',
      },
    ],
  };
  partnersImages = [
    { image: 'assets/images/landing/partners/logo_1819.jpg' },
    { image: 'assets/images/landing/partners/logo_actiris.jpg' },
    { image: 'assets/images/landing/partners/logo_beci.jpg' },
    { image: 'assets/images/landing/partners/logo_feder.jpg' },
    { image: 'assets/images/landing/partners/logo_impulse.jpg' },
    { image: 'assets/images/landing/partners/logo_innoviris.jpg' },
    { image: 'assets/images/landing/partners/logo_izeo.jpg' },
    { image: 'assets/images/landing/partners/logo_joyn.jpg' },
    { image: 'assets/images/landing/partners/logo_rbc.jpg' },
    { image: 'assets/images/landing/partners/logo_visitbrussels.jpg' },
    { image: 'assets/images/landing/partners/logo_vub.jpg' },
  ];
  outters: any[];
  subSection: any;
  rawLandingData: any;
  currentUser: any;
  imageWidth: number;
  imageHeight: number;
  contact: any = {
    id: 1,
    enAddress: '',
    frAddress: '',
    nlAddress: '',
    phone: '',
    facebookLink: '',
    instagramLink: '',
    twitterLink: '',
    linkedLink: '',
    terms_and_conditions: 'landing/AnalyticsBrusselsPrivacyPolicy.pdf'
  };
  constructor(
    private sanitizer: DomSanitizer,
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private utilityService: UtilityService,
    private notificationService: NotificationService,
    private generalService: GeneralService,
    private router: Router
  ) { }

  ngOnInit() {
    this.loadUser();
    this.buildForm();
    // this.buildPartnersTable();
    this.listenFormChanges();
    this.getLandingData();
  }
  loadUser() {
    this.authService.currentUser$.subscribe((user) => {
      if (user) {
        this.currentUser = user;
      }
    });
  }
  buildForm() {
    this.section1Form = this.formBuilder.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      image: [''],
    });
    this.section2Form = this.formBuilder.group({
      subSection: this.formBuilder.array([]),
    });
    this.section3Form = this.formBuilder.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      image: [''],
    });
    this.section4Form = this.formBuilder.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      image: [''],
    });
    this.section5Form = this.formBuilder.group({
      address: ['', Validators.required],
      phone: ['', Validators.required],
      facebookLink: ['', Validators.required],
      instagramLink: ['', Validators.required],
      linkedInLink: ['', Validators.required],
      twitterLink: ['', Validators.required]
    });
    [1, 2, 3, 4].forEach((i) => {
      this.addItem();
    });
  }

  addItem(): void {
    this.subSection = this.section2Form.get('subSection') as FormArray;
    this.subSection.push(this.buildSubSectionForm());
  }

  buildSubSectionForm() {
    return this.formBuilder.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      image: ['', Validators.required]
    });
  }
  buildPartnersTable() {
    const outterArray = [];
    let innerArray = [];
    let n;
    this.partnersImages.forEach(
      (partner: any, index: number) => (partner.id = index)
    );

    // console.log('this.partners.logos', this.partners.logos);
    // this.partners.imageUrl = this.partners.logos
    //   .filter((item: any) => item.imageUrl && !item.imageUrl.toString().includes('feder_logo'))[0].imageUrl;
    const partnersArray: any = this.partners.logos
      .filter((item: any) => item.imageUrl && item.imageUrl.toString());
    // add image option
    partnersArray.push({ label: 'addImage', value: false });
    // console.log('partnersArray', partnersArray);
    while (n !== 0) {
      n = Math.ceil(partnersArray.length / 4);
      if (n !== 1) {
        innerArray = partnersArray.slice(0, 4);
        outterArray.push(innerArray);
        partnersArray.splice(0, 4);
        innerArray = [];
      } else {
        innerArray = partnersArray.slice(0, partnersArray.length);
        outterArray.push(innerArray);
        n = 0;
      }
    }
    this.outters = outterArray;
    // console.log(outterArray);
  }

  fileOverBase(event) {
    // console.log('event', event);
  }
  onFileSelected(event: any, section: any, index?: any) {
    if (event && event[0]) {
      // console.log('section', section);
      // console.log('event', event);
      switch (section) {
        case 1:
          this.validateImage(event[0], 10, 550, 425).subscribe(res => {
            if (res) {
              this.getImageAsDataUrl(event[0], this.section1Form);
            }
          });
          break;
        case 2:
          this.validateImage(event[0], 10, 550, 425).subscribe(res => {
            if (res) {
              const subSection: any = (this.section2Form.get('subSection') as FormArray).at(index);
              this.getImageAsDataUrl(event[0], subSection);
            }
          });
          break;
        case 3:
          this.validateImage(event[0], 10, 550, 425).subscribe(res => {
            if (res) {
              this.getImageAsDataUrl(event[0], this.section3Form);
            }
          });
          break;
        case 4:
          this.validateImage(event[0], 10, 1140, 70).subscribe(res => {
            if (res) {
              this.getImageAsDataUrl(event[0], this.section4Form);
            }
          });
          break;
        case 0:
          // this.validateImage(event[0], 10, 550, 425).subscribe(res => {
          this.getImageAsDataUrl(event[0], undefined, index);
          // });
          break;
        case -1:
          // console.log('index', index);
          this.getImageAsDataUrl(event[0], undefined, index);
          break;
      }
    }
  }


  validateImage(fileUpload, maxSize, maxWidth, maxHeight) {
    return from(new Promise((resolve, reject) => {
      if (fileUpload.type.includes('image/')) {
        if (fileUpload.size >= maxSize * 1000 * 1000) {
          // this.notificationService.showError(`File size more than 10mb is not allowed`);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Landing.FileSizeValidate', 'ERROR');

          resolve(false);
        }
        // reader.readAsDataURL(fileUpload);
        this.getBase64(fileUpload).subscribe((res: any) => {
          if (res.imageHeight > maxHeight || res.imageWidth > maxWidth) {
            // this.notificationService.showError('Height and Width must not exceed the given values.');
            this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Landing.ImageDimensionValidate', 'ERROR');
            resolve(false);
          } else {
            resolve(true);
          }
        });
      } else {
        // this.notificationService.showError('File type should be image.');
        this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Landing.FileTypeImage', 'ERROR');
        resolve(false);
      }
    }));
  }

  getBase64(file) {
    return from(new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.getImageDimension(reader.result).subscribe(res => {
          resolve(res);
        });
      };
      reader.onerror = error => reject(error);
    }));
  }

  getImageDimension(base64) {
    return from(new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => { resolve({ imageHeight: img.height, imageWidth: img.width }); };
      img.src = base64.toString();
    }));
  }
  onSubmit() {
    let data = null;
    if (this.checkValidity()) {
      // this.removeImageMetaData();

      // remove extra properties
      this.partners.logos.forEach((element: any) => {
        delete element.imageId;
      });

      data = {
        dummy: '',
        id: 1,
        discoverBrussels: this.discoverBrussels,
        hubBrussels: this.hubBrussels,
        keywords: this.keywords,
        partners: this.partners,
        contact: this.contact
      };
      // console.log('data', data);
      this.generalService.updateLandingData(data).subscribe(res => {
        // console.log('res', res);
        // this.notificationService.showSuccess('Update successful!');
        window.location.reload();
        this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Landing.Updated', 'SUCCESS');
      });
    } else {
      // console.log('data', data);
      // this.notificationService.showError(
      //   'Please fill all details for all three languages'
      // );
      this.utilityService.showTranslatedNotificationMessage('NotificationMessages.General.ThreeLangMandatory', 'ERROR');
    }
  }

  removeImageMetaData() {
    if (this.discoverBrussels.imageDto.updateFlag === true) {
      this.discoverBrussels.imageDto.imageUrl = this.discoverBrussels.imageDto.imageUrl.split(',')[1];
    }
    if (this.hubBrussels.imageDto.updateFlag === true) {
      this.hubBrussels.imageDto.imageUrl = this.hubBrussels.imageDto.imageUrl.split(',')[1];
    }
    this.partners.logos.forEach(element => {
      if (element.updateFlag === true) {
        element.imageUrl = element.imageUrl.split(',')[1];
      }
    });
  }

  onCancel() {
    this.router.navigateByUrl('/user/dashboard');
  }

  getLandingData() {
    this.generalService.getLandingData().subscribe((res) => {
      // console.log('res', res);
      this.rawLandingData = res.value;
      this.rawLandingData.partners.logos.forEach((item: any, i) => {
        item.imageId = i;
      });
      // console.log('this.rawLandingData.partners.logos', this.rawLandingData.partners.logos)
      this.partners.logos = this.rawLandingData.partners.logos; // .filter((item: any, i) => item.imageId = i);
      this.partners.federLogo = this.rawLandingData.partners.federLogo;
      this.buildPartnersTable();
      ['en', 'nl', 'fr'].forEach((lang) => { this.selectedTabLanguage = lang; this.setLandingData(this.selectedTabLanguage); });
      // this.selectedTabLanguage = 'fr';
    });
  }
  setLandingData(selectedTabLanguage: any) {
    // console.log('setLandingData');
    // set discover brussels
    // console.log('this.rawLandingData', this.rawLandingData);
    const index1 = this.rawLandingData.discoverBrussels.landingSectionDetailDtos.findIndex(
      (item) => item.languageCode === this.selectedTabLanguage
    );
    // console.log('index1', index1);
    this.discoverBrussels.imageDto.imageUrl = this.rawLandingData.discoverBrussels.imageDto.imageUrl;
    this.section1Form.patchValue({
      title: this.rawLandingData.discoverBrussels.landingSectionDetailDtos[index1].title,
      description: this.rawLandingData.discoverBrussels.landingSectionDetailDtos[index1].description,
      image: this.rawLandingData.discoverBrussels.imageDto.imageUrl
    });
    // console.log('this.section1Form', this.section1Form.value);

    // set keywords
    let i = 0;
    const keywordsArray = [];
    this.subSection = this.section2Form.get('subSection') as FormArray;
    // console.log('this.subSection', this.subSection.value);
    // console.log('this.rawLandingData.keywords', this.rawLandingData.keywords);
    Object.keys(this.rawLandingData.keywords).forEach((key: string) => {
      if (!key.includes('id')) {
        const index2 = this.rawLandingData.keywords[key].landingSectionDetailDtos.findIndex(
          (item) => item.languageCode === this.selectedTabLanguage
        );
        const keyWordData = {
          title: this.rawLandingData.keywords[key].landingSectionDetailDtos[index2].title,
          description: this.rawLandingData.keywords[key].landingSectionDetailDtos[index2].description,
          image: this.rawLandingData.keywords[key].imageDto.imageUrl,
        };
        keywordsArray.push(keyWordData);
        i++;
      }
    });
    // console.log('keywordsArray', keywordsArray);
    this.subSection.setValue(keywordsArray);

    // set hub brussels
    const index3 = this.rawLandingData.hubBrussels.landingSectionDetailDtos.findIndex(
      (item) => item.languageCode === this.selectedTabLanguage
    );
    this.hubBrussels.imageDto.imageUrl = this.rawLandingData.hubBrussels.imageDto.imageUrl;
    this.section3Form.patchValue({
      title: this.rawLandingData.hubBrussels.landingSectionDetailDtos[index3].title,
      description: this.rawLandingData.hubBrussels.landingSectionDetailDtos[index3].description,
      image: this.rawLandingData.hubBrussels.imageDto.imageUrl
    });

    // set thanks partners
    const index4 = this.rawLandingData.partners.landingSectionDetailDtos.findIndex(
      (item) => item.languageCode === this.selectedTabLanguage
    );
    this.section4Form.patchValue({
      title: this.rawLandingData.partners.landingSectionDetailDtos[index4].title,
      description: this.rawLandingData.partners.landingSectionDetailDtos[index4].description,
    });

    // console.log('this.section4Form', this.section4Form.value);

    // set footer
    // const index5 = this.rawLandingData.footer && this.rawLandingData.footer.landingSectionDetailDtos.findIndex(
    //   (item) => item.languageCode === this.selectedTabLanguage
    // );
    this.section5Form.patchValue({
      address: this.rawLandingData.contact && this.rawLandingData.contact[this.selectedTabLanguage + 'Address'],
      phone: this.rawLandingData.contact && this.rawLandingData.contact.phone || '',
      facebookLink: this.rawLandingData.contact.facebookLink,
      instagramLink: this.rawLandingData.contact.instagramLink,
      twitterLink: this.rawLandingData.contact.twitterLink,
      linkedInLink: this.rawLandingData.contact.linkedLink
    });
    this.checkFrCompleteness();
    this.checkNlCompleteness();
    this.checkEnCompleteness();
  }

  getImageAsDataUrl(file: any, sectionForm: FormGroup, index?: any) {
    const reader = new FileReader();
    let imageAsDataUrl: any = '';
    reader.addEventListener(
      'load',
      () => {
        const img = new Image();
        img.onload = () => {
          this.imageWidth = img.width;
          this.imageHeight = img.height;
        };
        // convert image file to base64 string
        const imageData = reader.result;
        imageAsDataUrl = imageData.toString();
        if (sectionForm) {
          sectionForm.controls.image.setValue(this.sanitizer.bypassSecurityTrustResourceUrl(imageAsDataUrl));
          // console.log('sectionForm', sectionForm.value);
        } else if (index === -1) {
          this.addPartnerLogo(imageAsDataUrl);
        } else {
          this.partners.logos.forEach(logo => {
            if (logo.id === index) {
              logo.imageUrl = imageAsDataUrl;
              logo.updateFlag = true;
            }
          });
        }
        // return imageAsDataUrl;
      },
      false
    );
    if (file) {
      reader.readAsDataURL(file);
    }
  }

  listenFormChanges() {
    // discover brussels
    this.section1Form.valueChanges.subscribe((form: any) => {
      // console.log('form', form);
      const index = this.discoverBrussels.landingSectionDetailDtos.findIndex(
        (item) => item.languageCode === this.selectedTabLanguage
      );
      this.discoverBrussels.landingSectionDetailDtos[index].title = form.title;
      this.discoverBrussels.landingSectionDetailDtos[index].description =
        form.description;
      // tslint:disable-next-line: max-line-length
      if (this.discoverBrussels.imageDto.imageUrl !== (form.image.toString().changingThisBreaksApplicationSecurity || form.image.toString())) {
        // console.log('images are not same now');
        // console.log('form.image', form.image);
        // console.log('this.discoverBrussels.imageDto.imageUrl', this.discoverBrussels.imageDto.imageUrl);
        this.discoverBrussels.imageDto.imageUrl = form.image.changingThisBreaksApplicationSecurity;
        this.discoverBrussels.imageDto.updateFlag = true;
      }
      // to maintain consistent view
      this.rawLandingData.discoverBrussels.landingSectionDetailDtos[index].title = form.title;
      this.rawLandingData.discoverBrussels.landingSectionDetailDtos[index].description =
        form.description;
      this.checkFrCompleteness();
      this.checkNlCompleteness();
      this.checkEnCompleteness();
    });

    // keywords
    this.section2Form.valueChanges.subscribe((values: any) => {
      const form = values.subSection;
      // console.log('form', form);
      // subSection1
      const index1 = this.keywords.subSection1.landingSectionDetailDtos.findIndex(
        (item) => item.languageCode === this.selectedTabLanguage
      );
      this.keywords.subSection1.landingSectionDetailDtos[index1].title =
        form[0].title;
      this.keywords.subSection1.landingSectionDetailDtos[index1].description =
        form[0].description;
      // to maintain consistent view  subSection1

      this.rawLandingData.keywords.subSection1.landingSectionDetailDtos[index1].title =
        form[0].title;
      this.rawLandingData.keywords.subSection1.landingSectionDetailDtos[index1].description =
        form[0].description;
      // as any).changingThisBreaksApplicationSecurity as
      // tslint:disable-next-line: max-line-length
      if (!(form[0].image.toString().changingThisBreaksApplicationSecurity || form[0].image.toString()).includes('https') && this.keywords.subSection1.imageDto.imageUrl !== form[0].image) {
        this.keywords.subSection1.imageDto.imageUrl = form[0].image.changingThisBreaksApplicationSecurity;
        this.keywords.subSection1.imageDto.updateFlag = true;
      }

      // subSection2
      const index2 = this.keywords.subSection2.landingSectionDetailDtos.findIndex(
        (item) => item.languageCode === this.selectedTabLanguage
      );
      this.keywords.subSection2.landingSectionDetailDtos[index2].title =
        form[1].title;
      this.keywords.subSection2.landingSectionDetailDtos[index2].description =
        form[1].description;

      // to maintain consistent view  subSection2
      this.rawLandingData.keywords.subSection2.landingSectionDetailDtos[index1].title =
        form[1].title;
      this.rawLandingData.keywords.subSection2.landingSectionDetailDtos[index1].description =
        form[1].description;

      // tslint:disable-next-line: max-line-length
      if (!(form[1].image.toString().changingThisBreaksApplicationSecurity || form[1].image.toString()).includes('https') && this.keywords.subSection2.imageDto.imageUrl !== form[1].image) {
        this.keywords.subSection2.imageDto.imageUrl = form[1].image.changingThisBreaksApplicationSecurity;
        this.keywords.subSection2.imageDto.updateFlag = true;
      }

      // subSection3
      const index3 = this.keywords.subSection3.landingSectionDetailDtos.findIndex(
        (item) => item.languageCode === this.selectedTabLanguage
      );
      this.keywords.subSection3.landingSectionDetailDtos[index3].title =
        form[2].title;
      this.keywords.subSection3.landingSectionDetailDtos[index3].description =
        form[2].description;

      // to maintain consistent view  subSection3
      this.rawLandingData.keywords.subSection3.landingSectionDetailDtos[index1].title =
        form[2].title;
      this.rawLandingData.keywords.subSection3.landingSectionDetailDtos[index1].description =
        form[2].description;

      // tslint:disable-next-line: max-line-length
      if (!(form[2].image.toString().changingThisBreaksApplicationSecurity || form[2].image.toString()).includes('https') && this.keywords.subSection3.imageDto.imageUrl !== form[2].image) {
        this.keywords.subSection3.imageDto.imageUrl = form[2].image.changingThisBreaksApplicationSecurity;
        this.keywords.subSection3.imageDto.updateFlag = true;
      }

      // subSection4
      const index4 = this.keywords.subSection4.landingSectionDetailDtos.findIndex(
        (item) => item.languageCode === this.selectedTabLanguage
      );
      this.keywords.subSection4.landingSectionDetailDtos[index4].title =
        form[3].title;
      this.keywords.subSection4.landingSectionDetailDtos[index4].description =
        form[3].description;

      // to maintain consistent view  subSection4
      this.rawLandingData.keywords.subSection4.landingSectionDetailDtos[index1].title =
        form[3].title;
      this.rawLandingData.keywords.subSection4.landingSectionDetailDtos[index1].description =
        form[3].description;

      // tslint:disable-next-line: max-line-length
      if (!(form[3].image.toString().changingThisBreaksApplicationSecurity || form[3].image.toString()).includes('https') && this.keywords.subSection4.imageDto.imageUrl !== form[3].image) {
        this.keywords.subSection4.imageDto.imageUrl = form[3].image.changingThisBreaksApplicationSecurity;
        this.keywords.subSection4.imageDto.updateFlag = true;
      }
      this.checkFrCompleteness();
      this.checkNlCompleteness();
      this.checkEnCompleteness();
    });

    // hub brussels
    this.section3Form.valueChanges.subscribe((form: any) => {
      // console.log('form', form);
      const index = this.hubBrussels.landingSectionDetailDtos.findIndex(
        (item) => item.languageCode === this.selectedTabLanguage
      );
      this.hubBrussels.landingSectionDetailDtos[index].title = form.title;
      this.hubBrussels.landingSectionDetailDtos[index].description =
        form.description;
      if (this.hubBrussels.imageDto.imageUrl !== (form.image.toString().changingThisBreaksApplicationSecurity || form.image.toString())) {
        this.hubBrussels.imageDto.imageUrl = form.image.changingThisBreaksApplicationSecurity;
        this.hubBrussels.imageDto.updateFlag = true;
      }
      // to maintain consistent view
      this.rawLandingData.hubBrussels.landingSectionDetailDtos[index].title = form.title;
      this.rawLandingData.hubBrussels.landingSectionDetailDtos[index].description =
        form.description;
      this.checkFrCompleteness();
      this.checkNlCompleteness();
      this.checkEnCompleteness();
    });
    // thanks to partners
    this.section4Form.valueChanges.subscribe((form: any) => {
      // console.log('form', form);
      const index = this.partners.landingSectionDetailDtos.findIndex(
        (item) => item.languageCode === this.selectedTabLanguage
      );
      this.partners.landingSectionDetailDtos[index].title = form.title;
      this.partners.landingSectionDetailDtos[index].description =
        form.description;
      // to maintain consistent view
      this.rawLandingData.partners.landingSectionDetailDtos[index].title = form.title;
      this.rawLandingData.partners.landingSectionDetailDtos[index].description =
        form.description;
      // this.partners.logos = form.image;
      if ((form.image.toString().changingThisBreaksApplicationSecurity || form.image.toString())) {
        this.partners.federLogo.imageUrl = form.image.changingThisBreaksApplicationSecurity; // federlogo
        this.partners.federLogo.updateFlag = true;
        this.rawLandingData.partners.federLogo.imageUrl = form.image.changingThisBreaksApplicationSecurity; // federlogo
        this.rawLandingData.partners.federLogo.updateFlag = true;
        // this.rawLandingData.partners.logos.forEach(logo => {
        //   if (logo.imageUrl.includes('feder_logo')) {
        //     logo.imageUrl = form.image.changingThisBreaksApplicationSecurity;
        //     logo.updateFlag = true;
        //   }
        // });
        // this.partners.logos.forEach(logo => {
        //   if (!logo.imageUrl.includes('feder_logo')) {
        //     logo.imageUrl = form.image.changingThisBreaksApplicationSecurity;
        //     logo.updateFlag = true;
        //   }
        // });
      }
      this.checkFrCompleteness();
      this.checkNlCompleteness();
      this.checkEnCompleteness();
    });

    // footer
    this.section5Form.valueChanges.subscribe((form: any) => {

      this.contact[this.selectedTabLanguage + 'Address'] = form.address;
      this.contact.phone = form.phone;
      this.contact.facebookLink = form.facebookLink;
      this.contact.twitterLink = form.twitterLink;
      this.contact.instagramLink = form.instagramLink;
      this.contact.linkedLink = form.linkedInLink;
      // to maintain consistent view
      if (this.rawLandingData.contact) {
        this.rawLandingData.contact[this.selectedTabLanguage + 'Address'] = form.address;
        this.rawLandingData.contact.phone = form.phone;
        this.rawLandingData.contact.facebookLink = form.facebookLink;
        this.rawLandingData.contact.twitterLink = form.twitterLink;
        this.rawLandingData.contact.instagramLink = form.instagramLink;
        this.rawLandingData.contact.linkedLink = form.linkedInLink;
      }
      this.checkFrCompleteness();
      this.checkNlCompleteness();
      this.checkEnCompleteness();

    });
  }

  switchLangauageTab(lang) {
    this.selectedTabLanguage = lang;
    this.setLandingData(this.selectedTabLanguage);
  }

  checkCompleteness(lang: string) {
    // console.log('checkFrCompleteness');
    let section1 = false;
    let section2 = false;
    let section3 = false;
    let section4 = false;
    let section5 = false;
    const index = this.discoverBrussels.landingSectionDetailDtos.findIndex(item => item.languageCode === lang);
    if (this.discoverBrussels.landingSectionDetailDtos[index].title &&
      this.discoverBrussels.landingSectionDetailDtos[index].description) {
      section1 = true;
    }
    const index2 = this.hubBrussels.landingSectionDetailDtos.findIndex(item => item.languageCode === lang);
    if (this.hubBrussels.landingSectionDetailDtos[index2].title &&
      this.hubBrussels.landingSectionDetailDtos[index2].description) {
      section2 = true;
    }
    const sections = ['subSection1', 'subSection2', 'subSection3', 'subSection4'];
    // .every(
    //   (subSection) =>

    for (const subSection of sections) {
      const index3 = this.keywords[subSection].landingSectionDetailDtos.findIndex(item => item.languageCode === lang);
      if (this.keywords[subSection].landingSectionDetailDtos[index3].title &&
        this.keywords[subSection].landingSectionDetailDtos[index3].description
      ) {
        section3 = true;
      } else {
        return false;
      }
    }
    // );
    const index4 = this.partners.landingSectionDetailDtos.findIndex(item => item.languageCode === lang);
    if (this.partners.landingSectionDetailDtos[index4].title &&
      this.partners.landingSectionDetailDtos[index4].description) {
      section4 = true;
    }

    if (this.contact[lang + 'Address'] && this.contact.phone) {
      section5 = true;
    } else {
      section5 = false;
    }
    if (section1 && section2 && section3 && section4 && section5) {
      // console.log('completemeness', true);
      return true;
    } else {
      // console.log('completeness', false);
      return false;
    }

  }

  checkFrCompleteness() {
    this.frCompleted = this.checkCompleteness('fr');
  }

  checkEnCompleteness() {
    this.nlCompleted = this.checkCompleteness('nl');
  }

  checkNlCompleteness() {
    this.enCompleted = this.checkCompleteness('en');
  }

  checkValidity() {
    let validForm = true;

    this.discoverBrussels.landingSectionDetailDtos.forEach((element) => {
      // console.log('element', element);
      if (!element.title || !element.description) {
        validForm = false;
        // console.log(' discover brussels validForm', validForm);
      }
    });
    this.hubBrussels.landingSectionDetailDtos.forEach((element) => {
      if (!element.title || !element.description) {
        validForm = false;
        // console.log('hub brussels validForm', validForm);
      }
    });
    ['subSection1', 'subSection2', 'subSection3', 'subSection4'].forEach(
      (subSection) => {
        this.keywords[subSection].landingSectionDetailDtos.forEach(
          (element) => {
            if (!element.title || !element.description) {
              validForm = false;
              // console.log('validForm', validForm);

            }
          }
        );
      }
    );
    this.partners.landingSectionDetailDtos.forEach((element) => {
      if (!element.title || !element.description) {
        validForm = false;
        // console.log('validForm', validForm);
      }
    });

    if (
      !this.contact.enAddress ||
      !this.contact.frAddress ||
      !this.contact.nlAddress ||
      !this.contact.phone
      // !this.contact.facebookLink ||
      // !this.contact.twitterLink ||
      // !this.contact.instagramLink ||
      // !this.contact.linkedLink
      ) {
      validForm = false;
      // console.log('validForm', validForm);
    } else {
      // console.log('validForm', validForm);
      // console.log(!!this.contact.enAddress);
      // console.log('this.contact', this.contact);
    }

    return validForm;
  }


  // onClick() {
  // }

  addPartnerLogo(imageDataUrl) {
    const data = {
      id: undefined,
      imageUrl: imageDataUrl,
      updateFlag: true,
      imageId: this.partners.logos.length
    };
    this.partners.logos.push(data);
    this.buildPartnersTable();
  }

  removePartnerLogo(outerIndex, innerIndex, imageId) {
    // this.partners.logos.splice(index, 1);
    this.outters[outerIndex].splice(innerIndex, 1);
    // console.log('this.partners.logos', this.partners.logos);
    const index = this.partners.logos.findIndex((item: any) => item.imageId === imageId);
    this.partners.logos.splice(index, 1);
    this.buildPartnersTable();

  }

}
