import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LandingEditFormComponent } from './landing-edit-form.component';

describe('LandingEditFormComponent', () => {
  let component: LandingEditFormComponent;
  let fixture: ComponentFixture<LandingEditFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LandingEditFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LandingEditFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
