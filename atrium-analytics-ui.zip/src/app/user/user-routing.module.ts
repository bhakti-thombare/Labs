import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AboutUsEditFormComponent } from './about-us-edit-form/about-us-edit-form.component';
import { TagManagementFormComponent } from './tag-management-form/tag-management-form.component';
import { LandingEditFormComponent } from './landing-edit-form/landing-edit-form.component';
import { PageUnderdevelopmentComponent } from '../shared/components/page-underdevelopment/page-underdevelopment.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserAccountFormComponent } from './account/user-account-form/user-account-form.component';
import { AdminGuard } from '../core/guards/admin.guard';
import {UserDashboardComponent} from './user-dashboard/user-dashboard.component';
import {SharedContentComponent} from './shared-content/shared-content.component';
import {FavoriteContentComponent} from './favorite-content/favorite-content.component';
import {DraftContentComponent} from './draft-content/draft-content.component';
import {PrivateContentComponent} from './private-content/private-content.component';



const routes: Routes = [
  { path: 'under-development', component: PageUnderdevelopmentComponent },
  { path: '', redirectTo: 'dashboard' },
  {
    path: 'dashboard', component: DashboardComponent, children: [
      { path: '', component: UserDashboardComponent },
      { path: 'shared-content', component: SharedContentComponent},
      { path: 'favorite-content', component: FavoriteContentComponent },
      { path: 'draft-content', component: DraftContentComponent },
      { path: 'under-development', component: PageUnderdevelopmentComponent },
      { path: 'private-product', component: PrivateContentComponent },

      { path: 'user-list', component: UserListComponent, canActivate: [AdminGuard] },

    ]
  },
  { path: 'dashboard/about-us-edit', component: AboutUsEditFormComponent, canActivate: [AdminGuard] },
  { path: 'dashboard/landing-edit', component: LandingEditFormComponent, canActivate: [AdminGuard] },
  { path: 'dashboard/tags', component: TagManagementFormComponent, canActivate: [AdminGuard] },
  { path: 'account', component: UserAccountFormComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
