import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { GeneralService } from '../shared/general.service';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'ab-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.scss'],
})
export class UserDashboardComponent implements OnInit {
  constructor(
    private authService: AuthService,
    private generalService: GeneralService,
    private translate: TranslateService,
    private router: Router
  ) {}
  element = [];
  userBody;
  sharedContent = [];
  selectedLanguage;
  languageIndex;
  currentUser;
  subscriber;
  hubster;
  champion;
  favoriteElement = [];
  favoriteContent = [];
  languageChangeSubscription: Subscription;

  loadUser() {
    this.authService.currentUser$.subscribe((user) => {
      this.currentUser = user.role;
      this.userBody = {
        languageCode: user.language,
        roleCode: user.role,
        userId: user.id,
        dashboardLanguage: this.selectedLanguage,
      };
    });
  }
  goToPage(type, id) {
    if (type === 'viz' || type === 'visualisation') {
      this.router.navigate([
        `/library/viz-details/${id}`,
        { previousUrl: 'shared-content' },
      ]);
    }
    if (type === 'product' || type === 'report') {
      this.router.navigate([
        `/library/product-details/${id}`,
        { previousUrl: 'shared-content' },
      ]);
    }
  }
  getUserCount() {
    this.generalService.getUserCount(this.userBody).subscribe((user) => {
      this.subscriber = user.value.subscriber;
      this.hubster = user.value.hubster;
      this.champion = user.value.champion;
    });
  }
  loadSharedContent() {
    this.sharedContent = [];
    this.userBody.dashboardLanguage = this.selectedLanguage;
    this.generalService
      .sharedElements(this.userBody, { size: 5 })
      .subscribe((res) => {
        this.sharedContent = res.value.content;
        this.getElement();
      });
  }
  loadFavoriteContent() {
    this.favoriteContent = [];
    this.userBody.dashboardLanguage = this.selectedLanguage;

    this.generalService
      .favoriteElements(this.userBody, { size: 5 })
      .subscribe((res) => {
        this.favoriteContent = res.value.content;
        this.getFavorite();
      });
  }

  getElement() {
    this.element = [];
    this.sharedContent.forEach((element) => {
      // tslint:disable-next-line: no-string-literal
      element.elementInfo['type'] = element.elementType;
      // tslint:disable-next-line: no-string-literal
      element.elementInfo['elementId'] = element.elementId;
      // tslint:disable-next-line: no-string-literal
      element.elementInfo['productType'] = element.productType;

      this.element.push(element.elementInfo);
      this.element.forEach((ele) => {
        ele.lang = ele.findIndex(
          (x) => x.language.toLowerCase() === this.selectedLanguage
        );
      });
    });
  }
  getFavorite() {
    this.favoriteElement = [];
    this.favoriteContent.forEach((element) => {
      // tslint:disable-next-line: no-string-literal
      element.elementInfo['type'] = element.elementType;
      // tslint:disable-next-line: no-string-literal
      element.elementInfo['productType'] = 'private';
      // tslint:disable-next-line: no-string-literal
      element.elementInfo['elementId'] = element.elementId;

      // tslint:disable-next-line: no-string-literal
      element.elementInfo['productType'] = element.productType;

      this.favoriteElement.push(element.elementInfo);
      this.favoriteElement.forEach((ele) => {
        ele.lang = ele.findIndex(
          (x) => x.language.toLowerCase() === this.selectedLanguage
        );
      });
    });
  }
  ngOnInit() {
    this.selectedLanguage = localStorage.getItem('language');

    this.loadUser();
    if (this.currentUser === 'admin') {
      this.getUserCount();
    }
    this.languageIndex =
      this.selectedLanguage === 'en'
        ? 0
        : this.selectedLanguage === 'fr'
        ? 1
        : 2;
    if (this.currentUser !== 'admin') {
      this.loadFavoriteContent();
    }

    this.loadSharedContent();
    this.languageChangeSubscription = this.translate.onLangChange.subscribe(
      (event: LangChangeEvent) => {
        this.selectedLanguage = event.lang;
        this.languageIndex =
          this.selectedLanguage === 'en'
            ? 0
            : this.selectedLanguage === 'fr'
            ? 1
            : 2;
        if (this.router.url === '/user/dashboard') {
          if (this.currentUser !== 'admin') {
            this.loadFavoriteContent();
          }
          this.loadSharedContent();
        }
      }
    );
  }
  // tslint:disable-next-line: use-lifecycle-interface
  ngOnDestroy() {
    if (this.languageChangeSubscription) {
      this.languageChangeSubscription.unsubscribe();
    }
  }
}
