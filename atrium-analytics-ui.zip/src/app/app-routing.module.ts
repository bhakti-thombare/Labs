import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutUsComponent } from './home/about-us/about-us.component';
import { LandingComponent } from './home/landing/landing.component';
import { WelcomeOnboardComponent } from './home/welcome-onboard/welcome-onboard.component';
import { PageUnderdevelopmentComponent } from './shared/components/page-underdevelopment/page-underdevelopment.component';
import { PageNotFoundComponent } from './home/page-not-found/page-not-found.component';
import { AuthGuard } from './core/guards/auth.guard';
import { UserProfileFormComponent } from './home/user-profile-form/user-profile-form.component';
import { ResendVerificationPageComponent } from './home/resend-verification-page/resend-verification-page.component';
import { UiElementsComponent } from './shared/example/ui-elements/ui-elements.component';

const routes: Routes = [
  //{ path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: '', component: LandingComponent },
  { path: 'about-us', component: AboutUsComponent },
  { path: 'welcome-on-board', component: WelcomeOnboardComponent },
  { path: 'resend-verification-link', component: ResendVerificationPageComponent },
  { path: 'sign-up-error', component: WelcomeOnboardComponent },
  { path: 'library', loadChildren: () => import('./library/library.module').then(m => m.LibraryModule) },
  { path: 'open-data', loadChildren: () => import('./open-data/open-data.module').then(m => m.OpenDataModule) },

  { path: 'user', canActivate: [AuthGuard], loadChildren: () => import('./user/user.module').then(m => m.UserModule) },
  // loadChildren: () => import('./library/library.module').then(m => m.LibraryModule) },
  // { path: 'library', component: PageUnderdevelopmentComponent },
  // loadChildren: () => import('./open-data/open-data.module').then(m => m.OpenDataModule) },
  // { path: 'open-data', component: PageUnderdevelopmentComponent },
  { path: 'guide', loadChildren: () => import('./library/library.module').then(m => m.LibraryModule)},
  { path: 'product', component: PageUnderdevelopmentComponent },
  { path: 'create-profile', component: UserProfileFormComponent },
  { path: 'design-system', component: UiElementsComponent },
  { path: '**', component: PageNotFoundComponent }
];



@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true, scrollPositionRestoration: 'enabled' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
