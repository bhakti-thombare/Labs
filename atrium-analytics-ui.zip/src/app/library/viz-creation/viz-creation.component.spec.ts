import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VizCreationComponent } from './viz-creation.component';

describe('VizCreationComponent', () => {
  let component: VizCreationComponent;
  let fixture: ComponentFixture<VizCreationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VizCreationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VizCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
