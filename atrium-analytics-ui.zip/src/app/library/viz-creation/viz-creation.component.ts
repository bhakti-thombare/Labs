import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { GeneralService } from '..//shared/general-service.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { findIndex } from 'lodash';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { DomSanitizer } from '@angular/platform-browser';
import {
  debounceTime,
  distinctUntilChanged,
  switchMap,
  catchError,
  tap,
  filter,
  delay,
} from 'rxjs/operators';
import { of, observable, Observable, ReplaySubject } from 'rxjs';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { UtilityService } from 'src/app/core/services/utility.service';
import { ErrorMessageHandlerService } from 'src/app/core/services/error-message-handler.service';

@Component({
  selector: 'ab-viz-creation',
  templateUrl: './viz-creation.component.html',
  styleUrls: ['./viz-creation.component.scss'],
})
export class VizCreationComponent implements OnInit {
  constructor(
    private errorMessageHandler: ErrorMessageHandlerService,
    private generalservice: GeneralService,
    private notificationService: NotificationService,
    private router: Router,
    private authServie: AuthService,
    // tslint:disable-next-line: variable-name
    private _d: DomSanitizer,
    private utilityService: UtilityService,
    private sanitizer: DomSanitizer,
    private activeRoute: ActivatedRoute,
    private translate: TranslateService
  ) {
    this.vizId = this.activeRoute.snapshot.params.id;
  }
  tagData = [];
  checkQualityFlag;
  vizId: any;
  selectedTag = [];
  editFlag = false;
  validateElement;
  img: any;
  img1: any;
  userLanguage: any;
  currentUser: any;
  userId: any;
  tagDataNl = [];
  imageRequired;
  oneTag;
  maxLimit;
  imageSizeExceeded;
  imageType;
  mandatoryInThreeLanguage;
  selectedLanguage;
  vizCreated;
  tagNotFound;
  duplicateVizName = false;
  vizNameObj = {};
  lang = 'en';
  duplicateVizNameEn;
  duplicateVizNameFr;
  duplicateVizNameNl;
  vizNameEn;
  vizNameFr;
  vizNameNl;

  leftPannel = {
    stepTwo: false,
    stepThree: false,
    stepFour: false,
    categoryFlag: ['tag'],
  };
  leftPannel2 = {
    stepFour: false,
  };

  public dataobj: any = {
    userId: this.userId,
    roleCode: this.currentUser,
    languageCode: this.userLanguage,
    vizCommonSection: {
      thumbnailImage: true,
      completeTitle: false,
      completeLegend: false,
      filtersConfigured: false,
      appropriateFonts: false,
      appropriateColors: false,
      actions: false,
      hubmapInserted: false,
      mapFunctionsConfigured: false,
      tooltipsConfigured: false,
      translationIn3Lang: false,
      vizLive: false,
      vizHomepageDisplay: false,
      publish: false,
      tags: null,
    },
    vizInformation: [
      {
        language: 'EN',
        name: '',
        description: '',
        embedCode: '',
        information: '',
      },
      {
        language: 'FR',
        name: '',
        description: '',
        embedCode: '',
        information: '',
      },
      {
        language: 'NL',
        name: '',
        description: '',
        embedCode: '',
        information: '',
      },
    ],
  };
  public qualityCheck = [
    { id: 'completeTitle', label: 'CompleteTitle' },
    { id: 'completeLegend', label: 'CompleteLegend' },
    { id: 'filtersConfigured', label: 'FiltersConfigured' },
    { id: 'appropriateFonts', label: 'font' },
    { id: 'appropriateColors', label: 'GraphMap' },
    { id: 'actions', label: 'Action' },
    { id: 'hubmapInserted', label: 'HubMap' },
    { id: 'mapFunctionsConfigured', label: 'MapFunctuin' },
    { id: 'tooltipsConfigured', label: 'ToolTip' },
    { id: 'translationIn3Lang', label: 'Translation' },
  ];
  indexTag = [];
  tagDataFr = [];
  tags: ReplaySubject<any> = new ReplaySubject<any>(undefined);
  tags$: Observable<any> = this.tags.asObservable();
  index1 = 0;
  selectColorE3 = false;
  selectColorF3 = false;
  selectColorN3 = false;
  filteredTagsMultipleArray: any[];
  selectedType;
  types = [];
  basicInformation: FormGroup;
  stepOne = false;
  color;
  activeTwo = false;
  activeThree = false;
  activeFour = false;
  stepTwo = false;
  step2 = true;
  step3 = false;
  stepThree = false;
  stepFour = false;
  activeColor2 = 'black';
  activeColor3: 'black';
  activeColor4: 'black';
  received;
  stepValues = {
    stepOne: true,
    stepTwo: false,
    stepThree: false,
    stepFour: false,
    activeTwo: false,
    activeThree: false,
    activeFour: false,
    activeColor2: '#1A77EE',
    activeColor1: 'gray',
    activeColor3: 'black',
    activeColor4: 'black',
  };
  step4: boolean;
  key;
  tagName;
  tagArray = [];
  imgsrc: any;
  image;
  imageSize;
  sizeLimit = 10485760;
  public myValue = new FormControl([]);

  selectColorE2 = false;
  selectColorF2 = false;
  selectColorN2 = false;
  selectTabE2 = false;
  selectTabF2 = true;
  selectTabN2 = true;

  index2 = 0;
  selectTabE3 = false;
  selectTabF3 = true;
  selectTabN3 = true;
  flag = false;
  tagId = [];

  tagBody = {
    userId: this.userId,
    roleCode: this.currentUser,
    languageCode: this.userLanguage,
  };
  // tslint:disable-next-line: member-ordering
  tagdata1 = [];
  // tslint:disable-next-line: member-ordering
  tagDataen = [];
  submitted = false;
  userInit() {
    this.authServie.currentUser$.subscribe((user) => {
      this.userId = user.id;
      this.userLanguage = user.language;
      this.currentUser = user.role;
    });
  }
  getTagListBySearch(tag) {
    return this.generalservice.getTags(this.tagBody, tag, { loader: true });
  }

  listenChanges() {
    this.tags$
      .pipe(
        debounceTime(500),
        tap((tag) => {}),
        switchMap((tag) =>
          this.getTagListBySearch(tag).pipe(
            catchError((err) => {
              // throw of(err);
              return of(err);
            })
          )
        )
      )
      .subscribe(
        (tags) => {
          this.processResult(tags);
        },
        (error) => {}
      );
  }
  processResult(tags) {
    let resultTags = [];
    if (tags.hasOwnProperty('error')) {
      const error = this.errorMessageHandler.getMessageFromError(tags);
      this.translate.get('NotificationMessages.' + error).subscribe((res) => {
        this.notificationService.showError(res);
      });
    } else {
      resultTags = tags.value.content;
    }
    this.filteredTagsMultipleArray = this.filterTag(this.key, resultTags);
  }

  filterTagsMultiple(event) {
    this.key = event;
    this.tags.next(this.key);
  }
  filterTag(query, tagCount: any[]): any[] {
    tagCount.forEach((tag) => {
      this.tagData.push(tag);
    });

    // tslint:disable-next-line: prefer-const
    let filtered: any[] = [];
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < tagCount.length; i++) {
      if (this.index1 === 0) {
        this.tagArray = tagCount[i].enTagName;
      } else if (this.index1 === 1) {
        this.tagArray = tagCount[i].frTagName;
      } else {
        this.tagArray = tagCount[i].nlTagName;
      }

      filtered.push(this.tagArray);
    }
    return filtered;
  }

  receivedEvent(event) {
    this.step2 = event.step2;
    this.step4 = event.step4;
    this.stepOne = event.stepOne;
    this.stepTwo = event.stepThree;
    this.stepThree = event.stepThree;
    this.step3 = event.step3;
    this.stepFour = event.stepFour;
  }
  fileChange(e) {
    const file = e.srcElement.files[0];
    this.imageSize = 0;
    this.imageSize = e.srcElement.files[0].size;

    const allowedExtensions = /(\.jpg|\.jpeg|\.png|\.svg)$/i;
    if (!allowedExtensions.exec(file.name)) {
      // this.notificationService.showError(this.imageType);
      this.utilityService.showTranslatedNotificationMessage(
        'NotificationMessages.Viz.FileTypeImage',
        'ERROR'
      );
      return false;
    } else {
      if (this.imageSize > this.sizeLimit) {
        // this.notificationService.showError(this.imageSizeExceeded);
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Viz.FileSizeValidate',
          'ERROR'
        );
      } else {
        this.readThis(e.target);
        this.dataobj.vizCommonSection.thumbnailImage = true;

        this.imgsrc = this._d.bypassSecurityTrustUrl(
          window.URL.createObjectURL(file)
        );
      }
    }
  }
  readThis(inputValue: any): void {
    const file: File = inputValue.files[0];
    const myReader: FileReader = new FileReader();

    myReader.onloadend = (e) => {
      this.image = myReader.result;

      this.dataobj.vizCommonSection.thumbnail = this.image;
    };
    myReader.readAsDataURL(file);
  }
  setMessage(lang) {
    switch (lang) {
      case 'en':
        this.imageRequired = 'Image is required';
        this.oneTag = 'Atleast one tag is required!';
        this.maxLimit = 'max size 10 Mb';
        this.imageSizeExceeded = 'Image size exceeds maximum limit of 10 MB.';
        this.imageType = 'Only .jpg, .png, .svg types are allowed';
        this.mandatoryInThreeLanguage =
          'Please fill in the fields in three languages';
        this.vizCreated = 'Viz created successfully';
        this.tagNotFound = 'Tag not found!';
        this.validateElement = 'Please validate all the elements';

        break;
      case 'fr':
        this.imageRequired = 'L\'image est requise';
        this.oneTag = 'Au moins un tag est requis';
        this.maxLimit = 'taille maximum 10Mb';
        this.imageSizeExceeded =
          'La taille de l\'image dépasse la limite maximale de 10 Mb.';
        this.imageType = 'Seuls les formats .jpg, .png, .svg sont autorisés';
        this.mandatoryInThreeLanguage =
          'Veuillez remplir les champs en trois langues ';
        this.vizCreated = 'Visualisation créées avec succès';
        this.tagNotFound = 'Tag non trouvé.';
        this.validateElement = 'Veuillez valider tous les éléments';

        break;
      case 'nl':
        this.imageRequired = 'Een afbeelding is vereist';
        this.oneTag = 'Ten minste één label is vereist';
        this.maxLimit = 'max grootte 10 Mb';
        this.imageSizeExceeded =
          'Afbeeldingsgrootte overschrijdt de maximum limiet van 10 MB.';
        this.imageType = 'Alleen .jpg, .png, .svg formaten zijn toegestaan';
        this.mandatoryInThreeLanguage =
          'Gelieve de velden in drie talen in te vullen';
        this.vizCreated = 'Visualisatie met succes gemaakt';
        this.tagNotFound = 'tag niet gevonden!';
        this.validateElement = 'Valideer alle elementen';

        break;
    }
  }

  ngOnInit() {
    this.checkQualityFlag = true;
    this.userInit();
    this.selectedLanguage = localStorage.getItem('language');
    this.setMessage(this.selectedLanguage);

    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.selectedLanguage = event.lang;
      this.setMessage(this.selectedLanguage);
    });
    this.basicInformation = new FormGroup({
      vizName: new FormControl(''),
      thumbnail: new FormControl(''),
      description: new FormControl(''),
      langS2: new FormControl(''),
      langS3: new FormControl(''),
      embedCode: new FormControl(''),
      information: new FormControl(''),
      completeTitle: new FormControl(''),
      completeLegend: new FormControl(''),
      filtersConfigured: new FormControl(''),
      appropriateFonts: new FormControl(''),
      appropriateColors: new FormControl(''),
      actions: new FormControl(''),
      hubmapInserted: new FormControl(''),
      mapFunctionsConfigured: new FormControl(''),
      tooltipsConfigured: new FormControl(''),
      translationIn3Lang: new FormControl(''),
      vizHomepageDisplay: new FormControl(''),
      vizLive: new FormControl(''),
    });
    if (this.vizId !== undefined) {
      this.editViz();
      // this.stepTwoFr();
    }
    this.onValueChanges();
    this.onVizNameChanges();
    this.listenChanges();
  }
  transform() {
    // tslint:disable-next-line: whitespace
    this.img1 = this.sanitizer.bypassSecurityTrustResourceUrl(this.img);
    this.imgsrc = this.img1.changingThisBreaksApplicationSecurity;
  }
  editViz() {
    this.editFlag = true;
    // get api

    this.generalservice
      .getViz(this.tagBody, { loader: true }, this.vizId)
      .subscribe((res) => {

        this.dataobj = res.value;
        this.tagData = res.value.vizCommonSection.tags;
        this.tagData.forEach((i) => {
          this.selectedTag.push(i.enTagName);
        });
        this.dataobj.vizCommonSection.thumbnailImage = false;
        this.img = this.dataobj.vizCommonSection.thumbnail;
        this.vizNameEn = res.value.vizInformation[0].name.toLowerCase();
        this.vizNameFr = res.value.vizInformation[1].name.toLowerCase();
        this.vizNameNl = res.value.vizInformation[2].name.toLowerCase();
        this.transform();
        // this.indexTag=this.dataobj.vizCommonSection.tags;
        this.stepTwoEnglish();
        // this.stepThreeFr();
        this.stepThreeEn();
        this.checkedQualityPatch();
        // this.checkedQualityPatch();
      });
  }
  getVizName() {
    // tslint:disable-next-line: no-string-literal
    this.vizNameObj['language'] = this.lang;

    return this.generalservice.getVizName(this.vizNameObj, { loader: true });
  }
  onVizNameChanges() {
    this.basicInformation
      .get('vizName')
      .valueChanges.pipe(
        debounceTime(800),
        distinctUntilChanged(),
        filter((searchTerm) => searchTerm.length >= 2 || !searchTerm.length),
        switchMap((form) =>
          this.getVizName().pipe(
            catchError((err) => {
              return of(err);
            })
          )
        )
      )
      .subscribe((res) => {
        if (this.lang === 'en') {
          if (res.hasOwnProperty('error') && res.error.status === 409) {
            this.duplicateVizName = true;
            this.duplicateVizNameEn = true;
          } else {
            this.duplicateVizNameEn = false;
          }
        }
        if (this.lang === 'fr') {
          if (res.hasOwnProperty('error') && res.error.status === 409) {
            this.duplicateVizName = true;
            this.duplicateVizNameFr = true;
          } else {
            this.duplicateVizNameFr = false;
          }
        }
        if (this.lang === 'nl') {
          if (res.hasOwnProperty('error') && res.error.status === 409) {
            this.duplicateVizName = true;
            this.duplicateVizNameNl = true;
          } else {
            this.duplicateVizNameNl = false;
          }
        }

        if (
          res.hasOwnProperty('error') && res.error.status === 409
            ? // tslint:disable-next-line: no-conditional-assignment
              (this.duplicateVizName = true)
            : // tslint:disable-next-line: no-conditional-assignment
              (this.duplicateVizName = false)
        ) {
          //   this.duplicateVizName=true;
        }
        this.checkValidation();
      });
  }
  checkValidation() {
    // tslint:disable-next-line: no-string-literal
    if (this.vizNameObj['vizName'] !== undefined) {

    // tslint:disable-next-line: no-string-literal
    if (this.vizNameEn === this.vizNameObj['vizName'].toLowerCase()) {
      this.duplicateVizName = false;
      this.duplicateVizNameEn = false;
    }
    // tslint:disable-next-line: no-string-literal
    if (this.vizNameFr === this.vizNameObj['vizName'].toLowerCase()) {
      this.duplicateVizName = false;
      this.duplicateVizNameFr = false;
    }
    // tslint:disable-next-line: no-string-literal
    if (this.vizNameNl === this.vizNameObj['vizName'].toLowerCase()) {
      this.duplicateVizName = false;
      this.duplicateVizNameNl = false;
    }
  }

}

  deleteTag(event) {
    this.leftPannel = {
      stepTwo: false,
      stepThree: true,
      stepFour: false,
      categoryFlag: this.selectedTag,
    };
  }
  selectedTagList(event) {
    this.leftPannel = {
      stepTwo: false,
      stepThree: true,
      stepFour: false,
      categoryFlag: this.selectedTag,
    };
  }

  onValueChanges(): void {
    this.index2 = 0;
    // tslint:disable-next-line: no-string-literal
    this.vizNameObj['roleCode'] = this.currentUser;
    // tslint:disable-next-line: no-string-literal
    this.vizNameObj['userId'] = this.userId;
    this.basicInformation.valueChanges.subscribe((val) => {
      // tslint:disable-next-line: no-string-literal
      this.vizNameObj['vizName'] = val.vizName;

      val.vizName = val.vizName.trim();
      val.description = val.description.trim();
      val.embedCode = val.embedCode.trim();
      val.information = val.information.trim();

      this.dataobj.vizInformation[this.index1].name = val.vizName;
      this.dataobj.vizInformation[this.index1].description = val.description;


      if (this.flag) {
        this.dataobj.vizInformation[this.index2].embedCode = val.embedCode;
        this.dataobj.vizInformation[this.index2].information = val.information;
      }
      if (!this.flag) {
        this.flag = true;
      }

      this.selectColorE2 = false;
      this.selectColorF2 = false;
      this.selectColorN2 = false;
      this.selectColorE3 = false;
      this.selectColorF3 = false;
      this.selectColorN3 = false;
      // this.trimInitialWhiteSpace(this.dataobj.vizInformation);
      if (
        this.dataobj.vizInformation[0].description !== '' &&
        this.dataobj.vizInformation[0].name !== ''
      ) {
        this.selectColorE2 = true;
      }
      if (
        this.dataobj.vizInformation[1].description !== '' &&
        this.dataobj.vizInformation[1].name !== ''
      ) {
        this.selectColorF2 = true;
      }

      if (
        this.dataobj.vizInformation[2].description !== '' &&
        this.dataobj.vizInformation[2].name !== ''
      ) {
        this.selectColorN2 = true;
      }

      if (this.selectColorF2 && this.selectColorE2 && this.selectColorN2) {
        this.leftPannel = {
          stepTwo: false,
          stepThree: true,
          stepFour: false,
          categoryFlag: this.selectedTag,
        };
      } else {
        this.leftPannel = {
          stepTwo: false,
          stepThree: false,
          stepFour: false,
          categoryFlag: this.selectedTag,
        };
      }

      if (
        this.dataobj.vizInformation[0].embedCode !== '' &&
        this.dataobj.vizInformation[0].information !== ''
      ) {

        this.selectColorE3 = true;
      }
      if (
        this.dataobj.vizInformation[1].embedCode !== '' &&
        this.dataobj.vizInformation[1].information !== ''
      ) {

        this.selectColorF3 = true;
      }

      if (
        this.dataobj.vizInformation[2].embedCode !== '' &&
        this.dataobj.vizInformation[2].information !== ''
      ) {

        this.selectColorN3 = true;
      }

      if (this.selectColorF3 && this.selectColorE3 && this.selectColorN3) {

        this.leftPannel2 = {
          stepFour: true,
        };
      } else {
        this.leftPannel2 = {
          stepFour: false,
        };
      }
    });
  }

  onCheckedLive(e) {
    this.dataobj.vizCommonSection.vizLive = e.srcElement.checked;
  }
  onCheckedHome(e) {
    this.dataobj.vizCommonSection.vizHomepageDisplay = e.srcElement.checked;
  }
  stepTwoEnglish() {
    this.indexTag = [];
    this.tagDataen = [];
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < this.selectedTag.length; i++) {
      if (this.index1 === 1) {
        const index = findIndex(this.tagData, [
          'frTagName',
          this.selectedTag[i],
        ]);
        this.indexTag.push(index);
      } else if (this.index1 === 2) {
        const index = findIndex(this.tagData, [
          'nlTagName',
          this.selectedTag[i],
        ]);
        this.indexTag.push(index);
      } else if (this.index1 === 0) {
        const index = findIndex(this.tagData, [
          'enTagName',
          this.selectedTag[i],
        ]);
        this.indexTag.push(index);
      }
    }

    this.indexTag.forEach((i) => {
      this.tagDataen.push(this.tagData[i].enTagName);
    });
    this.selectedTag = [...new Set(this.tagDataen)];
    this.selectTabE2 = false;
    this.selectTabN2 = true;
    this.selectTabF2 = true;

    this.index1 = 0;
    this.lang = 'en';
    this.basicInformation.patchValue({
      vizName: this.dataobj.vizInformation[this.index1].name,
      description: this.dataobj.vizInformation[this.index1].description,
    });
    // }
  }

  stepTwoFr() {
    this.indexTag = [];
    this.tagDataFr = [];

    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < this.selectedTag.length; i++) {
      if (this.index1 === 0) {
        const index = findIndex(this.tagData, [
          'enTagName',
          this.selectedTag[i],
        ]);

        this.indexTag.push(index);
      } else if (this.index1 === 2) {
        const index = findIndex(this.tagData, [
          'nlTagName',
          this.selectedTag[i],
        ]);
        this.indexTag.push(index);
      }
    }

    this.indexTag.forEach((i) => {
      this.tagDataFr.push(this.tagData[i].frTagName);
    });

    this.selectedTag = [...new Set(this.tagDataFr)];

    this.selectTabE2 = true;
    this.selectTabF2 = false;
    this.selectTabN2 = true;
    this.index1 = 1;
    this.lang = 'fr';
    this.selectColorF2 = false;
    this.selectColorN2 = false;
    this.basicInformation.patchValue({
      vizName: this.dataobj.vizInformation[this.index1].name,
      description: this.dataobj.vizInformation[this.index1].description,
    });
  }

  stepTwoNl() {
    this.indexTag = [];
    this.tagDataNl = [];
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < this.selectedTag.length; i++) {
      if (this.index1 === 0) {
        const index = findIndex(this.tagData, [
          'enTagName',
          this.selectedTag[i],
        ]);
        this.indexTag.push(index);
      } else if (this.index1 === 1) {
        const index = findIndex(this.tagData, [
          'frTagName',
          this.selectedTag[i],
        ]);
        this.indexTag.push(index);
      }
    }

    this.indexTag.forEach((i) => {
      this.tagDataNl.push(this.tagData[i].nlTagName);
    });
    this.selectedTag = [...new Set(this.tagDataNl)];
    this.index1 = 2;
    this.lang = 'nl';
    this.selectTabN2 = false;
    this.selectTabF2 = true;
    this.selectTabE2 = true;
    this.basicInformation.patchValue({
      vizName: this.dataobj.vizInformation[this.index1].name,
      description: this.dataobj.vizInformation[this.index1].description,
    });
  }
  stepThreeEn() {
    this.index2 = 0;
    this.selectTabE3 = false;
    this.selectTabF3 = true;
    this.selectTabN3 = true;

    this.basicInformation.patchValue({
      embedCode: this.dataobj.vizInformation[this.index2].embedCode,
      information: this.dataobj.vizInformation[this.index2].information,
    });
  }
  stepThreeFr() {
    this.index2 = 1;
    this.selectTabE3 = true;
    this.selectTabF3 = false;
    this.selectTabN3 = true;
    this.selectColorF2 = false;
    this.selectColorN2 = false;
    this.basicInformation.patchValue({
      embedCode: this.dataobj.vizInformation[this.index2].embedCode,
      information: this.dataobj.vizInformation[this.index2].information,
    });
  }
  stepThreeNl() {
    this.index2 = 2;
    this.selectTabE3 = true;
    this.selectTabF3 = true;
    this.selectTabN3 = false;
    this.basicInformation.patchValue({
      embedCode: this.dataobj.vizInformation[this.index2].embedCode,
      information: this.dataobj.vizInformation[this.index2].information,
    });
  }
  goStepTwo() {
    this.stepOne = true;
    this.activeTwo = true;
    this.color = '#1A77EE';
    this.step2 = true;
    this.stepValues = {
      stepOne: this.stepOne,
      stepTwo: this.stepTwo,
      stepThree: this.stepThree,
      stepFour: this.stepFour,
      activeTwo: this.activeTwo,
      activeThree: this.activeThree,
      activeFour: this.activeFour,
      activeColor1: 'grey',
      activeColor2: '#1A77EE',
      activeColor3: 'black',
      activeColor4: 'black',
    };
  }
  goStepThree() {
    let categoryId = [];
    let categoryFlag = false;
    // to check tag category
    this.tagData.forEach((val) => {
      this.selectedTag.forEach((tag) => {
        // tslint:disable-next-line: triple-equals
        if (
          // tslint:disable-next-line: triple-equals
          tag == val.enTagName ||
          // tslint:disable-next-line: triple-equals
          tag == val.frTagName ||
          // tslint:disable-next-line: triple-equals
          tag == val.nlTagName
        ) {
          categoryId.push(val.categoryId);
        }
      });
    });
    categoryId = [...new Set(categoryId)];
    categoryId.forEach((id) => {
      if (id === 1) {
        categoryFlag = true;
      }
    });
    if (this.imgsrc === undefined) {
      this.utilityService.showTranslatedNotificationMessage(
        'NotificationMessages.Viz.ImageRequired',
        'ERROR'
      );
    } else if (this.selectedTag.length === 0) {
      this.utilityService.showTranslatedNotificationMessage(
        'NotificationMessages.Viz.AtleasetOneTag',
        'ERROR'
      );
    } else if (!categoryFlag) {
      this.utilityService.showTranslatedNotificationMessage(
        'NotificationMessages.Viz.tagCategory',
        'ERROR'
      );
    } else if (
      this.duplicateVizNameEn ||
      this.duplicateVizNameFr ||
      this.duplicateVizNameNl
    ) {
      this.utilityService.showTranslatedNotificationMessage(
        'VIZCREATION.STEPCREATION.VizNameError',
        'ERROR'
      );
    } else if (
      this.selectColorE2 &&
      this.selectColorF2 &&
      this.selectColorN2 &&
      !this.duplicateVizName
    ) {
      this.flag = true;
      this.activeThree = true;
      this.stepOne = true;
      this.step3 = true;
      this.stepTwo = true;
      this.step2 = false;
      this.stepValues = {
        stepOne: this.stepOne,
        stepTwo: this.stepTwo,
        stepThree: this.stepThree,
        stepFour: this.stepFour,
        activeTwo: this.activeTwo,
        activeThree: this.activeThree,
        activeFour: this.activeFour,
        activeColor1: 'grey',
        activeColor2: 'grey',
        activeColor3: '#1A77EE',
        activeColor4: 'black',
      };
    } else {
      this.utilityService.showTranslatedNotificationMessage(
        'NotificationMessages.General.ThreeLangMandatory',
        'ERROR'
      );
    }
  }
  checkedQualityPatch() {
    this.dataobj.vizCommonSection.actions = false;
    this.dataobj.vizCommonSection.appropriateColors = false;
    this.dataobj.vizCommonSection.appropriateFonts = false;
    this.dataobj.vizCommonSection.completeLegend = false;
    this.dataobj.vizCommonSection.completeTitle = false;
    this.dataobj.vizCommonSection.filtersConfigured = false;
    this.dataobj.vizCommonSection.hubmapInserted = false;
    this.dataobj.vizCommonSection.mapFunctionsConfigured = false;
    this.dataobj.vizCommonSection.tooltipsConfigured = false;
    this.dataobj.vizCommonSection.translationIn3Lang = false;
    this.basicInformation.patchValue({
      vizLive: this.dataobj.vizCommonSection.vizLive,
      vizHomepageDisplay: this.dataobj.vizCommonSection.vizHomepageDisplay,
    });
  }
  goStepFour() {
    // this.checkedQualityPatch();
    if (this.selectColorE3 && this.selectColorN3 && this.selectColorF3) {
      this.stepThree = true;
      this.step3 = false;
      this.step4 = true;
      this.activeFour = true;
      this.stepValues = {
        stepOne: this.stepOne,
        stepTwo: this.stepTwo,
        stepThree: this.stepThree,
        stepFour: this.stepFour,
        activeTwo: this.activeTwo,
        activeThree: this.activeThree,
        activeFour: this.activeFour,
        activeColor2: 'grey',
        activeColor3: 'grey',
        activeColor4: '#1A77EE',
        activeColor1: 'grey',
      };
    } else {
      this.utilityService.showTranslatedNotificationMessage(
        'NotificationMessages.General.ThreeLangMandatory',
        'ERROR'
      );
    }
  }
  onCheckedQuality(event, id) {
    this.submitted = false;
    this.dataobj.vizCommonSection[id] = event.srcElement.checked;
    this.checkedAllQualityMarks();
  }
  checkedAllQualityMarks() {
    this.checkQualityFlag = false;
    this.qualityCheck.forEach((ele) => {
      if (this.dataobj.vizCommonSection[ele.id] === false) {
        this.checkQualityFlag = true;
      }
    });
    if (this.checkQualityFlag && this.submitted) {
      // this.notificationService.showError(this.validateElement);
      this.utilityService.showTranslatedNotificationMessage(
        'NotificationMessages.Viz.ValidateElements',
        'ERROR'
      );
    }
  }

  submit() {
    this.submitted = true;
    this.checkedAllQualityMarks();
    this.stepTwoEnglish();
    this.stepTwoFr();
    this.stepTwoNl();
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < this.selectedTag.length; i++) {
      if (this.index1 === 0) {
        // tslint:disable-next-line: no-shadowed-variable
        const index = findIndex(this.tagData, [
          'enTagName',
          this.selectedTag[i],
        ]);
        this.indexTag.push(index);
      } else if (this.index1 === 0) {
        // tslint:disable-next-line: no-shadowed-variable
        const index = findIndex(this.tagData, [
          'frTagName',
          this.selectedTag[i],
        ]);
        this.indexTag.push(index);
      } else if (this.index2 === 0) {
        // tslint:disable-next-line: no-shadowed-variable
        const index = findIndex(this.tagData, [
          'nlTagName',
          this.selectedTag[i],
        ]);
        this.indexTag.push(index);
      }
    }
    const index = [...new Set(this.indexTag)];

    index.forEach((i) => {
      this.tagId.push(this.tagData[i].tagId);
      this.tagId = [...new Set(this.tagId)];
    });
    this.dataobj.vizCommonSection.tags = this.tagId;

    this.step4 = true;

    this.dataobj.vizCommonSection.publish = true;
    if (this.dataobj.vizCommonSection.thumbnailImage === false) {
      delete this.dataobj.vizCommonSection.thumbnail;
    }
    if (this.editFlag) {
      if (this.checkQualityFlag === false) {
        this.generalservice
          .editViz(this.dataobj, this.vizId)
          .subscribe((res) => {
            if (res.message === 'Request successful') {
              this.utilityService.showTranslatedNotificationMessage(
                'NotificationMessages.Viz.VizUpated',
                'SUCCESS'
              );
              this.router.navigate(['/library/dashboard']);
            }
          });
      }
    } else {
      if (this.checkQualityFlag === false) {
        this.generalservice.createViz(this.dataobj).subscribe((res) => {
          if (res.message === 'Request successful') {
            // this.notificationService.showSuccess(this.vizCreated);
            this.utilityService.showTranslatedNotificationMessage(
              'NotificationMessages.Viz.VizCreated',
              'SUCCESS'
            );

            this.router.navigate(['/library/dashboard']);
          }
        });
      }
    }

    this.stepFour = true;
    this.stepValues = {
      stepOne: this.stepOne,
      stepTwo: this.stepTwo,
      stepThree: this.stepThree,
      stepFour: this.stepFour,
      activeTwo: this.activeTwo,
      activeThree: this.activeThree,
      activeFour: this.activeFour,
      activeColor2: 'grey',
      activeColor3: 'grey',
      activeColor4: 'grey',
      activeColor1: 'grey',
    };
  }
}
