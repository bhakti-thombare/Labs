import { Component, OnInit, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { GeneralService } from '../shared/general-service.service';
import { AuthService } from 'src/app/core/services/auth.service';
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {
  distinctUntilChanged,
  debounceTime,
  filter,
  switchMap,
  catchError,
  takeUntil,
} from 'rxjs/operators';
import { of, interval } from 'rxjs';
import { NotificationService } from 'src/app/core/services/notification.service';
import { error } from 'util';
import { ErrorMessageHandlerService } from 'src/app/core/services/error-message-handler.service';
import { UtilityService } from 'src/app/core/services/utility.service';

@Component({
  selector: 'ab-invite-people',
  templateUrl: './invite-people.component.html',
  styleUrls: ['./invite-people.component.scss'],
})
export class InvitePeopleComponent implements OnInit {
  constructor(
    private utilityService: UtilityService,
    private errorMessageHandler: ErrorMessageHandlerService,
    private generealService: GeneralService,
    private authService: AuthService,
    private router: Router,
    private activeRoute: ActivatedRoute,
    public formBuilder: FormBuilder,
    private ref: ChangeDetectorRef,
    private notificationService: NotificationService
  ) { }
  currentUser: any;
  userId: number;
  languageCode: string;
  vizId;
  page = 0;
  search = [];


  emailAddressPattern = new RegExp(
    // tslint:disable-next-line: max-line-length
    /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  );

  multipleEmailAddressPattern = new RegExp(
    /^(\s?[^\s,]+@[^\s,]+\.[^\s,]+\s?,)*(\s?[^\s,]+@[^\s,]+\.[^\s,]+)$/
  );
  invitePeopleSearch: FormGroup;

  invitePeople = new FormGroup({
    searchByEmail: new FormControl(),
  });

  searchBody;
  val = '';
  userData;
  searchResult;
  inviteUserFlag = false;
  removeUserFlag = false;
  invitedUser = [];
  removedUser = [];
  @Output() closeModal = new EventEmitter<boolean>();
  flag = false;
  emailArray = [];
  userCount;
  invitedEmail;
  totalElements: number;
  isLastPage;
  loadUser() {
    this.authService.currentUser$.subscribe((user) => {
      this.currentUser = user.role;
      this.userId = user.id;
      this.languageCode = user.language;
    });
    this.searchBody = {
      userId: this.userId,
      roleCode: this.currentUser,
      languageCode: this.languageCode,
      name: this.val,
      vizId: this.vizId,
    };
    this.defaultUsers();
    // this.searchBody.email = '';
  }
  defaultUsers() {
    this.generealService
    .searchUser(this.searchBody, {page: this.page, loader: true })
    .subscribe((res) => {
      this.totalElements = res.value.totalElements;
      this.isLastPage = res.value.last;

      this.searchResult = res.value.content;
      this.userData = res.value.content;
      this.searchResult.forEach((element) => {
        const index = element.userName.split(' ');
        element.firstletter = element.userName[0].concat([index[1][0]]);
      });
      this.searchResult.forEach((result) => {
        this.search.push(result);
      });
    });
  }
  invitedUsers(userId) {
    this.inviteUserFlag = true;

    this.invitedUser.push(userId);
    this.invitedUser.forEach((user) => {
      this.removedUser.forEach((removeUser) => {
        // tslint:disable-next-line: triple-equals
        if (user == removeUser) {
          const index = this.removedUser.indexOf(user);
          this.removedUser.splice(index, 1);
        }
      });
    });

    this.search.forEach((val) => {
      if (val.userId === userId) {
        val.invitedOnViz = true;
      }
    });

  }
  removedUsers(userId) {
    this.removedUser.push(userId);

    this.removeUserFlag = true;

    this.removedUser.forEach((user) => {
      this.invitedUser.forEach((invitedUser) => {
        // tslint:disable-next-line: triple-equals
        if (user == invitedUser) {
          const index = this.invitedUser.indexOf(user);
          this.invitedUser.splice(index, 1);
        }
      });
    });

    this.search.forEach((val) => {
      if (val.userId === userId) {
        val.invitedOnViz = false;
      }
    });
  }
  getUserListBySearch() {
    this.page = 0;
    this.searchBody.name = this.invitePeople.value.searchByEmail;

    return this.generealService.searchUser(this.searchBody, { page: this.page, loader: true });
  }
  onChanges() {
    this.searchBody.name = this.invitePeople.value.searchByEmail;
    this.invitePeople.
      valueChanges
      .pipe(
        debounceTime(150),
        distinctUntilChanged(),
        filter(searchTerm => searchTerm.length >= 2 || !searchTerm.length),
        switchMap((form) =>
          this.getUserListBySearch().pipe(
            takeUntil(this.invitePeople.valueChanges),
            catchError(err => {
              return of(err);
            })
          )
        )
      )
      .subscribe((res) => {
        this.processResult(res);
        // this.searchResult = res.value.content;
        // tslint:disable-next-line: no-unused-expression
      });
  }
  processResult(data) {
    this.search = [];
    this.searchResult = [];
    this.totalElements = data.value.totalElements;
    this.isLastPage = data.value.last;

    if (data.hasOwnProperty('error')) {
      this.onChanges();
      // this.errorMessageHandler.getMessageFromError(data);
      if (data.status !== 404) {
        throw data;
        this.notificationService.showError(data.error.message);
      }
    } else {

      this.searchResult = data.value.content;

    }
    this.searchResult.forEach(element => {
      const index = element.userName.split(' ');
      element.firstletter = element.userName[0].concat([index[1][0]]);
    });
    this.searchResult.forEach(element => {
      this.search.push(element);
    });

  }
  validateUser() {
    this.searchBody.inviteUsers = [...new Set(this.invitedUser)];
    this.searchBody.removeUsers = [...new Set(this.removedUser)];
    this.searchBody.inviteEmails = [];
    this.callInvitePeople();
  }
  callInvitePeople() {
    let email;
    email = this.invitePeopleSearch.value.email.trim().split(',');
    delete this.searchBody.name;
    this.searchBody.inviteEmails = [];

    // tslint:disable-next-line: triple-equals
    if (!(email == '')) {
      this.searchBody.inviteEmails = email;
    }
    this.generealService.inviteUser(this.searchBody).subscribe((res) => {
      // tslint:disable-next-line: triple-equals
      if (res.message == 'Request successful') {
        this.flag = true;
        // this.notificationService.showSuccess('People invited successfully');
        this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Viz.PeopleInvited', 'SUCCESS');
        this.closeModal.emit(this.flag);
      }
    });

  }
  checkEmailValidations() {
    this.invitePeopleSearch = this.formBuilder.group({
      email: [
        '',
        [
          Validators.required,
          Validators.pattern(this.multipleEmailAddressPattern),
        ],
      ],
    });
    this.invitePeopleSearch
      .get('email')
      .valueChanges.subscribe((emails: string) => {
        if (emails) {
          if (
            emails.trim().split(',').length > 1 &&
            this.invitePeopleSearch.valid
          ) {
            this.userCount = emails.split(',').filter((email) => email).length;
          } else if (
            emails.trim().split(',').length === 1 &&
            emails.match(this.emailAddressPattern)
          ) {
            this.userCount = 1;
          } else if (!emails.length) {
            this.userCount = 0;
          }
        } else if (!emails.length) {
          this.userCount = 0;
        }
        this.ref.detectChanges();
      });
  }
  onScroll(event) {
    if (event.target.scrollHeight - event.target.scrollTop === event.target.clientHeight) {
      if (this.searchResult.length < this.totalElements) {
        if (!this.isLastPage) {
          this.page = this.page + 1;
          this.defaultUsers();
        }
      }
    }

  }
  ngOnInit() {
    this.vizId = this.activeRoute.snapshot.params.id;
    this.loadUser();
    this.onChanges();
    this.checkEmailValidations();
  }
}
