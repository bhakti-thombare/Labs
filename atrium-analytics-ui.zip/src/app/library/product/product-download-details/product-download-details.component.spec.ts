import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductDownloadDetailsComponent } from './product-download-details.component';

describe('ProductDownloadDetailComponent', () => {
  let component: ProductDownloadDetailsComponent;
  let fixture: ComponentFixture<ProductDownloadDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductDownloadDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductDownloadDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
