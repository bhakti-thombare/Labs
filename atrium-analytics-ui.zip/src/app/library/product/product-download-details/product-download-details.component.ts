import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'ab-product-download-details',
  templateUrl: './product-download-details.component.html',
  styleUrls: ['./product-download-details.component.scss']
})
export class ProductDownloadDetailsComponent implements OnInit {
  @Output() closeEvent: EventEmitter<any> = new EventEmitter<any>();
  constructor() { }

  ngOnInit() {
  }

  closeModal() {
    this.closeEvent.emit(true);
  }

}
