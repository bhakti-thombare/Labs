import {
  Component,
  OnInit,
  Input,
  EventEmitter,
  Output,
  AfterViewInit,
  AfterViewChecked,
  ViewChild,
  TemplateRef,
  ChangeDetectorRef,
  ViewEncapsulation,
  ViewRef,
} from '@angular/core';
import {
  GridsterConfig,
  GridsterItem,
  GridsterComponentInterface,
  GridType,
  DisplayGrid,
  CompactType,
} from 'angular-gridster2';
import { GeneralService } from '../../shared/general-service.service';
// import { product as productObject } from '../../../../assets/product1';
import { trigger, transition, style, animate } from '@angular/animations';
import { TranslateService } from '@ngx-translate/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import * as _ from 'lodash';
// import * as jsPDF from 'jspdf';
// import html2canvas from 'html2canvas';
// import html2pdf from 'html2pdf.js';
// var html2pdf = require('html2pdf');
// declare var FireShotAPI: any;
// const puppeteer = require('puppeteer-extra');
// puppeteer.use(require('puppeteer-extra-plugin-angular')());

// import domtoimage from 'dom-to-image';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { UtilityService } from 'src/app/core/services/utility.service';
// import { CanvasRenderer } from 'html2canvas/dist/types/render/canvas/canvas-renderer';
// import { CanvasElementContainer } from 'html2canvas/dist/types/dom/replaced-elements/canvas-element-container';
// import { image } from 'html2canvas/dist/types/css/types/image';
import { BsModalService, ModalDirective } from 'ngx-bootstrap/modal';
import { Cookie } from 'src/app/core/services/cookie';
import { Orientation, TourStep, GuidedTourService } from 'ngx-guided-tour';
import { LoaderService } from 'src/app/core/services/loader.service';
import { SharedDataServiceService } from 'src/app/core/services/shared-data-service.service';
import { Subscription } from 'rxjs';
import { ProductPreviewDetailsComponent } from '../product-preview-details/product-preview-details.component';


@Component({
  selector: 'ab-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss'],
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({ transform: 'translateX(-100%)' }),
        animate('200ms ease-in', style({ transform: 'translateX(0%)' })),
      ]),
      transition(':leave', [
        animate('200ms ease-in', style({ transform: 'translateX(-100%)' })),
      ]),
    ]),
  ],
  // encapsulation: ViewEncapsulation.None,
})
export class ProductDetailsComponent implements OnInit, AfterViewInit, AfterViewChecked {
  productLangs = [];
  messageObject: any;
  guidedTour: any;
  isGuide = false;
  tutorialCalled = true;
  observer: MutationObserver;
  @ViewChild('missionDate',{static : true}) myRangeInput: ProductPreviewDetailsComponent;
  flag: boolean=false;
  name: any;
  checkedFlag: boolean =false;
  leftPanelSelected: boolean = false;
  constructor(
    private cdRef: ChangeDetectorRef,
    private loaderService: LoaderService,
    private guidedTourService2: GuidedTourService,
    private modalService2: BsModalService,
    private modalService: BsModalService,
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private translate: TranslateService,
    private generalService: GeneralService,
    private utilityService: UtilityService,
    private sharedData: SharedDataServiceService
  ) {
    ProductDetailsComponent.that = this;
    this.dashboard = {
      languages: [
        {
          language: 'fr',
          gridItems: [],
        },
        {
          language: 'nl',
          gridItems: [],
        },
        {
          language: 'en',
          gridItems: [],
        },
      ],
    };

    this.privateDashboard = {
      languages: [
        {
          language: 'fr',
          gridItems: [],
        },
        {
          language: 'nl',
          gridItems: [],
        },
        {
          language: 'en',
          gridItems: [],
        },
      ],
    };
  }
  // tslint:disable-next-line: member-ordering
  private static that: ProductDetailsComponent;
  product: any;
  kpiCategoryInput: any;
  kpiSelectionCollapsed = false;
  activeTab = 0;
  //  productHeight: any;
  productInfo: any;
  kpiCategory = {
    languages: [
      {
        language: 'fr',
        productName: '',
        description: '',
        productCategoryList: [],
      },
      {
        language: 'nl',
        productName: '',
        description: '',
        productCategoryList: [],
      },
      {
        language: 'en',
        productName: '',
        description: '',
        productCategoryList: [],
      },
    ],
  };
  selectedTabLanguage = localStorage.getItem('language');
  options: GridsterConfig;
  dashboardLanguageIndex: number;
  checkPreviousUrl;
  saveAsDraft = false;
  languageChangeSubscription: Subscription;


  dashboard: {
    languages: Array<{ language: string; gridItems: Array<GridsterItem> }>;
  };
  sectionsToShow = [];
  productType: string;
  frCompleted: boolean;
  enCompleted: boolean;
  nlCompleted: boolean;
  id: any;
  currentUser: any;
  homepage = false; 
  @ViewChild('catDetails', { static: true }) catDetails: ProductPreviewDetailsComponent;
  @ViewChild('genericConfirm', { static: true })
  genericConfirm: GenericConfirmComponent;
  deleteProductTitle: string;
  deleteProductText: string;
  selectedLanguage = localStorage.getItem('language');
  modalRef: any;
  loginModalRef: any;
  invitePeopleModalRef: any;
  shareLinkModalRef: any;
  link: string;
  link2: string;
  kpiSelectionParm: string;
  kpiSelectionParam: string;
  privateDashboard: {
    languages: Array<{ language: string; gridItems: Array<GridsterItem> }>;
  };
  isLogin = false;
  showButtons = false;
  dashboardUrl = false;
  deleteForDraft = false;
  guidePage = false;
  categoryIndexPos = 0;

  static gridSizeChanged(gridsterComponent: GridsterComponentInterface) {
    const element = document.getElementById('gridster-preview-content');
    if (element) {
      // console.log('element', element);90.5
      element.style.height = gridsterComponent.rows * 93.5 + 80.5 + 'px';
    }
    const element1 = document.getElementById('gridster-preview-content');
    if (element1) {
      // console.log('element1', element1);
    }
  }
  backToLibrary(value) {
    // window.history.back();
    if (value === 'library') {
      this.router.navigate(['/library', { previousUrl: 'product-details' }]);
    } else {
      this.sharedData.sharedUrl = 'product-page';
      window.history.back();
    }
  }
  ngOnInit() {
    this.name=this.translate.instant('Select all');
    this.checkPreviousUrl = this.route.snapshot.paramMap.get('previousUrl')
      ? this.route.snapshot.paramMap.get('previousUrl')
      : 'no-value';
    if (this.checkPreviousUrl.includes('content')) {
      this.dashboardUrl = true;
    }
    if (this.checkPreviousUrl.includes('homepage')) {
      this.homepage = true;
    }
    if (this.checkPreviousUrl.includes('draft-content')) {
      this.saveAsDraft = true;
      this.showButtons = true;
      this.deleteForDraft = true;
    }

    this.kpiSelectionParam = this.route.snapshot.queryParamMap.get(
      'kpiSelection'
    );

    this.setMessages();
    this.id = this.route.snapshot.paramMap.get('id');
    this.options = {
      gridType: GridType.VerticalFixed,
      displayGrid: DisplayGrid.Always,
      compactType: CompactType.CompactUp,
      swap: true,
      pushItems: true,
      // gridSizeChangedCallback: ProductStepFiveFormComponent.gridSizeChanged,
      // push: true,
      draggable: {
        delayStart: 0,
        enabled: false,
        // start: ProductStepFiveFormComponent.startedDragging,
        // stop: ProductStepFiveFormComponent.stoppedDragging
      },
      resizable: {
        handles: {
          n: true,
          e: true,
          w: true,
          ne: true,
          nw: true,
          s: true,
          se: true,
          sw: true,
        },
        enabled: false,
        // start: ProductStepFiveFormComponent.startedResizing,
        // stop: ProductStepFiveFormComponent.stoppedResizing
      },

      pushing: true,
      sparse: false,
      defaultSizeX: 2, // the default width of a gridster item, if not specifed
      defaultSizeY: 1, // the default height of a gridster item, if not specified
      columns: 2, // the width of the grid, in columns
      // colWidth: '92.5', // can be an integer or 'auto'.  'auto' uses the pixel width of the element divided by 'columns'
      fixedRowHeight: 80.5, // can be an integer or 'match'.  Match uses the colWidth, giving you square widgets.
      margins: [10, 10], // the pixel distance between each widget
      minCols: 2,
      maxCols: 2,
      minRows: 1,
      maxRows: 100000,
      maxItemCols: 100,
      minItemCols: 1,
      maxItemRows: 100,
      minItemRows: 1,
      maxItemArea: 250,
      minItemArea: 1,
      defaultItemCols: 1,
      defaultItemRows: 3,
      // itemChangeCallback: ProductStepFiveFormComponent.itemChange,
      // itemResizeCallback: ProductStepFiveFormComponent.itemResize,
      gridSizeChangedCallback: ProductDetailsComponent.gridSizeChanged,
    };
    this.loadUser();
    if (this.router.url.includes('guide')) {
      // console.log('guide.......!!!');
      this.guidePage = true;
      this.getGuideProductDetails();
    } else {
      this.getProductDetails();

    }
    this.listenForLanguageChange();
    this.setTourMessages();
    this.observer = new MutationObserver((dom) => {
      // console.log('dom', dom)
      if (document.getElementsByClassName('PD-OPTIONS').length) {
        // console.log('document.getElementById(\'HSD-1\')', document.getElementsByClassName('HSD-1')[0])
        // console.log('document.getElementById(\'HSD-1\')', document.getElementsByClassName('HSD-1')[0].parentElement.parentElement);
        const tourblock = document.getElementsByClassName('PD-OPTIONS')[0].parentElement.parentElement;
        tourblock.style.top = '-11px';
        tourblock.style.left = null;
      }
      if (document.getElementsByClassName('PD-1').length) {
        // console.log('document.getElementById(\'HSD-1\')', document.getElementsByClassName('HSD-1')[0])
        // console.log('document.getElementById(\'HSD-1\')', document.getElementsByClassName('HSD-1')[0].parentElement.parentElement);
        const tourblock = document.getElementsByClassName('PD-1')[0].parentElement.parentElement;
        tourblock.style.top = '-20px';
        // tourblock.style.left = '5px';
        tourblock.style.left = null;

      }
      if (document.getElementsByClassName('PD-OTHER').length) {
        // console.log('document.getElementById(\'HSD-2\')', document.getElementsByClassName('HSD-2')[0])
        // console.log('document.getElementById(\'HSD-2\')', document.getElementsByClassName('HSD-2')[0].parentElement.parentElement);
        const tourblock = document.getElementsByClassName('PD-OTHER')[0].parentElement.parentElement;
        tourblock.style.top = null;
        tourblock.style.left = null;
      }
    });
    this.utilityService.startTour.subscribe(res => {
      if (res) {
        if (this.router.url.toString().includes('/library/product-details')) { this.startTour(); }
        // if(this.guidePage){
        //   this.startTour();
        // }

      }
    });
    this.addSelectAll();
  }

  loadUser() {
    this.authService.currentUser$.subscribe((user) => {
      this.currentUser = user;
      // console.log('user', user);
      if (this.isLogin && user) {
        this.getProductDetails();
      }
      this.closeLoginDialog();
    });
  }

  listenForLanguageChange() {
    this.languageChangeSubscription = this.translate.onLangChange.subscribe((event) => {
      // console.log('lang', event);
      this.selectedLanguage = event.lang;
      this.selectedTabLanguage = event.lang;
      if (this.productType === 'private' && this.productLangs.includes(event.lang)) { this.getProductDetails(); }
      this.setMessages();
      // if (this.productType === 'public') {
      const index = this.kpiCategory.languages.findIndex(
        (item) => item.language === event.lang
      );
      // console.log('index', index);
      if (index !== -1) {
        this.dashboardLanguageIndex = index;
      }
      // }
      // console.log('this.dashboardLanguageIndex', this.dashboardLanguageIndex);
      this.setTourMessages();
    });
  }

  getProductDetails() {
    this.generalService.getProductDetails(this.id, this.saveAsDraft).subscribe(res => {
      // console.log('res', res);
      // this.product = res.value;
      this.productInfo = res.value; // productObject;
      const tempProduct = res.value;
      this.setDetails();
    }, error => {
      // console.log(error);

      if (error.status === 404) {
        this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.ProductNotFound', 'ERROR');
        if (this.dashboardUrl) {
          window.history.back();
        } else {
          this.router.navigateByUrl('/library/dashboard');
        }
      } else {
        throw error;
      }
    }
    );
  }
  getGuideProductDetails() {
    this.generalService.getGuideProductDetails().subscribe(res => {
      // console.log('res', res);
      // this.product = res.value;
      this.productInfo = res.value; // productObject;
      const tempProduct = res.value;
      this.setDetails();
    }, error => {
      // console.log(error);

      if (error.status === 404) {
        this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.ProductNotFound', 'ERROR');
        if (this.dashboardUrl) {
          window.history.back();
        } else {
          this.router.navigateByUrl('/library/dashboard');
        }
      } else {
        throw error;
      }
    }
    );
  }
  setDetails() {

    // this.productInfo=this.catDetails;
    this.productInfo.productDetailsList.forEach((element, langIndex) => {
      element.productCategoryList.forEach((cat, catIndex) => {
        cat.sectionList.forEach((sec, secIndex) => {
          sec.widgetList = sec.widgetList.filter(item => item.widgetType !== 'vizLink');
        });
      });
    });
    this.isGuide = this.productInfo.isGuide;
    this.saveAsDraft = this.productInfo.saveAsDraft;
    // console.log('this.product', this.productInfo);
    this.kpiCategory.languages.forEach((element: any) => {
      const index = this.productInfo.productDetailsList.findIndex(
        (item) => item.language === element.language
      );
      // console.log('index', index);
      // console.log('element', element);
      if (element && index !== -1) {
        element.productName = this.productInfo.productDetailsList[
          index
        ].productName;
        element.description = this.productInfo.productDetailsList[
          index
        ].description;
        element.productCategoryList = this.productInfo.productDetailsList[
          index
        ].productCategoryList;
      }
    });
    // console.log('this.product', this.product);
    this.productType = this.productInfo.productType;
    // console.log('this.productType', this.productType)

    if (this.productType === 'public') {
      this.frCompleted = true;
      this.nlCompleted = true;
      this.enCompleted = true;
      this.productLangs = ['fr', 'nl', 'en'];
    }
    this.productInfo.productDetailsList.forEach((details) => {
      if (details.productCategoryList.length) {
        this.productInfo[details.language.toLowerCase() + 'Completed'] = true;
      }
    });
    if (this.productInfo.saveAsDraft) {
      this.productInfo.productDetailsList.forEach((details) => {
        if (details.productName) {
          this.productInfo[details.language.toLowerCase() + 'Completed'] = true;
        }
      });
    }
    if (this.productType === 'private') {
      // console.log('this.productInfo', this.productInfo)
      if (this.productInfo.frCompleted) {
        // this.selectedTabLanguage = 'fr';
        this.frCompleted = true;
        this.productLangs.push('fr');
      }
      if (this.productInfo.nlCompleted) {
        // this.selectedTabLanguage = 'nl';
        this.nlCompleted = true;
        this.productLangs.push('nl');
      }
      if (this.productInfo.enCompleted) {
        // this.selectedTabLanguage = 'en';
        this.enCompleted = true;
        this.productLangs.push('en');
      }
      this.productLangs = Array.from(new Set(this.productLangs));
      // console.log('this.productLangs', this.productLangs);
      // console.log('this.selectedTabLanguage', this.selectedTabLanguage);
    }
    // this.setUpWidgets();
    this.dashboardLanguageIndex = this.kpiCategory.languages.findIndex(
      (item) => item.language === this.selectedTabLanguage
    );
    this.dashboardLanguageIndex = this.dashboard.languages.findIndex(
      (item) => item.language === this.selectedTabLanguage
    );
    // console.log('this.kpiCategoryInput', this.kpiCategoryInput);
    // this.kpiCategory = JSON.parse(JSON.stringify(this.kpiCategoryInput));
    if (!this.kpiSelectionParam) {
      this.kpiCategory.languages.forEach((element,k) => {
        // const index = this.product.productDetailsList.findIndex(item => item.language === element.language)
        // element.productCategoryList = this.product.productDetailsList[index].productCategoryList;
        element.productCategoryList.forEach((item, i) => {
          if (item.sectionList.length >= 3) {
            if (i === 0) {
              const sectionObject = {
                'sectionTitle': this.translate.instant('Select all'),
                'checked': true
              }
              item.sectionList.unshift(sectionObject);
            }
            else {
              const sectionObject = {
                'sectionTitle': this.translate.instant('Select all'),
                'checked': false
              }
              item.sectionList.unshift(sectionObject);
            }
          }
          // console.log('item', item);
          if (i === 0) {
            item.open = false;
          } else {
            item.open = true;
          }
          item.sectionList.forEach((item2, j) => {
            if (i === 0) {
              item2.checked = true;
              this.sectionsToShow.push(i + '' + j);
              if(this.kpiCategory.languages[k].productCategoryList[i].sectionList[j].sectionTitle==this.translate.instant('Select all')){
                this.sectionsToShow = this.sectionsToShow.filter(
                  (section) => section !== i + '' +j
                );
              }
            } else {
              item2.checked = false;
            }
            
          });
        });
      });
    }
   
    if (this.kpiSelectionParam) {
      // console.log('this.kpiSelectionParam', this.kpiSelectionParam);
      this.sectionsToShow = this.kpiSelectionParam.split(',');
      if (this.productInfo.productType === 'public') {
        this.sectionsToShow.forEach((sectionElement) => {
          // console.log('sectionElement', sectionElement[0]);
          // console.log('sectionElement', sectionElement[1]);
          this.kpiCategory.languages.forEach((element) => {
            element.productCategoryList.forEach((cat, i) => {
              if (i.toString() === sectionElement[0]) {
                cat.open = false;
              }
              cat.sectionList.forEach((sec, j) => {
                if (
                  i.toString() === sectionElement[0] &&
                  j.toString() === sectionElement[1]
                ) {
                  sec.checked = true;
                }
              });
            });
          });
        });
      }

      if (this.productInfo.productType === 'private') {
        const index = this.kpiCategory.languages.findIndex(
          (item) => item.language === this.selectedTabLanguage
        );
        this.sectionsToShow.forEach((sectionElement) => {
          // console.log('sectionElement', sectionElement[0]);
          // console.log('sectionElement', sectionElement[1]);

          const element = this.kpiCategory.languages[index];
          element.productCategoryList.forEach((cat, i) => {
            if (
              i.toString() === sectionElement[0] &&
              i.toString() === sectionElement[0]
            ) {
              cat.open = false;
            }
            cat.sectionList.forEach((sec, j) => {
              if (
                i.toString() === sectionElement[0] &&
                j.toString() === sectionElement[1]
              ) {
                sec.checked = true;
              }
            });
          });
        });
      }
    }

    // console.log('this.kpiCategory', this.kpiCategory);
    this.sectionsToShow = Array.from(new Set(this.sectionsToShow));
    // console.log('this.sectionsToShow', this.sectionsToShow);

    // this.dashboard = JSON.parse(JSON.stringify(this.product));
    // this.addSelectAll();
    this.kpiSelectionChanged();
    // this.makeItFav()
    console.log("KPI Cateogory",this.kpiCategory);
  }

  addSelectAll(){
    this.sectionsToShow.forEach((item, i) => {
      if(item =='00'){
        this.sectionsToShow.splice(item,1);
        this.sectionsToShow.push('0' + this.sectionsToShow.length)
      } 
    });

    this.sectionsToShow.length
    this.kpiCategory.languages.forEach((element: any) => {
      element.productCategoryList.forEach((element1, i) => {
        if (element1.sectionList.length >= 3) {
          if (i === 0) {
            const sectionObject = {
              'sectionTitle': this.translate.instant('Select all'),
              'checked': true
            }
            element1.sectionList.unshift(sectionObject);
          }
          else {
            const sectionObject = {
              'sectionTitle': this.translate.instant('Select all'),
              'checked': false
            }
            element1.sectionList.unshift(sectionObject);
            
          }
        }
      });
    });
  }
  // ngAfterViewInit() {
  // document.getElementById('gridster-preview-content').style.height = this.productHeight + 'px';
  // document.getElementById('kpi-selection').style.height = this.productHeight + 'px';
  // }

  switchLanguageTab(lang) {
    if (this.productType === 'private') {
      return;
    }
    this.selectedTabLanguage = lang;
    // this.setUpWidgets();
    this.dashboardLanguageIndex = this.dashboard.languages.findIndex(
      (item) => item.language === this.selectedTabLanguage
    );
  }

  checkboxChange(e, categoryIndex, sectionIndex) {
    //this.categoryIndexPos = categoryIndex;
    this.leftPanelSelected = true;
    if (this.productType === 'public') {
      [0, 1, 2].forEach((index) => {
        if (this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList[sectionIndex].sectionTitle == this.translate.instant('Select all')) {
          this.flag = true;
          this.kpiCategory.languages[index].productCategoryList[
            categoryIndex].sectionList.forEach(element => {
              element.checked = e.target.checked;
            });
          
          // let allUnchecked = this.kpiCategory.languages[index].productCategoryList[
          //   categoryIndex
          // ].sectionList.every(res => res.checked == false);

          // this.kpiCategory.languages[index].productCategoryList[
          //   categoryIndex
          // ].sectionList[0].allUnchecked = allUnchecked;

          // this.kpiCategory.languages[index].productCategoryList.every((res, catIndex)=>{
          //   if(res.sectionList[0].allUnchecked == false){
          //     return this.categoryIndexPos = catIndex;
          //   }
          // })
        }
        else {
          this.flag = false;
          this.kpiCategory.languages[index].productCategoryList[
            categoryIndex
          ].sectionList[sectionIndex].checked = e.target.checked;

          // let allUnchecked = this.kpiCategory.languages[index].productCategoryList[
          //   categoryIndex
          // ].sectionList.every(res => res.checked == false);

          // this.kpiCategory.languages[index].productCategoryList[
          //   categoryIndex
          // ].sectionList[0].allUnchecked = allUnchecked;

          // this.kpiCategory.languages[index].productCategoryList.every((res, catIndex) => {
          //   if (res.sectionList[0].allUnchecked == false) {
          //     return this.categoryIndexPos = catIndex;
          //   }
          // })
        }
      });
    }
    if (this.productType === 'private') {
      const index = this.kpiCategory.languages.findIndex(
        (item) => item.productCategoryList.length
      );
      [0, 1, 2].forEach((index) => { 
      if (this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList[sectionIndex].sectionTitle == this.translate.instant('Select all')) {
        this.flag = true;
        this.kpiCategory.languages[index].productCategoryList[
          categoryIndex].sectionList.forEach(element => {
            element.checked = e.target.checked;
          });
      }
      else {
        this.flag = false;
        this.kpiCategory.languages[index].productCategoryList[
          categoryIndex
        ].sectionList[sectionIndex].checked = e.target.checked;
      }
    });
    }
    if (e.target.checked) {
      const prevLength = this.sectionsToShow.length;
      if (this.flag === true) {
        [0, 1, 2].forEach((index) => {
          this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList.forEach((element, j) => {

            if (this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList[j].sectionTitle == this.translate.instant('Select all')) {
              this.sectionsToShow.push(categoryIndex + '' + j);
              this.sectionsToShow = this.sectionsToShow.filter(
                (section) => section !== categoryIndex + '' + '0'
              );
            }
            else {
              this.sectionsToShow.push(categoryIndex + '' + j);
            }
          });
        }); 
      }
      else {
        this.sectionsToShow.push(categoryIndex + '' + sectionIndex);
        this.checkedFlag = false;
        [0, 1, 2].forEach((index) => {
          this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList.forEach((element, j) => {

            if (element.sectionTitle !== this.translate.instant('Select all')) {
              element.checked !== true ? this.checkedFlag = true : false;
            }
          });
          
          if (this.checkedFlag == true) {
            this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList[0].sectionTitle == 'Select all' ?
              this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList[0].checked = false : false;
          }
          else  this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList[0].sectionTitle == 'Select all' ?
          this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList[0].checked = true : false;
        });
      }
      // this.addSectionToView(categoryIndex, sectionIndex)
      if (this.sectionsToShow.length > 2) {
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.ScrollDown',
          'INFORMATION'
        );
      }
      // [0, 1, 2].forEach((index) => {
      //   this.kpiCategory.languages[index].productCategoryList.forEach((element, j) => {
      //     this.sectionsToShow = this.sectionsToShow.filter(
      //       (section) => section !== j + '' + '0'
      //     );
      //   });
      // });
    } else {
      [0, 1, 2].forEach((index) => {
        this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList.forEach((element, j) => {
          this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList[0].sectionTitle == 'Select all'?
          this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList[0].checked =false : false;         
          if (this.kpiCategory.languages[index].productCategoryList[categoryIndex].sectionList[sectionIndex].sectionTitle == this.translate.instant('Select all')) {
            this.sectionsToShow = this.sectionsToShow.filter(
              (section) => section !== categoryIndex + '' + j
            );
          }
          else {
            this.sectionsToShow = this.sectionsToShow.filter(
              (section) => section !== categoryIndex + '' + sectionIndex
            );
          }
        });
      });
      // this.removeSectionFromView(categoryIndex, sectionIndex);
    }
    this.sectionsToShow = _.uniqBy(this.sectionsToShow, Number);
    this.kpiSelectionChanged();
  }

  kpiSelectionChanged() {
    // this.kpiCategory
    // console.log('this.sectionsToShow', this.sectionsToShow);
    this.dashboard.languages.forEach((lang) => {
      lang.gridItems = [];
    });
    // console.log('this.kpiCategory', this.kpiCategory);
    const newKpiCategory = {
      languages: [
        {
          language: 'fr',
          productName: '',
          description: '',
          productCategoryList: [],
        },
        {
          language: 'nl',
          productName: '',
          description: '',
          productCategoryList: [],
        },
        {
          language: 'en',
          productName: '',
          description: '',
          productCategoryList: [],
        },
      ],
    };
    this.sectionsToShow.sort();
    if (this.sectionsToShow.length) {
      ['fr', 'nl', 'en'].forEach((lang) => {
        const index = newKpiCategory.languages.findIndex(
          (item) => item.language === lang
        );
        const index2 = this.kpiCategory.languages.findIndex(
          (item) => item.language === lang
        );
        const newCategories: any = [];
        let categoryIndices = [];
        this.sectionsToShow.forEach((location) => {
          categoryIndices.push(location[0]);
        });
        categoryIndices = Array.from(new Set(categoryIndices));
        categoryIndices.forEach((location) => {
          // console.log('location', location);

          newKpiCategory.languages[index].description = JSON.parse(
            JSON.stringify(this.kpiCategory.languages[index2].description)
          );
          newKpiCategory.languages[index].productName = JSON.parse(
            JSON.stringify(this.kpiCategory.languages[index2].productName)
          );
          newKpiCategory.languages[index].productCategoryList = JSON.parse(
            JSON.stringify(
              this.kpiCategory.languages[index2].productCategoryList
            )
          );
          for (
            let catIndex = 0;
            catIndex <
            newKpiCategory.languages[index].productCategoryList.length;
            catIndex++
          ) {
            if (catIndex === parseInt(location, 10)) {
              newKpiCategory.languages[index].productCategoryList[
                parseInt(location, 10)
              ].categoryIndex = parseInt(location, 10);
              newKpiCategory.languages[index].productCategoryList[
                parseInt(location, 10)
              ].sectionList = [];
              newCategories.push(
                newKpiCategory.languages[index].productCategoryList[
                parseInt(location, 10)
                ]
              );
              break;
            }
          }
          // console.log('newCategories', newCategories);
          // newCategories = _.uniqBy(newCategories, 'id');
          newKpiCategory.languages[index].productCategoryList = newCategories;
        });
        // console.log('newKpiCategory', newKpiCategory);

        // adding selceted sections to selected categories

        newKpiCategory.languages[index].productCategoryList.forEach((newCat, newCatIndex2) => {
          const newSections = [];
          // console.log('this.sectionsToShow', this.sectionsToShow);
          let catergoriesWise = this.sectionsToShow.filter(res => res[0] == newCat.categoryIndex);
          catergoriesWise.forEach((loc, secIndex) => {
            const newCatIndex =
              newKpiCategory.languages[index].productCategoryList.findIndex(item => item.categoryIndex === parseInt(loc[0], 10));
            const oldCatIndex = newKpiCategory.languages[index].productCategoryList[newCatIndex].categoryIndex;
            // console.log(newCat.categoryIndex + ' === ' + parseInt(loc[0], 10), newCat.categoryIndex === parseInt(loc[0], 10));
            if (newCat.categoryIndex === parseInt(loc[0], 10)) {
              if(this.leftPanelSelected == false){
                if (this.kpiCategory.languages[index2].productCategoryList[oldCatIndex].sectionList.length >= 3){
                  newSections.push(this.kpiCategory.languages[index2].productCategoryList[oldCatIndex].sectionList[secIndex + 1]);
                  newKpiCategory.languages[index].productCategoryList[newCatIndex].sectionList = newSections;
                } else {
                  newSections.push(this.kpiCategory.languages[index2].productCategoryList[oldCatIndex].sectionList[secIndex]);
                  newKpiCategory.languages[index].productCategoryList[newCatIndex].sectionList = newSections;
                }
              } else {
                let checked = this.kpiCategory.languages[index2].productCategoryList[oldCatIndex].sectionList.filter(res => res.checked == true);
                if(checked[0].sectionTitle == this.translate.instant('Select all')){
                  newSections.push(checked[secIndex+1]);
                  newKpiCategory.languages[index].productCategoryList[newCatIndex].sectionList = newSections;
                } else {
                  newSections.push(checked[secIndex]);
                  newKpiCategory.languages[index].productCategoryList[newCatIndex].sectionList = newSections;
                }
                // newSections.push(this.kpiCategory.languages[index2].productCategoryList[oldCatIndex].sectionList[parseInt(loc[1], 10)]);
                // newKpiCategory.languages[index].productCategoryList[newCatIndex].sectionList = newSections;
              }
            }
          });
        });
      });
    } else {
      this.dashboard = {
        languages: [
          { language: 'fr', gridItems: [] },
          { language: 'nl', gridItems: [] },
          { language: 'en', gridItems: [] },
        ],
      }; // JSON.parse(JSON.stringify(this.product));
    }
    // console.log('newKpiCategory', newKpiCategory);
    this.modifyWidgetsSteup(newKpiCategory);
    // console.log('newKpiCategory', newKpiCategory);
    // console.log('this.dashboard', this.dashboard);
    // this.dashboard.languages.forEach(element => {
    //   element.gridItems.forEach((element2, index) => {
    //     if (element2.type == 'vizLink') {
    //       element.gridItems.splice(index, 1);
    //     }
    //   })
    // })
  }

  toggleCategoryDropDown(index) {
    this.kpiCategory.languages.forEach((element) => {
      if (element) {
        if (element.productCategoryList.length) {
          element.productCategoryList[index].open = !element.productCategoryList[
            index
          ].open;
        }
      }
    });
  }

  obj;
  setUpWidgets() {
    // const updatedDashIndex = this.dashboard.languages.findIndex(item => item.language === this.selectedTabLanguage);
    // console.log('this.kpiCategory', this.kpiCategory);
    this.kpiCategory.languages.forEach((element) => {
      // if (element.language === this.selectedTabLanguage) {
      const dashIndex = this.dashboard.languages.findIndex(
        (item) => item.language === element.language
      );
      for (let i = 0; i < element.productCategoryList.length; i++) {
        const category = element.productCategoryList[i];
        const secData = {
          x: 0,
          y: 0,
          cols: 2,
          rows: 1,
          type: 'title',
          data: category.categoryName,
          gridElementId: i,
          hi: i+1
        };
        this.dashboard.languages[dashIndex].gridItems.push(secData);
        for (let j = 0; j < category.sectionList.length; j++) {
          const section = category.sectionList[j];
          for (let k = 0; k < section.widgetList.length; k++) {
            const widget = section.widgetList[k];
            this.obj=widget;
            const data = {
              x: widget.widgetPositionX,
              y: widget.widgetPositionY,
              cols: widget.widgetSizeCols,
              rows: widget.widgetSizeCols<2 && widget.widgetType=='title'?2:widget.widgetSizeRows,
              type: widget.widgetType,
              data: widget.widgetUrl,
              vizUrl: (widget.vizUrl && widget.vizUrl !== 'embed 1') ? widget.vizUrl : '',
              gridElementId: i + '' + j + '' + k
            };
            this.dashboard.languages[dashIndex].gridItems.push(data);
            
          }
        }
      }
      // }
    });
    this.product = { ...this.dashboard };
    // console.log('this.dashboard', this.dashboard);
  }

  obj1=[];
  modifyWidgetsSteup(kpiCategory) {
    // const updatedDashIndex = this.dashboard.languages.findIndex(item => item.language === this.selectedTabLanguage);
    // console.log('this.kpiCategory', kpiCategory);
    //let transformObj = [];
    // kpiCategory.languages.forEach((element) => {
     
    // })

    kpiCategory.languages.forEach((element) => {
      // console.log('element', element);
      // if (element.language === this.selectedTabLanguage) {
      /* Beginning -  For updating widgetPosition Y value */  
        // element.productCategoryList.forEach(cat => {
        //   cat.sectionList.forEach(sec => {
        //     sec.widgetList.forEach(wid => {
        //       transformObj.push(wid);
        //     })
        //   })
        // })

        // transformObj.forEach((element, index) => {
        //   if (index == 0) {
        //     element.widgetPositionY = 0;
        //   } else {
        //     element.widgetPositionY = (transformObj[index - 1].widgetPositionY) + (transformObj[index - 1].widgetSizeRows);
        //   }
        // })
        // console.log("transform", transformObj);
      /* End -  For updating widgetPosition Y value */

      const dashIndex = this.dashboard.languages.findIndex(
        (item) => item.language === element.language
      );

      // console.log('this.dashboard.languages[dashIndex]', this.dashboard.languages[dashIndex]);
      for (let i = 0; i < element.productCategoryList.length; i++) {
        const category = element.productCategoryList[i];
        const secData = {
          x: 0,
          y: 0,
          cols:2,
          rows: 1,
          type: 'title',
          data: category.categoryName,
          gridElementId: i,
          hi: i+1
        };
        // this.dashboard.languages[dashIndex].gridItems.push(secData);
        for (let j = 0; j < category.sectionList.length; j++) {
          const section = category.sectionList[j];
          for (let k = 0; k < section.widgetList.length; k++) {
            const widget = section.widgetList[k];
            const data = {
              x: widget.widgetPositionX,
              y: widget.widgetPositionY,
              cols: widget.widgetSizeCols,
              rows: widget.widgetSizeRows,
              // rows: widget.widgetType=='title'?widget.widgetSizeRows+1:widget.widgetSizeRows,
              type: widget.widgetType,
              data: widget.widgetUrl,
              vizUrl: (widget.vizUrl && widget.vizUrl !== 'embed 1') ? widget.vizUrl : '',
              gridElementId: category.categoryIndex + '' + j + '' + k,
              firstSection: j == 0 && k == 0 ? true : false
            };
            this.dashboard.languages[dashIndex].gridItems.push(data);
          }
          // console.log('this.dashboard.languages[dashIndex]', this.dashboard.languages[dashIndex]);
          this.dashboard.languages[dashIndex].gridItems = _.uniqBy(
            this.dashboard.languages[dashIndex].gridItems,
            'gridElementId'
          );
        }
      }
      // }
      this.obj1 = [];
      // for (let i = 1; i < this.dashboard.languages[dashIndex].gridItems.length; i++) {
      //   const widget1 = this.dashboard.languages[dashIndex].gridItems[i];
      //   const widget2 = this.dashboard.languages[dashIndex].gridItems[i-1]
      //   widget1.y=widget2.y + widget2.rows;
      // }
    });
    console.log('dashboard', this.dashboard);
    console.log('KPI Category', this.kpiCategory);
    this.dashboard.languages.forEach((element) => {
      element.gridItems = _.uniqBy(element.gridItems, 'gridElementId');
    });
    this.product = { ...this.dashboard };
    // console.log('this.dashboard', this.dashboard);
    // console.log('this.selectedLanguage', this.selectedLanguage);
    // this.dashboardLanguageIndex = this.dashboard.languages.findIndex(item => item.language === this.selectedLanguage);
    // console.log('dashboardLanguageIndex', this.dashboardLanguageIndex);
    if (this.productType === 'private') {
      this.privateDashboard = JSON.parse(JSON.stringify(this.dashboard));
      this.getChartsUrl();
    }
    // if (document.getElementsByClassName('isCat').length>0) {
    //   for (let i = 0; i < document.getElementsByClassName('isCat').length; i++){
    //     let element: HTMLElement = <HTMLElement>document.getElementsByClassName('isCat')[i];
    //     element.insertAdjacentHTML('afterend', "<div style='position:relative; height:2rem; width:100%'></div>");
    //   }
    // }
  }

  validateNumber(widget1, array) {
    for (let i = 1; i <= array.length; i++) {
      for (let j = 0; j < i - 1; j++) {
        if (widget1.y <= array[j].y) {
          widget1.y = array[j].y + 2;
        }
      }
    }
  }

  kpiLeftMenuResized() {
    if (this.kpiSelectionCollapsed) {
      document
        .getElementById('col-kpi')
        .classList.remove('col-md-2', 'col-sm-2');
      document
        .getElementById('col-kpi')
        .classList.add('col-md-1', 'col-sm-1', 'pr-0');
      document
        .getElementById('col-product')
        .classList.remove('col-md-10', 'col-sm-10');
      document
        .getElementById('col-product')
        .classList.add('col-md-11', 'col-sm-11');
      document.getElementById('product-body').classList.add('make-center');
    } else {
      document
        .getElementById('col-kpi')
        .classList.remove('col-md-1', 'col-sm-1', 'pr-0');
      document.getElementById('col-kpi').classList.add('col-md-2', 'col-sm-2');
      document
        .getElementById('col-product')
        .classList.remove('col-md-11', 'col-sm-11');
      document
        .getElementById('col-product')
        .classList.add('col-md-10', 'col-sm-10');
      document.getElementById('product-body').classList.remove('make-center');
    }
    window.dispatchEvent(new Event('resize'));
  }
  
  selectAllSections() {
    this.kpiCategory.languages.forEach(lang => {
      const index = this.kpiCategory.languages.findIndex(item => item.language === lang.language);
      if (index !== -1) {
        if (this.kpiCategory.languages[
          index
        ].productCategoryList.length) {
          this.kpiCategory.languages[
            index
          ].productCategoryList.forEach((cat, i) => {
            cat.open = false;
            if (cat.sectionList.length) {
              cat.sectionList.forEach((sec, j) => {
                sec.checked = true;
                this.sectionsToShow.push(i + '' + j);
                if(this.kpiCategory.languages[index].productCategoryList[i].sectionList[j].sectionTitle==this.translate.instant('Select all')){
                  this.sectionsToShow = this.sectionsToShow.filter(
                    (section) => section !== i + '' +j
                  );
                }
              });
            }
            
          });
        }
      }
    });
    this.sectionsToShow=_.uniqBy(this.sectionsToShow,Number);
    this.sectionsToShow = Array.from(new Set(this.sectionsToShow));
    this.kpiSelectionChanged();
    this.utilityService.showTranslatedNotificationMessage(
      'NotificationMessages.Product.ScrollDown',
      'INFORMATION'
    );
    // console.log('this.sectionsToShow', this.sectionsToShow);
  }

  resetSections() {
    this.sectionsToShow = [];
    this.kpiCategory.languages.forEach(lang => {
      const index = this.kpiCategory.languages.findIndex(item => item.language === lang.language);
      if (index !== -1) {
        if (this.kpiCategory.languages[index].productCategoryList.length) {
          this.kpiCategory.languages[index].productCategoryList.forEach((cat, i) => {
            cat.open = true;
            if (cat.sectionList.length) {
              cat.sectionList.forEach((sec, j) => {
                sec.checked = false;
              });
            }
          });
        }
      }
    });
    this.sectionsToShow = Array.from(new Set(this.sectionsToShow));
    this.kpiSelectionChanged();
  }

  download(template) {
    // const canvas = document.createElement('canvas');
    // const body = document.getElementsByTagName('body')[0] a;
    // canvas.width = body.offsetWidth;
    // canvas.height = body.offsetHeight;
    // canvas.getContext('2d').drawImage(body, 0, 0);
    // const dataUrl = canvas.toDataURL('image/png');

    // const hrefElement = document.createElement('a');
    // hrefElement.href = dataUrl;
    // document.body.appendChild(hrefElement);
    // hrefElement.download = 'somename.png';
    // hrefElement.click();
    // hrefElement.remove();
    // window["html2canvas"] = html2canvas;
    // const doc: any = new jsPDF();
    // console.log('document.body', document.body)
    // // doc.fromHTML(document.body, 10, 10, { width: 180 });
    // doc.html(document.body, {
    //   callback: (docu) => {
    //     docu.save();
    //   }
    // });
    // doc.output('datauri');
    // console.log('doc', doc);
    // doc.save('sample-file.pdf');

    // const svgElements = document.body.querySelectorAll('svg');
    // svgElements.forEach(function (item: any) {
    //   item.setAttribute("width", item.getBoundingClientRect().width);
    //   item.style.width = null;
    // });

    // html2canvas(document.getElementsByTagName('body')[0], {
    //   useCORS: true,
    //   imageTimeout: 0,
    //   allowTaint: true,
    //   scrollY: - window.scrollY
    // }).then(function (canvas) {
    //   const img = canvas.toDataURL('image/png');
    //   console.log('img', img);
    //   const doc = new jsPDF('p', 'mm', 'a4');

    //   const width = doc.internal.pageSize.getWidth();
    //   console.log('width', width)
    //   const height = doc.internal.pageSize.getHeight();
    //   console.log('height', height)
    //   doc.addImage(img, 'JPEG', 0, 0, width, height);
    //   doc.save('testCanvas.pdf');
    // });

    // const element = document.getElementsByTagName('body')[0];
    // console.log('element', element)
    // html2pdf(element);

    // FireShotAPI.AutoInstall = true;

    // FireShotAPI.savePage(true);

    // domtoimage.toBlob(document.getElementsByTagName('body')[0])
    //   .then(function (blob) {
    //     // window.saveAs(blob, 'my-node.png');
    //     const link = document.createElement('a');
    //     link.download = 'my-image-name.jpeg';
    //     link.href = blob;
    //     link.click();
    //   });

    // browser.takeScreenshot().then(function (png) {
    //   console.log('png', png)
    // create stream for writing the image
    // const stream = createWriteStream("exception.png");
    // // write the stream to local file
    // stream.write(new Buffer(png, 'base64'));
    // // close the stream
    // stream.end();
    // });
    this.openModal(template);
  }
  goProductEdit() {
    this.router.navigate(['/library/product-edit', this.productInfo.productId]);
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {
      animated: true,
      backdrop: 'static',
      keyboard: false,
      class: 'custom-width',
    });
  }

  closeModal(event) {
    this.modalRef.hide();
    if (this.loginModalRef) { this.loginModalRef.hide(); }
    // console.log('this.currentUser', this.currentUser);
    if (event) {
      // window.location.reload()
      this.isLogin = event;
    }
    if (this.currentUser) {
      // console.log('assadadadadaevent', event);
      this.closeLoginDialog();
    }
  }
  deleteProduct() {
    this.genericConfirm.show({
      headlineText: this.deleteProductTitle,
      notConfirmText: 'NOTEXT',
      text: this.deleteProductText,
      confirmText: 'YESTEXT',
      callback: (result: any) => {
        // console.log('result', result);
        if (result) {
          this.generalService
            .deleteProduct(this.id, this.saveAsDraft)
            .subscribe((res) => {
              // console.log(res);
              this.utilityService.showTranslatedNotificationMessage(
                'NotificationMessages.Product.DeleteSuccess',
                'SUCCESS'
              );
              if (this.productType === 'public') {
                if ( this.dashboardUrl || this.homepage) {
                    window.history.back();
                } else {
                  // tslint:disable-next-line: no-unused-expression
                  // this.router.navigate[('/library/dashboard')];
                  window.location.href = '/#!/library/dashboard';
                }
              }
              if (this.productType === 'private') {
                // this.router.navigateByUrl('/user/dashboard/private-product');
                if ( this.dashboardUrl || this.homepage) {
                  window.history.back();
              } else {
                // tslint:disable-next-line: no-unused-expression
                window.location.href = '/#!/library/dashboard';
              }              }
            });
        } else {
          // console.log('do not delete user');
        }
      },
    });
  }

  setMessages() {
    switch (this.selectedLanguage) {
      case 'en':
        this.deleteProductTitle = 'Delete report';
        if (this.deleteForDraft) {
          // tslint:disable-next-line: max-line-length
          this.deleteProductText =
            'Careful, you are about to delete both the draft and the product on the platform. Do you wish to continue?';
        } else {
          this.deleteProductText =
            'Are you sure you want to delete this product?';
        }
        break;
      case 'fr':
        this.deleteProductTitle = 'Supprimer rapport';
        if (this.deleteForDraft) {
          // tslint:disable-next-line: max-line-length
          this.deleteProductText =
            'Attention, vous allez supprimer le rapport ainsi que son brouillon. Voulez-vous continuer?';
        } else {
          this.deleteProductText =
            'Êtes-vous sûr de vouloir supprimer ce rapport ?';
        }
        break;
      case 'nl':
        this.deleteProductTitle = 'Verwijderen rapport';
        if (this.deleteForDraft) {
          // tslint:disable-next-line: max-line-length
          this.deleteProductText =
            'Let op, u staat op het punt om zowel het concept als het rapport op het platform te verwijderen. Wilt u doorgaan?';
        } else {
          this.deleteProductText =
            'Weet u zeker dat u dit rapport wilt verwijderen?';
        }
        break;
    }
  }

  markAsFavourite(template) {
    if (this.currentUser) {
      let isFavourite = false;
      if (
        this.productInfo.favouriteUsersList &&
        !this.productInfo.favouriteUsersList.includes(this.currentUser.id)
      ) {
        isFavourite = true;
      }
      this.generalService
        .markProductFavourite(this.id, isFavourite)
        .subscribe((res) => {
          // this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product')
          // console.log(res);
          const index = this.productInfo.favouriteUsersList.findIndex(
            (item) => item === this.currentUser.id
          );
          if (isFavourite) {
            this.productInfo.favouriteUsersList.push(this.currentUser.id);
            if (document.getElementById('heart')) {
              document.getElementById('heart').classList.remove('fa-heart-o');
              document.getElementById('heart').classList.add('fa-heart');
            }
          } else {
            if (document.getElementById('heart')) { document.getElementById('heart').classList.remove('fa-heart'); }
            if (index !== -1) {
              this.productInfo.favouriteUsersList.splice(index, 1);
            }
            if (document.getElementById('heart')) { document.getElementById('heart').classList.add('fa-heart-o'); }
          }
        });
    } else {
      this.openLoginDialog(template);
    }
  }

  openLoginDialog(template: TemplateRef<any>) {
    this.loginModalRef = this.modalService.show(template, {
      animated: true,
      backdrop: 'static',
      keyboard: false,
      class: 'addFavModal',
    });
  }

  closeLoginDialog() {
    if (this.loginModalRef) {
      this.loginModalRef.hide();
    }
  }

  openInviteModal(invitePeople: TemplateRef<any>) {
    // console.log('invitePeople', invitePeople);
    this.invitePeopleModalRef = this.modalService2.show(invitePeople, {
      animated: true,
      backdrop: 'static',
      keyboard: true,
      class: 'custom-modal-invite',
    });
  }

  closeInvitePeopleModal(event) {
    this.invitePeopleModalRef.hide();
  }

  openShareLinkDialog(shareLinkModal) {

    // console.log(this.sectionsToShow);
    this.link = window.location.href.split('?')[0];
    this.link2 =
      window.location.href.split('?')[0] +
      '?kpiSelection=' +
      this.sectionsToShow.join();
    // this.copyToClipboard(true)
    if (this.currentUser && (this.currentUser.role.toLowerCase() === 'admin' || this.currentUser.role.toLowerCase() === 'champion')) {
      this.shareLinkModalRef = this.modalService2.show(shareLinkModal, {
        animated: true,
        backdrop: 'static',
        keyboard: true,
        // class: 'custom-modal-invite'
      });
    // tslint:disable-next-line: max-line-length
    } else if ((this.currentUser && (this.currentUser.role.toLowerCase() !== 'admin' && this.currentUser.role.toLowerCase() !== 'champion')) ||
    !this.currentUser) {
      let copyWithKpiSelection = false;
      // const sections = this.sectionsToShow.split(',');
      this.sectionsToShow.forEach(element => {
        if (parseInt(element[0], 10) > 0) {
          copyWithKpiSelection = true;
        }
      });

      this.copyToClipboard(copyWithKpiSelection);
    }
  }

  closeShareLinkDialog() {
    if (this.shareLinkModalRef) { this.shareLinkModalRef.hide(); }
  }

  copyToClipboard(copyWithKpiSelection) {
    let link = this.link;
    if (copyWithKpiSelection) {
      link = this.link2;
    }
    // console.log('link', link);
    const dummy = document.createElement('textarea');
    // to avoid breaking orgain page when copying more words
    // cant copy when adding below this code
    // dummy.style.display = 'none'
    document.body.appendChild(dummy);
    // Be careful if you use texarea. setAttribute('value', value), which works with "input" does not work with "textarea". – Eduard
    dummy.value = link;
    dummy.select();
    document.execCommand('copy');
    document.body.removeChild(dummy);
    // console.log('link', link);
    this.closeShareLinkDialog();
    this.utilityService.showTranslatedNotificationMessage(
      'NotificationMessages.Product.LinkCopied',
      'INFORMATION'
    );
  }

  getChartsUrl() {
    // console.log('this.privateDashboard', this.privateDashboard);
    const index = this.privateDashboard.languages.findIndex(
      (item) => item.language === this.selectedLanguage
    );
    const data = [];

    this.privateDashboard.languages[index].gridItems.forEach((element) => {
      if (element.type === 'chart') {
        element.data = '/views/' + element.data.split('/views/').pop();
        data.push(element.data);
      }
    });
    // console.log('data', data);
    this.generalService.getChartsUrl({ urlList: data }).subscribe((res) => {
      // console.log('res', res);
      const urlList = res.value.urlList;
      // console.log('urlList', urlList);

      this.privateDashboard.languages[index].gridItems.forEach((element) => {
        if (element.type === 'chart') {
          if (element.data.includes('https') || element.data.includes('http')) {
            element.data = '/views/' + element.data.split('/views/').pop();
          }
          const urlIndex = urlList.findIndex(
            (item) => '/views/' + item.split('/views/').pop() === element.data
          );
          if (urlIndex !== -1) {
            // console.log(
            //   'compare',
            //   '/views/' +
            //   urlList[urlIndex].split('/views/').pop() +
            //   '===' +
            //   element.data
            // );
            element.data = urlList[urlIndex];
          }
        }
      });
      // console.log(
      //   'this.privateDashboard.languages[index].gridItems',
      //   this.privateDashboard.languages[index].gridItems
      // );
      this.dashboard = _.cloneDeep(this.privateDashboard); // JSON.parse(JSON.stringify(this.privateDashboard))
      // console.log('this.selectedLanguage', this.selectedLanguage);
      // this.dashboardLanguageIndex = this.dashboard.languages.findIndex(item => item.language === this.selectedLanguage);
      // this.updatedDashboard = { ...this.dashboard };
    });
  }

  openVizUrl(link) {
    window.open(link + '?productId=' + this.id + '&language=' + this.selectedLanguage, '_target');
  }
  ngAfterViewChecked(){
    if (document.getElementsByClassName('isCat').length > 0) {
      document.querySelectorAll('.hasPos').forEach(e => e.remove());
      for (let i = 0; i < document.getElementsByClassName('isCat').length; i++) {
        if (document.querySelectorAll('.has_'+i).length == 0) {
          let element: HTMLElement = <HTMLElement>document.getElementsByClassName('isCat')[i];
          element.insertAdjacentHTML('afterend', "<div class='hasPos has_"+i+"' style='position:relative; height:2.5rem; width:100%'></div>");
        }
      }
    }
  }
  
  ngAfterViewInit() {
    if (this.cdRef && !(this.cdRef as ViewRef).destroyed) {
      this.cdRef.detectChanges();
    }
    // this.startTour();
    this.loaderService.isLoading.subscribe(v => {
      if (!v) {
        this.makeItFav();
        if (this.currentUser) {
          // console.log('this.loggedInUser.role', this.currentUser.role)
          if (this.currentUser.role !== 'admin' && this.currentUser.role !== 'champion') {
            if (this.currentUser.tutorialProduct) {
              const data = {
                tutorialDashboard: this.currentUser.tutorialDashboard,
                tutorialLibrary: this.currentUser.tutorialLibrary,
                tutorialProduct: false
              };
              if (this.tutorialCalled) {
                const queryParams = {
                  loader: true
                };
                this.tutorialCalled = false;
                this.generalService.updateTutorialFlags(data, queryParams).subscribe(res => {
                  this.currentUser.tutorialProduct = false;
                  this.authService.updateCurrentUser(this.currentUser);
                });
              }
              this.startTour();
            }
          }
        } else {
          this.setCookieForProductTutorial();
        }
      }
    });
  }
  startTour() {
    // console.log('Starting the tour for product');
    this.observer.observe(document.getElementsByTagName('ngx-guided-tour')[0], { subtree: true, characterData: true, childList: true });
    const tourSteps: TourStep[] = [
      {
        selector: '.product-step-one',
        content: `<p class="PD-1">
        ${this.messageObject.ProductTutorialText.Step1}
        <p>
        <p>${this.messageObject.ProductTutorialText.Step2}</p>`,
        orientation: Orientation.Right,
        skipStep: false,
        scrollAdjustment: -1000
      },
      // {
      //   selector: '.product-step-two',
      //   content: `<p class="PD-OTHER">${this.messageObject.ProductTutorialText.Step2}</p>`,
      //   orientation: Orientation.Bottom,
      //   skipStep: false,
      // },
      {
        selector: '.product-step-three',
        content: `<p class="PD-OPTIONS">${this.messageObject.ProductTutorialText.Step3}</p>`,
        orientation: Orientation.Left,
        skipStep: false,
        // scrollAdjustment: 1000
      },
      {
        selector: '.product-step-four',
        content: `<p class="PD-OPTIONS">${this.messageObject.ProductTutorialText.Step4}</p>`,
        orientation: Orientation.Left,
        skipStep: false,

        // scrollAdjustment: -5000
      },
      {
        selector: '.product-step-five',
        content: `<p class="PD-OPTIONS">${this.messageObject.ProductTutorialText.Step5}</p>`,
        orientation: Orientation.Left,
        skipStep: false,
      },
      {
        // selector: '.product-step-six',
        // tslint:disable-next-line: max-line-length
        content: `<p class="PD-OTHER">${this.messageObject.ProductTutorialText.Step6Part1} <span class="step-viz-icon"><i class="fa fa-share-alt" ></i></span>
                      ${this.messageObject.ProductTutorialText.Step6Part2}
                  </p>
        `,
        orientation: Orientation.Center,
        skipStep: false,
        // scrollAdjustment: 300
      },
      {
        // selector: '.product-step-seven',
        // tslint:disable-next-line: max-line-length
        content: `<p class="PD-OTHER">${this.messageObject.ProductTutorialText.Step7Part1} <span class="step-viz-icon"><i class="fa fa-download" ></i></span>
                     ${this.messageObject.ProductTutorialText.Step7Part2}
                  </p>`,
        orientation: Orientation.Center,
        skipStep: false,
      },
      {
        // selector: '.product-step-seven',
        // tslint:disable-next-line: max-line-length
        content: `<p class="PD-OTHER">${this.messageObject.ProductTutorialText.Step8Part1} <span class="step-viz-icon"><i class="fa fa-link" ></i></span>
                     ${this.messageObject.ProductTutorialText.Step8Part2}
                  </p>`,
        orientation: Orientation.Center,
        skipStep: false,
      }

    ];
    this.guidedTour = {
      tourId: 'product-details',
      useOrb: false,
      steps: tourSteps,
      skipCallback: () => {
        this.observer.disconnect();
        this.utilityService.startTour.next(false);
      },
      completeCallback: () => {
        this.observer.disconnect();
        this.utilityService.startTour.next(false);
      },
      preventBackdropFromAdvancing: true,
    };
    // console.log('starting tour');
    this.guidedTourService2.startTour(this.guidedTour);
    if (this.cdRef && !(this.cdRef as ViewRef).destroyed) {
      this.cdRef.detectChanges();
      this.cdRef.detectChanges();
    }
  }

  setTourMessages() {
    if (this.selectedLanguage === 'en') {
      this.messageObject = {
        ProductTutorialText: {
          Step1: 'Activate the sections that you want to feature in your report.',
          // tslint:disable-next-line: max-line-length
          Step2: 'Each section displays specific information and sometimes sections can interact with each other. Follow the instructions for each report or see our detailed demo <a href="/#!/guide/product">here</a>.',
          Step3: 'Share the link of this report with someone of your choice.',
          Step4: 'Download the report via an add-on that will save a printscreen into a pdf.',
          Step5: 'Save the report and access it on your dashboard once you are logged in.',
          Step6Part1: 'If you see this icon ',
          Step6Part2: ' in a frame, then you can generate an embed code to embed this vizualisation anywhere you want.',
          Step7Part1: 'If you see this icon ',
          Step7Part2: ' in a frame, then you can download this vizualisation in .png, .ppt, .pdf, and/or .xlsx format.',
          Step8Part1: 'If you see this icon ',
          Step8Part2: ' in a frame, then you can visit the vizualisation page in new tab.'
        }
      };
    }
    if (this.selectedLanguage === 'nl') {
      this.messageObject = {
        ProductTutorialText: {
          Step1: 'Activeer de secties die u in uw rapport wilt zien.',
          // tslint:disable-next-line: max-line-length
          Step2: 'Elke sectie beeldt specifieke informatie af en soms kunnen secties met elkaar interacteren. Volg de instructies per rapport of bekijk onze gedetailleerde demo <a href="/#!/guide/product">hier.</a>',
          Step3: 'Deel de link van dit rapport met iemand.',
          Step4: 'Download het rapport met behulp van een add-on, die een printscreen opslaat in een pdf-bestand.',
          Step5: 'Sla het rapport op en vind het terug op uw eigen dashboard wanneer u ingelogd bent.',
          Step6Part1: 'Als dit icoon ',
          Step6Part2: ' zit in een kader, dan kunt u een code genereren waarmee u de visualisatie kunt integreren waar u wil.',
          Step7Part1: 'Als dit icoon ',
          Step7Part2: ' zit in een kader, dan kunt u deze visualisatie downloaden in .png, .ppt, .pdf, en/of .xlsx formaat.',
          Step8Part1: 'Als dit icoon ',
          Step8Part2: ' zit in een kader, dan kunt u opent de visualisatie in een nieuw tabblad.'
        }
      };
    }
    if (this.selectedLanguage === 'fr') {
      this.messageObject = {
        ProductTutorialText: {
          Step1: 'Activez les sections que vous désirez voir apparaitre.',
          // tslint:disable-next-line: max-line-length
          Step2: 'Chaque section affiche une information spécifique et dans certains cas, elles peuvent intéragir entre elles. Suivez les instructions pour chaque rapport ou regardez notre démo <a href="/#!/guide/product">ici.</a>',
          Step3: 'Partagez le lien de ce rapport avec la personne de votre choix.',
          // tslint:disable-next-line: max-line-length
          Step4: 'Téléchargez le rapport dans son ensemble grâce à un module d\'extension qui capturera l\'entiereté de votre écran sous format pdf. ',
          Step5: 'Sauvegardez le rapport et retrouvez le sur votre tableau de bord personnel lorsque vous êtes connectés.',
          Step6Part1: 'Si cet icône ',
          Step6Part2: ' est dans un encadré, vous générerez un code afin d\'intégrer la visualisation où vous le voulez.',
          Step7Part1: 'Si cet icône ',
          Step7Part2: ' est dans un encadré, vous pourrez télécharger la visualisation en format .png, .ppt, .pdf et/ou .xlsx',
          Step8Part1: 'Si cet icône ',
          Step8Part2: 'est dans un encadré, vous pourrez accéder à la page de la visualisation dans un nouvel onglet.'
        }
      };
    }
  }
  setCookieForProductTutorial() {
    if (!Cookie.get('product_page_visited')) {
      this.startTour();
      Cookie.set('product_page_visited',
        'yes',
        new Date(new Date().setFullYear(new Date().getFullYear() + 10)),
        '/',
        Cookie.get('_host'));

    }
  }
  makeItFav() {
    if (
      this.currentUser &&
      this.productInfo &&
      this.productInfo.favouriteUsersList &&
      this.productInfo.favouriteUsersList.length &&
      this.productInfo.favouriteUsersList.includes(this.currentUser.id)
    ) {
      // console.log(document.getElementById('heart'));

      if (document.getElementById('heart')) {
        // console.log('yess yess yess yess done');
        document.getElementById('heart').classList.remove('fa-heart-o');
        document.getElementById('heart').classList.add('fa-heart');
      }
    } else {
      if (document.getElementById('heart')) {
        // console.log('yess yess yess yess done');
        document.getElementById('heart').classList.add('fa-heart-o');
        document.getElementById('heart').classList.remove('fa-heart');
      }
    }
  }
  // tslint:disable-next-line: use-lifecycle-interface
  ngOnDestroy() {

    if (this.languageChangeSubscription) {
      this.languageChangeSubscription.unsubscribe();
    }
  }
  ngOnChanges() {
    // this.cdRef.detectChanges();
    document.getElementsByTagName('body')[0].style.overflow = 'hidden';
    // console.log('this.product', this.product)
    this.productType = this.productInfo.productType;
    
    // console.log('this.kpiCategoryInput', this.kpiCategoryInput)
    this.kpiCategory = _.cloneDeep(this.kpiCategoryInput); // JSON.parse(JSON.stringify(this.kpiCategoryInput));
    // this.kpiCategory = JSON.parse(JSON.stringify(this.dataSharingService.backupKpiCategory));
    this.kpiCategory.languages.forEach(element => {
      // const index = this.product.productDetailsList.findIndex(item => item.language === element.language)
      // element.productCategoryList = this.product.productDetailsList[index].productCategoryList;
      element.productCategoryList.forEach((item, i) => {
        // console.log('item', item, i)
        if (i === 0) { item.open = false; } else { item.open = true; }
        item.sectionList.forEach((item2, j) => {
          if (i === 0) {
            item2.checked = true;
            this.sectionsToShow.push(i + '' + j);
          } else { item2.checked = false; }
        });
      });
    });
    this.dashboardLanguageIndex = this.kpiCategory.languages.findIndex(item => item.language === this.selectedTabLanguage);
    this.sectionsToShow = Array.from(new Set(this.sectionsToShow));
    // tslint:disable-next-line: max-line-length
    // console.log('JSON.parse(lz.decompress(localStorage.getItem(\'backupDashboard\')))', JSON.parse(lz.decompress(localStorage.getItem('backupDashboard'))))
    // console.log('this.productType', this.productType)
    // tslint:disable-next-line: max-line-length
    // console.log('JSON.parse(JSON.stringify(this.dataSharingService.backupDashboard))', JSON.parse(JSON.stringify(this.dataSharingService.backupDashboard)))
    
    // this.cdRef.detectChanges();
    this.kpiSelectionChanged();
  }
}


