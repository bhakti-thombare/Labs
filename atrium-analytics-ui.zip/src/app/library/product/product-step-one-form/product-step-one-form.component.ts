import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
@Component({
  selector: 'ab-product-step-one-form',
  templateUrl: './product-step-one-form.component.html',
  styleUrls: ['./product-step-one-form.component.scss']
})
export class ProductStepOneFormComponent implements OnInit {

  selectedType: any;
  /**
   * 0: not selected
   * 1: public selected
   * 2: private selected
   */
  tabState = 0;
  nlCompleted: any;
  frCompleted: any;
  enCompleted: any;
  @Output() nextStep: EventEmitter<any> = new EventEmitter<any>();
  constructor(private notificationService: NotificationService,
              private utilityService: UtilityService) { }

  ngOnInit() {
  }

  selectType(value) {
    this.selectedType = value;
    if (value === 'private') {
      this.tabState = 2;
    } else {
      this.tabState = 1;
    }
  }
  submit() {
    if (this.selectedType) { this.nextStep.emit({ type: this.selectedType }); } else {
      // this.notificationService.showError('PRODUCTCREATION.SelectTableauType');
      this.utilityService.showTranslatedNotificationMessage(
        'PRODUCTCREATION.ProductType',
        'ERROR'
      );
    }
  }

}
