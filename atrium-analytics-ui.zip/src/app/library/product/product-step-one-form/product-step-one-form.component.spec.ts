import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductStepOneFormComponent } from './product-step-one-form.component';

describe('ProductStepOneFormComponent', () => {
  let component: ProductStepOneFormComponent;
  let fixture: ComponentFixture<ProductStepOneFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductStepOneFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductStepOneFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
