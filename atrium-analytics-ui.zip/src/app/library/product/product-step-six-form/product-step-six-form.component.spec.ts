import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductStepSixFormComponent } from './product-step-six-form.component';

describe('ProductStepSixFormComponent', () => {
  let component: ProductStepSixFormComponent;
  let fixture: ComponentFixture<ProductStepSixFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductStepSixFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductStepSixFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
