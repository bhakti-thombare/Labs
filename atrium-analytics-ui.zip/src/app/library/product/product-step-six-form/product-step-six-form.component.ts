import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';

@Component({
  selector: 'ab-product-step-six-form',
  templateUrl: './product-step-six-form.component.html',
  styleUrls: ['./product-step-six-form.component.scss']
})
export class ProductStepSixFormComponent implements OnInit, OnChanges {
  @Input() isEdit: any;
  @Input() product: any;
  @Output() nextStep: EventEmitter<any> = new EventEmitter<any>();
  qualityChecks = [
    { backendKey: 'completeTitle', key: 'CompleteTitle', text: 'Complete title', checked: false },
    { backendKey: 'completeLegend', key: 'CompleteLegend', text: 'Complete legend', checked: false },
    { backendKey: 'filtersConfigured', key: 'FiltersConfigured', text: 'Filters configured', checked: false },
    { backendKey: 'appropriateFonts', key: 'AppropriateFonts', text: 'Appropriate font(s) (type & color)', checked: false },
    { backendKey: 'appropriateColors', key: 'AppropriateColors', text: 'Appropriate color(s) of graphs and maps', checked: false },
    { backendKey: 'actions', key: 'Actions', text: 'Action(s) (isolate, etc.) configured', checked: false },
    { backendKey: 'hubmapInserted', key: 'HubMap', text: 'Hub-map inserted', checked: false },
    { backendKey: 'mapFunctionsConfigured', key: 'Tooltip', text: 'Tooltip(s) configured', checked: false },
    { backendKey: 'tooltipsConfigured', key: 'Translation', text: 'Translation in 3 languages', checked: false },
    { backendKey: 'translationIn3Languages', key: 'MapFunction', text: 'Map functions configured', checked: false },
  ];
  outters: any[];
  productLive = false;
  DisplayOnHomePage = false;
  isAllQualityMarksChecked: boolean;
  productLiveOption: boolean;
  DisplayOnHomePageOption: boolean;
  enbleToggle: boolean;
  constructor(private utilityService: UtilityService, private notificationService: NotificationService) { }

  ngOnInit() {
    this.buildCheckboxTable();
  }

  ngOnChanges() {
    if (this.product) {
      // console.log('this.product', this.product)
      // this.qualityChecks.forEach(element => {
      //   element.checked = this.product[element.backendKey];
      // });
      this.productLive = this.product.productLive;
      this.DisplayOnHomePage = this.product.homePage;

    }
  }

  buildCheckboxTable() {
    const outterArray = [];
    let innerArray = [];
    let n;
    const qualityChecksTemp = JSON.parse(JSON.stringify(this.qualityChecks));

    while (n !== 0) {
      n = Math.ceil(qualityChecksTemp.length / 3);
      if (n !== 1) {
        innerArray = qualityChecksTemp.slice(0, 3);
        outterArray.push(innerArray);
        qualityChecksTemp.splice(0, 3);
        innerArray = [];
      } else {
        innerArray = qualityChecksTemp.slice(0, qualityChecksTemp.length);
        outterArray.push(innerArray);
        n = 0;
      }
    }
    this.outters = outterArray;
    // console.log(outterArray);
  }

  onCheckedQuality(event, key) {
    for (const element of this.qualityChecks) {
      if (element.key === key) {
        element.checked = event.target.checked;
        break;
      }
    }
    this.validateQualityMarks();
    // console.log('this.qualityChecks', this.qualityChecks);
  }

  submit(value) {
    let allCheck = true;
    this.qualityChecks.forEach(property => {
      this.product[property.backendKey] = property.checked;
    });
    if (value === 'publish') {
      for (const element of this.qualityChecks) {
        if (!element.checked) {
          // this.notificationService.showError('Please select all quality checks');
          this.utilityService.showTranslatedNotificationMessage(
            'NotificationMessages.Product.QualityChecksText', 'ERROR');
          allCheck = false;
          break;
        }
      }
      if (!allCheck) {
        return;
      }
      this.product.publish = true;
    }
    if (value === 'draft') {
      this.product.saveAsDraft = true;
    }

    if (this.isEdit && value === 'publish') {
      this.product.saveAsDraft = false;
    }

    this.product.productLive = this.productLive;
    this.product.homePage = this.DisplayOnHomePage;
    this.nextStep.emit({ product: this.product, type: value });
  }

  toggleChange(event, value) {
    if (value === 'productLive') {
      this.productLive = event.target.checked;
    }
    if (value === 'DisplayOnHomePage') {
      this.DisplayOnHomePage = event.target.checked;
    }

  }

  validateQualityMarks() {
    for (const element of this.qualityChecks) {
      if (element.checked) {
        this.isAllQualityMarksChecked = true;
      } else {
        this.isAllQualityMarksChecked = false;
        break;
      }
    }
    if (this.isAllQualityMarksChecked) {
      this.enbleToggle = true;
    } else {
      this.enbleToggle = false;
    }
    if (this.isEdit) {
      if (this.isAllQualityMarksChecked) {
        if (this.productLive) {
          this.productLiveOption = true;
        } else {
          this.productLiveOption = false;
        }
        this.DisplayOnHomePageOption = false;
      } else {
        this.productLiveOption = true;
        this.DisplayOnHomePageOption = true;

      }
    }
    if (!this.isEdit) {
      if (!this.isAllQualityMarksChecked) {
        this.productLiveOption = false;
        this.DisplayOnHomePageOption = false;
        this.productLive = false;
        this.DisplayOnHomePage = false;
      }
    }
  }


}
