import { Component, OnInit, Input, OnChanges, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import * as _ from 'lodash';
import { UtilityService } from 'src/app/core/services/utility.service';
@Component({
  selector: 'ab-select-chart-form',
  templateUrl: './select-chart-form.component.html',
  styleUrls: ['./select-chart-form.component.scss']
})
export class SelectChartFormComponent implements OnInit, OnChanges {
  @Input() charts;
  @Input() selectSingleChart;
  @Input() alreadySelectedCharts: any;
  @Output() closeEvent: EventEmitter<any> = new EventEmitter<any>();
  @Output() gotCharts: EventEmitter<any> = new EventEmitter<any>();
  selectedCharts: any[] = [];
  submitted = false;
  constructor(private cdRef: ChangeDetectorRef, private utilityService: UtilityService) { }

  ngOnInit() {
  }
  ngOnChanges() {
    if (this.charts) {
      // console.log('this.charts', this.charts)
      this.charts.projects.forEach(project => {
        project.open = true;
        project.workbooks.forEach(workbook => {
          workbook.checked = false;
          workbook.alreadySelected = false;
          workbook.views.forEach(view => {
            view.checked = false;
            view.alreadySelected = false;
          });
        });
      });
      if (this.alreadySelectedCharts && this.alreadySelectedCharts.length) {
        // console.log('this.alreadySelectedCharts', this.alreadySelectedCharts)
        this.selectedCharts = this.alreadySelectedCharts;
        this.disableAlreadySelected();
      }
      if (this.selectSingleChart) {
        this.charts.projects.forEach(project => {
          project.open = true;
          project.workbooks.forEach(workbook => {
            workbook.checked = false;
            workbook.alreadySelected = true;
          });
        });
      }
      if (this.selectSingleChart && !this.submitted) {
        this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.SelectSingleChart', 'INFORMATION');
      }
      this.setChartValues();
    }
  }

  closeModal() {
    this.closeEvent.emit(true);
  }

  toggleCategoryDropDown(index) {
    // console.log('index', index)
    this.charts.projects[index].open = !this.charts.projects[index].open;
  }
  allSelected(event, projectIndex, workbookIndex) {
    if (event.target.checked) {
      this.charts.projects[projectIndex].workbooks[workbookIndex].checked = true;
      this.selectedCharts = this.selectedCharts.concat(this.charts.projects[projectIndex].workbooks[workbookIndex].views);
      this.charts.projects[projectIndex].workbooks[workbookIndex].views.forEach(view => {
        view.checked = true;
      });
    } else {
      this.charts.projects[projectIndex].workbooks[workbookIndex].checked = false;
      const removeViews = this.charts.projects[projectIndex].workbooks[workbookIndex].views;
      removeViews.forEach(view => {
        const index = this.selectedCharts.findIndex(item => item.id === view.id);
        if (index !== -1) {
          this.selectedCharts.splice(index, 1);
        }
      });
      this.charts.projects[projectIndex].workbooks[workbookIndex].views.forEach(view => {
        view.checked = false;
      });
    }
    this.selectedCharts = _.uniqBy(this.selectedCharts, 'id');
    // console.log('this.selectedCharts', this.selectedCharts)
  }
  chartSelected(event, projectIndex, workbookIndex, viewIndex) {
    let allViewSelected = false;
    if (event.target.checked) {
      this.charts.projects[projectIndex].workbooks[workbookIndex].views[viewIndex].checked = true;
      // this.charts.projects[projectIndex].workbooks[workbookIndex].views[viewIndex].alreadySelected = true;
      this.selectedCharts.push(this.charts.projects[projectIndex].workbooks[workbookIndex].views[viewIndex]);
    } else {
      this.charts.projects[projectIndex].workbooks[workbookIndex].views[viewIndex].checked = false;
      // this.charts.projects[projectIndex].workbooks[workbookIndex].views[viewIndex].alreadySelected = false;
      const removeView = this.charts.projects[projectIndex].workbooks[workbookIndex].views[viewIndex];
      const index = this.selectedCharts.findIndex(item => item.id === removeView.id);
      if (index !== -1) { this.selectedCharts.splice(index, 1); }
    }
    for (const view of this.charts.projects[projectIndex].workbooks[workbookIndex].views) {
      // console.log('view', view)
      if (view.checked === true) {
        allViewSelected = true;
      } else {
        allViewSelected = false;
        break;
      }
    }
    if (allViewSelected) {
      this.charts.projects[projectIndex].workbooks[workbookIndex].checked = true;
      // this.charts.projects[projectIndex].workbooks[workbookIndex].alreadySelected = true;
    } else {
      this.charts.projects[projectIndex].workbooks[workbookIndex].checked = false;
      // this.charts.projects[projectIndex].workbooks[workbookIndex].alreadySelected = false;
    }
    this.selectedCharts = _.uniqBy(this.selectedCharts, 'id');
    // console.log('this.selectedCharts', this.selectedCharts)
  }

  submit() {
    this.submitted = true;
    this.closeModal();
    if (this.selectedCharts.length) {
      this.selectedCharts = _.uniqBy(this.selectedCharts, 'id');
      this.gotCharts.emit(this.selectedCharts);
    }
  }

  disableAlreadySelected() {
    // tslint:disable-next-line: one-variable-per-declaration // tslint:disable-next-line: prefer-const
    let allViewSelected, projectIndex, workbookIndex;
    this.charts.projects.forEach(project => {
      project.workbooks.forEach(workbook => {
        workbook.alreadySelected = false;
        workbook.views.forEach(view => {
          view.alreadySelected = false;
          if (this.alreadySelectedCharts.some(e => e.id === view.id)) {
            // console.log('_.includes(this.alreadySelectedCharts, view.id)', _.includes(this.alreadySelectedCharts, view.id))
            view.alreadySelected = true;
          }
        });
      });
    });
    let breakout = false;
    for (const project of this.charts.projects) {
      for (const workbook of project.workbooks) {

        for (const view of workbook.views) {
          if (view.alreadySelected === true) {
            allViewSelected = true;
          } else {
            allViewSelected = false;
            breakout = true;
            break;
          }
        }
        // console.log('allViewSelected', allViewSelected)
        if (allViewSelected) {
          // console.log('work is already selected')
          workbook.alreadySelected = true;
        }
        if (this.selectSingleChart) {
          workbook.alreadySelected = true;
        }
        // if (breakout) {
        //   break;
        // }
      }
      // if (breakout) {
      //   break;
      // }
    }

    // console.log('this.charts.projects', this.charts.projects)

  }

  singleChartSelected(projectIndex, workbookIndex, viewIndex, event, url) {
    this.cdRef.detectChanges();
    const isSelected = event.target.checked;
    // console.log('isSelected', isSelected)
    // console.log('this.charts', this.charts)
    if (this.selectSingleChart) {
      if (isSelected) {
        this.charts.projects.forEach((project, pIndex) => {
          project.workbooks.forEach((workbook, wIndex) => {
            workbook.views.forEach((view, vIndex) => {
              // if (this.charts.projects[projectIndex].id !== this.charts.projects[pIndex].id) {
              //   console.log('this.charts.projects[pIndex].workbooks[wIndex]', this.charts.projects[pIndex].workbooks[wIndex].id)
              // tslint:disable-next-line: max-line-length
              //   if (this.charts.projects[projectIndex].workbooks[workbookIndex].id !== this.charts.projects[pIndex].workbooks[wIndex].id) {
              // tslint:disable-next-line: max-line-length
              //     if (this.charts.projects[projectIndex].workbooks[workbookIndex].views[viewIndex].id !== this.charts.projects[pIndex].workbooks[wIndex].views[vIndex].id) {
              //       if (!view.checked) {
              //         console.log('view', view)
              //         view.alreadySelected = true;
              //       }
              //     }
              //   }

              // }
              if (view.contentUrl !== url) {
                view.alreadySelected = true;
              }

            });
          });
        });

        // console.log('making all disable')
      } else {
        this.charts.projects.forEach((project, pIndex) => {
          project.workbooks.forEach((workbook, wIndex) => {
            workbook.views.forEach((view, vIndex) => {
              if (!view.checked) {
                if (view.contentUrl !== url) {
                  view.alreadySelected = false;
                }
              }

            });
          });
        });
      }
      this.cdRef.detectChanges();
      // console.log('this.charts.projects', this.charts.projects)
    }
  }

  setChartValues() {
    if (this.selectedCharts.length) {
      this.selectedCharts.forEach(chart => {
        this.charts.projects.forEach((project, i) => {
          project.workbooks.forEach((workbook, j) => {
            workbook.views.forEach((view, k) => {
              if (view.id === chart.id) {
                this.chartSelected({ target: { checked: true } }, i, j, k);
              }
            }); // views ends
          }); // workbook ends
        }); // project ends
      });
    }
  }
}
