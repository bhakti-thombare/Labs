import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectChartFormComponent } from './select-chart-form.component';

describe('SelectChartFormComponent', () => {
  let component: SelectChartFormComponent;
  let fixture: ComponentFixture<SelectChartFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectChartFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectChartFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
