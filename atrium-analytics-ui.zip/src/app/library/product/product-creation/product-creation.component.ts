import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { GeneralService } from '../../shared/general-service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { UtilityService } from 'src/app/core/services/utility.service';
import { ProductStepThreeFormComponent } from '../product-step-three-form/product-step-three-form.component';
import { ProductStepFourFormComponent } from '../product-step-four-form/product-step-four-form.component';
import { ProductStepSixFormComponent } from '../product-step-six-form/product-step-six-form.component';
import { ProductStepFiveFormComponent } from '../product-step-five-form/product-step-five-form.component';
import { NotificationService } from 'src/app/core/services/notification.service';
import { LeftMenuProductCreationComponent } from '../../left-menu-product-creation/left-menu-product-creation.component';

@Component({
  selector: 'ab-product-creation',
  templateUrl: './product-creation.component.html',
  styleUrls: ['./product-creation.component.scss'],
})
export class ProductCreationComponent implements OnInit {
  revertStepColor: any;
  stepOne = false;
  color;
  activeTwo = false;
  activeThree = false;
  activeFour = false;
  stepTwo = false;
  step2 = false;
  step3 = false;
  step5 = false;
  step6 = false;
  step4 = false;
  stepThree = false;
  stepFour = false;
  activeColor2 = 'black';
  activeColor3: 'black';
  activeColor4: 'black';
  received;
  stepValues = {
    stepOne: false,
    stepTwo: false,
    stepThree: false,
    stepFour: false,
    stepFive: false,
    stepSix: false,
    activeTwo: false,
    activeThree: false,
    activeFour: false,
    activeColor2: 'black',
    activeColor1: 'blue',
    activeColor3: 'black',
    activeColor4: 'black',
    activeColor5: 'black',
    activeColor6: 'black',
    activeColor7: 'black',
  };
  stepFive = false;
  stepSix = false;
  stepSeven = false;

  // product json
  product: any = {
    userId: 0,
    roleCode: '',
    languageCode: '',
    productId: null,
    productName: '',
    productType: '',
    image: {
      id: null,
      imageUrl: '',
      updateFlag: false
    },
    tagList: [],
    favouriteUsersList: null,
    invitedUsersList: null,
    saveAsDraft: false,
    productLive: false,
    homePage: false,
    publish: false,
    productDetailsList: [
      {
        language: 'en',
        productName: '',
        productDetailsId: null,
        description: '',
        additionalInfo: null,
        productCategoryList: []
      },
      {
        language: 'fr',
        productName: '',
        productDetailsId: null,
        description: '',
        additionalInfo: null,
        productCategoryList: []
      },
      {
        language: 'nl',
        productName: '',
        productDetailsId: null,
        description: '',
        additionalInfo: null,
        productCategoryList: []
      }
    ],
    deleted: false,
    completeTitle: false,
    completeLegend: false,
    filtersConfigured: false,
    appropriateFonts: false,
    appropriateColors: false,
    actions: false,
    hubmapInserted: false,
    mapFunctionsConfigured: false,
    tooltipsConfigured: false,
    translationIn3Languages: false
  };
  selectedCharts = [];
  allSelectedCharts: any = {
    frSelectedCharts: [],
    nlSelectedCharts: [],
    enSelectedCharts: []
  };
  id: any;
  isEdit = false;
  privateProductlanguages = [];
  isEditProduct = false;
  // all steps components
  @ViewChild(ProductStepThreeFormComponent, { static: false }) childStepThree: ProductStepThreeFormComponent;
  @ViewChild(ProductStepFourFormComponent, { static: false }) childStepFour: ProductStepFourFormComponent;
  @ViewChild(ProductStepFiveFormComponent, { static: false }) childStepFive: ProductStepFiveFormComponent;
  @ViewChild(ProductStepSixFormComponent, { static: false }) childStepSix: ProductStepSixFormComponent;
  @ViewChild(LeftMenuProductCreationComponent, { static: false }) leftMenuComponent: LeftMenuProductCreationComponent;
  productLeftMenu: any;


  constructor(
    private notificationService: NotificationService,
    private utilityService: UtilityService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private generalService: GeneralService) { }
  receivedEvent(event) {
    // console.log('event', event)
    // console.log(this.privateProductlanguages);
    if (this.checkProductValidity(event)) {
      this.stepOne = event.stepOne;
      this.stepTwo = event.stepThree;
      this.step2 = event.stepTwo;
      this.step4 = event.step4;
      this.step3 = event.step3;
      this.step5 = event.step5;
      this.stepThree = event.stepThree;
      this.step3 = event.step3;
      this.step6 = event.step6;
      this.stepFour = event.stepFour;
      this.stepFive = event.stepFive;
      this.stepSix = event.stepSix;
      this.stepSeven = event.stepSeven;

      if (event.step3) {
        // console.log('on step 3')
        this.revertStepColor = 3;
        this.leftMenuComponent.changeStepColor(3);

      }
      if (event.step4) {
        // console.log('on step 4')
        this.revertStepColor = 4;
        this.leftMenuComponent.changeStepColor(4);
      }
      if (event.step5) {
        // console.log('on step 5')
        this.revertStepColor = 5;
        this.leftMenuComponent.changeStepColor(5);
      }
      if (event.step6) {
        // console.log('on step 6')
        this.revertStepColor = 6;
        this.leftMenuComponent.changeStepColor(6);
      }
    } else {
      // console.log('event', event)

      this.leftMenuComponent.changeStepColor(false);
    }
  }

  ngOnInit() {
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    if (this.id) {
      this.isEdit = true;
      this.getProductDetails();
      // this.goStepThree({ type: 'private' });
    } else {
      this.goStepTwo();
    }

    // this.goStepFour({type:'nextStep'});
    // this.goStepFour(null);
    // this.goStepFive({ type: 'nextStep' });
    // this.goStepSix();
  }
  getProductDetails() {
    this.generalService.getProductDetails(this.id, true).subscribe(res => {
      // console.log('res', res);
      this.product = res.value;
      this.productLeftMenu = this.product;
      this.isEditProduct = true;
      this.product.productDetailsList.forEach(element => {
        element.productCategoryList.forEach(cat => {
          cat.sectionList.forEach(sec => {
            sec.widgetList.forEach((wid, widIndex) => {
              if (wid.widgetType === 'vizLink') {
                sec.widgetList.splice(widIndex, 1);
              }
            });
          });
        });
      });

      this.product.productDetailsList.forEach(element => {
        element.productCategoryList.forEach(cat => {
          cat.open = false;
          cat.sectionList.forEach(sec => {
            sec.openOtherOptions = false;
            sec.widgetList.forEach((wid, widIndex) => {
              if (wid.vizUrl === 'embed 1') {
                wid.vizUrl = '';
              }
              wid.fileName = wid.widgetData || 'file';
              if (wid.widgetType === 'chart') {
                wid.widgetUrl = '/views/' + wid.widgetUrl.split('/views/').pop();
                const data = {
                  contentUrl: wid.widgetUrl,
                  name: wid.widgetData
                };
                this.allSelectedCharts[element.language + 'SelectedCharts'].push(data);
                // console.log('this.allSelectedCharts', this.allSelectedCharts)
                // this.selectedCharts.push(data);
              }
            });
          });
        });
      });
      // console.log('this.allSelectedCharts', this.allSelectedCharts)
      // console.log('this.product', this.product)
      this.goStepThree({ type: this.product.productType });
      // this.goStepSix({type: this.product.productType,product :this.product});
      // this.goStepFive({ type: 'nextStep' });
    });
  }
  goStepTwo() {
    this.stepOne = true;
    this.activeTwo = true;
    this.color = 'blue';
    this.step2 = true;
    this.stepValues = {
      stepOne: this.stepOne,
      stepTwo: this.stepTwo,
      stepThree: this.stepThree,
      stepFour: this.stepFour,
      stepFive: this.stepFive,
      stepSix: this.stepSix,
      activeTwo: this.activeTwo,
      activeThree: this.activeThree,
      activeFour: this.activeFour,
      activeColor1: 'grey',
      activeColor2: 'blue',
      activeColor3: 'black',
      activeColor4: 'black',
      activeColor5: 'black',
      activeColor6: 'black',
      activeColor7: 'black',
    };
  }
  goStepThree(event) {
    this.activeThree = true;
    this.step3 = true;
    this.stepTwo = true;
    this.step2 = false;
    this.stepValues = {
      stepOne: this.stepOne,
      stepTwo: this.stepTwo,
      stepThree: this.stepThree,
      stepFour: this.stepFour,
      stepFive: this.stepFive,
      stepSix: this.stepSix,
      activeTwo: this.activeTwo,
      activeThree: this.activeThree,
      activeFour: this.activeFour,
      activeColor1: 'grey',
      activeColor2: 'grey',
      activeColor3: 'blue',
      activeColor4: 'black',
      activeColor5: 'black',
      activeColor6: 'black',
      activeColor7: 'black',
    };
    this.product.productType = event.type;
    // console.log('this.product', this.product)
  }
  goStepFour(data?) {
    if (data.type === 'nextStep') {
      // console.log('data', data)
      this.stepThree = true;
      this.step3 = false;
      this.step4 = true;
      this.activeFour = true;
      this.stepValues = {
        stepOne: this.stepOne,
        stepTwo: this.stepTwo,
        stepThree: this.stepThree,
        stepFour: this.stepFour,
        stepFive: this.stepFive,
        stepSix: this.stepSix,
        activeTwo: this.activeTwo,
        activeThree: this.activeThree,
        activeFour: this.activeFour,
        activeColor2: 'grey',
        activeColor3: 'grey',
        activeColor4: 'blue',
        activeColor1: 'grey',
        activeColor5: 'black',
        activeColor6: 'black',
        activeColor7: 'black',
      };
    }
    //
    if (data.product) {
      this.product.tagList = data.product.tagList;
      this.product.image = data.product.image;
      ['fr', 'nl', 'en'].forEach(lang => {
        const index1 = this.product.productDetailsList.findIndex(item => item.language === lang);
        const index2 = data.product.languages.findIndex(item => item.language === lang);
        if (index1 === -1 && index2 !== -1) {
          const basicData = {
            additionalInfo: null,
            description: data.product.languages[index2].description,
            language: data.product.languages[index2].language,
            productCategoryList: [],
            productDetailsId: null,
            productName: data.product.languages[index2].productName,
          };
          this.product.productDetailsList.push(basicData);
        }
        if (index1 !== -1 && index2 !== -1) {
          this.product.productDetailsList[index1].description = data.product.languages[index2].description;
          this.product.productDetailsList[index1].productName = data.product.languages[index2].productName;
        }
        if (this.product.productType === 'private') {
          this.product.frCompleted = data.product.frCompleted;
          this.product.nlCompleted = data.product.nlCompleted;
          this.product.enCompleted = data.product.enCompleted;
        }
      });
    }
    // console.log('this.product', this.product);
    if (data.type === 'draft') {
      // eliminating null value objects from private product
      if (this.product.productType === 'private') {
        if (this.product.image) {
          if (!this.product.image.imageUrl) {
            this.product.image = null;
          }
        }
        if (this.product.tagList === null) {
          this.product.tagList = [];
        }
        if (this.product.invitedUsersList === null) {
          this.product.invitedUsersList = [];
        }
        if (this.product.favouriteUsersList === null) {
          this.product.favouriteUsersList = [];
        }


        ['fr', 'nl', 'en'].forEach(lang => {
          const index = this.product.productDetailsList.findIndex(item => item.language === lang);
          if (index !== -1) {
            if (!this.product.productDetailsList[index].productName || this.product.productDetailsList[index].productName === '') {
              if (this.product.productDetailsList[index].productCategoryList.length === 0) {
                this.product.productDetailsList.splice(index, 1);
              }
            }
          }
        });
      }
      // console.log('this.product', this.product);
      // console.log('call post apis');
      this.product.saveAsDraft = true;
      if (!this.isEdit) {
        this.generalService.createProduct(this.product).subscribe(res => {
          // console.log('res', res);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.ProductDraftCreated', 'SUCCESS');
          window.location.href = '/#!/user/dashboard/draft-content';
        });
      } else {
        this.generalService.updateProduct(this.product).subscribe(res => {
          // console.log('res', res);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.ProductDraftUpdated', 'SUCCESS');
          window.location.href = '/#!/user/dashboard/draft-content';
        });
      }
      // this.router.navigate(['/user/dashboard/draft-content']);
    }
  }
  goStepFive(event?) {
    // console.log('this.product', this.product);
    if (event.type === 'nextStep') {
      this.step4 = false;
      this.step5 = true;
      this.stepFour = true;
      this.stepValues = {
        stepOne: this.stepOne,
        stepTwo: this.stepTwo,
        stepThree: this.stepThree,
        stepFour: this.stepFour,
        stepFive: this.stepFive,
        stepSix: this.stepSix,
        activeTwo: this.activeTwo,
        activeThree: this.activeThree,
        activeFour: this.activeFour,
        activeColor2: 'grey',
        activeColor3: 'grey',
        activeColor4: 'grey',
        activeColor1: 'grey',
        activeColor5: 'blue',
        activeColor6: 'black',
        activeColor7: 'black',
      };
    }
    if (event.product) {
      ['fr', 'nl', 'en'].forEach(lang => {
        const index1 = this.product.productDetailsList.findIndex(item => item.language === lang);
        const index2 = event.product.languages.findIndex(item => item.language === lang);
        if (index1 !== -1 && index2 !== -1) {
          this.product.productDetailsList[index1].productCategoryList = event.product.languages[index2].productCategoryList;
        }
      });
      this.allSelectedCharts = event.charts;
    }

    if (event.type === 'draft') {
      // eliminating null value objects from private product
      if (this.product.productType === 'private') {
        if (this.product.image) {
          if (!this.product.image.imageUrl) {
            this.product.image = null;
          }
        }
        if (this.product.tagList === null) {
          this.product.tagList = [];
        }
        if (this.product.invitedUsersList === null) {
          this.product.invitedUsersList = [];
        }
        if (this.product.favouriteUsersList === null) {
          this.product.favouriteUsersList = [];
        }


        ['fr', 'nl', 'en'].forEach(lang => {
          const index = this.product.productDetailsList.findIndex(item => item.language === lang);
          if (index !== -1) {
            if (!this.product.productDetailsList[index].productName || this.product.productDetailsList[index].productName === '') {
              if (this.product.productDetailsList[index].productCategoryList.length === 0) {
                this.product.productDetailsList.splice(index, 1);
              }
            }
          }
        });
      }
      // console.log('this.product', this.product);
      this.product.saveAsDraft = true;
      if (!this.isEdit) {
        this.generalService.createProduct(this.product).subscribe(res => {
          // console.log('res', res);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.ProductDraftCreated', 'SUCCESS');
          window.location.href = '/#!/user/dashboard/draft-content';
        });
      } else {
        this.generalService.updateProduct(this.product).subscribe(res => {
          // console.log('res', res);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.ProductDraftUpdated', 'SUCCESS');
          window.location.href = '/#!/user/dashboard/draft-content';
        });
      }
      // this.router.navigate(['/user/dashboard/draft-content']);

    }
    // console.log('this.product', this.product);

  }
  goStepSix(event?) {
    if (event.type === 'nextStep') {
      this.step5 = false;
      this.step6 = true;
      this.stepFive = true;
      this.stepValues = {
        stepOne: this.stepOne,
        stepTwo: this.stepTwo,
        stepThree: this.stepThree,
        stepFour: this.stepFour,
        stepFive: this.stepFive,
        stepSix: this.stepSix,
        activeTwo: this.activeTwo,
        activeThree: this.activeThree,
        activeFour: this.activeFour,
        activeColor2: 'grey',
        activeColor3: 'grey',
        activeColor4: 'grey',
        activeColor1: 'grey',
        activeColor5: 'grey',
        activeColor6: 'blue',
        activeColor7: 'black',
      };
    }
    if (event.product) {
      // console.log('event', event.product);
      this.product.productDetailsList.forEach(element => {
        element.productCategoryList.forEach((categoryItem, categoryIndex) => {
          categoryItem.sectionList.forEach((sectionItem, sectionIndex) => {
            sectionItem.widgetList.forEach((widgetItem, widgetIndex) => {
              const gridElementId = categoryIndex + '' + sectionIndex + '' + widgetIndex;
              const langIndex = event.product.languages.findIndex(item => item.gridItems.length);
              if (langIndex !== -1) {
                const index = event.product.languages[langIndex].gridItems.findIndex(item => item.gridElementId === gridElementId);
                widgetItem.widgetPositionX = event.product.languages[langIndex].gridItems[index].x;
                widgetItem.widgetPositionY = event.product.languages[langIndex].gridItems[index].y;
                widgetItem.widgetSizeCols = event.product.languages[langIndex].gridItems[index].cols;
                widgetItem.widgetSizeRows = event.product.languages[langIndex].gridItems[index].rows;
              }
            });
          });
        });
      });
      // console.log('this.product', this.product)
    }

    if (event.type === 'draft') {
      // eliminating null value objects from private product
      if (this.product.productType === 'private') {
        if (this.product.image) {
          if (!this.product.image.imageUrl) {
            this.product.image = null;
          }
        }
        if (this.product.tagList === null) {
          this.product.tagList = [];
        }
        if (this.product.invitedUsersList === null) {
          this.product.invitedUsersList = [];
        }
        if (this.product.favouriteUsersList === null) {
          this.product.favouriteUsersList = [];
        }


        ['fr', 'nl', 'en'].forEach(lang => {
          const index = this.product.productDetailsList.findIndex(item => item.language === lang);
          if (index !== -1) {
            if (!this.product.productDetailsList[index].productName || this.product.productDetailsList[index].productName === '') {
              if (this.product.productDetailsList[index].productCategoryList.length === 0) {
                this.product.productDetailsList.splice(index, 1);
              }
            }
          }
        });
      }
      // console.log('this.product', this.product)
      // console.log('product created')
      this.product.saveAsDraft = true;
      if (!this.isEdit) {
        this.generalService.createProduct(this.product).subscribe(res => {
          // console.log('res', res);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.ProductDraftCreated', 'SUCCESS');
          window.location.href = '/#!/user/dashboard/draft-content';
        });
      } else {
        this.generalService.updateProduct(this.product).subscribe(res => {
          // console.log('res', res);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.ProductDraftUpdated', 'SUCCESS');
          window.location.href = '/#!/user/dashboard/draft-content';
        });
      }
      // this.router.navigate(['/user/dashboard/draft-content']);
      // window.location.href = '/#!/user/dashboard/draft-content';

    }

  }
  goStepSeven() {
    this.stepSix = true;
    this.step6 = false;
    this.stepValues = {
      stepOne: this.stepOne,
      stepTwo: this.stepTwo,
      stepThree: this.stepThree,
      stepFour: this.stepFour,
      stepFive: this.stepFive,
      stepSix: this.stepSix,
      activeTwo: this.activeTwo,
      activeThree: this.activeThree,
      activeFour: this.activeFour,
      activeColor2: 'grey',
      activeColor3: 'grey',
      activeColor4: 'grey',
      activeColor1: 'grey',
      activeColor5: 'grey',
      activeColor6: 'grey',
      activeColor7: 'blue',
    };
  }

  done(event) {
    // console.log('event', event)
    if (this.product.hasOwnProperty('frCompleted')) {
      delete this.product.frCompleted;
    }
    if (this.product.hasOwnProperty('enCompleted')) {
      delete this.product.enCompleted;
    }
    if (this.product.hasOwnProperty('nlCompleted')) {
      delete this.product.nlCompleted;
    }

    // eliminating null value objects from private product
    if (this.product.productType === 'private') {
      if (this.product.image) {
        if (!this.product.image.imageUrl) {
          this.product.image = null;
        }
      }
      if (this.product.tagList === null) {
        this.product.tagList = [];
      }
      if (this.product.invitedUsersList === null) {
        this.product.invitedUsersList = [];
      }
      if (this.product.favouriteUsersList === null) {
        this.product.favouriteUsersList = [];
      }


      ['fr', 'nl', 'en'].forEach(lang => {
        const index = this.product.productDetailsList.findIndex(item => item.language === lang);
        if (index !== -1) {
          if (!this.product.productDetailsList[index].productName || this.product.productDetailsList[index].productName === '') {
            if (this.product.productDetailsList[index].productCategoryList.length === 0) {
              this.product.productDetailsList.splice(index, 1);
            }
          }
        }
      });
    }
    if (event.type === 'draft') {
      // console.log('event', event);
      // console.log('this.product', this.product);
      this.product.saveAsDraft = true;


      // eliminating null value objects from private product
      if (this.product.productType === 'private') {
        if (this.product.image) {
          if (!this.product.image.imageUrl) {
            this.product.image = null;
          }
        }
        if (this.product.tagList === null) {
          this.product.tagList = [];
        }
        if (this.product.invitedUsersList === null) {
          this.product.invitedUsersList = [];
        }
        if (this.product.favouriteUsersList === null) {
          this.product.favouriteUsersList = [];
        }


        ['fr', 'nl', 'en'].forEach(lang => {
          const index = this.product.productDetailsList.findIndex(item => item.language === lang);
          if (index !== -1) {
            if (!this.product.productDetailsList[index].productName || this.product.productDetailsList[index].productName === '') {
              if (this.product.productDetailsList[index].productCategoryList.length === 0) {
                this.product.productDetailsList.splice(index, 1);
              }
            }
          }
        });
      }
      if (!this.isEdit) {
        this.generalService.createProduct(this.product).subscribe(res => {
          // console.log('res', res);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.ProductDraftCreated', 'SUCCESS');
          // this.router.navigate(['/user/dashboard/draft-content']);
          window.location.href = '/#!/user/dashboard/draft-content';
        });
      } else {
        this.generalService.updateProduct(this.product).subscribe(res => {
          // console.log('res', res);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.ProductDraftUpdated', 'SUCCESS');
          // this.router.navigate(['/user/dashboard/draft-content']);
          window.location.href = '/#!/user/dashboard/draft-content';

        });
      }
    }
    if (event.type === 'publish') {
      // console.log('event', event);
      // console.log('this.product', this.product);
      if (!this.isEdit) {
        this.generalService.createProduct(this.product).subscribe(res => {
          // console.log('res', res);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.ProductPublishCreated', 'SUCCESS');
          if (this.product.productType === 'public') { this.router.navigateByUrl('/library/dashboard'); }
          if (this.product.productType === 'private') { this.router.navigate(['/user/dashboard/private-product']); }
        });
      } else {
        this.generalService.updateProduct(this.product).subscribe(res => {
          // console.log('res', res);
          this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.ProductPublishUpdated', 'SUCCESS');
          if (this.product.productType === 'public') { this.router.navigateByUrl('/library/dashboard'); }
          if (this.product.productType === 'private') { this.router.navigate(['/user/dashboard/private-product']); }
        });
      }
    }
  }
  updatePrivateLangs(event) {
    this.privateProductlanguages = event;
    // console.log('this.privateProductlanguages', this.privateProductlanguages)
  }
  checkProductValidity(event) {
    // tslint:disable-next-line: prefer-const
    let isValid = false;
    // console.log('event', event)
    // console.log(this.childStepSix)
    // console.log(this.childStepFive)
    // console.log(this.childStepFour)
    // console.log(this.childStepThree)

    if (this.childStepThree) {
      // console.log('currently on step 3');
      if (event.step3) {
        return false;
      }
      const dataFromStep3 = this.childStepThree.checkValidityBeforeMoving();
      // console.log('dataFromStep3', dataFromStep3)
      if (dataFromStep3.isValid) {
        // console.log(this.allSelectedCharts, 'these are current charts');
        if (event.step4) {

        }
        if (event.step5 || event.step6) {
          if (this.product.productDetailsList.length) {
            if (this.product.productType === 'public') {
              for (const element of this.product.productDetailsList) {
                if (element.productCategoryList.length) {
                  element.productCategoryList.forEach(cat => {
                    if (cat.sectionList.length) {
                      cat.sectionList.forEach(sec => {
                        const titles = sec.widgetList.filter(item => item.widgetType === 'title');

                        if ((sec.widgetList.length - titles.length) === 0) {
                          // this.notificationService
                          //   .showError
                          // tslint:disable-next-line: max-line-length
                          //   ('For all three language, there must be category,each category must have a section and each section must have a widget');
                          this.utilityService.showTranslatedNotificationMessage(
                            'NotificationMessages.Product.ForAllLanguages', 'ERROR');
                          return false;
                        }
                      });
                    } else {
                      // this.notificationService
                      //   .showError
                      // tslint:disable-next-line: max-line-length
                      //   ('For all three language, there must be category,each category must have a section and each section must have a widget');
                      this.utilityService.showTranslatedNotificationMessage(
                        'NotificationMessages.Product.ForAllLanguages', 'ERROR');
                      return false;
                    }
                  });
                } else {
                  // this.notificationService
                  //   .showError
                  // tslint:disable-next-line: max-line-length
                  //   ('For all three language, there must be category,each category must have a section and each section must have a widget');
                  this.utilityService.showTranslatedNotificationMessage(
                    'NotificationMessages.Product.ForAllLanguages', 'ERROR');
                  return false;
                }
              }
            }

            if (this.product.productType === 'private') {
              for (const lang of this.privateProductlanguages) {
                // console.log('lang', lang)
                // const index = this.product.productDetailsList.findIndex(item => item.language === lang);
                const element = this.product.productDetailsList.filter(item => item.language === lang)[0];
                // console.log('element', element)

                if (element.productCategoryList.length) {
                  for (const cat of element.productCategoryList) {
                    if (cat.sectionList.length) {
                      for (const sec of cat.sectionList) {
                        const titles = sec.widgetList.filter(item => item.widgetType === 'title');

                        if ((sec.widgetList.length - titles.length) === 0) {
                          // console.log('cat', cat)
                          // console.log('sec', sec)
                          // console.log('sec.widgetList.length', sec.widgetList.length)
                          // console.log('titles.length', titles.length)
                          // console.log('im wrong')
                          // this.notificationService
                          //   .showError
                          // tslint:disable-next-line: max-line-length
                          //   ('For selected language, there must be category,each category must have a section and each section must have a widget');
                          this.utilityService.showTranslatedNotificationMessage(
                            'NotificationMessages.Product.ForSelectedLanguage', 'ERROR');
                          return false;
                        }
                      }
                    } else {
                      // console.log('im wrong')
                      // this.notificationService
                      //   .showError
                      // tslint:disable-next-line: max-line-length
                      //   ('For selected language, there must be category,each category must have a section and each section must have a widget');
                      this.utilityService.showTranslatedNotificationMessage(
                        'NotificationMessages.Product.ForSelectedLanguage', 'ERROR');
                      return false;
                    }
                  }
                } else {
                  // console.log('im wrong')
                  // this.notificationService
                  //   .showError
                  // tslint:disable-next-line: max-line-length
                  //   ('For selected language, there must be category,each category must have a section and each section must have a widget');
                  this.utilityService.showTranslatedNotificationMessage(
                    'NotificationMessages.Product.ForSelectedLanguage', 'ERROR');
                  return false;
                }
              }

            }
          } else {
            return false;
          }
        }
        if (event.step6) {

        }
        return true;
      } else {
        return false;
      }
    }

    if (this.childStepFour) {
      // console.log('currently on step 4');
      if (event.step4) {
        return false;
      }
      const dataFromStep4 = this.childStepFour.checkValidityBeforeMoving(event.step3);
      if (event.step3) {
        return true;
      }
      if (dataFromStep4.isValid) {
        // if (event.step5) {
        //   this.goStepFive({ product: dataFromStep4.product, charts: dataFromStep4.charts, type: 'doNothing' });
        // }
        // if (event.step6) {
        //   this.goStepFive({ product: dataFromStep4.product, charts: dataFromStep4.charts, type: 'doNothing' });
        //   this.goStepSix({ product: dataFromStep4.product, type: 'doNothing' });

        // }
        return true;
      } else {
        return false;
      }
    }

    if (this.childStepFive) {
      // console.log('currently on step 5');
      const dataFromStep5 = this.childStepFive.checkValidityBeforeMoving();
      if (dataFromStep5.isValid) {
        // if (event.step6) {
        //   this.goStepSix({ product: dataFromStep5.product, type: 'doNothing' });
        // }
        return true;
      } else {
        return false;
      }
    }
    if (this.childStepSix) {
      // console.log('currently on step 6');
      return true;
    }
    // return false;
    // if (this.product.productType === 'private' || this.product.productType === 'public') {
    //   console.log('event.step5 || event.step6', event.step5, event.step6)
    //   // event.step5 || event.step6 &&
    //   console.log('this.isEditProduct', this.isEditProduct)
    //   if (this.isEditProduct) {
    //     console.log('this.product.productDetailsList', this.product.productDetailsList)
    //     this.product.productDetailsList.forEach(element => {
    //       // if (this.privateProductlanguages.includes(element.language)) {
    //       if (element.productCategoryList.length) {
    //         isValid = true;
    //         element.productCategoryList.forEach(cat => {
    //           if (cat.sectionList.length) {
    //             isValid = true;
    //             cat.sectionList.forEach(sec => {
    //               if (sec.widgetList.length) {
    //                 isValid = true;
    //                 sec.widgetList.forEach(wid => {
    //                   if (wid.widgetUrl) {
    //                     isValid = true;
    //                   } else {
    //                     isValid = false;
    //                     console.log('returning back from here-no widget url')
    //                     return false;
    //                   }
    //                 });
    //               } else {
    //                 isValid = false;
    //                 console.log('returning back from here-widgetList.length is zero')
    //                 return false;
    //               }
    //             })
    //           } else {
    //             isValid = false;
    //             console.log('returning back from here- sectionList.length is zero')
    //             return false;
    //           }
    //         })
    //       } else {
    //         isValid = false;
    //         console.log('returning back from here- category.length is zero')
    //         return false;
    //       }
    //       // }
    //     })
    //   } else {
    //     isValid = true;
    //   }
    // } else {
    //   isValid = true;
    // }
    // console.log('isValid', isValid)
    // return isValid;
  }
}
