import { Component, OnInit, EventEmitter, Output, Input, OnChanges } from '@angular/core';
import { GeneralService } from '../../shared/general-service.service';
import { ActivatedRoute } from '@angular/router';
import { FormControl } from '@angular/forms';
import { debounceTime, distinctUntilChanged, filter, switchMap, takeUntil, catchError, tap } from 'rxjs/operators';
import { of } from 'rxjs/internal/observable/of';
import { UtilityService } from 'src/app/core/services/utility.service';
import * as _ from 'lodash';
@Component({
  selector: 'ab-product-invite-people-form',
  templateUrl: './product-invite-people-form.component.html',
  styleUrls: ['./product-invite-people-form.component.scss']
})
export class ProductInvitePeopleFormComponent implements OnInit, OnChanges {
  @Output() closeEvent: EventEmitter<any> = new EventEmitter<any>();
  @Input() productType: any;
  id: any;
  userList = [];
  totalElements: any;
  page = 0;
  isLastTagPage: any;
  isLastPage: any;
  searchTerm: FormControl;
  loader = false;
  userIdsToInvite: any[] = [];
  emailIdsToInvite: any[] = [];
  userIdsToRemove: any[] = [];
  commaSeparatedEmails = '';
  multipleEmailAddressPattern = new RegExp(/^(\s?[^\s,]+@[^\s,]+\.[^\s,]+\s?,)*(\s?[^\s,]+@[^\s,]+\.[^\s,]+)$/);
  userListModified = false;
  alreadyInvitedUsers = [];
  invalidEmailError = false;
  i = 0;
  atBottom: boolean;

  constructor(private generalService: GeneralService, private activatedRoute: ActivatedRoute, private utilityService: UtilityService) { }

  ngOnInit() {
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    this.searchTerm = new FormControl('');
    this.getInitialUsers();
    this.listenSearchTermChanges();
  }

  ngOnChanges() {
    if (this.productType) {
      // console.log('this.productType', this.productType);
    }
  }

  listenSearchTermChanges() {
    this.searchTerm.valueChanges.pipe(
      distinctUntilChanged(),
      debounceTime(150),
      tap(term => {
        if (!term.trim().length) {
          this.getInitialUsers();
        }
      }),
      filter(term => term.length >= 1 && term.trim().length),
      switchMap(searchTerm => this.getUsersBySearch().pipe(
        takeUntil(this.searchTerm.valueChanges),
        catchError(err => {
          return of(err);
        })
      ))
    ).subscribe(res => {
      this.processResult(res);
    });
  }

  closeModal() {
    this.closeEvent.emit(false);
  }

  getUsers() {
    const queryParams = {
      productId: this.id,
      size: 5,
      page: this.page,
      search: this.searchTerm.value.trim(),
      loader: true
    };
    return this.generalService.getUsers(queryParams);
  }

  getInitialUsers() {
    // console.log(this.i);
    this.getUsers()
      // .pipe(
      //   catchError(err => {
      //     return of(err);
      //   })
      // )
      .subscribe(res => {
        // console.log('res', res);
        this.processResult(res);
        this.i++;
      });
  }

  getUsersBySearch() {
    this.userList = [];
    this.page = 0;
    this.loader = true;
    return this.getUsers();
  }

  onScroll(event) {
    // if (this.atBottom) {
    if (event.target.scrollHeight - event.target.scrollTop === event.target.clientHeight) {
      this.atBottom = true;
      if (this.userList.length < this.totalElements) {
        // console.log('end how many times')
        // console.log('this.isLastPage', this.isLastPage)
        if (!this.isLastPage) {
          this.page = this.page + 1;
          // console.log('this.page', this.page);
          this.getInitialUsers();
          // alert('bttom');}
        }
      }
    } else {
      this.atBottom = false;
    }
    // }

  }

  processResult(res) {
    this.loader = false;
    if (res.hasOwnProperty('error')) {
      this.listenSearchTermChanges();
      if (res.error.status !== 404) {
        throw res;
      }
      if (res.error.status === 404) {
        // console.log('res.error.status', res.error.status);
        // this.showPagination = false; this.loader = false;
      }
      this.userList = [];
      // this.total = 1;
    } else {

      this.userList = this.userList.concat(res.value.content);
      this.totalElements = res.value.totalElements;
      this.isLastPage = res.value.last;
      this.userList.forEach(user => {
        user.email = user.email;
        user.fullName = user.firstName + ' ' + user.lastName;
        user.initials = (user.firstName[0] + '' + user.lastName[0]).toUpperCase();
        user.isInvited = user.invited;
        user.role = user.roleCode.toLowerCase();
        if (user.isInvited) {
          this.alreadyInvitedUsers.push(user.id);
        }
        if (user.invited) {
          // this.userIdsToInvite.push(user.id);
        }
      });
      this.alreadyInvitedUsers = Array.from(new Set(this.alreadyInvitedUsers));
      this.userList = _.uniqBy(this.userList, 'id');
      // this.userList.forEach(user => {
      //   if (this.userIdsToInvite.includes(user.id)) {
      //     user.invited = true;
      //   }
      //   if (this.userIdsToRemove.includes(user.id)) {
      //     user.invited = false;
      //   }
      // });


    }
  }
  addUser(user, index) {
    if (!user.invited) {
      this.userListModified = true;
      this.userIdsToInvite.push(user.id);
      const index2 = this.userIdsToRemove.indexOf(user.id);
      if (index2 !== -1) {
        this.userIdsToRemove.splice(index2, 1);
      }
      user.invited = true;
      this.userList[index].invited = true;
    }
    this.userIdsToInvite = Array.from(new Set(this.userIdsToInvite));
    const tempUsers = JSON.parse(JSON.stringify(this.userIdsToInvite));
    tempUsers.forEach(id => {
      if (this.alreadyInvitedUsers.includes(id)) {
        const indexU = this.userIdsToInvite.findIndex(item => item === id);
        this.userIdsToInvite.splice(indexU, 1);
      }
    });
    // console.log('this.userIdsToInvite', this.userIdsToInvite);
    // console.log('this.userIdsToRemove', this.userIdsToRemove);
  }
  removeUser(user, index) {
    this.userListModified = true;
    if (user.invited) {
      // console.log('this.alreadyInvitedUsers.length', this.alreadyInvitedUsers.length)
      if (this.alreadyInvitedUsers.length && this.alreadyInvitedUsers.includes(user.id)) {
        // console.log('user.id', user.id)
        this.userIdsToRemove.push(user.id);
      }
      const index2 = this.userIdsToInvite.indexOf(user.id);
      if (index2 !== -1) {
        this.userIdsToInvite.splice(index2, 1);
      }
      user.invited = false;
      this.userList[index].invited = false;
    }
    this.userIdsToRemove = Array.from(new Set(this.userIdsToRemove));

    // console.log('this.alreadyInvitedUsers', this.alreadyInvitedUsers)
    if (this.alreadyInvitedUsers.length) {
      const removeUsers = JSON.parse(JSON.stringify(this.userIdsToRemove));
      removeUsers.forEach(userId => {
        if (!this.alreadyInvitedUsers.includes(userId)) {
          const index2 = this.userIdsToRemove.indexOf(userId);
          if (index2 !== -1) {
            this.userIdsToInvite.splice(index2, 1);
          }
        }
      });
    } else {
      this.userIdsToRemove = [];
    }


    // console.log('this.userIdsToRemove', this.userIdsToRemove);
    // console.log('this.userIdsToInvite', this.userIdsToInvite);

  }
  onEmailTextChanged() {
    if (this.commaSeparatedEmails && this.commaSeparatedEmails.match(this.multipleEmailAddressPattern)) {
      // console.log(this.commaSeparatedEmails);
      this.invalidEmailError = false;
    } else {
      this.invalidEmailError = true;
    }
  }

  submit() {

    // console.log('this.userIdsToRemove', this.userIdsToRemove);
    // console.log('this.userIdsToInvite', this.userIdsToInvite);
    // console.log(this.commaSeparatedEmails);
    // if (!this.userListModified) {
    //   this.userIdsToInvite = [];
    // }
    // const tempUsers = JSON.parse(JSON.stringify(this.userIdsToInvite));
    // tempUsers.forEach(id => {
    //   if (this.alreadyInvitedUsers.includes(id)) {
    //     const index = this.userIdsToInvite.findIndex(item => item == id)
    //     this.userIdsToInvite.splice(index, 1);
    //   }
    // });
    const data = {
      inviteEmails: this.commaSeparatedEmails && this.commaSeparatedEmails.split(',') || [],
      inviteUsers: this.userIdsToInvite,
      publishProductId: this.id,
      removeUsers: this.userIdsToRemove,
    };
    this.generalService.addUsersToProduct(data).subscribe(res => {
      // console.log('res', res);
      this.closeModal();
      this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Product.PeopleInvited', 'SUCCESS');
    });
  }

  isValid() {
    return true;
    let isValid = false;
    // if (this.userListModified || (this.commaSeparatedEmails && !this.invalidEmailError)) {
    //   isValid = true;
    //   if (this.commaSeparatedEmails && !this.invalidEmailError) {
    //     isValid = true;
    //   } else {
    //     isValid = false;
    //   }
    //   if (!this.commaSeparatedEmails && this.userListModified) {
    //     isValid = true;
    //   }
    // } else {
    //   isValid = false;
    // }
    if (this.userIdsToInvite.length || this.userIdsToRemove.length || (this.commaSeparatedEmails && !this.invalidEmailError)) {
      isValid = true;
    }
    return isValid;
  }
}
