import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductInvitePeopleFormComponent } from './product-invite-people-form.component';

describe('ProductInvitePeopleFormComponent', () => {
  let component: ProductInvitePeopleFormComponent;
  let fixture: ComponentFixture<ProductInvitePeopleFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductInvitePeopleFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductInvitePeopleFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
