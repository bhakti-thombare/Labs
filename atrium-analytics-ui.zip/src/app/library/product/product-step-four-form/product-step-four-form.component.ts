import {
  Component,
  OnInit, ChangeDetectorRef, QueryList, ElementRef, ViewChildren, EventEmitter, Output, Input, OnChanges, OnDestroy, SimpleChanges
} from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { FileUploader } from 'ng2-file-upload';
import { DomSanitizer } from '@angular/platform-browser';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GeneralService } from '../../shared/general-service.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import * as _ from 'lodash';
import { UtilityService } from 'src/app/core/services/utility.service';

@Component({
  selector: 'ab-product-step-four-form',
  templateUrl: './product-step-four-form.component.html',
  styleUrls: ['./product-step-four-form.component.scss']
})
export class ProductStepFourFormComponent implements OnInit, OnChanges, OnDestroy {
  @ViewChildren('fileInput') fileInputs: QueryList<ElementRef>;
  @ViewChildren('fileInputTag') fileInputTag: QueryList<ElementRef>;
  @Output() nextStep: EventEmitter<any> = new EventEmitter<any>();
  @Input() product: any;
  @Input() chartsInput: any;
  @Input() privateProductLanguages: any;
  selectedTabLanguage = 'fr';
  nlCompleted = false;
  frCompleted = false;
  enCompleted = false;
  categoryList: any;
  modalRef: BsModalRef;
  urlPattern = new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,10}\b([-a-zA-Z0-9@:%_\+.~#()?&//=]*)/);
  // = [{
  //   categoryTitle: 'string',
  //   section: [{
  //     sectionTitle: 'string',
  //     widgets: []
  //   }]
  // }];
  public uploader: FileUploader = new FileUploader({
    // url: URL,
    // disableMultipart:true
  });
  categoryForm: FormGroup;
  categoryFormArray: any;
  sectionFormArray: any;
  widgetFormArray: any;
  kpiCategory = {
    languages: [
      {
        language: 'fr',
        productCategoryList: []
      },
      {
        language: 'nl',
        productCategoryList: []

      },
      {
        language: 'en',
        productCategoryList: []
      }
    ]
  };
  category = {
    categoryId: null,
    categoryName: '',
    open: false,
    sectionList: []
  };

  section = {
    sectionId: null,
    sectionTitle: '',
    openOtherOptions: false,
    widgetList: []
  };
  rebuild = false;
  productType: any;
  // tslint:disable-next-line: max-line-length
  charts: { token: string; projects: { id: string; name: string; workbooks: { id: string; name: string; views: { id: string; name: string; contentUrl: string; }[]; }[]; }[]; };
  chartIndices: any = {};
  currentChartIndex: number;
  selectedCharts: any[] = [];
  allSelectedCharts = {
    frSelectedCharts: [],
    nlSelectedCharts: [],
    enSelectedCharts: []
  };
  privateProductLanguagesAllowed = [];
  singleChartIndices: any;
  selectSingleChart: boolean;
  chartwidgetIndex: any;
  isEdited: boolean = false;

  constructor(
    private utilityService: UtilityService,
    private modalService: BsModalService,
    private generalService: GeneralService,
    private notificationService: NotificationService,
    private formBuilder: FormBuilder,
    private sanitizer: DomSanitizer,
    private ref: ChangeDetectorRef) { }

  ngOnInit() {
    this.categoryList = [];
    // this.buildForm();
    this.listenChanges();
  }

  ngOnChanges(changes: SimpleChanges) {
    // console.log('----------------------------------------------------------------------------------------------------------------')
    // console.log('changes', changes)
    // console.log('----------------------------------------------------------------------------------------------------------------')
    this.buildForm();
    // console.log('this.product', this.product);
    if (this.product) {
      this.productType = this.product.productType;
      if (this.productType === 'private') {
        if (this.product.enCompleted) {
          this.selectedTabLanguage = 'en';
        }
        if (this.product.nlCompleted) {
          this.selectedTabLanguage = 'nl';
        }
        if (this.product.frCompleted) {
          this.selectedTabLanguage = 'fr';
        }

      }
    }
    if (this.product.productType === 'public') {
      if (this.product &&
        this.product.productDetailsList[0].productCategoryList.length &&
        this.product.productDetailsList[1].productCategoryList.length &&
        this.product.productDetailsList[2].productCategoryList.length) {
        this.rebuild = true;
        // console.log('this.product', this.product);
        ['fr', 'nl', 'en'].forEach(lang => {
          const index1 = this.kpiCategory.languages.findIndex(item => item.language === lang);
          const index2 = this.product.productDetailsList.findIndex(item => item.language === lang);
          this.cleanCategoryList(this.product.productDetailsList[index2].productCategoryList);
          this.kpiCategory.languages[index1].productCategoryList = this.product.productDetailsList[index2].productCategoryList;
        });
        // this.setDataOnLangSwitch(this.selectedTabLanguage);
        // console.log('this.kpiCategory', this.kpiCategory)
        this.patchValueToForm();
      }
    }
    // console.log('this.privateProductLanguages', this.privateProductLanguages)
    // console.log(this.privateProductLanguagesAllowed);
    if (this.product.productType === 'private') {
      this.privateProductLanguagesAllowed = this.privateProductLanguages;
      // console.log('this.chartsInput', this.chartsInput);

      if (this.chartsInput.frSelectedCharts.length && this.chartsInput.frSelectedCharts[0].hasOwnProperty('id')) {
        this.chartsInput.frSelectedCharts = _.uniqBy(this.chartsInput.frSelectedCharts, 'id');
      }
      if (this.chartsInput.nlSelectedCharts.length && this.chartsInput.nlSelectedCharts[0].hasOwnProperty('id')) {
        this.chartsInput.nlSelectedCharts = _.uniqBy(this.chartsInput.nlSelectedCharts, 'id');
      }
      if (this.chartsInput.enSelectedCharts.length && this.chartsInput.enSelectedCharts[0].hasOwnProperty('id')) {
        this.chartsInput.enSelectedCharts = _.uniqBy(this.chartsInput.enSelectedCharts, 'id');
      }
      // console.log('this.chartsInput', this.chartsInput);
      // this.selectedCharts = this.chartsInput;
      this.allSelectedCharts = this.chartsInput;
      const index = this.product.productDetailsList.findIndex(item => item.productCategoryList.length);
      // console.log('index', index)
      // console.log('this.privateProductLanguagesAllowed[0]', this.privateProductLanguagesAllowed[0])
      if (index !== -1) {
        // tslint:disable-next-line: max-line-length
        // console.log('this.product.productDetailsList[index].productCategoryList.length', this.product.productDetailsList[index].productCategoryList)
        // tslint:disable-next-line: max-line-length
        // console.log('this.product.productDetailsList[index].productCategoryList.length', this.product.productDetailsList[index].productCategoryList.length)
        if (this.product.productDetailsList[index].productCategoryList.length) {
          this.rebuild = true;
          // console.log('this.product', this.product);
          // console.log('this.privateProductLanguagesAllowed.', this.privateProductLanguagesAllowed)
          this.privateProductLanguagesAllowed.forEach(lang => {
            // console.log('lang', lang)
            // const lang = this.selectedTabLanguage;
            const index1 = this.kpiCategory.languages.findIndex(item => item.language === lang);
            const index2 = this.product.productDetailsList.findIndex(item => item.language === lang);
            if (this.product.productDetailsList.length) {
              if (this.product.productDetailsList[index2]) {
                // this.product.productDetailsList[index2].productCategoryList.length
                if (true) {

                  // console.log('this.product.productDetailsList[index2]', this.product.productDetailsList[index2])
                  // this.cleanCategoryList(this.product.productDetailsList[index2].productCategoryList);
                  this.kpiCategory.languages[index1].productCategoryList = this.product.productDetailsList[index2].productCategoryList;
                }
              }
            }
          });
          // this.setDataOnLangSwitch(this.selectedTabLanguage);
          // console.log('this.kpiCategory', this.kpiCategory)
          this.patchValueToPrivateForm();
        }
      }
    }
  }

  patchValueToPrivateForm() {
    // this.buildForm();
    const index = this.kpiCategory.languages.findIndex(item => item.productCategoryList.length);
    // console.log('index', index)
    if (index !== -1) {
      this.kpiCategory.languages[index].productCategoryList.forEach((categoryItem, categoryIndex) => {
        this.addCategoryToForm(false);
        categoryItem.sectionList.forEach((sectionItem, sectionIndex) => {
          this.addSectionToForm(false, categoryIndex);
          this.currentChartIndex = 0;
          sectionItem.widgetList.forEach(widgetItem => {
            if (widgetItem.widgetType === 'chart') {
              this.chartIndices.category = categoryIndex;
              this.chartIndices.section = sectionIndex;
              this.chartIndices.widgetType = widgetItem.widgetType;
            }
            this.addWidgetToForm(false, categoryIndex, sectionIndex, widgetItem.widgetType);
            if (widgetItem.widgetType === 'chart') { this.currentChartIndex = this.currentChartIndex + 1; }
          });
        });
      });
    }
    // this.privateProductLanguagesAllowed.forEach(lang => {
    // console.log('this.privateProductLanguagesAllowed', this.privateProductLanguagesAllowed)
    // this.privateProductLanguages.forEach(lang => {
    // console.log(this.categoryForm.value)
    this.setDataOnLangSwitch(this.selectedTabLanguage);
    // })
    // })
  }

  patchValueToForm() {
    // this.buildForm();
    this.kpiCategory.languages[0].productCategoryList.forEach((categoryItem, categoryIndex) => {
      this.addCategoryToForm(false);
      categoryItem.sectionList.forEach((sectionItem, sectionIndex) => {
        this.addSectionToForm(false, categoryIndex);
        sectionItem.widgetList.forEach(widgetItem => {
          this.addWidgetToForm(false, categoryIndex, sectionIndex, widgetItem.widgetType);
        });
      });
    });
    // ['fr', 'nl', 'en'].forEach(lang => {
    this.setDataOnLangSwitch(this.selectedTabLanguage);
    // })
  }

  listenChanges() {
    this.categoryForm.valueChanges.subscribe(category => {
      // console.log('category', category);
      this.setStepFourData(this.selectedTabLanguage);
      this.checkLanguageCompleteness();
      // if (this.productType === 'public') { this.isVizUrlPresent(); }
    });
    if (this.product.enCompleted) {
      this.enCompleted=true;
    }
    if (this.product.nlCompleted) {
      this.nlCompleted=true;
    }
    if (this.product.frCompleted) {
      this.frCompleted=true;
    }
  }

  buildForm() {
    this.categoryForm = this.formBuilder.group({
      category: this.formBuilder.array([])
    });
  }
  // category
  addCategoryToForm(value?) {
    this.categoryFormArray = this.categoryForm.get('category') as FormArray;
    this.categoryFormArray.push(this.buildCategoryForm());
    if (!this.rebuild || value) { this.addElementToArray('category'); }
    if (value == true && (location.href.split('/').indexOf('product-edit') != -1)){
      this.isEdited = true;
      sessionStorage.setItem('hasEdited',String(this.isEdited));
    }
  }

  buildCategoryForm() {
    return this.formBuilder.group({
      categoryName: ['', Validators.required],
      open: [false],
      sectionList: this.formBuilder.array([])
    });
  }

  // section
  addSectionToForm(value, index) {
    this.sectionFormArray = this.categoryForm.get(`category.${index}.sectionList`) as FormArray;
    this.sectionFormArray.push(this.buildSectionForm());
    if (!this.rebuild || value) { this.addElementToArray('section', index); }
    if (value == true && (location.href.split('/').indexOf('product-edit') != -1)) {
      this.isEdited = true;
      sessionStorage.setItem('hasEdited', String(this.isEdited));
    }
  }
  buildSectionForm() {
    return this.formBuilder.group({
      sectionTitle: ['', Validators.required],
      widget: this.formBuilder.array([]),
      openOtherOptions: [false]
    });
  }

  // widget
  addWidgetToForm(value, categoryIndex, sectionIndex, type) {
    this.widgetFormArray = this.categoryForm.get(`category.${categoryIndex}.sectionList.${sectionIndex}.widget`) as FormArray;
    this.widgetFormArray.push(this.buildWidgetForm(type));
    if (type === 'chart') {
      this.setChartToForm();
    }
    if (!this.rebuild || value) { this.addElementToArray('widget', categoryIndex, sectionIndex, type); }
    if (value == true && (location.href.split('/').indexOf('product-edit') != -1)) {
      this.isEdited = true;
      sessionStorage.setItem('hasEdited', String(this.isEdited));
    }
  }
  buildWidgetForm(type: string) {
    return this.formBuilder.group({
      fileName: [''],
      type: [type],
      dataUrl: [''],
      vizUrl: ['', Validators.pattern(this.urlPattern)]
    });
  }

  switchLangauageTab(lang) {
    if (this.productType === 'private') {
      if (!this.privateProductLanguagesAllowed.includes(lang)) {
        return;
      }
    }
    this.selectedTabLanguage = lang;
    this.setDataOnLangSwitch(this.selectedTabLanguage);
  }

  removeCategory(categoryIndex) {
    (this.categoryForm.get('category') as FormArray).removeAt(categoryIndex);
    this.removeElementFromArray('category', categoryIndex);
    this.isEdited = true;
    sessionStorage.setItem('hasEdited', String(this.isEdited));
  }
  removeSection(categoryIndex, sectionIndex) {
    (this.categoryForm.get(`category.${categoryIndex}.sectionList`) as FormArray).removeAt(sectionIndex);
    this.removeElementFromArray('section', categoryIndex, sectionIndex);
    this.isEdited = true;
    sessionStorage.setItem('hasEdited', String(this.isEdited));
  }
  removeWidget(categoryIndex, sectionIndex, widgetIndex) {
    this.kpiCategory.languages.forEach(element => {
      // console.log('element', element)
      if (element.productCategoryList.length) {
        if (element.productCategoryList[categoryIndex].sectionList.length) {
          if (element.productCategoryList[categoryIndex].sectionList[sectionIndex].widgetList.length) {
            const widgetToRemove = element
              .productCategoryList[categoryIndex]
              .sectionList[sectionIndex]
              .widgetList[widgetIndex];
            // console.log('widgetToRemove', widgetToRemove)
            if (widgetToRemove && widgetToRemove.widgetType === 'chart') {
              // console.log('removing chartssssssssssss')
              // console.log('this.allSelectedCharts', this.allSelectedCharts)

              const index2 =
                this.allSelectedCharts[element.language + 'SelectedCharts'].findIndex(item => item.contentUrl === widgetToRemove.widgetUrl);
              // tslint:disable-next-line: max-line-length
              // console.log('this.allSelectedCharts[this.selectedTabLanguage + \'SelectedCharts\']', this.allSelectedCharts[element.language + 'SelectedCharts'][index2])
              if (index2 !== -1) {
                this.allSelectedCharts[element.language + 'SelectedCharts'].splice(index2, 1);
              }
            }
          }
        }
      }
    });
    (this.categoryForm.get(`category.${categoryIndex}.sectionList.${sectionIndex}.widget`) as FormArray).removeAt(widgetIndex);
    // console.log('this.categoryForm.value', this.categoryForm.value)
    const category = this.categoryForm.value.category;
    if (this.categoryForm.value.category.length) {
      category.forEach((cat, catIndex) => {
        if (cat.sectionList.length) {
          cat.sectionList.forEach((sec, secIndex) => {
            if (sec.widget.length) {
              if (sec.widget.length === 1) {
                if (sec.widget.type === 'title') {
                  (this.categoryForm.get(`category.${catIndex}.sectionList.${secIndex}.widget`) as FormArray).removeAt(0);
                  // console.log('removing title');
                }
              }
            }
          });
        }
      });
    }
    // console.log('this.categoryForm.value', this.categoryForm.value)
    this.removeElementFromArray('widget', categoryIndex, sectionIndex, widgetIndex);
    this.isEdited = true;
    sessionStorage.setItem('hasEdited', String(this.isEdited));
  }

  setDataOnLangSwitch(lang) {
    const index = this.kpiCategory.languages.findIndex(item => item.language === lang);
    // console.log('this.kpiCategory', this.kpiCategory);
    const kpiCategoryData = this.kpiCategory.languages[index];
    // console.log('kpiCategoryData', kpiCategoryData)
    // const category = this.kpiCategory.languages[index];
    const category = this.categoryForm.get('category') as FormArray;
    // console.log('category', category.at(0));
    // (category.at(0).get('section') as FormArray).at(0)
    // console.log('(category.get(\'section\') as FormArray).at(index)', (category.at(0).get('section') as FormArray).at(0))
    if (kpiCategoryData.productCategoryList.length) {
      // console.log('category.length', category.length)
      const data = {
        category: []
      };
      kpiCategoryData.productCategoryList.forEach((cat, i) => {
        // console.log('cat', cat)
        data.category.push({ categoryName: cat.categoryName, open: cat.open, sectionList: [] });
        cat.sectionList.forEach((sec, j) => {
          data.category[i].sectionList.push({ sectionTitle: sec.sectionTitle, openOtherOptions: sec.openOtherOptions, widget: [] });
          sec.widgetList.forEach((wid, k) => {
            // tslint:disable-next-line: max-line-length
            data.category[i].sectionList[j].widget.push({ type: wid.widgetType, dataUrl: wid.widgetUrl, fileName: wid.fileName || '', vizUrl: wid.vizUrl || '' });
          });
        });
      });
      // console.log('lang', lang)
      // console.log('form array data', data);
      // console.log('this.categoryForm', this.categoryForm.value)
      this.categoryForm.setValue(data, { emitEvent: false });
    } else {
      // console.log('resetting form value');
      // this.categoryForm.reset('', { emitEvent: false });
      const data = {
        category: []
      };
      this.kpiCategory.languages.forEach(element => {
        // console.log('this.kpiCategory.languages', element.language, element.language !== this.selectedTabLanguage)
        // console.log(this.privateProductLanguagesAllowed)
        if (element.language === this.selectedTabLanguage) {
          // console.log('element', element);
          // console.log('element.productCategoryList.length', element.productCategoryList.length)
          // console.log('kpiCategoryData', kpiCategoryData)
          const tempCat = this.categoryForm.value;
          // console.log('tempCat', tempCat)
          tempCat.category.forEach((cat, i) => {
            // console.log('cat', cat)
            data.category.push({ categoryName: '', open: false, sectionList: [] });
            cat.sectionList.forEach((sec, j) => {
              // console.log('sec', sec)
              data.category[i].sectionList.push({ sectionTitle: '', openOtherOptions: false, widget: [] });
              sec.widget.forEach((wid, k) => {
                // console.log('wid', wid)
                data.category[i].sectionList[j].widget.push({ type: wid.type, dataUrl: '', fileName: '', vizUrl: '' });
              });
            });
          });
        }
      });
      // console.log('data', data)
      // data.category.splice(1, 1);
      // console.log('data', data)
      this.categoryForm.setValue(data, { emitEvent: true });
      // if (this.productType === 'public') {  }
      // if (this.productType === 'private') {
      //   this.categoryForm.setValue(data);
      // }
    }

    // console.log(this.categoryForm.value);
    this.checkLanguageCompleteness();

  }

  setStepFourData(lang) {
    const index = this.kpiCategory.languages.findIndex(item => item.language === lang);
    // console.log('this.kpiCategory', JSON.parse(JSON.stringify(this.kpiCategory)))
    // console.log('index', index)
    const originalKpiCategory = JSON.parse(JSON.stringify(this.kpiCategory));

    // this.kpiCategory.languages[index].categoryName = this.categoryForm.value.categoryTitle;
    // this.kpiCategory.languages[index].section = this.categoryForm.value.section.value

    // const data = {};
    // console.log('this.categoryForm.value', this.categoryForm.value)
    const category = this.categoryForm.value.category;
    if (this.categoryForm.value.category.length) {
      category.forEach((cat, catIndex) => {
        if (cat.sectionList.length) {
          cat.sectionList.forEach((sec, secIndex) => {
            if (sec.widget.length) {
              if (sec.widget.length === 1) {
                if (sec.widget.type === 'title') {
                  (this.categoryForm.get(`category.${catIndex}.sectionList.${secIndex}.widget`) as FormArray).removeAt(0);
                  // console.log('removing title');
                }
              }
            }
          });
        }
      });
    }
    // console.log('category', category)
    const categories = [];
    // Iterate through category array
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < category.length; i++) {
      const originalCategoryId = originalKpiCategory.languages[index].productCategoryList[i] &&
        originalKpiCategory.languages[index].productCategoryList[i].categoryId || null;
      const categoryData = {
        categoryId: originalCategoryId,
        categoryName: category[i].categoryName,
        sectionList: [],
        open: category[i].open
      };
      const section = category[i].sectionList;
      // console.log('categoryData', categoryData)

      // Iterate through section array
      // tslint:disable-next-line: prefer-for-of
      for (let j = 0; j < section.length; j++) {
        const originalSectionId = originalKpiCategory.languages[index].productCategoryList[i] &&
          originalKpiCategory.languages[index].productCategoryList[i] &&
          originalKpiCategory.languages[index].productCategoryList[i].sectionList[j] &&
          originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].sectionId || null;
        const sectionData = {
          sectionId: originalSectionId,
          sectionTitle: section[j].sectionTitle,
          openOtherOptions: section[j].openOtherOptions,
          widgetList: []
        };
        const widgets = section[j].widget;
        // console.log('sectionData', sectionData)

        // Iterate through widgets array
        // tslint:disable-next-line: prefer-for-of
        for (let k = 0; k < widgets.length; k++) {
          // console.log(i, j, k)
          // console.log('section[j].widgetList[k]', originalKpiCategory.languages[index]);
          const originalWidgetId = originalKpiCategory.languages[index].productCategoryList[i] &&
            originalKpiCategory.languages[index].productCategoryList[i] &&
            originalKpiCategory.languages[index].productCategoryList[i].sectionList[j] &&
            originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList[k] &&
            originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList[k].widgetId || null;
          let widgetData: any = {};

          widgetData = {

            widgetId: originalWidgetId,
            widgetType: widgets[k].type,
            widgetUrl: widgets[k].dataUrl,
            widgetData: widgets[k].fileName,
            widgetPositionX: originalKpiCategory.languages[index].productCategoryList.length &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList.length &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList.length &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList[k] &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList[k].widgetPositionX ||
              (widgets[k].type === 'title' ? 0 : 0),
            widgetPositionY: originalKpiCategory.languages[index].productCategoryList.length &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList.length &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList.length &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList[k] &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList[k].widgetPositionY ||
              (widgets[k].type === 'title' ? 0 : 0),
            widgetSizeCols: originalKpiCategory.languages[index].productCategoryList.length &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList.length &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList.length &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList[k] &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList[k].widgetSizeCols ||
              (widgets[k].type === 'title' ? 2 : 2),
            widgetSizeRows: originalKpiCategory.languages[index].productCategoryList.length &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList.length &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList.length &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList[k] &&
              originalKpiCategory.languages[index].productCategoryList[i].sectionList[j].widgetList[k].widgetSizeRows ||
              (widgets[k].type === 'title' ? 1 : 3),
            vizUrl: widgets[k].vizUrl || null,
            fileName: widgets[k].fileName
          };
          // }
          // console.log('widgetData', widgetData)
          sectionData.widgetList.push(widgetData);
          // console.log('sectionData.widgetList', sectionData.widgetList);
        }
        categoryData.sectionList.push(sectionData);
        // console.log('categoryData.section', categoryData.section);
      }
      categories.push(categoryData);
    }
    console.log('categories', categories);
    this.kpiCategory.languages[index].productCategoryList = categories;
    // console.log('this.kpiCategory', this.kpiCategory);
    // Updating title widget
    if (this.kpiCategory.languages[index].productCategoryList.length) {
      this.kpiCategory.languages[index].productCategoryList.forEach(cat => {
        if (cat.sectionList.length) {
          cat.sectionList.forEach(sec => {
            if (sec.widgetList.length) {
              sec.widgetList.forEach(wid => {
                if (wid.widgetType === 'title') {
                  wid.widgetUrl = sec.sectionTitle;
                }
              });
            }
          });
        }
      });
    }

    // updating widget positions for new lang

    // console.log('this.kpiCategory', this.kpiCategory)
    // console.log(this.product, 'just checking the product without next button hitting')
    this.updateOriginalProduct();
    this.checkLanguageCompleteness();
  }

  submit(value) {
    // console.log('this.kpiCategory', this.kpiCategory);
    // console.log('this.categoryForm', this.categoryForm);
    let mustHave = true;
    if (this.productType === 'public') {
      this.kpiCategory.languages.forEach(element => {
        const list = element.productCategoryList;

        if (list.length) {
          for (const category of list) {
            if (category.sectionList.length) {
              for (const section of category.sectionList) {
                const titles = section.widgetList.filter(item => item.widgetType === 'title');

                if ((section.widgetList.length - titles.length) === 0) {
                  mustHave = false;
                }
              }
            } else {
              mustHave = false;
            }
          }
        } else {
          mustHave = false;
        }
      });
      // console.log('mustHave', mustHave)
      if (!mustHave) {
        // this.notificationService
        //   .showError
        //   ('For all three language, there must be category,each category must have a section and each section must have a widget');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.ForAllLanguages', 'ERROR');
        return;
      }
      if (this.frCompleted && this.nlCompleted && this.enCompleted) {

      } else {
        // this.notificationService.showError('please fill info for three languages');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.MandatoryForAllLangs', 'ERROR');
        return;
      }
    }
    if (this.productType === 'private') {
      // console.log('this.privateProductLanguagesAllowed', this.privateProductLanguagesAllowed)
      for (const privateLang of this.privateProductLanguagesAllowed) {
        const index = this.kpiCategory.languages.findIndex(item => item.language === this.selectedTabLanguage);
        if (index !== -1) {
          const list = this.kpiCategory.languages[index].productCategoryList;
          // console.log('list', list)

          if (list.length) {
            for (const category of list) {
              if (category.sectionList.length) {
                for (const section of category.sectionList) {
                  const titles = section.widgetList.filter(item => item.widgetType === 'title');

                  if ((section.widgetList.length - titles.length) === 0) {
                    mustHave = false;
                  }
                }
              } else {
                mustHave = false;
              }
            }
          } else {
            mustHave = false;
          }
        }
      }
      // console.log('mustHave', mustHave)
      if (!mustHave) {
        // this.notificationService
        //   .showError
        //   ('For selected language, there must be category,each category must have a section and each section must have a widget');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.ForSelectedLanguage', 'ERROR');
        return;
      }
      if (this.privateProductLanguagesAllowed.includes('fr') && !this.frCompleted) {
        // this.notificationService.showError('Please fill in all fields, all are mandatory');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.AllMandatoryFields', 'ERROR');
        return;
      }
      if (this.privateProductLanguagesAllowed.includes('nl') && !this.nlCompleted) {
        // this.notificationService.showError('Please fill in all fields, all are mandatory');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.AllMandatoryFields', 'ERROR');
        return;
      }
      if (this.privateProductLanguagesAllowed.includes('en') && !this.enCompleted) {
        // this.notificationService.showError('Please fill in all fields, all are mandatory');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.AllMandatoryFields', 'ERROR');
        return;
      }

      // updating positions for new languages/ making them simple to the first language
      const firstIndex = this.kpiCategory.languages.findIndex(item => item.language === this.privateProductLanguagesAllowed[0]);
      const firstElement = this.kpiCategory.languages[firstIndex];
      // console.log('firstElement', firstElement)
      this.kpiCategory.languages.forEach(element => {

        if (firstElement.language !== element.language) {
          if (element.productCategoryList.length) {
            element.productCategoryList.forEach((cat, catIndex) => {
              if (cat.sectionList.length) {
                cat.sectionList.forEach((sec, secIndex) => {
                  if (sec.widgetList.length) {
                    sec.widgetList.forEach((wid, widIndex) => {
                      wid.widgetPositionX =
                        firstElement.productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].widgetPositionX;
                      wid.widgetPositionY =
                        firstElement.productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].widgetPositionY;
                      wid.widgetSizeCols =
                        firstElement.productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].widgetSizeCols;
                      wid.widgetSizeRows =
                        firstElement.productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].widgetSizeRows;
                    });
                  }
                });
              }
            });
          }
        }
      });

    }
    // if (this.frCompleted && this.nlCompleted && this.enCompleted) {
    this.kpiCategory.languages.forEach(element => {
      element.productCategoryList.forEach(categoryItem => {
        categoryItem.sectionList.forEach(sectionItem => {
          const data = {
            widgetId: null,
            widgetType: 'title',
            widgetUrl: sectionItem.sectionTitle,
            widgetData: '',
            widgetPositionX: 0,
            widgetPositionY: 0,
            widgetSizeCols: 2,
            widgetSizeRows: 1,
            vizUrl: '',
            fileName: ''
          };

          const titleIndex = sectionItem.widgetList.findIndex(item => item.widgetType === 'title');
          if (titleIndex === -1) {
            sectionItem.widgetList.unshift(data);
          } else {
            if (titleIndex !=0){
              let item = sectionItem.widgetList.filter(item => item.widgetType === 'title')[0];
              sectionItem.widgetList.splice(titleIndex,1);
              sectionItem.widgetList.unshift(item);
              //sectionItem.widgetList.unshift(sectionItem.widgetList.splice(sectionItem.widgetList.findIndex(item => item.widgetType === 'title'), 1)[0])
            } else{
              sectionItem.widgetList[titleIndex].widgetUrl = sectionItem.sectionTitle;
            }
          }
        });
      });
    });
    console.log("KPI Category",JSON.parse(JSON.stringify(this.kpiCategory)));
    this.nextStep.emit({ product: this.kpiCategory, type: value, charts: this.allSelectedCharts });
    // } else {
    //   this.notificationService.showError('please fill info for three languages');
    //   // return;
    // }
    // kpiCategory
  }

  checkValidityBeforeMoving(value) {
    // console.log('this.kpiCategory', this.kpiCategory);
    // console.log('this.categoryForm', this.categoryForm);
    if (value) {
      return { isValid: true };
    }
    let mustHave = true;
    if (this.productType === 'public') {
      this.kpiCategory.languages.forEach(element => {
        const list = element.productCategoryList;

        // console.log('element', element)
        if (list.length) {
          for (const category of list) {
            if (category.sectionList.length) {
              for (const section of category.sectionList) {
                const titles = section.widgetList.filter(item => item.widgetType === 'title');

                if ((section.widgetList.length - titles.length) === 0) {
                  // console.log('mustHave', mustHave)
                  mustHave = false;
                }
              }
            } else {
              // console.log('mustHave', mustHave)
              mustHave = false;
            }
          }
        } else {
          // console.log('mustHave', mustHave)
          mustHave = false;
        }
      });
      // console.log('mustHave', mustHave)
      if (!mustHave) {
        // this.notificationService
        //   .showError
        //   ('For all three language, there must be category,each category must have a section and each section must have a widget');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.ForAllLanguages', 'ERROR');
        return { isValid: false };
      }
      if (this.frCompleted && this.nlCompleted && this.enCompleted) {

      } else {
        // this.notificationService.showError('please fill info for three languages');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.MandatoryForAllLangs', 'ERROR');
        return { isValid: false };
      }
    }
    if (this.productType === 'private') {
      // console.log('this.privateProductLanguagesAllowed', this.privateProductLanguagesAllowed)
      for (const privateLang of this.privateProductLanguagesAllowed) {
        const index = this.kpiCategory.languages.findIndex(item => item.language === this.selectedTabLanguage);
        if (index !== -1) {
          const list = this.kpiCategory.languages[index].productCategoryList;
          // console.log('list', list)

          if (list.length) {
            for (const category of list) {
              if (category.sectionList.length) {
                for (const section of category.sectionList) {
                  const titles = section.widgetList.filter(item => item.widgetType === 'title');

                  if ((section.widgetList.length - titles.length) === 0) {
                    mustHave = false;
                  }
                }
              } else {
                mustHave = false;
              }
            }
          } else {
            mustHave = false;
          }
        }
      }
      // console.log('mustHave', mustHave)
      if (!mustHave) {
        // this.notificationService
        //   .showError
        //   ('For selected language, there must be category,each category must have a section and each section must have a widget');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.ForSelectedLanguage', 'ERROR');
        return { isValid: false };
      }
      if (this.privateProductLanguagesAllowed.includes('fr') && !this.frCompleted) {
        // this.notificationService.showError('Please fill in all fields, all are mandatory');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.AllMandatoryFields', 'ERROR');
        return { isValid: false };
      }
      if (this.privateProductLanguagesAllowed.includes('nl') && !this.nlCompleted) {
        // this.notificationService.showError('Please fill in all fields, all are mandatory');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.AllMandatoryFields', 'ERROR');
        return { isValid: false };
      }
      if (this.privateProductLanguagesAllowed.includes('en') && !this.enCompleted) {
        // this.notificationService.showError('Please fill in all fields, all are mandatory');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.AllMandatoryFields', 'ERROR');
        return { isValid: false };
      }

      // updating positions for new languages/ making them simple to the first language
      const firstIndex = this.kpiCategory.languages.findIndex(item => item.language === this.privateProductLanguagesAllowed[0]);
      const firstElement = this.kpiCategory.languages[firstIndex];
      // console.log('firstElement', firstElement)
      this.kpiCategory.languages.forEach(element => {

        if (firstElement.language !== element.language) {
          if (element.productCategoryList.length) {
            element.productCategoryList.forEach((cat, catIndex) => {
              if (cat.sectionList.length) {
                cat.sectionList.forEach((sec, secIndex) => {
                  if (sec.widgetList.length) {
                    sec.widgetList.forEach((wid, widIndex) => {
                      wid.widgetPositionX =
                        firstElement.productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].widgetPositionX;
                      wid.widgetPositionY =
                        firstElement.productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].widgetPositionY;
                      wid.widgetSizeCols =
                        firstElement.productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].widgetSizeCols;
                      wid.widgetSizeRows =
                        firstElement.productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].widgetSizeRows;
                    });
                  }
                });
              }
            });
          }
        }
      });

    }
    // if (this.frCompleted && this.nlCompleted && this.enCompleted) {
    this.kpiCategory.languages.forEach(element => {
      element.productCategoryList.forEach(categoryItem => {
        categoryItem.sectionList.forEach(sectionItem => {
          const data = {
            widgetId: null,
            widgetType: 'title',
            widgetUrl: sectionItem.sectionTitle,
            widgetData: '',
            widgetPositionX: 0,
            widgetPositionY: 0,
            widgetSizeCols: 2,
            widgetSizeRows: 1,
            vizUrl: '',
            fileName: ''
          };

          const titleIndex = sectionItem.widgetList.findIndex(item => item.widgetType === 'title');
          if (titleIndex === -1) {
            sectionItem.widgetList.unshift(data);
          } else {
            sectionItem.widgetList[titleIndex].widgetUrl = sectionItem.sectionTitle;
          }
        });
      });
    });
    // this.nextStep.emit({ product: this.kpiCategory, type: value, charts: this.allSelectedCharts });
    // } else {
    //   this.notificationService.showError('please fill info for three languages');
    //   // return;
    // }
    // kpiCategory
    return { product: this.kpiCategory, isValid: true, charts: this.allSelectedCharts };

  }


  emptyObject(obj: any) {
    // tslint:disable-next-line: forin
    {
      for (const k in obj) {
        if (obj[k] instanceof Object) {
          this.emptyObject(obj[k]);
        } else {
          // document.write(obj[k] + '<br>');
          // if (typeof obj[k] === 'string') {
          // if (obj[k] === '' || obj[k] === ' ') {
          // delete obj[k];
          // } else {
          obj[k] = '';
          // }
          // }
        }
      }
    }
    return obj;
  }

  addElementToArray(value, categoryIndex?, sectionIndex?, type?) {
    // console.log(this.product, 'original product');
    this.kpiCategory.languages.forEach(element => {
      // element.language !== this.selectedTabLanguage &&
      if (element.language !== this.selectedTabLanguage && element.productCategoryList.length) {
        // console.log('element', element)
        switch (value) {
          case 'category':
            element.productCategoryList.push({ categoryName: '', open: false, sectionList: [] });
            break;
          case 'section':
            element
              .productCategoryList[categoryIndex]
              .sectionList.push({ sectionTitle: '', openOtherOptions: false, widgetList: [] });
            break;
          case 'widget':
            const widgetData = {
              widgetId: null,
              widgetType: type,
              widgetUrl: '',
              widgetData: '',
              widgetPositionX: 0,
              widgetPositionY: 0,
              widgetSizeCols: 2,
              widgetSizeRows: 3,
              vizUrl: '',
              fileName: ''
            };
            if (type === 'vizLink' || type === 'webpage' || type === 'title') {

              widgetData.widgetPositionX = 0;
              widgetData.widgetPositionY = 0;
              widgetData.widgetSizeCols = 2;
              widgetData.widgetSizeRows = 1;

            }
            element
              .productCategoryList[categoryIndex]
              .sectionList[sectionIndex]
              .widgetList.push(widgetData);

            break;
        }
        // ['fr', 'nl', 'en'].forEach(lang => {
        //   if (lang !== this.selectedTabLanguage) { this.setDataOnLangSwitch(lang); }
        // })
        this.checkLanguageCompleteness();
      }
    });
    // console.log('this.kpiCategory', this.kpiCategory)
  }


  removeElementFromArray(value, categoryIndex?, sectionIndex?, widgetIndex?) {
    // console.log('value, categoryIndex?, sectionIndex?, widgetIndex?', value, categoryIndex, sectionIndex, widgetIndex)
    this.kpiCategory.languages.forEach(element => {
      // element.language !== this.selectedTabLanguage &&
      if (element.language !== this.selectedTabLanguage && element.productCategoryList.length) {
        // console.log('element', element)
        switch (value) {
          case 'category':
            element.productCategoryList.splice(categoryIndex, 1);
            break;
          case 'section':
            element
              .productCategoryList[categoryIndex]
              .sectionList.splice(sectionIndex, 1);
            break;
          case 'widget':
            const widgetToRemove = element
              .productCategoryList[categoryIndex]
              .sectionList.length && element
                .productCategoryList[categoryIndex]
                .sectionList[sectionIndex]
                .widgetList.length && element
                  .productCategoryList[categoryIndex]
                  .sectionList[sectionIndex]
                  .widgetList[widgetIndex] || undefined;
            // console.log('element.language', element.language);
            // console.log('widgetToRemove', widgetToRemove)
            // if (widgetToRemove && widgetToRemove.widgetType === 'chart') {
            //   console.log('removing chartssssssssssss')
            //   console.log('this.allSelectedCharts', this.allSelectedCharts)
            //   // const index =
            // tslint:disable-next-line: max-line-length
            //   //   this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'].findIndex(item => item.contentUrl === widgetToRemove.widgetUrl);
            // tslint:disable-next-line: max-line-length
            //   //   console.log('this.allSelectedCharts[this.selectedTabLanguage + \'SelectedCharts\']', this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'][index])
            //   // if (index !== -1) {
            //   //   this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'].splice(index, 1);
            //   // }

            //   const index2 =
            // tslint:disable-next-line: max-line-length
            //     this.allSelectedCharts[element.language + 'SelectedCharts'].findIndex(item => item.contentUrl === widgetToRemove.widgetUrl);
            // tslint:disable-next-line: max-line-length
            //   console.log('this.allSelectedCharts[this.selectedTabLanguage + \'SelectedCharts\']', this.allSelectedCharts[element.language + 'SelectedCharts'][index2])
            //   if (index2 !== -1) {
            //     this.allSelectedCharts[element.language + 'SelectedCharts'].splice(index2, 1);
            //   }
            // }
            const widgetData = {
              widgetId: null,
              widgetType: '',
              widgetUrl: '',
              widgetData: '',
              widgetPositionX: 0,
              widgetPositionY: 0,
              widgetSizeCols: 2,
              widgetSizeRows: 3,
              vizUrl: ''
            };
            if (widgetToRemove) {
              element
                .productCategoryList[categoryIndex]
                .sectionList[sectionIndex]
                .widgetList.splice(widgetIndex, 1);

              // if (element.productCategoryList[categoryIndex].sectionList[sectionIndex].widgetList.length === 1) {
              //   if (element.productCategoryList[categoryIndex].sectionList[sectionIndex].widgetList[0].widgetType === 'title') {
              //     this.removeElementFromArray('widget', categoryIndex, sectionIndex, 0)
              //   }
              // }
            }
            break;
        }
        // ['fr', 'nl', 'en'].forEach(lang => {
        //   if (lang !== this.selectedTabLanguage) { this.setDataOnLangSwitch(lang); }
        // })
        this.checkLanguageCompleteness();
      }
      // console.log('this.categoryForm', this.categoryForm.value)
      // if (element.productCategoryList.length) {
      //   element.productCategoryList.forEach((cat, catIndex) => {
      //     if (cat.sectionList.length) {
      //       cat.sectionList.forEach((sec, secIndex) => {
      //         if (sec.widgetList.length) {
      //           if (sec.widgetList.length === 1) {
      //             if (sec.widgetList[0].widgetType === 'title') {
      //               sec.widgetList = [];
      //             }
      //           }
      //         }
      //       })
      //     }
      //   })
      // }
    });
  }

  onFileSelected(event: any, section: any, categoryIndex?: any, sectionIndex?: any, widgetIndex?: any) {
    // console.log('section', section)
    // console.log('widgetIndex', widgetIndex)
    // console.log('sectionIndex', sectionIndex)
    // console.log('categoryIndex', categoryIndex)
    // console.log('event', event);
    if (event && event[0]) {
      // console.log('section', section);
      // console.log('event', event);
      if (section === 'image') {
        this.getImageAsDataUrl(event[0], section, categoryIndex, sectionIndex, widgetIndex);
      }
      if (section === 'document') {
        this.getImageAsDataUrl(event[0], section, categoryIndex, sectionIndex, widgetIndex);
      }
    }
    // console.log('this.uploader', this.uploader);
  }

  getImageAsDataUrl(file: any, section, categoryIndex, sectionIndex, widgetIndex) {
    // console.log('file', file)
    if (section === 'image') {
      if (!file.type.includes('image/')) {
        // this.notificationService.showError('File type should be image');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Viz.FileTypeImage', 'ERROR');
        return;
      }
    }
    if (section === 'document') {
      if (file.type !== 'application/pdf') {
        // this.notificationService.showError('File type should be pdf');
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Product.PdfRequired', 'ERROR');
        return;
      }
    }
    const reader = new FileReader();
    let fileAsDataUrl: any = '';
    reader.addEventListener(
      'load',
      () => {

        const dataUrl = reader.result;
        fileAsDataUrl = dataUrl.toString();
        const data: any = this.sanitizer.bypassSecurityTrustResourceUrl(fileAsDataUrl);
        if (widgetIndex !== undefined && widgetIndex !== '') {
          (((this.categoryForm.get('category') as FormArray)
            .at(categoryIndex).get('sectionList') as FormArray)
            .at(sectionIndex).get('widget') as FormArray)
            .at(widgetIndex).get('dataUrl').setValue(data.changingThisBreaksApplicationSecurity);

          (((this.categoryForm.get('category') as FormArray)
            .at(categoryIndex).get('sectionList') as FormArray)
            .at(sectionIndex).get('widget') as FormArray)
            .at(widgetIndex).get('fileName').setValue(file.name);
        } else {

          (((this.categoryForm.get('category') as FormArray)
            .at(categoryIndex).get('sectionList') as FormArray)
            .at(sectionIndex).get('widget') as FormArray)
            .at(
              (((this.categoryForm.get('category') as FormArray)
                .at(categoryIndex).get('sectionList') as FormArray)
                .at(sectionIndex).get('widget') as FormArray).length - 1
            ).get('dataUrl').setValue(data.changingThisBreaksApplicationSecurity);

          (((this.categoryForm.get('category') as FormArray)
            .at(categoryIndex).get('sectionList') as FormArray)
            .at(sectionIndex).get('widget') as FormArray)
            .at(
              (((this.categoryForm.get('category') as FormArray)
                .at(categoryIndex).get('sectionList') as FormArray)
                .at(sectionIndex).get('widget') as FormArray).length - 1
            ).get('fileName').setValue(file.name);
        }
      },
      false
    );
    if (file) {
      reader.readAsDataURL(file);
    }
    this.uploader.queue = [];
  }

  fileInputClick(index) {
    // console.log('index', index)
    // console.log('this.fileInputs', this.fileInputs)
    const arr = this.fileInputs.toArray();
    const arr2 = this.fileInputTag.toArray();
    // console.log('arr2', arr2);
    // console.log('arr', arr)
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < arr2.length; i++) {
      // console.log('arr2[i].nativeElement.htmlFor', arr2[i].nativeElement.htmlFor);
      if (arr2[i].nativeElement.id === index) {
        // console.log('arr2[i].nativeElement.value', arr2[i].nativeElement.value);
        if (arr2[i].nativeElement.value) { arr2[i].nativeElement.value = ''; }
      }
    }
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < arr.length; i++) {
      if (arr[i].nativeElement.htmlFor === index) {
        arr[i].nativeElement.click();
        // console.log('arr[i].nativeElement', arr[i].nativeElement);
        // console.log('arr[i].nativeElement.children', arr[i].nativeElement.children[0]);
        break;
      }
    }

  }

  cleanCategoryList(categoryList) {
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < categoryList.length; i++) {
      if (!categoryList[i].sectionList.length) {
        categoryList.splice(i, 1);
      }
    }
  }

  checkLanguageCompleteness() {
    // console.log('checkLanguageCompleteness');
    let checkAll = true;
    ['fr', 'nl', 'en'].forEach(lang => {
      // console.log('lang', lang);
      // console.log('this.kpiCategory', this.kpiCategory);
      const frIndex = this.kpiCategory.languages.findIndex(item => item.language === lang);
      if (frIndex !== -1) {
        if (this.kpiCategory.languages[frIndex].productCategoryList.length) {
          for (const category of this.kpiCategory.languages[frIndex].productCategoryList) {
            if (!category.categoryName) {
              // console.log('no cat name for', lang)
              this.updateLangFlag(lang, false);
              checkAll = false;
              return;
            } else {
              this.updateLangFlag(lang, true);
            }
            if (!category.sectionList.length) {
              // console.log('no sec for', lang)
              this.updateLangFlag(lang, false);
              checkAll = false;
              return;
            } else {
              this.updateLangFlag(lang, true);
            }

            if (category.sectionList.length) {
              for (const section of category.sectionList) {
                if (!section.sectionTitle) {
                  // console.log('no section title for', lang)
                  this.updateLangFlag(lang, false);
                  checkAll = false;
                  return;
                } else {
                  this.updateLangFlag(lang, true);
                }
                const widgetList = section.widgetList.filter(item => item.widgetType !== 'title');
                if (!widgetList.length) {
                  // console.log('no wid for', lang)
                  this.updateLangFlag(lang, false);
                  checkAll = false;
                  return;
                } else {
                  this.updateLangFlag(lang, true);
                }
                if (section.widgetList.length) {
                  const widgetLists = section.widgetList.filter(item => item.widgetType !== 'title');
                  for (const widget of widgetLists) {

                    if (true) {
                      if ((!widget.widgetUrl && widget.widgetUrl === '')) {
                        // console.log('no wudgetUrl for', lang)
                        // console.log('widget.widgetUrl', widget.widgetUrl);
                        this.updateLangFlag(lang, false);
                        checkAll = false;
                        return 0;
                      } else {
                        this.updateLangFlag(lang, true);
                      }
                    }

                  }
                }
              }
            }
          }
        } else {
          this.updateLangFlag(lang, false);
          checkAll = false;
          return;
        }
      }
      // const index = this.kpiCategory.languages.findIndex(item => item.language === lang);
      // const categories = this.kpiCategory.languages[index].productCategoryList;
      // for (const category of categories) {
      //   const sections = category.sectionList;
      //   for (const section of sections) {
      //     const widgets = section.widgetList;
      //     for (const widget of widgets) {
      //       if (widget.vizUrl) {
      //         // this.isVizUrlPresent(index, true);
      //         this.updateLangFlag(lang, true);
      //       } else {
      //         // this.isVizUrlPresent(index, false)
      //         this.updateLangFlag(lang, false);
      //       }
      //     }
      //   }
      // }
    });
    // console.log('this.productType', this.productType)
    // console.log('this.product OG', this.product)
    if ((this.productType === 'public' || this.productType === 'private') && checkAll) {
      this.isVizUrlPresent();
    }


  }

  // check if viz url is present for a widget in three languages
  isVizUrlPresent() {
    const indices = ['fr', 'nl', 'en'];

    // const i = indices.findIndex(item => item === index);
    // indices.splice(i, 1);

    indices.forEach((lang) => {

      const otherIndex = this.kpiCategory.languages.findIndex(item => item.language === lang);
      const categories = this.kpiCategory.languages[otherIndex].productCategoryList;
      // tslint:disable-next-line: prefer-for-of
      for (let i = 0; i < categories.length; i++) {
        const sections = categories[i].sectionList;
        // tslint:disable-next-line: prefer-for-of
        for (let j = 0; j < sections.length; j++) {
          const widgets = sections[j].widgetList;
          // tslint:disable-next-line: prefer-for-of
          for (let k = 0; k < widgets.length; k++) {
            if (widgets[k].widgetType === 'embedCode') {
              if (!this.checkAllLanguageValidity(otherIndex, i, j, k)) {
                return;
              }
            }
          }
        }
      }
    });


  }

  checkAllLanguageValidity(langIndex, catIndex, secIndex, widIndex) {

    const truthValues = {
      fr: false,
      nl: false,
      en: false
    };
    const frIndex = this.kpiCategory.languages.findIndex(item => item.language === 'fr');
    const nlIndex = this.kpiCategory.languages.findIndex(item => item.language === 'nl');
    const enIndex = this.kpiCategory.languages.findIndex(item => item.language === 'en');
    // tslint:disable-next-line: max-line-length
    // console.log('vizUrl', this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl)
    if (this.kpiCategory.languages[frIndex] &&
      this.kpiCategory.languages[frIndex].productCategoryList[catIndex] &&
      this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex] &&
      this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex] &&
      this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl &&
      this.urlPattern.test(
        this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl)) {
      truthValues.fr = true;
    } else {
      truthValues.fr = false;
    }
    // console.log('truthValues.fr', truthValues.fr)
    // console.log('truthValues.nl', truthValues.nl)
    // console.log('truthValues.en', truthValues.en)

    if (this.kpiCategory.languages[nlIndex] &&
      this.kpiCategory.languages[nlIndex].productCategoryList[catIndex] &&
      this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex] &&
      this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex] &&
      this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl &&
      this.urlPattern.test(
        this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl)) {
      truthValues.nl = true;
    } else {
      truthValues.nl = false;
    }

    if (this.kpiCategory.languages[enIndex] &&
      this.kpiCategory.languages[enIndex].productCategoryList[catIndex] &&
      this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex] &&
      this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex] &&
      this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl &&
      this.urlPattern.test(
        this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl)) {
      truthValues.en = true;
    } else {
      truthValues.en = false;

    }

    const frVizUrl = this.kpiCategory.languages[frIndex] &&
      this.kpiCategory.languages[frIndex].productCategoryList[catIndex] &&
      this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex] &&
      this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex] &&
      this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl || '';

    const nlVizUrl = this.kpiCategory.languages[nlIndex] &&
      this.kpiCategory.languages[nlIndex].productCategoryList[catIndex] &&
      this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex] &&
      this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex] &&
      this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl || '';

    const enVizUrl = this.kpiCategory.languages[enIndex] &&
      this.kpiCategory.languages[enIndex].productCategoryList[catIndex] &&
      this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex] &&
      this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex] &&
      this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl || '';


    // console.log('truthValues', truthValues)

    if (truthValues.fr || truthValues.en || truthValues.nl) {
      if (truthValues.fr) {
        this.updateLangFlag('fr', true);
      } else {
        this.updateLangFlag('fr', false);
        // return false;
      }
      if (truthValues.nl) {
        this.updateLangFlag('nl', true);
      } else {
        this.updateLangFlag('nl', false);
        // return false;
      }
      if (truthValues.en) {
        this.updateLangFlag('en', true);
      } else {
        this.updateLangFlag('en', false);
        // return false;
      }
      if (truthValues.fr && truthValues.nl && truthValues.en) {
        return true;
      }

      if (!truthValues.fr || !truthValues.nl && !truthValues.en) {
        return false;
      }


    }
    if (!truthValues.fr && !truthValues.nl && !truthValues.en &&
      (this.kpiCategory.languages[frIndex] &&
        this.kpiCategory.languages[frIndex].productCategoryList[catIndex] &&
        this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex] &&
        this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex] &&
        this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl &&
        this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl === '') &&
      (this.kpiCategory.languages[nlIndex] &&
        this.kpiCategory.languages[nlIndex].productCategoryList[catIndex] &&
        this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex] &&
        this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex] &&
        this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl &&
        this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl === '') &&
      (this.kpiCategory.languages[enIndex] &&
        this.kpiCategory.languages[enIndex].productCategoryList[catIndex] &&
        this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex] &&
        this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex] &&
        this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl &&
        this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl === '')) {
      this.updateLangFlag('fr', true);
      this.updateLangFlag('nl', true);
      this.updateLangFlag('en', true);
      return true;
    }


    if (!truthValues.fr &&
      (this.kpiCategory.languages[frIndex] &&
        this.kpiCategory.languages[frIndex].productCategoryList[catIndex] &&
        this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex] &&
        this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex] &&
        this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl &&
        this.kpiCategory.languages[frIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl.length > 0)) {
      this.updateLangFlag('fr', false);

    }

    if (!truthValues.nl &&
      (this.kpiCategory.languages[nlIndex] &&
        this.kpiCategory.languages[nlIndex].productCategoryList[catIndex] &&
        this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex] &&
        this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex] &&
        this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl &&
        this.kpiCategory.languages[nlIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl.length > 0)) {
      this.updateLangFlag('nl', false);

    }


    if (!truthValues.en &&
      (this.kpiCategory.languages[enIndex] &&
        this.kpiCategory.languages[enIndex].productCategoryList[catIndex] &&
        this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex] &&
        this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex] &&
        this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl &&
        this.kpiCategory.languages[enIndex].productCategoryList[catIndex].sectionList[secIndex].widgetList[widIndex].vizUrl.length > 0)) {
      this.updateLangFlag('en', false);

    }

    if (frVizUrl && (!nlVizUrl || !enVizUrl)) {
      if (!nlVizUrl) {
        this.updateLangFlag('nl', false);
      }
      if (!enVizUrl) {
        this.updateLangFlag('en', false);
      }
    }

    if (nlVizUrl && (!frVizUrl || !enVizUrl)) {
      if (!frVizUrl) {
        this.updateLangFlag('fr', false);
      }
      if (!enVizUrl) {
        this.updateLangFlag('en', false);
      }
    }

    if (enVizUrl && (!frVizUrl || !nlVizUrl)) {
      if (!frVizUrl) {
        this.updateLangFlag('fr', false);
      }
      if (!enVizUrl) {
        this.updateLangFlag('nl', false);
      }
    }



    // if (!truthValues.fr || !truthValues.nl || !truthValues.en) {
    //   if (!truthValues.fr) {
    //     this.updateLangFlag('fr', false)
    //   }
    //   if (!truthValues.nl) {
    //     this.updateLangFlag('nl', false)
    //   }
    //   if (!truthValues.en) {
    //     this.updateLangFlag('en', false)
    //   }
    //   return false;
    // }

  }

  updateLangFlag(lang, flag) {
    switch (lang) {
      case 'fr':
        // console.log('\'fr\'', 'fr')
        this.frCompleted = flag;
        break;
      case 'nl':
        // console.log('\'nl\'', 'nl')
        this.nlCompleted = flag;
        break;
      case 'en':
        // console.log('\'en\'', 'en')
        this.enCompleted = flag;
        break;
    }
    // console.log('this.frCompleted', this.frCompleted)
    // console.log('this.nlCompleted', this.nlCompleted)
    // console.log('this.enCompleted', this.enCompleted)
  }

  openCharts(template, categoryIndex?, sectionIndex?, type?) {
    // console.log(this.selectedTabLanguage)
    this.selectSingleChart = false;
    this.selectSingleChart = false;
    this.generalService.getCharts().subscribe(res => {
      // console.log('res', res);
      this.chartIndices = {
        category: categoryIndex,
        section: sectionIndex,
        widgetType: type
      };
      document.getElementsByTagName('body')[0].style.overflow = 'hidden';
      this.charts = res.value;
      // console.log('this.charts', this.charts)
      this.modalRef = this.modalService.show(template, {
        animated: true,
        backdrop: 'static',
        keyboard: false,
        class: 'custom-width'
      });
    });
  }

  openChartsForSingleWidget(template, categoryIndex, sectionIndex, widgetIndex) {
    // console.log('template, categoryIndex, sectionIndex, widgetIndex', template, categoryIndex, sectionIndex, widgetIndex)
    this.selectSingleChart = true;
    this.chartwidgetIndex = widgetIndex;
    // console.log(this.selectedTabLanguage)
    this.generalService.getCharts().subscribe(res => {
      // console.log('res', res);
      this.singleChartIndices = {
        category: categoryIndex,
        section: sectionIndex,
        widget: widgetIndex
        // widgetType: type
      };
      // console.log('this.singleChartIndice', this.singleChartIndices)
      document.getElementsByTagName('body')[0].style.overflow = 'hidden';
      this.charts = res.value;
      // console.log('this.charts', this.charts)
      this.modalRef = this.modalService.show(template, {
        animated: true,
        backdrop: 'static',
        keyboard: false,
        class: 'custom-width'
      });
    });
  }

  closeModal() {
    document.getElementsByTagName('body')[0].style.overflow = 'unset';
    this.modalRef.hide();

  }

  gotCharts(event) {
    // console.log('event', event);
    this.selectedCharts = event;
    // tslint:disable-next-line: max-line-length
    // console.log('this.allSelectedCharts[this.selectedTabLanguage + \'SelectedCharts\']', this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'])
    this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'] = event;
    // tslint:disable-next-line: max-line-length
    // console.log('this.allSelectedCharts[this.selectedTabLanguage + \'SelectedCharts\']', this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'])
    // console.log('this.allSelectedCharts', this.allSelectedCharts)
    this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'] =
      _.uniqBy(this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'], 'id');
    // this.closeModal();
    this.currentChartIndex = 0;
    let skipIndices = [];
    event.forEach((chart, chartIndex) => {
      // console.log('chart', chart)
      this.categoryForm.value.category.forEach(cat => {
        cat.sectionList.forEach(sec => {
          sec.widget.forEach(wid => {
            const index = this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts']
              .findIndex(item => item.contentUrl === wid.dataUrl);
            if (index !== -1) {
              skipIndices.push(index);
            }
          });
        });
      });
      skipIndices = Array.from(new Set(skipIndices));
      // console.log('skipIndices', skipIndices)
      if (!skipIndices.includes(chartIndex)) {
        if (!this.selectSingleChart) {
          this.addWidgetToForm(true, this.chartIndices.category, this.chartIndices.section, this.chartIndices.widgetType);
        }
        if (this.selectSingleChart) {
          // console.log('this.chartwidgetIndex', this.chartwidgetIndex)

          // console.log('this.currentChartIndex', this.currentChartIndex)
          // this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'][this.currentChartIndex]
          // tslint:disable-next-line: max-line-length
          // console.log('this.allSelectedCharts[this.selectedTabLanguage + \'SelectedCharts\'][this.currentChartIndex]', this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'][this.currentChartIndex])
          this.setChartToForm(this.chartwidgetIndex);
        }
      }
      // this.chartIndices.category += 1; this.chartIndices.section += 1;
      this.currentChartIndex = this.currentChartIndex + 1;
    });
  }

  setChartToForm(widIndex?) {
    // console.log('this.currentChartIndex', this.currentChartIndex);
    // console.log('this.selectedCharts', this.selectedCharts);
    // console.log('this.singleChartIndices', this.singleChartIndices)
    const categoryIndex = this.selectSingleChart ? this.singleChartIndices.category : this.chartIndices.category;
    // console.log('categoryIndex', categoryIndex)
    const sectionIndex = this.selectSingleChart ? this.singleChartIndices.section : this.chartIndices.section;
    // console.log('sectionIndex', sectionIndex)
    const widgetIndex = widIndex;
    // console.log('widgetIndex', widgetIndex)
    // tslint:disable-next-line: max-line-length
    // console.log('this.allSelectedCharts[this.selectedTabLanguage + \'SelectedCharts\'][this.currentChartIndex]', this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'])
    if (widgetIndex !== undefined && widgetIndex !== '') {
      (((this.categoryForm.get('category') as FormArray)
        .at(categoryIndex).get('sectionList') as FormArray)
        .at(sectionIndex).get('widget') as FormArray)
        .at(widgetIndex).get('dataUrl')
        .setValue(this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'][this.currentChartIndex] &&
          this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'][this.currentChartIndex].contentUrl || '');

      (((this.categoryForm.get('category') as FormArray)
        .at(categoryIndex).get('sectionList') as FormArray)
        .at(sectionIndex).get('widget') as FormArray)
        .at(widgetIndex).get('fileName')
        .setValue(this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'][this.currentChartIndex] &&
          this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'][this.currentChartIndex].name || '');
      this.clearUnnecessaryCharts();
    } else {

      (((this.categoryForm.get('category') as FormArray)
        .at(categoryIndex).get('sectionList') as FormArray)
        .at(sectionIndex).get('widget') as FormArray)
        .at(
          (((this.categoryForm.get('category') as FormArray)
            .at(categoryIndex).get('sectionList') as FormArray)
            .at(sectionIndex).get('widget') as FormArray).length - 1
        ).get('dataUrl')
        .setValue(this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'][this.currentChartIndex] &&
          this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'][this.currentChartIndex].contentUrl || '');

      (((this.categoryForm.get('category') as FormArray)
        .at(categoryIndex).get('sectionList') as FormArray)
        .at(sectionIndex).get('widget') as FormArray)
        .at(
          (((this.categoryForm.get('category') as FormArray)
            .at(categoryIndex).get('sectionList') as FormArray)
            .at(sectionIndex).get('widget') as FormArray).length - 1
        ).get('fileName')
        .setValue(this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'][this.currentChartIndex] &&
          this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'][this.currentChartIndex].name || '');
    }
  }

  toggleCategoryDropDown(index) {
    (this.categoryForm.get('category') as FormArray).at(index).get('open')
      .setValue(!(this.categoryForm.get('category') as FormArray).at(index).get('open').value);
  }

  addOtherOpen(categoryIndex, sectionIndex) {
    ((this.categoryForm.get('category') as FormArray)
      .at(categoryIndex).get('sectionList') as FormArray)
      .at(sectionIndex).get('openOtherOptions').setValue(true);
  }

  onChange(event) {
    // console.log('event', event);
    event.srcElement.value = '';
    event.target.value = '';
  }
  clearUnnecessaryCharts() {
    const chartUrls = [];
    const selectCharts = this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'];
    // console.log('this.categoryForm.value', this.categoryForm)
    this.categoryForm.value.category.forEach(cat => {
      cat.sectionList.forEach(sec => {
        sec.widget.forEach(wid => {
          // console.log('wid', wid)
          if (wid.type === 'chart') {
            chartUrls.push(wid.dataUrl);
          }
        });
      });
    });
    selectCharts.forEach((chart, index) => {
      if (!chartUrls.includes(chart.contentUrl)) {
        this.allSelectedCharts[this.selectedTabLanguage + 'SelectedCharts'].splice(index, 1);
      }
    });
  }

  ngOnDestroy() {
    this.updateOriginalProduct();
  }

  updateOriginalProduct() {
    // modified original product according to current step four
    ['fr', 'en', 'nl'].forEach(lang => {
      const proIndex = this.product.productDetailsList.findIndex(item => item.language === lang);
      const kpiIndex = this.kpiCategory.languages.findIndex(item => item.language === lang);
      if (proIndex !== -1 && this.product.productDetailsList[proIndex]) {
        this.product.productDetailsList[proIndex].productCategoryList = this.kpiCategory.languages[kpiIndex].productCategoryList;
      }
    });
  }



}
