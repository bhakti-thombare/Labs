import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductStepFourFormComponent } from './product-step-four-form.component';

describe('ProductStepFourFormComponent', () => {
  let component: ProductStepFourFormComponent;
  let fixture: ComponentFixture<ProductStepFourFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductStepFourFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductStepFourFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
