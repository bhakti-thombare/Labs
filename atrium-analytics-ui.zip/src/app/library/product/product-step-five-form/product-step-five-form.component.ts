import { Component, OnInit, EventEmitter, Input, OnChanges, TemplateRef, Output, OnDestroy, ChangeDetectorRef, ElementRef } from '@angular/core';
import {
  GridsterConfig,
  GridsterItem,
  DisplayGrid,
  GridType,
  CompactType,
  GridsterItemComponentInterface,
  GridsterComponentInterface
} from 'angular-gridster2';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
// import { product as productObject } from '../../../../assets/product1';
import { GeneralService } from '../../shared/general-service.service';
import { ActivatedRoute } from '@angular/router';
// import * as lz from 'lz-string';
import { SharedDataServiceService } from 'src/app/core/services/shared-data-service.service';
import { BehaviorSubject, Observable } from 'rxjs';
@Component({
  selector: 'ab-product-step-five-form',
  templateUrl: './product-step-five-form.component.html',
  styleUrls: ['./product-step-five-form.component.scss'],
  // tslint:disable-next-line: no-host-metadata-property
  // host: {
  //   '(document:click)': 'onMouseDown($event)',
  //   '(document:mouseup)': 'onMouseUp($event)',
  // }
})
export class ProductStepFiveFormComponent implements OnInit, OnChanges, OnDestroy {
  modalRef: BsModalRef;
  userInterated = false;
  previousLanguage = 'fr';
  productHeight: number;
  listenGridChanges = true;
  frCompleted = false;
  nlCompleted = false;
  enCompleted = false;
  productType: any;
  showPreview: boolean;
  id: any;
  backupDashboard: {
    languages: Array<{ language: string, gridItems: Array<GridsterItem> }>
  };
  privateProductLanguagesAllowed = [];

  dashboardUpdated: any = new BehaviorSubject(this.backupDashboard);
  dashboardUpdated$: Observable<any> = this.dashboardUpdated.asObservable();
  constructor(
    private sharingDataService: SharedDataServiceService,
    private cdRef: ChangeDetectorRef,
    private generalService: GeneralService,
    private route: ActivatedRoute,
    private modalService: BsModalService) {
    ProductStepFiveFormComponent.that = this;
    this.dashboard = {
      languages: [
        {
          language: 'fr',
          gridItems: []
        },
        {
          language: 'nl',
          gridItems: []
        },
        {
          language: 'en',
          gridItems: []
        }
      ]
    };

    this.backupDashboard = {
      languages: [
        {
          language: 'fr',
          gridItems: []
        },
        {
          language: 'nl',
          gridItems: []
        },
        {
          language: 'en',
          gridItems: []
        }
      ]
    };
    this.dashboardUpdated$.subscribe(async (data) => {
      // console.log('updating dashboard');
      if (data) {
        // console.log('data', JSON.parse(JSON.stringify(data)));
        // console.log('data', data);
        this.sharingDataService.backupDashboard = data;
        // tslint:disable-next-line: no-shadowed-variable
        for await (const element of this.kpiCategory.languages) {
          for (let i = 0; i < element.productCategoryList.length; i++) {
            const categoryItem = element.productCategoryList[i];
            const categoryIndex = i;
            for (let j = 0; j < categoryItem.sectionList.length; j++) {
              const sectionItem = categoryItem.sectionList[j];
              const sectionIndex = j;
              for (let k = 0; k < sectionItem.widgetList.length; k++) {
                const widgetItem = sectionItem.widgetList[k];
                const widgetIndex = k;
                const gridElementId = categoryIndex + '' + sectionIndex + '' + widgetIndex;
                const langIndex = data.languages.findIndex(itemz => itemz.language === element.language);
                // console.log('langIndex', langIndex)
                if (langIndex !== -1) {
                  const index =
                    data.languages[langIndex].gridItems.findIndex(item => item.gridElementId === gridElementId);
                  // console.log('index', index)
                  // console.log('data.languages[langIndex].gridItems[index]', JSON.parse(JSON.stringify(data.languages[langIndex].gridItems[index])))
                  // console.log('widgetItem', widgetItem)
                  widgetItem.widgetPositionX = data.languages[langIndex].gridItems[index].x;
                  widgetItem.widgetPositionY = data.languages[langIndex].gridItems[index].y;
                  widgetItem.widgetSizeCols = data.languages[langIndex].gridItems[index].cols;
                  widgetItem.widgetSizeRows = data.languages[langIndex].gridItems[index].rows;
                }
              }
            }
          }
        }
        // this.catDetails=this.kpiCategory;
        this.sharingDataService.backupKpiCategory = JSON.parse(JSON.stringify(this.kpiCategory));
        // console.log('this.kpiCategory', this.kpiCategory)
      }
    });
  }
  // tslint:disable-next-line: member-ordering
  private static that: ProductStepFiveFormComponent;
  doc: any;
  @Input() product: any;
  @Input() privateProductLanguages: any;
  @Output() nextStep: EventEmitter<any> = new EventEmitter<any>();
  kpiCategory = {
    languages: [
      {
        language: 'fr',
        productName: '',
        productCategoryList: []
      },
      {
        language: 'nl',
        productName: '',
        productCategoryList: []

      },
      {
        language: 'en',
        productName: '',
        productCategoryList: []
      }
    ]
  };
  selectedTabLanguage = 'fr';
  updatedDashboard: {
    languages: Array<{ language: string, gridItems: Array<GridsterItem> }>
  };
  options: GridsterConfig;
  dashboard: {
    languages: Array<{ language: string, gridItems: Array<GridsterItem> }>
  };
  privateDashboard: {
    languages: Array<{ language: string, gridItems: Array<GridsterItem> }>
  };
  dashboardLanguageIndex: number;


  static itemChange(item, itemComponent) {
    // console.log('itemChanged', item, itemComponent);
    // console.log('ProductStepFiveFormComponent.that.userInterated', ProductStepFiveFormComponent.that.userInterated)
    const el = document.getElementById(item.gridElementId); //
    // console.log('el', el)
    // if (el) { el.style.pointerEvents = 'none'; }
    if (ProductStepFiveFormComponent.that.userInterated) {
      // console.log('item.gridElementId', item.gridElementId);
      for (const lang of ['fr', 'nl', 'en']) {
        const dashboardLangIndex = ProductStepFiveFormComponent.that.dashboard.languages
          .findIndex((dashItem: any) => dashItem.language === ProductStepFiveFormComponent.that.selectedTabLanguage);

        const updatedDashboardLangIndex = ProductStepFiveFormComponent.that.updatedDashboard.languages
          .findIndex((dashItem: any) => dashItem.language === lang);
        // const updatedDashboardgridIndex = ProductStepFiveFormComponent.that.updatedDashboard.languages[updatedDashboardLangIndex]
        //   .gridItems.findIndex(element => element.gridElementId === item.gridElementId)

        // ProductStepFiveFormComponent.that.dashboard.languages[dashboardLangIndex].gridItems.forEach(el => {
        //   if (el.gridElementId === item.gridElementId) {
        //     el.cols = item.cols;
        //     el.rows = item.rows;
        //     el.x = item.x;
        //     el.y = item.y;
        //   }
        // });
        // console.log('updatedDashboard.languages[updatedDashboardLangIndex].gridItems[updatedDashboardgridIndex]',
        //   JSON.parse(JSON.stringify(ProductStepFiveFormComponent.that.updatedDashboard
        //     .languages[updatedDashboardLangIndex])));

        for (const updatedDashboardElement of ProductStepFiveFormComponent.that.updatedDashboard.languages) {

          // console.log('--------------------------------------------------------------')
          // console.log('updatedDashboardElement', updatedDashboardElement);
          // console.log('dashboardElement', ProductStepFiveFormComponent.that.dashboard.languages[dashboardLangIndex]);
          // console.log('--------------------------------------------------------------')
          // if (ProductStepFiveFormComponent.that.selectedTabLanguage !== updatedDashboardElement.language) {
          for (const gridElement of updatedDashboardElement.gridItems) {
            const dashboardgridIndex = ProductStepFiveFormComponent.that.dashboard.languages[dashboardLangIndex]
              // tslint:disable-next-line: no-shadowed-variable
              .gridItems.findIndex(element => element.gridElementId === gridElement.gridElementId);
            const indexyz = itemComponent.gridster.grid.findIndex(gridEl => gridElement.gridElementId === gridEl.item.gridElementId);

            // console.log('gridElement.gridElementId', gridElement.gridElementId)
            // console.log('itemComponent.gridster.grid[indexyz].item', itemComponent.gridster.grid[indexyz].item.gridElementId)
            if (gridElement.gridElementId ===
              itemComponent.gridster.grid[indexyz].item.gridElementId) {


              // console.log('[dashboardgridIndex].y',
              //   ProductStepFiveFormComponent.that.dashboard.languages[dashboardLangIndex].gridItems[dashboardgridIndex].y);


              gridElement.cols =
                itemComponent.gridster.grid[indexyz].item.cols;
              gridElement.rows =
                itemComponent.gridster.grid[indexyz].item.rows;
              gridElement.x =
                itemComponent.gridster.grid[indexyz].item.x;
              gridElement.y =
                itemComponent.gridster.grid[indexyz].item.y;
            }
          }
          // }
          // console.log('updatedDashboardElement', updatedDashboardElement)
        }

        // ProductStepFiveFormComponent.that.updatedDashboard
        //   .languages[updatedDashboardLangIndex]
        //   .gridItems[updatedDashboardgridIndex].cols = item.cols;

        // ProductStepFiveFormComponent.that.updatedDashboard
        //   .languages[updatedDashboardLangIndex]
        //   .gridItems[updatedDashboardgridIndex].rows = item.rows;

        // ProductStepFiveFormComponent.that.updatedDashboard
        //   .languages[updatedDashboardLangIndex]
        //   .gridItems[updatedDashboardgridIndex].x = item.x;

        // ProductStepFiveFormComponent.that.updatedDashboard
        //   .languages[updatedDashboardLangIndex]
        //   .gridItems[updatedDashboardgridIndex].y = item.y;
        // tslint:disable-next-line: max-line-length
        // console.log('ProductStepFiveFormComponent.that.updatedDashboard', JSON.parse(JSON.stringify(ProductStepFiveFormComponent.that.updatedDashboard)))
      }
      ProductStepFiveFormComponent.that.backupDashboard = { ...ProductStepFiveFormComponent.that.updatedDashboard };
      ProductStepFiveFormComponent.that.dashboardUpdated.next(ProductStepFiveFormComponent.that.backupDashboard);
      // tslint:disable-next-line: max-line-length
      // console.log('lz.compress(JSON.stringify(ProductStepFiveFormComponent.that.backupDashboard))', lz.compress(JSON.stringify(ProductStepFiveFormComponent.that.backupDashboard)))
      // localStorage.setItem('backupDashboard', lz.compress(JSON.stringify(ProductStepFiveFormComponent.that.backupDashboard)));
      // storing back in shared service
      ProductStepFiveFormComponent.that.sharingDataService.backupDashboard = ProductStepFiveFormComponent.that.backupDashboard;
      // tslint:disable-next-line: max-line-length
      // console.log('ProductStepFiveFormComponent.that.sharingDataService.backupDashboard', JSON.parse(JSON.stringify(ProductStepFiveFormComponent.that.sharingDataService.backupDashboard)))
      ProductStepFiveFormComponent.that.dashboard = { ...ProductStepFiveFormComponent.that.updatedDashboard };
      // console.log('ProductStepFiveFormComponent.that.dashboard', ProductStepFiveFormComponent.that.dashboard)
      ProductStepFiveFormComponent.that.userInterated = false;
      ProductStepFiveFormComponent.that.setupPositions(true);
    }
  }

  static itemResize(item, itemComponent) {
    // console.log('itemResized', item, itemComponent);
    // const el = document.getElementById(item.gridElementId); //
    // if (el) { el.style.pointerEvents = 'none'; }
    // const content = document.getElementsByClassName('content')[0];
    // const gridster = document.getElementsByClassName('gridster')[0];
    // console.log('gridster', gridster)
    // console.log('gridster', gridster.clientHeight)
    // console.log('content', content)
    // console.log('content', content.clientHeight);
    // document.getElementById('myDiv').style.height = 500;
  }

  static gridSizeChanged(gridsterComponent: GridsterComponentInterface) {

    if (ProductStepFiveFormComponent.that.listenGridChanges) {
      // if (gridsterComponent.el.id === 'grister-element') {
      // console.log('gridsterComponent', gridsterComponent)
      const element = document.getElementById('gridster-content');
      if (element) {
        element.style.height = ((gridsterComponent.rows * 90.5) + 50.5) + 'px';
        // element.style.height = ((gridsterComponent.gridRows.length * 80.5) + 280) + 'px';
        // element.style.height = (element.clientHeight + 80.5) + 'px';
        // console.log('element.clientHeight', element.offsetHeight);
      }
      // console.log('element.style.height', element.style.height);
      // }}
    }
  }

  static stoppedDragging(item: GridsterItem, itemComponent: GridsterItemComponentInterface, event: MouseEvent) {
    // ProductStepFiveFormComponent.that.userInterated = false;
    // console.log('---------------------------------------------------------------');
    // console.log('END DRAGGING');
    // ProductStepFiveFormComponent.that.onMouseUp();
    const el = document.getElementById(item.gridElementId); //
    if (el) { el.style.pointerEvents = 'initial'; }
    const elements = document.getElementsByClassName('iframe-container');
    if (elements && elements.length) {
      // console.log('elements', elements)

      // tslint:disable-next-line: prefer-for-of
      for (let i = 0; i < elements.length; i++) {
        const element: HTMLElement = elements[i] as HTMLElement;
        if (element) {
          element.style.pointerEvents = 'initial';
        }
      }
    }
    // console.log('item', item);
    // console.log('itemComponent', itemComponent);
    // ['fr', 'nl', 'en'].forEach(lang => {
    //   const dashboardLangIndex = ProductStepFiveFormComponent.that.dashboard.languages
    //     .findIndex((dashItem: any) => dashItem.language === ProductStepFiveFormComponent.that.selectedTabLanguage);

    //   const updatedDashboardLangIndex = ProductStepFiveFormComponent.that.updatedDashboard.languages
    //     .findIndex((dashItem: any) => dashItem.language === lang);

    //   const dashboardgridIndex = ProductStepFiveFormComponent.that.dashboard.languages[dashboardLangIndex]
    //     .gridItems.findIndex(element => element.gridElementId === item.gridElementId)

    //   const updatedDashboardgridIndex = ProductStepFiveFormComponent.that.updatedDashboard.languages[updatedDashboardLangIndex]
    //     .gridItems.findIndex(element => element.gridElementId === item.gridElementId)

    //   ProductStepFiveFormComponent.that.updatedDashboard
    //     .languages[updatedDashboardLangIndex]
    //     .gridItems[updatedDashboardgridIndex].cols = ProductStepFiveFormComponent.that.dashboard
    //       .languages[dashboardLangIndex]
    //       .gridItems[dashboardgridIndex].cols;

    //   ProductStepFiveFormComponent.that.updatedDashboard
    //     .languages[updatedDashboardLangIndex]
    //     .gridItems[updatedDashboardgridIndex].rows = ProductStepFiveFormComponent.that.dashboard
    //       .languages[dashboardLangIndex]
    //       .gridItems[dashboardgridIndex].rows;

    //   ProductStepFiveFormComponent.that.updatedDashboard
    //     .languages[updatedDashboardLangIndex]
    //     .gridItems[updatedDashboardgridIndex].x = ProductStepFiveFormComponent.that.dashboard
    //       .languages[dashboardLangIndex]
    //       .gridItems[dashboardgridIndex].x;

    //   ProductStepFiveFormComponent.that.updatedDashboard
    //     .languages[updatedDashboardLangIndex]
    //     .gridItems[updatedDashboardgridIndex].y = ProductStepFiveFormComponent.that.dashboard
    //       .languages[dashboardLangIndex]
    //       .gridItems[dashboardgridIndex].y;
    // })
    // ProductStepFiveFormComponent.that.dashboard = { ...ProductStepFiveFormComponent.that.updatedDashboard };
    // console.log('event', event);
    // console.log('ProductStepFiveFormComponent.that.updatedDashboard', ProductStepFiveFormComponent.that.updatedDashboard)
    // console.log('---------------------------------------------------------------');
  }
  static stoppedResizing(item: GridsterItem, itemComponent: GridsterItemComponentInterface, event: MouseEvent) {
    // ProductStepFiveFormComponent.that.userInterated = false;
    // console.log('*****************************************************************************');
    // console.log('END RESIZING');
    const el = document.getElementById(item.gridElementId); //
    if (el) { el.style.pointerEvents = 'initial'; }
    const elements = document.getElementsByClassName('iframe-container');
    if (elements && elements.length) {
      // console.log('elements', elements)

      // tslint:disable-next-line: prefer-for-of
      for (let i = 0; i < elements.length; i++) {
        const element: HTMLElement = elements[i] as HTMLElement;
        if (element) {
          element.style.pointerEvents = 'initial';
        }
      }
    }
    // ProductStepFiveFormComponent.that.onMouseUp();
    // console.log('item', item);
    // console.log('itemComponent', itemComponent);
    // console.log('event', event);
    // console.log('ProductStepFiveFormComponent.that.updatedDashboard', ProductStepFiveFormComponent.that.updatedDashboard)
    // console.log('*****************************************************************************');
  }


  static startedDragging(item: GridsterItem, itemComponent: GridsterItemComponentInterface, event: MouseEvent) {
    ProductStepFiveFormComponent.that.userInterated = true;
    // console.log('---------------------------------------------------------------');
    // console.log('START DRAGGING');
    const el = document.getElementById(item.gridElementId); //
    if (el) { el.style.pointerEvents = 'none'; }
    const elements = document.getElementsByClassName('iframe-container');
    if (elements && elements.length) {
      // console.log('elements', elements)

      // tslint:disable-next-line: prefer-for-of
      for (let i = 0; i < elements.length; i++) {
        const element: HTMLElement = elements[i] as HTMLElement;
        if (element) {
          element.style.pointerEvents = 'none';
        }
      }
    }
    // console.log('item', item);
    // console.log('itemComponent', itemComponent);
    // console.log('event', event);
    // console.log('---------------------------------------------------------------');
  }
  static startedResizing(item: GridsterItem, itemComponent: GridsterItemComponentInterface, event: MouseEvent) {
    ProductStepFiveFormComponent.that.userInterated = true;
    // console.log('---------------------------------------------------------------');
    // console.log('START RESIZING');
    const el = document.getElementById(item.gridElementId); //
    if (el) { el.style.pointerEvents = 'none'; }
    const elements = document.getElementsByClassName('iframe-container');
    if (elements && elements.length) {
      // console.log('elements', elements)

      // tslint:disable-next-line: prefer-for-of
      for (let i = 0; i < elements.length; i++) {
        // tslint:disable-next-line: no-shadowed-variable
        const element: HTMLElement = elements[i] as HTMLElement;
        if (element) {
          element.style.pointerEvents = 'none';
        }
      }
    }
    // // const element = document.getElementById('gridster-element');
    // const element = document.getElementById('gridster-content');
    // element.style.height = (element.offsetHeight + 90.5) + 'px';
    // console.log('element.clientHeight', element.offsetHeight)
    // console.log('element.style.height', element.style.height);
    // // element1.style.height = (element.clientHeight + 80.5) + 'px';
    // console.log('gridster.rows', itemComponent.gridster.rows)
    // console.log('gridster.rows', itemComponent.gridster.gridRows, itemComponent.gridster.gridRows.length)
    // console.log('item', item);
    // console.log('itemComponent', itemComponent);
    // console.log('event', event);
    // console.log('---------------------------------------------------------------');
  }

  // static gridSizeChanged(item: GridsterComponentInterface) {
  //   console.log('item', item)

  // }

  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get('id');
    this.options = {
      gridType: GridType.VerticalFixed,
      displayGrid: DisplayGrid.Always,
      compactType: CompactType.CompactUp,
      swap: true,
      pushItems: true,
      pushDirections: { north: true, east: true, south: true, west: true },
      gridSizeChangedCallback: ProductStepFiveFormComponent.gridSizeChanged,
      // push: true,
      draggable: {
        delayStart: 0,
        enabled: true,
        start: ProductStepFiveFormComponent.startedDragging,
        stop: ProductStepFiveFormComponent.stoppedDragging
      },
      resizable: {
        handles: { n: true, e: true, w: true, ne: true, nw: true, s: true, se: true, sw: true },
        enabled: true,
        start: ProductStepFiveFormComponent.startedResizing,
        stop: ProductStepFiveFormComponent.stoppedResizing
      },
      pushResizeItems: true,
      pushing: true,
      sparse: false,
      defaultSizeX: 2, // the default width of a gridster item, if not specifed
      defaultSizeY: 1, // the default height of a gridster item, if not specified
      columns: 2, // the width of the grid, in columns
      // colWidth: '92.5', // can be an integer or 'auto'.  'auto' uses the pixel width of the element divided by 'columns'
      fixedRowHeight: 80.5, // can be an integer or 'match'.  Match uses the colWidth, giving you square widgets.
      margins: [10, 10], // the pixel distance between each widget
      minCols: 2,
      maxCols: 2,
      minRows: 1,
      maxRows: 100000,
      // maxItemCols: 100,
      // minItemCols: 1,
      // maxItemRows: 100,
      // minItemRows: 1,
      // maxItemArea: 250,
      // minItemArea: 1,
      defaultItemCols: 1,
      defaultItemRows: 3,
      itemChangeCallback: ProductStepFiveFormComponent.itemChange,
      itemResizeCallback: ProductStepFiveFormComponent.itemResize,
      // gridSizeChangedCallback: ProductStepFiveFormComponent.gridSizeChanged
    };

    // this.dashboard = [
    //   { cols: 1, rows: 3, y: 0, x: 0 },
    //   { cols: 1, rows: 3, y: 0, x: 0 },
    //   { cols: 1, rows: 3, y: 0, x: 0 },
    //   // { cols: 1, rows: 2, y: 0, x: 0 },
    //   // { cols: 1, rows: 1, y: 0, x: 0 },
    //   // { cols: 1, rows: 2, y: 0, x: 0 },
    //   // { cols: 1, rows: 1, y: 0, x: 0 },
    //   // { cols: 1, rows: 2, y: 0, x: 0 },
    //   // { cols: 1, rows: 1, y: 0, x: 0 },
    //   // { cols: 1, rows: 2, y: 0, x: 0 }
    // ];

  }



  ngOnChanges() {
    // this.product = productObject;
    if (this.product) {
      this.productType = this.product.productType;
      if (this.productType === 'private') {
        if (this.product.enCompleted) {
          this.selectedTabLanguage = 'en';
          // this.frCompleted = true;
          // this.nlCompleted = false;
          this.enCompleted = true;
        }
        if (this.product.nlCompleted) {
          this.selectedTabLanguage = 'nl';
          this.nlCompleted = true;
          // this.enCompleted = false;
          // this.frCompleted = false;
        }
        if (this.product.frCompleted) {
          this.selectedTabLanguage = 'fr';
          // this.nlCompleted = false;
          // this.enCompleted = true;
          this.frCompleted = true;
        }

        this.privateProductLanguagesAllowed = this.privateProductLanguages;
      }
      if (this.productType === 'public') {
        this.frCompleted = true;
        this.nlCompleted = true;
        this.enCompleted = true;
        this.selectedTabLanguage = 'fr';
      }
      console.log('this.product', this.product)
      this.kpiCategory.languages.forEach((element, kpiIndex) => {
        const index = this.product.productDetailsList.findIndex(item => item.language === element.language);
        if (index !== -1) {
          element.productName = this.product.productDetailsList[index].productName;
          element.productCategoryList = this.product.productDetailsList[index].productCategoryList;
        }

        if ((location.href.split('/').indexOf('product-edit') != -1)){
          element.productCategoryList.forEach(categoryItem => {
            categoryItem.sectionList.forEach(sectionItem => {
              const data = {
                widgetId: null,
                widgetType: 'title',
                widgetUrl: sectionItem.sectionTitle,
                widgetData: '',
                widgetPositionX: 0,
                widgetPositionY: 0,
                widgetSizeCols: 2,
                widgetSizeRows: 1,
                vizUrl: '',
                fileName: ''
              };
              const titleIndex = sectionItem.widgetList.findIndex(item => item.widgetType === 'title');
              if (titleIndex === -1) {
                sectionItem.widgetList.unshift(data);
              } else {
                if (titleIndex != 0) {
                  let item = sectionItem.widgetList.filter(item => item.widgetType === 'title')[0];
                  sectionItem.widgetList.splice(titleIndex, 1);
                  sectionItem.widgetList.unshift(item);
                  //sectionItem.widgetList.unshift(sectionItem.widgetList.splice(sectionItem.widgetList.findIndex(item => item.widgetType === 'title'), 1)[0])
                } else {
                  sectionItem.widgetList[titleIndex].widgetUrl = sectionItem.sectionTitle;
                }
              }
            })
          })
        }

        if (JSON.parse(sessionStorage.getItem('hasEdited')) && (location.href.split('/').indexOf('product-edit') != -1)) {
          let transformObj = [];
          this.product.productDetailsList[kpiIndex].productCategoryList.forEach(cat => {
            cat.sectionList.forEach(sec => {
              sec.widgetList.forEach(wid => {
                transformObj.push(wid);
              })
            })
          })

          transformObj.forEach((element, index) => {
            if (index == 0) {
              element.widgetPositionY = 0;
            } else {
              element.widgetPositionY = (transformObj[index - 1].widgetPositionY) + (transformObj[index - 1].widgetSizeRows);
            }
          })
          console.log("transform",transformObj);
        }

      });
      this.dashboardLanguageIndex = this.dashboard.languages.findIndex(item => item.language === this.selectedTabLanguage);
      this.setUpWidgets();
      // this.kpiCategory = this.product
    }
  }

  changedOptions() {
    this.options.api.optionsChanged();
  }

  removeItem(item) {
    // this.dashboard.splice(this.dashboard.indexOf(item), 1);
  }

  // addItem(value) {
  //   // this.dashboard.push({ cols: 2, rows: 1, x: 0, y: 0 });
  //   this.builtContent(value);
  // }


  // builtContent(value) {
  //   switch (value) {
  //     case 'embedCode':
  //       this.dashboard.push({
  //         cols: 2, rows: 1, x: 0, y: 0,
  //         data: { url: 'https://public.tableau.com/views/ExempleBLCvtestvincent/Communedistrict' }, type: 'embedCode'
  //       });
  //       break;
  //     case 'image':
  //       this.dashboard.push({
  //         cols: 2, rows: 1, x: 0, y: 0,
  //         data: { url: '/assets/login-img.jpg' }, type: 'image'
  //       });
  //       break;
  //     case 'video':
  //       this.dashboard.push({
  //         cols: 2, rows: 1, x: 0, y: 0,
  //         data: { url: 'https://youtube.com/embed/X5baFS11tU0' }, type: 'video'
  //       });
  //       break;
  //     case 'doc':
  //       this.dashboard.push({
  //         cols: 2, rows: 1, x: 0, y: 0,
  //         data: { url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' }, type: 'doc'
  //       });
  //       break;
  //     case 'webpage':
  //       this.dashboard.push({
  //         cols: 2, rows: 1, x: 0, y: 0,
  //         data: { url: 'https://google.com' }, type: 'webpage'
  //       });
  //       break;
  //     case 'vizurl':
  //       this.dashboard.push({
  //         cols: 2, rows: 1, x: 0, y: 0,
  //         data: { url: 'platformurl' }, type: 'vizurl'
  //       });
  //       break;

  //     case 'text':
  //       this.dashboard.push({
  //         cols: 2, rows: 1, x: 0, y: 0,
  //         data: { url: 'text', value: 'There is some text' }, type: 'text'
  //       });
  //       break;
  //   }
  // }

  onFileSelected(event: EventEmitter<File[]>) {
    // console.log('event', event)
    const file: File = event[0];
    // console.log(file);
    this.getImageAsDataUrl(file);
  }

  getImageAsDataUrl(file: any) {
    const reader = new FileReader();
    let imageAsDataUrl: any = '';
    reader.addEventListener(
      'load',
      () => {

        // convert image file to base64 string
        const imageData = reader.result;
        imageAsDataUrl = imageData.toString();
        this.doc = imageAsDataUrl;
        // return imageAsDataUrl;
      },
      false
    );
    if (file) {
      reader.readAsDataURL(file);
    }
  }

  setUpWidgets() {
    // const updatedDashIndex = this.dashboard.languages.findIndex(item => item.language === this.selectedTabLanguage);
    this.privateDashboard = JSON.parse(JSON.stringify(this.dashboard));
    this.kpiCategory.languages.forEach(element => {
      // if (element.language === this.selectedTabLanguage) {
      const dashIndex = this.dashboard.languages.findIndex(item => item.language === element.language);
      // console.log('this.privateDashboard', this.privateDashboard)
      for (let i = 0; i < element.productCategoryList.length; i++) {
        const category = element.productCategoryList[i];
        // const secData = {
        //   x: category.sectionList[0].widgetList[0].widgetPositionX,
        //   y: category.sectionList[0].widgetList[0].widgetPositionY-2,
        //   cols: category.sectionList[0].widgetList[0].widgetSizeCols,
        //   rows: category.sectionList[0].widgetList[0].widgetSizeRows,
        //   type: 'title',
        //   data: category.categoryName,
        //   gridElementId: i,
        //   hi: i+1
        // };
        // this.dashboard.languages[dashIndex].gridItems.push(secData);
        // this.backupDashboard.languages[dashIndex].gridItems.push(secData);
        for (let j = 0; j < category.sectionList.length; j++) {
          const section = category.sectionList[j];
          for (let k = 0; k < section.widgetList.length; k++) {
            const widget = section.widgetList[k];
            const data = {
              x: widget.widgetPositionX,
              y: widget.widgetPositionY,
              cols: widget.widgetSizeCols,
              rows: widget.widgetSizeRows,
              type: widget.widgetType,
              data: widget.widgetUrl,
              vizUrl: widget.vizUrl || '',
              gridElementId: i + '' + j + '' + k
            };
            this.backupDashboard.languages[dashIndex].gridItems.push(data);
            console.log("X :", data.x, "Y :", data.y);
            if (this.productType === 'public') { this.dashboard.languages[dashIndex].gridItems.push(data); }
            if (this.productType === 'private') {
              this.privateDashboard.languages[dashIndex].gridItems.push(data);
            }
          }

        }
      }
      // }
    });
    // this.catDetails.nativeElement=this.kpiCategory;
    // tslint:disable-next-line: max-line-length
    // console.log('lz.compress(JSON.stringify(ProductStepFiveFormComponent.that.backupDashboard))', lz.compress(JSON.stringify(ProductStepFiveFormComponent.that.backupDashboard)))
    // localStorage.setItem('backupDashboard', lz.compress(JSON.stringify(this.backupDashboard)));
    this.sharingDataService.backupDashboard = this.backupDashboard;
    this.updatedDashboard = { ...this.dashboard };
    console.log('this.dashboard', JSON.parse(JSON.stringify(this.dashboard)));
    console.log('this.dashboard', this.dashboard)
    if (this.productType === 'private') {
      this.getChartsUrl();
    }
  }

  switchLanguageTab(lang) {
    if (this.productType === 'private') {
      if (!this.privateProductLanguagesAllowed.includes(lang)) { return; }
    }
    this.previousLanguage = this.selectedTabLanguage;
    this.selectedTabLanguage = lang;
    // this.setUpWidgets();
    this.setupPositions();
    this.dashboardLanguageIndex = this.dashboard.languages.findIndex(item => item.language === this.selectedTabLanguage);
    // console.log(this.dashboard)
  }

  setupPositions(isWidgetModified?) {
    const index = this.dashboard.languages.findIndex(item => item.language === this.previousLanguage);
    // console.log('this.dashboard.languages[this.previousLanguage]',
    // JSON.parse(JSON.stringify(this.dashboard.languages[index])));
    if (this.productType === 'public') {
      const previousLangObject = { ...this.dashboard.languages[index] };
      const otherLanguageObjects: any = {};
      otherLanguageObjects.languages = this.dashboard.languages.filter(item => item.language !== this.previousLanguage);
      // console.log('otherLanguageObjects', otherLanguageObjects)

      otherLanguageObjects.languages.forEach(object => {
        previousLangObject.gridItems.forEach(prevObject => {
          const objIndex = object.gridItems.findIndex(item => item.gridElementId === prevObject.gridElementId);

          if (prevObject.gridElementId === object.gridItems[objIndex].gridElementId) {
            object.gridItems[objIndex].cols = prevObject.cols;
            object.gridItems[objIndex].rows = prevObject.rows;
            object.gridItems[objIndex].x = prevObject.x;
            object.gridItems[objIndex].y = prevObject.y;

          }
        });
      });
    }

    if (this.productType === 'private') {
      const previousLangObject = { ...this.dashboard.languages[index] };
      const otherLanguageObjects: any = {};
      otherLanguageObjects.languages = this.dashboard.languages.filter(item => item.language !== this.previousLanguage);
      // console.log('otherLanguageObjects', otherLanguageObjects)

      otherLanguageObjects.languages.forEach(object => {
        if (object.gridItems.length) {
          previousLangObject.gridItems.forEach(prevObject => {
            const objIndex = object.gridItems.findIndex(item => item.gridElementId === prevObject.gridElementId);

            if (prevObject.gridElementId === object.gridItems[objIndex].gridElementId) {
              object.gridItems[objIndex].cols = prevObject.cols;
              object.gridItems[objIndex].rows = prevObject.rows;
              object.gridItems[objIndex].x = prevObject.x;
              object.gridItems[objIndex].y = prevObject.y;

            }
          });
        }
      });
    }

    // update product
    // tslint:disable-next-line: no-shadowed-variable
    this.product.productDetailsList.forEach(elementCat => {
      elementCat.productCategoryList.forEach((categoryItem, categoryIndex) => {
        categoryItem.sectionList.forEach((sectionItem, sectionIndex) => {
          sectionItem.widgetList.forEach((widgetItem, widgetIndex) => {
            const gridElementId = categoryIndex + '' + sectionIndex + '' + widgetIndex;
            // console.log('gridElementId', gridElementId)
            if (this.productType === 'public') {
              // console.log('this.dashboard.languages[0].gridItems', this.dashboard.languages[0].gridItems)
              // tslint:disable-next-line: max-line-length
              const index2 = this.dashboard.languages[0].gridItems.findIndex(item => item.gridElementId.toString() === gridElementId.toString());
              // console.log('this.dashboard.languages[0].gridItems[index2]', this.dashboard.languages[0].gridItems[index2])
              widgetItem.widgetPositionX = this.dashboard.languages[0].gridItems[index2].x;
              widgetItem.widgetPositionY = this.dashboard.languages[0].gridItems[index2].y;
              widgetItem.widgetSizeCols = this.dashboard.languages[0].gridItems[index2].cols;
              widgetItem.widgetSizeRows = this.dashboard.languages[0].gridItems[index2].rows;
            }
            if (this.productType === 'private') {
              // console.log('this.privateProductLanguagesAllowed', this.privateProductLanguagesAllowed)
              this.privateProductLanguagesAllowed.forEach(lang => {
                const indexp = this.dashboard.languages.findIndex(item => item.language === this.selectedTabLanguage);
                const index2 = this.dashboard.languages[indexp].gridItems.findIndex(item => item.gridElementId === gridElementId);
                if (index2 !== -1) {
                  // console.log('this.dashboard.languages[indexp].gridItems', this.dashboard.languages[indexp].gridItems)
                  // console.log('this.dashboard.languages[indexp].gridItems[index2]', this.dashboard.languages[indexp].gridItems[index2])
                  widgetItem.widgetPositionX = this.dashboard.languages[indexp].gridItems[index2].x;
                  widgetItem.widgetPositionY = this.dashboard.languages[indexp].gridItems[index2].y;
                  widgetItem.widgetSizeCols = this.dashboard.languages[indexp].gridItems[index2].cols;
                  widgetItem.widgetSizeRows = this.dashboard.languages[indexp].gridItems[index2].rows;
                }
              });
            }
          });
        });
      });
    });
    // if (this.productType === 'private') {
    //   const backupDashboard = JSON.parse(localStorage.getItem('backupDashboard'));
    //   const backupDashboardIndex = backupDashboard.languages.findIndex(item => item.gridItems.length);
    //   console.log(backupDashboard.languages[backupDashboardIndex])
    //   this.dashboard.languages.forEach(element => {
    //     // const index = backupDashboard.languages[backupDashboardIndex].gridItems.findIndex
    //     if (element.gridItems.length) {
    //       element.gridItems.forEach((gridElement, gridIndex) => {
    //         gridElement.cols = backupDashboard.languages[backupDashboardIndex].gridItems[gridIndex].cols;
    //         gridElement.rows = backupDashboard.languages[backupDashboardIndex].gridItems[gridIndex].rows;
    //         gridElement.x = backupDashboard.languages[backupDashboardIndex].gridItems[gridIndex].x;
    //         gridElement.y = backupDashboard.languages[backupDashboardIndex].gridItems[gridIndex].y;
    //       });
    //     }
    //   });

    // }
    // console.log('this.dashboard.languages', this.dashboard.languages)
    if (this.productType === 'private') { this.privateDashboard = this.dashboard; }
    // console.log('this.product.productDetailsList', this.product.productDetailsList)
    if (this.productType === 'private' && !isWidgetModified) {
      let callGetCharts = false;
      // console.log('this.dashboard', this.dashboard)
      const firstIndex = this.dashboard.languages.findIndex(item => item.language === this.privateProductLanguagesAllowed[0]);
      if (firstIndex !== -1) {
        for (const gridItem of this.dashboard.languages[firstIndex].gridItems) {
          if (gridItem.type === 'chart') {
            callGetCharts = true;
            break;
          }
        }
        if (callGetCharts) {
          this.getChartsUrl();
        }
      }
    }
    // this.dashboardUpdated.next(this.dashboard);
    // console.log('this.productzxxxxxxxxx', this.product)
    // this.catDetails.nativeElement=this.product;
  }

  enablePointer(widgteId: string) {
    const el = document.getElementById(widgteId);
    el.style.pointerEvents = 'initial';
  }


  openPreview(template: TemplateRef<any>) {
    this.listenGridChanges = false;
    this.showPreview = true;
    // console.log('productHeight', this.productHeight)
    // console.log('product', this.product)
    // console.log('updatedDashboard', this.updatedDashboard)
    // console.log('kpiCategory', this.kpiCategory)
    // console.log('this.sharingDataService.backupDashboard', this.sharingDataService.backupDashboard)
    document.getElementsByTagName('body')[0].style.overflow = 'hidden';
    this.productHeight = document.getElementById('gridster-content').offsetHeight;
    if (this.productType === 'private') {

    }
    this.modalRef = this.modalService.show(template, {
      animated: true,
      backdrop: 'static',
      keyboard: false,
      class: 'custom-width overflow-modal-custom'
    });
    this.cdRef.detectChanges();
  }

  closeModal() {
    document.getElementsByTagName('body')[0].classList.remove('hidden-overflow');
    document.getElementsByTagName('body')[0].style.overflow = 'unset';
    this.modalRef.hide();
    this.listenGridChanges = true;
    this.showPreview = false;
    // console.log('this.sharingDataService.backupDashboard', this.sharingDataService.backupDashboard)
    this.dashboard = this.sharingDataService.backupDashboard;
    this.switchLanguageTab(this.selectedTabLanguage);
    // console.log('this.product', this.product)
    // console.log('this.dashboard', this.dashboard)
    // console.log('this.updatedDashboard', this.updatedDashboard)
    // console.log('this.backupDashboard', this.backupDashboard)
    // console.log(lz.decompress(localStorage.getItem('backupDashboard')));
    // console.log('this.sharingDataService.backupDashboard', this.sharingDataService.backupDashboard)
    this.dashboard = this.sharingDataService.backupDashboard; // JSON.parse(lz.decompress(localStorage.getItem('backupDashboard')))
    if (this.productType === 'private') {
      this.privateDashboard = JSON.parse(JSON.stringify(this.dashboard));
      this.getChartsUrl();
    }
  }


  submit(value) {
    // this.updatedDashboard
    // this.product
    // console.log('this.product', this.product)
    // console.log('this.updatedDashboard', this.updatedDashboard)
    // if (value === 'nextStep') {
    if (this.productType === 'private') {
      const index = this.updatedDashboard.languages.findIndex(item => item.language === this.selectedTabLanguage);
      this.updatedDashboard.languages[index].gridItems.forEach(element => {
        element.data = '/views/' + (element.data.split('/views/').pop());
      });
    }
    this.nextStep.emit({ product: this.updatedDashboard, type: value });
    // }
  }

  checkValidityBeforeMoving() {
    // this.updatedDashboard
    // this.product
    // console.log('this.product', this.product)
    // console.log('this.updatedDashboard', this.updatedDashboard)
    // if (value === 'nextStep') {
    if (this.productType === 'private') {
      const index = this.updatedDashboard.languages.findIndex(item => item.language === this.selectedTabLanguage);
      this.updatedDashboard.languages[index].gridItems.forEach(element => {
        element.data = '/views/' + (element.data.split('/views/').pop());
      });
    }
    return { product: this.updatedDashboard, isValid: true };
    // }
  }

  getChartsUrl() {
    // console.log('this.privateDashboard', this.privateDashboard)
    const index = this.privateDashboard.languages.findIndex(item => item.language === this.selectedTabLanguage);
    const data = [];
    this.privateDashboard.languages[index].gridItems.forEach(element => {
      if (element.type === 'chart') {
        if (element.data.includes('https') || element.data.includes('http')) {
          element.data = '/views/' + (element.data.split('/views/').pop());
        }
        data.push(element.data);
      }
    });
    // console.log('data', data)
    data.forEach(element => {
      // console.log('element', element)
      if (element.includes('https') || element.includes('http')) {
        element = '/views/' + (element.split('/views/').pop());
      }
    });
    // console.log('request going in data', data)
    this.generalService.getChartsUrl({ urlList: data }).subscribe(res => {
      // console.log('res', res);
      const urlList = res.value.urlList;
      // console.log('urlList', urlList)

      this.privateDashboard.languages[index].gridItems.forEach(element => {
        if (element.type === 'chart') {
          if (element.data.includes('https') || element.data.includes('http')) {
            element.data = '/views/' + (element.data.split('/views/').pop());
          }
          const urlIndex = urlList.findIndex(item => '/views/' + (item.split('/views/').pop()) === element.data);
          // console.log('urlIndex', urlIndex)
          // console.log('urlList[urlIndex]', '/views/' + (urlList[0].split('/views/').pop()))
          // console.log('urlList[urlIndex]', urlList[urlIndex], element.data)
          {
            // console.log('compare', '/views/' + (urlList[urlIndex].split('/views/').pop()) + '===' + element.data)
            element.data = urlList[urlIndex];
          }
        }
      });
      // console.log('this.privateDashboard.languages[index].gridItems', this.privateDashboard.languages[index].gridItems)
      this.dashboard = JSON.parse(JSON.stringify(this.privateDashboard));
      this.updatedDashboard = { ...this.dashboard };
    });
  }

  ngOnDestroy() {
    localStorage.removeItem('backupDashboard');
    sessionStorage.removeItem('hasEdited');
  }
  onMouseDown() {
    Array.from(document.getElementsByClassName('iframe-container')).forEach(element => {
      element.classList.add('make-them-none');
    });
  }

  onMouseUp() {
    Array.from(document.getElementsByClassName('iframe-container')).forEach(element => {
      element.classList.remove('make-them-none');
    });
  }

  openVizUrl(link) {
    if (this.id) {
      link = link; // + '?productId=' + this.product.publishProductId;
    }
    window.open(link, '_target');
  }
}

