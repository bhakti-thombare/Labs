import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductStepFiveFormComponent } from './product-step-five-form.component';

describe('ProductStepFiveFormComponent', () => {
  let component: ProductStepFiveFormComponent;
  let fixture: ComponentFixture<ProductStepFiveFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductStepFiveFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductStepFiveFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
