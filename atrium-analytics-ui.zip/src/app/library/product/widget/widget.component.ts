import { Component, OnInit, Input, OnChanges, AfterViewInit, OnDestroy } from '@angular/core';
import { UtilityService } from 'src/app/core/services/utility.service';
import { TableauService } from 'src/app/core/services/tableau.service';
import { from } from 'rxjs';
declare var tableau: any;
@Component({
  selector: 'ab-widget',
  templateUrl: './widget.component.html',
  styleUrls: ['./widget.component.scss']
})
export class WidgetComponent implements OnInit, OnChanges, AfterViewInit, OnDestroy {
  @Input() data: any;
  @Input() type: any;
  @Input() widgetData: any;
  @Input() selectedLanguage: any;
  @Input() source: any;
  viz: any;
  constructor(private tableauService: TableauService) { }

  ngOnInit() {
  }

  ngOnChanges() {
    // console.log(this.data);
    // console.log(this.type);
    // console.log('widgetData', this.widgetData);
    // if (this.type === 'embedCode') {
    //   // console.log('this.data', this.data)
    //   this.createViz(this.data, 'vizContainer' + this.widgetData.gridElementId + '' + this.selectedLanguage);
    // }
  }

  ngAfterViewInit() {
    if (this.type === 'embedCode') {
      // console.log('this.data', this.data)
      this.createViz(this.data, 'vizContainer' + this.widgetData.gridElementId + '' + this.selectedLanguage + this.source);
    }
    if (this.type === 'chart') {
      this.createViz(this.data, 'private-vizContainer' + this.widgetData.gridElementId + '' + this.selectedLanguage + this.source);
    }
    this.tableauService.startMarkEventListener();
    this.tableauService.startFilterEventListener();
    // this.tableauService.startParameterListener();
  }

  createViz(data, id) {
    const placeholderDiv = document.getElementById(id);
    // console.log('placeholderDiv', placeholderDiv)
    let url = '';
    if (this.type === 'embedCode') { url = this.tableauService.getVizUrlFromEmbedCode(data); }
    if (this.type === 'chart') { url = data; }
    const options = {
      hideTabs: true,
      hideToolbar: true,
      // width: '100%',
      // height: '100%',
      // onFirstVizSizeKnown: (e) => {
      //   console.log('e', e)
      // },
      onFirstInteractive: () => {
        // this.viz.setFrameSize()
        // console.log('---------------------------------------------------------------------------')
        // console.log(this.viz.getWorkbook().getActiveSheet().getSize())
        const size = this.viz.getWorkbook().getActiveSheet().getSize();
        if (size.behavior === 'automatic') {
          this.viz.setFrameSize('100%', '100%');
          //   this.manageVizSize(size).subscribe(doc => {
          //     console.log('doc', doc);
          //     // console.log('placeholderDiv', placeholderDiv)
          //     // console.log((placeholderDiv.firstChild as HTMLElement).clientHeight);
          //     // console.log((placeholderDiv.firstChild as HTMLElement).clientWidth);
          //     this.viz.setFrameSize(
          //       size.maxSize.width,
          //       size.maxSize.height
          //     );
          //     this.viz.refreshDataAsync();
          //   });
        }
        // console.log(this.viz.getWorkbook().getActiveSheet().getName())
        // console.log(this.viz.getWorkbook().getActiveSheet().getSize())
        // console.log('---------------------------------------------------------------------------')
      }
    };
    // console.log('url', url)
    if (url.includes('https') || url.includes('http')) { this.viz = new tableau.Viz(placeholderDiv, url, options); }

  }

  ngOnDestroy() {
    if (this.viz) { this.viz.dispose(); }
  }

  manageVizSize(size) {
    return from(this.viz.getWorkbook().getActiveSheet().changeSizeAsync({
      behavior: size.behavior,
      maxSize: { width: size.maxSize.width, height: size.maxSize.height },
      minSize: { width: size.minSize.width, height: size.minSize.height }
    }));
    // ,
    // maxSize: { width: size.maxSize.width, height: size.maxSize.height },
    // minSize: { width: size.minSize.width, height: size.minSize.height }

  }

}
