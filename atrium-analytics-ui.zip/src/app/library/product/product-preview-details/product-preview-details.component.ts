// tslint:disable-next-line: max-line-length
import { Component, OnInit, Input, OnChanges, Output, EventEmitter, AfterViewInit, OnDestroy, ViewContainerRef, ChangeDetectorRef } from '@angular/core';
import { GridsterItem, GridsterConfig, GridType, CompactType, DisplayGrid, GridsterComponentInterface } from 'angular-gridster2';
import { trigger, transition, style, animate } from '@angular/animations';
import { GeneralService } from '../../shared/general-service.service';
import * as _ from 'lodash';
import { ActivatedRoute } from '@angular/router';
// import * as lz from 'lz-string';
import { SharedDataServiceService } from 'src/app/core/services/shared-data-service.service';
import { UtilityService } from 'src/app/core/services/utility.service';
@Component({
  selector: 'ab-product-preview-details',
  templateUrl: './product-preview-details.component.html',
  styleUrls: ['./product-preview-details.component.scss'],
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({ transform: 'translateX(-100%)' }),
        animate('200ms ease-in', style({ transform: 'translateX(0%)' }))
      ]),
      transition(':leave', [
        animate('200ms ease-in', style({ transform: 'translateX(-100%)' }))
      ])
    ])
  ]
})
export class ProductPreviewDetailsComponent implements OnInit, OnChanges, AfterViewInit, OnDestroy {


  private static that: ProductPreviewDetailsComponent;
  showPreview = true;
  @Input() product: any;
  @Input() kpiCategoryInput: any;
  @Input() productHeight: any;
  @Input() productInfo: any;
  @Input() selectedTabLanguageInput: any;
  @Output() closeEvent: EventEmitter<any> = new EventEmitter<any>();
  kpiCategory = {
    languages: [
      {
        language: 'fr',
        productName: '',
        productCategoryList: []
      },
      {
        language: 'nl',
        productName: '',
        productCategoryList: []

      },
      {
        language: 'en',
        productName: '',
        productCategoryList: []
      }
    ]
  };
  selectedTabLanguage = this.selectedTabLanguageInput;
  previewOptions: GridsterConfig;
  dashboardLanguageIndex: number;

  previewDashboard: {
    languages: Array<{ language: string, gridItems: Array<GridsterItem> }>
  };
  privateDashboard: {
    languages: Array<{ language: string, gridItems: Array<GridsterItem> }>
  };
  sectionsToShow = [];
  productType: string;
  frCompleted: boolean;
  enCompleted: boolean;
  nlCompleted: boolean;
  kpiSelectionCollapsed = false;
  id: any;
  privateProductLanguagesAllowed = [];
  leftPanelSelected: boolean = false;
  static gridSizeChanged(gridsterComponent: GridsterComponentInterface) {
    const element = document.getElementById('gridster-preview-content');
    if (element) {
      // console.log('element', element)
      element.style.height = ((gridsterComponent.rows * 90.5) + 50.5) + 'px';
    }
    const element1 = document.getElementById('gridster-preview-content');
    if (element1) {
      // console.log('element1', element1)
    }
  }
  constructor(
    private utilityService: UtilityService,
    private dataSharingService: SharedDataServiceService,
    private cdRef: ChangeDetectorRef,
    private viewContainerRef: ViewContainerRef,
    private route: ActivatedRoute,
    private generalService: GeneralService) {
    ProductPreviewDetailsComponent.that = this;
    this.previewDashboard = {
      languages: [
        {
          language: 'fr',
          gridItems: []
        },
        {
          language: 'nl',
          gridItems: []
        },
        {
          language: 'en',
          gridItems: []
        }
      ]
    };
  }

  static itemChange(item, itemComponent) {
    // console.log('itemChanged', item, itemComponent);
    const el = document.getElementById(item.gridElementId); //
    // console.log('el', el)
    if (el) { el.style.pointerEvents = 'initial'; }
    if (true) {
      // console.log('item.gridElementId', item.gridElementId);
      ['fr', 'nl', 'en'].forEach(lang => {
        const dashboardLangIndex = ProductPreviewDetailsComponent.that.previewDashboard.languages
          .findIndex((dashItem: any) => dashItem.language === ProductPreviewDetailsComponent.that.selectedTabLanguage);

        // const updatedDashboardLangIndex = ProductPreviewDetailsComponent.that.updatedDashboard.languages
        //   .findIndex((dashItem: any) => dashItem.language === lang);


        // const updatedDashboardgridIndex = ProductPreviewDetailsComponent.that.updatedDashboard.languages[updatedDashboardLangIndex]
        //   .gridItems.findIndex(element => element.gridElementId === item.gridElementId)

        // ProductPreviewDetailsComponent.that.dashboard.languages[dashboardLangIndex].gridItems.forEach(el => {
        //   if (el.gridElementId === item.gridElementId) {
        //     el.cols = item.cols;
        //     el.rows = item.rows;
        //     el.x = item.x;
        //     el.y = item.y;
        //   }
        // });
        // console.log('updatedDashboard.languages[updatedDashboardLangIndex].gridItems[updatedDashboardgridIndex]',
        //   JSON.parse(JSON.stringify(ProductPreviewDetailsComponent.that.previewDashboard
        //     .languages[dashboardLangIndex])));

        ProductPreviewDetailsComponent.that.previewDashboard
          .languages.forEach(updatedDashboardElement => {

            // console.log('--------------------------------------------------------------')
            // console.log('updatedDashboardElement', updatedDashboardElement);
            // console.log('dashboardElement', ProductPreviewDetailsComponent.that.previewDashboard.languages[dashboardLangIndex]);
            // console.log('--------------------------------------------------------------')
            // if (ProductPreviewDetailsComponent.that.selectedTabLanguage !== updatedDashboardElement.language) {
            updatedDashboardElement.gridItems.forEach(gridElement => {
              const dashboardgridIndex = ProductPreviewDetailsComponent.that.previewDashboard.languages[dashboardLangIndex]
                .gridItems.findIndex(element => element.gridElementId === gridElement.gridElementId);
              const indexyz = itemComponent.gridster.grid.findIndex(gridEl => gridElement.gridElementId === gridEl.item.gridElementId);

              // console.log('gridElement.gridElementId', gridElement.gridElementId)
              // console.log('itemComponent.gridster.grid[indexyz].item', itemComponent.gridster.grid[indexyz].item.gridElementId)
              if (indexyz !== -1) {
                if (gridElement.gridElementId ===
                  itemComponent.gridster.grid[indexyz].item.gridElementId) {


                  // console.log('[dashboardgridIndex].y',
                  //   ProductPreviewDetailsComponent.that.previewDashboard.languages[dashboardLangIndex].gridItems[dashboardgridIndex].y);


                  gridElement.cols =
                    itemComponent.gridster.grid[indexyz].item.cols;
                  gridElement.rows =
                    itemComponent.gridster.grid[indexyz].item.rows;
                  gridElement.x =
                    itemComponent.gridster.grid[indexyz].item.x;
                  gridElement.y =
                    itemComponent.gridster.grid[indexyz].item.y;
                }
              }
            });
            // }
            // console.log('updatedDashboardElement', updatedDashboardElement)
          });

        // ProductPreviewDetailsComponent.that.updatedDashboard
        //   .languages[updatedDashboardLangIndex]
        //   .gridItems[updatedDashboardgridIndex].cols = item.cols;

        // ProductPreviewDetailsComponent.that.updatedDashboard
        //   .languages[updatedDashboardLangIndex]
        //   .gridItems[updatedDashboardgridIndex].rows = item.rows;

        // ProductPreviewDetailsComponent.that.updatedDashboard
        //   .languages[updatedDashboardLangIndex]
        //   .gridItems[updatedDashboardgridIndex].x = item.x;

        // ProductPreviewDetailsComponent.that.updatedDashboard
        //   .languages[updatedDashboardLangIndex]
        //   .gridItems[updatedDashboardgridIndex].y = item.y;
        // console.log('ProductPreviewDetailsComponent.', JSON.parse(JSON.stringify(ProductPreviewDetailsComponent.that.updatedDashboard)))
      });
      ProductPreviewDetailsComponent.that.previewDashboard = { ...ProductPreviewDetailsComponent.that.previewDashboard };
      // console.log('ProductPreviewDetailsComponent.that.previewDashboard', ProductPreviewDetailsComponent.that.previewDashboard)
      // ProductPreviewDetailsComponent.that.setupPositions();
    }
  }





  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get('id');
    this.previewOptions = {
      gridType: GridType.VerticalFixed,
      displayGrid: DisplayGrid.Always,
      compactType: CompactType.CompactUp,
      // disableAutoPositionOnConflict: true,
      swap: false,
      pushItems: false,
      // gridSizeChangedCallback: ProductStepFiveFormComponent.gridSizeChanged,
      // push: true,
      draggable: {
        delayStart: 0,
        enabled: false,
        // start: ProductStepFiveFormComponent.startedDragging,
        // stop: ProductStepFiveFormComponent.stoppedDragging
      },
      resizable: {
        handles: { n: true, e: true, w: true, ne: true, nw: true, s: true, se: true, sw: true },
        enabled: false,
        // start: ProductStepFiveFormComponent.startedResizing,
        // stop: ProductStepFiveFormComponent.stoppedResizing
      },

      pushing: false,
      sparse: false,
      defaultSizeX: 2, // the default width of a gridster item, if not specifed
      defaultSizeY: 1, // the default height of a gridster item, if not specified
      columns: 2, // the width of the grid, in columns
      // colWidth: '92.5', // can be an integer or 'auto'.  'auto' uses the pixel width of the element divided by 'columns'
      fixedRowHeight: 80.5, // can be an integer or 'match'.  Match uses the colWidth, giving you square widgets.
      margins: [10, 10], // the pixel distance between each widget
      minCols: 2,
      maxCols: 2,
      minRows: 1,
      maxRows: 100000,
      maxItemCols: 100,
      minItemCols: 1,
      maxItemRows: 100,
      minItemRows: 1,
      maxItemArea: 250,
      minItemArea: 1,
      defaultItemCols: 1,
      defaultItemRows: 3,
      // itemChangeCallback: ProductPreviewDetailsComponent.itemChange,
      // itemResizeCallback: ProductStepFiveFormComponent.itemResize,
      // gridSizeChangedCallback: ProductPreviewDetailsComponent.gridSizeChanged
    };
    // this.previewOptions.api.optionsChanged();
  }

  ngOnChanges() {
    // this.cdRef.detectChanges();
    document.getElementsByTagName('body')[0].style.overflow = 'hidden';
    // console.log('this.product', this.product)
    this.productType = this.productInfo.productType;
    if (this.productType === 'public') {
      this.frCompleted = true;
      this.nlCompleted = true;
      this.enCompleted = true;
    }
    if (this.productType === 'private') {

      if (this.productInfo.enCompleted) {
        this.selectedTabLanguage = 'en';
        this.enCompleted = true;
        this.privateProductLanguagesAllowed.push('en');
      }
      if (this.productInfo.nlCompleted) {
        this.selectedTabLanguage = 'nl';
        this.nlCompleted = true;
        this.privateProductLanguagesAllowed.push('nl');
      }
      if (this.productInfo.frCompleted) {
        this.selectedTabLanguage = 'fr';
        this.frCompleted = true;
        this.privateProductLanguagesAllowed.push('fr');
      }
    }
    this.selectedTabLanguage = this.selectedTabLanguageInput;
    // console.log('this.kpiCategoryInput', this.kpiCategoryInput)
    this.kpiCategory = _.cloneDeep(this.kpiCategoryInput); // JSON.parse(JSON.stringify(this.kpiCategoryInput));
    // this.kpiCategory = JSON.parse(JSON.stringify(this.dataSharingService.backupKpiCategory));
    this.kpiCategory.languages.forEach(element => {
      // const index = this.product.productDetailsList.findIndex(item => item.language === element.language)
      // element.productCategoryList = this.product.productDetailsList[index].productCategoryList;
      element.productCategoryList.forEach((item, i) => {
        // console.log('item', item, i)
        if (i === 0) { item.open = false; } else { item.open = true; }
        item.sectionList.forEach((item2, j) => {
          if (i === 0) {
            item2.checked = true;
            this.sectionsToShow.push(i + '' + j);
          } else { item2.checked = false; }
        });
      });
    });
    this.dashboardLanguageIndex = this.kpiCategory.languages.findIndex(item => item.language === this.selectedTabLanguage);
    this.sectionsToShow = Array.from(new Set(this.sectionsToShow));
    // tslint:disable-next-line: max-line-length
    // console.log('JSON.parse(lz.decompress(localStorage.getItem(\'backupDashboard\')))', JSON.parse(lz.decompress(localStorage.getItem('backupDashboard'))))
    // console.log('this.productType', this.productType)
    // tslint:disable-next-line: max-line-length
    // console.log('JSON.parse(JSON.stringify(this.dataSharingService.backupDashboard))', JSON.parse(JSON.stringify(this.dataSharingService.backupDashboard)))
    if (this.productType === 'public') {
      // tslint:disable-next-line: max-line-length
      const temp = JSON.parse(JSON.stringify(this.dataSharingService.backupDashboard)); // this.dataJSON.parse(lz.decompress(localStorage.getItem('backupDashboard')));// JSON.parse(JSON.stringify(this.product));
      // console.log('temp', temp)
      temp.languages.forEach(element => {
        if (element.gridItems.length) {
          element.gridItems = _.orderBy(element.gridItems, ['y'], ['asc']);
        }
      });
      this.previewDashboard = temp;
      // console.log('this.previewDashboard', this.previewDashboard)
    }
    if (this.productType === 'private') {
      // tslint:disable-next-line: max-line-length
      const temp = JSON.parse(JSON.stringify(this.dataSharingService.backupDashboard)); // JSON.parse(lz.decompress(localStorage.getItem('backupDashboard')));// JSON.parse(JSON.stringify(this.product));
      temp.languages.forEach(element => {
        if (element.gridItems.length) {
          element.gridItems = _.orderBy(element.gridItems, ['y'], ['asc']);
        }
      });
      this.privateDashboard = temp;
      // console.log('this.privateDashboard', this.privateDashboard)

      // this.getChartsUrl();
    } else {

    }


    // this.cdRef.detectChanges();
    this.kpiSelectionChanged();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      document.getElementsByTagName('body')[0].classList.add('hidden-overflow');
      document.getElementById('gridster-preview-content').style.height = this.productHeight + 'px';
      document.getElementById('kpi-selection').style.height = this.productHeight + 'px';
    }, 0);
    this.cdRef.markForCheck();
  }

  switchLanguageTab(lang) {
    if (this.productType === 'private') {
      if (!this.privateProductLanguagesAllowed.includes(lang)) { return; }
    }
    this.selectedTabLanguage = lang;
    // this.setUpWidgets();
    this.dashboardLanguageIndex = this.previewDashboard.languages.findIndex(item => item.language === this.selectedTabLanguage);
    if (this.productType === 'private') {
      this.kpiSelectionChanged();
    }
  }

  closeModal() {

    // tslint:disable-next-line: triple-equals
    if (this.previewDashboard == this.product) {
      // console.log('same reference')
    }
    // console.log('this.dashboard', this.previewDashboard)
    // console.log('this.product', this.product)
    this.restoreStepFiveView();
    this.closeEvent.emit(true);
    this.showPreview = false;
  }

  checkboxChange(e, categoryIndex, sectionIndex) {
    this.leftPanelSelected = true;
    // console.log('j', sectionIndex);
    // console.log('i', categoryIndex);
    // console.log('e', e);
    if (this.productType === 'public') {
      [0, 1, 2].forEach(index => {
        this.kpiCategory.languages[index]
          .productCategoryList[categoryIndex].sectionList[sectionIndex].checked = e.target.checked;
      });
    }
    if (this.productType === 'private') {
      const index = this.kpiCategory.languages.findIndex(item => item.language === this.selectedTabLanguage);
      this.kpiCategory.languages[index]
        .productCategoryList[categoryIndex].sectionList[sectionIndex].checked = e.target.checked;
    }
    if (e.target.checked) {
      this.sectionsToShow.push(categoryIndex + '' + sectionIndex);
      // this.addSectionToView(categoryIndex, sectionIndex)
    } else {
      this.sectionsToShow = this.sectionsToShow.filter(section => section !== categoryIndex + '' + sectionIndex);
      // this.removeSectionFromView(categoryIndex, sectionIndex);
    }
    // console.log('this.sectionsToShow', this.sectionsToShow)
    this.kpiSelectionChanged();

  }

  // kpiSelectionChanged() {
  //   console.log(this.sectionsToShow, 'sectiontoshow')
  //   this.previewDashboard.languages.forEach(element => {
  //     const index = this.product.languages.findIndex(item => item.language === element.language);
  //     let gridElements = [];
  //     if (this.sectionsToShow.length) {
  //       this.sectionsToShow.forEach(location => {
  //         console.log('location', location)
  //         gridElements = gridElements.concat(this.product.languages[index].gridItems.filter(item => {
  //           // console.log('item.gridElementId.substring(0, 2)', item.gridElementId.substring(0, 2))
  //           // console.log('location', location)
  //           return item.gridElementId.substring(0, 2) === location;
  //         }));
  //       });

  //       console.log('gridElements', gridElements)
  //       element.gridItems = gridElements;
  //     } else {
  //       this.previewDashboard = {
  //         languages: [
  //           { language: 'fr', gridItems: [] },
  //           { language: 'en', gridItems: [] },
  //           { language: 'nl', gridItems: [] }
  //         ]
  //       }; // JSON.parse(JSON.stringify(this.product));
  //     }
  //   });
  //   console.log('this.dashboard', this.previewDashboard);
  //   console.log('this.product', this.product)
  //   console.log('this.productdashboard', this.previewDashboard)
  // }

  kpiSelectionChanged() {
    // this.kpiCategory
    // this.cdRef.detectChanges();
    // console.log('this.sectionsToShow', this.sectionsToShow)
    this.previewDashboard.languages.forEach(lang => {
      lang.gridItems = [];
    });
    // console.log('this.kpiCategory', this.kpiCategory)
    const newKpiCategory = {
      languages: [
        {
          language: 'fr',
          productName: '',
          description: '',
          productCategoryList: []
        },
        {
          language: 'nl',
          productName: '',
          description: '',
          productCategoryList: []

        },
        {
          language: 'en',
          productName: '',
          description: '',
          productCategoryList: []
        }
      ]
    };

    // console.log('this.sectionsToShow', this.sectionsToShow)
    this.sectionsToShow.sort();
    if (this.sectionsToShow.length) {
      ['fr', 'nl', 'en'].forEach(lang => {
        const index = newKpiCategory.languages.findIndex(item => item.language === lang);
        const index2 = this.kpiCategory.languages.findIndex(item => item.language === lang);
        const newCategories: any = [];
        let categoryIndices = [];
        this.sectionsToShow.forEach(location => {
          categoryIndices.push(location[0]);
        });
        categoryIndices = Array.from(new Set(categoryIndices));
        // console.log('categoryIndices', categoryIndices)
        categoryIndices.forEach(location => {
          // console.log('location', location);

          // newKpiCategory.languages[index].description = JSON.parse(JSON.stringify(this.kpiCategory.languages[index2].description));
          newKpiCategory.languages[index].productName = JSON.parse(JSON.stringify(this.kpiCategory.languages[index2].productName));
          newKpiCategory.languages[index].productCategoryList =
            JSON.parse(JSON.stringify(this.kpiCategory.languages[index2].productCategoryList));
          for (let catIndex = 0; catIndex < newKpiCategory.languages[index].productCategoryList.length; catIndex++) {
            if (catIndex === parseInt(location, 10)) {
              newKpiCategory.languages[index].productCategoryList[
                parseInt(location, 10)
              ].categoryIndex = parseInt(location, 10);
              newKpiCategory.languages[index].productCategoryList[
                parseInt(location, 10)
              ].sectionList = [];
              newKpiCategory.languages[index].productCategoryList[parseInt(location, 10)].originalIndex = catIndex;
              newCategories.push(newKpiCategory.languages[index].productCategoryList[parseInt(location, 10)]);
              break;
            }
          }
          // console.log('newCategories', newCategories)
          // newCategories = _.uniqBy(newCategories, 'id');
          newKpiCategory.languages[index].productCategoryList = newCategories;

        });
        // console.log('newKpiCategory', newKpiCategory)

        // adding selceted sections to selected categories

        newKpiCategory.languages[index].productCategoryList.forEach((newCat, newCatIndex2) => {
          const newSections = [];
          // console.log('this.sectionsToShow', this.sectionsToShow)
          let catergoriesWise = this.sectionsToShow.filter(res => res[0] == newCat.categoryIndex);
          catergoriesWise.forEach((loc, secIndex) => {
            const newCatIndex =
              newKpiCategory.languages[index].productCategoryList.findIndex(item => item.categoryIndex === parseInt(loc[0], 10));
            const oldCatIndex = newKpiCategory.languages[index].productCategoryList[newCatIndex].categoryIndex;
            // console.log(newCat.categoryIndex + ' === ' + parseInt(loc[0], 10), newCat.categoryIndex === parseInt(loc[0], 10))
            if (newCat.categoryIndex === parseInt(loc[0], 10)) {
              if (this.leftPanelSelected == false) {
                //newSections.push(this.kpiCategory.languages[index2].productCategoryList[oldCatIndex].sectionList[parseInt(loc[1], 10)]);
                newSections.push(this.kpiCategory.languages[index2].productCategoryList[oldCatIndex].sectionList[secIndex]);
                newKpiCategory.languages[index].productCategoryList[newCatIndex].sectionList = newSections;
              } else{
                let checked = this.kpiCategory.languages[index2].productCategoryList[oldCatIndex].sectionList.filter(res => res.checked == true);
                newSections.push(checked[secIndex]);
                newKpiCategory.languages[index].productCategoryList[newCatIndex].sectionList = newSections;
              }
            }
          });
        });
      });


    } else {
      this.previewDashboard = {
        languages: [
          { language: 'fr', gridItems: [] },
          { language: 'nl', gridItems: [] },
          { language: 'en', gridItems: [] }
        ]
      }; // JSON.parse(JSON.stringify(this.product));
    }
    // console.log('newKpiCategory', newKpiCategory)
    this.modifyWidgetsSteup(newKpiCategory);
    // console.log('newKpiCategory', newKpiCategory)
    // console.log('this.dashboard', this.previewDashboard);
    // this.cdRef.detectChanges();
  }



  modifyWidgetsSteup(kpiCategory) {
    // this.cdRef.detectChanges();
    // const updatedDashIndex = this.dashboard.languages.findIndex(item => item.language === this.selectedTabLanguage);
    // console.log('this.kpiCategory', kpiCategory);
    kpiCategory.languages.forEach(element => {
      // if (element.language === this.selectedTabLanguage) {
      const dashIndex = this.previewDashboard.languages.findIndex(item => item.language === element.language);
      for (let i = 0; i < element.productCategoryList.length; i++) {
        const category = element.productCategoryList[i];
        // const secData = {
        //   x: category.catPositionX,
        //   y: category.catPositionY,
        //   cols: category.catSizeCols,
        //   rows: category.catSizeRows,
        //   type: 'title',
        //   data: category.categoryName,
        //   gridElementId: i,
        //   hi: i+1
        // };
        // this.previewDashboard.languages[dashIndex].gridItems.push(secData);
        for (let j = 0; j < category.sectionList.length; j++) {
          const section = category.sectionList[j];
          for (let k = 0; k < section.widgetList.length; k++) {
            const widget = section.widgetList[k];
            const data = {
              x: widget.widgetPositionX,
              y:  widget.widgetPositionY,
              // (widget.widgetSizeCols==1 && widget.type=='title')?widget.data.length>23 ?widget.widgetPositionY+1:widget.widgetPositionY:widget.widgetPositionY,
              cols: widget.widgetSizeCols,
              rows:widget.widgetSizeRows,
              // widget.widgetSizeCols<2 && widget.widgetType=='title'?2:
              type: widget.widgetType,
              data: widget.widgetUrl,
              vizUrl: widget.vizUrl,
              gridElementId: i + '' + j + '' + k
            };
            this.previewDashboard.languages[dashIndex].gridItems.push(data);
          }
          // tslint:disable-next-line: max-line-length
          this.previewDashboard.languages[dashIndex].gridItems = _.uniqBy(this.previewDashboard.languages[dashIndex].gridItems, 'gridElementId');
        }
      }
      // }
    });
    this.previewDashboard.languages.forEach(element => {
      element.gridItems = _.uniqBy(element.gridItems, 'gridElementId');
    });
    this.product = { ...this.previewDashboard };
    // console.log('this.previewDashboard', this.previewDashboard);
    if (this.productType === 'private') {
      this.privateDashboard = JSON.parse(JSON.stringify(this.previewDashboard));
      if (
        // tslint:disable-next-line: max-line-length
        (this.previewDashboard.languages[0].gridItems.length && (this.previewDashboard.languages[0].gridItems.findIndex(item => item.type === 'chart') !== -1)) ||
        // tslint:disable-next-line: max-line-length
        (this.previewDashboard.languages[1].gridItems.length && (this.previewDashboard.languages[1].gridItems.findIndex(item => item.type === 'chart') !== -1)) ||
        // tslint:disable-next-line: max-line-length
        (this.previewDashboard.languages[2].gridItems.length && (this.previewDashboard.languages[2].gridItems.findIndex(item => item.type === 'chart') !== -1))
      ) {
        this.getChartsUrl();
      }
    }
    // this.cdRef.detectChanges();
  }

  toggleCategoryDropDown(index) {
    this.kpiCategory.languages.forEach(element => {
      if (element) {
        if (element.productCategoryList.length) {
          element.productCategoryList[index].open = !element.productCategoryList[index].open;
        }
      }
    });
  }

  kpiLeftMenuResized() {
    if (this.kpiSelectionCollapsed) {
      document.getElementById('col-kpi').classList.remove('col-md-2', 'col-sm-2');
      document.getElementById('col-kpi').classList.add('col-md-1', 'col-sm-1', 'pr-0');
      document.getElementById('col-product').classList.remove('col-md-10', 'col-sm-10');
      document.getElementById('col-product').classList.add('col-md-11', 'col-sm-11');
      document.getElementById('product-body').classList.add('make-center');
    } else {
      document.getElementById('col-kpi').classList.remove('col-md-1', 'col-sm-1', 'pr-0');
      document.getElementById('col-kpi').classList.add('col-md-2', 'col-sm-2');
      document.getElementById('col-product').classList.remove('col-md-11', 'col-sm-11');
      document.getElementById('col-product').classList.add('col-md-10', 'col-sm-10');
      document.getElementById('product-body').classList.remove('make-center');
    }
    window.dispatchEvent(new Event('resize'));

  }
  selectAllSections() {
    this.kpiCategory.languages.forEach(lang => {
      const index = this.kpiCategory.languages.findIndex(item => item.language === lang.language);
      if (this.kpiCategory.languages[index].productCategoryList.length) {
        this.kpiCategory.languages[index].productCategoryList.forEach((cat, i) => {
          cat.open = false;
          if (cat.sectionList.length) {
            cat.sectionList.forEach((sec, j) => {
              sec.checked = true;
              this.sectionsToShow.push(i + '' + j);
            });
          }
        });
      }
    });
    this.sectionsToShow = Array.from(new Set(this.sectionsToShow));
    this.kpiSelectionChanged();
    this.utilityService.showTranslatedNotificationMessage(
      'NotificationMessages.Product.ScrollDown',
      'INFORMATION'
    );
  }

  resetSections() {
    this.sectionsToShow = [];
    this.kpiCategory.languages.forEach(lang => {
      const index = this.kpiCategory.languages.findIndex(item => item.language === lang.language);
      if (index !== -1) {

        if (this.kpiCategory.languages[index].productCategoryList.length) {
          this.kpiCategory.languages[index].productCategoryList.forEach((cat, i) => {
            cat.open = true;
            if (cat.sectionList.length) {
              cat.sectionList.forEach((sec, j) => {
                sec.checked = false;
              });
            }
          });
        }
      }
    });
    this.sectionsToShow = Array.from(new Set(this.sectionsToShow));
    this.kpiSelectionChanged();
  }

  getChartsUrl() {
    // this.cdRef.detectChanges();
    // console.log('this.privateDashboard', this.privateDashboard)
    const index = this.privateDashboard.languages.findIndex(item => item.language === this.selectedTabLanguage);
    const data = [];

    this.privateDashboard.languages[index].gridItems.forEach(element => {
      if (element.type === 'chart') {
        element.data = '/views/' + (element.data.split('/views/').pop());
        data.push(element.data);
      }
    });
    // console.log('data', data)
    this.generalService.getChartsUrl({ urlList: data }).subscribe(res => {
      // console.log('res', res);
      const urlList = res.value.urlList;
      // console.log('urlList', urlList)

      this.privateDashboard.languages[index].gridItems.forEach(element => {
        if (element.type === 'chart') {
          if (element.data.includes('https') || element.data.includes('http')) {
            element.data = '/views/' + (element.data.split('/views/').pop());
          }
          const urlIndex = urlList.findIndex(item => '/views/' + (item.split('/views/').pop()) === element.data);
          if (urlIndex !== -1) {
            // console.log('compare', '/views/' + (urlList[urlIndex].split('/views/').pop()) + '===' + element.data)
            element.data = urlList[urlIndex];
          }
        }
      });
      // console.log('this.privateDashboard.languages[index].gridItems', this.privateDashboard.languages[index].gridItems)
      this.previewDashboard = _.cloneDeep(this.privateDashboard); // JSON.parse(JSON.stringify(this.privateDashboard))
      // this.updatedDashboard = { ...this.dashboard };
    });
    // this.cdRef.detectChanges();
  }
  ngOnDestroy() {
    this.viewContainerRef.clear();
  }

  openVizUrl(link) {
    if (this.id) {
      link = link; // + '?productId=' + this.id;
    }
    window.open(link, '_target');
  }

  restoreStepFiveView() {
    // this.sectionsToShow = [];
    this.kpiCategory.languages.forEach(lang => {
      const index = this.kpiCategory.languages.findIndex(item => item.language === lang.language);
      if (this.kpiCategory.languages[index].productCategoryList.length) {
        this.kpiCategory.languages[index].productCategoryList.forEach((cat, i) => {
          cat.open = false;
          if (cat.sectionList.length) {
            cat.sectionList.forEach((sec, j) => {
              sec.checked = true;
              this.sectionsToShow.push(i + '' + j);
            });
          }
        });
      }
    });
    this.sectionsToShow = Array.from(new Set(this.sectionsToShow));
    this.kpiSelectionChanged();
  }
}
