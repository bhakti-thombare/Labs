import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  Input,
  OnDestroy,
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ErrorMessageHandlerService } from 'src/app/core/services/error-message-handler.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import {
  debounceTime,
  tap,
  switchMap,
  catchError,
  distinctUntilChanged,
} from 'rxjs/operators';
import { GeneralService } from '../../shared/general-service.service';
import { of, ReplaySubject, Observable, from } from 'rxjs';
import { AuthService } from 'src/app/core/services/auth.service';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { UtilityService } from 'src/app/core/services/utility.service';
import { FileUploader } from 'ng2-file-upload';
import { DomSanitizer } from '@angular/platform-browser';
import { filter } from 'lodash';
@Component({
  selector: 'ab-product-step-three-form',
  templateUrl: './product-step-three-form.component.html',
  styleUrls: ['./product-step-three-form.component.scss'],
})
export class ProductStepThreeFormComponent implements OnInit, OnDestroy {
  @Output() nextStep: EventEmitter<any> = new EventEmitter<any>();
  @Output() updatePrivateProductLanguages: EventEmitter<any> = new EventEmitter<
    any
  >();
  @Input() product: any;
  selectedTabLanguage = 'fr';
  nlCompleted: any;
  frCompleted: any;
  enCompleted: any;
  selectedTag = [];
  filteredTagsMultipleArray: any[];
  key: any;
  tagBody: any;
  tags: ReplaySubject<any> = new ReplaySubject<any>(undefined);
  tags$: Observable<any> = this.tags.asObservable();
  index1: number;
  tagArray: any;
  tagData: any[] = [];
  currentUser: any;
  stepThreeForm: FormGroup;

  productBasicInfo: any = {
    tagList: [],
    image: {
      id: null,
      imageUrl: '',
      updateFlag: false,
    },
    languages: [
      {
        language: 'en',
        productName: '',
        productDetailsId: null,
        description: '',
        additionalInfo: null,
        productCategoryList: [],
      },
      {
        language: 'fr',
        productName: '',
        productDetailsId: null,
        description: '',
        additionalInfo: null,
        productCategoryList: [],
      },
      {
        language: 'nl',
        productName: '',
        productDetailsId: null,
        description: '',
        additionalInfo: null,
        productCategoryList: [],
      },
    ],
  };
  thumbnail: any;
  public uploader: FileUploader = new FileUploader({
    // url: URL,
    // disableMultipart:true
  });
  imageWidth: number;
  imageHeight: number;
  productType: any;
  @Input() privateProductLanguages;
  constructor(
    private translate: TranslateService,
    private formBuilder: FormBuilder,
    private sanitizer: DomSanitizer,
    private authService: AuthService,
    private generalservice: GeneralService,
    private utilityService: UtilityService,
    private notificationService: NotificationService,
    private errorMessageHandler: ErrorMessageHandlerService
  ) { }

  ngOnInit() {
    sessionStorage.removeItem('hasEdited');
    this.loadUser();
    this.listenChanges();
    this.buildForm();
    this.formChanges();
    this.onProductNameChanges();
  }

  // tslint:disable-next-line: use-lifecycle-interface
  ngOnChanges() {
    if (this.product) {
      // console.log('this.product', this.product);
      this.productNameEn =
        (this.product.productDetailsList[0] &&
          this.product.productDetailsList[0].productName) ||
        null;
      this.productNameFr =
        (this.product.productDetailsList[1] &&
          this.product.productDetailsList[1].productName) ||
        null;
      this.productNameNl =
        (this.product.productDetailsList[2] &&
          this.product.productDetailsList[2].productName) ||
        null;
      if (this.product.productType === 'private') {
        const frIndex = this.product.productDetailsList.findIndex(
          (item) => item.language === 'fr'
        );
        const nlIndex = this.product.productDetailsList.findIndex(
          (item) => item.language === 'nl'
        );
        const enIndex = this.product.productDetailsList.findIndex(
          (item) => item.language === 'en'
        );
        this.productNameEn =
          (this.product.productDetailsList[enIndex] &&
            this.product.productDetailsList[enIndex].productName) ||
          null;
        this.productNameFr =
          (this.product.productDetailsList[frIndex] &&
            this.product.productDetailsList[frIndex].productName) ||
          null;
        this.productNameNl =
          (this.product.productDetailsList[nlIndex] &&
            this.product.productDetailsList[nlIndex].productName) ||
          null;
        if (enIndex !== -1) {
          if (
            this.product.productDetailsList[enIndex] &&
            this.product.productDetailsList[enIndex].productCategoryList.length
          ) {
            // console.log(
            //   'this.product.productDetailsList[enIndex]',
            //   this.product.productDetailsList[enIndex]
            // );
            const index = this.productBasicInfo.languages.findIndex(
              (item) => item.language === 'en'
            );
            if (index !== -1) {
              this.productBasicInfo.languages[
                index
              ].productCategoryList = this.product.productDetailsList[
                enIndex
              ].productCategoryList;
            }
            this.selectedTabLanguage = 'en';
          }
        }
        if (nlIndex !== -1) {
          if (
            this.product.productDetailsList[nlIndex] &&
            this.product.productDetailsList[nlIndex].productCategoryList.length
          ) {
            const index = this.productBasicInfo.languages.findIndex(
              (item) => item.language === 'nl'
            );
            if (index !== -1) {
              this.productBasicInfo.languages[
                index
              ].productCategoryList = this.product.productDetailsList[
                nlIndex
              ].productCategoryList;
            }
            this.selectedTabLanguage = 'nl';
          }
        }
        if (frIndex !== -1) {
          if (
            this.product.productDetailsList[frIndex] &&
            this.product.productDetailsList[frIndex].productCategoryList.length
          ) {
            const index = this.productBasicInfo.languages.findIndex(
              (item) => item.language === 'fr'
            );
            if (index !== -1) {
              this.productBasicInfo.languages[
                index
              ].productCategoryList = this.product.productDetailsList[
                frIndex
              ].productCategoryList;
            }
            this.selectedTabLanguage = 'fr';
          }
        }
        // console.log('this.selectedTabLanguage', this.selectedTabLanguage);
      }
      this.productType = this.product.productType;
      // console.log('this.product', this.product);
      if (this.product.image) {
        this.productBasicInfo.image.id = this.product.image.id;
        this.productBasicInfo.image.imageUrl = this.product.image.imageUrl;
        this.productBasicInfo.image.updateFlag = this.product.image.updateFlag;
      }
      this.productBasicInfo.tagList = this.product.tagList;
      ['fr', 'nl', 'en'].forEach((lang) => {
        const index1 = this.productBasicInfo.languages.findIndex(
          (item) => item.language === lang
        );
        const index2 = this.product.productDetailsList.findIndex(
          (item) => item.language === lang
        );
        if (index1 !== -1 && index2 !== -1) {
          this.productBasicInfo.languages[
            index1
          ].productName = this.product.productDetailsList[index2].productName;
          this.productBasicInfo.languages[
            index1
          ].description = this.product.productDetailsList[index2].description;
        }
      });
      
      // sorting category
      this.product.productDetailsList.forEach(res => {
        res.productCategoryList.sort((a, b) => parseInt(a.categoryId) - parseInt(b.categoryId));
      })

      // sorting widget
      this.product.productDetailsList.forEach(res => {
        res.productCategoryList.forEach(cat=>{
          cat.sectionList.forEach(sec=>{
            sec.widgetList.sort((a, b) => parseInt(a.widgetId) - parseInt(b.widgetId));
          })
        })
      });
      
    }
  }

  formChanges() {
    this.stepThreeForm.valueChanges.subscribe((form) => {
      // console.log('form', form);
      // tslint:disable-next-line: no-string-literal
      this.productNameObj['productName'] = form.name;

      // console.log('this.selectedTabLanguage', this.selectedTabLanguage);
      const index = this.productBasicInfo.languages.findIndex(
        (item) => item.language === this.selectedTabLanguage
      );
      const proIndex = this.product.productDetailsList.findIndex(
        (item) => item.language === this.selectedTabLanguage
      );
      if (index !== -1) {
        this.productBasicInfo.languages[index].productName =
          (form.name && form.name.trim()) || '';
        this.productBasicInfo.languages[index].description =
          (form.description && form.description.trim()) || '';
      }
      if (form.image && form.image.includes('https://')) {
        this.productBasicInfo.image.id = null;
        this.productBasicInfo.image.imageUrl = form.image;
        this.productBasicInfo.image.updateFlag = true;
      }
      this.checkLanguageCompleteness();
      // console.log('stepthree product', this.productBasicInfo);
      if (proIndex !== -1) {
        // console.log('this.product', this.product);
        // console.log(
        //   'this.product.productDetailsList[proIndex]',
        //   this.product.productDetailsList[proIndex]
        // );
        if (this.product.productDetailsList[proIndex]) {
          this.product.productDetailsList[
            proIndex
          ].productName = this.productBasicInfo.languages[index].productName;
          this.product.productDetailsList[
            proIndex
          ].description = this.productBasicInfo.languages[index].description;
        }
      }

      if (this.product.productType === 'private') {
        const index2 = this.product.productDetailsList.findIndex(
          (item) => item.language === this.selectedTabLanguage
        );
        const index3 = this.productBasicInfo.languages.findIndex(
          (item) => item.language === this.selectedTabLanguage
        );
        if (
          this.productBasicInfo.languages[index3].productName ||
          this.productBasicInfo.languages[index3].description
        ) {
          if (index2 === -1) {
            this.product.productDetailsList.push({
              language: this.selectedTabLanguage,
              productName: this.productBasicInfo.languages[index3].productName,
              productDetailsId: null,
              description: this.productBasicInfo.languages[index3].description,
              additionalInfo: null,
              productCategoryList: this.productBasicInfo.languages[index3]
                .productCategoryList,
            });
          }
        }
      }
    });
  }

  checkLanguageCompleteness() {
    // console.log('checkLanguageCompleteness');
    const frIndex = this.productBasicInfo.languages.findIndex(
      (item) => item.language === 'fr'
    );
    const nlIndex = this.productBasicInfo.languages.findIndex(
      (item) => item.language === 'nl'
    );
    const enIndex = this.productBasicInfo.languages.findIndex(
      (item) => item.language === 'en'
    );
    const tag = this.productBasicInfo.tagList;

    // french
    // if (this.productBasicInfo.languages[frIndex].productName && this.productBasicInfo.languages[frIndex].description) {
    if (this.productType === 'private') {
      if (this.productBasicInfo.languages[frIndex].productName) {
        this.privateProductLanguages.push('fr');
        this.frCompleted = true;
        if (
          this.productBasicInfo.languages[frIndex].productName ||
          this.productBasicInfo.languages[frIndex].description
        ) {
          if (
            this.productBasicInfo.languages[nlIndex].productName &&
            this.productBasicInfo.languages[nlIndex].description
          ) {
            if (this.productBasicInfo.languages[frIndex].description) {
              if (this.productBasicInfo.languages[frIndex].productName) {
                this.privateProductLanguages.push('fr');
                this.frCompleted = true;
              } else {
                const i = this.privateProductLanguages.findIndex(
                  (item) => item === 'fr'
                );
                if (i !== -1) {
                  this.privateProductLanguages.splice(i, 1);
                }
                this.frCompleted = false;
              }
            } else {
              const i = this.privateProductLanguages.findIndex(
                (item) => item === 'fr'
              );
              if (i !== -1) {
                this.privateProductLanguages.splice(i, 1);
              }
              this.frCompleted = false;
            }
          }

          if (
            this.productBasicInfo.languages[enIndex].productName &&
            this.productBasicInfo.languages[enIndex].description
          ) {
            if (this.productBasicInfo.languages[frIndex].description) {
              if (this.productBasicInfo.languages[frIndex].productName) {
                this.privateProductLanguages.push('fr');
                this.frCompleted = true;
              } else {
                const i = this.privateProductLanguages.findIndex(
                  (item) => item === 'fr'
                );
                if (i !== -1) {
                  this.privateProductLanguages.splice(i, 1);
                }
                this.frCompleted = false;
              }
            } else {
              const i = this.privateProductLanguages.findIndex(
                (item) => item === 'fr'
              );
              if (i !== -1) {
                this.privateProductLanguages.splice(i, 1);
              }
              this.frCompleted = false;
            }
          }
        }
      } else {
        const i = this.privateProductLanguages.findIndex(
          (item) => item === 'fr'
        );
        if (i !== -1) {
          this.privateProductLanguages.splice(i, 1);
        }
        this.frCompleted = false;
      }
    }
    if (this.productType === 'public') {
      if (
        this.productBasicInfo.languages[frIndex].productName &&
        this.productBasicInfo.languages[frIndex].description
      ) {
        if (tag.length) {
          // console.log('tag', tag);
          // tslint:disable-next-line: prefer-for-of
          for (let i = 0; i < Object.keys(tag[0]).length; i++) {
            if (Object.keys(tag[0])[i].includes('fr')) {
              this.frCompleted = true;
              break;
            } else {
              this.frCompleted = false;
            }
          }
        } else {
          this.frCompleted = false;
        }
      } else {
        this.frCompleted = false;
      }
    }
    // }
    //  else {
    //   this.frCompleted = false;
    // }
    // dutch
    // if (this.productBasicInfo.languages[nlIndex].productName && this.productBasicInfo.languages[nlIndex].description) {
    if (this.productType === 'private') {
      if (this.productBasicInfo.languages[nlIndex].productName) {
        this.privateProductLanguages.push('nl');
        this.nlCompleted = true;

        if (
          this.productBasicInfo.languages[nlIndex].productName ||
          this.productBasicInfo.languages[nlIndex].description
        ) {
          if (
            this.productBasicInfo.languages[frIndex].productName &&
            this.productBasicInfo.languages[frIndex].description
          ) {
            if (this.productBasicInfo.languages[nlIndex].description) {
              if (this.productBasicInfo.languages[nlIndex].productName) {
                this.privateProductLanguages.push('nl');
                this.nlCompleted = true;
              } else {
                const i = this.privateProductLanguages.findIndex(
                  (item) => item === 'nl'
                );
                if (i !== -1) {
                  this.privateProductLanguages.splice(i, 1);
                }
                this.nlCompleted = false;
              }
            } else {
              const i = this.privateProductLanguages.findIndex(
                (item) => item === 'nl'
              );
              if (i !== -1) {
                this.privateProductLanguages.splice(i, 1);
              }
              this.nlCompleted = false;
            }
          }

          if (
            this.productBasicInfo.languages[enIndex].productName &&
            this.productBasicInfo.languages[enIndex].description
          ) {
            if (this.productBasicInfo.languages[nlIndex].description) {
              if (this.productBasicInfo.languages[nlIndex].productName) {
                this.privateProductLanguages.push('nl');
                this.nlCompleted = true;
              } else {
                const i = this.privateProductLanguages.findIndex(
                  (item) => item === 'nl'
                );
                if (i !== -1) {
                  this.privateProductLanguages.splice(i, 1);
                }
                this.nlCompleted = false;
              }
            } else {
              const i = this.privateProductLanguages.findIndex(
                (item) => item === 'nl'
              );
              if (i !== -1) {
                this.privateProductLanguages.splice(i, 1);
              }
              this.nlCompleted = false;
            }
          }
        }
      } else {
        const i = this.privateProductLanguages.findIndex(
          (item) => item === 'nl'
        );
        if (i !== -1) {
          this.privateProductLanguages.splice(i, 1);
        }
        this.nlCompleted = false;
      }
    }
    if (this.productType === 'public') {
      if (
        this.productBasicInfo.languages[nlIndex].productName &&
        this.productBasicInfo.languages[nlIndex].description
      ) {
        if (tag.length) {
          // tslint:disable-next-line: prefer-for-of
          for (let i = 0; i < Object.keys(tag[0]).length; i++) {
            if (Object.keys(tag[0])[i].includes('nl')) {
              this.nlCompleted = true;
              break;
            } else {
              this.nlCompleted = false;
            }
          }
        } else {
          this.nlCompleted = false;
        }
      } else {
        this.nlCompleted = false;
      }
    }
    // }

    // english
    // if (this.productBasicInfo.languages[enIndex].productName && this.productBasicInfo.languages[enIndex].description) {
    if (this.productType === 'private') {
      if (this.productBasicInfo.languages[enIndex].productName) {
        this.privateProductLanguages.push('en');
        this.enCompleted = true;

        if (
          this.productBasicInfo.languages[enIndex].productName ||
          this.productBasicInfo.languages[enIndex].description
        ) {
          if (
            this.productBasicInfo.languages[frIndex].productName &&
            this.productBasicInfo.languages[frIndex].description
          ) {
            if (this.productBasicInfo.languages[enIndex].description) {
              if (this.productBasicInfo.languages[enIndex].productName) {
                this.privateProductLanguages.push('en');
                this.enCompleted = true;
              } else {
                const i = this.privateProductLanguages.findIndex(
                  (item) => item === 'en'
                );
                if (i !== -1) {
                  this.privateProductLanguages.splice(i, 1);
                }
                this.enCompleted = false;
              }
            } else {
              const i = this.privateProductLanguages.findIndex(
                (item) => item === 'en'
              );
              if (i !== -1) {
                this.privateProductLanguages.splice(i, 1);
              }
              this.enCompleted = false;
            }
          }

          if (
            this.productBasicInfo.languages[nlIndex].productName &&
            this.productBasicInfo.languages[nlIndex].description
          ) {
            if (this.productBasicInfo.languages[enIndex].description) {
              if (this.productBasicInfo.languages[enIndex].productName) {
                this.privateProductLanguages.push('en');
                this.enCompleted = true;
              } else {
                const i = this.privateProductLanguages.findIndex(
                  (item) => item === 'en'
                );
                if (i !== -1) {
                  this.privateProductLanguages.splice(i, 1);
                }
                this.enCompleted = false;
              }
            } else {
              const i = this.privateProductLanguages.findIndex(
                (item) => item === 'en'
              );
              if (i !== -1) {
                this.privateProductLanguages.splice(i, 1);
              }
              this.enCompleted = false;
            }
          }
        }
      } else {
        const i = this.privateProductLanguages.findIndex(
          (item) => item === 'en'
        );
        if (i !== -1) {
          this.privateProductLanguages.splice(i, 1);
        }
        this.enCompleted = false;
      }
    }
    if (this.productType === 'public') {
      if (
        this.productBasicInfo.languages[enIndex].productName &&
        this.productBasicInfo.languages[enIndex].description
      ) {
        if (tag.length) {
          // tslint:disable-next-line: prefer-for-of
          for (let i = 0; i < Object.keys(tag[0]).length; i++) {
            if (Object.keys(tag[0])[i].includes('en')) {
              this.enCompleted = true;
              break;
            } else {
              this.enCompleted = false;
            }
          }
        } else {
          this.enCompleted = false;
        }
      } else {
        this.enCompleted = false;
      }
    }
    // }
    this.privateProductLanguages = Array.from(
      new Set(this.privateProductLanguages)
    );
    this.productBasicInfo.frCompleted = this.frCompleted;
    this.productBasicInfo.nlCompleted = this.nlCompleted;
    this.productBasicInfo.enCompleted = this.enCompleted;
    this.product.frCompleted = this.frCompleted;
    this.product.nlCompleted = this.nlCompleted;
    this.product.enCompleted = this.enCompleted;
    // this.updatePrivateProductLanguages.emit(this.privateProductLanguages);
    // console.log('this.privateProductLanguages', this.privateProductLanguages);
  }

  buildForm() {
    const index = this.productBasicInfo.languages.findIndex(
      (item) => item.language === this.selectedTabLanguage
    );
    this.stepThreeForm = this.formBuilder.group({
      name: [this.productBasicInfo.languages[index].productName],
      // image: [''],
      description: [this.productBasicInfo.languages[index].description],
    });
    this.thumbnail =
      (this.productBasicInfo.image && this.productBasicInfo.image.imageUrl) ||
      null;
    this.selectedTag = this.productBasicInfo.tagList;
    this.checkLanguageCompleteness();
  }

  loadUser() {
    this.authService.currentUser$.subscribe((user) => {
      this.currentUser = user;
      this.tagBody = {
        languageCode: this.currentUser.language,
        roleCode: this.currentUser.roleCode,
        userId: this.currentUser.id,
      };
    });
  }

  switchLangauageTab(lang) {
    this.lang = lang;
    if (this.productType === 'privateprivate') {
      const index = this.productBasicInfo.languages.findIndex(
        (item) => item.language === this.selectedTabLanguage
      );
      if (
        this.productBasicInfo.languages[index].productName ||
        this.productBasicInfo.languages[index].description ||
        this.productBasicInfo.tagList.length
      ) {
        this.notificationService.showError(
          'For private product, fields need to be filled only for one language'
        );
        return;
      }
    }
    this.selectedTabLanguage = lang;
    // console.log('this.selectedTabLanguage', this.selectedTabLanguage);
    this.setBasicInfoData();
  }

  setBasicInfoData() {
    const index = this.productBasicInfo.languages.findIndex(
      (item) => item.language === this.selectedTabLanguage
    );
    // console.log(
    //   'this.productBasicInfo.languages[index]',
    //   this.productBasicInfo.languages[index]
    // );
    // this.stepThreeForm.get('name').setValue(this.productBasicInfo.languages[index].productName);
    // this.stepThreeForm.get('description').setValue(this.productBasicInfo.languages[index].description);
    this.stepThreeForm.patchValue(
      {
        name: this.productBasicInfo.languages[index].productName,
        description: this.productBasicInfo.languages[index].description,
        // image: this.thumbnail
      },
      { emitEvent: false }
    );
    // tslint:disable-next-line: no-string-literal
    this.productNameObj['productName'] = this.stepThreeForm.value.name;

    this.getProductName()
      .pipe(
        catchError((err) => {
          return of(err);
        })
      )
      .subscribe((res) => {
        this.productNameResults(res);
      });
  }

  getTagListBySearch(tag) {
    return this.generalservice.getTags(this.tagBody, tag, { loader: true });
  }

  listenChanges() {
    this.tags$
      .pipe(
        debounceTime(500),
        tap((tag) => {
          // console.log(tag);
        }),
        switchMap((tag) =>
          this.getTagListBySearch(tag).pipe(
            catchError((err) => {
              // throw of(err);
              return of(err);
            })
          )
        )
      )
      .subscribe(
        (tags) => {
          // console.log(tags);
          this.processResult(tags);
        },
        (error) => {
          // console.log('error', error)
          // throw error;
        }
      );
  }
  processResult(tags) {
    // console.log('tags', tags);
    let resultTags = [];
    if (tags.hasOwnProperty('error')) {
      // if (tags.status >= 400 && tags.status <= 599) {
      //   this.notificationService.showError(tags.error.message);
      // }
      // this.key='';
      // this.tags$ = of([])
      // this.tags.next(this.key);
      // this.listenChanges();
      const error = this.errorMessageHandler.getMessageFromError(tags);
      this.translate.get('NotificationMessages.' + error).subscribe((res) => {
        this.notificationService.showError(res);
      });
      // throw tags;
    } else {
      resultTags = tags.value.content;
    }
    // if (!resultTags.length) {
    //   this.notificationService.showError(this.tagNotFound);
    // }
    // console.log('resultTags', resultTags);
    this.filteredTagsMultipleArray = resultTags; // this.filterTag(this.key, resultTags);
  }

  filterTagsMultiple(event) {
    // console.log('event=', event);
    this.key = event;
    this.tags.next(this.key);
  }
  // tslint:disable-next-line: member-ordering
  tagdata1 = [];
  filterTag(query, tagCount: any[]): any[] {
    // this.tagData.push(tagCount);
    tagCount.forEach((tag) => {
      this.tagData.push(tag);
    });

    // tslint:disable-next-line: prefer-const
    let filtered: any[] = [];
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < tagCount.length; i++) {
      if (this.index1 === 0) {
        this.tagArray = tagCount[i].enTagName;
      } else if (this.index1 === 1) {
        this.tagArray = tagCount[i].frTagName;
      } else {
        this.tagArray = tagCount[i].nlTagName;
      }

      filtered.push(this.tagArray);
    }
    // console.log('filtered', filtered);
    return filtered;
  }

  tagsSelected() {
    this.productBasicInfo.tagList = this.selectedTag;
    // console.log('this.productBasicInfo.tagList', this.productBasicInfo.tagList);
    this.checkLanguageCompleteness();
  }

  checkValidity() {
    // console.log(
    //   'duplicate name issue=',
    //   this.duplicateVizNameEn,
    //   this.duplicateVizNameFr,
    //   this.duplicateVizNameNl
    // );

    if (
      this.duplicateVizNameEn ||
      this.duplicateVizNameFr ||
      this.duplicateVizNameNl
    ) {
      this.utilityService.showTranslatedNotificationMessage(
        'PRODUCTCREATION.DuplicateProductName',
        'ERROR'
      );
    } else {
      let isValid = false;
      // console.log('this.productBasicInfo', this.productBasicInfo);

      if (this.productType === 'public') {
        if (
          !this.productBasicInfo.languages[0].productName ||
          !this.productBasicInfo.languages[0].description ||
          !this.productBasicInfo.languages[1].productName ||
          !this.productBasicInfo.languages[1].description ||
          !this.productBasicInfo.languages[2].productName ||
          !this.productBasicInfo.languages[2].description
        ) {
          isValid = false;
          this.utilityService.showTranslatedNotificationMessage(
            'NotificationMessages.General.ThreeLangMandatory',
            'ERROR'
          );
          return isValid;
        } else {
          isValid = true;
        }
      }
      if (this.productType === 'private') {
        if (
          this.productBasicInfo.languages[0].productName ||
          this.productBasicInfo.languages[1].productName ||
          this.productBasicInfo.languages[2].productName
        ) {
          isValid = true;

          // ENGLISH
          if (
            this.productBasicInfo.languages[0].productName ||
            this.productBasicInfo.languages[0].description
          ) {
            if (
              this.productBasicInfo.languages[1].productName &&
              this.productBasicInfo.languages[1].description
            ) {
              if (this.productBasicInfo.languages[0].description) {
                if (this.productBasicInfo.languages[0].productName) {
                  isValid = true;
                } else {
                  // console.log(
                  //   'error from',
                  //   this.productBasicInfo.languages[0].language
                  // );
                  isValid = false;
                  this.utilityService.showTranslatedNotificationMessage(
                    'NotificationMessages.General.FieldsMandatory',
                    'ERROR'
                  );
                  return isValid;
                }
              } else {
                isValid = false;
                // console.log(
                //   'error from',
                //   this.productBasicInfo.languages[0].language
                // );
                this.utilityService.showTranslatedNotificationMessage(
                  'NotificationMessages.General.FieldsMandatory',
                  'ERROR'
                );
                return isValid;
              }
            }

            if (
              this.productBasicInfo.languages[2].productName &&
              this.productBasicInfo.languages[2].description
            ) {
              if (this.productBasicInfo.languages[0].description) {
                if (this.productBasicInfo.languages[0].productName) {
                  isValid = true;
                } else {
                  isValid = false;
                  // console.log(
                  //   'error from',
                  //   this.productBasicInfo.languages[0].language
                  // );
                  this.utilityService.showTranslatedNotificationMessage(
                    'NotificationMessages.General.FieldsMandatory',
                    'ERROR'
                  );
                  return isValid;
                }
              } else {
                isValid = false;
                // console.log(
                //   'error from',
                //   this.productBasicInfo.languages[0].language
                // );
                this.utilityService.showTranslatedNotificationMessage(
                  'NotificationMessages.General.FieldsMandatory',
                  'ERROR'
                );
                return isValid;
              }
            }
          }

          // FRENCH
          if (
            this.productBasicInfo.languages[1].productName ||
            this.productBasicInfo.languages[1].description
          ) {
            if (
              this.productBasicInfo.languages[0].productName &&
              this.productBasicInfo.languages[0].description
            ) {
              if (this.productBasicInfo.languages[1].description) {
                if (this.productBasicInfo.languages[1].productName) {
                  isValid = true;
                } else {
                  isValid = false;
                  // console.log(
                  //   'error from',
                  //   this.productBasicInfo.languages[1].language
                  // );
                  this.utilityService.showTranslatedNotificationMessage(
                    'NotificationMessages.General.FieldsMandatory',
                    'ERROR'
                  );
                  return isValid;
                }
              } else {
                isValid = false;
                // console.log(
                //   'error from',
                //   this.productBasicInfo.languages[1].language
                // );
                this.utilityService.showTranslatedNotificationMessage(
                  'NotificationMessages.General.FieldsMandatory',
                  'ERROR'
                );
                return isValid;
              }
            }

            if (
              this.productBasicInfo.languages[2].productName &&
              this.productBasicInfo.languages[2].description
            ) {
              if (this.productBasicInfo.languages[1].description) {
                if (this.productBasicInfo.languages[1].productName) {
                  isValid = true;
                } else {
                  isValid = false;
                  // console.log(
                  //   'error from',
                  //   this.productBasicInfo.languages[1].language
                  // );
                  this.utilityService.showTranslatedNotificationMessage(
                    'NotificationMessages.General.FieldsMandatory',
                    'ERROR'
                  );
                  return isValid;
                }
              } else {
                isValid = false;
                // console.log(
                //   'error from',
                //   this.productBasicInfo.languages[1].language
                // );
                this.utilityService.showTranslatedNotificationMessage(
                  'NotificationMessages.General.FieldsMandatory',
                  'ERROR'
                );
                return isValid;
              }
            }
          }

          // DUTCH
          if (
            this.productBasicInfo.languages[2].productName ||
            this.productBasicInfo.languages[2].description
          ) {
            if (
              this.productBasicInfo.languages[0].productName &&
              this.productBasicInfo.languages[0].description
            ) {
              if (this.productBasicInfo.languages[2].description) {
                if (this.productBasicInfo.languages[2].productName) {
                  isValid = true;
                } else {
                  isValid = false;
                  // console.log(
                  //   'error from',
                  //   this.productBasicInfo.languages[2].language
                  // );
                  this.utilityService.showTranslatedNotificationMessage(
                    'NotificationMessages.General.FieldsMandatory',
                    'ERROR'
                  );
                  return isValid;
                }
              } else {
                isValid = false;
                // console.log(
                //   'error from',
                //   this.productBasicInfo.languages[2].language
                // );
                this.utilityService.showTranslatedNotificationMessage(
                  'NotificationMessages.General.FieldsMandatory',
                  'ERROR'
                );
                return isValid;
              }
            }

            if (
              this.productBasicInfo.languages[1].productName &&
              this.productBasicInfo.languages[1].description
            ) {
              if (this.productBasicInfo.languages[2].description) {
                if (this.productBasicInfo.languages[2].productName) {
                  isValid = true;
                } else {
                  isValid = false;
                  // console.log(
                  //   'error from',
                  //   this.productBasicInfo.languages[2].language
                  // );
                  this.utilityService.showTranslatedNotificationMessage(
                    'NotificationMessages.General.FieldsMandatory',
                    'ERROR'
                  );
                  return isValid;
                }
              } else {
                isValid = false;
                // console.log(
                //   'error from',
                //   this.productBasicInfo.languages[2].language
                // );
                this.utilityService.showTranslatedNotificationMessage(
                  'NotificationMessages.General.FieldsMandatory',
                  'ERROR'
                );
                return isValid;
              }
            }
          }
        } else {
          isValid = false;
          this.utilityService.showTranslatedNotificationMessage(
            'NotificationMessages.General.FieldsMandatory',
            'ERROR'
          );
          return isValid;
        }
      }

      if (this.productType === 'public') {
        if (this.productBasicInfo.image.imageUrl) {
          // if (!this.productBasicInfo.image.imageUrl.includes('https://')) {
          //   try {
          //     if (btoa(atob(this.productBasicInfo.image.imageUrl)) === this.productBasicInfo.image.imageUrl) {
          //       console.log('btoa')
          //       isValid = true;
          //     }
          //   } catch (err) {
          //     isValid = false;
          //     this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Viz.ImageRequired', 'ERROR');
          //   }
          // }
          isValid = true;
        } else {
          isValid = false;
          // console.log('not present');
          this.utilityService.showTranslatedNotificationMessage(
            'NotificationMessages.Viz.ImageRequired',
            'ERROR'
          );
          return isValid;
        }
      }

      if (this.productType === 'public') {
        if (!this.productBasicInfo.tagList.length) {
          isValid = false;
          this.utilityService.showTranslatedNotificationMessage(
            'NotificationMessages.Viz.AtleasetOneTag',
            'ERROR'
          );
          return isValid;
        }
        const tags = [];
        this.productBasicInfo.tagList.forEach((tag) => {
          // || tag.enTagName.toLowerCase() !== 'viz'
          tags.push(tag.enTagName.toLowerCase());
        });

        if ((!tags.includes('product') && !tags.includes('viz')) && (!tags.includes('report') && !tags.includes('visualisation'))) {
          isValid = false;
          this.utilityService.showTranslatedNotificationMessage(
            'NotificationMessages.Viz.tagCategory',
            'ERROR'
          );
          return isValid;
        }
      }
      return isValid;
    }
  }

  onFileSelected(event: any, section: any, index?: any) {
    if (event && event[0]) {
      // console.log('section', section);
      // console.log('event', event);

      this.validateImage(event[0], 10, 550, 425).subscribe((res) => {
        if (res) {
          // console.log('res', res);
          this.getImageAsDataUrl(event[0]);
        }
      });
    }
  }

  validateImage(fileUpload, maxSize, maxWidth, maxHeight) {
    return from(
      new Promise((resolve, reject) => {
        // console.log('fileUpload.type', fileUpload.type);
        if (
          fileUpload.type.includes('image/jpeg') ||
          fileUpload.type.includes('image/jpg') ||
          fileUpload.type.includes('image/png')
        ) {
          if (fileUpload.size >= maxSize * 1000 * 1000) {
            // this.notificationService.showError(`File size more than 10mb is not allowed`);
            this.utilityService.showTranslatedNotificationMessage(
              'NotificationMessages.Landing.FileSizeValidate',
              'ERROR'
            );

            resolve(false);
          }
          // reader.readAsDataURL(fileUpload);
          this.getBase64(fileUpload).subscribe((res: any) => {
            resolve(true);
            // if (res.imageHeight > maxHeight || res.imageWidth > maxWidth) {
            //   // this.notificationService.showError('Height and Width must not exceed the given values.');
            //   this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Landing.ImageDimensionValidate', 'ERROR');
            //   resolve(false);
            // } else {
            // }
          });
        } else {
          // this.notificationService.showError('File type should be image.');
          this.utilityService.showTranslatedNotificationMessage(
            'NotificationMessages.Landing.FileTypeImage',
            'ERROR'
          );
          resolve(false);
        }
      })
    );
  }

  getBase64(file) {
    return from(
      new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
          // this.getImageDimension(reader.result).subscribe(res => {
          resolve(reader.result);
          // });
        };
        reader.onerror = (error) => reject(error);
      })
    );
  }

  getImageAsDataUrl(file: any) {
    const reader = new FileReader();
    let imageAsDataUrl: any = '';
    reader.addEventListener(
      'load',
      () => {
        const img = new Image();
        img.onload = () => {
          this.imageWidth = img.width;
          this.imageHeight = img.height;
        };
        // convert image file to base64 string
        const imageData = reader.result;
        imageAsDataUrl = imageData.toString();
        const image = this.sanitizer.bypassSecurityTrustResourceUrl(
          imageAsDataUrl
        );
        this.thumbnail = image;
        // console.log('this.thumbnail', this.thumbnail);
        this.productBasicInfo.image.imageUrl = this.thumbnail.changingThisBreaksApplicationSecurity;
        this.productBasicInfo.image.updateFlag = true;
        this.nextStep.emit({ product: this.productBasicInfo });
        // return imageAsDataUrl;
      },
      false
    );
    if (file) {
      reader.readAsDataURL(file);
    }
  }

  submit(value) {
    if (this.checkValidity()) {
      // this.productBasicInfo.image.imageUrl = this.thumbnail;
      // console.log('this.thumbnail', this.thumbnail);
      // console.log(this.productBasicInfo);

      // console.log('enCompleted', this.enCompleted);
      // console.log('frCompleted', this.frCompleted);
      // console.log('nlCompleted', this.nlCompleted);
      this.productBasicInfo.frCompleted = this.frCompleted;
      this.productBasicInfo.nlCompleted = this.nlCompleted;
      this.productBasicInfo.enCompleted = this.enCompleted;
      {
        this.nextStep.emit({ product: this.productBasicInfo, type: value });
        if (this.productType === 'private') {
          this.privateProductLanguages = Array.from(
            new Set(this.privateProductLanguages)
          );
          // console.log(
          //   'this.privateProductLanguages',
          //   this.privateProductLanguages
          // );
          this.updatePrivateProductLanguages.emit(this.privateProductLanguages);
        }
      }
    }
  }

  checkValidityBeforeMoving() {
    if (this.checkValidity()) {
      // this.productBasicInfo.image.imageUrl = this.thumbnail;
      // console.log('this.thumbnail', this.thumbnail);
      // console.log(this.productBasicInfo);

      // console.log('enCompleted', this.enCompleted);
      // console.log('frCompleted', this.frCompleted);
      // console.log('nlCompleted', this.nlCompleted);
      this.productBasicInfo.frCompleted = this.frCompleted;
      this.productBasicInfo.nlCompleted = this.nlCompleted;
      this.productBasicInfo.enCompleted = this.enCompleted;
      {
        if (this.productType === 'private') {
          this.privateProductLanguages = Array.from(
            new Set(this.privateProductLanguages)
          );
          // console.log(
          //   'this.privateProductLanguages',
          //   this.privateProductLanguages
          // );
          this.updatePrivateProductLanguages.emit(this.privateProductLanguages);
        }
      }
      return { product: this.productBasicInfo, isValid: true };
    } else {
      return { product: this.productBasicInfo, isValid: false };
    }
  }

  getCharts() {
    this.generalservice.getCharts().subscribe((res) => {
      // console.log('res', res);
    });
  }
  // tslint:disable-next-line: member-ordering
  productNameObj = {};
  // tslint:disable-next-line: member-ordering
  lang = 'fr';
  // tslint:disable-next-line: member-ordering
  duplicateVizName = false;
  // tslint:disable-next-line: member-ordering
  duplicateVizNameEn;
  // tslint:disable-next-line: member-ordering
  duplicateVizNameFr;
  // tslint:disable-next-line: member-ordering
  duplicateVizNameNl;
  // tslint:disable-next-line: member-ordering
  productNameEn;
  // tslint:disable-next-line: member-ordering
  productNameFr;
  // tslint:disable-next-line: member-ordering
  productNameNl;

  getProductName() {
    // tslint:disable-next-line: no-string-literal
    this.productNameObj['language'] = this.lang;

    return this.generalservice.checkProductName(this.productNameObj, {
      loader: true,
    });
  }
  onProductNameChanges() {
    this.stepThreeForm
      .get('name')
      .valueChanges.pipe(
        debounceTime(800),
        distinctUntilChanged(),
        switchMap((form) =>
          this.getProductName().pipe(
            catchError((err) => {
              return of(err);
            })
          )
        )
      )
      .subscribe((res) => {
        this.productNameResults(res);
        // console.log('duplicateVizName2=', this.duplicateVizName);
      });
  }
  productNameResults(res) {
    // console.log('in process results....');

    if (this.lang === 'en') {
      // console.log('en language');

      if (res.hasOwnProperty('error') && res.error.status === 409) {
        this.duplicateVizName = true;
        this.duplicateVizNameEn = true;
      } else {
        this.duplicateVizName = false;

        this.duplicateVizNameEn = false;
      }
    }
    // console.log('duplicateVizName1=', this.duplicateVizName);

    if (this.lang === 'fr') {
      if (res.hasOwnProperty('error') && res.error.status === 409) {
        this.duplicateVizName = true;
        this.duplicateVizNameFr = true;
      } else {
        this.duplicateVizName = false;

        this.duplicateVizNameFr = false;
      }
    }
    if (this.lang === 'nl') {
      if (res.hasOwnProperty('error') && res.error.status === 409) {
        this.duplicateVizName = true;
        this.duplicateVizNameNl = true;
      } else {
        this.duplicateVizName = false;

        this.duplicateVizNameNl = false;
      }
    }

    if (
      res.hasOwnProperty('error') && res.error.status === 409
        ? // tslint:disable-next-line: no-conditional-assignment
        (this.duplicateVizName = true)
        : // tslint:disable-next-line: no-conditional-assignment
        (this.duplicateVizName = false)
    ) {
      //   this.duplicateVizName=true;
    }
    this.checkValidation();

    // console.log('duplicateVizName1 end=', this.duplicateVizName);
  }
  checkValidation() {
    // console.log('duplicateVizName3=', this.duplicateVizName);
    // console.log(
    //   'on check validation',
    //   this.productNameFr + '===' + this.productNameObj['productName']
    // );

    // tslint:disable-next-line: no-string-literal

    // tslint:disable-next-line: no-string-literal // tslint:disable-next-line: max-line-length
    if (this.productNameEn && this.productNameObj['productName'] && this.productNameEn.toString().toLowerCase() === this.productNameObj['productName'].toString().toLowerCase()) {
      this.duplicateVizName = false;
      this.duplicateVizNameEn = false;
    }
    // tslint:disable-next-line: no-string-literal // tslint:disable-next-line: max-line-length
    if (this.productNameFr && this.productNameObj['productName'] && this.productNameFr.toString().toLowerCase() === this.productNameObj['productName'].toString().toLowerCase()) {
      this.duplicateVizName = false;
      this.duplicateVizNameFr = false;
    }
    // tslint:disable-next-line: no-string-literal // tslint:disable-next-line: max-line-length
    if (this.productNameNl && this.productNameObj['productName'] && this.productNameNl.toString().toLowerCase() === this.productNameObj['productName'].toString().toLowerCase()) {
      this.duplicateVizName = false;
      this.duplicateVizNameNl = false;
    }
  }
  ngOnDestroy() {
    // console.log(this.privateProductLanguages);
    this.updatePrivateProductLanguages.emit(this.privateProductLanguages);
  }
}
