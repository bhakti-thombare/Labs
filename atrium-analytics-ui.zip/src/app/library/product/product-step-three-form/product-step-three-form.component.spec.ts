import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductStepThreeFormComponent } from './product-step-three-form.component';

describe('ProductStepThreeFormComponent', () => {
  let component: ProductStepThreeFormComponent;
  let fixture: ComponentFixture<ProductStepThreeFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductStepThreeFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductStepThreeFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
