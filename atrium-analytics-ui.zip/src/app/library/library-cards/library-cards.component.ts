import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
  Router,
  Event,
  NavigationStart,
  ActivatedRoute,
} from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { GeneralService } from '../shared/general-service.service';
import { SharedDataServiceService } from 'src/app/core/services/shared-data-service.service';
@Component({
  selector: 'ab-library-cards',
  templateUrl: './library-cards.component.html',
  styleUrls: ['./library-cards.component.scss'],
})
export class LibraryCardsComponent implements OnInit {
  public getViz;
  vizDetails = [];
  filterTags;
  postVizObj;
  page = 0;
  page1 = 0;
  viewDetails = [];
  selectedLanguage;
  libraryCards2 = [];
  vizNotFound = false;
  vizRecords = true;
  productRecords = true;
  viewDetailsProducts = [];
  libraryCardsProduct2 = [];
  productButtonDisabled;
  vizButtonDisabled;

  @Output() viewEvent = new EventEmitter<any>();
  moreProductFlag: boolean=false;
  size: number;
  filterProduct: boolean = false;
  filterViz: boolean = false;

  @Input('getViz')
  set data(getViz: any) {
    this.sharedData.filterCategoryData.filterProductTag == true? this.filterProduct =true :this.filterProduct =false;
    this.sharedData.filterCategoryData.filterVizTag == true? this.filterViz =true : this.filterViz =false;
    if (this.showViz || this.sharedData.filterCategoryData.filterVizTag || this.sharedData.filterCategoryData.filterProductTag) {
      this.showViz = true;

      if (!this.sharedData.filterCategoryData.filterVizTag && this.showViz && !this.sharedData.filterCategoryData.filterProductTag) {
        this.showViz = false;
      }

      if (getViz !== undefined) {
        this.page1 = 0;
        this.size = 6;
        // this.vizNotFound = false;
        if (getViz.length === 0) {
          this.vizNotFound = true;
          this.vizRecords = false;
        }
        // this.productRecords = true;
        this.filterTags = getViz.filterTags;
        this.postVizObj = getViz.postVizObj;

        this.getViz = getViz;

        this.libraryCards = [];
        if (this.getViz.length === 0) {
          return;
        } else {
          this.vizDetails = this.getViz.value.content;
          this.vizButtonDisabled = getViz.value.last;

          this.setMessage(this.selectedLanguage);
          if (this.libraryCards.length > 0) {
            this.vizRecords = true;
          }

          // this.vizDetails['libraryCards']=this.libraryCards;
        }
      }
    }
  }
  productNotFound = false;
  getProduct;
  libraryCardsProducts = [];
  productDetails = [];
  // @Input('getProduct')
  // set data1(getProduct: any) {
  //   if (
  //     this.showProduct ||
  //     this.sharedData.filterCategoryData.filterProductTag
  //   ) {
  //     this.showProduct = true;
  //     if (
  //       this.sharedData.filterCategoryData.filterProductTag &&
  //       !this.showProduct
  //     ) {
  //       this.showProduct = false;
  //     }
  //     if (!this.sharedData.filterCategoryData.filterProductTag) {
  //       this.showProduct = false;
  //     }

  //     this.page = 0;
  //     // this.productNotFound = false;

  //     // this.vizRecords = true;
  //     this.productRecords = true;

  //     if (getProduct.length === 0) {
  //       this.productNotFound = true;
  //       this.productRecords = false;
  //     }
  //     this.filterTags = getProduct.filterTags;
  //     this.postVizObj = getProduct.postVizObj;

  //     this.getProduct = getProduct;
  //     this.libraryCardsProducts = [];
  //     if (this.getProduct.length === 0) {
  //       return;
  //     } else {
  //       this.productDetails = this.getProduct.value.content;
  //       this.productButtonDisabled = getProduct.value.last;

  //       this.setMessage(this.selectedLanguage);
  //     }
  //   }
  // }
  constructor(
    private router: Router,
    private authService: AuthService,
    private translate: TranslateService,
    private generealService: GeneralService,
    private sharedData: SharedDataServiceService,
    private route: ActivatedRoute
  ) {
    router.events.subscribe((event: Event) => {
      if (event instanceof NavigationStart) {
        // this.filterTags = [...new Set(this.filterTags)];
        (this.sharedData.filterCategoryData.vizButtonDisabled = this.vizButtonDisabled),
          (this.sharedData.filterCategoryData.productButtonDisabled = this.productButtonDisabled),
          (this.sharedData.filterCategoryData.libraryCards = this.libraryCards);
        this.sharedData.filterCategoryData.filterTags = this.filterTags;
        this.sharedData.filterCategoryData.vizDetails = this.vizDetails;
        this.sharedData.filterCategoryData.productDetails = this.productDetails;

        this.sharedData.filterCategoryData.libraryCardsProducts = this.libraryCardsProducts;
        this.sharedData.filterCategoryData.postVizObj = this.postVizObj;
        // Navigation started.
      }
    });
  }
  libraryCards;
  currentUser;
  checkUser = false;

  onClick() {
    this.router.navigate(['/library/select-type']);
  }
  // tslint:disable-next-line: member-ordering
  showViz = true;
  // tslint:disable-next-line: member-ordering
  showProduct = true;
  viewMoreRecords() {
    this.showViz = true;
    // this.showProduct = false;
    this.sharedData.filterCategoryData.filterProductTag == true? this.sharedData.filterCategoryData.value1 = 'product':this.sharedData.filterCategoryData.value1 = null;
    this.sharedData.filterCategoryData.filterVizTag == true? this.sharedData.filterCategoryData.value2 = 'viz' :this.sharedData.filterCategoryData.value2 = null;
    // this.productRecords = false;
    // this.showProduct?false:this.libraryCardsProducts = [];
    this.vizRecords = true;
    this.viewEvent.emit({ viz: this.sharedData.filterCategoryData.filterVizTag, product: this.sharedData.filterCategoryData.filterProductTag });

    this.page1 = this.page1 + 1;
    // tslint:disable-next-line: no-string-literal
    if (!this.vizButtonDisabled) {
      this.generealService
        .getCards(this.postVizObj, { page: this.page1 , size: 6})
        .subscribe((res) => {
          this.vizButtonDisabled = res.value.last;

          this.viewDetails = [];
          this.libraryCards2 = [];
          this.libraryCards = [];
          this.viewDetails = res.value.content;
          this.viewDetails.forEach((element) => {
            this.vizDetails.push(element);
          });
          

          this.vizDetails.forEach((element) => {
            const index0 = element.elementInfo.findIndex(
              (x) => x.language.toLowerCase() === 'en' || x.language.toLowerCase() === 'english'
            );
            const index1 = element.elementInfo.findIndex(
              (x) => x.language.toLowerCase() === 'fr' || x.language.toLowerCase() === 'french'
            );
            const index2 = element.elementInfo.findIndex(
              (x) => x.language.toLowerCase() === 'nl' || x.language.toLowerCase() === 'dutch'
            );
            if (this.selectedLanguage === 'en') {
              this.libraryCards2.push(element.elementInfo[index0]);
            } else if (this.selectedLanguage === 'fr') {
              this.libraryCards2.push(element.elementInfo[index1]);
            } else {
              this.libraryCards2.push(element.elementInfo[index2]);
            }
          });
          let i = 0;
          this.libraryCards2.forEach((card) => {
            card.thumbnail = this.vizDetails[i].thumbnail;
            card.elementId = this.vizDetails[i].elementId;
            i++;
          });
          this.libraryCards2.forEach((element) => {
            this.libraryCards.push(element);
          });
          this.setMessage(this.selectedLanguage);
        });
    }
    else{
      this.productButtonDisabled;
    }
  }
  viewMoreRecordsProduct() {
    // this.showViz = false;
    this.showProduct = true;
    this.sharedData.filterCategoryData.value1 = 'product';
    this.sharedData.filterCategoryData.value2 = 'viz';

    this.showViz?false:this.libraryCards = [];
    this.productRecords = true;
    // this.vizRecords = false;
    this.viewEvent.emit({ product: this.productRecords, viz: this.vizRecords });
    this.page = this.page + 1;
    // tslint:disable-next-line: no-string-literal
    if (!this.productButtonDisabled) {
      this.generealService
        .filterProducts(this.postVizObj, {
          page: this.page,
          size: 3,
        })
        .subscribe((res) => {
          this.productButtonDisabled = res.value.last;

          this.libraryCardsProducts=[];
          this.viewDetailsProducts = [];
          this.libraryCardsProduct2 = [];
          this.viewDetailsProducts = res.value.content;

          this.viewDetailsProducts.forEach((element) => {
            this.productDetails.push(element);
          });

          this.productDetails.forEach((element) => {
            const index0 = element.publishProductDetails.findIndex(
              (x) => x.language === 'English'
            );
            const index1 = element.publishProductDetails.findIndex(
              (x) => x.language === 'French'
            );
            const index2 = element.publishProductDetails.findIndex(
              (x) => x.language === 'Dutch'
            );
            if (this.selectedLanguage === 'en') {
              this.libraryCardsProduct2.push(
                element.publishProductDetails[index0]
              );
            } else if (this.selectedLanguage === 'fr') {
              this.libraryCardsProduct2.push(
                element.publishProductDetails[index1]
              );
            } else {
              this.libraryCardsProduct2.push(
                element.publishProductDetails[index2]
              );
            }
          });
          let i = 0;

          this.libraryCardsProduct2.forEach((card) => {
            card.thumbnail = this.productDetails[i].image.imageUrl;
            card.productId = this.productDetails[i].publishProductId;
            i++;
          });
          this.libraryCardsProduct2.forEach((element) => {
            this.libraryCardsProducts.push(element);
          });
        });
    }
    else{
      this.productButtonDisabled;
    }
  }
  loadUser() {
    this.authService.currentUser$.subscribe((user) => {
      this.currentUser = user.role;

      if (this.currentUser === 'admin' || this.currentUser === 'champion') {
        this.checkUser = true;
      }
    });
  }
  setMessage(lang) {
    this.libraryCards = [];
    let i = 0;

    switch (lang) {
      case 'en':
        this.vizDetails.forEach((element) => {
         if (element.elementType == "product") {
            const index = element.elementInfo.findIndex(
              (x) => x.language.toLowerCase() === 'en'
            );
            if (element.productType === 'private') {
              const index2 = element.elementInfo.findIndex(
                (x) => x.name !== null
              );
              this.libraryCards.push(element.elementInfo[index2]);
            } else {
              this.libraryCards.push(
                element.elementInfo[index]
              );
            }
          } 
          else{
            const index = element.elementInfo.findIndex((x) => x.language.toLowerCase() === 'en');
            this.libraryCards.push(element.elementInfo[index]);
          }
        });

        this.libraryCards.forEach((card) => {
          card.thumbnail = this.vizDetails[i].thumbnail;
          card.elementId = this.vizDetails[i].elementId;
          card.link = this.vizDetails[i].elementType.toLowerCase() == 'viz' ? '/library/viz-details/' + this.vizDetails[i].elementId : '/library/product-details/' + this.vizDetails[i].elementId;
          i++;
        });
        // this.libraryCardsProducts = [];

        // this.productDetails.forEach((element) => {
        //   // this.libraryCards.push(element.vizInfo[0]);
        //   const index = element.publishProductDetails.findIndex(
        //     (x) => x.language === 'English'
        //   );
        //   if (element.productType === 'private') {
        //     const index2 = element.publishProductDetails.findIndex(
        //       (x) => x.productName !== null
        //     );
        //     this.libraryCardsProducts.push(
        //       element.publishProductDetails[index2]
        //     );
        //   } else {
        //     this.libraryCardsProducts.push(
        //       element.publishProductDetails[index]
        //     );
        //   }
        // });

        // let j = 0;

        // this.libraryCardsProducts.forEach((card) => {
        //   card.thumbnail = this.productDetails[j].image.imageUrl;
        //   card.productId = this.productDetails[j].publishProductId;
        //   j++;
        // });

        break;
      case 'fr':
        this.vizDetails.forEach((element) => {

          if (element.elementType == "product") {
            const index = element.elementInfo.findIndex(
              (x) => x.language.toLowerCase() === 'fr' || x.language.toLowerCase() === 'french'
            );
            if (element.productType === 'private') {
              const index2 = element.elementInfo.findIndex(
                (x) => x.name !== null
              );
              this.libraryCards.push(element.elementInfo[index2]);
            } else {
              this.libraryCards.push(
                element.elementInfo[index]
              );
            }
          }
          else{
            const index1 = element.elementInfo.findIndex((x) => x.language.toLowerCase() === 'fr');
            this.libraryCards.push(element.elementInfo[index1]);
          }
         
        });
        this.libraryCards.forEach((card) => {
          card.thumbnail = this.vizDetails[i].thumbnail;
          card.elementId = this.vizDetails[i].elementId;
          card.link = this.vizDetails[i].elementType.toLowerCase() == 'viz' ? '/library/viz-details/' + this.vizDetails[i].elementId : '/library/product-details/' + this.vizDetails[i].elementId;
          i++;
        });
       
        // this.libraryCardsProducts = [];
        // this.productDetails.forEach((element) => {
        //   // this.libraryCards.push(element.vizInfo[0]);
        //   const index = element.publishProductDetails.findIndex(
        //     (x) => x.language === 'French'
        //   );
        //   if (element.productType === 'private') {
        //     const index2 = element.publishProductDetails.findIndex(
        //       (x) => x.productName !== null
        //     );
        //     this.libraryCardsProducts.push(
        //       element.publishProductDetails[index2]
        //     );
        //   } else {
        //     this.libraryCardsProducts.push(
        //       element.publishProductDetails[index]
        //     );
        //   }
        //   // this.libraryCardsProducts.push(element.publishProductDetails[index]);
        // });

        // let j2 = 0;

        // this.libraryCardsProducts.forEach((card) => {
        //   card.thumbnail = this.productDetails[j2].image.imageUrl;
        //   card.productId = this.productDetails[j2].publishProductId;
        //   j2++;
        // });
        break;

      case 'nl':
        this.vizDetails.forEach((element) => {
          if (element.elementType == "product") {
            const index = element.elementInfo.findIndex(
              (x) => x.language.toLowerCase() === 'nl' || x.language.toLowerCase() === 'dutch'
            );
            if (element.productType === 'private') {
              const index2 = element.elementInfo.findIndex(
                (x) => x.name !== null
              );
              this.libraryCards.push(element.elementInfo[index2]);
            } else {
              this.libraryCards.push(
                element.elementInfo[index]
              );
            }
          }
          else {
            const index1 = element.elementInfo.findIndex((x) => x.language.toLowerCase() === 'nl');
            this.libraryCards.push(element.elementInfo[index1]);
          }
        });
        this.libraryCards.forEach((card) => {
          card.thumbnail = this.vizDetails[i].thumbnail;
          card.elementId = this.vizDetails[i].elementId;
          card.link = this.vizDetails[i].elementType.toLowerCase() == 'viz' ? '/library/viz-details/' + this.vizDetails[i].elementId : '/library/product-details/' + this.vizDetails[i].elementId;
          i++;
        });
        // this.libraryCardsProducts = [];
        // this.productDetails.forEach((element) => {
        //   // this.libraryCards.push(element.vizInfo[0]);
        //   const index = element.publishProductDetails.findIndex(
        //     (x) => x.language === 'Dutch'
        //   );
        //   if (element.productType === 'private') {
        //     const index2 = element.publishProductDetails.findIndex(
        //       (x) => x.productName !== null
        //     );
        //     this.libraryCardsProducts.push(
        //       element.publishProductDetails[index2]
        //     );
        //   } else {
        //     this.libraryCardsProducts.push(
        //       element.publishProductDetails[index]
        //     );
        //   }
        //   // this.libraryCardsProducts.push(element.publishProductDetails[index]);
        // });

        // let j3 = 0;

        // this.libraryCardsProducts.forEach((card) => {
        //   card.thumbnail = this.productDetails[j3].image.imageUrl;
        //   card.productId = this.productDetails[j3].publishProductId;
        //   j3++;
        // });
        break;
    }
  }
  // tslint:disable-next-line: member-ordering
  checkPreviousUrl;
  ngOnInit() {
    this.loadUser();
    this.selectedLanguage = localStorage.getItem('language');
    this.checkPreviousUrl = this.route.snapshot.paramMap.get('previousUrl')
      ? this.route.snapshot.paramMap.get('previousUrl')
      : 'no-value';

    if (
      this.sharedData.filterCategoryData.allCategories.length &&
      (this.checkPreviousUrl.includes('viz-details') ||
        this.checkPreviousUrl.includes('product-details'))
    ) {
      // this.libraryCardsProducts=[];
      // this.libraryCards=[];
      this.vizDetails = this.sharedData.filterCategoryData.vizDetails;
      this.productDetails = this.sharedData.filterCategoryData.productDetails;

      this.libraryCards = this.sharedData.filterCategoryData.libraryCards;
      this.libraryCardsProducts = this.sharedData.filterCategoryData.libraryCardsProducts;
      this.filterTags = this.sharedData.filterCategoryData.filterTags;
      (this.productButtonDisabled = this.sharedData.filterCategoryData.productButtonDisabled),
        (this.vizButtonDisabled = this.sharedData.filterCategoryData.vizButtonDisabled);

      this.postVizObj = this.sharedData.filterCategoryData.postVizObj;
      if (!this.sharedData.filterCategoryData.filterVizTag && !this.sharedData.filterCategoryData.filterProductTag) {
        this.libraryCards = [];
        this.vizDetails = [];
      }
      // if (!this.sharedData.filterCategoryData.filterProductTag) {
      //   this.libraryCardsProducts = [];
      //   this.productDetails = [];
      // }

      // if (this.libraryCardsProducts.length > 0) {
      //   this.productRecords = true;
      // }

      if (this.libraryCards.length !== 0) {
        this.vizRecords = true;
      } else {
        this.vizRecords = false;
      }
    }
    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.page = 0;
      this.selectedLanguage = event.lang;
      this.setMessage(this.selectedLanguage);
    });
  }

  viewMore() {
    // if (!this.productButtonDisabled && this.productRecords ) {
    //   this.viewMoreRecordsProduct();
    // }
    // if (!this.vizButtonDisabled && this.vizRecords) {
    //   this.viewMoreRecordsViz();
    // }
    this.viewMoreRecords();
  }

  // checkStatus(){
  //   if((!this.productRecords && !this.vizRecords) || (this.showProduct && !this.productRecords && this.vizRecords) || (!this.vizRecords && !this.productRecords) || (this.showViz && !this.vizRecords && this.productRecords)){
  //     return true;
  //   }
  // }
}
