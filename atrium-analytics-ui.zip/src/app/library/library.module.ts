import { NgModule } from '@angular/core';
import { AuthModule } from '../auth/auth.module';

import { CommonModule } from '@angular/common';
import { LibraryRoutingModule } from './library-routing.module';
import { LibraryDashboardComponent } from './library-dashboard/library-dashboard.component';
// import { LibraryLeftSideMenuComponent } from './left-menu-viz-creation/left-menu-viz-creation';
import { SharedModule } from '../shared/shared.module';
import { LeftMenuProductCreationComponent } from './left-menu-product-creation/left-menu-product-creation.component';
import { ProductCreationComponent } from './product/product-creation/product-creation.component';
import { LeftMenuVizCreationComponent } from './left-menu-viz-creation/left-menu-viz-creation.component';
import { VizCreationComponent } from './viz-creation/viz-creation.component';
import { TypeOfContentCreationComponent } from './type-of-content-creation/type-of-content-creation.component';
import { ChipsModule } from 'primeng/chips';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CollapseModule } from 'ngx-bootstrap/collapse';

import { VizDetailsComponent } from './viz-details/viz-details.component';
import { InvitePeopleComponent } from './invite-people/invite-people.component';
import { ProductStepOneFormComponent } from './product/product-step-one-form/product-step-one-form.component';
import { ProductStepThreeFormComponent } from './product/product-step-three-form/product-step-three-form.component';
import { ProductStepFourFormComponent } from './product/product-step-four-form/product-step-four-form.component';
import { ProductStepFiveFormComponent } from './product/product-step-five-form/product-step-five-form.component';
import { ProductStepSixFormComponent } from './product/product-step-six-form/product-step-six-form.component';
import { GridsterModule } from 'angular-gridster2';
import { NgxDocViewerModule } from 'ngx-doc-viewer';
import { WidgetComponent } from './product/widget/widget.component';
import { FileUploadModule } from 'ng2-file-upload';
import { ProductPreviewDetailsComponent } from './product/product-preview-details/product-preview-details.component';
import { LibraryCardsComponent } from './library-cards/library-cards.component';
import { SelectChartFormComponent } from './product/select-chart-form/select-chart-form.component';
import { ProductDetailsComponent } from './product/product-details/product-details.component';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ProductDownloadDetailsComponent } from './product/product-download-details/product-download-details.component';
import { ProductInvitePeopleFormComponent } from './product/product-invite-people-form/product-invite-people-form.component';
import { VizInfoFormatterPipe } from './viz-info-formatter.pipe';
import { ProductGuidePageComponent } from './product-guide-page/product-guide-page.component';
import { GuidedTourModule, GuidedTourService } from 'ngx-guided-tour';


@NgModule({
  declarations: [LibraryDashboardComponent,
    LeftMenuVizCreationComponent,
    LeftMenuProductCreationComponent,
    ProductCreationComponent,
    LeftMenuVizCreationComponent,
    VizCreationComponent,
    TypeOfContentCreationComponent,
    VizDetailsComponent,
    InvitePeopleComponent,
    ProductStepOneFormComponent,
    ProductStepThreeFormComponent,
    ProductStepFourFormComponent,
    ProductStepFiveFormComponent,
    ProductStepSixFormComponent,
    WidgetComponent,
    ProductPreviewDetailsComponent,
    LibraryCardsComponent,
    SelectChartFormComponent,
    ProductDetailsComponent,
    ProductDownloadDetailsComponent,
    ProductInvitePeopleFormComponent,
    VizInfoFormatterPipe,
    ProductGuidePageComponent
  ],
  imports: [
    ReactiveFormsModule,
    GridsterModule,
    NgxDocViewerModule,
    CommonModule,
    FileUploadModule,
    LibraryRoutingModule,
    SharedModule,
    AuthModule,
    ChipsModule,
    AutoCompleteModule,
    FormsModule,
    GuidedTourModule,
    BsDropdownModule.forRoot(),
    CollapseModule.forRoot()

  ],
  providers: [GuidedTourService]
})
export class LibraryModule { }
