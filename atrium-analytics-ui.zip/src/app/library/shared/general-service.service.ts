
import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  constructor(private restService: RestService) { }
  apiUrl = environment.apiUrl;

  createViz(body: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/viz`, body, null, true);
  }
  getTags(body: any, key: any, queryParams: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/tag/search?search=tagName,${key}`, body, queryParams, true);
  }
  editViz(body: any, vizId: any) {
    return this.restService.put(`${this.apiUrl}/v2/api/viz/${vizId}`, body, null, true);
  }
  getViz(body: any, queryParams, vizId: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/viz/${vizId}`, body, queryParams, true);
  }
  deleteViz(body: any, vizId: any) {
    return this.restService.delete(`${this.apiUrl}/v2/api/viz/${vizId}`, body, null, true);
  }
  addFavourite(body: any, queryParams) {
    return this.restService.post(`${this.apiUrl}/v2/api/viz/favorite`, body, queryParams, true);
  }
  searchUser(body: any, queryParams) {
    return this.restService.post(`${this.apiUrl}/v2/api/viz/search`, body, queryParams, true);
  }
  inviteUser(body: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/viz/invite`, body, null, true);
  }
  getAllCategories(body: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/category/all`, body, null, true);
  }

  getTagsByCategory(body: any, queryParams: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/tag/category`, body, queryParams, true);
  }
  getVizName(body: any, queryParams: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/viz/name`, body, queryParams, true);
  }
  filterViz(body: any, queryParams: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/library/cards/viz`, body, queryParams, true);
  }
  filterProducts(body: any, queryParams: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/library/cards/product`, body, queryParams, true);
  }
  getCards(body: any, queryParams: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/library/cards`, body, queryParams, true);
  }


  // product apis

  // create public product
  createProduct(product: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/product/create`, product, undefined, true);
  }

  updateProduct(product: any) {
    return this.restService.post(`${this.apiUrl}/v2/api/product/update`, product, undefined, true);
  }

  getCharts() {
    return this.restService.post(`${this.apiUrl}/v2/api/product/chart`, {}, undefined, true);
  }

  getProductDetails(id, isDraft) {
    return this.restService.post(`${this.apiUrl}/v2/api/product/view?productId=${id}&isDraft=${isDraft}`, {}, undefined, true);
  }

  deleteProduct(id, isDraft) {
    return this.restService.put(`${this.apiUrl}/v2/api/product/delete?isDraft=${isDraft}&productId=${id}`, {}, undefined, true);
  }

  markProductFavourite(productId, isFavourite) {
    const body = {
      favorite: isFavourite,
      publishProductId: productId
    };
    return this.restService.post(`${this.apiUrl}/v2/api/product/favourite`, body, { loader: true }, true);
  }

  getChartsUrl(body) {
    // for same side to make correct request
    body.urlList.forEach(element => {
      // console.log('element', element)
      if (element.includes('https') || element.includes('http')) {
        element = '/views/' + (element.split('/views/').pop());
      }
    });
    return this.restService.post(`${this.apiUrl}/v2/api/product/trusted`, body, undefined, true);
  }

  getUsers(queryParams) {
    return this.restService.post(`${this.apiUrl}/v2/api/product/users/all`, {}, queryParams, true);
  }

  addUsersToProduct(body) {
    return this.restService.post(`${this.apiUrl}/v2/api/product/invite/users`, body, undefined, true);
  }

  checkProductName(body, queryParams) {
    return this.restService.post(`${this.apiUrl}/v2/api/product/name`, body, queryParams, true);
  }
  // to get guide product details
  getGuideProductDetails() {
    return this.restService.post(`${this.apiUrl}/v2/api/product/guide`, {}, undefined, true);
  }


  // update tutorial flags specific to user
  updateTutorialFlags(body: any, queryParams: any) {
    return this.restService.put(`${this.apiUrl}/v2/api/user/tutorial`, body, queryParams, true);
  }

}
