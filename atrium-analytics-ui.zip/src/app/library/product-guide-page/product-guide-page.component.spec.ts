import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductGuidePageComponent } from './product-guide-page.component';

describe('ProductGuidePageComponent', () => {
  let component: ProductGuidePageComponent;
  let fixture: ComponentFixture<ProductGuidePageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductGuidePageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductGuidePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
