import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ab-product-guide-page',
  templateUrl: './product-guide-page.component.html',
  styleUrls: ['./product-guide-page.component.scss']
})
export class ProductGuidePageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
