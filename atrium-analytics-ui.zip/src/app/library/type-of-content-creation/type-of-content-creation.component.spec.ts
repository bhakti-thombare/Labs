import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TypeOfContentCreationComponent } from './type-of-content-creation.component';

describe('TypeOfContentCreationComponent', () => {
  let component: TypeOfContentCreationComponent;
  let fixture: ComponentFixture<TypeOfContentCreationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TypeOfContentCreationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TypeOfContentCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
