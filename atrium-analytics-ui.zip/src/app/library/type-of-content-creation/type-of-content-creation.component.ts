import { Component, OnInit } from '@angular/core';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';

@Component({
  selector: 'ab-type-of-content-creation',
  templateUrl: './type-of-content-creation.component.html',
  styleUrls: ['./type-of-content-creation.component.scss'],
})
export class TypeOfContentCreationComponent implements OnInit {
  squarefill1 = false;
  squarefill2 = false;
  selectedLanguage;
  selectType;

  constructor(private translate: TranslateService,
              private router: Router,
              private utilityService: UtilityService,
              private notificationService: NotificationService) {}
  onSelectP() {
    this.squarefill2 = false;
    this.squarefill1 = true;
  }
  onSelectV() {
    this.squarefill1 = false;
    this.squarefill2 = true;
  }
  next() {
    if (!this.squarefill1 && !this.squarefill2) {
      // this.notificationService.showError(this.selectType);
      this.utilityService.showTranslatedNotificationMessage('NotificationMessages.Viz.SelectContentType', 'ERROR');
      return;
    }
    if (this.squarefill1) {
      this.router.navigate(['library/product-creation']);
    } else {
      this.router.navigate(['library/viz-creation']);
    }
  }

  setMessage(lang) {
    switch (lang) {
      case 'en':
        this.selectType = 'Please select type of content';

        break;
      case 'fr':
        this.selectType = 'Veuillez sélectionner le type de contenu';


        break;
      case 'nl':
        this.selectType = 'Selecteer het type item';

        break;
    }
  }
  ngOnInit() {
    this.selectedLanguage = localStorage.getItem('language');
    this.setMessage(this.selectedLanguage);

    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.selectedLanguage = event.lang;
      this.setMessage(this.selectedLanguage);
    });
  }
}
