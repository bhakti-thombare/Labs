import { VizInfoFormatterPipe } from './viz-info-formatter.pipe';

describe('VizInfoFormatterPipe', () => {
  it('create an instance', () => {
    const pipe = new VizInfoFormatterPipe();
    expect(pipe).toBeTruthy();
  });
});
