import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductCreationComponent } from './product/product-creation/product-creation.component';
import { LibraryDashboardComponent } from './library-dashboard/library-dashboard.component';
// import {LibraryLeftSideMenuComponent} from './left-menu-viz-creation/left-menu-viz-creation';
import { VizCreationComponent } from './viz-creation/viz-creation.component';
import { VizDetailsComponent } from './viz-details/viz-details.component';
import { TypeOfContentCreationComponent } from './type-of-content-creation/type-of-content-creation.component';
import { ProductDetailsComponent } from './product/product-details/product-details.component';
import { ProductGuidePageComponent } from './product-guide-page/product-guide-page.component';
import { AuthGuard } from '../core/guards/auth.guard';
import { AdminChampionGuard } from '../core/guards/admin-champion.guard';


const routes: Routes = [
  { path: '', redirectTo: 'dashboard' },
  {
    path: 'dashboard', component: LibraryDashboardComponent, children: [
    ]
  },
  { path: 'product', component: ProductGuidePageComponent },

  {
    path: 'viz-creation', component: VizCreationComponent, canActivate: [AuthGuard, AdminChampionGuard]
  },
  {
    path: 'viz-creation/:id', component: VizCreationComponent, canActivate: [AuthGuard, AdminChampionGuard]
  },
  {
    path: 'viz-details/:id', component: VizDetailsComponent
  },
  {
    path: 'product-creation', component: ProductCreationComponent, canActivate: [AuthGuard, AdminChampionGuard]
  },
  {
    path: 'select-type', component: TypeOfContentCreationComponent, canActivate: [AuthGuard, AdminChampionGuard]
  },
  {
    path: 'product-details/:id', component: ProductDetailsComponent,
  },
  {
    path: 'product-edit/:id', component: ProductCreationComponent, canActivate: [AuthGuard, AdminChampionGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LibraryRoutingModule { }
