import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  ViewChildren,
  ElementRef,
  AfterContentInit,
  AfterViewInit,
  ChangeDetectorRef,
  ViewRef,
} from '@angular/core';
import {
  Router,
  Event,
  NavigationStart,
  ActivatedRoute,
  RoutesRecognized,
} from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { GeneralService } from '../shared/general-service.service';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { FormControl, FormBuilder, FormGroup } from '@angular/forms';
import {
  debounceTime,
  distinctUntilChanged,
  switchMap,
  catchError,
  filter,
  pairwise,
} from 'rxjs/operators';
import { of } from 'rxjs';
import { ErrorMessageHandlerService } from 'src/app/core/services/error-message-handler.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { SharedDataServiceService } from 'src/app/core/services/shared-data-service.service';
import * as _ from 'lodash';
import {
  GuidedTourService,
  GuidedTour,
  TourStep,
  Orientation,
} from 'ngx-guided-tour';
import { Cookie } from 'src/app/core/services/cookie';
import { LoaderService } from 'src/app/core/services/loader.service';

@Component({
  selector: 'ab-library-dashboard',
  templateUrl: './library-dashboard.component.html',
  styleUrls: ['./library-dashboard.component.scss'],
})
export class LibraryDashboardComponent implements OnInit, AfterViewInit {
  @Output() public emitDataViz = new EventEmitter<any>();
  @Output() public emitDataProduct = new EventEmitter<any>();

  @ViewChildren('inputs') public inputs: ElementRef<HTMLInputElement>[];
  currentUser: string;
  loggedInUser: any;
  checkUser = false;
  checked = false;
  isCollapsed = false;
  selectedCategoryId;
  isCategorySelected = false;
  filterTags = [];
  userObj = {};
  language;
  userId;
  allCategories;
  allTags;
  name;
  flag = false;
  selectedLanguage;
  search: FormGroup;
  postVizObj = { searchByName: '' };
  vizDetails;
  productDetails = [];
  filterVizTag = true;
  filterProductTag = true;
  checkPreviousUrl;
  filterApplied: string;
  typeCategoryTag: string;
  guidedTour: GuidedTour;
  messageObject: any;
  resetFilter;
  stepWith = 350;
  tutorialCalled = true;
  observer: MutationObserver;
  page: number =0;
  size: number = 6;
  constructor(
    private loaderService: LoaderService,
    private router: Router,
    private fb: FormBuilder,
    private authService: AuthService,
    private generalService: GeneralService,
    private translate: TranslateService,
    private errorMessageHandler: ErrorMessageHandlerService,
    private notificationService: NotificationService,
    private utilityService: UtilityService,
    private sharedData: SharedDataServiceService,
    private route: ActivatedRoute,
    private guidedTourService: GuidedTourService,
    private cdRef: ChangeDetectorRef
  ) {
    this.selectedLanguage = localStorage.getItem('language');
    router.events.subscribe((event: Event) => {
      if (event instanceof NavigationStart) {
        // this.filterTags = [...new Set(this.filterTags)];
        this.sharedData.filterCategoryData.allCategories = this.allCategories;
        this.sharedData.filterCategoryData.filterTags = this.filterTags;
        this.sharedData.filterCategoryData.postVizObj = this.postVizObj;
        this.sharedData.filterCategoryData.searchKey = this.search.value.searchKey;
        this.sharedData.filterCategoryData.filterVizTag = this.filterVizTag;
        if (!this.filterVizTag) {
          this.sharedData.filterCategoryData.libraryCards = [];
        }
        if (!this.filterProductTag) {
          this.sharedData.filterCategoryData.libraryCardsProducts = [];
        }
        this.sharedData.filterCategoryData.filterProductTag = this.filterProductTag;
      }
    });
  }
  onClick() {
    this.router.navigate(['/library/select-type']);
  }
  onChecked(event, label, tagId, categoryName) {
    label = label.toLowerCase();
    const index = this.allCategories.findIndex(
      (item) => item.categoryName === categoryName
    );
    for (const element of this.allCategories[index][categoryName]) {
      // tslint:disable-next-line: no-var-keyword
      var categoryFlag;
      element.categoryId === 1 ? (categoryFlag = true) : (categoryFlag = false);
      if (element.tagId === tagId) {
        element.checked = event.target.checked;
        break;
      }
    }

    if (event.target.checked) {
      // tslint:disable-next-line: no-unused-expression
      categoryFlag === true ? '' : this.filterTags.push(tagId);

      if (label === 'product' || label === 'report') {
        this.filterProductTag = true;
        this.sharedData.filterCategoryData.value1 = 'product';
      }
      if (label === 'viz' || label === 'visualisation') {
        this.filterVizTag = true;
        this.sharedData.filterCategoryData.value2 = 'viz';
      }
    }
    if (!event.target.checked) {
      this.filterTags.forEach((tag) => {
        if (tag === tagId) {
          // tslint:disable-next-line: no-shadowed-variable
          const index = this.filterTags.indexOf(tag);
          this.filterTags.splice(index, 1);
        }
      });
      if (label === 'product' || label === 'report') {
        this.filterProductTag = false;
        this.sharedData.filterCategoryData.value1 = null;
      }
      if (label === 'viz' || label === 'visualisation') {
        this.filterVizTag = false;
        this.sharedData.filterCategoryData.value2 = null;
      }
    }
  }
  loadUser() {
    this.authService.currentUser$.subscribe((user) => {
      this.loggedInUser = user;
      this.currentUser = user.role;
      this.userId = user.id;

      this.language = user.language;
      if (this.currentUser === 'admin' || this.currentUser === 'champion') {
        this.checkUser = true;
      }
    });
    this.userObj = {
      userId: this.userId,
      roleCode: this.currentUser,
      languageCode: this.language,
    };
  }

  getTags(categoryId, categoryName, size, page, index?) {
    this.flag = true;
    // tslint:disable-next-line: no-string-literal
    this.userObj['categoryId'] = categoryId;
    this.name = 'categoryName';
    if (index !== -1) {
      this.allCategories[index].open = !this.allCategories[index].open;
    }

    if (
      (this.allCategories[index] && !this.allCategories[index].open) ||
      index === -1
    ) {
      this.generalService
        .getTagsByCategory(this.userObj, { size, page, loader: true })
        .subscribe((res) => {
          const last = res.value.last;
          this.allTags = res.value.content;
          categoryName = categoryName.replace(/ +/g, '');
          this.allCategories.forEach((category: any) => {
            // tslint:disable-next-line: label-position
            category.size = size;
            category.page = page;
            category.last = last;
            if (category[categoryName] === undefined) {
              category[categoryName] = [];
            }
            if (category[categoryName].length && categoryId === 1) {
              category[categoryName] = [];
            }
            if (categoryId === 1) {
              this.allTags.forEach((tag) => {
                //  this.filterTags.push(tag.tagId);
                if (
                  this.sharedData.filterCategoryData.value1 === 'viz' &&
                  this.sharedData.filterCategoryData.value2 === 'product'
                ) {
                  category[categoryName].push({
                    label: tag.enTagName,
                    categoryId: tag.categoryId,
                    tagId: tag.tagId,
                    engTagName: tag.enTagName,
                    enTagName: tag.enTagName,
                    frTagName: tag.frTagName,
                    nlTagName: tag.nlTagName,
                    checked: false,
                  });
                } else if (
                  this.sharedData.filterCategoryData.value1 !== null ||
                  this.sharedData.filterCategoryData.value2 !== null
                ) {
                  category[categoryName].push({
                    label: tag.enTagName,
                    categoryId: tag.categoryId,
                    tagId: tag.tagId,
                    engTagName: tag.enTagName,
                    enTagName: tag.enTagName,
                    frTagName: tag.frTagName,
                    nlTagName: tag.nlTagName,
                    // tslint:disable-next-line: max-line-length
                    checked:
                      tag.categoryId === 1 &&
                        (tag.enTagName.toLowerCase() === 'viz' || tag.enTagName.toLowerCase() === 'visualisation') &&
                        this.sharedData.filterCategoryData.value2 === 'viz'
                        ? true
                        : // tslint:disable-next-line: max-line-length
                        tag.categoryId === 1 &&
                          (tag.enTagName.toLowerCase() === 'product' || tag.enTagName.toLowerCase() === 'report') &&
                          this.sharedData.filterCategoryData.value1 ===
                          'product'
                          ? true
                          : false,
                  });
                } else {
                  category[categoryName].push({
                    label: tag.enTagName,
                    categoryId: tag.categoryId,
                    tagId: tag.tagId,
                    engTagName: tag.enTagName,
                    enTagName: tag.enTagName,
                    frTagName: tag.frTagName,
                    nlTagName: tag.nlTagName,
                    checked: true,
                  });
                }
                // category.id= res.value.content.categoryId;
              });
            } else {
              this.allTags.forEach((tag) => {
                category[categoryName].push({
                  label: tag.enTagName,
                  categoryId: tag.categoryId,
                  tagId: tag.tagId,
                  engTagName: tag.enTagName,
                  enTagName: tag.enTagName,
                  frTagName: tag.frTagName,
                  nlTagName: tag.nlTagName,
                  checked: false,
                });
              });
            }
            category[categoryName] = _.uniqWith(
              category[categoryName],
              _.isEqual
            );
            category[categoryName] = _.uniqBy(category[categoryName], 'tagId');
          });
          this.sortTags();
        });
    }
  }

  getAllCategory() {
    this.generalService.getAllCategories(this.userObj).subscribe((res) => {
      this.allCategories = res.value.content;

      this.allCategories.forEach((category: any) => {
        if (category.categoryId === 1) {
          category.open = true;
          category.name = category.enCategoryName;
          category.categoryName = category.enCategoryName;
          category.categoryId = category.categoryId;
          category.size = 5;

          category.categoryName = category.categoryName.replace(/ +/g, '');
          this.getTags('1', 'Type', 5, 0, -1);
        } else {
          category.open = true;
          category.name = category.enCategoryName;
          category.categoryName = category.enCategoryName;
          category.categoryId = category.categoryId;
          category.size = 5;

          category.categoryName = category.categoryName.replace(/ +/g, '');
        }
      });
    });
  }

  getVizDetails() {
    this.postVizObj.searchByName = this.search.value.searchKey;
    this.filterTags = [...new Set(this.filterTags)];

    // tslint:disable-next-line: no-string-literal
    this.postVizObj['filterByTags'] = this.filterTags;
    const loading = false;
    this.filterVizTag && this.filterProductTag ? this.elementType=['viz','product']: this.filterVizTag? this.elementType=['viz'] :  this.filterProductTag? this.elementType=['product'] : this.elementType=[];
    this.postVizObj['filterByElementType'] = this.elementType;
    return this.generalService.getCards(this.postVizObj, { page : 0 , size: 6, loader: true });
  }
  // getProductDetails() {
  //   this.postVizObj.searchByName = this.search.value.searchKey;
  //   this.filterTags = [...new Set(this.filterTags)];

  //   // tslint:disable-next-line: no-string-literal
  //   this.postVizObj['filterByTags'] = this.filterTags;

  //   return this.generalService.filterProducts(this.postVizObj, {
  //     loader: true,
  //   });
  // }

  getSearchResults() {
    // tslint:disable-next-line: no-string-literal
    // this.emitDataViz.emit((this.vizDetails = []));
    this.postVizObj.searchByName = this.search.value.searchKey;
    this.search.valueChanges
      .pipe(
        debounceTime(500),
        distinctUntilChanged(),
        filter((viz, product) => this.filterVizTag === true && this.filterProductTag === true),
        switchMap((viz, product) =>
          this.getVizDetails().pipe(
            catchError((err) => {
              return of(err);
            })
          )
        )
      )
      .subscribe((res) => {
        this.processResultViz(res,1);
      });

    this.postVizObj.searchByName = this.search.value.searchKey;
    this.search.valueChanges
      .pipe(
        debounceTime(500),
        distinctUntilChanged(),
        filter((product) => this.filterProductTag === true && this.filterVizTag !== true),
        switchMap((product) =>
        this.getVizDetails().pipe(
            catchError((err) => {
              return of(err);
            })
          )
        )
      )
      .subscribe((res) => {
        this.processResultViz(res,2);
      });

    this.postVizObj.searchByName = this.search.value.searchKey;
    this.search.valueChanges
      .pipe(
        debounceTime(500),
        distinctUntilChanged(),
        filter((viz) => this.filterVizTag === true && this.filterProductTag !== true),
        switchMap((viz) =>
          this.getVizDetails().pipe(
            catchError((err) => {
              return of(err);
            })
          )
        )
      )
      .subscribe((res) => {
        this.processResultViz(res,3);
      });
  }

  // processResultProduct(data) {
  //   this.productDetails = [];
  //   if (data.hasOwnProperty('error')) {
  //     const error = this.errorMessageHandler.getMessageFromError(data);
  //     this.translate.get('NotificationMessages.' + error).subscribe((res) => {
  //       this.notificationService.showError(res);
  //     });
  //   } else {
  //     this.productDetails = data;
  //     // tslint:disable-next-line: no-string-literal
  //     this.productDetails['filterTags'] = this.filterTags;
  //     // tslint:disable-next-line: no-string-literal
  //     this.productDetails['postVizObj'] = this.postVizObj;
  //     this.emitDataProduct.emit(this.productDetails);
  //   }
  // }
  processResultViz(data,flag) {
    this.vizDetails = [];
    if (data.hasOwnProperty('error')) {
      const error = this.errorMessageHandler.getMessageFromError(data);
      if (flag == 1) {
        this.translate.get('NotificationMessages.Viz.NoResults' + error).subscribe((res) => {
          this.notificationService.showError(res);
        });
      } else if (flag == 2) {
        this.translate.get('NotificationMessages.Product.ProductNotFound' + error).subscribe((res) => {
          this.notificationService.showError(res);
        });
      }
      else if (flag == 3) {
        this.translate.get('NotificationMessages.Viz.VizNotFound' + error).subscribe((res) => {
          this.notificationService.showError(res);
        });
      }
      // this.errorMessageHandler.getMessageFromError(data);
    } else {
      this.vizDetails = data;
      // tslint:disable-next-line: no-string-literal
      this.vizDetails['filterTags'] = this.filterTags;
      // tslint:disable-next-line: no-string-literal
      this.vizDetails['postVizObj'] = this.postVizObj;
      this.emitDataViz.emit(this.vizDetails);
    }
  }

  showerror(){

  }

  elementType=[];
  loadCards() {
    this.filterTags = [...new Set(this.filterTags)];

    this.vizDetails = [];
    // tslint:disable-next-line: no-string-literal
    this.postVizObj['searchByName'] = null;
    // tslint:disable-next-line: no-string-literal
    this.postVizObj['filterByTags'] = this.filterTags;
    this.filterVizTag && this.filterProductTag ? this.elementType=['viz','product']: this.filterVizTag? this.elementType=['viz'] :  this.filterProductTag? this.elementType=['product'] : this.elementType=[];
    this.postVizObj['filterByElementType'] = this.elementType;
    this.generalService
      .getCards(this.postVizObj, { page : 0, size: 6 })
      .subscribe((res) => {
        this.vizDetails = res;
        // tslint:disable-next-line: no-string-literal
        this.vizDetails['postVizObj'] = this.postVizObj;

        // tslint:disable-next-line: no-string-literal
        this.vizDetails['filterTags'] = this.filterTags;

        this.emitDataViz.emit(this.vizDetails);
      });
    // this.productDetails = [];

    // this.generalService
    //   .filterProducts(this.postVizObj, { loader: true })
    //   .subscribe((res) => {
    //     this.productDetails = res;
    //     // tslint:disable-next-line: no-string-literal
    //     this.productDetails['postVizObj'] = this.postVizObj;

    //     // tslint:disable-next-line: no-string-literal
    //     this.productDetails['filterTags'] = this.filterTags;

    //     this.emitDataProduct.emit(this.productDetails);
    //   });
  }
  applyFilters() {
    this.filterTags = [...new Set(this.filterTags)];

    this.vizDetails = [];
    // tslint:disable-next-line: no-string-literal
    this.postVizObj['searchByName'] = this.search.value.searchKey;
    // tslint:disable-next-line: no-string-literal
    this.postVizObj['filterByTags'] = this.filterTags;
    this.filterVizTag && this.filterProductTag ? this.elementType=['viz','product']: this.filterVizTag? this.elementType=['viz'] :  this.filterProductTag? this.elementType=['product'] : this.elementType=[];
    this.postVizObj['filterByElementType'] = this.elementType;
    if (!this.filterProductTag && !this.filterVizTag) {
      this.notificationService.showError(this.typeCategoryTag);
    } else {
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth',
      });
      this.notificationService.showInfo(this.filterApplied);
    }
    // console.log("filterviz tag=",this.filterVizTag,this.filterProductTag);
    if (this.filterVizTag && !this.filterProductTag) {
      this.sharedData.filterCategoryData.filterProductTag = false;
      this.sharedData.filterCategoryData.filterVizTag = true;
      this.generalService
        .getCards(this.postVizObj, { page : 0 , size: 6 , loade: true})
        .subscribe((res) => {
          this.vizDetails = res;
          // tslint:disable-next-line: no-string-literal
          this.vizDetails['postVizObj'] = this.postVizObj;

          // tslint:disable-next-line: no-string-literal
          this.vizDetails['filterTags'] = this.filterTags;
          this.processResultViz(res,3);
          this.emitDataViz.emit(this.vizDetails);
        }, err => {
          this.processResultViz1(3);
        });
    }

    if (this.filterProductTag && !this.filterVizTag) {
      this.sharedData.filterCategoryData.filterVizTag = false;
      this.sharedData.filterCategoryData.filterProductTag = true;

      // tslint:disable-next-line: no-unused-expression
      this.sharedData.filterCategoryData.value1 === 'product';
      this.generalService
        .getCards(this.postVizObj, { page : 0, size : 6 , loade: true})
        .subscribe((res) => {
          this.vizDetails = res;
          // tslint:disable-next-line: no-string-literal
          this.vizDetails['postVizObj'] = this.postVizObj;

          // tslint:disable-next-line: no-string-literal
          this.vizDetails['filterTags'] = this.filterTags;
          this.emitDataViz.emit(this.vizDetails);

        }, err => {
          this.processResultViz1(2);
        });
    }
    if (this.filterProductTag && this.filterVizTag) {
      this.sharedData.filterCategoryData.filterProductTag = true;
      this.sharedData.filterCategoryData.filterVizTag = true;
      this.generalService
        .getCards(this.postVizObj, { page : 0, size : 6 , loade: true})
        .subscribe((res) => {
          this.vizDetails = res;
          // tslint:disable-next-line: no-string-literal
          this.vizDetails['postVizObj'] = this.postVizObj;

          // tslint:disable-next-line: no-string-literal
          this.vizDetails['filterTags'] = this.filterTags;
          this.processResultViz(res,1);
          this.emitDataViz.emit(this.vizDetails);
        }, err => {
          this.processResultViz1(1);
        });
      // this.generalService
      //   .filterProducts(this.postVizObj, { loader: false })
      //   .subscribe((res) => {
      //     this.productDetails = res;
      //     // tslint:disable-next-line: no-string-literal
      //     this.productDetails['postVizObj'] = this.postVizObj;

      //     // tslint:disable-next-line: no-string-literal
      //     this.productDetails['filterTags'] = this.filterTags;

      //     this.emitDataProduct.emit(this.productDetails);
      //   });
    }
  }

  processResultViz1(flag: number) {
    if (flag == 1) {
      this.translate.get('NotificationMessages.Viz.NoResults').subscribe((res) => {
        this.notificationService.showError(res);
      });
    } else if (flag == 2) {
      this.translate.get('NotificationMessages.Product.ProductNotFound' ).subscribe((res) => {
        this.notificationService.showError(res);
      });
    }
    else if (flag == 3) {
      this.translate.get('NotificationMessages.Viz.VizNotFound').subscribe((res) => {
        this.notificationService.showError(res);
      });
    }
  }

  uncheckAll() {
    this.filterVizTag = true;
    this.filterProductTag = true;
    this.sharedData.filterCategoryData.filterVizTag = true;
    this.sharedData.filterCategoryData.filterProductTag = true;
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth',
    });
    this.filterTags = [];
    this.allCategories = [];
    this.getAllCategory();
    this.loadCards();

    this.notificationService.showInfo(this.resetFilter);
  }
  receiveMessage(event) {
    if (event.product && !event.viz) {
      this.filterProductTag = true;
      this.filterVizTag = false;
      this.allCategories[0].Type.forEach((element) => {
        if (element.engTagName.toLowerCase() === 'viz' || element.engTagName.toLowerCase() === 'visualisation') {
          element.checked = false;
        }
        if (element.engTagName.toLowerCase() === 'product' || element.engTagName.toLowerCase() === 'report') {
          element.checked = true;
        }
      });
    } else if (!event.product && event.viz) {
      this.filterProductTag = false;
      this.filterVizTag = true;
      this.allCategories[0].Type.forEach((element) => {
        if (element.engTagName.toLowerCase() === 'viz' || element.engTagName.toLowerCase() === 'visualisation') {
          element.checked = true;
        }
        if (element.engTagName.toLowerCase() === 'product' || element.engTagName.toLowerCase() === 'report') {
          element.checked = false;
        }
      });
    } else {
      this.filterProductTag = true;
      this.filterVizTag = true;
      this.allCategories[0].Type.forEach((element) => {
        if (element.engTagName.toLowerCase() === 'viz' || element.engTagName.toLowerCase() === 'visualisation') {
          element.checked = true;
        }
        if (element.engTagName.toLowerCase() === 'product' || element.engTagName.toLowerCase() === 'report') {
          element.checked = true;
        }
      });
    }
  }
  onScroll(event, id, name, size, page, pageLast) {
    if (

      !pageLast
    ) {
      this.getTags(id, name, size, page + 1, -1);
    }
  }
  setMessage(lang) {
    switch (lang) {
      case 'en':
        this.filterApplied = 'Filters applied successfully.';
        this.typeCategoryTag = 'Please select at least one type category tag.';
        this.resetFilter = 'Filters reset successfully';
        break;
      case 'fr':
        this.filterApplied = 'Filtres appliqués avec succès.';
        this.typeCategoryTag =
          'Veuillez sélectionner au moins un tag de la catégorie type.';
        this.resetFilter = 'Filtres réinitialisés avec succès';

        break;
      case 'nl':
        this.filterApplied = 'Filters succesvol toegepast.';
        this.typeCategoryTag =
          'Selecteer ten minste één tag van type categorie';
        this.resetFilter = 'Filters zijn met succes gereset';

        break;
    }
  }

  ngOnInit() {
    // this.guidedTourService.startTour(this.guidedTour);
    this.search = this.fb.group({
      searchKey: new FormControl(),
    });
    this.checkPreviousUrl = this.route.snapshot.paramMap.get('previousUrl')
      ? this.route.snapshot.paramMap.get('previousUrl')
      : 'no-value';

    // this.getSearchResults();

    this.selectedLanguage = localStorage.getItem('language');
    this.setMessage(this.selectedLanguage);
    this.setTourMessages();
    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.selectedLanguage = event.lang;
      this.setMessage(this.selectedLanguage);
      this.sortTags();
      this.setTourMessages();

      // this.filterProductTag = true;
      // this.filterVizTag = true;
      // this.applyFilters();
    });
    this.loadUser();

    if (
      this.sharedData.filterCategoryData.allCategories.length &&
      (this.checkPreviousUrl.includes('viz-details') ||
        this.checkPreviousUrl.includes('product-details'))
    ) {
      this.search.patchValue({
        searchKey: this.sharedData.filterCategoryData.searchKey,
      });
      this.allCategories = this.sharedData.filterCategoryData.allCategories;
      this.filterTags = this.sharedData.filterCategoryData.filterTags;
      this.emitDataProduct.emit(
        this.sharedData.filterCategoryData.libraryCardsProducts
      );
      this.emitDataViz.emit(this.sharedData.filterCategoryData.libraryCards);
      this.filterVizTag = this.sharedData.filterCategoryData.filterVizTag;
      this.filterProductTag = this.sharedData.filterCategoryData.filterProductTag;

      this.getSearchResults();
    } else {
      this.sharedData.filterCategoryData.filterVizTag = true;
      this.sharedData.filterCategoryData.filterProductTag = true;
      this.getAllCategory();
      this.loadCards();
      this.getSearchResults();
    }

    this.observer = new MutationObserver((dom) => {
      // console.log('dom', dom)
      if (document.getElementsByClassName('LD-4').length) {
        // console.log('document.getElementById(\'HSD-2\')', document.getElementsByClassName('HSD-2')[0])
        // console.log('document.getElementById(\'HSD-2\')', document.getElementsByClassName('HSD-2')[0].parentElement.parentElement);
        const tourblock = document.getElementsByClassName('LD-4')[0].parentElement;
        const tourblock2 = document.getElementsByClassName('LD-4')[0].parentElement.parentElement;
        tourblock2.style.top = '-11px';
        tourblock.style.paddingBottom = '30px';
      }
      if (document.getElementsByClassName('LD-3').length) {
        // console.log('document.getElementById(\'HSD-1\')', document.getElementsByClassName('HSD-1')[0])
        // console.log('document.getElementById(\'HSD-1\')', document.getElementsByClassName('HSD-1')[0].parentElement.parentElement);
        const tourblock = document.getElementsByClassName('LD-3')[0].parentElement;
        const tourblock2 = document.getElementsByClassName('LD-3')[0].parentElement.parentElement;
        tourblock2.style.top = '-9px';
        tourblock.style.paddingBottom = 'unset';
      }
      if (document.getElementsByClassName('LD-2').length) {
        // console.log('document.getElementById(\'HSD-2\')', document.getElementsByClassName('HSD-2')[0])
        // console.log('document.getElementById(\'HSD-2\')', document.getElementsByClassName('HSD-2')[0].parentElement.parentElement);
        const tourblock = document.getElementsByClassName('LD-2')[0].parentElement;
        const tourblock2 = document.getElementsByClassName('LD-2')[0].parentElement.parentElement;
        tourblock2.style.top = '-7px';
        tourblock.style.paddingBottom = '30px';
      }
      if (document.getElementsByClassName('LD-1').length) {
        // console.log('document.getElementById(\'HSD-2\')', document.getElementsByClassName('HSD-2')[0])
        // console.log('document.getElementById(\'HSD-2\')', document.getElementsByClassName('HSD-2')[0].parentElement.parentElement);
        const tourblock = document.getElementsByClassName('LD-1')[0].parentElement;
        const tourblock2 = document.getElementsByClassName('LD-1')[0].parentElement.parentElement;
        tourblock2.style.top = 'unset';
        tourblock.style.paddingBottom = '30px';
      }

    });
    this.utilityService.startTour.subscribe((res) => {
      if (res) {
        if (this.router.url.toString().includes('/library/dashboard')) {
          this.startTour();
        }
      }
    });
  }
  sortTags() {
    this.allCategories.forEach((category: any) => {
      // tslint:disable-next-line: label-position
      if (!category.open && category.enCategoryName.toLowerCase() !== 'year') {
        category[category.enCategoryName] = _.orderBy(
          category[category.enCategoryName],
          [
            (tag) =>
              tag[this.selectedLanguage + 'TagName'].trim().toLowerCase(),
          ],
          ['asc']
        );
      }
    });
  }

  ngAfterViewInit() {
    if (this.cdRef && !(this.cdRef as ViewRef).destroyed) {
      this.cdRef.detectChanges();
    }
    // this.startTour();
    this.loaderService.isLoading.subscribe((v) => {
      if (!v) {
        if (this.loggedInUser) {
          // console.log('this.loggedInUser.role', this.loggedInUser.role);
          // tslint:disable-next-line: max-line-length
          if (
            this.loggedInUser.role.toString().toLowerCase() !== 'admin' &&
            this.loggedInUser.role.toString().toLowerCase() !== 'champion'
          ) {
            if (this.loggedInUser.tutorialLibrary) {
              const data = {
                tutorialDashboard: this.loggedInUser.tutorialDashboard,
                tutorialLibrary: false,
                tutorialProduct: this.loggedInUser.tutorialProduct,
              };
              if (this.tutorialCalled) {
                const queryParams = {
                  loader: true,
                };
                this.tutorialCalled = false;
                this.generalService
                  .updateTutorialFlags(data, queryParams)
                  .subscribe((res) => {
                    this.loggedInUser.tutorialLibrary = false;
                    this.authService.updateCurrentUser(this.loggedInUser);
                  });
              }
              this.startTour();
            }
          }
        } else {
          this.setCookieForLibraryTutorial();
        }
      }
    });
  }

  startTour() {
    this.observer.observe(document.getElementsByTagName('ngx-guided-tour')[0], { subtree: true, characterData: true, childList: true });
    this.stepWith = 350;
    const tourSteps: TourStep[] = [
      {
        // selector: '.library-step-one',
        content: `<p class="LD-1 step-one-library-tutorial-1">
        ${this.messageObject.LibraryTutorialText.Step1Part1}
        <br>
        <br>
        ${this.messageObject.LibraryTutorialText.Step1Part2}
        <ul>
        <li >
        ${this.messageObject.LibraryTutorialText.Step1Part3}
        </li>
        <br>
        <li>
        ${this.messageObject.LibraryTutorialText.Step1Part4}
        </li>
        </ul>
        </p>`,
        orientation: Orientation.Center,
        skipStep: false,
        action: () => {
          this.stepWith = 350;
        },
        closeAction: () => {
          this.stepWith = 290;
        },
      },
      {
        selector: '.library-step-two',
        content: `<p class="LD-2">${this.messageObject.LibraryTutorialText.Step2}</p>`,
        orientation: Orientation.Right,
        skipStep: false,
      },
      {
        selector: '.library-step-three',
        content: `<p class="LD-3">${this.messageObject.LibraryTutorialText.Step3Part1}</p>
                  <p>${this.messageObject.LibraryTutorialText.Step3Part2}</p>`,
        orientation: Orientation.Right,
        skipStep: false,
        scrollAdjustment: 5000
      },
      {
        selector: '.library-step-four',
        content: `<p class="LD-4">${this.messageObject.LibraryTutorialText.Step4}</p>`,
        orientation: Orientation.Right,
        skipStep: false,

        scrollAdjustment: -5000,
      },
      {
        selector: '.library-step-five',
        content: `<p class="LD-1">${this.messageObject.LibraryTutorialText.Step5}</p>`,
        orientation: Orientation.Right,
        skipStep: false,
      },
      // {
      //   selector: '.library-step-six',
      //   content: `<p class="LD-1">${this.messageObject.LibraryTutorialText.Step6}</p>`,
      //   orientation: Orientation.Right,
      //   skipStep: false,
      //   scrollAdjustment: 300,
      // },
      {
        selector: '.library-step-seven',
        content: `<p class="LD-1">${this.messageObject.LibraryTutorialText.Step7}</p>`,
        orientation: Orientation.Right,
        skipStep: false,
      },
    ];
    this.guidedTour = {
      tourId: 'library-dashboard',
      useOrb: false,
      steps: tourSteps,
      skipCallback: () => {
        this.observer.disconnect();
        this.utilityService.startTour.next(false);
      },
      completeCallback: () => {
        this.observer.disconnect();
        this.utilityService.startTour.next(false);
      },
      preventBackdropFromAdvancing: true,
    };
    this.guidedTourService.startTour(this.guidedTour);
    if (this.cdRef && !(this.cdRef as ViewRef).destroyed) {
      this.cdRef.detectChanges();
      this.cdRef.detectChanges();
    }
  }

  setTourMessages() {
    if (this.selectedLanguage === 'en') {
      this.messageObject = {
        LibraryTutorialText: {
          Step1Part1:
            'This page gathers all the information you can access on this platform.',
          Step1Part2: 'Two types are available :',
          // tslint:disable-next-line: max-line-length
          Step1Part3:
            // tslint:disable-next-line: max-line-length
            'Report : In there you will find answer about a broad topic with curated visualization, tables information to help you increase your knowledge.',
          Step1Part4:
            'Visualization : Smallest piece of information, it gives you a view on a specific topic.',
          Step2:
            'Click and activate filters to find the information you are interested in.',
          Step3Part1: 'After selecting your filters, press "Apply filters" to filter the content of the page.',
          Step3Part2: 'Press "Reset" if you want to remove all filters applied',
          Step4: 'Search by keywords on all reports and visualisations.',
          Step5:
            'Find a selection of reports and visualisations based on your filters selection.',
          // Step6: 'Find a selection of visualisation based on your filters selection.',
          Step7: 'Once you spot something, click on it and go explore.',
        },
      };
    }
    if (this.selectedLanguage === 'nl') {
      this.messageObject = {
        LibraryTutorialText: {
          Step1Part1:
            'Op deze pagina kunt u alle informatie vinden waartoe u toegang hebt op dit platform.',
          Step1Part2: 'Twee soorten informatie zijn beschikbaar :',
          // tslint:disable-next-line: max-line-length
          Step1Part3:
            // tslint:disable-next-line: max-line-length
            'Rapporten : Rapporten helpen u brede onderwerpen te bevatten, door middel van de verschillende visualisaties, grafieken, afbeeldingen, video\'s, etc. die in een rapport te vinden zijn.',
          Step1Part4:
            'Visualisaties : Visualisaties bieden informatie over specifieke onderwerpen.',
          Step2:
            'Klik en activeer filters om de informatie te vinden waarin u geïnteresseerd bent.',
          Step3Part1: 'Nadat je je filters hebt geselecteerd, druk je op "Filters toepassen" om de inhoud van de pagina te filteren.',
          Step3Part2: 'Druk op "Reset" als u alle toegepaste filters wilt verwijderen.',
          Step4: 'Doorzoek alle rapporten en visualisaties op trefwoorden.',
          Step5:
            'Vind een selectie van rapporten en visualisaties op basis van, de door u, geselecteerde filters.',
          // Step6: 'Vind een selectie van visualisatie op basis van, de door u, geselecteerde filters.',
          Step7:
            'Interesse voor een bepaald rapport of visualisatie Klik erop en ontdek ze!',
        },
      };
    }
    if (this.selectedLanguage === 'fr') {
      this.messageObject = {
        LibraryTutorialText: {
          Step1Part1:
            'Cette page rassemble les informations auxquelles vous pouvez accéder au travers de la plateforme.',
          Step1Part2: 'Deux types d\'informations sont disponibles&nbsp;: ',
          // tslint:disable-next-line: max-line-length
          Step1Part3:
            // tslint:disable-next-line: max-line-length
            'Les rapports : Ceux-ci vous permettront de comprendre un sujet général au travers des visualisations, graphiques, images, vidéos... qui s\'y trouvent.',
          Step1Part4:
            'Les visualisations : Celles-ci vous permettront de comprendre un sujet plus spécifique.',
          Step2:
            'Cliquez et activez les filtres afin de trouver l\'information qui vous intéresse.',
          Step3Part1: 'Après avoir sélectionné vos filtres, appuyer sur "Appliquer les filtres" pour filtrer le contenu de la page.',
          Step3Part2: 'Appuyez sur "Réinitialiser" si vous souhaitez retirer les filtres appliqués.',
          Step4: 'Recherchez par mots-clés sur l\'ensemble des rapports et visualisations.',
          Step5:
            'Trouvez une proposition de rapports et visualisations basée sur vos sélections.',
          // Step6: 'Trouvez une proposition de visualisation basée sur vos sélections.',
          Step7: 'Un rapport ou une visualisation vous intéresse, Cliquez et explorez.',
        },
      };
    }
  }
  setCookieForLibraryTutorial() {
    if (!Cookie.get('library_page_visited')) {
      this.startTour();
      Cookie.set(
        'library_page_visited',
        'yes',
        new Date(new Date().setFullYear(new Date().getFullYear() + 10)),
        '/',
        Cookie.get('_host')
      );
    }
  }
}
