import {Pipe, PipeTransform} from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';

@Pipe({
  name: 'vizInfoFormatter'
})
export class VizInfoFormatterPipe implements PipeTransform {

  constructor(private domSanitizer: DomSanitizer) {
  }

  transform(value: any, ...args: any[]): any {
    // console.log(value);

    let text = value;
    text = text.replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;');
    text = text.replace(/[ ]{2,}/g, (match) => {
      let result = '';
      for (let i = 0, len = match.length; i < len; i++) {
        result += '&nbsp;';
      }
      return result;
    });
    text = text.replace(/\n/g, '<br/> ');
    text = text.replace(/[-\u2014]/g, '&#8209;');
    return this.domSanitizer.bypassSecurityTrustHtml(text);
  }
}
