import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeftMenuVizCreationComponent } from './left-menu-viz-creation.component';

describe('LeftMenuVizCreationComponent', () => {
  let component: LeftMenuVizCreationComponent;
  let fixture: ComponentFixture<LeftMenuVizCreationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LeftMenuVizCreationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeftMenuVizCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
