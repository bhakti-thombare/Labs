import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import * as _ from 'lodash';
import { TranslateService } from '@ngx-translate/core';
import { ActivatedRoute } from '@angular/router';
import { UtilityService } from 'src/app/core/services/utility.service';

@Component({
  selector: 'ab-left-menu-viz-creation',
  templateUrl: './left-menu-viz-creation.component.html',
  styleUrls: ['./left-menu-viz-creation.component.scss'],
})
export class LeftMenuVizCreationComponent implements OnInit {
  constructor(
    private translate: TranslateService,
    private activeRoute: ActivatedRoute,
    private utilityService: UtilityService
  ) {
    this.vizId = this.activeRoute.snapshot.params.id;
  }
  vizId;
  public steps;
  public activeOne = false;
  public activeTwo = 'black';
  public stepOne;
  public stepTwo;
  public stepThree;
  public stepFour;
  public activeStepTwo;
  public activeThree = 'black';
  public activeFour = 'black';
  public getColors;
  activeColor2;
  activeColor3;
  activeColor4;
  activeColor1;
  active2;
  selectedLanguage: string;
  leftPanelStepThree;
  leftPanelStepFour;
  categoryList = [];
  flag = true;
  @Output() goBackEvent = new EventEmitter();
  @Input('leftPannel2')
  set Info2(leftPannel2: any) {
    this.leftPanelStepFour = leftPannel2.stepFour;
  }
  @Input('leftPannel')
  set Info(leftPannel: any) {

    this.leftPanelStepThree = leftPannel.stepThree;

    this.categoryList = leftPannel.categoryFlag;

  }
  @Input('steps')
  set data(steps: any) {
    this.steps = steps;
    if (this.vizId === undefined) {
      this.stepOne = this.steps.stepOne;
      this.stepTwo = this.steps.stepTwo;
      this.stepThree = this.steps.stepThree;
      this.stepFour = this.steps.stepFour;
    }

    this.active2 = this.steps.activeTwo;
    this.activeColor1 = this.steps.activeColor1;
    this.activeColor2 = this.steps.activeColor2;
    this.activeColor3 = this.steps.activeColor3;
    this.activeColor4 = this.steps.activeColor4;
  }

  // goStep1() {
  //   this.activeOne = false;
  //   this.activeStepTwo = true;
  //   this.goBackEvent.emit({
  //     stepOne: false,
  //     stepTwo: false,
  //     stepThree: false,
  //     stepFour: false
  //   });
  // }

  goStep2() {
    if (this.stepOne === true) {
      this.goBackEvent.emit({
        stepOne: true,
        stepTwo: true,
        stepThree: false,
        stepFour: false,
        step2: true,
      });
    }
    if (true) {
      this.activeColor1 = 'grey';
      this.activeColor2 = '#1A77EE';
      this.activeColor3 = 'grey';
      if (this.activeColor4 === '#1A77EE') {
        this.activeColor4 = 'grey';
      }
    }
  }
  goStep3() {
    if (!this.leftPanelStepThree) {
      this.utilityService.showTranslatedNotificationMessage(
        'NotificationMessages.General.ThreeLangMandatory',
        'ERROR'
      );
    }
    if (this.stepTwo && this.leftPanelStepThree) {

      this.categoryList = this.categoryList.map( (v) => {
        return v.toLowerCase();
      });
      // tslint:disable-next-line: no-shadowed-variable
      const value = this.categoryList.map((value) =>
        value.toLowerCase().startsWith('vi')
      );

      if (value.includes(true)) {
        this.goBackEvent.emit({
          stepOne: true,
          stepTwo: false,
          stepThree: true,
          stepFour: false,
          step3: true,
        });

        if ( this.leftPanelStepThree) {
          this.activeColor1 = 'grey';
          this.activeColor2 = 'grey';
          this.activeColor3 = '#1A77EE';
          if (this.activeColor4 === '#1A77EE') {
            this.activeColor4 = 'grey';
          }
        }
      } else {
        this.utilityService.showTranslatedNotificationMessage(
          'NotificationMessages.Viz.tagCategory',
          'ERROR'
        );
      }
    }
  }
  goStep4() {
    if (!this.leftPanelStepFour) {
      this.utilityService.showTranslatedNotificationMessage(
        'NotificationMessages.General.ThreeLangMandatory',
        'ERROR'
      );
    }
    if (this.stepTwo === true && this.stepThree === true) {

      if (this.leftPanelStepFour) {
        this.goBackEvent.emit({
          stepOne: true,
          stepTwo: false,
          stepThree: true,
          stepFour: true,
          step4: true,
          step3: false,
        });

        if (true) {
          this.activeColor1 = 'grey';
          this.activeColor2 = 'grey';
          this.activeColor3 = 'grey';
          this.activeColor4 = '#1A77EE';
        }
      }
    }
  }
  ngOnInit() {
    if (this.vizId !== undefined) {
      this.stepOne = true;
      this.stepTwo = true;
      this.stepThree = true;
      this.stepFour = true;
    }
  }
}
