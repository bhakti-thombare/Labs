import { Component, OnInit, Output, EventEmitter, Input, OnChanges, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';

@Component({
  selector: 'ab-left-menu-product-creation',
  templateUrl: './left-menu-product-creation.component.html',
  styleUrls: ['./left-menu-product-creation.component.scss'],
})
export class LeftMenuProductCreationComponent implements OnInit, OnChanges {
  on3rdStep = true;
  constructor(
    private cdRef: ChangeDetectorRef,
    private translate: TranslateService,
    private router: Router) { }
  @Input() product: any;
  public steps;
  public activeOne = false;
  public activeTwo = 'black';
  public stepOne;
  public stepTwo;
  public stepThree;
  public stepFour;
  public stepFive;
  public stepSix;
  public activeStepTwo;
  public activeThree = 'black';
  public activeFour = 'black';
  public getColors;
  activeColor2;
  activeColor3;
  activeColor4;
  activeColor1;
  activeColor5;
  activeColor6;
  activeColor7;
  active2;
  selectedLanguage: string;
  checkPreviousUrl = 'no-value';
  @Input() revertStepColor: any;

  @Output() goBackEvent = new EventEmitter();

  @Input('steps')
  set data(steps: any) {
    this.steps = steps;
    // console.log('this.steps', this.steps)
    if (!this.checkPreviousUrl.includes('product-edit')) {
      this.stepOne = this.steps.stepOne;
      this.stepTwo = this.steps.stepTwo;
      this.stepThree = this.steps.stepThree;
      this.stepFour = this.steps.stepFour;
      this.stepFive = this.steps.stepFive;
      this.stepSix = this.steps.stepSix;
    }

    this.active2 = this.steps.activeTwo;
    this.activeColor1 = this.steps.activeColor1;
    this.activeColor2 = this.steps.activeColor2;
    this.activeColor3 = this.steps.activeColor3;
    this.activeColor4 = this.steps.activeColor4;
    this.activeColor5 = this.steps.activeColor5;
    this.activeColor6 = this.steps.activeColor6;
    this.activeColor7 = this.steps.activeColor7;
    this.cdRef.detectChanges();
  }

  // goStep1() {
  //   this.activeOne = false;
  //   this.activeStepTwo = true;
  //   this.goBackEvent.emit({
  //     stepOne: false,
  //     stepTwo: false,
  //     stepThree: false,
  //     stepFour: false
  //   });
  // }
  // goStep2() {
  //   if (this.stepOne === true) {
  //     this.goBackEvent.emit({
  //       stepOne: true,
  //       stepTwo: true,
  //       stepThree: false,
  //       stepFour: false
  //     });

  //   }

  // }
  goStep3() {
    if (this.stepTwo === true) {
      this.goBackEvent.emit({
        stepOne: true,
        stepTwo: false,
        stepThree: true,
        stepFour: false,
        step3: true,
        step6: false,
      });
    }
    // if (this.checkPreviousUrl.includes('product-edit')) {
    //   this.activeColor1 = 'grey';
    //   this.activeColor2 = 'grey';
    //   this.activeColor3 = '#1A77EE';
    //   this.activeColor4 = 'grey';
    //   this.activeColor5 = 'grey';
    //   this.activeColor6 = 'grey';
    //   this.activeColor7 = 'grey';
    // }
  }
  goStep4() {
    //
    if (this.stepTwo && this.stepThree) {
      this.goBackEvent.emit({
        stepOne: true,
        stepTwo: false,
        stepThree: true,
        stepFour: true,
        step4: true,
        step3: false,
        step5: false,
        step6: false,
        fromStep: '4'
      });
    }
    // if (this.checkPreviousUrl.includes('product-edit')) {
    //   this.activeColor1 = 'grey';
    //   this.activeColor2 = 'grey';
    //   this.activeColor3 = 'grey';
    //   this.activeColor4 = '#1A77EE';
    //   this.activeColor5 = 'grey';
    //   this.activeColor6 = 'grey';
    //   this.activeColor7 = 'grey';
    // }
  }
  goStep5() {
    //
    if (this.stepTwo && this.stepThree && this.stepFour) {
      this.goBackEvent.emit({
        stepOne: true,
        stepTwo: false,
        stepThree: true,
        stepFour: true,
        step4: false,
        step3: false,
        step5: true,
        step6: false,
      });
    }
    // if (this.checkPreviousUrl.includes('product-edit')) {
    //   this.activeColor1 = 'grey';
    //   this.activeColor2 = 'grey';
    //   this.activeColor3 = 'grey';
    //   this.activeColor4 = 'grey';
    //   this.activeColor5 = '#1A77EE';
    //   this.activeColor6 = 'grey';
    //   this.activeColor7 = 'grey';
    // }
  }
  goStep6() {
    //
    if (this.stepTwo && this.stepThree && this.stepFour && this.stepFive) {
      this.goBackEvent.emit({
        stepOne: true,
        stepTwo: false,
        stepThree: true,
        stepFour: true,
        step4: false,
        step3: false,
        step5: false,
        step6: true,
      });
    }
    // if (this.checkPreviousUrl.includes('product-edit')) {
    //   this.activeColor1 = 'grey';
    //   this.activeColor2 = 'grey';
    //   this.activeColor3 = 'grey';
    //   this.activeColor4 = 'grey';
    //   this.activeColor5 = 'grey';
    //   this.activeColor6 = '#1A77EE';
    //   this.activeColor7 = 'grey';
    // }
  }
  ngOnInit() {
    this.checkPreviousUrl = this.router.url;
    if (this.checkPreviousUrl.includes('product-edit')) {
      this.stepOne = true;
      this.stepTwo = true;
      this.stepThree = true;
      this.stepFour = true;
      this.stepFive = true;
      this.stepSix = true;
    }

    // this.checkPreviousUrl = this.activeRoute.snapshot.paramMap.get('previousUrl')
  }

  ngOnChanges() {
    if (this.product) {
      // this.stepOne = true;
      // this.stepTwo = true;
      // this.stepThree = true;
      // this.stepFour = false;
      // this.stepFive = true;
      // this.stepSix = true;
      const productData = this.product; // JSON.parse(JSON.stringify(this.product));
      // console.log('productData', productData);
      if (productData) {
        if (this.checkPreviousUrl.includes('product-edit')) {
          if (productData.saveAsDraft) {
            if (productData.productDetailsList.length) {
              const index = productData.productDetailsList.findIndex(item => item.productCategoryList.length);
              if (this.on3rdStep) {
                if (index === -1) {
                  this.on3rdStep = false;
                }
              }
              if (!this.on3rdStep) {
                // console.log('changing step values');
                // this.stepOne = this.steps.stepOne;
                // this.stepTwo = this.steps.stepTwo;
                this.stepThree = this.steps.stepThree;
                this.stepFour = this.steps.stepFour;
                this.stepFive = this.steps.stepFive;
                this.stepSix = this.steps.stepSix;
              }
              // if (index !== -1) {
              //   const categories = productData.productDetailsList[index].productCategoryList;
              //   if (categories.length) {
              //     this.stepOne = this.steps.stepOne;
              //     this.stepTwo = this.steps.stepTwo;
              //     this.stepThree = this.steps.stepThree;
              //     console.log('this.stepThree', this.stepThree)
              //     this.stepFour = this.steps.stepFour;
              //     console.log('this.stepFour', this.stepFour)
              //     this.stepFive = this.steps.stepFive;
              //     console.log('this.stepFive', this.stepFive)
              //     this.stepSix = this.steps.stepSix;
              //     console.log('this.stepSix', this.stepSix)
              //     // this.stepFive = true;
              //     // this.stepFour = true;
              //   } else {
              //     // this.stepThree = false;
              //     // this.stepFive = false;
              //     // this.stepFour = false;
              //     // this.stepSix = false;
              //   }
              // } else {
              //   this.stepThree = false;
              //   this.stepFive = false;
              //   this.stepFour = false;
              //   this.stepSix = false;
              // }
            }

          }
        }
      }
    }
    this.cdRef.detectChanges()
  }

  changeStepColor(step) {
    this.cdRef.detectChanges();

    if (step) {
      // console.log('present on step', step)
      if (step === 3) {
        // console.log('present on step', step)
        this.activeColor1 = 'grey';
        this.activeColor2 = 'grey';
        this.activeColor4 = 'grey';
        this.activeColor3 = '#1A77EE';
        this.activeColor5 = 'grey';
        this.activeColor6 = 'grey';
        this.activeColor7 = 'grey';

      }
      if (step === 4) {
        // console.log('present on step', step)
        this.activeColor1 = 'grey';
        this.activeColor2 = 'grey';
        this.activeColor3 = 'grey';
        this.activeColor4 = '#1A77EE';
        this.activeColor5 = 'grey';
        this.activeColor6 = 'grey';
        this.activeColor7 = 'grey';

      }
      if (step === 5) {
        // console.log('present on step', step)
        this.activeColor1 = 'grey';
        this.activeColor2 = 'grey';
        this.activeColor3 = 'grey';
        this.activeColor5 = '#1A77EE';
        this.activeColor4 = 'grey';
        this.activeColor6 = 'grey';
        this.activeColor7 = 'grey';

      }
      if (step === 6) {
        // console.log('present on step', step)
        this.activeColor1 = 'grey';
        this.activeColor2 = 'grey';
        this.activeColor3 = 'grey';
        this.activeColor6 = '#1A77EE';
        this.activeColor5 = 'grey';
        this.activeColor4 = 'grey';
        this.activeColor7 = 'grey';
      }
    } else {

    }
    this.cdRef.detectChanges();

  }
}
