import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeftMenuProductCreationComponent } from './left-menu-product-creation.component';

describe('LeftMenuProductCreationComponent', () => {
  let component: LeftMenuProductCreationComponent;
  let fixture: ComponentFixture<LeftMenuProductCreationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LeftMenuProductCreationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeftMenuProductCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
