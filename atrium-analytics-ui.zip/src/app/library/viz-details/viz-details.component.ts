import {
  Component,
  OnInit,
  ViewChild,
  AfterViewInit,
  TemplateRef,
  OnDestroy,
} from '@angular/core';
import { ActivatedRoute, Router, Event, NavigationStart } from '@angular/router';
import { GeneralService } from '../shared/general-service.service';
import { TableauService } from 'src/app/core/services/tableau.service';

import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { Subscription } from 'rxjs';
import { SharedDataServiceService } from 'src/app/core/services/shared-data-service.service';


declare var tableau: any;

@Component({
  selector: 'ab-viz-details',
  templateUrl: './viz-details.component.html',
  styleUrls: ['./viz-details.component.scss'],
})
export class VizDetailsComponent implements OnInit, AfterViewInit, OnDestroy {
  productId: any;
  queryParamLanguage: any;
  constructor(
    private activeRoute: ActivatedRoute,
    private router: Router,
    private generalService: GeneralService,
    private tableauService: TableauService,
    private utilityService: UtilityService,
    private translate: TranslateService,
    private authService: AuthService,
    private modalService2: BsModalService,
    private notificationService: NotificationService,
    private sharedData: SharedDataServiceService
  ) {
    router.events.subscribe((event: Event) => {
      if (event instanceof NavigationStart) {
        if (this.viz) {
          this.viz.dispose();
        }
      }
    });
  }
  modalRef: any;
  deleteVizMsg;
  activeTab = 0;
  modalRef2;
  currentUser = 'visitor';
  languageCode = 0;
  userId = 0;
  heartColor = false;
  selectedLanguage;
  vizName;
  vizInfo;
  backtoLibrary;
  infoFlag;
  mapFlag;
  embedCode;
  linkCopied;
  getVizFlag = false;
  getVizDetailArray;
  closeFlag = false;
  languageChanged = false;
  checkPreviousUrl;
  dashboardUrl = false;
  homepage = false;



  viz: any;
  @ViewChild('genericConfirm', { static: true })
  genericConfirm: GenericConfirmComponent;
  vizId: any;
  // tslint:disable-next-line: member-ordering
  body = {
    userId: this.userId,
    roleCode: this.currentUser === 'visitor' ? 0 : this.currentUser,
    languageCode: this.languageCode,
  };
  confirmMessage;
  link;
  addfavouriteBody;

  languageChangeSubscription: Subscription;

  addToFavourites(template) {
    this.addfavouriteBody = {
      userId: this.userId,
      roleCode: this.currentUser,
      languageCode: 'en',
      vizId: this.vizId,
      favorite: false

    };
    if (this.userId === 0) {
      this.modalRef = this.modalService2.show(template, {
        animated: true,
        // backdrop: 'static',
        keyboard: true,
        class: 'addFavModal',
      });
    } else {
      if (!this.heartColor) {
        this.addfavouriteBody.favorite = true;
        this.heartColor = true;

        this.generalService
          .addFavourite(this.addfavouriteBody, { loader: true })
          .subscribe((res) => { });
      } else {
        this.addfavouriteBody.favorite = false;
        this.heartColor = false;

        this.generalService
          .addFavourite(this.addfavouriteBody, { loader: true })
          .subscribe((res) => { });
      }
    }
  }
  openModal(template) {
    this.modalRef2 = this.modalService2.show(template, {
      animated: true,
      backdrop: 'static',
      keyboard: false,
      class: 'custom-width',
    });
  }
  closeModal() {
    this.closeFlag = true;
    this.loadUser();

    this.modalRef2.hide();
    this.modalRef.hide();
  }


  switchToInfo() {
    this.infoFlag = true;
    this.mapFlag = true;
  }
  switchMap() {
    this.infoFlag = false;
    this.mapFlag = false;
    this.getVizDetails();
  }
  goVizCreation() {
    this.router.navigate(['/library/viz-creation', this.vizId]);
  }
  backToLibrary(value) {
    // window.history.back();
    if (value === 'library') {
      this.router.navigate(['/library', { previousUrl: 'viz-details' }]);

    } else {
      this.sharedData.sharedUrl = 'viz-page';
      window.history.back();
    }
  }
  deleteViz() {
    this.genericConfirm.show({
      headlineText: this.deleteVizMsg,
      notConfirmText: 'NOTEXT',
      confirmText: 'YESTEXT',
      text: this.confirmMessage,
      callback: (result) => {
        // this.deleteAdjustment(adjustment);
        if (result) {
          this.generalService
            .deleteViz(this.body, this.vizId)
            .subscribe((res) => {
              if (res.message === 'Request successful') {
                if (this.dashboardUrl || this.homepage) {
                  window.history.back();
                } else {
                  window.location.href = '/#!/library/dashboard';
                }
                // this.notificationService.showSuccess('Viz deleted successfully');
                this.utilityService.showTranslatedNotificationMessage(
                  'NotificationMessages.Viz.VizDeleted',
                  'SUCCESS'
                );
              }
            });
        }
      },
    });
  }

  invitePeople(template) {
    this.modalRef = this.modalService2.show(template, {
      animated: true,
      // backdrop: 'static',
      keyboard: true,
      class: 'customModal',
    });
  }
  getVizDetails() {
    this.generalService
      .getViz(this.body, { loader: true }, this.vizId)
      .subscribe((res) => {
        this.getVizFlag = true;
        this.getVizDetailArray = res.value;
        this.heartColor = this.getVizDetailArray.favorite;

        this.setData(this.selectedLanguage);
      });
  }
  initViz() {
    if (this.viz) {
      this.viz.dispose();
    }
    const url = this.tableauService.getVizUrlFromEmbedCode(this.embedCode);

    const placeholderDiv = document.getElementById('vizContainer');

    // Replace this url with the url of your Tableau dashboard

    const options = {
      hideTabs: true,
      onFirstInteractive() {
      },
    };

    this.viz = new tableau.Viz(placeholderDiv, url, options);

  }
  shareLink() {
    this.link = window.location.href;

    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = this.link;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    //  this.notificationService.showInfo(this.linkCopied);
    this.utilityService.showTranslatedNotificationMessage(
      'NotificationMessages.Viz.LinkCopied',
      'INFORMATION'
    );
  }
  setData(lang) {
    switch (lang) {
      case 'en':
        this.vizName = this.getVizDetailArray.vizInformation[0].name;
        this.vizInfo = this.getVizDetailArray.vizInformation[0].information;
        this.embedCode = this.getVizDetailArray.vizInformation[0].embedCode;

        this.initViz();

        break;
      case 'fr':
        this.vizName = this.getVizDetailArray.vizInformation[1].name;
        this.vizInfo = this.getVizDetailArray.vizInformation[1].information;
        this.embedCode = this.getVizDetailArray.vizInformation[1].embedCode;
        this.initViz();

        break;
      case 'nl':
        this.vizName = this.getVizDetailArray.vizInformation[2].name;
        this.vizInfo = this.getVizDetailArray.vizInformation[2].information;
        this.embedCode = this.getVizDetailArray.vizInformation[2].embedCode;
        this.initViz();
        break;
    }
  }
  setMessage(lang) {
    switch (lang) {
      case 'en':
        this.confirmMessage = 'Are you sure you want to delete this viz ?';
        this.deleteVizMsg = 'Delete Viz';
        this.linkCopied = 'Link copied to clipboard';

        break;
      case 'fr':
        this.confirmMessage =
          'Êtes-vous sûr de vouloir supprimer ce  visualisations ?';
        this.deleteVizMsg = 'Supprimer viz';
        this.linkCopied = 'Lien copié dans le presse-papiers';


        break;
      case 'nl':
        this.confirmMessage =
          'Weet u zeker dat u dit visualisaties wilt verwijderen?';
        this.deleteVizMsg = 'Viz verwijderen';
        this.linkCopied = 'Link gekopieerd naar klembord';

        break;
    }
  }
  loadUser() {
    this.authService.currentUser$.subscribe((user) => {
      this.currentUser = user.role;
      this.languageCode = user.languageCode;
      this.userId = user.id;
      if (this.closeFlag) {
        this.getVizDetails();

      }
    });
  }
  ngOnInit() {
    // tslint:disable-next-line: no-string-literal
    this.queryParamLanguage = this.activeRoute.snapshot.queryParams['language'];
    // tslint:disable-next-line: no-string-literal
    this.productId = this.activeRoute.snapshot.queryParams['productId'];
    if (this.queryParamLanguage) {
      this.translate.use(this.queryParamLanguage.toLowerCase());
    }
    this.loadUser();
    this.checkPreviousUrl = this.activeRoute.snapshot.paramMap.get('previousUrl')
      ? this.activeRoute.snapshot.paramMap.get('previousUrl')
      : 'no-value';
    if (this.checkPreviousUrl.includes('content')) {
      this.dashboardUrl = true;
    }
    if (this.checkPreviousUrl.includes('homepage')) {
      this.homepage = true;
    }
    this.selectedLanguage = localStorage.getItem('language');
    this.setMessage(this.selectedLanguage);
    this.vizId = this.activeRoute.snapshot.params.id;
    this.getVizDetails();

    this.languageChangeSubscription = this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.selectedLanguage = event.lang;
      this.languageChanged = true;
      this.setMessage(this.selectedLanguage);
      this.setData(this.selectedLanguage);
    });
  }

  onCloseModal(flag: string, template) {
    if (flag) {
      this.modalRef.hide();
    }
  }
  ngAfterViewInit() { }

  ngOnDestroy() {
    if (this.viz) {
      this.viz.dispose();
    }

    if (this.languageChangeSubscription) {
      this.languageChangeSubscription.unsubscribe();
    }
  }

  backToProduct() {
    this.router.navigateByUrl('/library/product-details/' + this.productId);
  }
}
