import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VizDetailsComponent } from './viz-details.component';

describe('VizDetailsComponent', () => {
  let component: VizDetailsComponent;
  let fixture: ComponentFixture<VizDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VizDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VizDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
