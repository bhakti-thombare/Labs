import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from 'src/app/core/services/auth.service';
declare var JSEncrypt: any;

@Component({
  selector: 'ab-forgot-password-form',
  templateUrl: './forgot-password-form.component.html',
  styleUrls: ['./forgot-password-form.component.scss']
})
export class ForgotPasswordFormComponent implements OnInit {
  @Output() openSignIn: EventEmitter<any> = new EventEmitter<any>();

  @Output() closeEvent: EventEmitter<any> = new EventEmitter<any>();
  @Output() nextStep: EventEmitter<any> = new EventEmitter<any>();
  forgotPasswordForm: FormGroup;
  isEmailSelected = false;
  encrypt: any;
  // tslint:disable-next-line: max-line-length
  emailPattern = new RegExp(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
  constructor(private formBuilder: FormBuilder, private authService: AuthService) { }

  ngOnInit() {
    this.buildForm();
  }

  buildForm() {
    this.forgotPasswordForm = this.formBuilder.group({
      emailAddress: ['', [Validators.required, Validators.pattern(this.emailPattern)]]
    });
  }

  closeModal() {
    this.closeEvent.emit(true);
  }

  onSubmit() {
    if (this.forgotPasswordForm.valid) {
      const data = this.forgotPasswordForm.value;
      // console.log('data', data);
      data.email = this.forgotPasswordForm.value.emailAddress;
      this.encrypt = new JSEncrypt();
      this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
      data.userName = this.encrypt.encrypt(data.email);
      this.authService.forgotPassword(data.userName).subscribe((res: any) => {
        if (res.message === 'Request successful') { this.nextStep.emit({ emailAddress: data.email }); }
      });
    }
  }

  get emailAddress() {
    return this.forgotPasswordForm.get('emailAddress');
  }


}
