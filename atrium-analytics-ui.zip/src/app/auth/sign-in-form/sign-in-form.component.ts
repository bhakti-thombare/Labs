import { Component, OnInit, Output, EventEmitter, Input, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NotificationService } from 'src/app/core/services/notification.service';
// import { JSEncrypt } from 'jsencrypt';
import { RestService } from 'src/app/core/services/rest.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
declare var JSEncrypt: any;

@Component({
  selector: 'ab-sign-in-form',
  templateUrl: './sign-in-form.component.html',
  styleUrls: ['./sign-in-form.component.scss']
})
export class SignInFormComponent implements OnInit, OnChanges {
  @Output() closeEvent: EventEmitter<any> = new EventEmitter<any>();
  @Input() activeTab: any;
  isPasswordSelected = false;

  isEmailSelected = false;
  activeState = 0;
  signInForm: FormGroup;
  encrypt: any;
  publicKey: any;
  privateKey: any;
  key: any;
  emailAddressInput: any;
  // tslint:disable-next-line: max-line-length
  emailPattern = new RegExp(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
  constructor(private formBuilder: FormBuilder,
              private restService: RestService,
              private router: Router,
              private authService: AuthService,
              private notificationService: NotificationService) {
  }

  ngOnInit() {
    this.buildForm();
  }

  ngOnChanges() {
    if (this.activeTab) {
      this.activeState = this.activeTab;
    }
  }
  buildForm() {
    this.signInForm = this.formBuilder.group({
      emailAddress: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      password: ['', Validators.required]
    });
  }

  closeModal() {
    this.closeEvent.emit(false);
  }

  onSubmit() {
    if (this.signInForm.valid) {
      // console.log(this.signInForm.value);
      const data = this.signInForm.value;
      data.email = this.signInForm.value.emailAddress;
      this.encrypt = new JSEncrypt();
      this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
      data.userName = this.encrypt.encrypt(data.email);
      data.password = this.encrypt.encrypt(data.password);
      this.authService.login(this.router.url, data.email, data.userName, data.password);
      this.signInForm.reset();
      this.closeEvent.emit(true);
    }
  }

  get emailAddress() {
    return this.signInForm.get('emailAddress');
  }

  get password() {
    return this.signInForm.get('password');
  }

  // manual logout for test
  logoutss() {
    this.encrypt = new JSEncrypt();
    const url = environment.apiUrl + '/v2/api/user/logout';
    this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
    const userNames = this.encrypt.encrypt('');
    this.restService.post(url, { userName: userNames }).subscribe(res => {
      // console.log('res', res);
    });
  }

  nextStep(event: any) {
    // console.log('event', event)
    this.emailAddressInput = event.emailAddress;
    this.activeState = 3;
  }



}
