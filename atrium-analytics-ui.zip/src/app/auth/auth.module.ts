import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SignInFormComponent } from './sign-in-form/sign-in-form.component';
import { SignUpFormComponent } from './sign-up-form/sign-up-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { TranslateModule } from '@ngx-translate/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ForgotPasswordFormComponent } from './forgot-password-form/forgot-password-form.component';
import { ConfirmForgotPasswordFormComponent } from './confirm-forgot-password-form/confirm-forgot-password-form.component';



@NgModule({
  declarations: [SignInFormComponent, SignUpFormComponent, ForgotPasswordFormComponent, ConfirmForgotPasswordFormComponent],
  imports: [
    TranslateModule,
    FormsModule,
    BsDropdownModule.forRoot(),
    NgSelectModule,
    ReactiveFormsModule,
    CommonModule,
  ],
  exports: [SignInFormComponent, SignUpFormComponent]
})
export class AuthModule { }
