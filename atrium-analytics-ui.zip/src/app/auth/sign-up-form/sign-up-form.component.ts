import { Component, OnInit, Output, EventEmitter, TemplateRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from 'src/app/core/services/auth.service';
declare var JSEncrypt: any;
// import Swal from 'sweetalert2';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { UtilityService } from 'src/app/core/services/utility.service';
import { FooterComponent } from 'src/app/shared/components/footer/footer.component';
import { SharedDataServiceService } from 'src/app/core/services/shared-data-service.service';

@Component({
  selector: 'ab-sign-up-form',
  templateUrl: './sign-up-form.component.html',
  styleUrls: ['./sign-up-form.component.scss'],
  // tslint:disable-next-line: no-host-metadata-property
  // host: {
  //   '(document:click)': 'onClick($event)',
  // }
})
export class SignUpFormComponent implements OnInit {
  @ViewChild('confirmSignUp', { static: false }) confirmSignUptemplate: any;
  // @ViewChild(FooterComponent, { static: false }) footerComponent: FooterComponent;
  signUpForm: FormGroup;
  param: any = {};
  selectedLanguage = '';
  passwordStrength = '';
  selectedEmployment = '';
  isConfirmPasswordSelected = false;
  isPasswordSelected = false;
  isEmploymentSelected = false;
  isFirstNameSelected = false;
  isLastNameSelected = false;
  isLanguageSelected = false;
  isEmailSelected = false;
  isCompanySelected = false;

  jobTitles = [
    { title: 'Employee', code: 'Employee' },
    { title: 'Looking for a job', code: 'LookingJob' },
    { title: 'Entrepreneur', code: 'Entrepreneur' },
    { title: 'Student', code: 'Student' },
    { title: 'Young Graduate', code: 'YoungGraduate' },
    { title: 'Manager', code: 'Manager' },
    { title: 'Member of a merchant association', code: 'MerchantAssociation' },
    { title: 'Member of a residents\' association', code: 'ResidentOrAssociation' },
    { title: 'Partner', code: 'Partner' },
    { title: 'CEO', code: 'CEO' },
    { title: 'Trainee', code: 'Trainee' },
    { title: 'Other', code: 'Other' },
    // { title: 'Programmer', code: 'Programmer' },
    // { title: 'Solutions Architect', code: 'SA' },
    // { title: 'Database Developer', code: 'DBA' },
    // { title: 'Accountant', code: 'Accountant' },
    // { title: 'Payroll Officer', code: 'PayrollOfficer' },
    // { title: 'Accounts Clerk', code: 'AccountClerk' },
    // { title: 'Analyst', code: 'Analyst' },
    // { title: 'Financial Controller', code: 'FinancialController' },
    // { title: 'Recruitment Consultant', code: 'RecruitmentConsultant' },
    // { title: 'Change Management', code: 'ChangeManagement' },
    // { title: 'Industrial Relations', code: 'IndustrialRelations' },
    // { title: 'Market Researcher', code: 'MarketResearcher' },
    // { title: 'Marketing Manager', code: 'MarketingManager' },
    // { title: 'Marketing Co-ordinator', code: 'MarketingCoordinator' }

  ];

  employmentList =
    ['Employee',
      'Looking for a job',
      'Entrepreneur',
      'Student',
      'Young graduate',
      'Manager',
      'Member of a merchant association',
      'Member of a residents\' association',
      'Partner',
      'CEO',
      'Trainee',
      'Other'];
  @Output() openSignIn: EventEmitter<any> = new EventEmitter<any>();

  @Output() closeEvent: EventEmitter<any> = new EventEmitter<any>();

  languageTouched = false;
  employmentTouched = false;
  encrypt: any;
  mainHead: string;
  subHead: string;
  modalRef: any;
  // tslint:disable-next-line: max-line-length
  emailPattern = new RegExp(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
  constructor(
    private dataSharingService: SharedDataServiceService,
    private formBuilder: FormBuilder,
    private utilityService: UtilityService,
    private authService: AuthService,
    private router: Router,
    private modalService: BsModalService,
    private translate: TranslateService) { }

  ngOnInit() {
    this.initialiseVariables();
    this.builForm();
    const setLang = localStorage.getItem('language');

    if (setLang === 'fr') {
      this.employmentList = [
        'Employé.e',
        'En recherche d\'emploi',
        'Entrepreneur.e',
        'Etudiant.e',
        'Jeune diplômé.e',
        'Manager',
        'Membre d\'une association de commerçants',
        'Membre d\'une association de riverains',
        'Partenaire',
        'PDG',
        'Stagiaire',
        'Autre'];
    }
    if (setLang && setLang === 'nl') {
      this.employmentList = ['Werknemer',
        'Werkzoekende',
        'Ondernemer',
        'Student',
        'Afgesturdeerde',
        'Manager',
        'Lid van een handelsvereniging',
        'Lid van een bewonersvereniging',
        'Partener',
        'CEO',
        'Stagiair',
        'Andere'];
    }
  }

  builForm() {
    this.signUpForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      emailAddress: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      language: [this.selectedLanguage],
      employment: [this.selectedEmployment],
      companyName: [''],
    }, {
      validator: this.MustMatch('password', 'confirmPassword')
    });

    this.signUpForm.get('password').valueChanges.subscribe(value => {
      if (value) {
        this.param.strength = this.getPasswordStrength(value);
      }
    });
  }

  get firstName() {
    return this.signUpForm.get('firstName');
  }
  get lastName() {
    return this.signUpForm.get('lastName');
  }
  get emailAddress() {
    return this.signUpForm.get('emailAddress');
  }
  get password() {
    return this.signUpForm.get('password');
  }
  get confirmPassword() {
    return this.signUpForm.get('confirmPassword');
  }
  get language() {
    return this.signUpForm.get('language');
  }
  get employment() {
    return this.signUpForm.get('employment');
  }
  get companyName() {
    return this.signUpForm.get('companyName');
  }
  getLanguageCode(language: string) {
    switch (language) {
      case 'English':
        return 'en';
      case 'French':
        return 'fr';
      case 'Dutch':
        return 'nl';
    }
  }
  submit() {
    if (this.signUpForm.valid && this.selectedLanguage) {
      this.signUpForm.get('language').setValue(this.selectedLanguage);
      this.signUpForm.get('employment').setValue(this.selectedEmployment);
      // console.log(this.signUpForm.value);
      const signUpData = this.signUpForm.value;
      this.encrypt = new JSEncrypt();
      this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
      setTimeout(() => {
        // this.encrypt.encrypt('asdas');
        signUpData.email = this.encrypt.encrypt(signUpData.emailAddress);
        signUpData.password = this.encrypt.encrypt(signUpData.password);
        // signUpData.password = this.encrypt.encrypt(signUpData.password);
        signUpData.languageCode = this.getLanguageCode(signUpData.language);
        signUpData.roleCode = 'visitor';
        // console.log('signUpData', signUpData);
        delete signUpData.confirmPassword;
        delete signUpData.emailAddress;
        delete signUpData.language;

        if (signUpData.employment === 'LookingJob') {
          signUpData.employment = 'Looking for a job';
        }

        if (signUpData.employment === 'YoungGraduate') {
          signUpData.employment = 'Young Graduate';
        }

        if (signUpData.employment === 'MerchantAssociation') {
          signUpData.employment = 'Member of a merchant association';
        }

        if (signUpData.employment === 'ResidentOrAssociation') {
          signUpData.employment = 'Member of a residents\' association';
        }

        const data = this.utilityService.removeEmptyStringAndTrim({ ...signUpData });

        this.authService.signUp(data).subscribe(res => {
          if (res && res.message === 'Request successful') {
            this.openModal(this.confirmSignUptemplate);
          }
        });
      }, 1000);
    }
  }

  initialiseVariables() {
    this.mainHead = 'Almost there! Please confirm your account.';
    // tslint:disable-next-line: max-line-length
    this.subHead = 'We have just sent you instructions by email to complete your registration. Please check your email and confirm your account.';
  }



  calculatePasswordStrength(password: string) {
    const regex = new Array<RegExp>();
    regex.push(/[A-Z]/); // Uppercase Alphabet.
    regex.push(/[a-z]/); // Lowercase Alphabet.
    regex.push(/[0-9]/); // Digit.
    regex.push(/[\W]/); // Special Character and underscore.

    let passed = 0;

    // Validate for each Regular Expression.
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < regex.length; i++) {
      if (new RegExp(regex[i]).test(password)) {
        passed++;
      }
    }

    if (passed <= 20 && passed >= 8) {
      return passed;
    }

  }

  getPasswordStrength(password: string) {

    // Must have capital letter, numbers and lowercase letters
    const strongRegex = new RegExp('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$', 'g');

    // Must have either capitals and lowercase letters or lowercase and numbers
    const mediumRegex = new RegExp('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$', 'g');
    // ((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|

    // Must be at least 6 characters long
    const okRegex = new RegExp('^(?=.*?[a-z]).{8,}$', 'g');

    if (okRegex.test(password) === false) {
      // If ok regex doesn't match the password
      // console.log('If ok regex doesn\'t match the password111');
      return 'Weak';
    } else if (strongRegex.test(password)) {
      // If reg ex matches strong password
      return 'Strong';
    } else if (mediumRegex.test(password)) {
      // If medium password matches the reg ex
      return 'Medium';
    } else {
      // console.log('If ok regex doesn\'t match the password');
      // If password is ok
      return 'Weak';
    }

  }

  // custom validator to check that two fields match
  MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        // return if another validator has already found an error on the matchingControl
        return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }

  handler(value) {
    if (value === 'language') {
      this.languageTouched = true;
    } else if (value === 'employment') {
      this.employmentTouched = true;
    }
  }


  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {
      animated: true,
      backdrop: 'static',
      keyboard: false,
      ignoreBackdropClick: false,
      class: 'custom-width'
    });
  }

  modalClick() {
    // console.log('modalClick');
    this.modalRef.hide();
    this.closeEvent.emit();
  }

  openTermsAndConditions() {

    // this.footerComponent.openTermsAndConditions();
    window.open(this.dataSharingService.termsAndCondition);
  }

}
