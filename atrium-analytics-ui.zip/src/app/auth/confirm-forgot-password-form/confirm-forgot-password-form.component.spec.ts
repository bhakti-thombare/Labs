import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmForgotPasswordFormComponent } from './confirm-forgot-password-form.component';

describe('ConfirmForgotPasswordFormComponent', () => {
  let component: ConfirmForgotPasswordFormComponent;
  let fixture: ComponentFixture<ConfirmForgotPasswordFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmForgotPasswordFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmForgotPasswordFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
