import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
declare var JSEncrypt: any;
@Component({
  selector: 'ab-confirm-forgot-password-form',
  templateUrl: './confirm-forgot-password-form.component.html',
  styleUrls: ['./confirm-forgot-password-form.component.scss']
})
export class ConfirmForgotPasswordFormComponent implements OnInit {
  @Output() openSignIn: EventEmitter<any> = new EventEmitter<any>();

  @Output() closeEvent: EventEmitter<any> = new EventEmitter<any>();
  @Input() emailAddress: any;
  isVerificationCodeSelected = false;
  isNewPasswordSelected = false;
  confirmForgotPasswordForm: FormGroup;
  encrypt: any;
  constructor(
    private utilityService: UtilityService,
    private notificationService: NotificationService, private formBuilder: FormBuilder, private authService: AuthService) { }

  ngOnInit() {
    this.buildForm();
  }

  buildForm() {
    this.confirmForgotPasswordForm = this.formBuilder.group({
      verificationCode: ['', Validators.required],
      newPassword: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.confirmForgotPasswordForm.valid) {
      const data = this.confirmForgotPasswordForm.value;
      // console.log('this.confirmForgotPasswordForm.value', this.confirmForgotPasswordForm.value);
      // console.log('this.emailAddress', this.emailAddress);

      this.encrypt = new JSEncrypt();
      this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
      data.email = this.encrypt.encrypt(this.emailAddress);
      data.newPassword = this.encrypt.encrypt(data.newPassword);
      data.confirmationCode = data.verificationCode;
      delete data.verificationCode;
      this.authService.confirmPassword(data).subscribe((res: any) => {
        if (res.message === 'Request successful') {
          // this.notificationService.showSuccess('Password reset successful!');
          // tslint:disable-next-line: max-line-length
          this.utilityService.showTranslatedNotificationMessage('CONFIRMFORGOTPASSWORD.PasswordResetSuccess', 'SUCCESS');
          this.closeEvent.emit(true);
        }
      });
    }
  }


  get verificationCode() {
    return this.confirmForgotPasswordForm.get('verificationCode');
  }

  get newPassword() {
    return this.confirmForgotPasswordForm.get('newPassword');
  }


}
