import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'ab-maintainance',
  templateUrl: './maintainance.component.html',
  styleUrls: ['./maintainance.component.scss']
})
export class MaintainanceComponent implements OnInit {
  showProgress: boolean = false;
  constructor( private router: Router ) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        (<any>window).ga('set', 'page', event.urlAfterRedirects);
        (<any>window).ga('send', 'pageview');
      }
    });
  }
  ngOnInit() {
    if (window.location.href.includes('/#!/library/dashboard')) {
      this.showProgress = true;
    }
  }
}
