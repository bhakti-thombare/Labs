// loader.interceptors.ts
import { Injectable } from '@angular/core';
import {
    HttpErrorResponse,
    HttpResponse,
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpParams
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoaderService } from '../services/loader.service';

@Injectable()
export class LoaderInterceptor implements HttpInterceptor {
    private requests: HttpRequest<any>[] = [];

    constructor(private loaderService: LoaderService) { }

    removeRequest(req: HttpRequest<any>) {
        const showLoader = req.params.get('loader');
        const i = this.requests.indexOf(req);
        if (i >= 0) {
            this.requests.splice(i, 1);
        }
        if (!showLoader) {
            setTimeout(() => {
                // console.log('this.requests', this.requests)
                this.loaderService.isLoading.next(this.requests.length > 0);
            }, 2000);
        }
    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const showLoader = req.params.get('loader');
        // console.log('showLoader', showLoader, req.url)

        // console.log('No of requests--->' + this.requests.length);
        if (!showLoader) {
            // console.log('loader not showned', showLoader)
            // setTimeout(() => {
            this.loaderService.isLoading.next(true);
            // }, 2000);
            // console.log('req', req);
        }
        if (req.params.has('loader')) {
            const queryParams = {};
            req.params.keys().forEach(key => {
                // key !== 'loader'
                if (true) {
                    queryParams[key] = req.params.get(key);
                }
            });
            // console.log('queryParams', queryParams);
            const proxyReq = req.clone({ params: this.serializeParams(queryParams) });
            // console.log('proxyReq', proxyReq);
            req = proxyReq;
            // console.log('req', req);
        }
        if (!req.url.includes('/v2/api/user/tutorial')) {
            this.requests.push(req);
        }
        // tslint:disable-next-line: deprecation
        return Observable.create((observer: any) => {
            const subscription = next.handle(req)
                .subscribe(
                    event => {
                        if (event instanceof HttpResponse) {
                            this.removeRequest(req);
                            observer.next(event);
                        }
                    },
                    err => {
                        // alert('error returned');
                        this.removeRequest(req);
                        observer.error(err);
                    },
                    () => {
                        this.removeRequest(req);
                        observer.complete();
                    });
            // remove request from queue when cancelled
            return () => {
                this.removeRequest(req);
                subscription.unsubscribe();
            };
        });
    }

    /**
     * Serialize search object to params
     */
    serializeParams(obj: any): HttpParams {
        let params = new HttpParams();
        for (const p in obj) {
            if (obj.hasOwnProperty(p)) {
                params = params.append(p, obj[p]);
            }
        }
        return params;
    }
}
