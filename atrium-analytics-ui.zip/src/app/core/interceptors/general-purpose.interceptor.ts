// loader.interceptors.ts
import { Injectable } from '@angular/core';
import {
    HttpErrorResponse,
    HttpResponse,
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpParams
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { UtilityService } from '../services/utility.service';
import { AuthService } from '../services/auth.service';

@Injectable()
export class GeneralPurposeInterceptor implements HttpInterceptor {
    private requests: HttpRequest<any>[] = [];
    currentUser: any;

    constructor(private authService: AuthService, private utilityService: UtilityService) {

        authService.currentUser$.subscribe(user => {
            this.currentUser = user;
        });
    }


    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        // for every PUT POST request, trim all strings, and remove empty in request body
        if (req.method === 'PUT' || req.method === 'POST') {
            let newBody = req.body;
            if (!req.url.includes('/v2/api/landing')) { newBody = this.utilityService.removeEmptyStringAndTrim(req.body); }
            // tslint:disable-next-line: max-line-length
            if (!req.url.includes('/v2/api/user/profile') && !req.url.includes('/v2/api/user/sign-up') && !req.url.includes('/v2/api/user/forgot-password') && !req.url.includes('/v2/api/landing/promoted-content')) {
                newBody.languageCode = localStorage.getItem('language');
                if (this.currentUser) {
                    newBody.languageCode = this.currentUser.language;
                    newBody.roleCode = this.currentUser.role;
                    newBody.userId = this.currentUser.id;
                } else if (!this.currentUser) {
                    newBody.languageCode = localStorage.getItem('language');
                    newBody.roleCode = 'visitor';
                    newBody.userId = '0';
                }
            }
            const body = req.body;
            const modifiedRequest = req.clone({
                body: newBody
            });
            req = modifiedRequest;
        }


        // tslint:disable-next-line: deprecation
        return Observable.create((observer: any) => {
            const subscription = next.handle(req)
                .subscribe(
                    event => {
                        if (event instanceof HttpResponse) {
                            // this.removeRequest(req);
                            observer.next(event);
                        }
                    },
                    err => {
                        // alert('error returned');
                        // this.removeRequest(req);
                        observer.error(err);
                    },
                    () => {
                        // this.removeRequest(req);
                        observer.complete();
                    });
            // remove request from queue when cancelled
            return () => {
                // this.removeRequest(req);
                subscription.unsubscribe();
            };
        });
    }

}
