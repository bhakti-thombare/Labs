import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

import { LoggingService } from '../services/logging.service';
import { ErrorService } from '../services/error.service';
import { NotificationService } from '../services/notification.service';
import { TranslateService } from '@ngx-translate/core';
import { ErrorMessageHandlerService } from '../services/error-message-handler.service';
import { UtilityService } from '../services/utility.service';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {

    // Error handling is important and needs to be loaded first.
    // Because of this we should manually inject the services with Injector.
    constructor(private injector: Injector, private translate: TranslateService) { }

    handleError(error: Error | HttpErrorResponse) {

        console.log('window.location.hostname', window.location.hostname);
        if (!window.location.hostname.includes('localhost')) {
            const errorService = this.injector.get(ErrorService);
            const logger = this.injector.get(LoggingService);
            const notifier = this.injector.get(NotificationService);
            const errorMessageHandler = this.injector.get(ErrorMessageHandlerService);
            const translate = this.injector.get(TranslateService);
            const utilityService = this.injector.get(UtilityService);
            let message;
            let stackTrace;

            // errorMessageHandler.getMessageFromError(error);
            if (error instanceof HttpErrorResponse) {
                console.log('----------------------------------------');
                console.log('server error', error);
                console.log('----------------------------------------');
                const key = errorMessageHandler.getMessageFromError(error);
                console.log('key', key);
                translate.get('NotificationMessages.' + key).subscribe((res: string) => {
                    console.log(res);
                    if (res.toLowerCase().includes('notificationmessages')) {
                        utilityService.showTranslatedNotificationMessage('NotificationMessages.General.ServerError', 'ERROR');
                    } else {

                        notifier.showError(res);
                    }
                    // => 'hello world'
                });
            } else {
                // errorMessageHandler.getMessageFromError(error, undefined);
                console.log('----------------------------------------');
                console.log('client error', error);
                console.log('----------------------------------------');
                // Client Error
                message = errorService.getClientMessage(error);
                stackTrace = errorService.getClientStack(error);
                // notifier.showError(message);
            }

            // Always log errors
            logger.logError(message, stackTrace);

            // console.error(error);}
        } else {
            throw error;
        }
    }

    // Must be removed once, error codes are added
    hotFixErrorMessage(message: string, lang: string) {
        let newMessage = '';
        switch (lang) {
            case 'en':
                newMessage = message.includes('Tableau Service failed 401 Unauthorized: [no body]') ?
                    'Invalid tableau credentials' : message;
                return newMessage;
            case 'fr':
                newMessage = message === 'Tag already exists for same category' ? 'Tag existe déjà pour la même catégorie' : message;
                newMessage = message.includes('Tableau Service failed 401 Unauthorized: [no body]') ?
                    'Informations d\'identification de Tableau non valides' : message;
                return newMessage;
            case 'nl':
                newMessage = message === 'Tag already exists for same category' ? 'Tag bestaat al voor dezelfde categorie' : message;
                newMessage = message.includes('Tableau Service failed 401 Unauthorized: [no body]') ?
                    'Ongeldige inloggegevens voor Tableau' : message;
                return newMessage;
        }
    }
}
