import { environment } from 'src/environments/environment';
export const errorMessage = [
    {
        url: `${environment.apiUrl}/v2/api/user/logout`,
        controller: 'Authentication',
        messages: []
    },
    {
        url: `${environment.apiUrl}/v2/api/user/login`,
        controller: 'Authentication',
        messages: [
            {
                401: 'InvalidEmailOrPassword',
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/user/sign-up`,
        controller: 'Authentication',
        messages: [
            {
                404: 'UserNotFound',
                401: 'UserNotAutherized',
                409: 'UserAlreadyExists',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/user/change-password`,
        controller: 'Authentication',
        messages: [
            {
                404: 'UserNotFound',
                401: 'UserPasswordChangedError',
                409: 'UserPasswordChangedError',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/user/forgot-password`,
        controller: 'Authentication',
        messages: [
            {
                500: 'UserNotFound',
                404: 'UserNotFound',
                401: 'UserNotAutherized',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/user/confirm-forgot-password`,
        controller: 'Authentication',
        messages: [
            {
                400: 'InvalidVerficationCode',
                404: 'UserNotFound',
                401: 'UserNotAutherized',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/contact/contact-us`,
        controller: 'AboutUs',
        messages: [
            {
                404: 'DataNotFound',
                401: 'UserNotAutherized',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/landing`,
        controller: 'Landing',
        messages: [
            {
                404: 'DataNotFound',
                401: 'UserNotAutherized',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/about-us`,
        controller: 'AboutUs',
        messages: [
            {
                404: 'DataNotFound',
                401: 'UserNotAutherized',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/user/profile`,
        controller: 'User',
        messages: [
            {
                404: 'UserNotFound',
                401: 'InvalidTableauCredentials',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/viz/invite`,
        controller: 'Viz',
        messages: [
            {
                404: 'VizNotFound',
                401: 'UserNotAutherized',
                409: 'UserInvited',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/viz`,
        controller: 'Viz',
        messages: [
            {
                404: 'VizNotFound',
                401: 'UserNotAutherized',
                409: 'VizAlreadyExists',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/tag/search?search=tagName,`,
        controller: 'Tag',
        messages: [
            {
                404: 'TagNotFound',
                401: 'UserNotAutherized',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/viz/favorite`,
        controller: 'Viz',
        messages: [
            {
                404: 'VizNotFound',
                401: 'UserNotAutherized',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/viz/search`,
        controller: 'Viz',
        messages: [
            {
                404: 'UsersNotFound',
                401: 'UserNotAutherized',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/viz/invite`,
        controller: 'Viz',
        messages: [
            {
                404: 'VizNotFound',
                401: 'UserNotAutherized',
                409: 'UserInvited',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/category/all`,
        controller: 'Category',
        messages: [
            {
                404: 'CategoryNotFound',
                401: 'UserNotAutherized',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/tag/category`,
        controller: 'Tag',
        messages: [
            {
                404: 'TagNotFound',
                401: 'UserNotAutherized',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/tag`,
        controller: 'Tag',
        messages: [
            {
                404: 'TagNotFound',
                401: 'UserNotAutherized',
                409: 'TagExists',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/tag/delete`,
        controller: 'Tag',
        messages: [
            {
                404: 'TagNotFound',
                401: 'UserNotAutherized',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/user`,
        controller: 'User',
        messages: [
            {
                404: 'UserNotFound',
                401: 'InvalidTableauCredentials',
                409: 'UserAlreadyExists',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/user/admin/all`,
        controller: 'User',
        messages: [
            {
                404: 'UserNotFound',
                401: 'UserNotAutherized',
                409: 'there is a conflict',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/user/admin/profile`,
        controller: 'User',
        messages: [
            {
                404: 'UserNotFound',
                401: 'InvalidTableauCredentials',
                409: 'InvalidTableauCredentials',
                417: 'the expectation failed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/user/delete`,
        controller: 'User',
        messages: [
            {
                404: 'UserNotFound',
                401: 'UserNotAutherized',
                409: 'UserConflict',
                417: 'UserExpectFailed'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/library/cards/viz`,
        controller: 'Viz',
        messages: [
            {
                404: 'VizNotFound',
                417: 'VizNotFound',
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/library/cards/product`,
        controller: 'Viz',
        messages: [
            {
                404: 'ProductNotFound',
                417: 'ProductNotFound'
            }
        ]
    },

    {
        url: `${environment.apiUrl}/v2/api/product/delete`,
        controller: 'Product',
        messages: [
            {
                404: 'ProductNotFound',
                417: 'ProductNotFound'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/product/trusted`,
        controller: 'Product',
        messages: [
            {
                404: 'ProductNotFound',
                417: 'ProductNotFound',
                401: 'UserNotAuthorized'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/product/view`,
        controller: 'Product',
        messages: [
            {
                404: 'ProductNotFound',
                417: 'ProductNotFound',
                401: 'UserNotAuthorized'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/product/invite/users`,
        controller: 'Product',
        messages: [
            {
                409: 'UserAlreadyInvited',
                404: 'ProductNotFound',
                417: 'ProductNotFound',
                401: 'UserNotAuthorized'
            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/dashboard/favorite`,
        controller: 'Dashboard',
        messages: [
            {

                404: 'FavoriteContentNotFound',

            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/dashboard/invited`,
        controller: 'Dashboard',
        messages: [
            {

                404: 'SharedContentNotFound',

            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/dashboard/invited`,
        controller: 'Dashboard',
        messages: [
            {

                404: 'SharedContentNotFound',

            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/dashboard/private-products`,
        controller: 'Dashboard',
        messages: [
            {

                404: 'PrivateContentNotFound',

            }
        ]
    },
    {
        url: `${environment.apiUrl}/v2/api/dashboard/draft-elements`,
        controller: 'Dashboard',
        messages: [
            {

                404: 'DraftContentNotFound',

            }
        ]
    },





];
