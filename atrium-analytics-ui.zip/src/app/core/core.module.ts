import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { RestService } from './services/rest.service';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoaderService } from './services/loader.service';
import { LoaderInterceptor } from './interceptors/loader.interceptor';
import { AuthGuard } from './guards/auth.guard';
import { UtilityService } from './services/utility.service';
import { GeneralPurposeInterceptor } from './interceptors/general-purpose.interceptor';
import { AdminGuard } from './guards/admin.guard';
import { AdminChampionGuard } from './guards/admin-champion.guard';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    // BrowserAnimationsModule, // required animations module
    HttpClientModule,
    ToastrModule.forRoot() // ToastrModule added
  ],
  providers: [AdminChampionGuard,
    AdminGuard, AuthGuard, UtilityService, RestService, LoaderService, LoaderInterceptor, GeneralPurposeInterceptor]
})
export class CoreModule { }
