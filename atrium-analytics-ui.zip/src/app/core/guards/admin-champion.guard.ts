import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { first, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AdminChampionGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    // console.log('ahsasaaasas')
    return this.authService.currentUser$.pipe(first(), map(user => {
      // console.log('user', user)
      // console.log('user', user)
      if (user) {
        if (user.role === 'admin' || user.role === 'champion') {
          return true;
        } else {
          this.router.navigateByUrl('/user/dashboard');
          return false;
        }
      } else {
        // console.log('user', user)
        this.router.navigateByUrl('/');
        return false;
      }
    }));
  }

}
