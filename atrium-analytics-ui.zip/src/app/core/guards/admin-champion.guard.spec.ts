import { TestBed, async, inject } from '@angular/core/testing';

import { AdminChampionGuard } from './admin-champion.guard';

describe('AdminChampionGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdminChampionGuard]
    });
  });

  it('should ...', inject([AdminChampionGuard], (guard: AdminChampionGuard) => {
    expect(guard).toBeTruthy();
  }));
});
