import { Injectable, Injector } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { NotificationService } from './notification.service';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UtilityService {

  public startTour = new BehaviorSubject(false);
  // public injector: Injector;
  constructor(private injector: Injector) {
  }
  notificationService = this.injector.get(NotificationService);
  translate = this.injector.get(TranslateService);

  /**
   * get language code from language word
   */
  public getLanguageCode(language: string) {
    switch (language) {
      case 'English':
        return 'en';
      case 'French':
        return 'fr';
      case 'Dutch':
        return 'nl';
    }
  }



  /**
   * get language word from language code
   */
  public getLanguage(lang: any) {
    switch (lang) {
      case 'en':
        return 'English';
      case 'fr':
        return 'French';
      case 'nl':
        return 'Dutch';
    }
  }


  /**
   * Replace empty string with null
   * Trim string left and right
   */
  public removeEmptyStringAndTrim(obj: any) {
    // tslint:disable-next-line: forin
    for (const k in obj) {
      if (obj[k] instanceof Object) {
        this.removeEmptyStringAndTrim(obj[k]);
      } else {
        // document.write(obj[k] + '<br>');
        if (typeof obj[k] === 'string') {
          if (obj[k] === '' || obj[k] === ' ') {
            delete obj[k];
          } else {
            obj[k] = obj[k].toString().trim();
          }
        }
      }
    }
    return obj;
  }

  /**
   * show translated notification message
   * params: keyword from translation and notification type(success, error, etc)
   */
  public showTranslatedNotificationMessage(translationKeyword, notificationType) {

    // const notificationService = injector.get(NotificationService);
    // const translate = injector.get(TranslateService);
    this.translate.get(translationKeyword).subscribe((res: string) => {
      switch (notificationType) {
        case 'ERROR':
          this.notificationService.showError(res);
          break;
        case 'SUCCESS':
          this.notificationService.showSuccess(res);
          break;
        case 'INFORMATION':
          this.notificationService.showInfo(res);
          break;
      }
    });
  }

  public titleCase(str) {
    str = str.toLowerCase()
      .split(' ')
      .map((word) => {
        return (word.charAt(0).toUpperCase() + word.slice(1));
      });
    return str.join(' ');
  }

}
