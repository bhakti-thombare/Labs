import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpHeaders,
  HttpParams
} from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { throwError, Observable } from 'rxjs';
import { Cookie } from './cookie';
enum RequestMethod {
  GET = 'get',
  POST = 'post',
  PUT = 'put',
  DELETE = 'delete'
}
@Injectable({
  providedIn: 'root'
})
export class RestService {
  options: {
    headers: HttpHeaders;
    observe: 'response';
    params: HttpParams;
    reportProgress?: boolean;
    responseType?: 'json';
    withCredentials?: boolean;
  };


  constructor(private http: HttpClient) {
    // console.log('RestService constructor');
  }
  /**
   * Set basic headers
   */
  setEssentialHeaders() {
    this.options.headers.set('Content-Type', 'application/json');
    const token = localStorage.get('token');
    if (token) {
      this.options.headers.set('Authorization', `${token}`);
    }
  }

  /**
   * User can set custom headers
   */
  setCustomeHeaders(key: any, value: any) {
    this.options.headers.set(key, value);
  }

  /**
   * Returns an Observable for the HTTP GET request for the JSON resource.
   */
  fetch(path: string, params?: object, absoluteUrl?: boolean): Observable<any> {
    return this.request(path, RequestMethod.GET, undefined, params, absoluteUrl);
  }

  /**
   * Returns an Observable for the HTTP POST request for the JSON resource.
   */
  post(path: string, body: object, params?: object, absoluteUrl?: boolean): Observable<any> {
    return this.request(path, RequestMethod.POST, body, params, absoluteUrl);
  }

  /**
   * Returns an Observable for the HTTP PUT request for the JSON resource.
   */
  put(path: string, body: object, params?: object, absoluteUrl?: boolean): Observable<any> {
    return this.request(path, RequestMethod.PUT, body, params, absoluteUrl);
  }

  /**
   * Returns an Observable for the HTTP DELETE request for the JSON resource.
   */
  delete(path: string, body?: object, params?: object, absoluteUrl?: boolean): Observable<any> {
    return this.request(path, RequestMethod.DELETE, body, params, absoluteUrl);
  }


  private stripTrailingSlash = str => {
    return str.endsWith('/') ? str.slice(0, -1) : str;
  }

  getRequestUrl(path: string): string {
    const host = window.location.protocol + '//' + window.location.host;
    let xBase = (document.getElementsByTagName('base')[0] || { href: '/' }).href;
    xBase = xBase.replace(new RegExp(host, 'g'), '');
    return this.stripTrailingSlash(xBase) + path;
  }

  /**
   * Actual rest request based on params
   */
  private request(
    path: string,
    method: string,
    bodyValue?: object,
    params?: object,
    absoluteUrl?: boolean,
    isFile?: boolean,
  ): Observable<any> {
    const url = absoluteUrl ? path : this.getRequestUrl(path);
    // const token = Cookie.get('idToken');
    const requestHeaders: any = {}; // .set('Authorization', `Bearer ${token}`);

    if (!isFile) {
      requestHeaders['Content-Type'] = 'application/json';
    }
    const token = Cookie.get('idToken');
    const tokenType = Cookie.get('tokenType');
    if (token) {
      requestHeaders.Authorization = `${tokenType} ${token}`;
    }
    const options: any = {
      body: bodyValue,
      headers: new HttpHeaders(requestHeaders),
      reportProgress: undefined,
      observe: 'body',
      params: params ? this.serializeParams(params) : undefined,
      responseType: 'json',
      withCredentials: undefined
    };
    return this.http.request(method, url, options).pipe(
      map((res: any) => {
        // because 204 does not contain body
        if (res.status >= 201 && res.status <= 226) {
          return;
        }
        {
          return JSON.parse(JSON.stringify(res));
        }
      })
    );
    // , catchError(this.handleError),
  }

  /**
   * Serialize search object to params
   */
  serializeParams(obj: any): HttpParams {
    let params = new HttpParams();
    for (const p in obj) {
      if (obj.hasOwnProperty(p)) {
        params = params.append(p, obj[p]);
      }
    }
    return params;
  }


  /**
   * Handle HTTP error
   */
  private handleError(error: any) {
    // We'd also dig deeper into the error to get a better message
    let errMsg = error.status
      ? `${error.status} - ${error.statusText || error.message}`
      : 'Server error';
    if (error._body) {
      try {
        const json = error.json();
        if (json.message) {
          errMsg = json.message;
        } else {
          errMsg = json;
        }
      } catch (error) { }
    }
    // console.error(errMsg); // log to console instead
    if (error.status === 401 || error.status === 403) {
      localStorage.removeItem('_activeUser');
      let baseHost = window.location.hostname;
      // Cookie.delete('token')
      if (!baseHost) {
        const domains = window.location.hostname.split('.');
        // assume we have 2 level domain always
        if (domains.length >= 2) {
          baseHost = `${domains[domains.length - 2]}.${domains[domains.length - 1]}`;
        }
      }
      const host = window.location.protocol + '//' + window.location.host;
      window.location.href = host + '/auth/login';
    }
    return throwError(errMsg);
  }
}
