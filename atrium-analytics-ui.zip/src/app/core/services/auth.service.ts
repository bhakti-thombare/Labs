import { Injectable } from '@angular/core';
import { ReplaySubject, Observable, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Cookie } from './cookie';
import { NotificationService } from './notification.service';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private currentUser: ReplaySubject<any> = new ReplaySubject<any>(undefined);
  private idToken: ReplaySubject<string> = new ReplaySubject(1);
  private loggedIn: ReplaySubject<boolean> = new ReplaySubject(1);

  /**
   * Current user
   *
   */
  currentUser$: Observable<any> = this.currentUser.asObservable();

  /**
   * Token for current user
   */
  idToken$: Observable<any> = this.idToken.asObservable();

  /**
   * Current logged in status
   */
  loggedIn$: Observable<boolean> = this.loggedIn.asObservable();

  baseApi = environment.baseUrl || '';
  production = environment.production || false;

  /**
   * Base host of app
   */
  public baseHost(): string {
    return Cookie.get('_host');
  }

  constructor(
    private translate: TranslateService,
    private http: HttpClient,
    public router: Router,
    private notificationService: NotificationService
  ) {
    this.init();
  }

  init() {
    const idToken = Cookie.get('idToken');
    if (idToken) {
      this.idToken.next(idToken);
      this.loggedIn.next(true);

      this.loadCurrentUser();
    } else {
      this.loggedIn.next(false);
    }
  }

  login(currentRoute: string, rawEmail: string, emailValue: string, passwordValue: string): Observable<string> {
    const url = environment.apiUrl + '/v2/api/user/login';
    const body = {
      userName: emailValue,
      password: passwordValue
    };
    const request = this.http.post<any>(url, body);
    request.subscribe((r: any) => this.handleLogin(currentRoute, rawEmail, r));
    return request;
  }

  logout(userNameValue: string): Observable<any> {
    return new Observable<any>((observer: any) => {
      // clear idToken$ remove user from local storage to log user out
      const url = environment.apiUrl + '/v2/api/user/logout';
      const body = {
        userName: userNameValue,
      };
      this.http.post<any>(url, body).subscribe(res => {
        if (res.message === 'Request successful') {
          this.removeAuthCookie();
          this.loggedIn.next(false);
          observer.next();
        }
      });

    });
  }

  signUp(user: any): Observable<any> {
    const url = environment.apiUrl + '/v2/api/user/sign-up';
    const request = this.http.post(url, user);
    // request.subscribe((r: any) => this.handleLogin(r));
    return request;
  }

  verifyActivationLink(idToken$: string): Observable<any> {
    const url = '/api/user/self';
    const request = this.http.get(url, { headers: { Authorization: `${idToken$}` } });
    // request.subscribe((r: any) => this.handleLogin(r));
    return request;
  }

  setPassword(setPassword: any, idToken$: string): Observable<any> {
    const url = '/api/user/password';
    const request = this.http.put(url, setPassword, { headers: { Authorization: `${idToken$}` } });
    // request.subscribe((r: any) => this.handleLogin(r));
    return request;
  }

  resetPassword(body: any): Observable<any> {
    const url = environment.apiUrl + '/v2/api/user/change-password';
    const idToken = Cookie.get('idToken');
    const accessToken = Cookie.get('accessToken');
    const tokenType = Cookie.get('tokenType');
    body.accessToken = accessToken;
    const request = this.http.put(url, body, {
      headers: { Authorization: `${tokenType} ${idToken}` },
    });
    // request.subscribe((r: any) => this.handleLogin(r));
    return request;
  }

  forgotPassword(emailValue: any): Observable<any> {
    const url = environment.apiUrl + '/v2/api/user/forgot-password';
    const request = this.http.put(url, { email: emailValue });
    // request.subscribe((r: any) => this.handleLogin(r));
    return request;
  }

  confirmPassword(data: any): Observable<any> {
    const url = environment.apiUrl + '/v2/api/user/confirm-forgot-password';
    const request = this.http.put(url, data);
    // request.subscribe((r: any) => this.handleLogin(r));
    return request;
  }

  loadCurrentUser() {
    // return new Observable<any>((observer: any) => {
    //   // clear idToken$ remove user from local storage to log user out
    //   const url = environment.apiUrl + '/v2/api/user/logout';
    //   const body = {
    //     userName: userNameValue,
    //   };
    //   this.http.post<any>(url, body).subscribe(res => {
    //     if (res.message === 'Request successful') {
    //       this.removeAuthCookie();
    //       this.loggedIn.next(false);
    //       observer.next();
    //     }
    //   });

    // });
    // const request = this.http.get('/api/auth/self', null);

    // request.subscribe((response: any) => {
    const a = localStorage.getItem('activeUser');
    this.currentUser.next(JSON.parse(a));
    // if (this.router.url === '/auth/login') {
    //   this.router.navigate(['tasks']);
    // }
    // this.currentUser.next(response);
    // });
    // return a;
  }

  refreshAvatar(res: any) {
    const user = JSON.parse(localStorage.getItem('activeUser'));
    user.updatedAt = res.updatedAt;
    user.avatar = res.avatar;
    localStorage.setItem('activeUser', JSON.stringify(user));
    this.currentUser.next(user);
  }


  removeAuthCookie() {
    localStorage.removeItem('activeUser');
    Cookie.deleteAll(['visited', 'library_page_visited', 'product_page_visited', 'HSDashboard_page_visited']);
  }


  private handleLogin(currentRoute, rawEmail: string, response: any) {
    // login successful if there's a jwt idToken$ in the response
    if (response.status !== 500) {
      if (response) {
        if (currentRoute === '/') {
          this.router.navigateByUrl('/user/dashboard');
        }
        const activeUser = response.value;
        const { idToken, accessToken, refreshToken, tokenType } = activeUser;
        activeUser.rawEmail = rawEmail;
        delete activeUser.accessToken;
        delete activeUser.refreshToken;
        delete activeUser.tokenType;
        delete activeUser.idToken;
        // update jobtitle with key for further things on account page
        const jobTitles = [
          { nltitle: 'Werknemer', frtitle: 'Employé.e', entitle: 'Employee', code: 'Employee' },
          { nltitle: 'Werkzoekende', frtitle: 'En recherche d\'emploi', entitle: 'Looking for a job', code: 'LookingJob' },
          { nltitle: 'Ondernemer', frtitle: 'Entrepreneur.e', entitle: 'Entrepreneur', code: 'Entrepreneur' },
          { nltitle: 'Student', frtitle: 'Etudiant.e', entitle: 'Student', code: 'Student' },
          { nltitle: 'Afgesturdeerde', frtitle: 'Jeune diplômé.e', entitle: 'Young Graduate', code: 'YoungGraduate' },
          { nltitle: 'Manager', frtitle: 'Manager', entitle: 'Manager', code: 'Manager' },
          {
            nltitle: 'Lid van een handelsvereniging',
            frtitle: 'Membre d\'une association de commerçants', entitle: 'Member of a merchant association', code: 'MerchantAssociation'
          },
          {
            nltitle: 'Lid van een bewonersvereniging',
            frtitle: 'Membre d\'une association de riverains', entitle: 'Member of a residents\' association', code: 'ResidentOrAssociation'
          },
          { nltitle: 'Partener', frtitle: 'Partenaire', entitle: 'Partner', code: 'Partner' },
          { nltitle: 'CEO', frtitle: 'PDG', entitle: 'CEO', code: 'CEO' },
          { nltitle: 'Stagiair', frtitle: 'Stagiaire', entitle: 'Trainee', code: 'Trainee' },
          { nltitle: 'Andere', frtitle: 'Autre', entitle: 'Other', code: 'Other' }
        ];

        let jobKey = null;
        if (activeUser.jobTitle) {
          const jobObject = jobTitles
            .filter(item => item[activeUser.language + 'title'].toLowerCase() === activeUser.jobTitle.toLowerCase())[0];
          if (jobObject) {
            jobKey = jobObject.code;
          }
        }
        activeUser.jobTitle = jobKey;

        if (activeUser.role === 'admin' || activeUser.role === 'champion') {
          Cookie.set('library_page_visited',
            'yes',
            new Date(new Date().setFullYear(new Date().getFullYear() + 10)),
            '/',
            Cookie.get('_host'));
          Cookie.set('product_page_visited',
            'yes',
            new Date(new Date().setFullYear(new Date().getFullYear() + 10)),
            '/',
            Cookie.get('_host'));
          Cookie.set('HSDashboard_page_visited',
            'yes',
            new Date(new Date().setFullYear(new Date().getFullYear() + 10)),
            '/',
            Cookie.get('_host'));
        }
        // set user language
        localStorage.setItem('language', activeUser.language);
        this.translate.use(activeUser.language);
        const now = new Date();
        try {
          // console.log('this.baseHost()', this.baseHost());
          Cookie.set(
            'idToken',
            idToken,
            1,
            '/',
            this.baseHost(),
          );

          Cookie.set(
            'accessToken',
            accessToken,
            1,
            '/',
            this.baseHost(),
          );

          Cookie.set(
            'refreshToken',
            refreshToken,
            1,
            '/',
            this.baseHost(),
          );

          Cookie.set(
            'tokenType',
            tokenType,
            1,
            '/',
            this.baseHost(),
          );
        } catch (e) {
          console.log(e);
        }
        localStorage.setItem('activeUser', JSON.stringify(activeUser));
        this.currentUser.next(activeUser);
        this.idToken.next(idToken);
        this.loggedIn.next(true);
        // this.router.navigate(['tasks'])
      }
    } else {
      // console.log('notificationService', this.notificationService);
      this.notificationService.showError(response.message);
    }
  }

  /**
   * update current user in local storage
   */
  updateCurrentUser(updateUser: any) {

    const activeUser: any = JSON.parse(localStorage.getItem('activeUser'));

    const newActiveUser = Object.assign({}, activeUser, updateUser);
    localStorage.setItem('language', updateUser.language);
    localStorage.setItem('activeUser', JSON.stringify(newActiveUser));
    this.currentUser.next(newActiveUser);
    // window.location.reload();
    this.translate.use(updateUser.language);
  }

  /**
   * Handle HTTP error
   */
  private handleError(error: any) {
    // We'd also dig deeper into the error to get a better message
    let errMsg = error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    if (error._body) {
      try {
        const json = error.json();
        if (json.message) {
          errMsg = json.message;
        } else {
          errMsg = json;
        }
      } catch (error) { }
    }
    console.error(errMsg); // log to console instead
    if (error.status === 401 || error.status === 403) {
      localStorage.removeItem('activeUser');
      let baseHost = this.baseHost() || window.location.hostname;
      Cookie.delete('idToken');
      if (!baseHost) {
        const domains = window.location.hostname.split('.');
        // assume we have 2 level domain always
        if (domains.length >= 2) {
          baseHost = `${domains[domains.length - 2]}.${domains[domains.length - 1]}`;
        }
      }
      this.router.navigate(['auth/login']);
    }
    return throwError(errMsg);
  }
}
