import { TestBed } from '@angular/core/testing';

import { ErrorMessageHandlerService } from './error-message-handler.service';

describe('ErrorMessageHandlerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ErrorMessageHandlerService = TestBed.get(ErrorMessageHandlerService);
    expect(service).toBeTruthy();
  });
});
