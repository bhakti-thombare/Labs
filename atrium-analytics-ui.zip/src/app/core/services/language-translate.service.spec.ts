import { TestBed } from '@angular/core/testing';

import { LanguageTranslateService } from './language-translate.service';

describe('LanguageTranslateService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LanguageTranslateService = TestBed.get(LanguageTranslateService);
    expect(service).toBeTruthy();
  });
});
