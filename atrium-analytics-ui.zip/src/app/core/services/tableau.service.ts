import { Injectable } from '@angular/core';
import { from, fromEvent, Observable, Subscription, combineLatest, forkJoin, ReplaySubject, of, throwError } from 'rxjs';
import { filter, toArray, concatAll, mergeAll, catchError } from 'rxjs/operators';
import * as _ from 'lodash';
declare var tableau: any;
@Injectable({
  providedIn: 'root'
})
export class TableauService {
  allMarkVizs$: Subscription[];
  shouldListenMarkEvent = true;
  allFilterList: ReplaySubject<any> = new ReplaySubject<any>(undefined);
  allFilterList$: Observable<any> = this.allFilterList.asObservable();
  shouldListenFilterEvent = true;
  newSheetsForFilter: any[];
  newSheetsForMarkSelection: any[];
  activeSheetsForFilter: number;
  counter: any;
  subscription: Subscription;
  dontCall: boolean;
  markSelectedFilterName = [];
  markSheetName: any;
  markSheetUrl: any;

  constructor() { }

  /**
   * Returns the viz url from them embed html code
   */
  getVizUrlFromEmbedCode(code: string) {

    const embedCodeTagArray = unescape(code.toString().replace(/&#(\d+);/g, (match, dec) => {
      return String.fromCharCode(dec);
    }).replace(/>/g, '>\n')).split('\n');
    let link = '';
    embedCodeTagArray.forEach(tag => {
      if (tag.includes('name=\'host_url\'') || tag.includes('name=\'path\'') || tag.includes('name=\'name\'')) {
        const newPart = tag.match(new RegExp('value=\'' + '(.*)' + '\''))[1];
        link = link + newPart;
        if (tag.includes('name=\'host_url\'')) { link = link + 'views/'; }
      }
    });
    return link;
  }

  /**
   * get filters from all instantiated vizzes
   */
  getAllVizFilters() {
    this.getFilterDataOfActiveSheet().subscribe((res: any) => {
      const newFilterData = res.flat(1);
      // console.log('newFilterData', newFilterData);
      const latestFilterData = [];
      // tslint:disable-next-line: no-shadowed-variable
      for (const filter of newFilterData) {
        const data = {
          name: filter.getFieldName(),
          values: filter.getAppliedValues()
        };
        latestFilterData.push(data);
      }
      const filterList = _.uniqBy(latestFilterData, 'name');
      this.allFilterList.next(filterList);
    });
  }


  /**
   * get filter by active sheets all together
   */
  getFilterDataOfActiveSheet() {
    const vizzes = tableau.VizManager.getVizs();
    const activeSheets = this.getAllActiveSheets(vizzes);
    const filterData = [];
    const filterList = [];
    for (const sheet of activeSheets) {
      filterData.push(from(sheet.getFiltersAsync()));
    }
    return forkJoin(filterData);
  }

  getFilterDataOfSpecificActiveSheet(activeSheets) {
    const vizzes = tableau.VizManager.getVizs();
    // const activeSheets = this.getAllActiveSheets(vizzes);
    const filterData = [];
    const filterList = [];
    for (const sheet of activeSheets) {
      // console.log('sheet', sheet)
      filterData.push(from(sheet.getFiltersAsync()));
    }
    // console.log('filterData', filterData)
    return forkJoin(filterData);
  }

  getMarkSelectionDataOfSpecificActiveSheet(activeSheets) {
    const vizzes = tableau.VizManager.getVizs();
    // const activeSheets = this.getAllActiveSheets(vizzes);
    const filterData = [];
    const filterList = [];

    for (const sheet of activeSheets) {
      // console.log(sheet)
      filterData.push(from(sheet.getDataSourcesAsync()));
    }
    return forkJoin(filterData);
  }


  /**
   * Get filter by active sheet single
   */
  getFilterByActiveSheet(activeSheet) {
    const a = activeSheet.getFiltersAsync();
    // console.log('a', a);
    const observable = from(a);
    return observable;
  }


  /**
   * Apply selected filters to single active sheet
   */
  // tslint:disable-next-line: no-shadowed-variable
  applyFilterToActiveSheet(activeSheet, filter, value) {
    const a = activeSheet.applyFilterAsync(filter, value, tableau.FilterUpdateType.REPLACE);
    const observable = from(a);
    return observable;
  }

  /**
   * Apply selected marks on single active sheet
   */
  applySelectedMarks(sheet, markData: any) {
    return from(sheet.selectMarksAsync(markData, tableau.SelectionUpdateType.REPLACE));
  }



  /**
   * get marks from marks event handler to apply mark on other vizzes
   */
  getMarks(event: any) {
    return from(event.getMarksAsync());
  }

  /**
   * Start listening mark selection event on all active sheets(instantiated vizzes)
   */
  startMarkEventListener() {
    this.allMarkVizs$ = [];
    const vizzes = tableau.VizManager.getVizs();
    const vizObservables = vizzes.map(viz => fromEvent(viz, 'marksselection'));
    this.allMarkVizs$ = vizObservables
      .map(viz =>
        viz.pipe(
          filter(data => this.shouldListenMarkEvent === true)
        ).subscribe(eventData => this.markEventHandler(eventData)));
  }

  /**
   * Mark selection event handler
   */
  markEventHandler(eventData: any) {
    if (eventData) {
      // console.log('eventData', eventData)
      // console.log('is it calling many times?')
      this.shouldListenMarkEvent = false;
      let vizzes = tableau.VizManager.getVizs();
      const emitterVizUrl = eventData.getViz().getUrl();
      vizzes = vizzes.filter(viz => viz.getUrl() !== emitterVizUrl);
      const activeSheets = this.getAllActiveSheets(vizzes);
      // console.log('activeSheets', activeSheets)
      this.getMarks(eventData).subscribe((markData: any) => {
        if (!markData.length) {
          this.shouldListenFilterEvent = false;
          this.markSheetName = '';
          this.markSheetUrl = '';
          // activeSheets.forEach((activeSheet: any) => activeSheet.clearSelectedMarksAsync());
          this.markSelectedFilterName = Array.from(new Set(this.markSelectedFilterName));
          const filterNames = JSON.parse(JSON.stringify(this.markSelectedFilterName));
          // console.log('filterNames to clear', filterNames)
          for (const filterName of filterNames) {
            this.clearAllFilters(filterName);
          }
          this.markSelectedFilterName = [];
          this.shouldListenMarkEvent = true;
        } else {
          // console.log('markData', markData[0].getPairs())
          const data = [];
          this.markSheetName = eventData.getWorksheet().getName();
          this.markSheetUrl = eventData.getViz().getUrl();


          /** V1
           * applying selection mark on all the worksheets in webpage, marks data got from current markselection event
           */
          // this.applyMarkSelectionOnSheets(activeSheets, markData); // With marks data


          /**
           *   V2
           *   applying filter values got from worksheet which is associated with current event,
           *   then applying those filter values to all viz/worksheets available.
           *    NOTE: this could mishave in some cases and work in some cases, not reliable
           */
          // this.getFilterByActiveSheet(eventData.getWorksheet()).subscribe((res: any) => {
          //   const filterData = res.flat(1);
          //   console.log('filterData', filterData)
          //   filterData.forEach((filterElement, index) => {
          //     from(filterElement.getFieldAsync()).subscribe(currentFilter => {
          //       console.log('currentFilter', currentFilter)
          //     });
          //     const filterValues = [];
          //     console.log('filterElement.getAppliedValues()', filterElement.getAppliedValues())
          //     filterElement.getAppliedValues().forEach(element => {
          //       filterValues.push(element.formattedValue);
          //     });
          //     console.log('calling for filter', filterElement, index)
          //     console.log('filterElement.getFieldName()', filterElement.getFieldName());
          //     console.log('filterValues', filterValues)
          //   });

          // });

          // -------------------------------------------------------------------------------
          /**
           * V3
           * get marks (fields and values), apply those marks field name as filter on other sheets with the marks values
           */
          // for (const element of markData[0].getPairs()) {
          //   console.log('element', element)
          //   data.push(element);
          // }

          // this.filterEventHandlerForMark(data, eventData, 'categorical');

          // ------------------------------------------------------------------------------

          /**
           * V4
           * get filter and their applied values of current worksheet associated with event,
           * then apply those filters to all the worksheets available on web(provided they are applicable)
           */
          // this.getFilterByActiveSheet(eventData.getWorksheet()).subscribe((worrrrrk: any) => {

          //   for (const item of worrrrrk) {
          //     console.log('item.getAppliedValues()', item.getFieldName())
          //     console.log('item.getAppliedValues()', item.getAppliedValues())
          //     data.push({
          //       fieldName: item.getFieldName(),
          //       value: item.getAppliedValues()
          //     })
          //   }
          // });

          /**
           * V5
           * get summarydata--> which gives current selected columns and values,
           * with those columns and their values apply the those columns as filters on other
           * sheets provided they have that filter present
           */
          const selectedSummaryData = [];
          from(eventData.getWorksheet().getSummaryDataAsync()).subscribe((summaryData: any) => {
            // console.log('summaryData', summaryData.getData())
            // console.log('summaryData', summaryData.getColumns())
            for (let i = 0; i < summaryData.getColumns().length; i++) {
              const column = summaryData.getColumns()[i];
              const newData = {
                fieldName: column.getFieldName(),
                value: []
              };
              // tslint:disable-next-line: prefer-for-of
              for (let j = 0; j < summaryData.getData().length; j++) {
                // console.log('summaryData.getData()[j][i]', summaryData.getData()[j][i])
                newData.value.push(summaryData.getData()[j][i].value);
              }
              selectedSummaryData.push(newData);
            }
            // console.log('selectedSummaryData', selectedSummaryData)
            this.filterEventHandlerForMark(selectedSummaryData, eventData, 'categorical');
          });



        }
      }, error => {

      });
    }
  }

  /**
   * Apply marks on all active sheets
   */
  applyMarkSelectionOnSheetsWithFieldValue(activeSheets: any, fieldName: any, value: any) {

    // tslint:disable-next-line: deprecation
    const markedObservable$ = combineLatest(
      activeSheets
        .map(activeSheet => {
          const a = from(activeSheet.selectMarksAsync(fieldName, value, tableau.SelectionUpdateType.REPLACE));
          return a;
        }));
    return markedObservable$.subscribe(res => {
      this.shouldListenMarkEvent = true;
    }, error => { });
  }



  /**
   * Apply marks on all active sheets
   */
  applyMarkSelectionOnSheets(activeSheets: any, markData: any) {

    // tslint:disable-next-line: deprecation
    // const markedObservable$ = combineLatest(
    //   activeSheets
    //     .map(activeSheet => {
    //       //   .map(activeSheet => {
    //       // activeSheet.clearSelectedMarksAsync()
    //       const a = from(activeSheet.selectMarksAsync(markData, tableau.SelectionUpdateType.ADD));
    //       return a;
    //     }));
    // return markedObservable$.subscribe(res => {
    //   console.log('res', res)
    //   // this.startMarkEventListener()
    //   this.shouldListenMarkEvent = true;
    // }, error => { });
    const promises = [];
    for (const activeSheet of activeSheets) {
      promises.push(activeSheet.selectMarksAsync(markData, tableau.SelectionUpdateType.REPLACE));
    }

    // console.log('promises', promises)
    this.subscription = from(promises).pipe(
      concatAll(),
      toArray()
    )
      .subscribe(v => {
        this.shouldListenMarkEvent = true;
        // console.log(v)
        // this.subscription.unsubscribe();
      });
  }


  applyMarkSelectionForValidActiveSheets(activeSheets, fieldNames, markData) {
    this.newSheetsForMarkSelection = [];
    // this.getMarkSelectionDataOfSpecificActiveSheet(activeSheets).subscribe((res: any) => {
    //   console.log('data sources res', res)
    //   const filtersData = res.flat(1);
    //   console.log('filtersData', filtersData)
    //   filtersData.forEach(filterElement => {
    //     console.log('filterElement', filterElement)
    //     filterElement.getFields().forEach(element => {
    //       console.log('element.getName()', element.getName())
    //     });
    //     console.log('fieldNames', fieldNames)
    //     if (fieldNames.includes(filterElement.getFieldName())) {
    //       this.newSheetsForMarkSelection.push(filterElement.getWorksheet());
    //     }
    //   });
    //   if (this.newSheetsForMarkSelection.length) { this.applyMarkSelectionOnSheets(this.newSheetsForMarkSelection, markData); }
    // });
    this.getActiveSheetDataSource(activeSheets[0]).subscribe(res => {
      // console.log('res', res[0].getName())
      this.shouldListenMarkEvent = true;
    });
    this.getFilterDataOfSpecificActiveSheet(activeSheets).subscribe((filterData: any) => {
      // console.log('filter datafilterData', filterData.flat(1))
      filterData = filterData.flat(1);
      for (const filterElement of filterData) {
        // console.log('filterElement', filterElement.getFieldName());

      }

    });

  }


  getActiveSheetDataSource(sheet) {
    return from(sheet.getDataSourcesAsync());
  }


  /**
   * Start listening on filter event on all instantiated vizzes
   */
  startFilterEventListener() {
    this.dontCall = true;
    this.allMarkVizs$ = [];
    const vizzes = tableau.VizManager.getVizs();
    // console.log('vizzes', vizzes.length)
    const vizObservables = vizzes.map(viz => fromEvent(viz, 'filterchange'));
    this.allMarkVizs$ = vizObservables
      .map(viz =>
        viz.pipe(
          filter(data => this.shouldListenFilterEvent === true)
        ).subscribe(eventData => {
          // console.log('this.shouldListenFilterEvent', JSON.parse(JSON.stringify(this.shouldListenFilterEvent)))
          if (this.shouldListenFilterEvent && this.dontCall) {
            this.dontCall = false;
            this.getCurrentEventFilters(eventData).subscribe((res: any) => {
              // console.log('res', res)
              const filterData = res.flat(1);
              // console.log('filterData', filterData)

              // console.log('this.shouldListenFilterEvent', JSON.parse(JSON.stringify(this.shouldListenFilterEvent)))
              // console.log('eventData', eventData.getFieldName())
              const selectedFilter = filterData.filter(item => item.getFieldName() === eventData.getFieldName())[0];
              // console.log('selectedFilter', selectedFilter.getFilterType())
              if (selectedFilter) {
                if (selectedFilter.getFilterType() === 'categorical') {
                  // console.log('selectedFilter', selectedFilter.getAppliedValues())
                  const data = [];
                  for (const element of selectedFilter.getAppliedValues()) {
                    data.push(element.value);
                  }
                  this.filterEventHandler(eventData.getFieldName(), data, eventData, selectedFilter.getFilterType());
                }
                if (selectedFilter.getFilterType() === 'quantitative') {
                  // console.log('selectedFilter', selectedFilter.getFieldName());
                  const minValue = selectedFilter.getMin();
                  // console.log('min', minValue)
                  const maxValue = selectedFilter.getMax();
                  // console.log('max', maxValue)
                  // tslint:disable-next-line: max-line-length
                  this.filterEventHandler(eventData.getFieldName(), { min: minValue.value, max: maxValue.value }, eventData, selectedFilter.getFilterType());
                }

                if (selectedFilter.getFilterType() === 'relativedate') {
                  // console.log('selectedFilter', selectedFilter.getFieldName());
                  const periodValue = selectedFilter.getPeriod();
                  const rangeValue = selectedFilter.getRange();
                  const rangeNValue = selectedFilter.getRangeN();
                  const data = {
                    anchorDate: new Date(new Date().getTime() + (new Date().getTimezoneOffset() * 60000)),
                    periodType: periodValue,
                    rangeType: rangeValue,
                    rangeN: rangeNValue
                  };
                  // console.log('data', data);
                  this.filterEventHandler(eventData.getFieldName(), data, eventData, selectedFilter.getFilterType());
                }
              }
              // console.log('eventData name', eventData.getViz().getWorkbook().getActiveSheet().getName());
              // console.log('this.getAppliedValues(filterData)', this.getAppliedValues(filterData))
              // this.shouldListenFilterEvent = true;
              // this.filterEventHandler()
            });
          }
        }));

  }

  getAppliedValues(filterData) {
    const data: any = {};
    data.fieldName = filterData.getFieldName();
    data.appliedValues = filterData.getAppliedValues();
    return data;
  }

  getCurrentEventFilters(eventData) {

    return this.getFilterByActiveSheet(eventData.getWorksheet());

  }
  applyFiltersToOthers() {
    this.shouldListenFilterEvent = false;
  }

  getValidActiveSheetsForFilter(activeSheets, fieldName, filterValue, filterType, eventData) {
    this.newSheetsForFilter = [];
    // console.log('activeSheets', activeSheets)
    this.getFilterDataOfSpecificActiveSheet(activeSheets).subscribe((res: any) => {
      // console.log('res', res)
      // tslint:disable-next-line: prefer-const
      let filtersData = res.flat(1);
      // console.log('all filters of active sheet filtersData', filtersData)
      // filtersData = _.uniqBy(filtersData, '$1');
      // console.log('filtersData', filtersData)
      for (const filterElement of filtersData) {
        if (filterElement.getFieldName() === fieldName) {
          // console.log('filterElement.getFieldName()', filterElement.getFieldName())
          // console.log('equal to')
          // console.log('fieldName', fieldName)
          // console.log('filterElement.getWorksheet()', filterElement.getWorksheet())
          this.newSheetsForFilter.push(filterElement.getWorksheet());
        }
      }
      this.activeSheetsForFilter = this.newSheetsForFilter.length;
      // console.log('this.newSheetsForFilter', this.newSheetsForFilter)
      // this.newSheetsForFilter.forEach(sheeet => {
      //   console.log('sheeet', sheeet)
      //   from(sheeet.getFilterAsync()).subscribe(resss => {
      //     console.log('res single filter async', resss)

      //   })
      // })
      // console.log('this.newSheetsForFilter.length', this.newSheetsForFilter.length)

      if (this.newSheetsForFilter.length) {
        // this.newSheetsForFilter = _.uniqBy(this.newSheetsForFilter, '$5');
        this.applyFilterOnSheets(this.newSheetsForFilter, fieldName, filterValue, filterType, eventData);
      } else {
        this.dontCall = true;
        this.shouldListenFilterEvent = true;
        // console.log('MAKING FILTER LISTENER TRUE');
        this.shouldListenMarkEvent = true;
        // console.log()
      }
    });

  }

  getValidActiveSheetsForMark(activeSheets, fieldData, filterType, eventData) {
    this.newSheetsForFilter = [];
    const fields = [];
    for (const obj of fieldData) {
      fields.push(obj.fieldName);
    }
    // console.log('activeSheets', activeSheets)
    this.getFilterDataOfSpecificActiveSheet(activeSheets).subscribe((res: any) => {
      // console.log('res', res)
      // tslint:disable-next-line: prefer-const
      let filtersData = res.flat(1);
      // console.log('all filters of active sheet filtersData', filtersData)
      // filtersData = _.uniqBy(filtersData, '$1');
      // console.log('filtersData', filtersData)
      for (const filterElement of filtersData) {
        if (fields.includes(filterElement.getFieldName())) {
          // console.log('filterElement.getFieldName()', filterElement.getFieldName())
          // console.log('equal to')
          // console.log('fieldName', fieldName)
          // console.log('filterElement.getWorksheet()', filterElement.getWorksheet())
          this.newSheetsForFilter.push(filterElement.getWorksheet());
        }
      }
      this.activeSheetsForFilter = this.newSheetsForFilter.length;
      // console.log('this.newSheetsForFilter', this.newSheetsForFilter)
      // this.newSheetsForFilter.forEach(sheeet => {
      //   console.log('sheeet', sheeet)
      //   from(sheeet.getFilterAsync()).subscribe(resss => {
      //     console.log('res single filter async', resss)

      //   })
      // })
      // console.log('this.newSheetsForFilter.length', this.newSheetsForFilter.length)

      if (this.newSheetsForFilter.length) {
        // this.newSheetsForFilter = _.uniqBy(this.newSheetsForFilter, '$5');
        this.applyFilterOnSheetsForMarks(this.newSheetsForFilter, fieldData, filterType, eventData);
      } else {
        // console.log('MAKING FILTER LISTENER TRUE');
        this.shouldListenMarkEvent = true;
        // console.log()
      }
    });

  }


  /**
   * filter event handler, to apply selected filter on all instantiated vizzes
   */
  filterEventHandler(filterName: any, filterValue: any, eventData, filterType) {
    this.shouldListenFilterEvent = false;
    if (filterName && filterValue) {
      let vizzes = tableau.VizManager.getVizs();
      const emitterVizUrl = eventData.getViz().getUrl();
      vizzes = vizzes.filter(viz => viz.getUrl() !== emitterVizUrl);
      if (!this.shouldListenMarkEvent) {
      }
      const activeSheets =
        this.getSplicedActiveSheets(this.getAllActiveSheets(vizzes), eventData.getWorksheet().getName(), eventData.getViz().getUrl());
      // this.getAllActiveSheets(vizzes);
      // console.log('this.shouldListenMarkEvent', this.shouldListenMarkEvent)
      // console.log('this.shouldListenFilterEvent', this.shouldListenFilterEvent)
      // console.log('eventData.getWorksheet().getName', eventData.getWorksheet().getName());
      // console.log('eventData.getWorksheet().getUrl', eventData.getViz().getUrl());
      this.getValidActiveSheetsForFilter(activeSheets, filterName, filterValue, filterType, eventData);
    }
  }

  filterEventHandlerForMark(fieldData: any, eventData, filterType) {
    // console.log('calling filter for mark');

    this.shouldListenMarkEvent = false;
    if (fieldData.length) {
      let vizzes = tableau.VizManager.getVizs();
      const emitterVizUrl = eventData.getViz().getUrl();
      // vizzes = vizzes.filter(viz => viz.getUrl() !== emitterVizUrl);
      if (!this.shouldListenMarkEvent) {
      }
      const activeSheets =
        this.getSplicedActiveSheets(this.getAllActiveSheets(vizzes), eventData.getWorksheet().getName(), eventData.getViz().getUrl());
      // this.getAllActiveSheets(vizzes)
      // console.log('this.shouldListenMarkEvent', this.shouldListenMarkEvent)
      // console.log('this.shouldListenFilterEvent', this.shouldListenFilterEvent)
      // console.log('eventData.getWorksheet().getName', eventData.getWorksheet().getName());
      // console.log('eventData.getWorksheet().getUrl', eventData.getViz().getUrl());
      this.getValidActiveSheetsForMark(activeSheets, fieldData, filterType, eventData);
    }
  }

  getSplicedActiveSheets(activeSheets, sheetName, url) {
    const sheetsToReturn = [];
    for (const sheet of activeSheets) {
      const currentSheetUrl = sheet.getWorkbook().getViz().getUrl();
      const currentSheetName = sheet.getName();


      if (this.markSheetName === currentSheetName) {
        // console.log('sheet name is same but checking url is same or not');
        if (this.markSheetUrl === currentSheetUrl) {
          // console.log(' dont push, url is same')
        } else {
          // console.log('yes push sheet name is same but url is different');
          // console.log('url', url)
          // console.log('sheetName', sheetName)

          // console.log('currentSheetUrl', currentSheetUrl)
          // console.log('currentSheetName', currentSheetName)
          sheetsToReturn.push(sheet);
        }
      } else {
        // console.log('yes push sheet name is different');
        // console.log('url', url)
        // console.log('sheetName', sheetName)

        // console.log('currentSheetUrl', currentSheetUrl)
        // console.log('currentSheetName', currentSheetName)
        sheetsToReturn.push(sheet);
      }
    }

    return sheetsToReturn;
  }


  applyFilterOnSheetsForMarks(activeSheets: any, fieldData, filterType, eventData) {
    // console.log('activeSheets', activeSheets)
    const promises = [];
    let filterName: any = '';
    let filterValue: any = '';
    const prom = new Promise((resolve, reject) => {

      // console.log('activeSheets', activeSheets)
      // activeSheets = _.uniqBy(activeSheets, '$5');
      // tslint:disable-next-line: prefer-for-of
      for (let i = 0; i < activeSheets.length; i++) {
        const sheet = activeSheets[i];
        this.getFilterByActiveSheet(sheet).subscribe((sheetfilter: any) => {
          // console.log('sheetfilter', sheetfilter)
          const gotFilters = [];
          for (const singleFilter of sheetfilter) {
            // console.log('filterName', filterName)
            // console.log('filter', singleFilter.getFieldName());
            gotFilters.push(singleFilter.getFieldName());

          }

          // console.log('fieldData', fieldData)
          // console.log('gotFilters', JSON.stringify(gotFilters))

          for (const fdata of fieldData) {
            if (gotFilters.includes(fdata.fieldName)) {
              filterName = fdata.fieldName;
              filterValue = fdata.value;
              if (eventData.getEventName() === 'marksselection') {
                this.markSelectedFilterName.push(filterName);
              }
              try {
                if (filterType === 'categorical') {

                  // for (const activeSheet of activeSheets) {
                  try {
                    // console.log('applying these values')
                    // console.log('filterValue', filterValue)
                    // console.log('filterName', filterName)
                    // console.log('fdata applying', fdata)
                    // console.log('sheet', sheet)
                    const a = sheet.applyFilterAsync(filterName, filterValue, tableau.FilterUpdateType.REPLACE);
                    promises.push(a);
                  } catch (error) {
                    console.log('error', error);
                    // console.log(error);
                  }
                  // }
                }

              } catch (e) {
                console.log('filter cannot be applied, here is the error', e);
              }
            } else {
              // console.log('fdata not applying', fdata)

            }

          }

          //  else {
          // console.log('should not apply')
          // console.log('filterName', filterName)
          // console.log('gotFilters', gotFilters)
          // }
          // console.log('i', i)
          // console.log('activeSheets.length-1', activeSheets.length - 1)
          if ((activeSheets.length - 1) === i) {
            // console.log('resolving')
            resolve(promises);
          }
        });

      }
    });


    // console.log('promises', promises)
    // console.log('prom', prom)
    this.subscription = from(prom).pipe(
      catchError(err => { console.log('filter cannot be applied, here is the error', err); return throwError(err); }),
      concatAll(),
      toArray()
    )
      .subscribe(v => {
        // console.log('MAKING FILTER LISTENER TRUE');
        this.shouldListenMarkEvent = true;
        // this.dontCall = true;
        // console.log(v)
        // this.subscription.unsubscribe();
      }, error => {
        console.log('tableau error', error);
      });
  }

  /**
   * Apply selected filter on all active sheets
   */
  applyFilterOnSheets(activeSheets: any, filterName: any, filterValue, filterType, eventData) {
    const promises = [];
    const prom = new Promise((resolve, reject) => {
      this.shouldListenFilterEvent = false;
      for (let i = 0; i < activeSheets.length; i++) {
        const sheet = activeSheets[i];
        this.getFilterByActiveSheet(sheet).subscribe((sheetfilter: any) => {
          const gotFilters = [];
          for (const singleFilter of sheetfilter) {
            // console.log('filterName', filterName)
            // console.log('filter', singleFilter.getFieldName());
            gotFilters.push(singleFilter.getFieldName());

          }

          if (gotFilters.includes(filterName)) {
            // console.log('should apply')
            // console.log('filterName', filterName)
            // console.log('gotFilters', gotFilters)
            if (eventData.getEventName() === 'marksselection') {
              this.markSelectedFilterName.push(filterName);
            }
            try {
              if (filterType === 'categorical') {

                // for (const activeSheet of activeSheets) {
                try {
                  // console.log('applying these values')
                  // console.log('filterValue', filterValue)
                  // console.log('filterName', filterName)
                  const a = sheet.applyFilterAsync(filterName, filterValue, tableau.FilterUpdateType.REPLACE);
                  promises.push(a);
                } catch (error) {
                  console.log('error', error);
                  // console.log(error);
                }
                // }
              }

              // console.log('promises', promises)
              if (filterType === 'quantitative') {

                // for (const activeSheet of activeSheets) {
                promises.push(sheet.applyRangeFilterAsync(filterName, filterValue, tableau.FilterUpdateType.REPLACE));
                // }
              }

              if (filterType === 'relativedate') {

                // for (const activeSheet of activeSheets) {
                promises.push(sheet.applyRelativeDateFilterAsync(filterName, filterValue, tableau.FilterUpdateType.REPLACE));
                // }
              }


            } catch (e) {
              console.log('filter cannot be applied, here is the error', e);
            }

          } else {
            // console.log('should not apply')
            // console.log('filterName', filterName)
            // console.log('gotFilters', gotFilters)
          }
          if (activeSheets.length - 1 == i) {
            resolve(promises);
          }
        });
      }
    });
    // if (filterValue instanceof Array) { filterValue = Array.from(new Set(filterValue)); }
    // console.log('calling it so many times applyFilterOnSheets')
    // tslint:disable-next-line: deprecation
    // const markedObservable$ = combineLatest(
    //   activeSheets
    //     .map(activeSheet => {
    //       return from(activeSheet.applyFilterAsync(filterName, filterValue, tableau.FilterUpdateType.REPLACE));
    //     }));
    // console.log('markedObservable$', markedObservable$)
    // return markedObservable$.subscribe(res => {
    //   this.shouldListenFilterEvent = true;
    // }, error => { });

    // console.log('promises', promises)
    // console.log('prom', prom)
    this.subscription = from(prom).pipe(
      catchError(err => { console.log('filter cannot be applied, here is the error', err); return throwError(err); }),
      concatAll(),
      toArray()
    )
      .subscribe(v => {
        this.shouldListenFilterEvent = true;
        // console.log('MAKING FILTER LISTENER TRUE');
        this.shouldListenMarkEvent = true;
        this.dontCall = true;
        // console.log(v)
        // this.subscription.unsubscribe();
      }, error => {
        console.log('tableau error', error);
      });

  }

  /**
   * Get all active sheets [active sheets array] from all the instantiated vizzes
   */
  getAllActiveSheets(vizzes: any) {
    const activeSheets = [];
    for (const viz of vizzes) {
      if (viz && viz !== null) {
        // console.log('viz', viz)
        // console.log('viz', viz.getWorkbook());
        let activeSheet: any;
        try {
          activeSheet = viz && viz.getWorkbook() && viz.getWorkbook().getActiveSheet();
        } catch (e) {
          console.log('error in getviz', e)

        }
        if (activeSheet) {
          switch (activeSheet.getSheetType()) {
            case 'worksheet':
              activeSheets.push(activeSheet);
              break;
            case 'dashboard':
              // console.log('-----------------------------------------')
              // console.log('activeSheet', activeSheet)
              // console.log('this is dashboard-----------', activeSheet.getObjects())
              for (const obj of activeSheet.getObjects()) {
                // console.log('obj.getObjectType()', obj.getObjectType())
                if (obj.getObjectType() === 'quickFilter') {
                  // console.log('obj', obj)

                }
              }
              // console.log('-----------------------------------------')
              for (const sheet of activeSheet.getWorksheets()) {
                activeSheets.push(sheet);
              }
              break;
            case 'story':
              // console.log('there is a story');
              break;
          }
        }
      }
    }
    return activeSheets;
  }

  /**
   * clear the filters from active sheets
   */
  clearAllFilters(selectedFilter) {
    // console.log('selectedFilter', selectedFilter);
    const vizzes = tableau.VizManager.getVizs();
    const activeSheets = this.getAllActiveSheets(vizzes);
    // console.log('activeSheets', activeSheets)
    const promises = [];
    const prom = new Promise((resolve, reject) => {

      for (let i = 0; i < activeSheets.length; i++) {
        // console.log('activeSheet.getSheetType()', activeSheet.getSheetType());
        // activeSheet.clearFilterAsync(selectedFilter);
        const activeSheet = activeSheets[i];
        this.getFilterByActiveSheet(activeSheet).subscribe((sheetfilter: any) => {
          const gotFilters = [];
          for (const singleFilter of sheetfilter) {
            // console.log('filterName', filterName)
            // console.log('filter', singleFilter.getFieldName());
            gotFilters.push(singleFilter.getFieldName());

          }

          if (gotFilters.includes(selectedFilter)) {

            promises.push(activeSheet.applyFilterAsync(selectedFilter, '', tableau.FilterUpdateType.ALL));
          }
        });        // if (activeSheet.getSheetType() === 'dashboard') {
        //   activeSheet.getWorksheets().forEach((sheet) => {
        //     sheet.clearFilterAsync(selectedFilter);
        //   });
        // }

        // if (activeSheet.getSheetType() === 'worksheet') {
        // }
        if (activeSheets.length - 1 === i) {
          resolve(promises);
        }
      }
    });
    // console.log('promises', promises)
    // console.log('prom', prom)
    this.subscription = from(prom).pipe(
      concatAll(),
      toArray()
    )
      .subscribe(v => {
        this.shouldListenMarkEvent = true;
        this.shouldListenFilterEvent = true;
        // console.log('MAKING FILTER LISTENER TRUE');
        // console.log(v)
        // this.subscription.unsubscribe();
      });
  }

  /**
   * Start listening parameter event on all active sheets(instantiated vizzes)
   */
  startParameterListener() {
    this.startUrlListener();
    this.allMarkVizs$ = [];
    const vizzes = tableau.VizManager.getVizs();
    const vizObservables = vizzes.map(viz => fromEvent(viz, 'parametervaluechange'));
    this.allMarkVizs$ = vizObservables
      .map(viz =>
        viz.pipe(
          // filter(data => this.shouldListenMarkEvent === true)
        ).subscribe(eventData => {
          // console.log('eventData', eventData)
        }));
  }

  /**
   * Start listening URL event on all active sheets(instantiated vizzes)
   */
  startUrlListener() {
    this.allMarkVizs$ = [];
    const vizzes = tableau.VizManager.getVizs();
    const vizObservables = vizzes.map(viz => fromEvent(viz, 'urlaction'));
    this.allMarkVizs$ = vizObservables
      .map(viz =>
        viz.pipe(
          // filter(data => this.shouldListenMarkEvent === true)
        ).subscribe(eventData => {
          // console.log('eventData', eventData)
        }));
  }
}
