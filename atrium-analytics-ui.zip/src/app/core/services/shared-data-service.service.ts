import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedDataServiceService {
  filterCategoryData: any = {
    allCategories: [],
    filterTags: [],
    libraryCards: [],
    libraryCardsProducts: [],
    postVizObj: [],
    vizDetails: [],
    productDetails: [],
    vizButtonDisabled: null,
    productButtonDisabled: null,
    previousUrl: '',
    searchKey: null,
    filterVizTag: true,
    filterProductTag: true,
    value1: null,
    value2: null,

  }; // library page
  sharedUrl: any = {
    previousUrl: null,
  };

  // product creation- step five data
  backupDashboard: any;
  backupKpiCategory: any;
  currentPage: any = 0;
  // terms and condition link
  termsAndCondition = '';
  constructor() { }
}
