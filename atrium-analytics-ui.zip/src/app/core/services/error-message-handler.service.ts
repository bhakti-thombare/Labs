import { Injectable } from '@angular/core';
import { errorMessage } from '../error-handler/error-messages';

enum controllers {
  user
}
@Injectable({
  providedIn: 'root'
})
export class ErrorMessageHandlerService {
  errorMessages = errorMessage;
  constructor() { }

  // urls having specific message for 400 or 500 and not generic message,
  exceptionUrls = ['/v2/api/user/confirm-forgot-password', '/v2/api/user/forgot-password'];

  getMessageFromError(errorObject, requestUrl?) {
    // console.log('errorObject', errorObject);
    const url = errorObject.url;
    const httpStatus = errorObject.status;
    let keyword = '';

    let skipUrl = false;
    this.exceptionUrls.forEach((exUrl) => {
      if (url.includes(exUrl)) {
        skipUrl = true;
        keyword = this.getMessage(url, httpStatus);
      } else {
        skipUrl = false;
      }
    });
    if (!skipUrl) {
      if (httpStatus !== 400 && httpStatus !== 500 && httpStatus !== 0 && httpStatus !== -1) {
        keyword = this.getMessage(url, httpStatus);
      } else {
        let text = httpStatus === 500 ? 'ServerError' : 'ClientError';
        if (httpStatus === 500) {
          text = 'ServerError';
        } else if (httpStatus === 400) {
          text = 'ClientError';
        } else if (httpStatus === 0) {
          text = 'ServerDown';
        }
        keyword = 'General.' + text;
      }
    }
    // console.log('keyword last', keyword)
    return keyword;
  }

  getMessage(url, httpStatus) {
    let breakIt = false;
    let keyword = '';
    // iterate over error-code-message array
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < this.errorMessages.length; i++) {
      // check url matches or not
      const urlArr = url.split('/');
      let num = 0;
      // console.log('urlArr[urlArr.length - 1]',typeof urlArr[urlArr.length - 1])
      if (!isNaN(urlArr[urlArr.length - 1])) {
        num = urlArr[urlArr.length - 1];
        // console.log('urlArr[urlArr.length - 1]', urlArr[urlArr.length - 1])
        this.errorMessages[i].url = this.errorMessages[i].url + '/' + num;
      }
      if (url.includes(this.errorMessages[i].url)) {
        // console.log('url', url)
        // console.log('this.errorMessages[i].url', this.errorMessages[i].url)
        // iterate over error code-messages for matched url
        // console.log('this.errorMessages[i]', this.errorMessages[i]);
        // tslint:disable-next-line: prefer-for-of
        for (let j = 0; j < this.errorMessages[i].messages.length; j++) {
          // console.log('this.errorMessages[i].messages[j])[0]', Object.keys(this.errorMessages[i].messages[j]))
          // console.log('httpStatus.toString()', httpStatus.toString())
          const messageKeys = Object.keys(this.errorMessages[i].messages[j]);
          // console.log('messageKeys', messageKeys)
          // tslint:disable-next-line: prefer-for-of
          for (let k = 0; k < messageKeys.length; k++) {
            // console.log('messageKeys[k]', messageKeys[k] + ' === ' + httpStatus.toString());
            if (messageKeys[k] === httpStatus.toString()) {
              keyword = this.errorMessages[i].controller + '.' + this.errorMessages[i].messages[j][httpStatus.toString()];
              // console.log('keyword', keyword)
              if (keyword) {
                breakIt = true;
              }
              break;
            }
          }
          if (breakIt) {
            break;
          }
        }
        break;
      }
    }
    return keyword;
  }
}
