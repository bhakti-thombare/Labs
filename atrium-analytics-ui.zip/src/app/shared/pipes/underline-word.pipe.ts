import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';


@Pipe({
  name: 'underlineWord',
  pure: true
})
export class UnderlineWordPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) { }

  transform(value: any, wordNumber: any[]): any {
    if (value) {
      const wordsArray = value.split(' ');
      const selectedWord: any = wordNumber.map(numb => wordsArray[numb - 1]);
      const underlinedSentence = selectedWord.join(' ');
      const newText = '<span class="blue-underline">' + underlinedSentence.trim() + '</span>';
      return value.replace(underlinedSentence.trim(), newText);
    }
  }

  underlineEachWordSeparately(value, wordNumber) {
    const wordsArray = value.split(' ');
    const selectedWords = [];
    const mapObj = {};
    wordNumber.forEach((position: any) => {
      // console.log('position', position);
      // selectedWords.push(wordsArray[position + 1]);
      // console.log('wordsArray[position + 1]', wordsArray[position - 1]);
      mapObj[wordsArray[position - 1]] = '<span class="blue-underline">' + wordsArray[position - 1] + '</span>';
    });

    // console.log('mapObj', mapObj);
    const re = new RegExp(Object.keys(mapObj).join('|'), 'g');
    const newText = value.replace(re, (matched) => {
      return mapObj[matched];
    });
    // console.log('newText', newText);
    // const newText = value.replace(selectedWord,
    // this.sanitizer.bypassSecurityTrustHtml('<span class="blue-underline">' + selectedWord + '</span>'));
    return newText;
  }

}
