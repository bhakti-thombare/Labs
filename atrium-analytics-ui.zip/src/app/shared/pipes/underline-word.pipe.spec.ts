import { UnderlineWordPipe } from './underline-word.pipe';

describe('UnderlineWordPipe', () => {
  it('create an instance', () => {
    const pipe = new UnderlineWordPipe();
    expect(pipe).toBeTruthy();
  });
});
