import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { RouterModule } from '@angular/router';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { AvatarModule } from 'ngx-avatar';
import { AuthModule } from '../auth/auth.module';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { UnderlineWordPipe } from './pipes/underline-word.pipe';
import { LoaderComponent } from './components/loader/loader.component';
import { PageUnderdevelopmentComponent } from './components/page-underdevelopment/page-underdevelopment.component';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { NgSelectModule } from '@ng-select/ng-select';
import { GenericConfirmComponent } from './components/generic-confirm/generic-confirm.component';
import { PaginationComponent } from './pagination/pagination.component';
import { UiElementsComponent } from './example/ui-elements/ui-elements.component';
import { SafeContentPipe } from './pipes/safe-content.pipe';
import { WarningPopupComponent } from './components/warning-popup/warning-popup.component';


export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [HeaderComponent,
    FooterComponent,
    UnderlineWordPipe,
    LoaderComponent,
    GenericConfirmComponent,
    PageUnderdevelopmentComponent,
    PaginationComponent,
    UiElementsComponent,
    SafeContentPipe,
    WarningPopupComponent],
  imports: [
    RouterModule,
    // AvatarModule,
    NgSelectModule,
    CommonModule,
    AuthModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      },
      isolate: false
    }),
    ModalModule.forRoot(),
    // BrowserAnimationsModule,
    BsDropdownModule.forRoot()
  ],
  exports: [
    TranslateModule,
    GenericConfirmComponent,
    HeaderComponent,
    FooterComponent,
    UnderlineWordPipe,
    SafeContentPipe,
    LoaderComponent,
    PaginationComponent,
    PageUnderdevelopmentComponent],
  providers: [UnderlineWordPipe]
})
export class SharedModule { }
