import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { range } from 'lodash';

@Component({
  selector: 'ab-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements OnInit, OnChanges {

  @Input() pageSize = 1;
  @Input() total = 1;
  @Input() range = 3;
  @Input() delta = 3;
  @Input() currentPage: number;
  @Output() pageChange: EventEmitter<{ page: number }> = new EventEmitter<{ page: number }>();
  @Output() totalPagesCount: EventEmitter<number> = new EventEmitter<number>();

  // pages: Observable<number[]>;
  pages: any;
  totalPages: number;

  get offset(): number {
    return this.currentPage * this.pageSize;
  }

  constructor() { }

  ngOnInit() {
    this.getPages(this.offset, this.pageSize, this.total);
    this.totalPagesCount.emit(this.totalPages);
  }

  ngOnChanges() {
    this.getPages(this.offset, this.pageSize, this.total);
    this.totalPagesCount.emit(this.totalPages);
  }

  getPages(offset: number, pageSize: number, total: number) {
    this.totalPages = this.getTotalPages(pageSize, total);
    this.pages = this.pagination(this.currentPage, this.totalPages, this.delta);
  }

  isValidPageNumber(page: any, totalPages: number): boolean {
    return page > 0 && page <= totalPages;
  }

  getCurrentPage(offset: number, limit: number): number {
    return Math.floor(offset / limit) + 1;
  }

  getTotalPages(pageSzie: number, total: number): number {
    return Math.ceil(Math.max(total, 1) / Math.max(pageSzie, 1));
  }

  selectPage(page: number, event) {
    this.cancelEvent(event);
    if (this.isValidPageNumber(page, this.totalPages)) {
      // console.log('page', page);
      // console.log('this.totalPages', this.totalPages);
      this.pages = this.pagination(page, this.totalPages, this.delta);
      this.currentPage = page;
      this.pageChange.emit({ page: this.currentPage });
    }
  }

  cancelEvent(event) {
    event.preventDefault();
  }

  getRange(start, end) {
    return Array(end - start + 1).fill(0).map((v, i) => i + start);
  }

  pagination(current, length, delta = 2) {
    const ranges = {
      start: Math.round(current - delta / 2),
      end: Math.round(current + delta / 2)
    };
    if (length === 1) {
      return [1];
    }

    if (ranges.start - 1 === 1 || ranges.end + 1 === length) {
      ranges.start += 1;
      ranges.end += 1;
    }

    let pages = current > delta ? this.getRange(
      Math.min(ranges.start, length - delta),
      Math.min(ranges.end, length)
    ) : this.getRange(1, Math.min(length, delta + 1));

    const withDots = (value, pair) => pages.length + 1 !== length ? pair : [value];

    if (pages[0] !== 1) {
      pages = withDots(1, [1, '...']).concat(pages);
    }

    if (pages[pages.length - 1] < length) {
      pages = pages.concat(withDots(length, ['...', length]));
    }

    return pages;
  }

}
