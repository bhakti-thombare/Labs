import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ab-ui-elements',
  templateUrl: './ui-elements.component.html',
  styleUrls: ['./ui-elements.component.scss']
})
export class UiElementsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
