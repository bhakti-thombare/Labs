import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageUnderdevelopmentComponent } from './page-underdevelopment.component';

describe('PageUnderdevelopmentComponent', () => {
  let component: PageUnderdevelopmentComponent;
  let fixture: ComponentFixture<PageUnderdevelopmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageUnderdevelopmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageUnderdevelopmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
