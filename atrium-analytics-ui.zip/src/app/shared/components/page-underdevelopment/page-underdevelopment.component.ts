import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'ab-page-underdevelopment',
  templateUrl: './page-underdevelopment.component.html',
  styleUrls: ['./page-underdevelopment.component.scss']
})
export class PageUnderdevelopmentComponent implements OnInit {
  currentRoute: string;

  constructor(private router: Router) { }

  ngOnInit() {
    this.currentRoute = this.router.url;
  }

}
