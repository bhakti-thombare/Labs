import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { SharedDataServiceService } from 'src/app/core/services/shared-data-service.service';

@Component({
  selector: 'ab-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  contact: any = {
    id: 1,
    enAddress: '',
    frAddress: '',
    nlAddress: '',
    phone: '',
    facebookLink: '',
    instagramLink: '',
    twitterLink: '',
    linkedLink: ''
  };
  selectedLanguage: string;
  TermsAndConditionsLink: string;
  twitterLink = '';
  linkedInLink = '';
  facebookLink = '';
  instagramLink = '';

  constructor(
    private dataSharingService: SharedDataServiceService,
    private restService: RestService, private translate: TranslateService) { }

  ngOnInit() {
    this.selectedLanguage = localStorage.getItem('language') || 'fr';
    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.selectedLanguage = event.lang;
    });
    this.getLandingData();
  }

  openTermsAndConditions() {
    this.translate.currentLang == 'en'? this.TermsAndConditionsLink = 'https://hub.brussels/en/privacy-policy/' : this.translate.currentLang == 'fr'? this.TermsAndConditionsLink = 'https://hub.brussels/fr/politique-de-confidentialite/' : this.TermsAndConditionsLink = 'https://hub.brussels/nl/privacybeleid/';
    window.open(this.TermsAndConditionsLink);
  }

  getLandingData() {
    this.restService.fetch(`${environment.apiUrl}/v2/api/landing`, undefined, true).subscribe((landingData = '') => {
      this.contact = landingData.value.contact;
      // console.log('this.contact', this.contact)
      // this.TermsAndConditionsLink = this.contact.termsAndConditionsUrl;
      this.translate.currentLang == 'en'? this.TermsAndConditionsLink = 'https://hub.brussels/en/privacy-policy/' : this.translate.currentLang == 'fr'? this.TermsAndConditionsLink = 'https://hub.brussels/fr/politique-de-confidentialite/' : this.TermsAndConditionsLink = 'https://hub.brussels/nl/privacybeleid/';
      this.dataSharingService.termsAndCondition = this.TermsAndConditionsLink;
      if ((this.contact.facebookLink.includes('https') || this.contact.facebookLink.includes('http')) &&
        this.contact.facebookLink.includes('facebook.com')) {
        this.facebookLink = this.contact.facebookLink;
      }
      if ((this.contact.instagramLink.includes('https') || this.contact.instagramLink.includes('http')) &&
        this.contact.instagramLink.includes('instagram.com')) {
        this.instagramLink = this.contact.instagramLink;
      }
      if ((this.contact.twitterLink.includes('https') || this.contact.twitterLink.includes('http')) &&
        this.contact.twitterLink.includes('twitter.com')) {
        this.twitterLink = this.contact.twitterLink;
      }
      if ((this.contact.linkedLink.includes('https') || this.contact.linkedLink.includes('http')) &&
        this.contact.linkedLink.includes('linkedin.com')) {
        this.linkedInLink = this.contact.linkedLink;
      }
    });
  }

  openLink(value) {
    // console.log('value', value)
    switch (value) {
      case 'facebook':
        if (this.facebookLink) { window.open(this.facebookLink); }
        break;
      case 'twitter':
        if (this.twitterLink) { window.open(this.twitterLink); }
        break;
      case 'linkedin':
        if (this.linkedInLink) { window.open(this.linkedInLink); }
        break;
      case 'instagram':
        if (this.instagramLink) { window.open(this.instagramLink); }
        break;
    }
  }

}
