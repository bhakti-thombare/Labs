import { Component, OnInit, TemplateRef, AfterViewInit } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { NotificationService } from 'src/app/core/services/notification.service';
import { BehaviorSubject } from 'rxjs';
import { UtilityService } from 'src/app/core/services/utility.service';
declare var JSEncrypt: any;

@Component({
  selector: 'ab-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, AfterViewInit {

  menu = [
    { title: 'Home', url: '/' },
    { title: 'Library', url: '/library' },
    { title: 'OpenData', url: '/open-data' },
    { title: 'Guide', url: '/guide/product' },
    { title: 'AboutUs', url: '/about-us' }];
  modalRef: BsModalRef;
  selectedLanguage: string;
  currentUser: any;
  showQuestionMark = false;
  encrypt: any;
  activeTab = 0;
  constructor(
    private utilityService: UtilityService,
    private modalService: BsModalService,
    private notificationService: NotificationService,
    private authService: AuthService,
    private router: Router,
    private translate: TranslateService) {
    this.loadUser();
    router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
      // console.log(this.router.url);
      if (this.router.url.includes('/library') && !this.router.url.includes('/library/viz-details')) {
        if (this.currentUser && (this.currentUser.role === 'champion' || this.currentUser.role === 'admin')) {
          this.showQuestionMark = false;
        } else {
          this.showQuestionMark = true;
        }
        // console.log('this.showQuestionMark', this.showQuestionMark);
      } else {
        this.showQuestionMark = false;
        // console.log('this.showQuestionMark', this.showQuestionMark);
      }

      if (this.router.url === '/user/dashboard') {
        if (this.currentUser && (this.currentUser.role.includes('hubster') || this.currentUser.role.includes('subscriber'))) {
          this.showQuestionMark = true;
        } else {
          this.showQuestionMark = false;
        }
        // console.log('this.showQuestionMark', this.showQuestionMark);
      }

    });
  }

  ngOnInit() {

    if (this.router.url.includes('/library') && !this.router.url.includes('/library/viz-details')) {
      if (this.currentUser && (this.currentUser.role === 'champion' || this.currentUser.role === 'admin')) {
        this.showQuestionMark = false;
      } else {
        this.showQuestionMark = true;
      }
    } else {
      this.showQuestionMark = false;
    }

    if (this.router.url === '/user/dashboard') {
      if (this.currentUser && (this.currentUser.role.includes('hubster') || this.currentUser.role.includes('subscriber'))) {
        this.showQuestionMark = true;
      } else {
        this.showQuestionMark = false;
      }
      // console.log('this.showQuestionMark', this.showQuestionMark);
    }
    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      // console.log('event', event);
      this.selectedLanguage = event.lang;
    });
    this.selectedLanguage = localStorage.getItem('language');
    // if (this.selectedLanguage) {
    //   this.translate.use(this.selectedLanguage);
    // } else {
    //   this.translate.use('fr');
    // }
  }

  ngAfterViewInit() {
    if (this.router.url.includes('/library') && !this.router.url.includes('/library/viz-details')) {
      if (this.currentUser && (this.currentUser.role === 'champion' || this.currentUser.role === 'admin')) {
        this.showQuestionMark = false;
      } else {
        this.showQuestionMark = true;
      }
    } else {
      this.showQuestionMark = false;
    }

    if (this.router.url === '/user/dashboard') {
      if (this.currentUser && (this.currentUser.role.includes('hubster') || this.currentUser.role.includes('subscriber'))) {
        this.showQuestionMark = true;
      } else {
        this.showQuestionMark = false;
      }
      // console.log('this.showQuestionMark', this.showQuestionMark);
    }
  }

  loadUser() {
    this.authService.currentUser$.subscribe((user: any) => {
      this.currentUser = user;

      if (this.router.url.includes('/library') && !this.router.url.includes('/library/viz-details')) {
        if (this.currentUser && (this.currentUser.role === 'champion' || this.currentUser.role === 'admin')) {
          this.showQuestionMark = false;
        } else {
          this.showQuestionMark = true;
        }
      } else {
        this.showQuestionMark = false;
      }

      if (this.router.url === '/user/dashboard') {
        if (this.currentUser && (this.currentUser.role.includes('hubster') || this.currentUser.role.includes('subscriber'))) {
          this.showQuestionMark = true;
        } else {
          this.showQuestionMark = false;
        }
        // console.log('this.showQuestionMark', this.showQuestionMark);
      }
    });
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {
      animated: true,
      backdrop: 'static',
      keyboard: false,
      class: 'custom-width'
    });
  }


  onOptionClick(title: any, template: any) {
    if (title === 'SignIn') {
      this.openModal(template);
    }
  }

  closeModal() {
    this.modalRef.hide();
  }

  getInitials() {
    if (this.currentUser) { return this.currentUser.firstName[0] + this.currentUser.lastName[0]; }
  }

  switchLanguage(lang: string) {
    this.selectedLanguage = lang;
    localStorage.setItem('language', lang);
    this.translate.use(lang);
  }

  logout() {
    this.encrypt = new JSEncrypt();
    this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
    const userName = this.encrypt.encrypt(this.currentUser.rawEmail);
    this.authService.logout(userName).subscribe(() => {
      window.location.href = '/';
    });
  }
  showNotification() {
    this.notificationService.showInfo('Feature Under Developement');
  }

  startTutorial() {
    this.utilityService.startTour.next(true);
  }
}
