import { Component, OnInit, Renderer2, ChangeDetectorRef, AfterViewInit, AfterViewChecked } from '@angular/core';
import { LoaderService } from 'src/app/core/services/loader.service';
import { delay } from 'rxjs/operators';

@Component({
  selector: 'ab-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit {

  loading = false;
  loaderSubMessage: string[];
  constructor(private cdRef: ChangeDetectorRef, private loaderService: LoaderService, private renderer: Renderer2) {
    this.loaderService.isLoading.pipe(
      delay(1)
    ).subscribe((v) => {
      // console.log(v);
      if (v === true) {
        renderer.setStyle(document.body, 'overflow', 'hidden');
      } else {
        renderer.setStyle(document.body, 'overflow', 'unset');
      }
      this.loading = v;
      this.cdRef.markForCheck();
    });
  }
  ngOnInit() {

    this.loadSubMessage();
  }

  loadSubMessage() {
    let counter = 0;
    let a = 0;
    a = 6000;
    let text = [];
    setInterval(() => {
      // console.log('setInterval');

      if (localStorage.getItem('langauge') === 'en') {
        text = ['In Brussels, nearly one in five businesses is in the Pentagon',
          'There are 3x more chocolatiers than fishmongers in Brussels',
          'Every year, brusselers spend as much money on clothes & shoes as on meat & fish',
          'Whatever the day of the week, there is an open public market in Brussels',
          'The peak of visits in Rue Neuve is at the end of the afternoon'];
      } else if (localStorage.getItem('langauge') === 'fr') {
        text = ['À Bruxelles, près d’une entreprise sur cinq se situe dans le Pentagone',
          ' Il y a trois fois plus de chocolatiers que de poissonneries à Bruxelles',
          ' Chaque année, les Bruxellois dépensent autant d’argent en vêtements et chaussures qu’en viande et poisson',
          ' Quel que soit le jour de la semaine, il y a toujours un marché à ciel ouvert à Bruxelles',
          ' Le pic de fréquentation à la rue Neuve a lieu en fin d’après-midi'];
      } else if (localStorage.getItem('langauge') === 'nl') {
        text = ['In Brussel ligt bijna één op de vijf ondernemingen in de Vijfhoek',
          'Brussel telt 3x meer chocolatiers dan vishandelaars ',
          'Jaarlijks besteden Brusselaars evenveel geld aan kleding en schoenen als aan vlees en vis, ongeacht de dag van de week',
          'Brussel heeft een openbare markt',
          'Aan het einde van de namiddag piekt het aantal bezoekers in de Nieuwstraat'];
      } else {
        text = ['In Brussels, nearly one in five businesses is in the Pentagon',
          'There are 3x more chocolatiers than fishmongers in Brussels',
          'Every year, brusselers spend as much money on clothes & shoes as on meat & fish',
          'Whatever the day of the week, there is an open public market in Brussels',
          'The peak of visits in Rue Neuve is at the end of the afternoon'];
      }
      this.loaderSubMessage = text[counter];
      counter++;
      if (counter >= text.length) {
        counter = 0;
      }
    }, a);

  }

}
