import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { filter } from 'rxjs/operators';
import { RestService } from './core/services/rest.service';
import { environment } from 'src/environments/environment';
import { Cookie } from './core/services/cookie';
import { trigger, transition, style, animate } from '@angular/animations';
import { AuthService } from './core/services/auth.service';
import { UtilityService } from './core/services/utility.service';
import { Location } from '@angular/common';
import { FooterComponent } from './shared/components/footer/footer.component';
import { WarningPopupComponent } from './shared/components/warning-popup/warning-popup.component';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
// import { GuidedTourService, GuidedTour, TourStep, Orientation } from 'ngx-guided-tour';

@Component({
  selector: 'ab-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  animations: [
    trigger('fadeInOut', [
      transition(':enter', [   // :enter is alias to 'void => *'
        style({ opacity: 0 }),
        animate(500, style({ opacity: 1 }))
      ]),
      transition(':leave', [   // :leave is alias to '* => void'
        animate(500, style({ opacity: 0 }))
      ])
    ])]
})
export class AppComponent implements OnInit {
  title = 'analytics-brussels';
  params: any;
  languages = ['en', 'nl', 'fr'];
  showLayout = true;
  showFooter = true;
  publicKey: any;
  showCookieBanner = true;
  currentUser: any;
  @ViewChild(FooterComponent, { static: false }) footerComponent: FooterComponent;
  showProgress: boolean = true;
  bsModalRef?: BsModalRef;
  // guidedTour: GuidedTour;
  constructor(
    private location: Location,
    private translate: TranslateService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private restService: RestService,
    private authService: AuthService,
    private modalService: BsModalService
    // private guidedTourService: GuidedTourService
  ) {
      this.router.events.subscribe(event => {
       if (event instanceof NavigationEnd) {
         (<any>window).ga('set', 'page', event.urlAfterRedirects);
         (<any>window).ga('send', 'pageview');
       }
     });
    translate.addLangs(this.languages);
    translate.setDefaultLang('fr');
    this.authService.currentUser$.subscribe(user => {
      // console.log('user', user);
      if (user) {
        this.currentUser = user;
        // this.getPlatformLanguage();
      }
    });
    // this.getPlatformLanguage();

    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
      // console.log('this.router.url.includes(\'langauge\')', this.router.url.toString().includes('language'));
      if (this.router.url === '/about-us' ||
        this.router.url === '/' ||
        this.router.url.includes('/?language=') ||
        this.router.url.includes('?email=') ||
        this.router.url === '/resend-verification-link' ||
        this.router.url === '/create-profile') {
        this.showLayout = false;
        if ((this.router.url === '/create-profile' ||
          this.router.url.includes('?email=') ||
          this.router.url === '/resend-verification-link')) {
          // console.log('here1');
          this.showFooter = false;
        } else {
          // console.log('here2');
          this.showFooter = true;
        }
      }
      else {
        // console.log('here3');
        this.showLayout = true;
      }
    });
    // this.getPlatformLanguage();
  }

  ngOnInit() {
    console.log('%c Stop!', 'color: red; font-weight: bold; font-size:36px');
    console.log('%c This area is meant for developers, do not paste anything here.', 'color: red; font-weight: bold; font-size:24px');
    // console.log('this.router.url', this.location.path())

      this.activatedRoute.queryParams.subscribe(params => {
        // console.log('params', params)
        if (params && params.language) {
          // console.log('params', params)
          // console.log('params.language.toLowerCase()', params.language.toLowerCase())
          localStorage.setItem('language', params.language.toLowerCase());
          // this.translate.use(params.language.toLowerCase());
          this.getPlatformLanguage(params.language && params.language.toLowerCase() || undefined);
        }
      });
      if (Cookie.get('visited') && Cookie.get('visited') === 'yes') {
        this.showCookieBanner = false;
      } else {
        // this.setCookieForVisitor();
      }
      this.getPublicKey();
      // console.log('this.location.path().toString()', this.location.path().toString()[this.location.path().toString().length - 1])
      // console.log('this.location.path().includes(\'/?language=\')', this.location.path().toString().includes('?language='))
      if (!(this.location.path().includes('?language='))) {
        // console.log('this.router.url', this.location.path())
        // console.log('language')
        this.getPlatformLanguage();
      }

      this.openSmallScreenWarningPopUp();
  }

  // Open Pop-Up for mobile/tablet warning
  openSmallScreenWarningPopUp() {
    if(window.innerWidth < 1025)
      this.bsModalRef = this.modalService.show(WarningPopupComponent, Object.assign({}, { class: 'warning-modal' }));
    }
  // }


  getPublicKey() {
    this.restService.fetch(environment.apiUrl + '/v2/api/user/encrypt', { loader: true }, true).subscribe(res => {
      this.publicKey = res.value.publicKey;
      localStorage.setItem('publicKey', this.publicKey);
      // this.privateKey = res.value.privateKey;
    });
    this.repeatThings();
  }


  repeatThings() {
    setInterval(() => {
      this.getPublicKey();
    }, 30 * 60 * 1000);
  }

  setCookieForVisitor() {
    if (!Cookie.get('visited')) {
      Cookie.set('visited',
        'yes',
        new Date(new Date().setFullYear(new Date().getFullYear() + 10)),
        '/',
        Cookie.get('_host'));

    }
  }

  onCookieBannerAction(value) {
    if (value === 'openPrivacyPolicy') {
      if (this.footerComponent) {
        this.footerComponent.openTermsAndConditions();
      }
    } else if (value === 'accept') {
      this.showCookieBanner = false;
      this.setCookieForVisitor();
    }
  }

  getPlatformLanguage(lang?: any) {
    // console.log(
    // 'this.activatedRoute.snapshot.queryParams.language.toLowerCase()', this.activatedRoute.snapshot.queryParamMap.get('language'))
    // if (this.activatedRoute.snapshot.queryParams.language) {
    //   lang = this.activatedRoute.snapshot.queryParams.language.toLowerCase();
    // }
    // console.log('lang', lang)
    // this.translate.use(lang && lang.toString());

    if (!lang) {
      let localLanguage = '';
      if (this.currentUser) {
        localLanguage = this.currentUser.language;
        localStorage.setItem('language', localLanguage);
      } else {
        localLanguage = this.translate.getBrowserLang();
      }
      // console.log('localLanguage', localLanguage);
      if (!localStorage.getItem('language')) {
        if (this.languages.includes(localLanguage.toString())) {
          localStorage.setItem('language', localLanguage);
          // console.log('localLanguage', localLanguage)
          this.translate.use(localLanguage);
        } else {
          localStorage.setItem('language', 'fr');
          this.translate.use('fr');
        }
      } else {
        this.translate.use(localStorage.getItem('language'));
      }
    } else {
      // console.log('setting the lang', lang)
      this.translate.use(lang.toString());
      // window.location.reload();
    }
  }

  // startTours() {
  //   const tourSteps: TourStep[] = [
  //     {
  //       selector: '.step-one',
  //       content: 'step 1',
  //       orientation: Orientation.Left,
  //       skipStep: true,
  //     },
  //     {
  //       selector: '.step-two',
  //       content: 'step 2',
  //       orientation: Orientation.Top,
  //       skipStep: true,
  //     },
  //     // {
  //     //   selector: '.step-three',
  //     //   content: 'step 3',
  //     //   orientation: 'left',
  //     //   skipStep: true,
  //     // },
  //     // {
  //     //   selector: '.step-four',
  //     //   content: 'step 4',
  //     //   orientation: 'left',
  //     //   skipStep: true,
  //     // },
  //     // { selector:'.step-one',
  //     //   content: 'step 5',
  //     //   orientation: 'left',
  //     //   skipStep: true,
  //     // },
  //     // { selector:'.step-one',
  //     //   content: 'step 6',
  //     //   orientation: 'left',
  //     //   skipStep: true,
  //     // },
  //     // { selector:'.step-one',
  //     //   content: 'step 7',
  //     //   orientation: 'left',
  //     //   skipStep: true,
  //     // }
  //   ];
  //   this.guidedTour = {
  //     /** Identifier for tour */
  //     tourId: 'library-dashboard',
  //     /** Use orb to start tour */
  //     useOrb: true,
  //     /** Steps fo the tour */
  //     steps: tourSteps,
  //     /** Function will be called when tour is skipped */
  //     // skipCallback?: (stepSkippedOn: number) => void;
  //     /** Function will be called when tour is completed */
  //     // completeCallback?: () => void;
  //     /** Minimum size of screen in pixels before the tour is run, if
  //          the tour is resized below this value the user will be told to resize */
  //     minimumScreenSize: 800,

  //     /**
  //      * Prevents the tour from advancing by clicking the backdrop.
  //      * This should only be set if you are completely sure your
  //      * tour is displaying correctly on all screen sizes otherwise a user can get stuck.
  //      */
  //     preventBackdropFromAdvancing: false,
  //   }
  //   this.guidedTourService.startTour(this.guidedTour)
  // }
}
