import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class GeneralServiceService {
  apiUrl = environment.apiUrl;
  url;

  constructor(private restService: RestService) {}
  // /v2/api​/open-data​/static​/commune
  getCommuneList(body: any, queryParams) {
    return this.restService.post(
      `${this.apiUrl}/v2/api/open-data/static/commune`,
      body,
      queryParams,
      true
    );
  }
  getNeighbourhood(body: any, queryParams) {
    return this.restService.post(
      `${this.apiUrl}/v2/api/open-data/static/quartier`,
      body,
      queryParams,
      true
    );
  }
  getYear(body: any, queryParams) {
    return this.restService.post(
      `${this.apiUrl}/v2/api/open-data/static/year`,
      body,
      queryParams,
      true
    );
  }
  downloadFile(body: any) {
    this.apiUrl.includes('dev')
      ? (this.url = 'https://v2devlb.analytics.brussels')
      : this.apiUrl.includes('qa')
      ? (this.url = 'https://v2qalb.analytics.brussels')
      : (this.url = 'https://v2prodlb.analytics.brussels');
    // https://v2prodlb.analytics.brussels/v2/api/open-data/static/z-download
    return this.restService.post(
      `${this.url}/v2/api/open-data/static/z-download`,
      body,
      null,
      true
    );
  }
}
