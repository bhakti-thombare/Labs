import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OpenDataDashboardComponent } from './open-data-dashboard/open-data-dashboard.component';


const routes: Routes = [
  { path: '', component: OpenDataDashboardComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OpenDataRoutingModule { }
