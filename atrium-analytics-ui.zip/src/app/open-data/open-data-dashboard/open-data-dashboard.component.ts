import { Component, OnInit } from '@angular/core';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { GeneralServiceService } from '../shared/general-service.service';
import * as _ from 'lodash';


@Component({
  selector: 'ab-open-data-dashboard',
  templateUrl: './open-data-dashboard.component.html',
  styleUrls: ['./open-data-dashboard.component.scss'],
})
export class OpenDataDashboardComponent implements OnInit {
  languageCode;
  constructor(
    private translate: TranslateService,
    private authService: AuthService,
    private modalService2: BsModalService,
    private router: Router,
    private generalService: GeneralServiceService
  ) {}
  currentUser;
  activeTab;
  userId = 0;
  typeOfData = [];
  modalRef;
  link = '';
  setOfCommune: any = [];
  setOfYear: any = [];
  selectedItems;
  selectedNeighbourhood;
  communeData = [];
  communeFlag = false;
  years = [];
  bindNeighbourhood = [];
  yearsselect = [];

  // setOfData = ['cs', 'pf', 'pos'];
  setOfTypeData = [
    {
      key: 'cs',
      valueEn: 'Customer Survey',
      valueFr: 'Enquête chaland',
      valueNl: 'Klantenenquête',
    },
    {
      key: 'pf',
      valueEn: 'Pedestrian Flow',
      valueFr: 'Flux piétons',
      valueNl: 'Voetgangersstroom',
    },
    {
      key: 'pos',
      valueEn: 'Point of Sale',
      valueFr: 'Point de vente',
      valueNl: 'Verkooppunt',
    },
    {
      key: 'stands',
      valueEn: 'Stands',
      valueFr: 'Marché',
      valueNl: 'Markt',
    },
    // {key:'stands',value:"Stands"}
  ];

  setOfNeighborhood: any = [];
  selectedYears: any = [];
  selectedType;
  neighborhood: any;
  commune = [];
  flag = false;
  neighbourhoodData;
  bindCommune = [];
  neighborhoodFlag = false;
  requestBody = {
    commune: [],
    fileType: 'xlsx',
    languageCode: this.languageCode,
    quartier: [],
    roleCode: this.currentUser,
    typeOfData: '',
    userId: this.userId,
    years: [],
  };
  setOfData: any = [];
  // tslint:disable-next-line: member-ordering
  generateFileObj;
  selectedLanguage;
  buttonDisabled = true;
  getSelectedYears(event) {
    if (event.length !== 0) {
      this.buttonDisabled = false;
    } else {
      this.buttonDisabled = true;
    }

    const years = [];
    event.forEach((element) => {
      years.push(element.value);
    });
    this.requestBody.years = years;
  }

  getTypeOfData(event) {
    this.communeFlag = true;
    this.communeData = [];
    const type = [];

    type.push(event.key);

    this.buttonDisabled = true;
    this.setOfCommune = Object.assign([], this.setOfCommune);
    this.selectedItems = [];
    this.selectedNeighbourhood = [];
    this.setOfNeighborhood = [];
    this.setOfYear = [];
    this.selectedYears = [];
    const communeList = [];

    // if (event.key === 'stands') {
    //   communeList.push({
    //     communeName: '',
    //     coummuneId: 0,
    //   })
    // this.requestBody.typeOfData = type[0];
    // this.getCommune(communeList);
    // this.setOfCommune=[];
    // }
    // else {
      this.requestBody.typeOfData = type[0];
      this.generalService
        .getCommuneList(this.requestBody, { loader: true })
        .subscribe((res) => {
          this.communeData = res.value;

          this.communeData.forEach((ele) => {
            this.selectedLanguage === 'en'
              ? communeList.push({
                communeName: ele.communeNameEn,
                coummuneId: ele.communeId,
              })
              : this.selectedLanguage === 'fr'
                ? communeList.push({
                  communeName: ele.communeNameFr,
                  coummuneId: ele.communeId,
                })
                : communeList.push({
                  communeName: ele.communeNameNl,
                  coummuneId: ele.communeId,
                });
          });
          this.setOfCommune = _.orderBy(communeList, ['communeName'], ['asc']);
          // this.setOfCommune=_.orderBy(this.setOfCommune)
        });
    // }
  }
  getNeighborhood(event) {
    if (event !== undefined) {
      if (this.neighborhoodFlag || this.bindNeighbourhood !== event) {
        this.buttonDisabled = true;

        this.setOfYear = [];
        this.selectedYears = [];
        const neighbourhood = [];
        this.yearsselect = [];
        this.bindNeighbourhood = this.selectedNeighbourhood;
        event.forEach((element) => {
          neighbourhood.push(element.quartierId);
        });
        this.requestBody.quartier = neighbourhood;
        if (event.length !== 0) {
          this.generalService
            .getYear(this.requestBody, { loader: true })
            .subscribe((res) => {
              this.neighborhoodFlag = false;
              this.years = res.value;
              if (this.years.length) {
                this.years.forEach((element, index) => {
                  this.yearsselect.push({
                    value: element.toString(),
                    quartierId: index,
                  });
                });
                this.setOfYear = _.orderBy(
                  this.yearsselect,
                  ['value'],
                  ['desc']
                );
              }
            });
        }
      }
    }
  }
  getCommune(event) {
    if (this.communeFlag || this.bindCommune !== event) {
      this.buttonDisabled = true;
      this.bindCommune = this.selectedItems;
      const neighbourhood = [];
      this.neighbourhoodData = [];
      this.setOfNeighborhood = [];
      this.selectedNeighbourhood = [];
      this.setOfYear = [];
      this.selectedYears = [];
      this.setOfNeighborhood = [];
      this.commune = [];
      event.forEach((element) => {
        this.commune.push(element.coummuneId);
      });

      this.requestBody.commune = this.commune;
      if (event.length !== 0) {
        this.generalService
          .getNeighbourhood(this.requestBody, { loader: true })
          .subscribe((res) => {
            this.neighborhoodFlag = true;
            this.neighbourhoodData = res.value;
            this.neighbourhoodData.forEach((ele) => {
              this.neighborhood = true;

              this.selectedLanguage === 'en'
                ? neighbourhood.push({
                    quartierName: ele.quartierNameEn,
                    quartierId: ele.quartierId,
                  })
                : this.selectedLanguage === 'fr'
                ? neighbourhood.push({
                    quartierName: ele.quartierNameFr,
                    quartierId: ele.quartierId,
                  })
                : neighbourhood.push({
                    quartierName: ele.quartierNameNl,
                    quartierId: ele.quartierId,
                  });
            });
            this.setOfNeighborhood = _.orderBy(
              neighbourhood,
              ['quartierName'],
              ['asc']
            );
          });
      }
      this.communeFlag = false;
    }
  }
  // generateFile() {
  //   this.generalService.downloadFile(this.requestBody).subscribe((res) => {
  //     window.open(res.value);
  //   });
  // }
  generateFile() {
    this.generalService.downloadFile(this.requestBody).subscribe((res) => {
  window.location = res.value;
});
}
  loadUser() {
    if (this.userId === 0) {
      this.flag = true;
    }
    this.authService.currentUser$.subscribe((user) => {
      this.currentUser = user.role;
      this.languageCode = user.languageCode;
      this.userId = user.id;
      if (this.userId === 0) {
        this.flag = true;
      } else {
        this.flag = false;
      }
    });
  }
  loadCommonObj() {
    this.generateFileObj = {
      userId: this.userId,
      roleCode: this.currentUser,
      languageCode: 'en',
    };
  }
  openModal(template) {
    this.modalRef = this.modalService2.show(template, {
      animated: true,
      backdrop: 'static',
      keyboard: false,
      class: 'custom-width',
    });
  }

  closeModal() {
    this.router.navigate(['/open-data']);
    this.modalRef.hide();
    this.loadUser();
  }
  ngOnInit() {
    this.selectedLanguage = localStorage.getItem('language');
    this.loadUser();

    if (window.location.hostname === 'v2qa.analytics.brussels') {
      this.link = 'https://v2qalb.analytics.brussels';
    } else if (window.location.hostname === 'v2dev.analytics.brussels') {
      this.link = 'https://v2devlb.analytics.brussels';
    } else if (window.location.hostname === 'v2prod.analytics.brussels')  {
      this.link = 'https://v2prodlb.analytics.brussels';
    } else if (window.location.hostname === 'analytics.brussels')  {
      this.link = 'https://v2prodlb.analytics.brussels';
    } else {
      this.link = 'https://v2qalb.analytics.brussels';
    }
    this.setOfTypeData.forEach((ele) => {
      this.selectedLanguage === 'en'
        ? this.setOfData.push({ key: ele.key, value: ele.valueEn })
        : this.selectedLanguage === 'fr'
        ? this.setOfData.push({ key: ele.key, value: ele.valueFr })
        : this.setOfData.push({ key: ele.key, value: ele.valueNl });
    });
    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.selectedLanguage = event.lang;
      this.setOfData = [];
      if (this.selectedLanguage === 'en') {
        this.setOfTypeData.forEach((ele) => {
          this.setOfData.push({ key: ele.key, value: ele.valueEn });
        });
        if (this.setOfCommune !== []) {
          this.setOfCommune = [];
          this.communeData.forEach((ele) => {
            this.setOfCommune.push({
              communeName: ele.communeNameEn,
              coummuneId: ele.communeId,
            });
          });
          this.setOfCommune = _.orderBy(
            this.setOfCommune,
            ['communeName'],
            ['asc']
          );
        }
        const commune = [];

        this.setOfCommune.forEach((element1) => {
          this.selectedItems.forEach((element2) => {

            if (element1.coummuneId === element2.coummuneId) {
              commune.push({
                communeName: element1.communeName,
                coummuneId: element1.coummuneId,
              });
            }
          });
        });
        this.selectedItems = commune;
        if (this.neighbourhoodData !== undefined) {
          this.setOfNeighborhood = [];
          this.neighbourhoodData.forEach((ele) => {
            this.setOfNeighborhood.push({
              quartierName: ele.quartierNameEn,
              quartierId: ele.quartierId,
            });
          });
          const data = [];
          this.setOfNeighborhood.forEach((element1) => {
            this.selectedNeighbourhood.forEach((element2) => {
              if (element1.quartierId === element2.quartierId) {
                data.push({
                  quartierName: element1.quartierName,
                  quartierId: element1.quartierId,
                });
              }
            });
          });
          this.selectedNeighbourhood = data;
          this.setOfNeighborhood = _.orderBy(
            this.setOfNeighborhood,
            ['quartierName'],
            ['asc']
          );
        }
        this.setOfYear = [];
        this.yearsselect.forEach((element) => {
          this.setOfYear.push(element);
        });
        this.setOfYear = _.orderBy(this.setOfYear, ['value'], ['desc']);

        if (this.selectedType !== undefined) {
          this.selectedType = this.setOfData.filter(
            (item) => item.key === this.selectedType.key
          )[0];
        }
      }
      if (this.selectedLanguage === 'fr') {
        this.setOfTypeData.forEach((ele) => {
          this.setOfData.push({ key: ele.key, value: ele.valueFr });
        });
        if (this.setOfCommune !== []) {
          this.setOfCommune = [];
          this.communeData.forEach((ele) => {
            this.setOfCommune.push({
              communeName: ele.communeNameFr,
              coummuneId: ele.communeId,
            });
          });
          this.setOfCommune = _.orderBy(
            this.setOfCommune,
            ['communeName'],
            ['asc']
          );
        }
        const commune = [];

        this.setOfCommune.forEach((element1) => {
          this.selectedItems.forEach((element2) => {
            if (element1.coummuneId === element2.coummuneId) {
              commune.push({
                communeName: element1.communeName,
                coummuneId: element1.coummuneId,
              });
            }
          });
        });
        this.selectedItems = commune;
        if (this.neighbourhoodData !== undefined) {
          this.setOfNeighborhood = [];
          this.neighbourhoodData.forEach((ele) => {
            this.setOfNeighborhood.push({
              quartierName: ele.quartierNameFr,
              quartierId: ele.quartierId,
            });
          });
          const data = [];
          this.setOfNeighborhood.forEach((element1) => {
            this.selectedNeighbourhood.forEach((element2) => {
              if (element1.quartierId === element2.quartierId) {
                data.push({
                  quartierName: element1.quartierName,
                  quartierId: element1.quartierId,
                });
              }
            });
          });
          this.selectedNeighbourhood = data;
          this.setOfNeighborhood = _.orderBy(
            this.setOfNeighborhood,
            ['quartierName'],
            ['asc']
          );
        }
        this.setOfYear = [];
        this.yearsselect.forEach((element) => {
          this.setOfYear.push(element);
        });
        this.setOfYear = _.orderBy(this.setOfYear, ['value'], ['desc']);

        // this.setOfYear=years
        if (this.selectedType !== undefined) {
          this.selectedType = this.setOfData.filter(
            (item) => item.key === this.selectedType.key
          )[0];
        }
      }
      if (this.selectedLanguage === 'nl') {
        // const years=this.setOfYear
        // this.setOfYear=[]
        this.setOfTypeData.forEach((ele) => {
          this.setOfData.push({ key: ele.key, value: ele.valueNl });
        });
        if (this.setOfCommune !== []) {
          this.setOfCommune = [];

          this.setOfCommune = [];
          this.communeData.forEach((ele) => {
            this.setOfCommune.push({
              communeName: ele.communeNameNl,
              coummuneId: ele.communeId,
            });
          });
          this.setOfCommune = _.orderBy(
            this.setOfCommune,
            ['communeName'],
            ['asc']
          );
        }
        const commune = [];

        this.setOfCommune.forEach((element1) => {
          this.selectedItems.forEach((element2) => {

            if (element1.coummuneId === element2.coummuneId) {
              commune.push({
                communeName: element1.communeName,
                coummuneId: element1.coummuneId,
              });
            }
          });
        });
        this.selectedItems = commune;

        // console.log('this.selecteditems=', this.selectedItems);

        if (this.neighbourhoodData !== undefined) {
          this.setOfNeighborhood = [];
          this.neighbourhoodData.forEach((ele) => {
            this.setOfNeighborhood.push({
              quartierName: ele.quartierNameNl,
              quartierId: ele.quartierId,
            });
          });

          const data = [];
          this.setOfNeighborhood.forEach((element1) => {
            this.selectedNeighbourhood.forEach((element2) => {
              if (element1.quartierId === element2.quartierId) {
                data.push({
                  quartierName: element1.quartierName,
                  quartierId: element1.quartierId,
                });
              }
            });
          });
          this.selectedNeighbourhood = data;
          this.setOfNeighborhood = _.orderBy(
            this.setOfNeighborhood,
            ['quartierName'],
            ['asc']
          );
        }
        // this.setOfYear=years
        this.setOfYear = [];
        this.yearsselect.forEach((element) => {
          this.setOfYear.push(element);
        });
        this.setOfYear = _.orderBy(this.setOfYear, ['value'], ['desc']);
        this.setOfData = _.orderBy(this.setOfData, ['value'], ['asc']);

        if (this.selectedType !== undefined) {
          this.selectedType = this.setOfData.filter(
            (item) => item.key === this.selectedType.key
          )[0];
        }
      }
    });
    // this.loadCommonObj();
  }
}
