import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenDataDashboardComponent } from './open-data-dashboard.component';

describe('OpenDataDashboardComponent', () => {
  let component: OpenDataDashboardComponent;
  let fixture: ComponentFixture<OpenDataDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpenDataDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenDataDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
