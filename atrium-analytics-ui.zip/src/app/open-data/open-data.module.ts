import { NgModule } from '@angular/core';
import {AuthModule} from '../auth/auth.module';

import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { SharedModule } from '../shared/shared.module';
import { OpenDataRoutingModule } from './open-data-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MultiSelectModule} from 'primeng/multiselect';
import {DropdownModule} from 'primeng/dropdown';

import { OpenDataDashboardComponent } from './open-data-dashboard/open-data-dashboard.component';


@NgModule({
  declarations: [OpenDataDashboardComponent],
  imports: [
    AuthModule,
    CommonModule,
    OpenDataRoutingModule,
    NgSelectModule,
    SharedModule,
    FormsModule,
    MultiSelectModule,
    DropdownModule
  ]
})
export class OpenDataModule { }
