import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import { GlobalErrorHandler } from './core/error-handler/global-error-handler';
import { APP_BASE_HREF } from '@angular/common';
import { AboutUsComponent } from './home/about-us/about-us.component';
import { LandingComponent } from './home/landing/landing.component';
import { ContactFormComponent } from './home/contact-form/contact-form.component';
import { AuthModule } from './auth/auth.module';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { RecaptchaModule, RecaptchaSettings, RECAPTCHA_SETTINGS, RecaptchaFormsModule } from 'ng-recaptcha';
import { TranslateModule, TranslateLoader, TranslateStore } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgSelectModule } from '@ng-select/ng-select';
import { GraphicSliderComponent } from './home/graphic-slider/graphic-slider.component';
// import { CarouselModule } from 'ngx-bootstrap/carousel';
import { environment } from 'src/environments/environment';
import { PartnerSliderComponent } from './home/partner-slider/partner-slider.component';
import { WelcomeOnboardComponent } from './home/welcome-onboard/welcome-onboard.component';
// import { NguCarouselModule } from '@ngu/carousel';
// import { SlickCarouselModule } from 'ngx-slick-carousel';
import { CarouselModule } from 'primeng/carousel';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { PageUnderdevelopmentComponent } from './home/page-underdevelopment/page-underdevelopment.component';
import { PageNotFoundComponent } from './home/page-not-found/page-not-found.component';
import { LoaderService } from './core/services/loader.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoaderInterceptor } from './core/interceptors/loader.interceptor';
import { UserProfileFormComponent } from './home/user-profile-form/user-profile-form.component';
import { ResendVerificationPageComponent } from './home/resend-verification-page/resend-verification-page.component';
import { GeneralPurposeInterceptor } from './core/interceptors/general-purpose.interceptor';
import { MaintainanceComponent } from './maintainance/maintainance.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { WarningPopupComponent } from './shared/components/warning-popup/warning-popup.component';
// import { GuidedTourModule, GuidedTourService } from 'ngx-guided-tour';

export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
@NgModule({
  declarations: [
    MaintainanceComponent,
    AppComponent,
    LandingComponent,
    AboutUsComponent,
    ContactFormComponent,
    GraphicSliderComponent,
    PartnerSliderComponent,
    WelcomeOnboardComponent,
    // PageUnderdevelopmentComponent,
    PageNotFoundComponent,
    UserProfileFormComponent,
    ResendVerificationPageComponent,
  ],
  imports: [
    BsDropdownModule.forRoot(),
    SharedModule,
    BrowserAnimationsModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient],
      }
    }),
    ModalModule.forRoot(),
    // CarouselModule.forRoot(),
    // NgSelectModule,
    RecaptchaModule,
    BrowserModule,
    AuthModule,
    FormsModule,
    CoreModule,
    FormsModule,
    CarouselModule,
    ReactiveFormsModule,
    RecaptchaFormsModule,
    // GuidedTourModule,
    AppRoutingModule
  ],

  providers: [
    // GuidedTourService,
    TranslateStore,
    LoaderService,
    [{ provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: GeneralPurposeInterceptor, multi: true }],
    { provide: APP_BASE_HREF, useValue: '!' },
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
    {
      provide: RECAPTCHA_SETTINGS,
      useValue: {
        siteKey: environment.siteKey || '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI',
      } as RecaptchaSettings,
    },
  ],
  entryComponents:[WarningPopupComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }

// {provide: ErrorHandler, useClass: GlobalErrorHandler
