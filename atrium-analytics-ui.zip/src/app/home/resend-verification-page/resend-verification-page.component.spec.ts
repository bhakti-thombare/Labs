import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResendVerificationPageComponent } from './resend-verification-page.component';

describe('ResendVerificationPageComponent', () => {
  let component: ResendVerificationPageComponent;
  let fixture: ComponentFixture<ResendVerificationPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResendVerificationPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResendVerificationPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
