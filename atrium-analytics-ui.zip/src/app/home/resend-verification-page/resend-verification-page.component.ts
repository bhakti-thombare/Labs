import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ab-resend-verification-page',
  templateUrl: './resend-verification-page.component.html',
  styleUrls: ['./resend-verification-page.component.scss']
})
export class ResendVerificationPageComponent implements OnInit {
  mainHead: string;
  subHead: string;

  constructor() { }

  ngOnInit() {
    this.initialiseVariables();
  }

  initialiseVariables() {
    this.mainHead = 'Almost there! Please confirm your account.';
    // tslint:disable-next-line: max-line-length
    this.subHead = 'We have just sent you instructions by email to complete your registration. Please check your email and confirm your account.';
  }

}
