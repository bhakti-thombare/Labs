import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { NotificationService } from 'src/app/core/services/notification.service';
import { SharedService } from '../shared/services/shared.service';
import { Router } from '@angular/router';
import { UtilityService } from 'src/app/core/services/utility.service';
declare var JSEncrypt: any;
@Component({
  selector: 'ab-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.scss']
})
export class ContactFormComponent implements OnInit {
  submitted = false;
  contactForm: FormGroup;
  encrypt: any;
  // tslint:disable-next-line: max-line-length
  emailPattern = new RegExp(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
  constructor(
    private router: Router,
    private utilityService: UtilityService,
    private sharedService: SharedService,
    private formBuilder: FormBuilder,
    private notificationService: NotificationService) { }

  ngOnInit() {
    this.buildContactForm();
  }

  buildContactForm() {
    this.contactForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      emailAddress: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      recaptcha: [null, Validators.required],
      message: ['', Validators.required]
    });
  }

  get firstName() {
    return this.contactForm.get('firstName');
  }
  get lastName() {
    return this.contactForm.get('lastName');
  }
  get emailAddress() {
    return this.contactForm.get('emailAddress');
  }
  get recaptcha() {
    return this.contactForm.get('recaptcha');
  }
  get message() {
    return this.contactForm.get('message');
  }

  submit() {
    this.submitted = true;
    if (this.contactForm.valid) {
      this.encrypt = new JSEncrypt();
      this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
      const data = {
        toEmail: '',
        fromEmail: this.encrypt.encrypt(this.contactForm.value.emailAddress),
        subject: '',
        body: this.contactForm.value.message,
        firstName: this.contactForm.value.firstName,
        lastName: this.contactForm.value.lastName
      };
      // console.log(data);
      this.sharedService.submitContact(data).subscribe(res => {
        // console.log('res', res);
        // if (res.message === 'Contact form questions send succesfully!') {
        // this.notificationService.showSuccess('Your message is sent.');
        this.utilityService.showTranslatedNotificationMessage('NotificationMessages.AboutUs.ContactFormSubmitted', 'SUCCESS');
        this.contactForm.reset();
        this.router.navigateByUrl('/');
        // }
        this.submitted = false;
      });
    } else {
      // this.notificationService.showError('Please fill in all details');
    }
  }
}
