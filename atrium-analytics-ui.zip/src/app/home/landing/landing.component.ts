import { Component, OnInit, Inject, TemplateRef } from '@angular/core';
import { HostListener } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { AuthService } from 'src/app/core/services/auth.service';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { SharedService } from '../shared/services/shared.service';
import { ActivatedRoute } from '@angular/router';
import { SharedDataServiceService } from 'src/app/core/services/shared-data-service.service';

declare var JSEncrypt: any;

@Component({
  selector: 'ab-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss'],
})
export class LandingComponent implements OnInit {
  encrypt: any;
  selectedLanguage: string;
  landingData: any;
  rawLandingData: any;
  constructor(
    private activatedRoute: ActivatedRoute,
    private modalService: BsModalService,
    private authService: AuthService,
    private translate: TranslateService,
    private sharedService: SharedService,
    private sharedData: SharedDataServiceService
  ) {}
  modalRef: any;
  currentUser: any;

  activeTab: any;
  moreInfoData = [
    {
      title: 'Title1',
      description: 'Description1',
      image: 'assets/images/landing/more-info-logos/interrogate.svg',
    },
    {
      title: 'Title2',
      description: 'Description2',
      image: 'assets/images/landing/more-info-logos/analyze.svg',
    },
    {
      title: 'Title3',
      description: 'Description3',
      image: 'assets/images/landing/more-info-logos/download.svg',
    },
    {
      title: 'Title4',
      description: 'Description4',
      image: 'assets/images/landing/more-info-logos/share.svg',
    },
  ];
  @HostListener('window:scroll', []) onWindowScroll() {
    if (window.innerWidth > 991) {
      const element = document.querySelector('.navbar');
      const element2 = document.querySelector(
        '.language-dropdown-background-blue'
      );
      const element3 = document.querySelector(
        '.profile-dropdown-background-blue'
      );
      if (window.pageYOffset > element.clientHeight) {
        element.classList.add('solid');
      } else {
        element.classList.remove('solid');
      }
    }
  }

  @HostListener('window:resize', []) onWindowResize() {
    const element = document.querySelector('.navbar');
    if (window.innerWidth <= 991) {
      element.classList.add('solid');
    } else {
      element.classList.remove('solid');
    }
  }

  ngOnInit() {
    // this.activatedRoute.queryParams.subscribe(params => {
    //   if (params && params.language) {
    //     localStorage.setItem('language', params.language.toLowerCase());
    //     this.translate.use(params.language.toLowerCase());
    //   }
    // });
    if (this.sharedData.sharedUrl === 'viz-page' || this.sharedData.sharedUrl === 'product-page') {
      const position = document.getElementById('content');
      position.scrollIntoView({
        block: 'center',
      });
      position.scrollIntoView(true);

    }
    this.sharedData.sharedUrl = null;

    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      // console.log('event', event);
      this.selectedLanguage = event.lang;
      this.getLandingData();
    });
    this.getLandingData();
    const element = document.querySelector('.navbar');
    if (window.innerWidth <= 991) {
      element.classList.add('solid');
    } else {
      element.classList.remove('solid');
    }
    this.selectedLanguage = localStorage.getItem('language');
    // console.log('this.selectedLanguage', this.selectedLanguage);
    // if (this.selectedLanguage) {
    //   this.translate.use(this.selectedLanguage);
    // } else {
    //   this.translate.use('fr');
    // }

    this.loadUser();
  }

  getLandingData() {
    this.sharedService.getLandingData().subscribe((res) => {
      // console.log('res', res);
      this.rawLandingData = res.value;
      this.setLandingData(this.selectedLanguage);
    });
  }

  setLandingData(language: string) {
    let langIndex = 0;
    if (language === 'en') {
      langIndex = 0;
    }
    if (language === 'fr') {
      langIndex = 1;
    }
    if (language === 'nl') {
      langIndex = 2;
    }
    const data: any = {
      discoverBrussels: {
        title: this.rawLandingData.discoverBrussels.landingSectionDetailDtos[
          langIndex
        ].title.replace(/\n/g, '<br>'),
        description: this.rawLandingData.discoverBrussels.landingSectionDetailDtos[
          langIndex
        ].description.replace(/\n/g, '<br>'),
        image: this.rawLandingData.discoverBrussels.imageDto.imageUrl,
      },
      keywords: [],
      hubBrussels: {
        title: this.rawLandingData.hubBrussels.landingSectionDetailDtos[
          langIndex
        ].title.replace(/\n/g, '<br>'),
        description: this.rawLandingData.hubBrussels.landingSectionDetailDtos[
          langIndex
        ].description.replace(/\n/g, '<br>'),
        image: this.rawLandingData.hubBrussels.imageDto.imageUrl,
      },
      partners: {
        title: this.rawLandingData.partners.landingSectionDetailDtos[
          langIndex
        ].title.replace(/\n/g, '<br>'),
        description: this.rawLandingData.partners.landingSectionDetailDtos[
          langIndex
        ].description.replace(/\n/g, '<br>'),
        // this.rawLandingData.partners.logos.filter(logo => logo.imageUrl.includes('feder_logo'))[0].imageUrl || '',
        federLogo: this.rawLandingData.partners.federLogo.imageUrl,
        logos: this.rawLandingData.partners.logos, // .filter(logo => !logo.imageUrl.includes('feder_logo')) || ''
      },
    };
    let i = 0;
    Object.keys(this.rawLandingData.keywords).forEach((key: string) => {
      if (!key.includes('id')) {
        const keyWordData = {
          title: this.rawLandingData.keywords[key].landingSectionDetailDtos[
            langIndex
          ].title.replace(/\n/g, '<br>'),
          description: this.rawLandingData.keywords[
            key
          ].landingSectionDetailDtos[langIndex].description.replace(
            /\n/g,
            '<br>'
          ),
          image: this.rawLandingData.keywords[key].imageDto.imageUrl,
        };
        data.keywords.push(keyWordData);
        i++;
      }
    });
    this.landingData = data;
    // console.log('this.landingData', this.landingData);
    // console.log('data', data);
  }

  loadUser() {
    this.authService.currentUser$.subscribe((user: any) => {
      this.currentUser = user;
    });
  }

  getInitials() {
    if (this.currentUser) {
      return this.currentUser.firstName[0] + this.currentUser.lastName[0];
    }
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {
      animated: true,
      backdrop: 'static',
      keyboard: false,
      class: 'custom-width',
    });
  }

  onSignInClick(template: any) {
    this.activeTab = 0;
    this.openModal(template);
  }

  onSignUpClick(template: any) {
    this.activeTab = 1;
    this.openModal(template);
  }

  closeModal() {
    this.modalRef.hide();
  }

  logout() {
    this.encrypt = new JSEncrypt();
    this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
    const userName = this.encrypt.encrypt(this.currentUser.rawEmail);
    this.authService.logout(userName).subscribe(() => {
      window.location.href = '/';
    });
  }

  switchLanguage(lang: string) {
    this.selectedLanguage = lang;
    localStorage.setItem('language', lang);
    this.translate.use(lang);
    this.setLandingData(this.selectedLanguage);
  }

  openHubBrussels() {
    window.open('http://hub.brussels');
  }
}
