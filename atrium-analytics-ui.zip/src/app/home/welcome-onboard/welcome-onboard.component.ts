import { Component, OnInit, TemplateRef } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { filter } from 'rxjs/operators';
import { BsModalService } from 'ngx-bootstrap/modal';
import { AuthService } from 'src/app/core/services/auth.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'ab-welcome-onboard',
  templateUrl: './welcome-onboard.component.html',
  styleUrls: ['./welcome-onboard.component.scss']
})
export class WelcomeOnboardComponent implements OnInit {
  signUpSuccess: boolean;
  title = 'Welcome on board';
  description = 'We have sent you a confirmation link. Please check your emails in order to activate your account. ' +
    'You can already browse our app or follow our tutorial to learn how analytics is working.';
  activeTab: any;
  modalRef: any;
  currentUser: any;
  constructor(
    private translate: TranslateService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private modalService: BsModalService, private authService: AuthService) {

    router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
      // console.log(this.router.url);
      if (this.router.url === '/sign-up-error') {
        this.signUpSuccess = false;
        // console.log('signUpSuccess', this.signUpSuccess);
        this.title = 'Something went wrong';
        this.description = 'Your sign up process was not successfull, please try again';

      } else {
        this.signUpSuccess = true;
      }
    });

    // this.activatedRoute.queryParams.subscribe(params => {
    //   if (params && params.language) {
    //     localStorage.setItem('language', params.language.toLowerCase());
    //     translate.use(params.language.toLowerCase());
    //   }
    // });
  }



  ngOnInit() {
    // this.activatedRoute.queryParams.subscribe(params => {
    //   if (params && params.language) {
    //     localStorage.setItem('language', params.language.toLowerCase());
    //     this.translate.use(params.language.toLowerCase());
    //   }
    // });
    this.loadUser();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  openModal(template: TemplateRef<any>) {
    if (this.currentUser) {
      this.router.navigateByUrl('/user/dashboard/under-development');
    } else {
      this.modalRef = this.modalService.show(template, {
        animated: true,
        backdrop: 'static',
        keyboard: false,
        class: 'custom-width'
      });
    }
  }

  closeModal() {
    this.modalRef.hide();
  }



}
