import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WelcomeOnboardComponent } from './welcome-onboard.component';

describe('WelcomeOnboardComponent', () => {
  let component: WelcomeOnboardComponent;
  let fixture: ComponentFixture<WelcomeOnboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WelcomeOnboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WelcomeOnboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
