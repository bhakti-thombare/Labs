import { Component, OnInit, TemplateRef, AfterViewInit, HostListener } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { AuthService } from 'src/app/core/services/auth.service';
import { ActivatedRoute } from '@angular/router';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { SharedService } from '../shared/services/shared.service';
import { VirtualTimeScheduler } from 'rxjs';

declare var JSEncrypt: any;


@Component({
  selector: 'ab-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.scss']
})
export class AboutUsComponent implements OnInit, AfterViewInit {
  activeTab: any;
  modalRef: BsModalRef;
  currentUser: any;
  encrypt: any;
  fragment: string;
  selectedLanguage: string;
  aboutUsData: any = {};
  rawAboutUsData: any;

  @HostListener('window:scroll', [])  onWindowScroll() {
    if (window.innerWidth > 991) {
      const element = document.querySelector('.navbar');
      const element2 = document.querySelector('.language-dropdown-background-blue');
      const element3 = document.querySelector('.profile-dropdown-background-blue');
      if (window.pageYOffset > element.clientHeight) {
        element.classList.add('solid');
      } else {
        element.classList.remove('solid');
      }
    }
  }

  @HostListener('window:resize', [])  onWindowResize() {
    const element = document.querySelector('.navbar');
    if (window.innerWidth <= 991) {
      element.classList.add('solid');
    } else {
      element.classList.remove('solid');
    }
  }


  constructor(
    private translate: TranslateService,
    private sharedService: SharedService,
    private activatedRoute: ActivatedRoute,
    private modalService: BsModalService,
    private authService: AuthService) { }

  ngOnInit() {
    const element = document.querySelector('.navbar');
    if (window.innerWidth <= 991) {
      element.classList.add('solid');
    } else {
      element.classList.remove('solid');
    }
    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      // console.log('event', event);
      this.selectedLanguage = event.lang;
    });
    this.selectedLanguage = localStorage.getItem('language');
    this.activatedRoute.fragment.subscribe(fragment => { this.fragment = fragment; });
    this.getAboutUsData();
    this.loadUser();
  }
  ngAfterViewInit(): void {
    try {
      if (this.fragment) {
        const element = document.getElementById(this.fragment);
        const elementRect = element.getBoundingClientRect();
        const absoluteElementTop = elementRect.top + window.pageYOffset;
        const middle = absoluteElementTop - (window.innerHeight / 4);
        window.scrollTo(0, middle);
        // document.querySelector('#' + this.fragment).scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
      }
    } catch (e) { }
  }
  loadUser() {
    this.authService.currentUser$.subscribe((user: any) => {
      this.currentUser = user;
    });
  }


  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {
      animated: true,
      backdrop: 'static',
      keyboard: false,
      class: 'custom-width'
    });
  }

  getInitials() {
    if (this.currentUser) { return this.currentUser.firstName[0] + this.currentUser.lastName[0]; }
  }

  onSignInClick(template: any) {
    this.activeTab = 0;
    this.openModal(template);
  }

  onSignUpClick(template: any) {
    this.activeTab = 1;
    this.openModal(template);
  }

  closeModal() {
    this.modalRef.hide();
  }

  logout() {
    this.encrypt = new JSEncrypt();
    this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
    const userName = this.encrypt.encrypt(this.currentUser.rawEmail);
    this.authService.logout(userName).subscribe(() => {
      window.location.href = '/';
    });
  }

  switchLanguage(lang: string) {
    this.selectedLanguage = lang;
    localStorage.setItem('language', lang);
    this.translate.use(lang);
    this.formatAndSwitchData();
  }


  getAboutUsData() {
    this.sharedService.getAboutUsData().subscribe((res) => {
      // console.log('res', res);
      this.rawAboutUsData = res.value;
      this.formatAndSwitchData();
    });
  }


  formatAndSwitchData() {
    // console.log('formatAndSwitchData');
    this.rawAboutUsData.languages.forEach((element: any) => {
      if (element.language.toLowerCase() === this.selectedLanguage) {
        this.aboutUsData.section1 = element.section.filter(item => item.sectionId === 1)[0];
        this.aboutUsData.section2 = element.section.filter(item => item.sectionId === 2)[0];
        this.aboutUsData.section3 = {};
        this.aboutUsData.section4 = element.section.filter(item => item.sectionId === 4)[0];
        this.aboutUsData.section5 = element.multipleDescriptionSection;
      }
    });
    this.aboutUsData.section1.image = this.rawAboutUsData.imageSection.filter(item => item.sectionId === 1)[0].sectionImage;
    this.aboutUsData.section2.image = this.rawAboutUsData.imageSection.filter(item => item.sectionId === 2)[0].sectionImage;
    this.aboutUsData.section3.image = this.rawAboutUsData.imageSection.filter(item => item.sectionId === 3)[0].sectionImage;
    this.aboutUsData.section4.image = this.rawAboutUsData.imageSection.filter(item => item.sectionId === 4)[0].sectionImage;
    // console.log('this.aboutUsData', this.aboutUsData);
    this.replaceNewLineWithBr();
  }

  replaceNewLineWithBr() {
    Object.keys(this.aboutUsData).forEach(section => {
      Object.keys(this.aboutUsData[section]).forEach(key => {
        if (key !== 'image' && key !== 'sectionId') {
          this.aboutUsData[section][key] = this.aboutUsData[section][key].replace(/\n/g, '<br>');
        }
      });
    });
  }
}
