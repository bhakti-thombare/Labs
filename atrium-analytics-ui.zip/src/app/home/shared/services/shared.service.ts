import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  constructor(private restService: RestService) { }

  submitContact(data: any) {
    return this.restService.post(`${environment.apiUrl}/v2/api/contact/contact-us`, data, undefined, true);
  }

  getLandingData() {
    return this.restService.fetch(`${environment.apiUrl}/v2/api/landing`, undefined, true);
  }


  getAboutUsData() {
    return this.restService.fetch(`${environment.apiUrl}/v2/api/about-us`, undefined, true);
  }

  createUserProfile(body: any) {
    return this.restService.put(`${environment.apiUrl}/v2/api/user/profile`, body, undefined, true);
  }

  promotedContent(queryParams) {
    return this.restService.put(`${environment.apiUrl}/v2/api/landing/promoted-content`, undefined, queryParams, true);
  }
}
