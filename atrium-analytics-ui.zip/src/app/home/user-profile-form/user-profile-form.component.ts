import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UtilityService } from 'src/app/core/services/utility.service';
import { SharedService } from '../shared/services/shared.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { Router, ActivatedRoute } from '@angular/router';
import { SharedDataServiceService } from 'src/app/core/services/shared-data-service.service';
declare var JSEncrypt: any;
@Component({
  selector: 'ab-user-profile-form',
  templateUrl: './user-profile-form.component.html',
  styleUrls: ['./user-profile-form.component.scss']
})
export class UserProfileFormComponent implements OnInit {
  userAddForm: FormGroup;
  selectedLanguage = '';
  passwordStrength = '';
  selectedEmployment = '';
  isConfirmPasswordSelected = false;
  isPasswordSelected = false;
  isEmploymentSelected = false;
  isFirstNameSelected = false;
  isLastNameSelected = false;
  languageTouched = false;
  isEmailSelected = false;
  isCompanySelected = false;
  // tslint:disable-next-line: max-line-length
  emailPattern = new RegExp(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
  encrypt: any;
  disableEmailField = false;
  param = { strength: '' };
  jobTitles = [
    { title: 'Employee', code: 'Employee' },
    { title: 'Looking for a job', code: 'LookingJob' },
    { title: 'Entrepreneur', code: 'Entrepreneur' },
    { title: 'Student', code: 'Student' },
    { title: 'Young Graduate', code: 'YoungGraduate' },
    { title: 'Manager', code: 'Manager' },
    { title: 'Member of a merchant association', code: 'MerchantAssociation' },
    { title: 'Member of a residents\' association', code: 'ResidentOrAssociation' },
    { title: 'Partner', code: 'Partner' },
    { title: 'CEO', code: 'CEO' },
    { title: 'Trainee', code: 'Trainee' },
    { title: 'Other', code: 'Other' },
    // { title: 'Programmer', code: 'Programmer' },
    // { title: 'Solutions Architect', code: 'SA' },
    // { title: 'Database Developer', code: 'DBA' },
    // { title: 'Accountant', code: 'Accountant' },
    // { title: 'Payroll Officer', code: 'PayrollOfficer' },
    // { title: 'Accounts Clerk', code: 'AccountClerk' },
    // { title: 'Analyst', code: 'Analyst' },
    // { title: 'Financial Controller', code: 'FinancialController' },
    // { title: 'Recruitment Consultant', code: 'RecruitmentConsultant' },
    // { title: 'Change Management', code: 'ChangeManagement' },
    // { title: 'Industrial Relations', code: 'IndustrialRelations' },
    // { title: 'Market Researcher', code: 'MarketResearcher' },
    // { title: 'Marketing Manager', code: 'MarketingManager' },
    // { title: 'Marketing Co-ordinator', code: 'MarketingCoordinator' }

  ];
  constructor(
    private dataSharingService: SharedDataServiceService,
    private utilityService: UtilityService,
    private formBuilder: FormBuilder,
    private router: Router,
    private sharedService: SharedService,
    private activatedRoute: ActivatedRoute,
    private notificationService: NotificationService) { }

  ngOnInit() {
    this.buildForm();
    this.activatedRoute.queryParams.subscribe(params => {
      let email = params.email;
      // console.log(email);
      if (email) {
        email = atob(email);
        this.userAddForm.get('email').setValue(email.trim());
        this.disableEmailField = true;
        // console.log('this.disableEmailField', this.disableEmailField);
      }
    });
  }

  buildForm() {

    this.userAddForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      companyName: [''],
      languageCode: ['', Validators.required]
    }, {
      validator: this.MustMatch('password', 'confirmPassword')
    });

    this.userAddForm.get('password').valueChanges.subscribe(value => {
      // console.log('value', value)
      if (value) {
        this.param.strength = this.getPasswordStrength(value);
        // console.log('this.param.strength', this.param.strength)
      }
    });
  }

  get firstName() {
    return this.userAddForm.get('firstName');
  }

  get lastName() {
    return this.userAddForm.get('lastName');
  }

  get email() {
    return this.userAddForm.get('email');
  }
  get password() {
    return this.userAddForm.get('password');
  }

  get companyName() {
    return this.userAddForm.get('companyName');
  }

  get langauageF() {
    return this.userAddForm.get('langauage');
  }

  get confirmPassword() {
    return this.userAddForm.get('confirmPassword');
  }

  onSubmit() {
    // console.log(this.userAddForm.value);
    this.encrypt = new JSEncrypt();
    this.encrypt.setPublicKey(localStorage.getItem('publicKey'));
    const data = this.userAddForm.value;
    data.email = this.encrypt.encrypt(data.email);
    data.password = this.encrypt.encrypt(data.password);
    data.employment = this.selectedEmployment;
    // data.employment = 'employee';
    delete data.confirmPassword;
    // console.log(data);
    if (!data.companyName) {
      delete data.companyName;
    }
    if (!data.employment) {
      delete data.employment;
    }


    if (data.employment) {
      if (data.employment === 'LookingJob') {
        data.employment = 'Looking for a job';
      }

      if (data.employment === 'YoungGraduate') {
        data.employment = 'Young Graduate';
      }

      if (data.employment === 'MerchantAssociation') {
        data.employment = 'Member of a merchant association';
      }

      if (data.employment === 'ResidentOrAssociation') {
        data.employment = 'Member of a residents\' association';
      }
    }
    // console.log('data', data)
    this.sharedService.createUserProfile(data).subscribe(res => {
      // console.log('res', res);
      // this.notificationService.showSuccess('Profile created successfully.');
      this.utilityService.showTranslatedNotificationMessage('NotificationMessages.User.ProfileCreated', 'SUCCESS');
      this.router.navigateByUrl('/');
    });

  }
  handler(value, value2) {
    if (value === 'language') {
      this.languageTouched = value2;
    }
    if (value === 'employment') {
      this.isEmploymentSelected = value2;
    }
  }

  selectLanguage(lang) {
    this.selectedLanguage = lang;
    this.userAddForm.get('languageCode').setValue(this.utilityService.getLanguageCode(lang));
  }


  getPasswordStrength(password: string) {

    // Must have capital letter, numbers and lowercase letters
    const strongRegex = new RegExp('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$', 'g');

    // Must have either capitals and lowercase letters or lowercase and numbers
    const mediumRegex = new RegExp('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$', 'g');
    // ((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|

    // Must be at least 6 characters long
    const okRegex = new RegExp('^(?=.*?[a-z]).{8,}$', 'g');

    if (okRegex.test(password) === false) {
      // If ok regex doesn't match the password
      // console.log('If ok regex doesn\'t match the password111');
      return 'Weak';
    } else if (strongRegex.test(password)) {
      // If reg ex matches strong password
      return 'Strong';
    } else if (mediumRegex.test(password)) {
      // If medium password matches the reg ex
      return 'Medium';
    } else {
      // console.log('If ok regex doesn\'t match the password');
      // If password is ok
      return 'Weak';
    }

  }

  // custom validator to check that two fields match
  MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        // return if another validator has already found an error on the matchingControl
        return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }

  openTermsAndConditions() {

    // this.footerComponent.openTermsAndConditions();
    window.open(this.dataSharingService.termsAndCondition);
  }

}
