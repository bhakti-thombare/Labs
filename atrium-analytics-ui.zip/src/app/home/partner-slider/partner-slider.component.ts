import { Component, OnInit, HostListener, ViewEncapsulation, Input, OnChanges } from '@angular/core';


@Component({
  selector: 'ab-partner-slider',
  templateUrl: './partner-slider.component.html',
  styleUrls: ['./partner-slider.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PartnerSliderComponent implements OnInit, OnChanges {

  itemsPerSlide = 4;
  singleSlideOffset = true;
  noWrap = true;
  @Input() logoData: any;
  slides = [
    { image: 'assets/images/landing/partners/logo_1819.jpg' },
    { image: 'assets/images/landing/partners/logo_actiris.jpg' },
    { image: 'assets/images/landing/partners/logo_beci.jpg' },
    { image: 'assets/images/landing/partners/logo_feder.jpg' },
    { image: 'assets/images/landing/partners/logo_impulse.jpg' },
    { image: 'assets/images/landing/partners/logo_innoviris.jpg' },
    { image: 'assets/images/landing/partners/logo_izeo.jpg' },
    { image: 'assets/images/landing/partners/logo_joyn.jpg' },
    { image: 'assets/images/landing/partners/logo_rbc.jpg' },
    { image: 'assets/images/landing/partners/logo_visitbrussels.jpg' },
    { image: 'assets/images/landing/partners/logo_vub.jpg' }
  ];
  responsiveOptions: { breakpoint: string; numVisible: number; numScroll: number; }[];

  @HostListener('window:resize', []) onResize() {
    if (window.innerWidth <= 1366) {
      this.itemsPerSlide = 3;
      // console.log('itemsPerSlide', this.itemsPerSlide);
    }
  }

  constructor() {
    this.responsiveOptions = [
      {
        breakpoint: '1600px',
        numVisible: 4,
        numScroll: 1
      },
      {
        breakpoint: '1440px',
        numVisible: 4,
        numScroll: 1
      },
      {
        breakpoint: '1366px',
        numVisible: 4,
        numScroll: 1
      },
      {
        breakpoint: '1280px',
        numVisible: 3,
        numScroll: 1
      },
      {
        breakpoint: '1024px',
        numVisible: 3,
        numScroll: 1
      },
      {
        breakpoint: '768px',
        numVisible: 2,
        numScroll: 1
      },
      {
        breakpoint: '560px',
        numVisible: 1,
        numScroll: 1
      }
    ];
  }


  ngOnInit() {
    if (window.innerWidth <= 1366) {
      this.itemsPerSlide = 3;
    }
  }

  ngOnChanges() {
    if (this.logoData) {
      this.slides = this.logoData;
    }
  }

}
