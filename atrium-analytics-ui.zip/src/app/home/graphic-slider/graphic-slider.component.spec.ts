import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GraphicSliderComponent } from './graphic-slider.component';

describe('GraphicSliderComponent', () => {
  let component: GraphicSliderComponent;
  let fixture: ComponentFixture<GraphicSliderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GraphicSliderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GraphicSliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
