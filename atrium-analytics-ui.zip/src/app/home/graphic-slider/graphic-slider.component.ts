import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared/services/shared.service';
import { LangChangeEvent, TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';

@Component({
  selector: 'ab-graphic-slider',
  templateUrl: './graphic-slider.component.html',
  styleUrls: ['./graphic-slider.component.scss'],
})
export class GraphicSliderComponent implements OnInit {
  constructor(
    private sharedService: SharedService,
    private translate: TranslateService,
    private router: Router
  ) {
    this.responsiveOptions = [
      {
        breakpoint: '1024px',
        numVisible: 3,
        numScroll: 3,
      },
      {
        breakpoint: '765px',
        numVisible: 2,
        numScroll: 2,
      },
      {
        breakpoint: '560px',
        numVisible: 1,
        numScroll: 1,
      },
    ];
  }
  length = true;
  itemsPerSlide = 3;
  singleSlideOffset = true;
  noWrap = true;

  responsiveOptions: {
    breakpoint: string;
    numVisible: number;
    numScroll: number;
  }[];
  slides = [];
  selectedLanguage;
  flag;
  i = 0;
  getPromotedContent() {
      this.sharedService
        .promotedContent({ loader: true })
        .subscribe((res) => {
          const getdata = res.value.content;
          getdata.forEach((element) => {
            this.i = this.i;
            this.slides.push({
              image: element.thumbnail,
              enName: element.elementNameEn,
              frName: element.elementNameFr,
              nlName: element.elementNameNl,
              elementId: element.elementId,
              elementType: element.elementType,
            });
            this.i++;
            if (this.i < 4) {
             this.length = false;
          } else {
            this.length = true;
          }
          });
        });
  }
  goTo(id, type) {
    if (type === 'viz' || type === 'visualisation') {
      this.router.navigate([`/library/viz-details/${id}`, { previousUrl: 'homepage' }]);
    }
    if (type === 'product' || type === 'report') {
      this.router.navigate([`/library/product-details/${id}`, { previousUrl: 'homepage' }]);
    }
  }
  ngOnInit() {
    this.selectedLanguage = localStorage.getItem('language');
    this.getPromotedContent();
    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.selectedLanguage = event.lang;
    });
  }
}
