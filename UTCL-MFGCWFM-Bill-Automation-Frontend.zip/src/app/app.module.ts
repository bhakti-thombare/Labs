import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material.module';

import { MsAdalAngular6Module, AuthenticationGuard } from 'microsoft-adal-angular6';
import { MsAdalInterceptor } from './authentication/token-interceptor';
import { getAdalConfiguration } from './authentication/azure-configuration';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';

import { SharedModule  } from '../app/shared/shared.module';
import { LoginComponent } from './shared/login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    InvoiceComponent,
    DashboardComponent,
    HomeComponent,
    LoginComponent
  ],
  imports: [
    ReactiveFormsModule,
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    SharedModule,
    MsAdalAngular6Module.forRoot(getAdalConfiguration()),
  ],
  providers: [AuthenticationGuard, {
    provide: HTTP_INTERCEPTORS,
    useClass: MsAdalInterceptor,
    multi: true
  }, HttpClientModule],
  bootstrap: [AppComponent]
})
export class AppModule { }
