import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { AuthService } from './auth.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
@Injectable({
    providedIn: 'root'
})
export class AuthGuardService implements CanActivate {
    constructor(public auth: AuthService, public router: Router, private msAdalService: MsAdalAngular6Service) { }
    canActivate(route: ActivatedRouteSnapshot): boolean {
        // console.log('isAuthenticated',this.msAdalService.isAuthenticated)
        // console.log('AuthGuard,',route.data.expectedRole)
        if (this.msAdalService.isAuthenticated) {
            return true
        }
        if (!this.auth.isAuthenticated()) {
            this.router.navigate(['/login']);
            return false;
        }
        return true;
    }
}