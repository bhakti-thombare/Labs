// src/app/auth/auth.service.ts
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    constructor() { }
    // ...
    public isAuthenticated(): boolean {
        const token = localStorage.getItem('UpdatedToken');
        if ((token != undefined && token != null)) {
            return true;
        } else {
            return false;
        }
    }
}
