import { Component, OnInit } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  showPassword= false;
  constructor(public router: Router, private msAdalService: MsAdalAngular6Service,) { }

  ngOnInit(): void {
    if (this.msAdalService.isAuthenticated) {
      console.log('Authenticated');
      this.router.navigate(['home']);
    }
  }

  login(){
    this.msAdalService.login();
    //this.router.navigate(['/home']);
  }
}
