import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router, CanActivate, ActivatedRouteSnapshot } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'utclBillGeneration';
  constructor(public router: Router){

  }
  ngOnInit(){
    // this.router.navigate(['/login']);
  }
}
