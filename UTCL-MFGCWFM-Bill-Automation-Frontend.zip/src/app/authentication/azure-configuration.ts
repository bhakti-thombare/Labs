// Configuration for the Azure Active Directory Authentication
// on website portal.azure.com under App registrations

export function getAdalConfiguration() {
    return {
        tenant: 'f87a5f5e-f97e-4aec-bab8-6e4187ef4f1c',                         // Tenanat ID
        clientId: '67c6e93c-5550-4ade-9461-1c212cc73960',                       // Client ID
        redirectUri: window.location.origin,                                    // http://localhost:4200
        endpoints: {
            'https://localhost:44328/Api/': '67c6e93c-5550-4ade-9461-1c212cc73960',    // Web API or Backend Api URL and Client ID
        },
        navigateToLoginRequestUrl: false,
        // Callback URL
        cacheLocation: 'localStorage',                    // Storage to store athenticated user details
    };
}
