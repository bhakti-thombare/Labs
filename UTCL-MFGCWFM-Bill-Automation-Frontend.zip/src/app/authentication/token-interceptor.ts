import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpResponse, HttpErrorResponse, HttpEvent } from '@angular/common/http';
import { mergeMap, catchError, tap } from 'rxjs/operators';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';

@Injectable()
export class MsAdalInterceptor implements HttpInterceptor {

    constructor(private msAdalService: MsAdalAngular6Service,
        private router: Router) { }

    tokenValue = null;
    createAuthorizationHeader(headers: Headers) {
        headers.append('Authorization', 'Basic ' +
            btoa('username:password'));
    }
    intercept(req: HttpRequest<any>, next: HttpHandler) {
        // console.log("interceptor Page");
        // get api url from adal config
        // console.log('localStorage.getItem(\'UpdatedToken\')', localStorage.getItem('UpdatedToken'));

        const resource = this.msAdalService.GetResourceForEndpoint(req.url);
        if (!resource || !this.msAdalService.isAuthenticated) {
            let splitUrl = req.url.split('?')[0];
            if (localStorage.getItem('UpdatedToken') != null && splitUrl != "https://www.utclconnect.com/AuthenticateApp/validateToken") {
                const authorizedRequest = req.clone({
                    headers: req.headers.set('Authorization', 'Bearer ' + localStorage.getItem('UpdatedToken')),
                });
                return next.handle(authorizedRequest);
            }
            return next.handle(req).pipe(tap(() => { },
                (err: any) => {
                    if (err instanceof HttpErrorResponse) {
                        if (err.status !== 401) {
                            return;
                        }
                        this.router.navigate(['login']);
                    }
                }));
        }
        if (localStorage.getItem('updatedtoken') != undefined) {
        }

        // if(localStorage.getItem('updatedtoken')!=null ||localStorage.getItem('updatedtoken')!=undefined){
        //     const authorizedRequest = req.clone({
        //         headers: req.headers.set('Authorization', 'Bearer' +localStorage.getItem('updatedtoken'))
        //         return next.handle(req);
        //     });
        // }
        // merge the bearer token into the existing headers
        return this.msAdalService.acquireToken(resource).pipe(
            mergeMap((token: string) => {
                // console.log('token', token);
                const authorizedRequest = req.clone({
                    headers: req.headers.set('Authorization', `Bearer ${token}`),
                });
                return next.handle(authorizedRequest);
            }));

    }
}
