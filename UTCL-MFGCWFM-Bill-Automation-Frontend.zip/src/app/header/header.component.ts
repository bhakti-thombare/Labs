import { Component, OnInit } from '@angular/core';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor(private msAdalService: MsAdalAngular6Service) { }

  ngOnInit(): void {
  }
  logOut() {
    // this.msAdalService.logout();
    if (this.msAdalService.isAuthenticated) {
      // console.log(localStorage.getItem('Storage'));
      this.msAdalService.logout();
      localStorage.clear();
      sessionStorage.clear();
      // this.router.navigate(['/login']);
    } else {
      localStorage.setItem('adal.login.request', 'http://localhost:4200/#/login');
      // console.log(localStorage.getItem('Storage'));
      this.msAdalService.logout();
      localStorage.clear();
      sessionStorage.clear();
    }
    // this.router.navigate(['/login']);
  }
}
