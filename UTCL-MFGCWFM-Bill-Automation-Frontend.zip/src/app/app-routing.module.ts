import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InvoiceComponent } from '../app/invoice/invoice.component';
import { DashboardComponent  } from '../app/dashboard/dashboard.component';
import { HomeComponent } from '../app/home/home.component';
import { AuthGuardService as AuthGuard } from './shared/auth-guard.service';

const routes: Routes = [
  { 
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard],
  },
  {
    path:'',
    component:DashboardComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', component: HomeComponent },
      { path: 'invoice', component: InvoiceComponent }
    ]
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
