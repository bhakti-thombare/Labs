const console = require("console");

console.trace("Testing....");

console.trace("No of emps: %d", 39);
