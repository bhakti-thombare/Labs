const number = Number(8);

console.log("Testing format specifiers");
console.log("I have %s complete %d HansdOn", "to", 3);
console.log("%o handson are completed", number);
