const oranges = ["orange", "orange"];

oranges.forEach((fruit) => {
  console.count(fruit);
});
