import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-faq-dashboard',
  templateUrl: './faq-dashboard.component.html',
  styleUrls: ['./faq-dashboard.component.scss']
})
export class FAQDashboardComponent implements OnInit, OnDestroy {

  currentUser: any;
  faqId: any;
  subscription: Subscription;
  selectedTab = 'Help and frequently asked questions';
  faqOptions = [
    { title: 'List', url: '/faq/list', selected: false },
    { title: 'New', url: '/faq/new', selected: false }
  ];
  currentRoute: any;
  constructor(
    private router: Router,
    private authService: AuthService,
    private activatedRoute: ActivatedRoute,
  ) {
    this.loadUser();

    this.subscription = router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      
      this.currentRoute = event.url;
      this.modifyUserTabs();
    });
  }


  ngOnInit() {

    this.faqId = this.activatedRoute.firstChild.snapshot.paramMap.get('id');
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  modifyUserTabs() {

    
    const faqId = this.activatedRoute.firstChild.snapshot.paramMap.get('id');
    


    if (this.currentUser.role === 'ADMIN') {  // food bank users
      if (!faqId) {
        this.faqOptions = [
          { title: 'List', url: '/faq/list', selected: false },
          { title: 'New', url: '/faq/new', selected: false }
        ];
      } else {
        this.faqOptions = [
          { title: 'List', url: '/faq/list', selected: false },
          { title: 'New', url: '/faq/new', selected: false },
          { title: 'Edit', url: '/faq/edit/' + faqId, selected: false },
          // { title: 'View', url: '/faq/view/' + faqId, selected: false }
        ];
      }
    } else {
      this.faqOptions = [
        { title: 'List', url: '/faq/list', selected: false }];
    }
    for (const option of this.faqOptions) {
      if (this.currentRoute.includes(option.url) || option.url.includes(this.currentRoute)) {
        
        this.selectedTab = this.getHeader(option.title);
      }
    }

  }

  tabSelected(url) {
    for (const option of this.faqOptions) {
      if (url.includes(option.url) || option.url.includes(url)) {
        this.selectedTab = this.getHeader(option.title);
        option.selected = true;
        this.router.navigateByUrl(url);
      } else {
        option.selected = false;
      }
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getHeader(option) {
    option = option.toString().toLowerCase();
    switch (option) {
      case 'list':
        return 'Help and frequently asked questions';
      case 'new':
        return 'Create FAQ';
      case 'edit':
        return 'Edit FAQ';
      case 'view':
        return 'View FAQ';
    }
  }

}
