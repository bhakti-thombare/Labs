import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FAQDashboardComponent } from './faq-dashboard.component';

describe('FAQDashboardComponent', () => {
  let component: FAQDashboardComponent;
  let fixture: ComponentFixture<FAQDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FAQDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FAQDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
