import { Component, OnInit } from '@angular/core';
import { GeneralService } from '../shared/services/general.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { NotificationService } from 'src/app/core/services/notification.service';
import { ViewChild } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-faq-list',
  templateUrl: './faq-list.component.html',
  styleUrls: ['./faq-list.component.scss']
})
export class FAQListComponent implements OnInit {
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  currentUser: any;

  faqList: any = [];
  pdfUrl: string;
  constructor(
    private authService: AuthService,
    private notificationService: NotificationService,
    private generalService: GeneralService
  ) { }

  ngOnInit() {
    this.loadUser();
    this.getFAQs();

  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }
  getFAQs() {
    this.generalService.getFAQs().subscribe(res => {
      this.pdfUrl = res.payload && res.payload.pdfUrl || null;
      this.faqList = res.payload && res.payload.faqList || [];
      for (const element of this.faqList) {
        element.collapsed = true;
      }
    });
  }


  deleteFAQ(faqId) {

    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: 'Are you sure that you want to perform this action?',
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {
          this.generalService.deleteFAQ(faqId).subscribe(res => {
            this.notificationService.showSuccess('FAQ deleted successfully.');
            this.getFAQs();
          });
        }
      },
    });
  }
  openPDF() {
    window.open(this.pdfUrl, '_blank');
  }
}
