import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  constructor(
    private restService: RestService
  ) { }

  baseUrl = environment.apiUrl;

  getFAQs() {
    return this.restService.fetch(`${this.baseUrl}​/api/v1/help/getAll`, undefined, true);
  }

  getFAQById(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/help/getById/${id}`, undefined, true);
  }

  createFAQ(data) {

    return this.restService.post(`${this.baseUrl}/api/v1/help/create`, data, undefined, true);
  }

  updateFAQ(data, id) {
    return this.restService.put(`${this.baseUrl}/api/v1/help/update/${id}`, data, undefined, true);
  }

  deleteFAQ(id) {
    return this.restService.delete(`${this.baseUrl}/api/v1/help/deleteById/${id}`, undefined, undefined, true);
  }


}
