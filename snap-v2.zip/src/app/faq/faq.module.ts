import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FAQRoutingModule } from './faq-routing.module';
import { FAQDashboardComponent } from './faq-dashboard/faq-dashboard.component';
import { FAQListComponent } from './faq-list/faq-list.component';
import { FAQFormComponent } from './faq-form/faq-form.component';
import { SharedModule } from '../shared/shared.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CollapseModule } from 'ngx-bootstrap/collapse';


@NgModule({
  declarations: [FAQDashboardComponent, FAQListComponent, FAQFormComponent],
  imports: [
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    CollapseModule.forRoot(),
    CommonModule,
    FAQRoutingModule
  ]
})
export class FAQModule { }
