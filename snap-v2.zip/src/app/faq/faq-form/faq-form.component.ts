import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-faq-form',
  templateUrl: './faq-form.component.html',
  styleUrls: ['./faq-form.component.scss']
})
export class FAQFormComponent implements OnInit {

  FAQForm: FormGroup;
  FAQId: any;
  FAQDetails: any;
  constructor(
    private notificationService: NotificationService,
    private generalService: GeneralService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.buildFAQForm();
    this.FAQId = this.activatedRoute.snapshot.paramMap.get('id');
    if (this.FAQId) {
      this.getFAQDetails();
    }
  }

  buildFAQForm() {
    this.FAQForm = this.formBuilder.group({
      question: ['', Validators.required],
      answer: ['', Validators.required],
      isPublic: [false]
    });
  }

  getFAQDetails() {
    this.generalService.getFAQById(this.FAQId).subscribe(res => {
      this.FAQDetails = res.payload;
      this.patchFAQDetails();
    });
  }

  patchFAQDetails() {
    this.FAQForm.patchValue({
      question: this.FAQDetails.question,
      answer: this.FAQDetails.answer,
      isPublic: this.FAQDetails.public
    });
  }

  submit() {
    if (this.checkValidity()) {
      const data = this.FAQForm.value;
      
      if (!this.FAQId) {
        this.generalService.createFAQ(data).subscribe(res => {
          this.notificationService.showSuccess('FAQ created successfully.');
          this.router.navigateByUrl('/faq/list');
        });
      } else {
        this.generalService.updateFAQ(data, this.FAQId).subscribe(res => {
          this.notificationService.showSuccess('FAQ updated successfully.');
          this.router.navigateByUrl('/faq/list');
        });
      }
    } else {
      this.notificationService.showError('Please fill mandatory fields.');
    }
  }

  checkValidity() {
    return this.FAQForm.valid;
  }
}
