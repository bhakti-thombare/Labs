import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FAQFormComponent } from './faq-form.component';

describe('FAQFormComponent', () => {
  let component: FAQFormComponent;
  let fixture: ComponentFixture<FAQFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FAQFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FAQFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
