import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FAQDashboardComponent } from './faq-dashboard/faq-dashboard.component';
import { FAQFormComponent } from './faq-form/faq-form.component';
import { FAQListComponent } from './faq-list/faq-list.component';


const routes: Routes = [
  {
    path: '', component: FAQDashboardComponent, children: [
      { path: 'list', component: FAQListComponent },
      { path: 'new', component: FAQFormComponent },
      { path: 'edit/:id', component: FAQFormComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FAQRoutingModule { }
