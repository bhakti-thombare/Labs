import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OfferRoutingModule } from './offer-routing.module';
import { OfferDashboardComponent } from './offer-dashboard/offer-dashboard.component';
import { OfferDetailFormComponent } from './offer-detail-form/offer-detail-form.component';
import { OfferListComponent } from './offer-list/offer-list.component';
import { SharedModule } from '../shared/shared.module';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { FormsModule } from '@angular/forms';
import { OfferConfirmShipmentFormComponent } from './offer-confirm-shipment-form/offer-confirm-shipment-form.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgSelectModule } from '@ng-select/ng-select';
import { DonationDetailsComponent } from './donation-details/donation-details.component';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { OfferDonationDetailsComponent } from './offer-donation-details/offer-donation-details.component';

@NgModule({
  declarations: [OfferDashboardComponent, OfferDetailFormComponent, OfferListComponent, OfferConfirmShipmentFormComponent, DonationDetailsComponent, OfferDonationDetailsComponent],
  imports: [
    TypeaheadModule.forRoot(),
    BsDatepickerModule.forRoot(),
    CollapseModule.forRoot(),
    NgSelectModule,
    FormsModule,
    CommonModule,
    SharedModule,
    OfferRoutingModule
  ]
})
export class OfferModule { }
