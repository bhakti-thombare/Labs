import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferConfirmShipmentFormComponent } from './offer-confirm-shipment-form.component';

describe('OfferConfirmShipmentFormComponent', () => {
  let component: OfferConfirmShipmentFormComponent;
  let fixture: ComponentFixture<OfferConfirmShipmentFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfferConfirmShipmentFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferConfirmShipmentFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
