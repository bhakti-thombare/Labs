import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GeneralService } from '../shared/general.service';

@Component({
  selector: 'app-offer-confirm-shipment-form',
  templateUrl: './offer-confirm-shipment-form.component.html',
  styleUrls: ['./offer-confirm-shipment-form.component.scss']
})
export class OfferConfirmShipmentFormComponent implements OnInit {
  offerId: string;
  currentUser: any;
  offerDetail: any =
    {
      feedOntarioId: '',
      productDescription: '',
      orgName: '',
      orgId: undefined,
      offerDate: null,
      comments: '',
      donationNotes: '',
      palletsAllocated: undefined,
      receivedQuantity: undefined,
      quality: '',
      weightPerPallet: undefined,
      report: undefined,
      notes: undefined,
      deliveryDate: new Date()
    };
  minDate = new Date();
  qualities = ['Excellent', 'Very good', 'Good', 'Fair', 'Poor'];
  reports = ['Wrong product', 'Never received', 'Refused'];
  currentFoodBank: any;
  donationWeight = 0;
  constructor(
    private notificationService: NotificationService,
    private utilityService: UtilityService,
    private generalService: GeneralService,
    private router: Router,
    private authService: AuthService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.loadUser();

    this.offerId = this.activatedRoute.snapshot.paramMap.get('id');

    if (this.offerId) {
      this.getAllocatedOfferDetails();
    }
  }

  getAllocatedOfferDetails() {
    this.generalService.getAllocatedOfferById(this.offerId).subscribe(res => {
      this.offerDetail = res.payload;
      this.donationWeight = this.offerDetail.donationWeightPerPallet;
      this.offerDetail.deliveryDate = this.offerDetail.deliveryDate || new Date();
    });

  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      this.currentFoodBank = {
        name: user.foodbank.name,
        id: user.foodbank.id
      };
    });
  }

  submit() {
    const data: any = {
      offerId: this.offerId,
      receivedQuantity: this.offerDetail.receivedQuantity,
      quality: (this.offerDetail.quality || '').toString().toLowerCase(),
      weightPerPallet: +this.offerDetail.weightPerPallet,
      report: (this.offerDetail.report || '').toString().toLowerCase(),
      notes: this.offerDetail.notes,
      status: 'CONFIRMED',
      deliveryDate: this.utilityService.convertToUtc(this.offerDetail.deliveryDate)
    };
    if (this.offerDetail.responseList && this.offerDetail.responseList.length) {
      data.childOrgList = this.offerDetail.responseList;
    }

    if (!this.checkValidity(data)) {
      return false;
    }
    if (this.donationWeight < data.weightPerPallet) {
      return false;
    }

    this.generalService.confirmShipment(data).subscribe(res => {
      this.notificationService.showSuccess('Shipment confirmed.');
      this.router.navigateByUrl('/home/shipment-confirmations');
    });
  }

  validateChildAllocatedQuantity(receivedQuantity) {
    let totalAllocatedQuantity = 0;
    for (const item of this.offerDetail.responseList) {
      totalAllocatedQuantity += item.allocatedQuantity;
    }
    if (totalAllocatedQuantity > receivedQuantity) {
      return false;
    }
    return true;
  }

  checkValidity(data) {
    if (!data.receivedQuantity || data.receivedQuantity === 0) {
      this.notificationService.showError('Please add valid received quantity.');
      return false;
    }
    // if (!data.weightPerPallet || data.weightPerPallet === 0) {
    //   this.notificationService.showError('Please add valid weight per pallet.');
    //   return false;
    // }
    if (this.offerDetail.receivedQuantity > this.offerDetail.palletsAllocated) {
      return false;
    }
    if (!data.quality) {
      this.notificationService.showError('Please select a quality.');
      return false;
    }
    if (this.offerDetail.responseList && this.offerDetail.responseList.length) {
      if (!this.validateChildAllocatedQuantity(data.receivedQuantity)) {
        this.notificationService.showError('Total allocated quantity should be less than received quantity.');
        return false;
      }
    }
    return true;
  }

  allowOnlyFloat(txt, event) {
    return this.utilityService.allowOnlyFloat(txt, event);
  }


  receiveQuantityChanged(abc, abcx) {


  }

  weightValueChanged(value) {

  }

  allowFloatOnly(allocatedQuantity, event) {
    return this.utilityService.allowOnlyFloat(allocatedQuantity, event);
  }

  isCharLengthValid(value, limit) {
    if (value && value.toString().length >= limit) {
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
  }
}
