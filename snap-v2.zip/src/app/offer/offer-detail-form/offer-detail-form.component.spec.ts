import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferDetailFormComponent } from './offer-detail-form.component';

describe('OfferDetailFormComponent', () => {
  let component: OfferDetailFormComponent;
  let fixture: ComponentFixture<OfferDetailFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfferDetailFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferDetailFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
