import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Observer, of } from 'rxjs';
import { filter, map, switchMap, tap } from 'rxjs/operators';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GeneralService } from '../shared/general.service';
import * as moment from 'moment';
import { NotificationService } from 'src/app/core/services/notification.service';
import { AuthService } from 'src/app/core/services/auth.service';
@Component({
  selector: 'app-offer-detail-form',
  templateUrl: './offer-detail-form.component.html',
  styleUrls: ['./offer-detail-form.component.scss']
})
export class OfferDetailFormComponent implements OnInit {

  foodBankSearch: any;
  foodBankSuggestions$: Observable<any>;
  selectedFoodBanks = [];
  errorMessage: any;
  offerDetail: any;
  offerId: string;
  sharedMoreThanRequest = false;
  totalSharedQuantity: number;
  shareBeforeRequest: boolean;
  removedFoodBanks = [];
  originalOfferDetail: any;
  disableOptions: boolean;
  currentUser: any;
  showFoodBankLoading = false;
  noFoodBankFound: any;
  selectedFoodbankIndex: any;
  offeredQuantity: any;


  constructor(
    private notificationService: NotificationService,
    private cdRef: ChangeDetectorRef,
    private utilityService: UtilityService,
    private generalService: GeneralService,
    private router: Router,
    private authService: AuthService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.addFoodBank();
    this.offerId = this.activatedRoute.snapshot.paramMap.get('id');
    this.offerDetail = {
      productDescription: '',
      source: { id: undefined, name: undefined },
      category: '',
      foodBank: '',
      offerDate: '',
      bbDate: '',
      deadline: '',
      quantityPallets: null,
      offeredQuantity: '',
      requestedQuantity: '',
      notes: null,
      sharedOrganization: [],
      donationDetails: undefined
    };
    this.loadUser();
    this.getFoodBankSuggestions();
    this.getOfferDetails();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  getOfferDetails() {
    this.generalService.getOfferById(this.offerId).subscribe(response => {
      if (typeof response.payload !== 'string') {
        const res = response.payload;
        this.offerDetail = res;
        this.offeredQuantity = this.offerDetail.allocationMethod === 'DIRECT_OFFER' ? this.offerDetail.offeredQuantity :
          (this.offerDetail.allocationMethod === 'FOOD_OFFER' ? this.offerDetail.quantityPallets : this.offerDetail.allocatedQuantity);


        this.originalOfferDetail = res;
        if (this.offerDetail.sharedOrganization && this.offerDetail.sharedOrganization.length) {
          this.selectedFoodBanks = this.formatSharedOrgResponse(this.offerDetail.sharedOrganization);
        }
        this.offerDetail.offerDate = res.offerDate && moment(res.offerDate).format('DD MMM') || '';
        this.offerDetail.bbDate = res.bbDate && moment(res.bbDate).format('DD MMM' || '');
        this.offerDetail.deadline = res.deadlineDate &&
          moment(this.utilityService.convertToLocalTimeZone(res.deadlineDate + ' UTC', 'MMMM DD YYYY, h:mm:ss a')).format('DD MMM, hh:mm a') || '';
        if (res.deadlineDate) {
          this.disableOptions = true;
        }
        this.isOfferExpired(this.utilityService.convertToLocalTimeZone(res.deadlineDate + ' UTC', 'MMMM DD YYYY, h:mm:ss a'));
        this.offerDetail.requestedQuantity = this.offerDetail.requestedQuantity ? this.offerDetail.requestedQuantity : null;
      }
    });
  }

  isOfferExpired(deadline) {



    this.disableOptions = moment(new Date()).isAfter(moment(deadline));
    if (!deadline || deadline === 'Invalid date') {
      this.disableOptions = true;
    }
  }


  getFoodBankSuggestions() {
    this.foodBankSuggestions$ = new Observable((observer: Observer<string>) => {
      observer.next(this.foodBankSearch);
    }).pipe(
      filter(query => this.foodBankSearch && this.foodBankSearch.toString().trim() && this.foodBankSearch.toString().trim().length > 2),
      switchMap((query: string) => {
        if (query) {
          return this.generalService.getFoodBanksByName({ name: query }).pipe(
            map((data: any) => this.filterSelctedFoodBanks(data) || []),
            tap((noop) => noop, err => {
              // in case of http error
              this.errorMessage = err && err.message || 'Something goes wrong';
            })
          );
        }

        return of([]);
      })
    );
  }

  filterSelctedFoodBanks(data) {
    let newList = data.payload;

    if (this.selectedFoodBanks[0].orgId) {
      const foodBankIds = [];
      for (const foodbank of this.selectedFoodBanks) {
        foodBankIds.push(foodbank.orgId);
      }
      newList = data.payload.filter(foodbank => !foodBankIds.includes(foodbank.id));
    }
    newList = newList.filter(foodbank => foodbank.id !== this.currentUser.foodbank.id);

    return newList;
  }
  foodBanks: any[] = [];
  submit(value) {
    this.foodBanks = JSON.parse(JSON.stringify(this.selectedFoodBanks));
    this.removeInvalidFoodBanks();
    this.foodBanks = JSON.parse(JSON.stringify(this.foodBanks));
    const data1 = {
      donationId: this.offerDetail.donationId,
      notes: this.offerDetail.notes,
      offerId: +this.offerId,
      requestedQuantity: +this.offerDetail.requestedQuantity,
      sharedOrganization: this.foodBanks.length === 1 && !this.foodBanks[0].orgId && !this.foodBanks[0].foodBank ? [] :
        (this.foodBanks.length === 1 && !this.foodBanks[0].orgId && this.foodBanks[0].foodBank ? [] : this.foodBanks),
      status: value
    };
    if (value === 'ACCEPTED') {
      if (this.checkValidity() && this.checkFoodBankValidity(data1.sharedOrganization)) {

        if (this.removedFoodBanks.length) {
          this.foodBanks = this.foodBanks.concat(this.removedFoodBanks);
        }
        if (this.foodBanks.length === 1) {
          if (!this.foodBanks[0].orgId && !this.foodBanks[0].foodBank) {
            this.foodBanks = [];
          }
        }

        console.log('data1', data1)


        data1.sharedOrganization = this.removeUnsavedFoodBanks(this.foodBanks);

        this.generalService.handleOffer(data1).subscribe(res => {
          this.notificationService.showSuccess('Offer accepted.');
          this.router.navigateByUrl('home/current-offers');
        });
      }
    } else {
      this.removeInvalidFoodBanks();
      this.foodBanks = JSON.parse(JSON.stringify(this.foodBanks));
      if (this.removedFoodBanks.length) {
        this.foodBanks = this.foodBanks.concat(this.removedFoodBanks);
      }
      this.foodBanks = this.removeUnsavedFoodBanks(this.foodBanks);
      const data2 = {
        donationId: this.offerDetail.donationId,
        notes: this.offerDetail.notes,
        offerId: +this.offerId,
        requestedQuantity: +this.offerDetail.requestedQuantity,
        sharedOrganization: this.foodBanks,
        status: value
      };
      this.generalService.handleOffer(data2).subscribe(res => {
        this.notificationService.showSuccess('Offer declined.');
        this.router.navigateByUrl('home/current-offers');
      });
    }
  }

  checkValidity() {
     if (!this.offerDetail.requestedQuantity || this.offerDetail.requestedQuantity === 0) {
      this.notificationService.showError('Pallet requested cannot be zero or empty.');
      return false;
    }
    this.noFoodBankFound = false;

    for (const element of this.foodBanks) {
      if (!element.orgId) {
        this.noFoodBankFound = true;
        break;
      }
    }
    if (this.noFoodBankFound) {
      return false;
    }
    if (this.offerDetail.requestedQuantity) {
      if (this.offerDetail.requestedQuantity > this.offeredQuantity) {
        return false;
      }
      if (this.offerDetail.requestedQuantity < this.totalSharedQuantity) {
        return false;
      }
    } else {
      return false;
    }
    return true;
  }

  checkFoodBankValidity(list) {
    console.log('this.selectedFoodBanks', this.selectedFoodBanks)
    // if (this.selectedFoodBanks.length === 1) {
    //   return true;
    // }
    for (const element of list) {
      if (element.orgId === undefined) {
        this.notificationService.showError('Please select valid food bank.');


        return false;
        break;
      }
    }
    for (const element of list) {

      if (element.foodBank) {
        if (!element.quantity || element.quantity === 0) {
          this.notificationService.showError('Shared quantity cannot be zero or left blank.');


          return false;
          break;
        }
      }
    }
    if (list && list.length) {
      this.sharedQuantityChanged(list[0].quantity, 0);
      if (this.sharedMoreThanRequest) {
        return false;
      }
    }
    return true;
  }

  triggerSearch(text, i) {

    this.foodBankSearch = text;
    this.selectedFoodbankIndex = i;
    if (!text) {
      if (this.selectedFoodBanks.length > 1) {
        // this.selectedFoodBanks.splice(i, 1);
      } else {
        // this.selectedFoodBanks[i].orgId = undefined;
        // this.selectedFoodBanks[i].foodBank = undefined;
        // this.selectedFoodBanks[i].quantity = undefined;
        
        this.selectedFoodBanks[i].delete = true;

      }
    }
  }

  onFoodBankSelected(event, index) {

    this.selectedFoodBanks[index].orgId = event.item.id;

  }

  foodBankChangeTypeaheadLoading(event) {

    this.showFoodBankLoading = event;
  }

  foodBankTypeaheadNoResults(event, i) {


    if (!this.showFoodBankLoading) {
      this.noFoodBankFound = event;
    }
    if (event) {
      this.selectedFoodBanks[i].orgId = undefined;
    }
    if (!this.foodBankSearch) {
      this.noFoodBankFound = false;
    }
  }

  onlyNumberKey(event) {
    return this.utilityService.onlyNumberKey(event);
  }

  addFoodBank() {
    this.selectedFoodBanks.push({
      foodBank: undefined,
      quantity: undefined,
      orgId: undefined,
      delete: false
    });
  }

  removeFoodBank(index) {
    // debugger;
    this.sharedQuantityChanged(0, index);
    this.selectedFoodBanks[index].delete = true;
    this.removedFoodBanks.push(this.selectedFoodBanks[index]);
    
    this.selectedFoodBanks.splice(index, 1);
  }

  sharedQuantityChanged(event?, index?) {
    // debugger;
    if(event !== null)
    this.selectedFoodBanks[index].quantity = +(+event.toFixed(2));
    console.log(event);
    console.log(index);
    
    
    let tempValue = 0;
    console.log('this.selectedFoodBanks', this.selectedFoodBanks)
    for (const element of this.selectedFoodBanks) {
      tempValue = +(+tempValue + +element.quantity || 0).toFixed(2);
    }
    console.log('tempValue', tempValue)

    this.totalSharedQuantity = tempValue;

    if (!this.offerDetail.requestedQuantity && tempValue) {
      this.shareBeforeRequest = true;
    } else {
      this.shareBeforeRequest = false;
    }
    if (this.offerDetail.requestedQuantity && this.offerDetail.requestedQuantity < tempValue) {
      this.sharedMoreThanRequest = true;
    } else {
      this.sharedMoreThanRequest = false;
    }
    this.cdRef.detectChanges();
  }

  requestQuantityChanged(event) {

    this.offerDetail.requestedQuantity = +event;
    let tempValue = 0;
    for (const element of this.selectedFoodBanks) {
      tempValue = tempValue + element.quantity || 0;
    }
    if (!this.offerDetail.requestedQuantity && tempValue) {
      this.shareBeforeRequest = true;
    } else {
      this.shareBeforeRequest = false;
    }
    if (this.offerDetail.requestedQuantity && this.offerDetail.requestedQuantity < tempValue) {
      this.sharedMoreThanRequest = true;
    } else {
      this.sharedMoreThanRequest = false;
    }
  }
  removeInvalidFoodBanks() {
    const tempArr = JSON.parse(JSON.stringify(this.foodBanks));
    let i = 0;
    for (const element of tempArr) {
      if (!element.orgId && element.orgId !== 0) {
        console.log('here', i);
        this.foodBanks.splice(i, 1);
      }
      i++;
    }
    console.log('this.selectedFoodBanks', this.foodBanks)
  }

  removeUnsavedFoodBanks(sharedOrgs) {
    const tempArr = [];
    for (const org of sharedOrgs) {
      if (!org.id && !org.quantity && org.delete) {

      } else {
        tempArr.push(org);
      }
    }
    return tempArr;
  }
  allowOnlyFloat(txt, event) {
    return this.utilityService.allowOnlyFloat(txt, event);
  }

  formatSharedOrgData(foodBanks) {
    if (foodBanks && foodBanks.length) {
      for (const element of foodBanks) {
        element.foodBank = element.orgId;
        delete element.orgId;
      }
    }
    return foodBanks;
  }
  formatSharedOrgResponse(sharedOrgs) {
    const tempArr = [];
    if (sharedOrgs && sharedOrgs.length) {
      for (const element of sharedOrgs) {
        tempArr.push({
          foodBank: element.foodBank.name,
          orgId: element.foodBank.id,
          quantity: element.quantity,
          id: element.id
        });
      }
    }
    return tempArr;
  }
  isCharLengthValid(value, limit) {
    if (value && value.toString().length >= limit) {
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
  }
}
