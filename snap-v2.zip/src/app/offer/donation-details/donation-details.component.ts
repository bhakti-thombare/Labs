import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GeneralService } from '../shared/general.service';

@Component({
  selector: 'app-donation-details',
  templateUrl: './donation-details.component.html',
  styleUrls: ['./donation-details.component.scss']
})
export class DonationDetailsComponent implements OnInit {
  isDonationDetailsCollapsed = false;
  donationDetail: any;
  donationId: string;
  showDetailsPage = false;
  constructor(
    private utilityService: UtilityService,
    private generalService: GeneralService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.donationId = this.activatedRoute.snapshot.paramMap.get('id');
    this.getDonationDetails();
  }

  getDonationDetails() {
    this.generalService.getDonationById(this.donationId).subscribe(res => {
      this.donationDetail = res;
      this.showDetailsPage = true;
      // Sun, 2 January 2022 08:00 AM
      this.donationDetail.deadlineDate = this.donationDetail.deadlineDate &&
        this.utilityService.convertToLocalTimeZone(new Date(this.donationDetail.deadlineDate + ' UTC'), 'ddd, DD MMMM YYYY hh:mm A') || undefined;
      
    });
  }
}
