import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DonationDetailsComponent } from './donation-details/donation-details.component';
import { OfferConfirmShipmentFormComponent } from './offer-confirm-shipment-form/offer-confirm-shipment-form.component';
import { OfferDashboardComponent } from './offer-dashboard/offer-dashboard.component';
import { OfferDetailFormComponent } from './offer-detail-form/offer-detail-form.component';
import { OfferDonationDetailsComponent } from './offer-donation-details/offer-donation-details.component';
import { OfferListComponent } from './offer-list/offer-list.component';


const routes: Routes = [
  {
    path: '', component: OfferDashboardComponent, children: [
      { path: '', redirectTo: 'list', pathMatch: 'full' },
      { path: 'list', component: OfferListComponent },
      { path: 'details-form/:id', component: OfferDetailFormComponent },
      { path: 'confirm-shipment/:id', component: OfferConfirmShipmentFormComponent },
      { path: 'donation-details/:id', component: DonationDetailsComponent },
      { path: 'offer-details/:id', component: OfferDonationDetailsComponent }

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OfferRoutingModule { }
