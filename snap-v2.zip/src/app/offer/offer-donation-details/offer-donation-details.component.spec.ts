import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferDonationDetailsComponent } from './offer-donation-details.component';

describe('OfferDonationDetailsComponent', () => {
  let component: OfferDonationDetailsComponent;
  let fixture: ComponentFixture<OfferDonationDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfferDonationDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferDonationDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
