import { Component, OnInit } from '@angular/core';
import { GeneralService } from '../shared/general.service';
import { ActivatedRoute, Router } from '@angular/router';
import { UtilityService } from 'src/app/core/services/utility.service';

@Component({
  selector: 'app-offer-donation-details',
  templateUrl: './offer-donation-details.component.html',
  styleUrls: ['./offer-donation-details.component.scss']
})
export class OfferDonationDetailsComponent implements OnInit {
  offerId: string;
  offerDetail: any;

  constructor(
    private utilityService: UtilityService,
    private generalService: GeneralService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.offerId = this.activatedRoute.snapshot.paramMap.get('id');
    this.getOfferById();
  }

  getOfferById() {
    this.generalService.getOfferById(this.offerId).subscribe(response => {
      if (typeof response.payload !== 'string') {
        const res = response.payload;
        this.offerDetail = res;
        this.offerDetail.deadlineDate = this.offerDetail.deadlineDate &&
          this.utilityService.convertToLocalTimeZone(this.offerDetail.deadlineDate, 'ddd, MMMM D YYYY, hh:mm a') || 'NA';
      }

    });
  }

}
