import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  baseUrl = environment.apiUrl;
  constructor(private restService: RestService) { }

  submitOffer(data) {
    return this.restService.post(`${this.baseUrl}`, data, undefined, true);
  }

  getOfferById(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/offer/${id} `, undefined, true);
  }

  getDonationById(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donor/getDonationById/${id}`, undefined, true);
  }

  updateDonation(data, id) {
    return this.restService.put(`${this.baseUrl}​​/api/v1/donor/edit-donationForm/${id}`, data, undefined, true);
  }

  // get all
  getFoodBanksByName(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/foodbank/profile/byName`, data, { hideLoader: true }, true);
  }

  // accept or decline offer by foodbank
  handleOffer(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/foodbank/offerAction`, data, undefined, true);
  }

  getAllocatedOfferById(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/shipment/allocated-offers/offer/${id}`, undefined, true);
  }

  confirmShipment(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/shipment/confirm`, data, undefined, true);
  }
}
