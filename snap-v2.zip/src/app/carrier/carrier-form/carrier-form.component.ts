import { ChangeDetectorRef, Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { combineLatest, Subscription } from 'rxjs';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-carrier-form',
  templateUrl: './carrier-form.component.html',
  styleUrls: ['./carrier-form.component.scss']
})
export class CarrierFormComponent implements OnInit {
   public lettersOnlyCustomPatterns = {'S': { pattern: new RegExp('\[a-zA-Z \]')}};
  //  public numbersOnlycustomPatterns = {'0': { pattern: new RegExp('^[0-9 ]*$')}};
   public lettersAndNumbersCustomPatterns = {'A': { pattern: new RegExp('\[a-zA-Z0-9 \]')}};
   
  selectedContactIndex: number;
  carrierForm: FormGroup;
  modalRef: BsModalRef;
  contactMustUniqueEmail = false;
  carrierId: any;
  isEdit = false;
  countries = this.utilityService.countries;
  emailPattern = this.utilityService.emailPattern;
  deletedContacts = [];
  carrierDetail = {
    id: '',
    name: '',
    notes: '',
    contacts: [],
    locations: []
  };
  selectedLocationIndex: number;
  deletedLocations = [];
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  subscriptions: Subscription[] = [];
  messages: string[] = [];


  constructor(
    private router: Router,
    private generalService: GeneralService,
    private activatedRoute: ActivatedRoute,
    private utilityService: UtilityService,
    private modalService: BsModalService,
    private notificationService: NotificationService,
    private formBuilder: FormBuilder,
    private changeDetection: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.carrierId = this.activatedRoute.snapshot.paramMap.get('id');
    this.buildCarrierForm();
    if (this.carrierId) {
      this.isEdit = true;
      this.getCarrierDetails();
    }
  }

  getCarrierDetails() {
    this.generalService.getCarrierById(this.carrierId).subscribe(res => {
      this.patchCarrierDataFromResponse(res.payload);
    });
  }

  patchCarrierDataFromResponse(carrierData) {
    this.carrierDetail.id = carrierData.id;
    this.carrierDetail.name = carrierData.name;
    this.carrierDetail.notes = carrierData.notes;
    this.carrierDetail.contacts = this.getResponseContacts(carrierData.contact);
    this.carrierDetail.locations = this.getResponseLocations(carrierData.locations);
    this.patchCarrierForm();

  }
  getResponseContacts(contacts) {
    const tempContacts = [];
    for (const contact of contacts) {
      tempContacts.push({
        id: contact.id,
        // title: contact.ctitle,
        name: contact.cname,
        phone: contact.cphone,
        email: contact.cemail,
        deleted: contact.deleted || false
      });
    }
    return tempContacts;
  }

  getResponseLocations(locations) {
    const tempLocations = [];
    for (const location of locations) {
      tempLocations.push({
        id: location.id,
        locationName: location.locationName,
        street: location.street,
        city: location.city,
        province: location.province,
        postalCode: location.postalCode,
        country: location.country,
        phone: location.phone,
        // fax: location.fax,
        deleted: location.deleted || false
      });
    }
    return tempLocations;
  }
  buildCarrierForm() {
    this.carrierForm = this.formBuilder.group({
      name: ['', Validators.required],
      notes: [''],
      contacts: this.formBuilder.array([]),
      locations: this.formBuilder.array([])
    });

    this.carrierForm.get('contacts').valueChanges.subscribe(contacts => {
      if (contacts.length > 1) {
        if (this.carrierForm.get('contacts').valid) {

          if (this.isEmailUnique(contacts)) {
            this.contactMustUniqueEmail = false;
          } else {
            this.contactMustUniqueEmail = true;
          }
        }
      }

    });
  }

  buildContactForm() {
    return this.formBuilder.group({
      // title: ['', Validators.required],
      name: ['', Validators.required],
      phone: ['', Validators.required],
      email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      deleted: [false]
    });
  }

  isEmailUnique(arr) {
    const tmpArr = [];
    if (arr.length) {
      for (const obj in arr) {

        if (tmpArr.indexOf(arr[obj].email) < 0) {
          tmpArr.push(arr[obj].email);
        } else {
          return false;
        }

      }
    }
    return true;
  }

  addContact(template) {
    // if (this.carrierForm.value.contacts.length >= 3) {
    //   this.notificationService.showError('More than 3 contacts cannot be added.');
    // } else {
    (this.carrierForm.get('contacts') as FormArray).push(this.buildContactForm());
    this.selectedContactIndex = (this.carrierForm.get('contacts') as FormArray).length - 1;
    this.openContactModal(template);
    // }
  }

  removeContact(i) {
    const contact: any = (this.carrierForm.get('contacts') as FormArray).at(i);

    this.deletedContacts.push(
      {
        id: this.carrierDetail.contacts[i].id,
        name: contact.get('name').value,
        phone: contact.get('phone').value,
        email: contact.get('email').value,
        // title: contact.get('title').value,
        deleted: true
      }
    );
    this.carrierDetail.contacts.splice(i, 1);
    (this.carrierForm.get('contacts') as FormArray).removeAt(i);
  }
  saveContactData(i) {
    if (this.checkFormValidity(i, 'contacts')) {
      this.selectedContactIndex = i;
      const element = (this.carrierForm.get('contacts') as FormArray).at(this.selectedContactIndex).value;
      if (this.carrierDetail.contacts[this.selectedContactIndex]) {
        const data = this.carrierDetail.contacts[this.selectedContactIndex];
        // data.title = element.title;
        data.phone = element.phone;
        data.email = element.email;
        data.name = element.name;
        data.deleted = false;
      } else {
        this.carrierDetail.contacts.push({
          // title: element.title,
          phone: element.phone,
          email: element.email,
          name: element.name,
          deleted: false
        });

      }
      this.closeModal();

    }
  }

  editContact(index, template) {
    this.selectedContactIndex = index;

    this.openContactModal(template);
  }

  checkFormValidity(i, formName) {
    const form: FormGroup = ((this.carrierForm.get(formName) as FormArray).at(i) as FormGroup);
    if (form.invalid) {
      this.turnFormControlsDirty(form);
      this.notificationService.showError('Please fill in the mandatory fields with valid data.');
      return false;
    }
    if (formName === 'contacts') {
      if (this.contactMustUniqueEmail) {
        this.notificationService.showError('Please make sure emails are unique accross all the contacts');
        return false;
      }
    }
    return true;
  }

  turnFormControlsDirty(form) {
    this.utilityService.turnFormControlsDirty(form);
  }

  openContactModal(template: TemplateRef<any>) {

    const combine = combineLatest(
      this.modalService.onShow,
      this.modalService.onShown,
      this.modalService.onHide,
      this.modalService.onHidden
    ).subscribe(() => this.changeDetection.markForCheck());

    this.subscriptions.push(
      this.modalService.onHide.subscribe((reason: string | any) => {

        this.closeModal('REMOVE_CONTACT');
        this.unsubscribe();
      })
    );


    this.subscriptions.push(combine);
    this.modalRef = this.modalService.show(template);
  }

  unsubscribe() {

    this.subscriptions.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
    this.subscriptions = [];
  }

  closeModal(value?) {

    if (value && value === 'REMOVE_LOCATION') {
      const locationLength = this.carrierDetail.locations.length;
      const formLocationLength = (this.carrierForm.get('locations') as FormArray).length;
      if (locationLength < formLocationLength) {
        (this.carrierForm.get('locations') as FormArray).removeAt(formLocationLength - locationLength);
      }
    }

    if (value && value === 'REMOVE_CONTACT') {
      const contactLength = this.carrierDetail.contacts.length;
      const formContactLength = (this.carrierForm.get('contacts') as FormArray).length;
      if (contactLength < formContactLength) {
        (this.carrierForm.get('contacts') as FormArray).removeAt(formContactLength - contactLength);
      }
    }
    (this.carrierForm.get('contacts') as FormArray).clear();
    (this.carrierForm.get('locations') as FormArray).clear();
    this.patchCarrierContactsForm();
    this.patchCarrierLocationsForm();

    if (this.modalRef) {
      this.modalRef.hide();
    }
  }


  patchCarrierForm() {

    this.carrierForm.patchValue({
      name: this.carrierDetail.name,
      notes: this.carrierDetail.notes
    });
    this.patchCarrierContactsForm();
    this.patchCarrierLocationsForm();
  }

  patchCarrierContactsForm() {
    const tempContacts = [];
    this.carrierDetail.contacts.forEach(element => {
      tempContacts.push({
        name: element.name,
        // title: element.title,
        phone: element.phone,
        email: element.email,
        deleted: element.deleted
      });
      (this.carrierForm.get('contacts') as FormArray).push(this.buildContactForm());
    });
    this.carrierForm.get('contacts').patchValue(tempContacts);

  }

  patchCarrierLocationsForm() {
    const tempLocations = [];
    this.carrierDetail.locations.forEach(element => {
      tempLocations.push({
        locationName: element.locationName,
        street: element.street,
        city: element.city,
        postalCode: element.postalCode,
        province: element.province,
        country: element.country,
        phone: element.phone,
        // fax: element.fax,
        deleted: element.deleted
      });
      (this.carrierForm.get('locations') as FormArray).push(this.buildLocationForm());
    });
    this.carrierForm.get('locations').patchValue(tempLocations);
  }


  buildLocationForm() {
    return this.formBuilder.group({
      locationName: ['', Validators.required],
      street: ['', Validators.required],
      city: ['', Validators.required],
      province: ['Ontario', Validators.required],
      postalCode: ['', Validators.required],
      country: ['Canada', Validators.required],
      phone: ['', Validators.required],
      // fax: ['', Validators.required],
      deleted: [false]
    });
  }

  addLocation(template) {
    // if (this.carrierDetail.locations.length >= 3) {
    //   this.notificationService.showError('More than 3 locations cannot be added');
    // } else {
    (this.carrierForm.get('locations') as FormArray).push(this.buildLocationForm());
    this.selectedLocationIndex = (this.carrierForm.get('locations') as FormArray).length - 1;
    this.openLocationModal(template);
    // }
  }

  editLocation(index, template) {
    this.selectedLocationIndex = index;

    this.openLocationModal(template);
  }

  openLocationModal(template: TemplateRef<any>) {
    const combine = combineLatest(
      this.modalService.onShow,
      this.modalService.onShown,
      this.modalService.onHide,
      this.modalService.onHidden
    ).subscribe(() => this.changeDetection.markForCheck());

    this.subscriptions.push(
      this.modalService.onHide.subscribe((reason: string | any) => {

        this.closeModal('REMOVE_LOCATION');
        this.unsubscribe();
      })
    );
    this.modalRef = this.modalService.show(template, { ignoreBackdropClick: true });
  }

  saveLocationData(i) {
    if (this.checkFormValidity(i, 'locations')) {
      this.selectedLocationIndex = i;
      const element = (this.carrierForm.get('locations') as FormArray).at(this.selectedLocationIndex).value;
      if (this.carrierDetail.locations[this.selectedLocationIndex]) {
        const data = this.carrierDetail.locations[this.selectedLocationIndex];
        data.locationName = element.locationName;
        data.street = element.street;
        data.city = element.city;
        data.province = element.province;
        data.postalCode = element.postalCode;
        data.country = element.country;
        data.phone = element.phone;
        // data.fax = element.fax;
        data.deleted = false;
      } else {
        this.carrierDetail.locations.push({
          locationName: element.locationName,
          street: element.street,
          city: element.city,
          province: element.province,
          postalCode: element.postalCode,
          country: element.country,
          phone: element.phone,
          // fax: element.fax,
          deleted: false
        });

      }
      this.closeModal();
    }
  }

  removeLocation(i) {
    const location: any = (this.carrierForm.get('locations') as FormArray).at(i);
    this.deletedLocations.push({
      id: this.carrierDetail.locations[i].id,
      locationName: location.get('locationName').value,
      street: location.get('street').value,
      city: location.get('city').value,
      province: location.get('province').value,
      postalCode: location.get('postalCode').value,
      country: location.get('country').value,
      phone: location.get('phone').value,
      // fax: location.get('fax').value,
      deleted: true
    });
    this.carrierDetail.locations.splice(i, 1);
    (this.carrierForm.get('locations') as FormArray).removeAt(i);
  }


  onlyNumberKey(event) {
    return this.utilityService.onlyNumberKey(event);
  }

  submit() {
    if (this.checkValidity()) {
      const data: any = {
        id: this.carrierDetail.id,
        name: this.carrierForm.value.name,
        notes: this.carrierForm.value.notes,
        contact: this.getContacts(),
        locations: this.getLocations()
      };
      data.deleted = false;

      if (!this.carrierId) {
        this.generalService.createCarrier(data).subscribe(res => {
          this.notificationService.showSuccess('Carrier created successfully.');
          this.router.navigateByUrl('/carrier/list');
        });
      } else {
        this.generalService.updateCarrier(data, this.carrierId).subscribe(res => {
          this.router.navigateByUrl('/carrier/list');
          this.notificationService.showSuccess('Carrier update successfully.');
        });
      }
    } else {
      this.notificationService.showError('Please make sure all mandatory fields have valid data.');
    }
  }


  getContacts() {
    const tempContacts = [];
    for (const contact of this.carrierDetail.contacts) {
      const data: any = {
        // ctitle: contact.title,
        cname: contact.name,
        cphone: contact.phone,
        cemail: contact.email,
        deleted: contact.deleted
      };
      if (contact.id) {
        data.id = contact.id;
      }
      tempContacts.push(data);
    }
    for (const deletedContact of this.deletedContacts) {
      const data: any = {
        // ctitle: deletedContact.title,
        cname: deletedContact.name,
        cphone: deletedContact.phone,
        cemail: deletedContact.email,
        deleted: deletedContact.deleted
      };
      if (deletedContact.id) {
        data.id = deletedContact.id;
      }
      tempContacts.push(data);
    }
    return tempContacts;
  }

  getLocations() {
    const tempLocations = [];
    for (const location of this.carrierDetail.locations) {
      const data: any = {
        locationName: location.locationName,
        street: location.street,
        city: location.city,
        province: location.province,
        postalCode: location.postalCode,
        country: location.country,
        phone: location.phone,
        // fax: location.fax,
        deleted: location.deleted
      };
      if (location.id) {
        data.id = location.id;
      }
      tempLocations.push(data);
    }
    for (const deletedLocation of this.deletedLocations) {
      const data: any = {
        locationName: deletedLocation.locationName,
        street: deletedLocation.street,
        city: deletedLocation.city,
        province: deletedLocation.province,
        postalCode: deletedLocation.postalCode,
        country: deletedLocation.country,
        phone: deletedLocation.phone,
        // fax: deletedLocation.fax,
        deleted: deletedLocation.deleted
      };
      if (deletedLocation.id) {
        data.id = deletedLocation.id;
      }
      tempLocations.push(data);

    }
    return tempLocations;
  }


  checkValidity() {
    console.log('this.carrierForm', this.carrierForm)
    if (this.carrierForm.valid) {

      let isContactEmpty = true;
      let isLocationEmpty = true;
      if (this.carrierForm.get('contacts').value && this.carrierForm.get('contacts').value.length) {
        for (const item of this.carrierForm.get('contacts').value) {
          if (!item.deleted) {
            isContactEmpty = false;
            break;
          }
        }
      }

      if (isContactEmpty) {
        return false;
      }

      if (this.carrierForm.get('locations').value && this.carrierForm.get('locations').value.length) {
        for (const item of this.carrierForm.get('locations').value) {
          if (!item.deleted) {
            isLocationEmpty = false;
            break;
          }
        }
      }

      if (isLocationEmpty) {
        return false;
      }
      return true;
    } else {
      return this.carrierForm.valid;
    }
  }
  deleteCarrier() {

    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: 'Are you sure that you want to perform this action?',
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to deleted
        if (result) {
          this.generalService.deleteCarrier(this.carrierId).subscribe(res => {
            this.notificationService.showSuccess('Carrier deleted successfully.');
            this.router.navigateByUrl('/carrier/list');
          });
        }
      },
    });
  }
  lettersOnly(event, field?, limit?) {
    if (field && field === 'name') {
      if (this.carrierForm.get(field).value.length >= limit) {
        // debugger;
        this.notificationService.showError('Only ' + limit + ' characters allowed.');
      }
    }
    // return this.utilityService.lettersOnly(event);
    if(this.utilityService.lettersOnly(event)){
      return true;
    }
    else{
      this.notificationService.showError('Only letters are allowed.');
      return false;
    }
  }
  numbersAndLettersOnly(event) {
    if (this.utilityService.onlyNumberKey(event) || this.utilityService.lettersOnly(event)) {
      return true;
    } else {
      return false;
    }
  }
  isCharLengthValid(value, limit, event?) {
    if (value && value.toString().length >= limit) {
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
    if (event) {
      if (this.utilityService.onlyNumberKey(event) || this.utilityService.lettersOnly(event)) {
        return true;
      } else {
        this.notificationService.showError('Only numbers and letters are allowed.');
        return false;
      }
    }
  }
}
