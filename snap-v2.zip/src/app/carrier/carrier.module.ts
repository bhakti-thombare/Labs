import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CarrierRoutingModule } from './carrier-routing.module';
import { CarrierDashboardComponent } from './carrier-dashboard/carrier-dashboard.component';
import { CarrierListComponent } from './carrier-list/carrier-list.component';
import { CarrierDetailsComponent } from './carrier-details/carrier-details.component';
import { CarrierFormComponent } from './carrier-form/carrier-form.component';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';

import { NgxMaskModule, IConfig } from "ngx-mask";

export const options: Partial<IConfig> | (() => Partial<IConfig>) = null;

@NgModule({
  declarations: [CarrierDashboardComponent, CarrierListComponent, CarrierDetailsComponent, CarrierFormComponent],
  imports: [
    NgSelectModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    CarrierRoutingModule,
    NgxMaskModule.forRoot()
  ]
})
export class CarrierModule { }
