import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-carrier-details',
  templateUrl: './carrier-details.component.html',
  styleUrls: ['./carrier-details.component.scss']
})
export class CarrierDetailsComponent implements OnInit {
  carrierId: any;
  carrierDetails: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private generalService: GeneralService,
  ) { }

  ngOnInit() {
    this.carrierId = this.activatedRoute.snapshot.paramMap.get('id');
    this.getCarrierDetails();
  }

  getCarrierDetails() {
    this.generalService.getCarrierById(this.carrierId).subscribe(res => {
      this.carrierDetails = res.payload;
    });
  }
}
