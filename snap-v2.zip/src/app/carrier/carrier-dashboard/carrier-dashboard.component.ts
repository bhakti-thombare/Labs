import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-carrier-dashboard',
  templateUrl: './carrier-dashboard.component.html',
  styleUrls: ['./carrier-dashboard.component.scss']
})
export class CarrierDashboardComponent implements OnInit, OnDestroy {
  currentUser: any;
  carrierId: any;
  subscription: Subscription;
  selectedTab = 'Carriers';
  carrierTabOptions = [
    { title: 'List', url: '/carrier/list', selected: true },
    { title: 'New', url: '/carrier/new', selected: false }
  ];
  currentRoute: any;
  constructor(
    private router: Router,
    private authService: AuthService,
    private activatedRoute: ActivatedRoute,
  ) {

    this.subscription = router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.currentRoute = event.url;
      this.modifyUserTabs();
    });
  }

  ngOnInit() {
    this.carrierId = this.activatedRoute.firstChild.snapshot.paramMap.get('id');
    this.loadUser();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  modifyUserTabs() {

    const carrierId = this.activatedRoute.firstChild.snapshot.paramMap.get('id');
    if (this.currentUser && this.currentUser.role.toString().toLowerCase() === 'admin') {

      if (!carrierId) {
        this.carrierTabOptions = [
          { title: 'List', url: '/carrier/list', selected: false },
          { title: 'New', url: '/carrier/new', selected: false }
        ];
      } else {
        this.carrierTabOptions = [
          { title: 'List', url: '/carrier/list', selected: false },
          { title: 'New', url: '/carrier/new', selected: false },
          { title: 'Edit', url: '/carrier/edit/' + carrierId, selected: false },
          { title: 'View', url: '/carrier/view/' + carrierId, selected: false }
        ];
      }

      for (const option of this.carrierTabOptions) {
        if (this.currentRoute.includes(option.url) || option.url.includes(this.currentRoute)) {
          this.selectedTab = this.getHeader(option.title);
        }
      }
    }
  }

  tabSelected(url) {
    for (const option of this.carrierTabOptions) {
      if (url.includes(option.url) || option.url.includes(url)) {
        this.selectedTab = this.getHeader(option.title);
        option.selected = true;
        this.router.navigateByUrl(url);
      } else {
        option.selected = false;
      }
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getHeader(option) {
    option = option.toString().toLowerCase();
    switch (option) {
      case 'list':
        return 'Carriers';
      case 'new':
        return 'Create carrier';
      case 'edit':
        return 'Edit carrier';
      case 'view':
        return 'Carrier details';
    }
  }


}
