import { Component, OnInit } from '@angular/core';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-carrier-list',
  templateUrl: './carrier-list.component.html',
  styleUrls: ['./carrier-list.component.scss']
})
export class CarrierListComponent implements OnInit {
  carrierList = [];

  constructor(
    private notificationService: NotificationService,
    private generalService: GeneralService,
  ) { }

  ngOnInit() {
    this.getCarriers();
  }

  getCarriers() {
    this.generalService.getCarrierList().subscribe(res => {
      this.carrierList = res.payload;
    });
  }

}
