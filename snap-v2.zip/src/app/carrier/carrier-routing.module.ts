import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CarrierDashboardComponent } from './carrier-dashboard/carrier-dashboard.component';
import { CarrierDetailsComponent } from './carrier-details/carrier-details.component';
import { CarrierFormComponent } from './carrier-form/carrier-form.component';
import { CarrierListComponent } from './carrier-list/carrier-list.component';


const routes: Routes = [
  {
    path: '', component: CarrierDashboardComponent, children: [
      { path: '', redirectTo: 'list', pathMatch: 'full' },
      { path: 'list', component: CarrierListComponent },
      { path: 'new', component: CarrierFormComponent },
      { path: 'edit/:id', component: CarrierFormComponent },
      { path: 'view/:id', component: CarrierDetailsComponent }

    ]
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CarrierRoutingModule { }
