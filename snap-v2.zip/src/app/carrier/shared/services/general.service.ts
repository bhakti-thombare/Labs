import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  baseUrl = environment.apiUrl;
  constructor(
    private restService: RestService
  ) { }

  getCarrierList() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/carrier/`, undefined, true);
  }

  getCarrierById(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/carrier/${id}`, undefined, true);
  }

  deleteCarrier(id) {
    return this.restService.delete(`${this.baseUrl}/api/v1/carrier/${id}`, undefined, undefined, true);
  }

  createCarrier(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/carrier/`, data, undefined, true);
  }

  updateCarrier(data, id) {
    return this.restService.put(`${this.baseUrl}/api/v1/carrier/${id}`, data, undefined, true);
  }
}
