import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor(private titleService: Title) {
    this.titleService.setTitle('S.N.A.P.');
    console.log('%c Stop!', 'color: red; font-weight: bold; font-size:36px');
    console.log('%c This area is meant for developers, do not paste anything here.', 'color: red; font-weight: bold; font-size:24px');
  }

  title = 'snap-v2';
}
