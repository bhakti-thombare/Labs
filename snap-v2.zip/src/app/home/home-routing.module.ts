import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CurrentOffersListComponent } from './current-offers-list/current-offers-list.component';
import { NewDonationsListComponent } from './new-donations-list/new-donations-list.component';
import { ProfileUpdatesListComponent } from './profile-updates-list/profile-updates-list.component';
import { DeadlinesPastListComponent } from './deadlines-past-list/deadlines-past-list.component';
import { ShipmentConfirmationsListComponent } from './shipment-confirmations-list/shipment-confirmations-list.component';


const routes: Routes = [
  {
    path: '', component: DashboardComponent, children: [
      { path: '', redirectTo: 'new-donations', pathMatch: 'full' },
      { path: 'current-offers', component: CurrentOffersListComponent },
      { path: 'shipment-confirmations', component: ShipmentConfirmationsListComponent },
      { path: 'new-donations', component: NewDonationsListComponent },
      { path: 'deadlines-past', component: DeadlinesPastListComponent },
      { path: 'profile-updates', component: ProfileUpdatesListComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
