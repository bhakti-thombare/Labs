import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { GeneralService } from '../shared/services/general.service';
import { DONATION_STATUS } from '../shared/donation';
import { UtilityService } from 'src/app/core/services/utility.service';

@Component({
  selector: 'app-deadlines-past-list',
  templateUrl: './deadlines-past-list.component.html',
  styleUrls: ['./deadlines-past-list.component.scss']
})
export class DeadlinesPastListComponent implements OnInit {


  newDonationList = [];
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  currentUser: any;
  currentPage = 1;
  pageSize = 10;
  total = 0;
  delta = 2;
  totalPages: number;
  toolTipContent = '';
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private authService: AuthService,
    private generalService: GeneralService,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {
    this.loadUser();
    this.getDeadlinePastDonations();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }
  getDeadlinePastDonations() {
    const queryParams = {
      pageNo: this.currentPage - 1,
      pageSize: this.pageSize
    };
    this.generalService.getDonationsPastDeadline(queryParams).subscribe(res => {
      
      this.total = parseInt(res.payload && res.payload.count || 0, 10);
      if (res.payload.donationList && res.payload.donationList.length) {
        this.newDonationList = res.payload.donationList.filter(item =>
          (item.donationStatus !== DONATION_STATUS.DONATION_CREATED) &&
          (item.donationStatus !== null));
        
        this.addConfirmedColumn();
      }
    });
  }


  addConfirmedColumn() {
    for (const element of this.newDonationList) {
      element.deadLineDate = element.deadLineDate.split('.')[0];
      
      element.deadLineDate = this.utilityService.convertToLocalTimeZone(new Date(element.deadLineDate + ' UTC'), 'MMM DD, hh:mm a')
      
      
      if (element.confirmed) {
        element.confirmedSummary = element.confirmed + '/' + (element.confirmed + element.allocated);
      }
    }
  }



  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {
    // 
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getDeadlinePastDonations();
  }

  completeDonation(id) {
    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: `Are you sure that you want perform this action?`,
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {

          this.generalService.completeDonation(id).subscribe(res => {
            this.notificationService.showSuccess('Donation marked completed.');
            this.getDeadlinePastDonations();
          });
        }
      },
    });

  }
}
