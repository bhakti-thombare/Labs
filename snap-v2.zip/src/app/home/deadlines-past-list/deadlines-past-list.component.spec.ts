import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeadlinesPastListComponent } from './deadlines-past-list.component';

describe('DeadlinesPastListComponent', () => {
  let component: DeadlinesPastListComponent;
  let fixture: ComponentFixture<DeadlinesPastListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeadlinesPastListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeadlinesPastListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
