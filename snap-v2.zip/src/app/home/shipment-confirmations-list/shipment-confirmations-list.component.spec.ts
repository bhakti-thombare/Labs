import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShipmentConfirmationsListComponent } from './shipment-confirmations-list.component';

describe('ShipmentConfirmationsListComponent', () => {
  let component: ShipmentConfirmationsListComponent;
  let fixture: ComponentFixture<ShipmentConfirmationsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShipmentConfirmationsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShipmentConfirmationsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
