import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-shipment-confirmations-list',
  templateUrl: './shipment-confirmations-list.component.html',
  styleUrls: ['./shipment-confirmations-list.component.scss']
})
export class ShipmentConfirmationsListComponent implements OnInit {
  shipmentConfirmationList = [];
  currentFoodBank: any;
  constructor(
    private authService: AuthService,
    private generalService: GeneralService,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {
    this.loadUser();
    this.getshipmentReadyOffers();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentFoodBank = user.foodbank;
    });
  }
  getshipmentReadyOffers() {
    this.generalService.getShipmentReadyOffers(this.currentFoodBank.id).subscribe(res => {
      this.shipmentConfirmationList = res.payload;
    });
  }
}
