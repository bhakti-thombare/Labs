import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  homeOptions = [
    { title: 'New donations', url: '/home/new-donations', selected: false },
    { title: 'Current offers', url: '/home/current-offers', selected: false },
    { title: 'Deadlines past', url: '/home/deadlines-past', selected: false }
  ];
  selectedTab: string;
  currentUser: any;
  currentRoute: string;
  constructor(private router: Router, private authService: AuthService) {

    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {

      this.currentRoute = event.url;
      this.setLowerTabOptions();
    });
  }

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (this.currentUser) {
        if (this.currentUser.role.toString().toLowerCase() !== 'admin') {
          this.homeOptions = [
            { title: 'Current offers', url: '/home/current-offers', selected: false },
            { title: 'Shipment confirmations', url: '/home/shipment-confirmations', selected: false },
          ];
        }
      }
    });

  }


  setLowerTabOptions() {
    for (const option of this.homeOptions) {
      if (this.currentRoute.includes(option.url) || option.url.includes(this.currentRoute)) {
        this.selectedTab = this.getHeader(option.title);
        break;
      }
    }
  }

  getHeader(option) {
    option = option.toString().toLowerCase();
    
    switch (option) {
      case 'new donations':
        return 'New donations';
      case 'current offers':
        return 'Current offers';
      case 'deadlines past':
        return 'Deadlines past';
      case 'shipment confirmations':
        return 'Shipment confirmations';

    }
  }

}
