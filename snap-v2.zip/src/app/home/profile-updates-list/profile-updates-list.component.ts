import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-updates-list',
  templateUrl: './profile-updates-list.component.html',
  styleUrls: ['./profile-updates-list.component.scss']
})
export class ProfileUpdatesListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
