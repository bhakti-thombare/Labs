import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileUpdatesListComponent } from './profile-updates-list.component';

describe('ProfileUpdatesListComponent', () => {
  let component: ProfileUpdatesListComponent;
  let fixture: ComponentFixture<ProfileUpdatesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileUpdatesListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileUpdatesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
