import { Component, OnInit, ViewChild } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { GeneralService } from '../shared/services/general.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { NotificationService } from 'src/app/core/services/notification.service';
import * as moment from 'moment';
import { UtilityService } from 'src/app/core/services/utility.service';
@Component({
  selector: 'app-current-offers-list',
  templateUrl: './current-offers-list.component.html',
  styleUrls: ['./current-offers-list.component.scss']
})
export class CurrentOffersListComponent implements OnInit {
  foodOfferList = [];
  dryHubOfferList = [];
  directOfferList = [];
  currentUser: any;
  toolTipContent: any;
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  allOffers: any;
  allAdminOffers: any = {
    directOfferList: [],
    dryHubOfferList: [],
    foodOfferList: []
  };
  constructor(
    private utilityService: UtilityService,
    private notificationService: NotificationService,
    private authService: AuthService,
    private generalService: GeneralService) { }

  ngOnInit() {
    this.loadUser();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;

      if (this.currentUser.role === 'ADMIN') {
        this.getAdminCurrentOffers();
      } else {
        this.getFoodBankUserCurrentOffers();
      }
    });
  }

  getAdminCurrentOffers() {
    this.generalService.getAdminCurrentoffers().subscribe(res => {
      this.createListsForAdmin(res.payload.currentOffer);
    });
  }


  createListsForAdmin(currentOffers) {
    this.allAdminOffers.dryHubOfferList = [];
    this.allAdminOffers.directOfferList = [];
    this.allAdminOffers.foodOfferList = [];
    for (const element of currentOffers) {
      const data = {
        id: element.id,
        allocationMethod: element.allocationtype && element.allocationtype.replace(/_/g, ' ') || '-',
        feedOntarioId: element.feedOntarioId,
        deadline: element.deadLine && this.utilityService.convertToLocalTimeZone(element.deadLine + ' UTC', 'DD MMM, hh:mm a') || '',
        available: element.available,
        confirmed: element.confirmed,
        declined: element.decline,
        productDescription: element.productDescription,
        requested: element.request,
        noResponse: element.noresponse,
        foodTemperature: element.foodTemperature,
        foodCategory: element.foodCategory,
        comments: element.comments,
        donationStatus: element.donationStatus,
        total: element.total
      };

      if (element.allocationtype && (element.allocationtype.toString().toLowerCase() === 'dry_hub_offer' ||
        element.allocationtype.toString().toLowerCase() === 'dry_hub offer' ||
        element.allocationtype.toString().toLowerCase() === 'dry hub offer')) {
        this.allAdminOffers.dryHubOfferList.push(data);
      }
      if (element.allocationtype && (element.allocationtype.toString().toLowerCase() === 'food_offer' ||
        element.allocationtype.toString().toLowerCase() === 'food offer')) {
        this.allAdminOffers.foodOfferList.push(data);
      }
      if (element.allocationtype && (element.allocationtype.toString().toLowerCase() === 'direct_offer' ||
        element.allocationtype.toString().toLowerCase() === 'direct offer')) {
        this.allAdminOffers.directOfferList.push(data);
      }
    }
    this.directOfferList = this.allAdminOffers.directOfferList;
    this.dryHubOfferList = this.allAdminOffers.dryHubOfferList;
    this.foodOfferList = this.allAdminOffers.foodOfferList;
  }
  getFoodBankUserCurrentOffers() {
    this.generalService.getFoodBankUserCurrentoffers().subscribe(res => {

      this.allOffers = res.payload;
      this.createLists();
    });
  }

  isOfferExpire(deadline) {
    if (deadline) {



      return moment(new Date()).isAfter(moment(new Date(deadline)));
    }
  }

  createLists() {
    this.allAdminOffers.dryHubOfferList = [];
    this.allAdminOffers.directOfferList = [];
    this.allAdminOffers.foodOfferList = [];
    for (const key in this.allOffers) {
      if (this.allOffers.hasOwnProperty(key)) {
        const temp = [];
        this.allOffers[key].forEach(element => {
          temp.push({
            feedOntarioId: element.feed_ontario_id,
            deadline: element.deadline_date && this.utilityService.convertToLocalTimeZone(new Date(element.deadline_date + ' UTC'), 'MMM DD, hh:mm a') || '',
            expiryDate: element.expiry_date,
            productDescription: element.product_description,
            requestedQuantity: element.requested_quantity,
            offeredQuantity: element.offered_quantity,
            quantityPallets: element.quantity_pallets || undefined,
            status: element.status || undefined,
            donationId: element.donation_id || undefined,
            foodTemperature: element.foodTemperature,
            foodCategory: element.foodCategory,
            comments: element.comments,
            offerId: element.offer_id || undefined,
            disableEditOptions: element.deadline_date && this.isOfferExpire(
              this.utilityService.convertToLocalTimeZone(new Date(element.deadline_date + ' UTC'), 'MMMM DD YYYY, h:mm:ss a')
            )
          });
        });
        key === 'food-offer' ? this.foodOfferList = temp :
          (key === 'dry-hub-offer' ? this.dryHubOfferList = temp : this.directOfferList = temp);
      }
    }




  }


  handleOffer(element, value) {

    if (!element.disableEditOptions) {
      const data = {
        donationId: element.donationId,
        notes: '',
        offerId: element.offerId,
        requestedQuantity: element.requestedQuantity,
        sharedOrganization: [],
        status: value
      };
      this.genericConfirm.show({
        headlineText: 'Confirmation',
        notConfirmText: 'No',
        confirmText: 'Yes',
        text: 'Are you sure that you want to perform this action?',
        callback: (result) => {
          // Actual logic to perform a confirmation
          // api call to delete
          if (result) {

            this.generalService.handleOffer(data).subscribe(res => {
              this.notificationService.showSuccess('Offer' + value.toString().toLowerCase());
              this.getFoodBankUserCurrentOffers();
            });
          }
        },
      });
    }

  }

  completeDonation(id) {
    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: `Are you sure that you want perform this action?`,
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {

          this.generalService.completeDonation(id).subscribe(res => {
            this.notificationService.showSuccess('Donation marked completed.');
            this.getAdminCurrentOffers();
          });
        }
      },
    });

  }

}
