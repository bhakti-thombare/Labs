import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { RestService } from 'src/app/core/services/rest.service';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  baseUrl = environment.apiUrl;
  constructor(private restService: RestService) { }

  // get donations list for admin
  getNewDonations(queries) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/getAllDonation`, queries, true);
  }

  // approve or reject donation by admin
  handleDonationRequest(data, id) {
    return this.restService.put(`${this.baseUrl}/api/v1/donation/action/${id}`, data, undefined, true);
  }

  getAdminCurrentoffers() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/currentOffers`, undefined, true);
  }
  getFoodBankUserCurrentoffers() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/food-bank/donation`, undefined, true);
  }

  // accept or decline offer by foodbank
  handleOffer(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/foodbank/offerAction`, data, undefined, true);
  }

  // get allocated offers for food bank user, so that food bank can confirm the shipment
  getShipmentReadyOffers(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/shipment/allocated-offers/${id}`, undefined, true);
  }

  getDonationsPastDeadline(queryParams) {
    return this.restService.fetch(`${this.baseUrl}​​/api/v1/donation/deadlinePastDonations`, queryParams, true);
  }

  completeDonation(id) {
    return this.restService.put(`${this.baseUrl}/api/v1/donor/completeDonation/${id}`, undefined, undefined, true);
  }
}

