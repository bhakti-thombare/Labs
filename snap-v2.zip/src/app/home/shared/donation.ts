export enum DONATION_STATUS {
  DONATION_CREATED = 'DONATION_CREATED',
  DONATION_SAVED = 'DONATION_SAVED', // saved by donor
  DONATION_SUBMIT = 'DONATION_SUBMIT', // submitted by donor
  DONATION_UPDATED = 'DONATION_UPDATED', // updated by admin
  DONATION_APPROVED = 'DONATION_APPROVED', // approved by admin
  DONATION_REJECTED = 'DONATION_REJECTED', // rejected by admin
  SETALLOCATION_METHOD = 'SETALLOCATION_METHOD', // allocation method is set by admi
  EDIT_DONATION = 'EDIT_DONATION', // donation edited by admin
  SET_DEADLINE = 'SET_DEADLINE' // deadline is set by admin
}
