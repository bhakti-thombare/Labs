import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewDonationsListComponent } from './new-donations-list.component';

describe('NewDonationsListComponent', () => {
  let component: NewDonationsListComponent;
  let fixture: ComponentFixture<NewDonationsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewDonationsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewDonationsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
