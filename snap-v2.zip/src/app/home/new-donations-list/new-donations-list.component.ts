import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { GeneralService } from '../shared/services/general.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { AuthService } from 'src/app/core/services/auth.service';
import { DONATION_STATUS } from '../shared/donation';
@Component({
  selector: 'app-new-donations-list',
  templateUrl: './new-donations-list.component.html',
  styleUrls: ['./new-donations-list.component.scss']
})
export class NewDonationsListComponent implements OnInit {
  newDonationList = [];
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  currentUser: any;
  currentPage = 1;
  pageSize = 15;
  total = 0;
  delta = 2;
  totalPages: number;
  toolTipContent: any;
  constructor(
    private router: Router,
    private authService: AuthService,
    private generalService: GeneralService,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {

    this.loadUser();
    this.getNewDonations();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (this.currentUser && this.currentUser.role !== 'ADMIN') {
        this.router.navigateByUrl('/home/current-offers');
      }
    });
  }
  getNewDonations() {
    const queries = {
      pageNo: this.currentPage - 1,
      pageSize: this.pageSize
    };
    this.generalService.getNewDonations(queries).subscribe(res => {
      this.total = parseInt(res.count || 0, 10);
      this.newDonationList = res.donationList.filter(item =>
        (item.donationStatus !== DONATION_STATUS.DONATION_CREATED) &&
        (item.donationStatus !== null));
      
    });
  }


  handleDonationRequest(productDescription, value, id) {
    let key = '';
    let message = '';
    if (value) {
      key = 'APPROVED';
      message = 'approve';
    } else {
      key = 'REJECTED';
      message = 'reject';
    }
    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: `Are you sure that you want ${message} ${productDescription} donation request?`,
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {
          
          const data = {
            action: key
          };
          this.generalService.handleDonationRequest(data, id).subscribe(res => {
            this.notificationService.showSuccess(`Donation ${value ? 'accepted' : 'rejected'}.`);
            this.getNewDonations();
          });
        }
      },
    });
  }
  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {
    // 
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getNewDonations();
  }

  completeDonation(id) {
    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: `Are you sure that you want perform this action?`,
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {

          this.generalService.completeDonation(id).subscribe(res => {
            this.notificationService.showSuccess('Donation marked completed.');
            this.getNewDonations();
          });
        }
      },
    });

  }
}
