import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CurrentOffersListComponent } from './current-offers-list/current-offers-list.component';
import { NewDonationsListComponent } from './new-donations-list/new-donations-list.component';
import { ProfileUpdatesListComponent } from './profile-updates-list/profile-updates-list.component';
import { DeadlinesPastListComponent } from './deadlines-past-list/deadlines-past-list.component';
import { SharedModule } from '../shared/shared.module';
import { ShipmentConfirmationsListComponent } from './shipment-confirmations-list/shipment-confirmations-list.component';
import { PopoverModule } from 'ngx-bootstrap/popover';
// import { TabViewModule } from "primeng/tabview";
import { TabsModule } from 'ngx-bootstrap/tabs';

@NgModule({
  declarations: [
    DashboardComponent,
    CurrentOffersListComponent,
    NewDonationsListComponent,
    ProfileUpdatesListComponent,
    DeadlinesPastListComponent,
    ShipmentConfirmationsListComponent],
  imports: [
    CommonModule,
    SharedModule,
    PopoverModule.forRoot(),
    HomeRoutingModule,
    TabsModule.forRoot()
  ]
})
export class HomeModule { }
