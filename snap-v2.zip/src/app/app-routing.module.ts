import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminAuthGuard } from './core/guards/admin-auth.guard';
import { UserAuthGuard } from './core/guards/user-auth.guard';
import { PageNotFoundComponent } from './shared/components/page-not-found/page-not-found.component';


const routes: Routes = [
  { path: '', redirectTo: '', pathMatch: 'full' },
  { path: '', loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule) },
  { path: 'user', canActivate: [UserAuthGuard], loadChildren: () => import('./user/user.module').then(m => m.UserModule) },
  { path: 'home', canActivate: [UserAuthGuard], loadChildren: () => import('./home/home.module').then(m => m.HomeModule) },
  { path: 'donation', loadChildren: () => import('./donation/donation.module').then(m => m.DonationModule) },
  { path: 'offer', loadChildren: () => import('./offer/offer.module').then(m => m.OfferModule) },
  { path: 'zone', canActivate: [UserAuthGuard], loadChildren: () => import('./zone/zone.module').then(m => m.ZoneModule) },
  { path: 'carrier', canActivate: [AdminAuthGuard], loadChildren: () => import('./carrier/carrier.module').then(m => m.CarrierModule) },
  { path: 'report', canActivate: [UserAuthGuard], loadChildren: () => import('./report/report.module').then(m => m.ReportModule) },
  {
    path: 'miscellaneous', canActivate: [UserAuthGuard],
    loadChildren: () => import('./miscellaneous/miscellaneous.module').then(m => m.MiscellaneousModule)
  },
  { path: 'faq', canActivate: [UserAuthGuard], loadChildren: () => import('./faq/faq.module').then(m => m.FAQModule) },
  {
    path: 'your-food-bank', canActivate: [UserAuthGuard],
    loadChildren: () => import('./your-food-bank/your-food-bank.module').then(m => m.YourFoodBankModule)
  },
  {
    path: 'email-template', canActivate: [AdminAuthGuard],
    loadChildren: () => import('./email-template/email-template.module').then(m => m.EmailTemplateModule)
  },
  { path: '**', component: PageNotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
