import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-food-bank-list',
  templateUrl: './other-food-bank-list.component.html',
  styleUrls: ['./other-food-bank-list.component.scss']
})
export class OtherFoodBankListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
