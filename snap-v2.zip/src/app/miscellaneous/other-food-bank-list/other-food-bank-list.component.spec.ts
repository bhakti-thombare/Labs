import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherFoodBankListComponent } from './other-food-bank-list.component';

describe('OtherFoodBankListComponent', () => {
  let component: OtherFoodBankListComponent;
  let fixture: ComponentFixture<OtherFoodBankListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtherFoodBankListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherFoodBankListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
