import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MiscellaneousRoutingModule } from './miscellaneous-routing.module';
import { FoodBankHungerCountListComponent } from './food-bank-hunger-count-list/food-bank-hunger-count-list.component';
import { FoodBankHungerCountFormComponent } from './food-bank-hunger-count-form/food-bank-hunger-count-form.component';
import { MiscellaneousDashboardComponent } from './miscellaneous-dashboard/miscellaneous-dashboard.component';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OtherFoodBankListComponent } from './other-food-bank-list/other-food-bank-list.component';
import { OtherFoodBankDetailsComponent } from './other-food-bank-details/other-food-bank-details.component';
import { OtherFoodBankDashboardComponent } from './other-food-bank-dashboard/other-food-bank-dashboard.component';
import { UserModule } from '../user/user.module';
import { YourFoodBankModule } from '../your-food-bank/your-food-bank.module';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { SettingsFormComponent } from './settings-form/settings-form.component';
import { FileUploadModule } from 'ng2-file-upload';

@NgModule({
  declarations: [
    FoodBankHungerCountListComponent,
    FoodBankHungerCountFormComponent,
    MiscellaneousDashboardComponent,
    OtherFoodBankListComponent,
    OtherFoodBankDetailsComponent,
    OtherFoodBankDashboardComponent,
    ContactFormComponent,
    SettingsFormComponent],
  imports: [
    FileUploadModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    YourFoodBankModule,
    UserModule,
    MiscellaneousRoutingModule
  ]
})
export class MiscellaneousModule { }
