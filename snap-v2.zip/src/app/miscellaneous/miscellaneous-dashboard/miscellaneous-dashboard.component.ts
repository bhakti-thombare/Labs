import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-miscellaneous-dashboard',
  templateUrl: './miscellaneous-dashboard.component.html',
  styleUrls: ['./miscellaneous-dashboard.component.scss']
})
export class MiscellaneousDashboardComponent implements OnInit {
  currentUser: any;

  constructor(
    private authService: AuthService,
  ) { }

  ngOnInit() {
    this.loadUser();
  }
  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

}
