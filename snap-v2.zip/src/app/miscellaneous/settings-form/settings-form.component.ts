import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GeneralService } from '../shared/services/general.service';
import { FileUploader } from 'ng2-file-upload';

@Component({
  selector: 'app-settings-form',
  templateUrl: './settings-form.component.html',
  styleUrls: ['./settings-form.component.scss']
})
export class SettingsFormComponent implements OnInit {
  settingsForm: FormGroup;
  emailPattern = this.utilityService.emailPattern;
  userGuide; any;
  settingsDetail: any;
  fileUrl: any;
  uploader: any = new FileUploader({
    disableMultipart: false // 'DisableMultipart' must be 'true' for formatDataFunction to be called.
  });

  constructor(
    private generalService: GeneralService,
    private notificationService: NotificationService,
    private formBuilder: FormBuilder,
    private utilityService: UtilityService) { }

  ngOnInit() {
    this.buildForm();
    this.getSettings();
  }

  buildForm() {
    this.settingsForm = this.formBuilder.group({
      contactEmail: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      contactPhone: ['', Validators.required],
      // userGuideFileName: ['userGuide']
    });
  }


  getSettings() {
    this.generalService.getSettings().subscribe(res => {
      this.settingsDetail = res.payload;
      this.patchForm();
    });
  }


  patchForm() {
    this.settingsForm.patchValue({
      contactEmail: this.settingsDetail.contactEmail,
      contactPhone: this.settingsDetail.contactPhone
    });
    this.fileUrl = this.settingsDetail.preSignedUrl;
    this.userGuide = this.settingsDetail.userGuideFileName.includes('document') ? this.settingsDetail.userGuideFileName.split('/')[1] : this.settingsDetail.userGuideFileName;
  }
  submit() {

    if (this.settingsForm.valid) {
      if (this.isUserGuidePresent) {
        const data = this.settingsForm.value;
        data.userGuideFileName = this.settingsDetail.userGuideFileName;
        this.generalService.submitSettings(data).subscribe(res => {
          this.notificationService.showSuccess('Settings saved');
        });
      } else {
        this.notificationService.showError('Please add a user guide pdf.');
      }
    } else {
      this.notificationService.showError('Please add valid data in mandatory fields.');
    }
  }

  isUserGuidePresent() {
    return this.userGuide ? true : false;
  }

  uploadHandler(event) {

    const file = event[0];
    if (file) {
      if (this.checkFileValidity(file)) {
        this.uploadFile(file);
      }
    }
  }


  checkFileValidity(file) {

    console.log('file', file);
    if (file.type === 'application/pdf') {
      if (file.name.includes(' ')) {
        this.notificationService.showError('File name should not contain space.');
        return false;
      }
      console.log('file.size', file.size);
      if (file.size > 15728640) {
        this.notificationService.showError('File size should be less than 15mb.');
        return false;
      }
    } else {
      this.notificationService.showError('File type should be pdf only.');
      return false;
    }
    return true;
  }

  uploadFile(file) {
    const formData = new FormData();
    formData.append('file', file);

    this.generalService.uploadFile(formData).subscribe(res => {

      this.notificationService.showSuccess('User guide uploaded.');
      // this.getSettings();
      this.userGuide = res.payload.fileName.includes('document') ? res.payload.fileName.split('/')[1] : res.payload.fileName;
      this.settingsDetail.userGuideFileName = res.payload.fileName;
      this.fileUrl = res.payload.preSignedUrl;
    });
  }
  onlyNumberKey(event) {
    return this.utilityService.onlyNumberKey(event);
  }
}
