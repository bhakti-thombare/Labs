import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-food-bank-hunger-count-list',
  templateUrl: './food-bank-hunger-count-list.component.html',
  styleUrls: ['./food-bank-hunger-count-list.component.scss']
})
export class FoodBankHungerCountListComponent implements OnInit {


  foodBankList = [];
  selectedFoodBankIds = [];
  constructor(
    private notificationService: NotificationService,
    private generalService: GeneralService,
    private router: Router
  ) { }

  ngOnInit() {
    this.getFoodBanks();
  }


  getFoodBanks() {
    this.generalService.getFoodBanksHungerCountList().subscribe(res => {
      this.foodBankList = this.formatData(res.payload.foodBankList);

    });
  }

  formatData(list) {
    for (const element of list) {
      element.hungerCount = element.orgProfile.hungerCount;
      element.city = element.orgProfile.city;
    }
    return list;
  }
  editSelectedFoodBank() {
    if (this.selectedFoodBankIds.length) {
      this.selectedFoodBankIds = Array.from(new Set(this.selectedFoodBankIds));
      localStorage.setItem('foodBankIds', JSON.stringify(this.selectedFoodBankIds));
      this.router.navigateByUrl('/miscellaneous/food-bank-hunger-count-update');
    } else {
      this.notificationService.showError('Please select a food bank');
    }
  }


  foodBankSelected(id, index, event) {
    
    if (event.target.checked) {
      this.selectedFoodBankIds.push(id);
    } else if (event.target.checked === false && this.selectedFoodBankIds.includes(id)) {
      index = this.selectedFoodBankIds.findIndex(item => item === id);
      if (index !== -1) {
        this.selectedFoodBankIds.splice(index, 1);
      }
    }
    
  }

}
