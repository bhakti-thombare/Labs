import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodBankHungerCountListComponent } from './food-bank-hunger-count-list.component';

describe('FoodBankHungerCountListComponent', () => {
  let component: FoodBankHungerCountListComponent;
  let fixture: ComponentFixture<FoodBankHungerCountListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoodBankHungerCountListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodBankHungerCountListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
