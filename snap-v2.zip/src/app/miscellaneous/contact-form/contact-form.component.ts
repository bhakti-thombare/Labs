import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.scss']
})
export class ContactFormComponent implements OnInit {
  message: any;
  settingsDetail: any;
  constructor(
    private router: Router,
    private generalService: GeneralService,
    private notificationService: NotificationService) { }

  ngOnInit() {
    this.getSettings();
  }


  getSettings() {
    this.generalService.getSettings().subscribe(res => {
      this.settingsDetail = res.payload;
    });
  }

  submit() {
    if (this.message.trim()) {
      
      this.generalService.sendEmail({ message: this.message, email: this.settingsDetail.contactEmail }).subscribe(res => {
        this.notificationService.showSuccess('Message sent.');
        this.router.navigateByUrl('/home/current-offers');
      });
    } else {
      this.notificationService.showError('Please add a message before submitting.');
    }
  }
}
