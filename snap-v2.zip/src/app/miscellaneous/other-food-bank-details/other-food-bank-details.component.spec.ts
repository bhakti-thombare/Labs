import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherFoodBankDetailsComponent } from './other-food-bank-details.component';

describe('OtherFoodBankDetailsComponent', () => {
  let component: OtherFoodBankDetailsComponent;
  let fixture: ComponentFixture<OtherFoodBankDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtherFoodBankDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherFoodBankDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
