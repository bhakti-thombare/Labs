import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-food-bank-details',
  templateUrl: './other-food-bank-details.component.html',
  styleUrls: ['./other-food-bank-details.component.scss']
})
export class OtherFoodBankDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
