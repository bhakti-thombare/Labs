import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  baseUrl = environment.apiUrl;
  constructor(private restService: RestService) { }

  getFoodBanksHungerCountList() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/profile`, { pageNo: 0, pageSize: 1000, status: 'Active' }, true);
  }

  updateFoodBanksHungerCount(data) {
    return this.restService.put(`${this.baseUrl}/api/v1/foodbank/profile/hungerCount`, data, undefined, true);
  }

  sendEmail(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/contact/sentToAdmin`, data, undefined, true);
  }

  submitSettings(data) {
    return this.restService.put(`${this.baseUrl}/api/v1/settings/update`, data, undefined, true);
  }

  getSettings() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/settings/getSettings`, undefined, true);
  }

  uploadFile(data) {
    return this.restService.upload('POST', `${this.baseUrl}/api/v1/settings/upload-document`, data, undefined, true);
  }
}
