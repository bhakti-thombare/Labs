import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminAuthGuard } from '../core/guards/admin-auth.guard';
import { FoodBankDetailsComponent } from '../your-food-bank/food-bank-details/food-bank-details.component';
import { FoodBankProfileListComponent } from '../user/food-bank-profile-list/food-bank-profile-list.component';
import { FoodBankHungerCountFormComponent } from './food-bank-hunger-count-form/food-bank-hunger-count-form.component';
import { FoodBankHungerCountListComponent } from './food-bank-hunger-count-list/food-bank-hunger-count-list.component';
import { MiscellaneousDashboardComponent } from './miscellaneous-dashboard/miscellaneous-dashboard.component';
import { OtherFoodBankDashboardComponent } from './other-food-bank-dashboard/other-food-bank-dashboard.component';
import { OtherFoodBankDetailsComponent } from './other-food-bank-details/other-food-bank-details.component';
import { OtherFoodBankListComponent } from './other-food-bank-list/other-food-bank-list.component';
import { UserAuthGuard } from '../core/guards/user-auth.guard';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { SettingsFormComponent } from './settings-form/settings-form.component';


const routes: Routes = [
  {
    path: '', component: MiscellaneousDashboardComponent, children: [
      { path: 'food-bank-hunger-count-list', canActivate: [AdminAuthGuard], component: FoodBankHungerCountListComponent },
      { path: 'food-bank-hunger-count-update', canActivate: [AdminAuthGuard], component: FoodBankHungerCountFormComponent },
      { path: 'contact', canActivate: [UserAuthGuard], component: ContactFormComponent },
      { path: 'settings', canActivate: [AdminAuthGuard], component: SettingsFormComponent },
      {
        path: 'other-food-bank', component: OtherFoodBankDashboardComponent, children: [
          { path: 'list', component: FoodBankProfileListComponent },
          { path: 'details/:id', component: FoodBankDetailsComponent },
        ]
      }
    ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MiscellaneousRoutingModule { }
