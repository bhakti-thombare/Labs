import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-other-food-bank-dashboard',
  templateUrl: './other-food-bank-dashboard.component.html',
  styleUrls: ['./other-food-bank-dashboard.component.scss']
})
export class OtherFoodBankDashboardComponent implements OnInit, OnDestroy {

  currentUser: any;
  foodBankId = null;
  subscription: Subscription;
  selectedTab;
  otherFoodBankTabOptions = [
    { title: 'List', url: '/miscellaneous/other-food-bank/list', selected: false }];
  currentRoute: any;
  constructor(
    private router: Router,
    private authService: AuthService,
    private activatedRoute: ActivatedRoute,
  ) {
    this.loadUser();

    this.subscription = router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      
      this.currentRoute = event.url;
      this.modifyUserTabs();
    });
  }

  ngOnInit() {
    this.foodBankId = this.activatedRoute.snapshot.paramMap.get('id') || this.activatedRoute.firstChild.snapshot.paramMap.get('id');
    
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  modifyUserTabs() {

    const foodBankId = this.activatedRoute.snapshot.paramMap.get('id') || this.activatedRoute.firstChild.snapshot.paramMap.get('id');
    



    if (this.router.url.includes('/miscellaneous/other-food-bank/details')) {
      this.otherFoodBankTabOptions = [
        { title: 'List', url: '/miscellaneous/other-food-bank/list', selected: false },
        { title: 'View', url: '/miscellaneous/other-food-bank/details/' + foodBankId, selected: false }
      ];
    } else {
      this.otherFoodBankTabOptions = [
        { title: 'List', url: '/miscellaneous/other-food-bank/list', selected: false }
      ];
    }
    for (const option of this.otherFoodBankTabOptions) {
      
      
      if (this.currentRoute.includes(option.url) || option.url.includes(this.currentRoute)) {
        this.selectedTab = this.getHeader(option.title);
      }
    }
    

  }

  tabSelected(url) {
    for (const option of this.otherFoodBankTabOptions) {
      if (url.includes(option.url) || option.url.includes(url)) {
        this.selectedTab = this.getHeader(option.title);
        option.selected = true;
        this.router.navigateByUrl(url);
      } else {
        option.selected = false;
      }
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getHeader(option) {
    option = option.toString().toLowerCase();
    switch (option) {
      case 'list':
        return 'Food banks';
      case 'view':
        return 'Food bank details';
    }
  }
}
