import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-food-bank-hunger-count-form',
  templateUrl: './food-bank-hunger-count-form.component.html',
  styleUrls: ['./food-bank-hunger-count-form.component.scss']
})
export class FoodBankHungerCountFormComponent implements OnInit, OnDestroy {
  foodBankList = [];
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private notificationService: NotificationService,
    private generalService: GeneralService
  ) { }

  ngOnInit() {
    this.getFoodBanks();

  }

  getFoodBanks() {

    this.generalService.getFoodBanksHungerCountList().subscribe(res => {
      this.foodBankList = this.formatData(res.payload.foodBankList);
      if (localStorage.getItem('foodBankIds')) {
        const selectedFoodBankIds = localStorage.getItem('foodBankIds');
        this.filterFoodBankList(JSON.parse(selectedFoodBankIds));
      }
    });
  }

  formatData(list) {
    for (const element of list) {
      element.hungerCount = element.orgProfile.hungerCount;
      element.city = element.orgProfile.city;
    }
    return list;
  }

  filterFoodBankList(selectedFoodBankIds) {
    if (selectedFoodBankIds.length) {
      const selectedFoodBanks = this.foodBankList.filter(element => selectedFoodBankIds.includes(element.id));
      this.foodBankList = selectedFoodBanks;
    }
  }

  submit() {
    this.validateHungerCounts();
    const foodBankListUpdated = this.formatRequest(this.foodBankList);
    
    this.generalService.updateFoodBanksHungerCount({ foodBank: foodBankListUpdated }).subscribe(res => {
      this.notificationService.showSuccess('Hunger count updated.');
      this.router.navigateByUrl('/miscellaneous/food-bank-hunger-count-list');
    });
  }

  formatRequest(list) {
    const tempArr = [];
    for (const element of list) {
      tempArr.push({
        id: element.id,
        hungerCount: +element.hungerCount
      });
    }
    return tempArr;
  }

  validateHungerCounts() {
    for (const element of this.foodBankList) {
      if (!element.hungerCount) {
        element.hungerCount = 0;
      }
    }
  }

  ngOnDestroy() {
    if (localStorage.getItem('foodBankIds')) {
      localStorage.removeItem('foodBankIds');
    }
  }

  onlyNumberKey(event) {
    return this.utilityService.onlyNumberKey(event);
  }
}
