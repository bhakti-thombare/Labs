import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { directOfferAllocationTableSortParam } from '../shared/enums/donation.enum';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-allocation-method-direct-offer-form',
  templateUrl: './allocation-method-direct-offer-form.component.html',
  styleUrls: ['./allocation-method-direct-offer-form.component.scss']
})
export class AllocationMethodDirectOfferFormComponent implements OnInit {
  donationId: string;
  @Input() donationDetail: any;
  totalOfferedQuantity = 0;
  totalRequestedQuantity = 0;
  totalAllocatedQuantity = 0;
  allocationList: any;
  toolTipContent: any;
  originalQuantityPallets: any;
  progressPercentage = 100;
  quantityText = 'remaining';
  sortParam: any;
  order = 'ASC';
  public get directOfferAllocationTableSortParam(): typeof directOfferAllocationTableSortParam {
    return directOfferAllocationTableSortParam;
  }
  selectedFilters = ['OFFERED', 'ACCEPTED', 'ALLOCATED', 'NOT_OFFERED', 'DECLINED'];
  filters = [
    {
      selected: true,
      status: 'OFFERED',
      count: null
    },
    {
      selected: true,
      status: 'ACCEPTED',
      count: null
    },
    {
      selected: true,
      status: 'ALLOCATED',
      count: null
    },
    {
      selected: true,
      status: 'NOT_OFFERED',
      count: null
    },
    {
      selected: true,
      status: 'DECLINED',
      count: null
    }
  ];
  pageSize = 7;
  currentPage = 1;
  total = 0;
  delta = 2;
  totalPages: number;
  mouseLeftPopover: boolean;
  observer: any;
  popover: any;
  onPop = false;
  @ViewChild('pop', { static: true }) pop: any;
  hoveredOfferDetails: any;
  showPopover: any;
  hoveredItem: any;
  tempContent: any;
  allocationListBackup: any;
  modifiedOfferIds = [];
  modifiedOrgIds: any[] = [];


  constructor(
    private notificationService: NotificationService,
    private router: Router,
    private utilityService: UtilityService,
    private ref: ChangeDetectorRef,
    private activatedRoute: ActivatedRoute,
    private generalService: GeneralService) { }

  ngOnInit() {
    this.allocationList = [];
    this.donationId = this.activatedRoute.snapshot.paramMap.get('id');
    this.originalQuantityPallets = JSON.parse(JSON.stringify(this.donationDetail.quantityPallets));
    // this.getfoodBankForDirectOffer();
    this.sortList(directOfferAllocationTableSortParam.DELTA);
  }

  getfoodBankForDirectOffer() {
    const queryParams: any = {
      // pageNo: this.currentPage - 1,
      // pageSize: this.pageSize,
      filter: this.selectedFilters.join(',') + ',CONFIRMED'
    };

    if (this.sortParam && this.order) {
      queryParams.sort = this.sortParam;
      queryParams.order = this.order;
    }
    this.generalService.getFoodBanksForDirectOffer(this.donationId, queryParams).subscribe(res => {

      this.allocationList = res.payload.directOfferList;
      this.allocationListBackup = JSON.parse(JSON.stringify(this.allocationList));
      this.total = res.payload.count;
      if (this.allocationList.length) {
        this.allocationList.forEach(element => {
          element.directOfferPercent = element.directOfferPercent && +element.directOfferPercent.toFixed(2);
          element.hcPercent = element.hcPercent && +element.hcPercent.toFixed(2);
          element.deltaFactorPercent = element.deltaFactorPercent && +element.deltaFactorPercent.toFixed(2);
          element.showPopover = false;
          if (!element.allocatedQuantity && element.allocatedQuantity !== 0) {
            element.allocatedQuantity = null;
          }
          if (!element.offeredQuantity && element.offeredQuantity !== 0) {
            element.offeredQuantity = null;
          }
          if (!element.requestedQuantity && element.requestedQuantity !== 0) {
            element.requestedQuantity = null;
          }
        });
        this.totalAllocatedQuantity = this.updateAllocationData('allocatedQuantity');
        this.totalOfferedQuantity = this.updateAllocationData('offeredQuantity');
        this.totalRequestedQuantity = this.updateAllocationData('requestedQuantity');
        this.updateQuantityPallet();
      }

    });
  }


  inputChanged(event, index, key) {
    switch (key) {
      case 'offeredQuantity':
        this.allocationList[index].offeredQuantity = event || 0;
        this.totalOfferedQuantity = this.updateAllocationData(key);
        break;
      case 'requestedQuantity':
        this.allocationList[index].requestedQuantity = event || 0;
        this.totalRequestedQuantity = this.updateAllocationData(key);
        break;
      case 'allocatedQuantity':
        this.allocationList[index].allocatedQuantity = event || 0;
        this.totalAllocatedQuantity = this.updateAllocationData(key);
        this.updateQuantityPallet();
        break;
    }

    this.ref.detectChanges();


  }


  updateAllocationData(key) {
    let tempValue = 0;
    for (const element of this.allocationList) {
      if (element[key]) {
        tempValue = tempValue + element[key] || 0;
      }
    }
    return tempValue;
  }

  updateQuantityPallet() {
    this.donationDetail.quantityPallets = JSON.parse(JSON.stringify(this.originalQuantityPallets));

    this.donationDetail.quantityPallets = this.donationDetail.quantityPallets - this.totalAllocatedQuantity;

    this.updateProgressBar();
  }

  updateProgressBar() {
    this.progressPercentage = (this.donationDetail.quantityPallets / this.originalQuantityPallets) * 100;
    if (this.donationDetail.quantityPallets < 0) {
      this.progressPercentage = 0;
      this.quantityText = 'over available';
    } else {
      this.quantityText = 'remaining';
    }
  }

  onlyNumberKey(event) {
    return this.utilityService.onlyNumberKey(event);
  }

  goToReviewDirectOfferPage(value) {
    if (!this.isValid()) {
      this.notificationService.showError('Please make sure fields have valid data.');
      return false;
    }

    const data = {
      allocations: this.getSelectedFoodBanks(),
      comment: this.donationDetail.comments,
      donationId: this.donationId,
      offerDeadline: this.donationDetail.deadlineDate || null,
      confirm: false
    };

    if (data.allocations.length) {
      this.generalService.submitDirectOffer(data).subscribe(res => {
        // this.generalService.updateDonation(this.donationDetail, this.donationId).subscribe(res2 => { });
        if (value === 'SUBMIT') {
          if (this.modifiedOfferIds.length || this.modifiedOrgIds.length) {
            this.router.navigateByUrl('/donation/review-direct-offer/' + this.donationId);
          } else {
            this.notificationService.showSuccess('Direct offer details saved.');
            this.getfoodBankForDirectOffer();
          }
        } else {
          if (value === 'SAVE') {
            this.notificationService.showSuccess('Direct offer saved successfully.');
            this.getfoodBankForDirectOffer();
          }
        }
      });
    } else {
      this.router.navigateByUrl('/donation/review-direct-offer/' + this.donationId);
    }
  }

  isValid() {
    for (const element of this.allocationList) {
      if (element.offeredQuantity > this.originalQuantityPallets ||
        element.requestedQuantity > element.offeredQuantity ||
        element.allocatedQuantity > element.requestedQuantity) {
        return false;
      }
    }
    if (this.donationDetail.quantityPallets < 0) {
      return false;
    }
    return true;
  }

  getSelectedFoodBanks() {
    const tempArr = [];
    for (const element of this.allocationList) {

      if (
        (element.requestedQuantity || element.requestedQuantity === 0) ||
        (element.allocatedQuantity || element.allocatedQuantity === 0) ||
        (element.offeredQuantity || element.offeredQuantity === 0)) {
        const isModified = this.isValueModified(element);
        tempArr.push({
          allocatedQuantity: element.allocatedQuantity || 0,
          foodBankId: element.orgId,
          offeredQuantity: element.offeredQuantity || 0,
          requestedQuantity: element.requestedQuantity || 0,
          status: isModified ? this.getStatus(element) : element.status,
          quantityModified: (this.modifiedOfferIds.length && element.offerId && this.modifiedOfferIds.includes(element.offerId)) ||
            (this.modifiedOrgIds.length && element.orgId && this.modifiedOrgIds.includes(element.orgId)) ? true : false
        });
      }
    }

    return tempArr;
  }

  allowOnlyFloat(txt, event) {
    return this.utilityService.allowOnlyFloat(txt, event);
  }

  getStatus(element) {
    if (element.requestedQuantity > 0 && element.status === 'ALLOCATED') {
      return element.status
    }
    if (element.allocatedQuantity > 0) {
      return 'ACCEPTED';
    } else if (element.requestedQuantity > 0) {
      return 'ACCEPTED';
    } else if (element.offeredQuantity > 0) {
      return 'NOT_OFFERED';
    } else {
      return element.status;
    }
  }

  filterClicked(item, event) {
    item.selected = event.target.checked;

    this.selectedFilters = [];
    for (const element of this.filters) {
      if (element.selected) {
        this.selectedFilters.push(element.status);
      }
    }

    this.getfoodBankForDirectOffer();
  }

  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {

    if (this.getSelectedFoodBanks().length) {
      this.goToReviewDirectOfferPage('PAGE_CHANGE');
    }
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getfoodBankForDirectOffer();
  }

  setHoverDetails(allocationItem, pop) {
    this.popover = pop;
    this.hoveredOfferDetails = {
      foodBankName: allocationItem.foodBankName,
      foodBankId: allocationItem.orgId,
      offerType: this.donationDetail.allocationMethod
    };
  }

  handlePopOverHide(pop) {


    // this.onPop = false;
    setTimeout(() => {
      if (!this.onPop) {
        pop.hide()

      } else {
        pop.show()

      }
    }, 100);
  }

  mouseenter(event) {

  }


  mouseExitPop(event) {

    this.popover.hide();

  }

  isValueModified(modifiedElement) {
    let isRequestModified = false;
    let isAllocModified = false;
    let isOfferModified = false;
    for (const element of this.allocationListBackup) {
      if (modifiedElement.orgId === element.orgId) {
        if (modifiedElement.offeredQuantity !== element.offeredQuantity || element.quantityModified) {
          isOfferModified = true;
          if (modifiedElement.status !== 'ACCEPTED' && modifiedElement.status !== 'ALLOCATED') {
            modifiedElement.quantityModified = true;


            if (element.offerId) {
              this.modifiedOfferIds.push(element.offerId);
            } else {
              this.modifiedOrgIds.push(element.orgId);
            }
          }
        }
        if (modifiedElement.requestedQuantity !== element.requestedQuantity) {
          isRequestModified = true;
          // modifiedElement.quantityModified = true;
          if (element.offerId) {
            modifiedElement.quantityModified = false;
            element.quantityModified = false;
            this.modifiedOfferIds.indexOf(element.offerId) !== -1 && this.modifiedOfferIds.splice(this.modifiedOfferIds.indexOf(element.offerId), 1)
          } else {
            modifiedElement.quantityModified = false;
            element.quantityModified = false;
            this.modifiedOrgIds.indexOf(element.orgId) !== -1 && this.modifiedOrgIds.splice(this.modifiedOrgIds.indexOf(element.orgId), 1)
          }
        }
        if (modifiedElement.allocatedQuantity !== element.allocatedQuantity || element.quantityModified) {
          isAllocModified = true;
          modifiedElement.quantityModified = true;
          if (element.offerId) {
            this.modifiedOfferIds.push(element.offerId);
          } else {
            this.modifiedOrgIds.push(element.orgId);
          }
        }
      }
    }

    this.modifiedOfferIds = Array.from(new Set(this.modifiedOfferIds));
    this.modifiedOrgIds = Array.from(new Set(this.modifiedOrgIds));

    if (this.modifiedOfferIds.length) { localStorage.setItem('modified_offers', JSON.stringify(this.modifiedOfferIds)); }
    if (this.modifiedOrgIds.length) { localStorage.setItem('modified_orgs', JSON.stringify(this.modifiedOrgIds)); }
    return (isRequestModified || this.modifiedOfferIds.length || this.modifiedOrgIds.length) ? true : false;
  }


  sortList(sortParam) {
    this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
    this.sortParam = sortParam;
    this.getfoodBankForDirectOffer();
  }

  isCharLengthValid(value, limit, event?) {
    if (value && value.toString().length >= limit) {
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
  }
}

