import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocationMethodDirectOfferFormComponent } from './allocation-method-direct-offer-form.component';

describe('AllocationMethodDirectOfferFormComponent', () => {
  let component: AllocationMethodDirectOfferFormComponent;
  let fixture: ComponentFixture<AllocationMethodDirectOfferFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllocationMethodDirectOfferFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllocationMethodDirectOfferFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
