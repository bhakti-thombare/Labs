import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocationMethodFoodOfferFormComponent } from './allocation-method-food-offer-form.component';

describe('AllocationMethodFoodOfferFormComponent', () => {
  let component: AllocationMethodFoodOfferFormComponent;
  let fixture: ComponentFixture<AllocationMethodFoodOfferFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllocationMethodFoodOfferFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllocationMethodFoodOfferFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
