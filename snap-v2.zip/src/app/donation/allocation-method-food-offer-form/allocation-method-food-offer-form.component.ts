import { ChangeDetectorRef, Input, ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { foodOfferAllocationTableSortParam } from '../shared/enums/donation.enum';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-allocation-method-food-offer-form',
  templateUrl: './allocation-method-food-offer-form.component.html',
  styleUrls: ['./allocation-method-food-offer-form.component.scss']
})
export class AllocationMethodFoodOfferFormComponent implements OnInit {

  @Input() donationDetail: any;
  donationId: any;
  totalRequestedQuantity = 0;
  totalAllocatedQuantity = 0;
  toolTipContent: any;
  originalQuantityPallets: any;
  progressPercentage = 100;
  quantityText = 'remaining';
  sortParam: any;
  order = 'ASC';
  public get foodOfferAllocationTableSortParam(): typeof foodOfferAllocationTableSortParam {
    return foodOfferAllocationTableSortParam;
  }
  selectedFilters = ['OFFERED', 'ACCEPTED', 'ALLOCATED', 'DECLINED', 'CONFIRMED', 'NOT_OFFERED'];
  filters = [
    {
      selected: true,
      status: 'OFFERED',
      count: null
    },
    {
      selected: true,
      status: 'NOT_OFFERED',
      count: null
    },
    {
      selected: true,
      status: 'ACCEPTED',
      count: null
    },
    {
      selected: true,
      status: 'ALLOCATED',
      count: null
    },
    {
      selected: true,
      status: 'DECLINED',
      count: null
    },
    {
      selected: true,
      status: 'CONFIRMED',
      count: null
    }
  ];

  pageSize = 7;
  currentPage = 1;
  total = 0;
  delta = 2;
  totalPages: number;
  mouseLeftPopover: boolean;
  observer: any;
  popover: any;
  onPop = false;
  @ViewChild('pop', { static: true }) pop: any;
  hoveredOfferDetails: any;
  showPopover: any;
  hoveredItem: any;
  tempContent: any;
  foodOfferAllocationListBackUp: any;
  modifiedOfferIds = [];

  constructor(
    private router: Router,
    private ref: ChangeDetectorRef,
    private activatedRoute: ActivatedRoute,
    private utilityService: UtilityService,
    private generalService: GeneralService,
    private notificationService: NotificationService
  ) { }
  foodOfferAllocationList = [];
  ngOnInit() {
    this.donationId = this.activatedRoute.snapshot.paramMap.get('id');
    this.originalQuantityPallets = JSON.parse(JSON.stringify(this.donationDetail.quantityPallets));
    // this.getfoodBankForFoodOffer();
    this.sortList(foodOfferAllocationTableSortParam.DELTA);
  }

  getfoodBankForFoodOffer() {

    const queryParams: any = {
      // pageNo: this.currentPage - 1,
      // pageSize: this.pageSize,
      filter: this.selectedFilters.join(',')
    }

    if (this.sortParam && this.order) {
      queryParams.sort = this.sortParam;
      queryParams.order = this.order;
    }
    this.generalService.getFoodBanksForFoodOffer(this.donationId, queryParams).subscribe(res => {


      this.total = res.payload && res.payload.count || 0;
      this.foodOfferAllocationList = res.payload && res.payload.list;
      this.foodOfferAllocationListBackUp = JSON.parse(JSON.stringify(this.foodOfferAllocationList));
      this.foodOfferAllocationList.forEach(element => {
        element.percentOfHungerCount = element.percentOfHungerCount && +element.percentOfHungerCount.toFixed(2) || 0;
        element.percentOfDdeltaFactor = element.percentOfDdeltaFactor && +element.percentOfDdeltaFactor.toFixed(2) || 0;
        element.percentOfFoodOffer = element.percentOfFoodOffer && +element.percentOfFoodOffer.toFixed(2) || 0;
        if (!element.allocatedQuantity && element.allocatedQuantity !== 0) {
          element.allocatedQuantity = null;
        }
        if (!element.requestedQuantity && element.requestedQuantity !== 0) {
          element.requestedQuantity = null;
        }
      });
      this.totalAllocatedQuantity = this.updateAllocationData('allocatedQuantity');
      this.totalRequestedQuantity = this.updateAllocationData('requestedQuantity');
      this.updateQuantityPallet();

    });
  }


  inputChanged(event, index, key) {
    switch (key) {
      case 'requestedQuantity':
        this.foodOfferAllocationList[index].requestedQuantity = event || 0;
        this.totalRequestedQuantity = this.updateAllocationData(key);
        break;
      case 'allocatedQuantity':
        this.foodOfferAllocationList[index].allocatedQuantity = event || 0;
        this.totalAllocatedQuantity = this.updateAllocationData(key);
        this.updateQuantityPallet();
        break;
    }

    this.ref.detectChanges();


  }


  allowOnlyFloat(txt, event) {
    return this.utilityService.allowOnlyFloat(txt, event);
  }

  updateAllocationData(key) {
    let tempValue = 0;
    for (const element of this.foodOfferAllocationList) {
      if (element[key]) {
        tempValue = tempValue + element[key] || 0;
      }
    }
    return tempValue;
  }

  updateQuantityPallet() {
    this.donationDetail.quantityPallets = JSON.parse(JSON.stringify(this.originalQuantityPallets));

    this.donationDetail.quantityPallets = this.donationDetail.quantityPallets - this.totalAllocatedQuantity;

    this.updateProgressBar();
  }

  updateProgressBar() {
    this.progressPercentage = (this.donationDetail.quantityPallets / this.originalQuantityPallets) * 100;
    if (this.donationDetail.quantityPallets < 0) {
      this.progressPercentage = 0;
      this.quantityText = 'over available';
    } else {
      this.quantityText = 'remaining';
    }
  }

  isValid() {
    if (this.totalAllocatedQuantity > this.originalQuantityPallets) {
      return false;
    }
    for (const element of this.foodOfferAllocationList) {
      if (element.requestedQuantity > this.originalQuantityPallets ||
        element.allocatedQuantity > element.requestedQuantity) {
        return false;
      }
    }
    return true;
  }

  getSelectedFoodBanks() {
    const tempArr = [];
    for (const element of this.foodOfferAllocationList) {

      const isModified = this.isValueModified(element);
      if (
        (element.requestedQuantity || element.requestedQuantity === 0) ||
        (element.allocatedQuantity || element.allocatedQuantity === 0)) {
        tempArr.push({
          allocatedQuantity: element.allocatedQuantity || 0,
          foodBankId: element.orgId,
          requestedQuantity: element.requestedQuantity || 0,
          status: isModified ? this.getStatus(element) : element.status,
          quantityModified: this.modifiedOfferIds.length && this.modifiedOfferIds.includes(element.id) ? true : false
        });
      }
    }

    return tempArr;
  }

  getStatus(element) {
    if (element.allocatedQuantity > 0) {
      return 'ACCEPTED';
    } else if (element.requestedQuantity > 0) {
      return 'ACCEPTED';
    } else {
      return element.status;
    }
  }

  isValueModified(modifiedElement) {
    let isRequestModified = false;
    let isAllocModified = false;
    for (const element of this.foodOfferAllocationListBackUp) {


      if (modifiedElement.orgId === element.orgId) {
        if (modifiedElement.requestedQuantity !== element.requestedQuantity || element.quantityModified) {
          // modifiedElement.quantityModified = true;
          isRequestModified = true;
        }
        if (modifiedElement.allocatedQuantity !== element.allocatedQuantity || element.quantityModified) {
          modifiedElement.quantityModified = true;
          isAllocModified = true;
          this.modifiedOfferIds.push(element.id);
        }
      }
    }

    this.modifiedOfferIds = Array.from(new Set(this.modifiedOfferIds));

    if (this.modifiedOfferIds.length) { localStorage.setItem('modified_offers', JSON.stringify(this.modifiedOfferIds)); }
    return isRequestModified || isAllocModified ? true : false;
  }
  goToReviewFoodOfferPage(value) {
    if (!this.isValid()) {
      this.notificationService.showError('Please make sure fields have valid data.');
      return false;
    }


    // if (this.modifiedOfferIds.length) { localStorage.setItem('modified_offers', JSON.stringify(this.modifiedOfferIds)); }
    const data = {
      allocations: this.getSelectedFoodBanks(),
      comment: this.donationDetail.comments,
      donationId: this.donationId,
    };

    this.generalService.submitFoodOffer(data).subscribe(res => {
      if (value === 'SUBMIT') {
        if (this.modifiedOfferIds.length) {
          this.router.navigateByUrl('/donation/review-food-offer/' + this.donationId);
        } else {
          this.notificationService.showSuccess('Food offer details saved.');
          this.getfoodBankForFoodOffer();
        }

      } else {
        this.notificationService.showSuccess('Food offer saved successfully.');
        this.getfoodBankForFoodOffer();
      }

    });
  }


  filterClicked(item, event) {
    item.selected = event.target.checked;

    this.selectedFilters = [];
    for (const element of this.filters) {
      if (element.selected) {
        this.selectedFilters.push(element.status);
      }
    }

    this.getfoodBankForFoodOffer();
  }

  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {

    if (this.getSelectedFoodBanks().length) {
      this.goToReviewFoodOfferPage('PAGE_CHANGE');
    }
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getfoodBankForFoodOffer();
  }


  setHoverDetails(allocationItem, pop) {
    this.popover = pop;
    this.hoveredOfferDetails = {
      foodBankName: allocationItem.foodBankName,
      foodBankId: allocationItem.orgId,
      offerType: this.donationDetail.allocationMethod
    };
  }
  handlePopOverHide(pop) {


    // this.onPop = false;
    setTimeout(() => {
      if (!this.onPop) {
        pop.hide()

      } else {
        pop.show()

      }
    }, 100);
  }

  mouseenter(event) {

  }


  mouseExitPop(event) {

    this.popover.hide();

  }

  sortList(sortParam) {
    this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
    this.sortParam = sortParam;
    this.getfoodBankForFoodOffer();
  }

  isCharLengthValid(value, limit, event?) {
    if (value && value.toString().length >= limit) {
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
  }

}
