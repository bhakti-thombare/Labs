import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { GeneralService } from '../shared/services/general.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { AuthService } from 'src/app/core/services/auth.service';
import { DONATION_STATUS } from '../../home/shared/donation';
import { donationListSortParam } from '../shared/enums/donation.enum';

@Component({
  selector: 'app-donation-list',
  templateUrl: './donation-list.component.html',
  styleUrls: ['./donation-list.component.scss']
})
export class DonationListComponent implements OnInit {

  newDonationList = [];
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  currentUser: any;
  currentPage = 1;
  pageSize = 15;
  total = 0;
  delta = 2;
  totalPages: number;
  toolTipContent = '';

  sortParam: any;
  order = 'ASC';
  public get donationListSortParam(): typeof donationListSortParam {
    return donationListSortParam;
  }
  constructor(
    private router: Router,
    private authService: AuthService,
    private generalService: GeneralService,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {
    this.loadUser();
    this.getNewDonations();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }
  getNewDonations() {
    const queries: any = {
      pageNo: this.currentPage - 1,
      pageSize: this.pageSize
    };

    if (this.sortParam && this.order) {
      queries.sort = this.sortParam;
      queries.order = this.order;
    }
    this.generalService.getAllDonations(queries).subscribe(res => {
      this.total = parseInt(res.count || 0, 10);
      this.newDonationList = res.donationList.filter(item =>
        (item.donationStatus !== DONATION_STATUS.DONATION_CREATED) &&
        (item.donationStatus !== null));
      
    });
  }


  handleDonationRequest(donationName, value, id) {
    let key = '';
    let message = '';
    if (value) {
      key = 'APPROVED';
      message = 'approve';
    } else {
      key = 'REJECTED';
      message = 'reject';
    }
    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: `Are you sure that you want ${message} ${donationName} donation request?`,
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {
          
          const data = {
            action: key
          };
          this.generalService.handleDonationRequest(data, id).subscribe(res => {
            this.notificationService.showSuccess(`Donation ${value ? 'accepted' : 'rejected'}.`);
            this.getNewDonations();
          });
        }
      },
    });
  }
  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {
    // 
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getNewDonations();
  }
  completeDonation(id) {
    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: `Are you sure that you want perform this action?`,
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {

          this.generalService.completeDonation(id).subscribe(res => {
            this.notificationService.showSuccess('Donation marked completed.');
            this.getNewDonations();
          });
        }
      },
    });

  }


  sortList(sortParam) {
    this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
    this.sortParam = sortParam;
    this.getNewDonations();
  }
}
