import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DonationDashboardComponent } from './donation-dashboard/donation-dashboard.component';
import { DonationFormComponent } from './donation-form/donation-form.component';
import { PageUnderDevelopmentComponent } from '../shared/components/page-under-development/page-under-development.component';
import { ViewDonationDetailsComponent } from './view-donation-details/view-donation-details.component';
import { AllocateDonationFormComponent } from './allocate-donation-form/allocate-donation-form.component';
import { DonationDetailsComponent } from './donation-details/donation-details.component';
import { UserAuthGuard } from '../core/guards/user-auth.guard';
import { AdminAuthGuard } from '../core/guards/admin-auth.guard';
import { DonationEditFormComponent } from './donation-edit-form/donation-edit-form.component';
import { DonationCreateFormComponent } from './donation-create-form/donation-create-form.component';
import { ReviewDirectOfferDetailsComponent } from './review-direct-offer-details/review-direct-offer-details.component';
import { DonationListComponent } from './donation-list/donation-list.component';
import {
  DonationShipmentConfirmationListComponent
} from './donation-shipment-confirmation-list/donation-shipment-confirmation-list.component';
import { ReviewDryHubOfferDetailsComponent } from './review-dry-hub-offer-details/review-dry-hub-offer-details.component';
import { ReviewFoodOfferDetailsComponent } from './review-food-offer-details/review-food-offer-details.component';


const routes: Routes = [
  {
    path: '', canActivate: [UserAuthGuard], component: DonationDashboardComponent, children: [
      { path: '', redirectTo: 'list', pathMatch: 'full' },
      { path: 'list', canActivate: [AdminAuthGuard], component: DonationListComponent },
      { path: 'new', component: DonationCreateFormComponent },
      { path: 'view-allocate/:id', canActivate: [AdminAuthGuard], component: DonationDetailsComponent },
      { path: 'shipment-confirmation/:id', canActivate: [AdminAuthGuard], component: DonationShipmentConfirmationListComponent },
      { path: 'edit/:id', canActivate: [AdminAuthGuard], component: DonationEditFormComponent },
      { path: 'review-direct-offer/:id', canActivate: [AdminAuthGuard], component: ReviewDirectOfferDetailsComponent },
      { path: 'review-dry-hub-offer/:id', canActivate: [AdminAuthGuard], component: ReviewDryHubOfferDetailsComponent },
      { path: 'review-food-offer/:id', canActivate: [AdminAuthGuard], component: ReviewFoodOfferDetailsComponent }
    ]
  },
  { path: 'form', component: DonationFormComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DonationRoutingModule { }
