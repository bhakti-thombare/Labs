import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonationCreateFormComponent } from './donation-create-form.component';

describe('DonationCreateFormComponent', () => {
  let component: DonationCreateFormComponent;
  let fixture: ComponentFixture<DonationCreateFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonationCreateFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonationCreateFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
