import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonationDashboardComponent } from './donation-dashboard.component';

describe('DonationDashboardComponent', () => {
  let component: DonationDashboardComponent;
  let fixture: ComponentFixture<DonationDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonationDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonationDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
