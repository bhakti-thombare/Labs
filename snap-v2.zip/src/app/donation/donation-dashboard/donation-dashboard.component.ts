import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-donation-dashboard',
  templateUrl: './donation-dashboard.component.html',
  styleUrls: ['./donation-dashboard.component.scss']
})
export class DonationDashboardComponent implements OnInit {
  id: string;
  showQuickLinks = false;
  currentUser: any;
  selectedTab: any;
  currentRoute: string;

  constructor(
    private authService: AuthService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      if (
        event.url.includes('donation/edit') ||
        event.url.includes('donation/shipment-confirmation') ||
        event.url.includes('donation/new') ||
        event.url.includes('donation/review-direct-offer') ||
        event.url.includes('donation/review-food-offer') ||
        event.url.includes('donation/review-dry-hub-offer')) {
        this.showQuickLinks = true;
      } else {
        this.showQuickLinks = false;
      }
      this.currentRoute = event.url;
      this.id = this.activatedRoute.firstChild.snapshot.paramMap.get('id');
      this.setLowerTabOptions();
    });
  }
  donationOptions = [];
  ngOnInit() {
    
    this.id = this.activatedRoute.firstChild.snapshot.paramMap.get('id');
    
    this.setLowerTabOptions();
    this.loadUser();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  setLowerTabOptions() {
    
    if (this.id) {
      this.donationOptions = [

        { title: 'List', selected: false, url: '/donation/list' },
        { title: 'View/Allocate', selected: false, url: '/donation/view-allocate/' + this.id },
        { title: 'Edit', selected: false, url: '/donation/edit/' + this.id },
        { title: 'Shipment Confirmation', selected: false, url: '/donation/shipment-confirmation/' + this.id }
      ];
    } else {
      this.donationOptions = [

        { title: 'List', selected: false, url: '/donation/list' },
        { title: 'New', selected: false, url: '/donation/new' },
      ];
    }
    for (const option of this.donationOptions) {
      if (this.currentRoute.includes(option.url) || option.url.includes(this.currentRoute)) {
        this.selectedTab = this.getHeader(option.title);
        break;
      }
    }
  }

  getHeader(option) {
    option = option.toString().toLowerCase();
    
    switch (option) {
      case 'list':
        return 'Donations';
      case 'new':
        return 'Create new donation';
      case 'edit':
        return 'Edit donation';
      case 'view/allocate':
        return 'Donation details';
      case 'shipment confirmation':
        return 'Shipment confirmation';

    }
  }

}
