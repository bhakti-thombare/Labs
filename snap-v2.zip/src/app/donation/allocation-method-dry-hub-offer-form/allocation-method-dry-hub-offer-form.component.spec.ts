import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocationMethodDryHubOfferFormComponent } from './allocation-method-dry-hub-offer-form.component';

describe('AllocationMethodDryHubOfferFormComponent', () => {
  let component: AllocationMethodDryHubOfferFormComponent;
  let fixture: ComponentFixture<AllocationMethodDryHubOfferFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllocationMethodDryHubOfferFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllocationMethodDryHubOfferFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
