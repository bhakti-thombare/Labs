import { ChangeDetectorRef, Component, Input, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { dryHubOfferAllocationTableSortParam } from '../shared/enums/donation.enum';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-allocation-method-dry-hub-offer-form',
  templateUrl: './allocation-method-dry-hub-offer-form.component.html',
  styleUrls: ['./allocation-method-dry-hub-offer-form.component.scss']
})
export class AllocationMethodDryHubOfferFormComponent implements OnInit {
  donationId: string;
  @Input() donationDetail: any;

  totalAllocatedQuantity = 0;
  allocationList: any;
  toolTipContent: any;
  originalQuantityPallets: any;
  progressPercentage = 100;
  quantityText = 'remaining';
  currentTypedAllocation: any;
  sortParam: any;
  order = 'ASC';
  allocationListBackup: any;
  public get dryHubOfferAllocationTableSortParam(): typeof dryHubOfferAllocationTableSortParam {
    return dryHubOfferAllocationTableSortParam;
  }
  selectedFilters = ['ALLOCATED', 'NOT_ALLOCATED', 'CONFIRMED'];
  filters = [

    {
      selected: true,
      status: 'ALLOCATED',
      count: null
    },
    {
      selected: true,
      status: 'NOT_ALLOCATED',
      count: null
    },
    {
      selected: true,
      status: 'CONFIRMED',
      count: null
    }
  ];
  mouseLeftPopover: boolean;
  observer: any;
  popover: any;
  onPop = false;
  @ViewChild('pop', { static: true }) pop: any;
  hoveredOfferDetails: any;
  showPopover: any;
  hoveredItem: any;
  tempContent: any;

  // selectedFilters = ['OFFERED', 'ACCEPTED', 'ALLOCATED', 'NOT_OFFERED', 'DECLINED'];
  // filters = [
  //   {
  //     selected: true,
  //     status: 'OFFERED',
  //     count: null
  //   },
  //   {
  //     selected: true,
  //     status: 'ACCEPTED',
  //     count: null
  //   },
  //   {
  //     selected: true,
  //     status: 'ALLOCATED',
  //     count: null
  //   },
  //   {
  //     selected: true,
  //     status: 'NOT_OFFERED',
  //     count: null
  //   },
  //   {
  //     selected: true,
  //     status: 'DECLINED',
  //     count: null
  //   }
  // ];
  pageSize = 7;
  currentPage = 1;
  total = 0;
  delta = 2;
  totalPages: number;


  constructor(
    private router: Router,
    private cdRef: ChangeDetectorRef,
    private activatedRoute: ActivatedRoute,
    private notificationService: NotificationService,
    private generalService: GeneralService,
    private utilityService: UtilityService) { }

  ngOnInit() {
    this.donationId = this.activatedRoute.snapshot.paramMap.get('id');
    this.originalQuantityPallets = JSON.parse(JSON.stringify(this.donationDetail.quantityPallets));
    // this.getFoodBanksForDryHubOffer();
    this.sortList(dryHubOfferAllocationTableSortParam.DELTA);
  }

  onlyNumberKey(event) {
    return this.utilityService.onlyNumberKey(event);
  }

  getFoodBanksForDryHubOffer() {
    const queryParams: any = {
      // pageNo: this.currentPage - 1,
      // pageSize: this.pageSize,
      filter: this.selectedFilters.join(',')
    };
    if (this.sortParam && this.order) {
      queryParams.sort = this.sortParam;
      queryParams.order = this.order;
    }
    this.generalService.getFoodBanksForDryHubOffer(this.donationId, queryParams).subscribe(res => {

      this.total = res.payload.count;
      this.allocationList = res.payload.dryHubOfferList || [];
      this.allocationListBackup = JSON.parse(JSON.stringify(this.allocationList));
      this.roundOffFloatValues(this.allocationList);
      if (this.allocationList && this.allocationList.length) {
        this.totalAllocatedQuantity = this.updateAllocationData('allocatedQuantity');
        this.updateQuantityPallet();
      }
    });
  }

  goToReviewDryHubOfferPage(status?) {
    if (!this.isValid()) {
      this.notificationService.showError('Please make sure fields have valid data.');
      return false;
    }

    const data = {
      allocations: this.getSelectedFoodBanks(status),
      comment: this.donationDetail.comments,
      donationId: parseInt(this.donationId, 10)
    };

    this.generalService.submitDryHubOffer(data).subscribe(res => {
      if (status === 'ALLOCATED') {
        this.notificationService.showSuccess('Dry hub allocation sent.');
        this.router.navigateByUrl('/donation/review-dry-hub-offer/' + this.donationId);
      } else {
        if (status === 'DRAFT') {
          this.notificationService.showSuccess('Saved as draft.');
        }
      }
      // this.generalService.updateDonation(this.donationDetail, this.donationId).subscribe(res2 => { });
    });
  }

  isValid() {
    if (this.originalQuantityPallets < this.totalAllocatedQuantity) {
      return false;
    }
    return true;
  }
  getSelectedFoodBanks(value) {
    const tempArr = [];
    let i = 0;
    for (const element of this.allocationList) {
      if ((element.allocatedQuantity || element.allocatedQuantity === 0) && element.status !== 'CONFIRMED') {
        if (this.valueModified(element, i)) {
          tempArr.push({
            allocatedQuantity: element.allocatedQuantity || 0,
            foodBankId: element.orgId,
            status: value === 'PAGE_CHANGE' ? element.status : value
          });
        }
      }
      i++;
    }

    return tempArr;
  }

  valueModified(modifiedElement, index) {
    if (modifiedElement.allocatedQuantity !== this.allocationListBackup[index].allocatedQuantity) {
      return true;
    } else {
      return false;
    }
  }

  inputChanged(event, index) {


    this.allocationList[index].allocatedQuantity = event || 0;
    this.totalAllocatedQuantity = this.updateAllocationData('allocatedQuantity');
    this.updateQuantityPallet();
    this.cdRef.detectChanges();
  }

  updateAllocationData(key) {
    let tempValue = 0;
    for (const element of this.allocationList) {
      if (element[key]) {
        tempValue = tempValue + element[key] || 0;
      }
    }
    return tempValue;
  }

  updateQuantityPallet() {
    this.donationDetail.quantityPallets = JSON.parse(JSON.stringify(this.originalQuantityPallets));

    this.donationDetail.quantityPallets = this.donationDetail.quantityPallets - this.totalAllocatedQuantity;

    this.updateProgressBar();
  }


  updateProgressBar() {
    this.progressPercentage = (this.donationDetail.quantityPallets / this.originalQuantityPallets) * 100;
    if (this.donationDetail.quantityPallets < 0) {
      this.progressPercentage = 0;
      this.quantityText = 'over available';
    } else {
      this.quantityText = 'remaining';
    }
  }

  allowOnlyFloat(txt, event) {


    return this.utilityService.allowOnlyFloat(txt, event);
  }

  filterClicked(item, event) {
    item.selected = event.target.checked;

    this.selectedFilters = [];
    for (const element of this.filters) {
      if (element.selected) {
        this.selectedFilters.push(element.status);
      }
    }

    this.getFoodBanksForDryHubOffer();
  }

  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {

    if (this.getSelectedFoodBanks('PAGE_CHANGE').length) {
      this.goToReviewDryHubOfferPage('PAGE_CHANGE');
    }
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getFoodBanksForDryHubOffer();
  }


  setHoverDetails(allocationItem, pop) {
    this.popover = pop;
    this.hoveredOfferDetails = {
      foodBankName: allocationItem.shortName,
      foodBankId: allocationItem.orgId,
      offerType: this.donationDetail.allocationMethod
    };
  }
  handlePopOverHide(pop) {


    // this.onPop = false;
    setTimeout(() => {
      if (!this.onPop) {
        pop.hide()

      } else {
        pop.show()

      }
    }, 100);
  }

  mouseenter(event) {

  }


  mouseExitPop(event) {

    this.popover.hide();

  }

  roundOffFloatValues(list) {
    for (const item of list) {
      item.dryHubDelta = item.dryHubDelta && +item.dryHubDelta.toFixed(2) || 0;
      item.dryHubOfferPercent = item.dryHubOfferPercent && +item.dryHubOfferPercent.toFixed(2) || 0;
      item.hcPercent = item.hcPercent && +item.hcPercent.toFixed(2) || 0;
    }

  }


  sortList(sortParam) {
    this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
    this.sortParam = sortParam;
    this.getFoodBanksForDryHubOffer();
  }

  isCharLengthValid(value, limit, event?) {
    if (value && value.toString().length >= limit) {
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
  }
}
