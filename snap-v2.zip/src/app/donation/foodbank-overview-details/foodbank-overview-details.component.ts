import { Component, Input, OnInit } from '@angular/core';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-foodbank-overview-details',
  templateUrl: './foodbank-overview-details.component.html',
  styleUrls: ['./foodbank-overview-details.component.scss']
})
export class FoodbankOverviewDetailsComponent implements OnInit {
  @Input() offerDetails: any;
  overViewDetails: any;
  showLoader = false;
  constructor(
    private utilityService: UtilityService,
    private generalService: GeneralService
  ) { }

  ngOnInit() {
    
    this.getFoodBankOverViewDetails();
  }

  getFoodBankOverViewDetails() {
    const queryParams: any = {
      offerType: this.offerDetails.offerType,
      hideLoader: true
    };
    this.showLoader = true;
    this.generalService.getFoodBankOverViewDetails(this.offerDetails.foodBankId, queryParams).subscribe(res => {
      this.overViewDetails = res.payload;
      this.showLoader = false;
      for (const element of this.overViewDetails.donationDetailsByHoveringDto) {
        element.offerDate = this.utilityService.convertToLocalTimeZone(element.offerDate, 'DD MMM yyyy');
      }
    });
  }

}
