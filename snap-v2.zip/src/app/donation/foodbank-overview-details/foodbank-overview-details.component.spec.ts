import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodbankOverviewDetailsComponent } from './foodbank-overview-details.component';

describe('FoodbankOverviewDetailsComponent', () => {
  let component: FoodbankOverviewDetailsComponent;
  let fixture: ComponentFixture<FoodbankOverviewDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoodbankOverviewDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodbankOverviewDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
