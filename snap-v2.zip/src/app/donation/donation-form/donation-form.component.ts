import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { GeneralService } from 'src/app/donation/shared/services/general.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { UtilityService } from 'src/app/core/services/utility.service';
import { forkJoin, Observable, Observer, of } from 'rxjs';
import * as _ from 'lodash';
import { FileUploader } from 'ng2-file-upload';
import { DONATION_STATUS } from 'src/app/home/shared/donation';
import { filter, map, switchMap, tap } from 'rxjs/operators';
@Component({
  selector: 'app-donation-form',
  templateUrl: './donation-form.component.html',
  styleUrls: ['./donation-form.component.scss']
})
export class DonationFormComponent implements OnInit {
  // public lettersOnlyCustomPatterns = {'S': { pattern: new RegExp('\[a-zA-Z \]')}};
  public numbersOnlycustomPatterns = {'0': { pattern: new RegExp('^[0-9 ]*$')}};
  public lettersAndNumbersCustomPatterns = {'A': { pattern: new RegExp('\[a-zA-Z0-9 \]')}};

  uploader: any = new FileUploader({
    disableMultipart: false // 'DisableMultipart' must be 'true' for formatDataFunction to be called.
  });

  donationForm: FormGroup;
  token: string;
  donationId: string;
  submitted = false;
  donationDetails: any;
  shipmentOptions: any;
  foodTemperatureOptions: any;
  donationWeightOptions: any;
  foodCategoryOptions: any;
  donorLocations: any;
  fileList: any[] = [];
  search: string;
  suggestions$: Observable<any[]>;
  errorMessage: string;
  selectedSource: any;
  WeightUnitOptions: any;


  constructor(
    private utilityService: UtilityService,
    private activatedRoute: ActivatedRoute,
    private notificationService: NotificationService,
    private generalService: GeneralService,
    private formBuilder: FormBuilder) {
    this.setDefaultSource();
  }

  ngOnInit() {
    this.token = this.activatedRoute.snapshot.queryParamMap.get('token');
    this.donationId = this.activatedRoute.snapshot.queryParamMap.get('id');

    this.getAllDropDownOptions();
    this.getDonationForm();
    this.buildDonationForm();
    this.getSourceSuggestions();
  }
  buildDonationForm() {
    this.donationForm = this.formBuilder.group({
      // donationName: ['', Validators.required],
      productDescription: [null, Validators.required],
      bbdate: [null],
      expiryDate: [null],
      quantityPallets: ['', Validators.required],
      weightPerPalletOrBox: ['', Validators.required],
      weightInKgOrLbs: ['kg', Validators.required],
      foodTemperature: [null, Validators.required],
      shipmentOption: [null, Validators.required],
      details: [''],
      attachment: [null],
      // adminComments: [''],
      // feedOntarioId: [''],
      // donationCode: [''],
      source: ['', Validators.required],
      offerDate: [null, Validators.required],
      donationWeightIn: [null, Validators.required],
      foodCategory: [null, Validators.required],
      locationOfOrigin: [null, Validators.required],
      comments: [''],
    });

  }
  submit(value) {
    if (this.checkValidity(value)) {
      let data = this.donationForm.value;
      data.bbdate = data.bbdate && moment(data.bbdate).format('YYYY-MM-DD') || '';
      data.expiryDate = data.expiryDate && moment(data.expiryDate).format('YYYY-MM-DD') || '';
      data.offerDate = data.offerDate && moment(data.offerDate).format('YYYY-MM-DD') || '';
      data.bbDate = data.bbdate || '';
      data.bBdate = data.bbdate || '';
      data.locationOfOrigin = +data.locationOfOrigin;
      data.attachment = ''; // this.getAttachmentIds();

      data = this.dateCorrection(data);
      let message = 'saved';
      if (value === 'save') {
        data.donationStatus = DONATION_STATUS.DONATION_SAVED;
      } else {
        message = 'submitted';
        data.donationStatus = DONATION_STATUS.DONATION_SUBMIT;
      }

      data.source = this.selectedSource && this.selectedSource.id || null;
      this.generalService.createDonation(data, this.token).subscribe(res => {
        this.notificationService.showSuccess(`Donation ${message} successfully`);
        (document.getElementById('attachment') as HTMLInputElement).value = '';
        if (value !== 'save') {
          this.donationForm.reset();
        }
      });
    }
  }

  dateCorrection(data) {
    if (data.bbdate === 'Invalid date') {
      data.bbdate = '';
    }
    if (data.bBDate === 'Invalid date') {
      data.bBDate = '';
    }
    if (data.expiryDate === 'Invalid date') {
      data.expiryDate = '';
    }
    if (data.offerDate === 'Invalid date') {
      data.offerDate = '';
    }
    return data;
  }

  uploadFile(file) {
    if (true) {
      const formData = new FormData();
      formData.append('file', file);

      this.generalService.uploadFile(formData, this.donationId).subscribe(res => {
        file.id = res.payload.id;
        this.fileList.push(file);

      });
    }
  }


  getAttachmentIds() {
    const attachments = [];
    for (const file of this.fileList) {
      attachments.push(file.id);
    }
    return attachments;
  }


  checkValidity(value) {

    if (this.donationForm.invalid) {
      this.notificationService.showError('Please fill all mandatory fields with valid data.');
      this.turnFormControlsDirty(this.donationForm);
      return false;
    }
    return true;
  }

  turnFormControlsDirty(form: any) {
    this.utilityService.turnFormControlsDirty(form);
  }

  onFileSelect(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];

      this.donationForm.get('attachment').setValue(file);
      // this.uploadFile();
    }
  }

  getDonationForm() {
    return this.generalService.getDonationById(this.donationId).subscribe(res => {
      this.donationDetails = res;
      if (this.donationDetails) {
        this.patchDonationForm();
      }
      this.donorLocations = this.donationDetails.donorId.locations;
    });
  }
  getFoodTemperatureOptions() {
    return this.generalService.getFoodTempatureOptions();
  }

  getShipmentOptions() {
    return this.generalService.getShipmentOptions();
  }
  getDonationWeightOptions() {
    return this.generalService.getDonationWeightOptions();
  }
  getFoodCategoryOptions() {
    return this.generalService.getFoodCategoryOptions();
  }

  uploadHandler(event) {

    const file = event[0];
    if (this.fileList.length <= 3) {
      if (file) {
        if (this.checkFileValidity(file)) {
          this.uploadFile(file);
        }
      }
    }
  }

  showNotification(event: any) {
    event.stopPropagation();
    event.preventDefault();
    this.notificationService.showError('Only three files can be selected');
  }

  checkFileValidity(file) {

    if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
      file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
      file.type === 'application/msword' ||
      file.type === 'application/pdf' ||
      file.type.split('/')[0] === 'image'
    ) {
      if (file.name.includes(' ')) {
        this.notificationService.showError('File name should not contain space.');
        return false;
      }
      return true;
    }
    this.notificationService.showError('File type should be image / pdf / doc / docx/ xsls');
    return false;
  }

  removeFile(index) {

    if (this.fileList.length) {
      this.deleteDocument(this.fileList[index].id);
      this.fileList.splice(index, 1);
    }
  }



  patchDonationForm() {
    this.donationForm.patchValue({
      // donationName: this.donationDetails.donationName,
      productDescription: this.donationDetails.productDescription,
      bbdate: this.donationDetails.bbDate,
      expiryDate: this.donationDetails.expiryDate,
      quantityPallets: this.donationDetails.quantityPallets,
      weightPerPalletOrBox: this.donationDetails.weightPerPalletOrBox,
      weightInKgOrLbs: this.donationDetails.weightInKgOrLbs || 'kg',
      foodTemperature: this.donationDetails.foodTemperature,
      shipmentOption: this.donationDetails.shipmentOption,
      details: this.donationDetails.details,
      attachment: this.donationDetails.attachment,
      // adminComments: this.donationDetails.adminComments,
      // feedOntarioId: this.donationDetails.feedOntarioId,
      // donationCode: this.donationDetails.donationCode,
      source: this.donationDetails.source && this.donationDetails.source.name || this.search,
      offerDate: this.donationDetails.offerDate && new Date(this.donationDetails.offerDate) || null,
      donationWeightIn: this.donationDetails.donationWeightIn,
      foodCategory: this.donationDetails.foodCategory,
      locationOfOrigin: this.donationDetails.locationOfOrigin && this.donationDetails.locationOfOrigin.location_id || null,
      comments: this.donationDetails.comments,
    });
    if (this.donationDetails.source) {
      this.selectedSource = this.donationDetails.source;
    }
  }

  getSourceSuggestions() {
    this.suggestions$ = new Observable((observer: Observer<string>) => {
      observer.next(this.search);
    }).pipe(
      filter(query => this.search && this.search.toString().trim() && this.search.toString().trim().length > 2),
      switchMap((query: string) => {
        if (query) {
          return this.generalService.getFoodBanksByName({ name: query }).pipe(
            map((data: any) => data && data.payload || []),
            tap((noop) => noop, err => {
              // in case of http error
              this.errorMessage = err && err.message || 'Something goes wrong';
            })
          );
        }

        return of([]);
      })
    );
  }

  onSourceSelect(event) {

    this.selectedSource = event.item;
  }


  allowOnlyFloat(value, event, limit) {
    if (value && value.length >= limit) {
      this.notificationService.showError(`Only ${limit} characters allowed.`);
    }
    // return this.utilityService.allowOnlyFloat(value, event);
    if(this.utilityService.allowOnlyFloat(value,event)){
      return true;
    }
    else{
      this.notificationService.showError('Only numbers are allowed.');
      return false;
    }
  }
  getAllDropDownOptions() {
    this.generalService.getDropdownOptions().subscribe((res: any) => {

      const data = res.payload;
      this.WeightUnitOptions = data['donation-weighted-unit'];
      this.donationWeightOptions = data['donation-weighted'];
      this.foodCategoryOptions = data['food-category'];
      this.foodTemperatureOptions = data['food-temperature'];
      this.shipmentOptions = data['shipment-option'];
    });
  }

  deleteDocument(id) {
    this.generalService.deleteDocumentById(id).subscribe(res => {
      this.notificationService.showSuccess('Document removed.');
    });
  }

  setDefaultSource() {
    const name = 'Feed Ontario'
    // this.donationForm.get('source').setValue(name);
    this.search = 'Feed Ontario';
    this.generalService.getFoodBanksByName({ name: name }).subscribe(data => {


      this.onSourceSelect({ item: data.payload[0] });
    });
  }

  numbersAndLettersOnly(event, field, limit) {
    if (this.donationForm.get(field).value && this.donationForm.get(field).value.length >= limit) {
      // debugger;
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
    if (this.utilityService.onlyNumberKey(event) || this.utilityService.lettersOnly(event)) {
      return true;
    } else {
      this.notificationService.showError('Only numbers and letters are allowed.');
      return false;
    }
  }

  isCharLengthValid(value, limit) {
    if (value && value.toString().length >= limit) {
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }

  }

}
