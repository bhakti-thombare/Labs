import { Component, OnInit } from '@angular/core';
import { GeneralService } from '../shared/services/general.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-donation-details',
  templateUrl: './donation-details.component.html',
  styleUrls: ['./donation-details.component.scss']
})
export class DonationDetailsComponent implements OnInit {
  isDonationDetailsCollapsed = true;
  donationDetail: any;
  donationId: string;
  showDetailsPage = false;
  constructor(private generalService: GeneralService, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.donationId = this.activatedRoute.snapshot.paramMap.get('id');
    this.getDonationDetails();
  }

  getDonationDetails() {
    this.generalService.getDonationById(this.donationId).subscribe(res => {
      this.donationDetail = res;
      this.showDetailsPage = true;
      
    });
  }

}
