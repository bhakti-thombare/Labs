import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonationEditFormComponent } from './donation-edit-form.component';

describe('DonationEditFormComponent', () => {
  let component: DonationEditFormComponent;
  let fixture: ComponentFixture<DonationEditFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonationEditFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonationEditFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
