import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { FileUploader } from 'ng2-file-upload';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GeneralService } from '../shared/services/general.service';
import * as moment from 'moment';
import { DONATION_STATUS } from '../../home/shared/donation';
import { UtilityService } from 'src/app/core/services/utility.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
@Component({
  selector: 'app-donation-edit-form',
  templateUrl: './donation-edit-form.component.html',
  styleUrls: ['./donation-edit-form.component.scss']
})
export class DonationEditFormComponent implements OnInit {
  uploader: any = new FileUploader({
    disableMultipart: false // 'DisableMultipart' must be 'true' for formatDataFunction to be called.
  });

  donationForm: FormGroup;
  token: string;
  donationId: string;
  submitted = false;
  donationDetails: any;
  shipmentOptions: any;
  foodTemperatureOptions: any;
  donationWeightOptions: any;
  foodCategoryOptions: any;
  donorLocations: any;
  fileList: any[] = [];
  donorDetails: any;
  selectedDonorLocation: any;
  modalRef: BsModalRef;
  anotherLocationForm: FormGroup;
  emailPattern = this.utilityService.emailPattern;
  sourceDetails: any;
  countries = this.utilityService.countries;
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  WeightUnitOptions: any;
  constructor(
    private router: Router,
    private modalService: BsModalService,
    private utilityService: UtilityService,
    private notificationService: NotificationService,
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private generalService: GeneralService
  ) { }

  ngOnInit() {
    this.buildDonationForm();
    this.donationId = this.activatedRoute.snapshot.paramMap.get('id');
    if (this.donationId) {
      this.getAllDropDownOptions();
      this.getDonationDetails();
      this.getDocuments();
    }
  }
  buildDonationForm() {
    this.donationForm = this.formBuilder.group({
      // donationName: ['', Validators.required],
      productDescription: [null, Validators.required],
      bbDate: [null],
      expiryDate: [null],
      quantityPallets: ['', Validators.required],
      weightPerPalletOrBox: ['', Validators.required],
      weightInKgOrLbs: ['kg', Validators.required],
      foodTemperature: [null, Validators.required],
      shipmentOption: [null, Validators.required],
      details: [''],
      attachment: [null],
      // adminComments: [''],
      feedOntarioId: [''],
      // donationCode: [''],
      source: ['', Validators.required],
      offerDate: [null, Validators.required],
      donationWeightIn: [null],
      foodCategory: [null, Validators.required],
      locationOfOrigin: [null, Validators.required],
      comments: [''],
    });

  }

  buildAnotherLocationForm() {
    this.anotherLocationForm = this.formBuilder.group({
      locationName: ['', Validators.required],
      street: ['', Validators.required],
      city: ['', Validators.required],
      province: ['Ontario', Validators.required],
      postalCode: ['', Validators.required],
      country: ['Canada', Validators.required],
      phone: ['', Validators.required],
      // hoursOfOperation: ['', Validators.required],
      // locationContact: ['', Validators.required],
      // contactEmail: ['', [Validators.pattern(this.emailPattern), Validators.required]],
      delete: [false]
    });
  }
  submit(value) {
    if (this.checkValidity(value)) {
      let data = this.donationForm.value;
      data.bbDate = data.bbDate && moment(data.bbDate).format('YYYY-MM-DD') || '';
      data.expiryDate = data.expiryDate && moment(data.expiryDate).format('YYYY-MM-DD') || '';
      data.offerDate = data.offerDate && moment(data.offerDate).format('YYYY-MM-DD') || ' ';
      data.attachment = ''; // this.getAttachmentIds();
      data.locationOfOrigin = +data.locationOfOrigin;
      data = this.dateCorrection(data);

      let message = '';
      if (value === 'save') {
        message = 'saved';
        data.donationStatus = DONATION_STATUS.DONATION_SAVED;
      } else {
        message = 'submitted';
        data.donationStatus = DONATION_STATUS.DONATION_SUBMIT;
      }
      if (this.donationDetails.allocationMethod) {
        data.donationStatus = this.donationDetails.donationStatus;
      }
      data.donationStatusMessage = data.donationStatus;
      this.generalService.updateDonation(data, this.donationId).subscribe(res => {
        this.router.navigateByUrl('/donation/list');
        this.notificationService.showSuccess(`Donation ${message} successfully`);
        (document.getElementById('attachment') as HTMLInputElement).value = '';
        this.getAllDropDownOptions();
      });
    }
  }

  checkValidity(value) {
    if (value === 'save') {
      return true;
    }

    if (this.donationForm.invalid) {
      this.notificationService.showError('Please fill all mandatory fields with valid data.');
      this.turnFormControlsDirty(this.donationForm);
      return false;
    }
    return true;
  }


  turnFormControlsDirty(form: any) {
    this.utilityService.turnFormControlsDirty(form);
  }


  dateCorrection(data) {
    if (data.bbDate === 'Invalid date' || data.bbDate === '') {
      data.bbDate = null;
    }
    if (data.bbDate === 'Invalid date' || data.bbDate === '') {
      data.bbDate = null;
    }
    if (data.expiryDate === 'Invalid date' || data.expiryDate === '') {
      data.expiryDate = null;
    }
    if (data.offerDate === 'Invalid date' || data.offerDate === '') {
      data.offerDate = null;
    }
    return data;
  }

  uploadFile(file) {
    if (true) {
      const formData = new FormData();
      formData.append('file', file);

      this.generalService.uploadFile(formData, this.donationId).subscribe(res => {

        file.id = res.payload.id;
        this.fileList.push(file);
      });
    }
  }


  getAttachmentIds() {
    const attachments = [];
    for (const file of this.fileList) {
      attachments.push(file.id);
    }
    return attachments;
  }

  getDonationForm() {
    return this.generalService.getDonationById(this.donationId);
  }
  getFoodTemperatureOptions() {
    return this.generalService.getFoodTempatureOptions();
  }

  getShipmentOptions() {
    return this.generalService.getShipmentOptions();
  }
  getDonationWeightOptions() {
    return this.generalService.getDonationWeightOptions();
  }
  getFoodCategoryOptions() {
    return this.generalService.getFoodCategoryOptions();
  }

  uploadHandler(event) {

    const file = event[0];
    if (this.fileList.length <= 3) {
      if (file) {
        if (this.checkFileValidity(file)) {
          this.uploadFile(file);
        }
      }
    }
  }

  showNotification(event: any) {
    event.stopPropagation();
    event.preventDefault();
    this.notificationService.showError('Only three files can be selected');
  }

  checkFileValidity(file) {

    if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
      file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
      file.type === 'application/msword' ||
      file.type === 'application/pdf' ||
      file.type.split('/')[0] === 'image'
    ) {
      if (file.name.includes(' ')) {
        this.notificationService.showError('File name should not contain space.');
        return false;
      }
      return true;
    }
    this.notificationService.showError('File type should be image / pdf / doc / docx/ xsls');
    return false;
  }

  removeFile(index) {
    if (this.fileList.length) {
      this.deleteDocument(this.fileList[index].id);
      this.fileList.splice(index, 1);
    }
  }
  getDonationDetails() {
    this.generalService.getDonationById(this.donationId).subscribe((res: any) => {
      this.donationDetails = res;
      if (this.donationDetails) {
        this.donorDetails = this.donationDetails.donorId;
        this.donorLocations = this.donorDetails.locations;



        const selectedLocation: any =
          this.donorDetails.locations.filter(item =>
            this.donationDetails.locationOfOrigin && item.location_id === this.donationDetails.locationOfOrigin.location_id)[0];

        this.selectedDonorLocation = selectedLocation && selectedLocation.location_id || undefined;

        this.donorDetails.primaryEmail = this.donorDetails.contactInformation.filter(item => item.primary)[0].email;
        this.sourceDetails = this.donationDetails.source;

        this.patchDonationForm();
      }
    });
  }

  getAllDropDownOptions() {

    this.generalService.getDropdownOptions().subscribe((res: any) => {

      const data = res.payload;
      this.WeightUnitOptions = data['donation-weighted-unit'];
      this.donationWeightOptions = data['donation-weighted'];
      this.foodCategoryOptions = data['food-category'];
      this.foodTemperatureOptions = data['food-temperature'];
      this.shipmentOptions = data['shipment-option'];
    });
  }

  patchDonationForm() {
    this.donationForm.patchValue({
      // donationName: this.donationDetails.donationName,
      productDescription: this.donationDetails.productDescription,
      bbDate: this.donationDetails.bbDate,
      expiryDate: this.donationDetails.expiryDate,
      quantityPallets: this.donationDetails.quantityPallets,
      weightPerPalletOrBox: this.donationDetails.weightPerPalletOrBox,
      weightInKgOrLbs: this.donationDetails.weightInKgOrLbs,
      foodTemperature: this.donationDetails.foodTemperature,
      shipmentOption: this.donationDetails.shipmentOption,
      details: this.donationDetails.details,
      attachment: this.donationDetails.attachment,
      // adminComments: this.donationDetails.adminComments,
      feedOntarioId: this.donationDetails.feedOntarioId,
      // donationCode: this.donationDetails.donationCode,
      source: this.donationDetails.source,
      offerDate: new Date(this.donationDetails.offerDate),
      donationWeightIn: this.donationDetails.donationWeightIn,
      foodCategory: this.donationDetails.foodCategory,
      locationOfOrigin: this.donationDetails.locationOfOrigin && this.donationDetails.locationOfOrigin.location_id || undefined,
      comments: this.donationDetails.comments,
    });
  }

  onlyNumberKey(event) {
    return this.utilityService.onlyNumberKey(event);
  }


  openModal(template: TemplateRef<any>) {
    this.buildAnotherLocationForm();
    this.modalRef = this.modalService.show(template, { ignoreBackdropClick: true });
  }
  closeModal() {
    if (this.modalRef) {
      this.modalRef.hide();
    }
  }

  submitLocation() {
    if (this.anotherLocationForm.valid) {
      const element = this.anotherLocationForm.value;
      const data = {
        locationName: element.locationName,
        street: element.street,
        city: element.city,
        province: element.province,
        postalCode: element.postalCode,
        country: element.country,
        phoneNumber: element.phone,
        // hoursOfOperation: element.hoursOfOperation,
        // locationContact: parseInt(element.locationContact, 10),
        // contactEmail: element.contactEmail,
        isDelete: false
      };


      this.generalService.addDonorLocation(data, this.donorDetails.donorId).subscribe(res => {
        this.notificationService.showSuccess('Donor location updated');
        this.getAllDropDownOptions();
        this.getDonationDetails();
        this.closeModal();
      });
    } else {
      this.notificationService.showError('Please fill all fields with valid data.');
    }
  }

  getDocuments() {
    this.generalService.getDonationDocuments(this.donationId).subscribe(res => {

      for (const file of res) {
        const elements = file.fileName.split('/');
        let fileName = elements[elements.length - 1]
        if (elements[elements.length - 1].includes('_')) {
          fileName = elements[elements.length - 1].split('_');
          fileName.pop();
          fileName = fileName.join('_');
        }
        // .join('_');
        this.fileList.push({
          url: file.presignedUrl,
          name: fileName,
          id: file.id
        });
      }
    });
  }

  allowOnlyFloat(value, event, limit) {
    if (value && value.length >= limit) {
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
    return this.utilityService.allowOnlyFloat(value, event);
  }

  isCharLengthValid(value, limit) {
    if (value && value.toString().length >= limit) {
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }

  }


  numbersAndLettersOnly(event, field, limit) {
    if (this.donationForm.get(field).value && this.donationForm.get(field).value.length >= limit) {
      // debugger;
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
    if (this.utilityService.onlyNumberKey(event) || this.utilityService.lettersOnly(event)) {
      return true;
    } else {
      return false;
    }
  }

  deleteDocument(id) {
    this.generalService.deleteDocumentById(id).subscribe(res => {
      this.notificationService.showSuccess('Document removed.');
    });
  }

  deleteDonationById() {
    this.generalService.deleteDonation(this.donationId).subscribe(res => {
      this.router.navigateByUrl('/donation/list');
      this.notificationService.showSuccess('Donation deleted successfully.');
    });
  }


  deleteDonation() {
    this.genericConfirm.show({
      headlineText: 'Delete donation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: `Are you sure that you want to perform this action?`,
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {
          this.deleteDonationById();
        }
      },
    });
  }
  shipmentOptionSelected(event, key) {
    this.donationForm.get('shipmentOption').setValue(key);
  }


  isCharLengthValidForLocation(value, limit, event?) {
    if (value && value.toString().length >= limit) {
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
    if (event) {
      if (this.utilityService.onlyNumberKey(event) || this.utilityService.lettersOnly(event)) {
        return true;
      } else {
        return false;
      }
    }
  }
}
