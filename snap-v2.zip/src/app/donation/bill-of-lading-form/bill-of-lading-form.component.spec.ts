import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillOfLadingFormComponent } from './bill-of-lading-form.component';

describe('BillOfLadingFormComponent', () => {
  let component: BillOfLadingFormComponent;
  let fixture: ComponentFixture<BillOfLadingFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillOfLadingFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillOfLadingFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
