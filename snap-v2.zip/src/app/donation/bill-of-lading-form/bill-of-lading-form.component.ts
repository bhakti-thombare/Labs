import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { GeneralService } from '../shared/services/general.service';
import * as moment from 'moment';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
@Component({
  selector: 'app-bill-of-lading-form',
  templateUrl: './bill-of-lading-form.component.html',
  styleUrls: ['./bill-of-lading-form.component.scss']
})
export class BillOfLadingFormComponent implements OnInit, OnChanges {
  @Input() selectedStreetAddress: any =[];

  @Input() donationDetail: any;
  @Input() offerDetail: any;
  @Output() closeEvent: EventEmitter<any> = new EventEmitter<any>();
  donorDetails: any;
  selectedDeliveryDate = new Date();
  carrierList: any;
  foodBankDetails: any;
  phoneNumber: any;
  locationId: any;
  allocatedQuantityWeight: number;
  receivingHours: any;
  constructor(
    private utilityService: UtilityService,
    private notificationService: NotificationService,
    private generalService: GeneralService
  ) { }

  ngOnInit() {
   
    console.log(this.selectedStreetAddress);
     
  }


  onLocationSelected(location) {
    this.locationId = location.location_id;
    this.phoneNumber = location.phoneNumber;
    this.receivingHours = location.hoursOfOperation;
  }

  getFoodBankById() {
    this.generalService.getFoodBankById(this.offerDetail.orgId).subscribe(res => {
      this.foodBankDetails = res.payload;
    });
  }

  ngOnChanges() {
    this.allocatedQuantityWeight = +this.donationDetail.weightPerPalletOrBox * +this.offerDetail.allocation;
    this.donorDetails = {
      name: this.donationDetail.donorId.name,
      address: this.getDonorSelectedAddress(),     
    };
  }
  
  // modifyLocation() {
  //   for (const element of this.offerDetail.locations) {
  //     element.streetAddress = element.street + ', ' + element.city + ', ' + element.province + ', ' + element.country;
  //   }
  // }

  getDonorSelectedAddress() {
    let address;

    for (const element of this.donationDetail.donorId.locations) {
      if (this.donationDetail.locationOfOrigin) {
        if (element.location_id === this.donationDetail.locationOfOrigin.location_id) {          
          address = element;
          break;
        }
      }
    }
    return address && address.street + ',' + address.city + ',' + address.province + ',' + address.country || '';
  }

  // submit() {
  //   if (this.checkValidity()) {
  //     const data = {
  //       billDate: moment(this.selectedDeliveryDate).format('yyyy-MM-DD'),
  //       // carrierId: this.selectedCarrier,
  //       //streetAddress: this.selectedStreetAddress,
  //       //orgId: this.offerDetail.orgId,
  //      // // contact: this.phoneNumber
  //       //locationId: this.locationId
  //       orgInfoList: this.getOrgInfoList()
  //     };    
  //     // console.log(this.selectedCarrier);
      
  //     this.generalService.createBillOfLading(data, this.donationDetail.id).subscribe(res => {
  //       this.notificationService.showSuccess('Bill of lading created.');
  //       // window.open(res.payload, '_blank');
  //       this.closeModal(true);
  //     });
  //   }
  // }
  

  // checkValidity() {
  //   if (!this.selectedCarrier || !this.selectedDeliveryDate || !this.selectedStreetAddress) {
  //     this.notificationService.showError('Please make sure fill in all editable fields');
  //     return false;
  //   }
  //   return true;
  // }

  // closeModal(value = false) {
  //   this.closeEvent.emit(value);

  // }

  // getOrgInfoList(){
  // const newArr =[]
  // for(let location of this.selectedStreetAddress){
  // newArr.push({
  //   locationId:location.location_id,
  //   orgId:location.orgId
  // })
  // }
  // return newArr;
  // }
}
