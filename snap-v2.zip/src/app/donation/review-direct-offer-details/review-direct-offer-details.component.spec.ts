import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewDirectOfferDetailsComponent } from './review-direct-offer-details.component';

describe('ReviewDirectOfferDetailsComponent', () => {
  let component: ReviewDirectOfferDetailsComponent;
  let fixture: ComponentFixture<ReviewDirectOfferDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewDirectOfferDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewDirectOfferDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
