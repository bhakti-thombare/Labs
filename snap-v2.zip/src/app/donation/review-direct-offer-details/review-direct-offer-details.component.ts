import { Component, OnChanges, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GeneralService } from '../shared/services/general.service';
import * as moment from 'moment';
import { NotificationService } from 'src/app/core/services/notification.service';
import * as _ from 'lodash';
import { UtilityService } from 'src/app/core/services/utility.service';
@Component({
  selector: 'app-review-direct-offer-details',
  templateUrl: './review-direct-offer-details.component.html',
  styleUrls: ['./review-direct-offer-details.component.scss']
})
export class ReviewDirectOfferDetailsComponent implements OnInit, OnChanges, OnDestroy {
  donationDetail: any;
  selectedFoodBanks: any;
  donationId: any;
  offeredFoodBankList = [];
  allocatedFoodBankList = [];
  totalAllocatedQuantity = 0;
  totalOfferedQuantity = 0;
  minDate = new Date();
  time = [
    { label: '8:00AM', value: 800 },
    { label: '8:30AM', value: 830 },
    { label: '9:00AM', value: 900 },
    { label: '9:30AM', value: 930 },
    { label: '10:00AM', value: 1000 },
    { label: '10:30AM', value: 1030 },
    { label: '11:00AM', value: 1100 },
    { label: '11:30AM', value: 1130 },
    { label: '12:00PM', value: 1200 },
    { label: '12:30PM', value: 1230 },
    { label: '1:00PM', value: 1300 },
    { label: '1:30PM', value: 1330 },
    { label: '2:00PM', value: 1400 },
    { label: '2:30PM', value: 1430 },
    { label: '3:00PM', value: 1500 },
    { label: '3:30PM', value: 1530 },
    { label: '4:00PM', value: 1600 },
    { label: '4:30PM', value: 1630 },
    { label: '5:00PM', value: 1700 },
    { label: '5:30PM', value: 1730 },
    { label: '6:00PM', value: 1800 },
    { label: '6:30PM', value: 1830 },
  ];
  selectedDeadline = new Date();
  selectedTime = 800;
  invalidTime = false;
  constructor(
    private utilityService: UtilityService,
    private notificationService: NotificationService,
    private router: Router,
    private generalService: GeneralService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.donationId = this.activatedRoute.snapshot.paramMap.get('id');
    this.getDonationDetails();
    this.getReviewDetails();
  }

  ngOnChanges() {

  }

  getReviewDetails() {
    const queryParams = {
      // pageNo: 0,
      // pageSize: 1000,
      filter: 'OFFERED,ACCEPTED,ALLOCATED,NOT_OFFERED,DECLINED',
      offerId: localStorage.getItem('modified_offers') ? JSON.parse(localStorage.getItem('modified_offers')).join(',') : '',
      orgId: localStorage.getItem('modified_orgs') ? JSON.parse(localStorage.getItem('modified_orgs')).join(',') : ''

    };

    this.generalService.getDirectOfferReviewDetails(this.donationId, queryParams).subscribe(res => {

      this.selectedFoodBanks = res.payload.directOfferList && _.uniqBy(res.payload.directOfferList.reverse(), 'orgId');
      this.sortFoodBanks();
    });
  }

  getDonationDetails() {
    this.generalService.getDonationById(this.donationId).subscribe(res => {

      this.donationDetail = res;
      this.donationDetail.offerDate = this.utilityService.convertToLocalTimeZone(new Date(this.donationDetail.offerDate), 'DD MMM, yyyy');

      this.selectedDeadline = this.donationDetail.deadlineDate ?
        new Date(new Date(this.donationDetail.deadlineDate + ' UTC').toLocaleString()) : new Date(new Date().setHours(8, 0, 0));


      this.selectedTime = this.formatTimeInString(this.selectedDeadline);
    });
  }

  sortFoodBanks() {

    for (const element of this.selectedFoodBanks) {
      if (element.allocatedQuantity > 0) {
        this.allocatedFoodBankList.push(element);
        this.totalAllocatedQuantity = this.totalAllocatedQuantity + element.allocatedQuantity;
      }

      if (element.offeredQuantity > 0 && !element.allocatedQuantity && element.status === 'NOT_OFFERED') {
        this.offeredFoodBankList.push(element);
        this.totalOfferedQuantity = this.totalOfferedQuantity + element.offeredQuantity;
      }
    }
  }

  submit() {
    if (!this.selectedDeadline || (this.selectedDeadline && this.selectedDeadline.toString().toLowerCase() === 'invalid date')) {
      this.notificationService.showError('Please select a deadline');
      return;
    }
    if (this.timeSelected({ value: this.selectedTime })) {
      return;
    }

    const { hour, min } = this.getTime({ value: this.selectedTime });
    const data = {
      confirm: true,
      allocations: this.getSelectedFoodBanks(),
      comment: this.donationDetail.comments,
      donationId: this.donationId,
      deadlineDateLocal: moment(this.selectedDeadline.setHours(hour, min, 0)).format('MMMM DD, YYYY HH:mm A'),
      offerDeadline: moment(
        this.utilityService.convertToUtc(
          this.selectedDeadline.setHours(hour, min, 0)
        )
      ).format('YYYY-MM-DD HH:mm:ss'),
    };

    this.generalService.submitDirectOffer(data).subscribe(res => {
      this.notificationService.showSuccess('Direct offers sent');
      this.router.navigateByUrl('/home/new-donations');
      // this.generalService.updateDonation(this.donationDetail, this.donationId).subscribe(res2 => { });
      // this.router.navigateByUrl('/donation/review-direct-offer/' + this.donationId);
    });
  }
  getSelectedFoodBanks() {
    const tempArr = [];
    for (const element of this.selectedFoodBanks) {
      if (element.requestedQuantity || element.allocatedQuantity || element.offeredQuantity) {
        tempArr.push({
          allocatedQuantity: element.allocatedQuantity || 0,
          foodBankId: element.orgId,
          offeredQuantity: element.offeredQuantity || 0,
          requestedQuantity: element.requestedQuantity || 0,
          status: element.allocatedQuantity ? 'ALLOCATED' : 'OFFERED', // 'ALLOCATED',
          quanityModified: false
        });
      }
    }

    return tempArr;
  }

  formatTimeIn24Hr(time) {
    const meridiem = time[time.length - 2] + time[time.length - 1];
    let num = +time.slice(0, -2);
    if (meridiem === 'PM') {
      num = num === 12 ? 12 : num + 12;
    }
    return num;
  }

  formatTimeInString(time) {
    const newtime = moment(time).format('hh:mm A').replace(/ /g, '');
    const timeToTest = newtime[0] === '0' ? newtime.substring(1, newtime.length) : newtime;
    const timeSelected = this.time.filter(item => item.label === timeToTest)[0];
    return timeSelected.value;
  }

  timeSelected(event) {
    const { hour, min } = this.getTime(event);

    const date = new Date(JSON.parse(JSON.stringify(this.selectedDeadline)));
    if (!moment(new Date()).isBefore(date.setHours(hour, min, 0))) {
      this.notificationService.showError('Please select time greater than current time');
      return true;
      // return false;
    } else {
      return false;
    }

    // return true;

  }


  getTime(event) {
    const hour = event.value.toString().length === 4 ? event.value.toString().substring(0, 2) : event.value.toString().substring(0, 1);
    const min = event.value.toString().slice(-2);
    return { hour, min };
  }

  ngOnDestroy() {
    if (localStorage.getItem('modified_offers')) {
      localStorage.removeItem('modified_offers');
    }

    if (localStorage.getItem('modified_orgs')) {
      localStorage.removeItem('modified_orgs');
    }
  }

}
