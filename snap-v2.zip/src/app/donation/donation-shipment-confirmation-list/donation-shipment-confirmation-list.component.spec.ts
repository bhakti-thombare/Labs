import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonationShipmentConfirmationListComponent } from './donation-shipment-confirmation-list.component';

describe('DonationShipmentConfirmationListComponent', () => {
  let component: DonationShipmentConfirmationListComponent;
  let fixture: ComponentFixture<DonationShipmentConfirmationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonationShipmentConfirmationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonationShipmentConfirmationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
