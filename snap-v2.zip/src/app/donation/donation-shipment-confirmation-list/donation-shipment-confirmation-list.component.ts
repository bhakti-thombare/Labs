import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GeneralService } from '../shared/services/general.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { UtilityService } from 'src/app/core/services/utility.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import * as moment from 'moment';
import { ValueConverter } from '@angular/compiler/src/render3/view/template';

@Component({
  selector: 'app-donation-shipment-confirmation-list',
  templateUrl: './donation-shipment-confirmation-list.component.html',
  styleUrls: ['./donation-shipment-confirmation-list.component.scss']
})
export class DonationShipmentConfirmationListComponent implements OnInit {
  // messageSuccess = true;
  // buttonDisabled:boolean = true;
  buttonDisabled1:boolean = true;
  loader =false;
  phoneNumber: any;
  locationId: any;
  receivingHours: any;
  selectedStreetAddress:any =[];
    selectedCarrier: any;
  allocationList = [];
  receiptList = [];
  modalRef: BsModalRef;
  donationId: string;
  donationDetail: any;
  offerDetail: any;
  toolTipContent: any;
  averageQuality: any;
  allocationItem=[];
  selectedDeliveryDate = new Date();
  pdfUrl: string;
  carrierList :any=[];
  constructor(
    private bsModelService: BsModalService,
    private utilityService: UtilityService,
    private activatedRoute: ActivatedRoute,
    private generalService: GeneralService,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {
    this.donationId = this.activatedRoute.snapshot.paramMap.get('id');
    this.getDonationDetails();
    this.getDonationShipmentConfirmations();
    // this.selectCarrier(this.selectedCarrier.id);
    this.getCarrier();
  }
 

  getDonationShipmentConfirmations() {
    const queries = {
      donationId: this.donationId,
      status: 'ALLOCATED'
    };
    this.generalService.getDonationShipmentConfirmations(queries).subscribe(res => {
      if (typeof res.payload !== 'string') {
        this.averageQuality = res.payload.averageQuality;
        console.log(res);

        this.sortResponse(res.payload.shipmentDetails, 'ALLOCATED');
        
      }
    });
    queries.status = 'CONFIRMED';
    this.generalService.getDonationShipmentConfirmations(queries).subscribe(res => {
      if (typeof res.payload !== 'string') {
        this.averageQuality = res.payload.averageQuality;
        this.sortResponse(res.payload.shipmentDetails, 'CONFIRMED');
      }
    });

  }


  getDonationDetails() {
    this.generalService.getDonationById(this.donationId).subscribe(res => {
      
      this.donationDetail = res;
      this.donationDetail.offerDate = this.utilityService.convertToLocalTimeZone(this.donationDetail.offerDate, 'DD MMM, yyyy');
    });
    
  }

  sortResponse(list, status) {
    
    
    if (list instanceof Array) {
      for (const listItem of list) {

        if (status === 'CONFIRMED') {
          this.receiptList.push(listItem);
          if (listItem.childOrganisationList && listItem.childOrganisationList.length) {
            for (const element of listItem.childOrganisationList) {
              if (element.allocatedQuantity) {
                this.receiptList.push({
                  feedOntarioId: listItem.feedOntarioId,
                  foodBank: element.childFoodBankName,
                  orgId: element.id,
                  shared: element.allocatedQuantity,
                  offerDate: listItem.offerDate,
                  quality: listItem.quality,
                  deliveryDate: listItem.deliveryDate,
                });
              }
            }
          }
          if (listItem.sharedOrganization && listItem.sharedOrganization.length) {
            for (const element of listItem.sharedOrganization) {
              this.receiptList.push({
                feedOntarioId: listItem.feedOntarioId,
                foodBank: element.foodBank.name,
                orgId: element.foodBank.id,
                shared: element.quantity,
                offerDate: listItem.offerDate,
                quality: listItem.quality,
                deliveryDate: listItem.deliveryDate,
              });
            }
          }
          if (listItem.name && listItem.name.length) {
           for (const element of listItem.carrierList) {
      
            element.name = this.carrierList.push(listItem); 
               
              }  
           }
        } 
        else {
          listItem.deadLine =
            listItem.deadLine && this.utilityService.convertToLocalTimeZone(listItem.deadLine + ' UTC', 'MMM DD, hh:mm a') || 'NA';
            if (listItem.locations && listItem.locations.length) {
              for (const element of listItem.locations) {
                element.streetAddress = element.street + ', ' + element.city + ', ' + element.province + ', ' + element.country;  
              }
            }
            this.allocationList.push(listItem);
               
          if (listItem.childOrganisationList && listItem.childOrganisationList.length) {
            for (const element of listItem.childOrganisationList) {
              if (element.allocatedQuantity) {
                this.allocationList.push({
                  foodBank: element.childFoodBankName,
                  orgId: element.id,
                  shared: element.allocatedQuantity,
                  deadLine: listItem.deadLine || 'NA',
                });
              }
            }
          }
          if (listItem.sharedOrganization && listItem.sharedOrganization.length) {
            for (const element of listItem.sharedOrganization) {
              for (const sharedElement of element.foodBank.orgProfile.locations) {
                sharedElement.streetAddress = sharedElement.street + ', ' + sharedElement.city + ', ' + sharedElement.province + ', ' + sharedElement.country;  
              }
              this.allocationList.push({
                foodBank: element.foodBank.name,
                orgId: element.foodBank.id,
                shared: element.quantity,
                deadLine: listItem.deadLine || 'NA',
                locations: element.foodBank.orgProfile.locations || []
              });
            }
          }

        }
        
      }
    }
    console.log('allocationlist', this.allocationList);
    
  }
  submit() {
    if (this.checkValidity()) {
      console.log(this.selectedCarrier);
      
      const data = {
        billDate: moment(this.selectedDeliveryDate).format('yyyy-MM-DD'),
        carrierId:this.selectedCarrier,
        //streetAddress: this.selectedStreetAddress,
        //orgId: this.offerDetail.orgId,
       // // contact: this.phoneNumber
        //locationId: this.locationId
        orgInfoList: this.getOrgInfoList()
      };    
      
      this.generalService.createBillOfLading(data, this.donationDetail.id).subscribe(res => {
        this.notificationService.showSuccess('Bill of lading created.');
        // window.open(res.payload, '_blank');
        // this.closeModal(true);
      });
      this.generatePdf();
    }
  }

  checkValidity() {
    if (!this.selectedCarrier || !this.selectedDeliveryDate || !this.selectedStreetAddress) {
      this.notificationService.showError('Please make sure fill in all editable fields');
      return false;
    }
    return true;
  }

  getOrgInfoList(){
    const newArr =[]
    for(let location of this.selectedStreetAddress){
    newArr.push({
      locationId:location.location_id,
      orgId:location.orgId
    })
    }
    return newArr;
    }


  // openModal(template, allocationItem) 
  // {
  //   this.offerDetail = allocationItem;
  //   this.modalRef = this.bsModelService.show(template, { ignoreBackdropClick: true, class: 'modal-lg' });
  // }

  onLocationSelected(location) { 
    this.locationId = location.location_id;
    this.phoneNumber = location.phoneNumber;
    this.receivingHours = location.hoursOfOperation;

    const data = {
      billDate: moment(this.selectedDeliveryDate).format('yyyy-MM-DD'),
      // carrierId: this.selectedCarrier,
      // streetAddress: this.selectedStreetAddress,
      orgId: this.offerDetail.orgId,
      // contact: this.phoneNumber
      locationId: this.locationId
    };
    
    this.generalService.createBillOfLading(data, this.donationDetail.id).subscribe(res => {
      this.notificationService.showSuccess('Bill of lading created.');
      // window.open(res.payload, '_blank');
      // this.closeModal(true);
    });
  }


//   closeModal(value) {
//     if (this.modalRef) {
//       this.modalRef.hide();
//       if(value === true){
// this.generatePdf();
//       }
//     } 
//   } 

generatePdf(){
  // this.loader = true;
  this.generalService.getPdf(this.donationDetail.id).subscribe(res=> {
 
    if(res.payload.status === 'COMPLETED')
    {
      this.loader = false;
      // this.downloadPdf();
      this.buttonDisabled1 = false;
    }
    else if(res.payload.status==='IN_PROGRESS')
    {
      this.loader = true;
      // setTimeout(()=>{
      //   this.generatePdf();
      // },500)
    }
    else if(res.payload.status ==='FAILED')
    {
      this.notificationService.showError('Something went wrong, PDF cannot be generated. Please try again.');
    }
  });
}

  downloadPdf() {
    this.generalService.downloadPdf(this.donationDetail.id).subscribe(res => {
      window.open(res.payload,'_blank')
    });
  }
  
  selectAddress(value, orgId){
    console.log(value);
    value.orgId = orgId;
    this.selectedStreetAddress.push(value);
  }


  selectCarrier(value) {
    console.log(value);
    if(value != undefined){
    this.selectedCarrier= value.id
    }
  }

  
  getCarrier(){
    this.generalService.getCarrierList().subscribe(res => {
      this.carrierList = res.payload;
    });
  }
}
