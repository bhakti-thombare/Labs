import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewFoodOfferDetailsComponent } from './review-food-offer-details.component';

describe('ReviewFoodOfferDetailsComponent', () => {
  let component: ReviewFoodOfferDetailsComponent;
  let fixture: ComponentFixture<ReviewFoodOfferDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewFoodOfferDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewFoodOfferDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
