import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-review-food-offer-details',
  templateUrl: './review-food-offer-details.component.html',
  styleUrls: ['./review-food-offer-details.component.scss']
})
export class ReviewFoodOfferDetailsComponent implements OnInit, OnDestroy {
  donationId: any;
  donationDetail: any;
  selectedFoodBanks = [];
  allocatedFoodBankList = [];
  totalAllocatedQuantity = 0;
  totalRequestedQuantity = 0;
  res = {
    payload: [
      {
        foodBankName: 'foodbank',
        orgId: 1,
        hungerCount: 109,
        hcPercent: 10,
        foodOfferPercent: 2,
        deltaFactorPercent: 23,
        requestedQuantity: 1,
        allocatedQuantity: 0,
        status: 'Not offered'
      },
      {
        foodBankName: 'foodbank',
        orgId: 1,
        hungerCount: 109,
        hcPercent: 10,
        foodOfferPercent: 2,
        deltaFactorPercent: 23,
        requestedQuantity: 1,
        allocatedQuantity: 1,
        status: 'Not offered'
      },
      {
        foodBankName: 'foodbank',
        orgId: 1,
        hungerCount: 109,
        hcPercent: 10,
        foodOfferPercent: 2,
        deltaFactorPercent: 23,
        requestedQuantity: 2,
        allocatedQuantity: 0,
        status: 'Not offered'
      },
      {
        foodBankName: 'foodbank',
        orgId: 1,
        hungerCount: 109,
        hcPercent: 10,
        foodOfferPercent: 2,
        deltaFactorPercent: 23,
        requestedQuantity: 2,
        allocatedQuantity: 2,
        status: 'Not offered'
      },
      {
        foodBankName: 'foodbank',
        orgId: 1,
        hungerCount: 109,
        hcPercent: 10,
        foodOfferPercent: 2,
        deltaFactorPercent: 23,
        requestedQuantity: 0,
        allocatedQuantity: 0,
        status: 'Not offered'
      },
      {
        foodBankName: 'foodbank',
        orgId: 1,
        hungerCount: 109,
        hcPercent: 10,
        foodOfferPercent: 2,
        deltaFactorPercent: 23,
        requestedQuantity: 0,
        allocatedQuantity: 0,
        status: 'Not offered'
      },
      {
        foodBankName: 'foodbank',
        orgId: 1,
        hungerCount: 109,
        hcPercent: 10,
        foodOfferPercent: 2,
        deltaFactorPercent: 23,
        requestedQuantity: 0,
        allocatedQuantity: 0,
        status: 'Not offered'
      }
    ]
  };
  constructor(
    private router: Router,
    private notificationService: NotificationService,
    private activatedRoute: ActivatedRoute,
    private generalService: GeneralService,
  ) { }

  ngOnInit() {
    this.donationId = this.activatedRoute.snapshot.paramMap.get('id');
    // this.getDonationDetails();
    this.getReviewDetails();
  }


  getDonationDetails() {
    this.generalService.getDonationById(this.donationId).subscribe(res => {
      
      this.donationDetail = res;
    });
  }

  getReviewDetails() {
    const queryParams: any = {
      ids: localStorage.getItem('modified_offers') ? JSON.parse(localStorage.getItem('modified_offers')).join(',') : ''
    }
    this.generalService.getFoodOfferReviewDetails(this.donationId, queryParams).subscribe(res => {
      this.selectedFoodBanks = res.payload.foodBankOfferDetails;
      this.donationDetail = res.payload;
      this.sortFoodBanks();
      
    });
  }

  sortFoodBanks() {
    for (const element of this.selectedFoodBanks) {
      this.totalRequestedQuantity = this.totalRequestedQuantity + element.requestedQuantity;
      if (element.allocatedQuantity > 0) {
        this.allocatedFoodBankList.push(element);
        this.totalAllocatedQuantity = this.totalAllocatedQuantity + element.allocatedQuantity;
      }
    }
  }

  submit() {
    const data = {
      allocations: this.getSelectedFoodBanks(),
      comment: this.donationDetail.comments,
      donationId: this.donationId,
    };
    
    this.generalService.submitFoodOffer(data).subscribe(res => {
      this.notificationService.showSuccess('Food offer allocations sent');
      this.router.navigateByUrl('/home/new-donations');
    });
  }
  getSelectedFoodBanks() {
    const tempArr = [];
    for (const element of this.selectedFoodBanks) {
      if (element.allocatedQuantity || element.allocatedQuantity === 0) {
        tempArr.push({
          allocatedQuantity: element.allocatedQuantity || element.allocatedQuantity === 0 ? element.allocatedQuantity : 0,
          foodBankId: element.orgId,
          requestedQuantity: element.requestedQuantity || element.requestedQuantity === 0 ? element.requestedQuantity : 0,
          status: 'ALLOCATED',
          quantityModified: false
        });
      }
    }
    
    return tempArr;
  }

  ngOnDestroy() {
    if (localStorage.getItem('modified_offers')) {
      localStorage.removeItem('modified_offers');
    }
  }

}
