import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewDonationDetailsComponent } from './view-donation-details.component';

describe('ViewDonationDetailsComponent', () => {
  let component: ViewDonationDetailsComponent;
  let fixture: ComponentFixture<ViewDonationDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewDonationDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewDonationDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
