import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { GeneralService } from '../shared/services/general.service';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { UtilityService } from 'src/app/core/services/utility.service';
@Component({
  selector: 'app-view-donation-details',
  templateUrl: './view-donation-details.component.html',
  styleUrls: ['./view-donation-details.component.scss']
})
export class ViewDonationDetailsComponent implements OnInit, OnChanges {
  id: string;
  @Input() donationDetails: any;
  offerDate: string;
  donationDetail: any;
  fileList = [];
  constructor(
    private activatedRoute: ActivatedRoute,
    private generalService: GeneralService,
    private utilityService: UtilityService
  ) { }

  ngOnInit() {
    this.id = this.activatedRoute.snapshot.paramMap.get('id');

    this.getDonationDocuments();
  }

  getDonationDetails() {
    this.generalService.getDonationById(this.id).subscribe(res => {
      
    });
  }

  ngOnChanges() {
    this.donationDetail = JSON.parse(JSON.stringify(this.donationDetails));
    this.offerDate = this.donationDetail &&
      this.donationDetail.offerDate && moment(this.donationDetail.offerDate).format('dddd, Do MMM, YYYY') || undefined;
    this.donationDetail.deadlineDate = this.donationDetail &&
      this.donationDetail.deadlineDate && this.utilityService.convertToLocalTimeZone(new Date(this.donationDetail.deadlineDate + ' UTC'), 'DD MMM YYYY, hh:mm a') || undefined;
  }


  getDonationDocuments() {
    this.generalService.getDonationDocuments(this.id).subscribe(res => {
      const tempFiles = [];
      for (const file of res) {
        const elements = file.fileName.split('/');
        let fileName = elements[elements.length - 1].split('_');
        fileName.pop();
        fileName = fileName.join('_');
        file.fileName = fileName;

      }
      this.fileList = res;
    });
  }
}
