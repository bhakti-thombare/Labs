import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DonationRoutingModule } from './donation-routing.module';
import { DonationDashboardComponent } from './donation-dashboard/donation-dashboard.component';
import { SharedModule } from '../shared/shared.module';
import { DonationFormComponent } from './donation-form/donation-form.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgSelectModule } from '@ng-select/ng-select';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ViewDonationDetailsComponent } from './view-donation-details/view-donation-details.component';
import { AllocateDonationFormComponent } from './allocate-donation-form/allocate-donation-form.component';
import { DonationDetailsComponent } from './donation-details/donation-details.component';
import { DonationEditFormComponent } from './donation-edit-form/donation-edit-form.component';
import { FileUploadModule } from 'ng2-file-upload';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { PopoverModule } from 'ngx-bootstrap/popover';

import { DonationCreateFormComponent } from './donation-create-form/donation-create-form.component';
import {
  AllocationMethodDirectOfferFormComponent
} from './allocation-method-direct-offer-form/allocation-method-direct-offer-form.component';
import { ReviewDirectOfferDetailsComponent } from './review-direct-offer-details/review-direct-offer-details.component';
import { DonationListComponent } from './donation-list/donation-list.component';
import {
  DonationShipmentConfirmationListComponent
} from './donation-shipment-confirmation-list/donation-shipment-confirmation-list.component';
import { ReviewDryHubOfferDetailsComponent } from './review-dry-hub-offer-details/review-dry-hub-offer-details.component';
import {
  AllocationMethodDryHubOfferFormComponent
} from './allocation-method-dry-hub-offer-form/allocation-method-dry-hub-offer-form.component';
import {
  AllocationMethodFoodOfferFormComponent
} from './allocation-method-food-offer-form/allocation-method-food-offer-form.component';
import {
  ReviewFoodOfferDetailsComponent
} from './review-food-offer-details/review-food-offer-details.component';
import { BillOfLadingFormComponent } from './bill-of-lading-form/bill-of-lading-form.component';
import { FoodbankOverviewDetailsComponent } from './foodbank-overview-details/foodbank-overview-details.component';

import { NgxMaskModule, IConfig } from "ngx-mask";

export const options: Partial<IConfig> | (() => Partial<IConfig>) = null;

@NgModule({
  declarations: [
    DonationDashboardComponent,
    DonationFormComponent,
    ViewDonationDetailsComponent,
    AllocateDonationFormComponent,
    DonationDetailsComponent,
    DonationEditFormComponent,
    DonationCreateFormComponent,
    AllocationMethodDirectOfferFormComponent,
    ReviewDirectOfferDetailsComponent,
    DonationListComponent,
    DonationShipmentConfirmationListComponent,
    ReviewDryHubOfferDetailsComponent,
    AllocationMethodDryHubOfferFormComponent,
    AllocationMethodFoodOfferFormComponent,
    ReviewFoodOfferDetailsComponent,
    BillOfLadingFormComponent,
    FoodbankOverviewDetailsComponent],
  imports: [
    ReactiveFormsModule.withConfig({ warnOnNgModelWithFormControl: 'never' }),
    FileUploadModule,
    FormsModule,
    TypeaheadModule.forRoot(),
    ModalModule.forRoot(),
    CollapseModule.forRoot(),
    PopoverModule.forRoot(),
    SharedModule,
    CommonModule,
    BsDatepickerModule.forRoot(),
    NgSelectModule,
    DonationRoutingModule,
    NgxMaskModule.forRoot()
  ]
})
export class DonationModule { }
