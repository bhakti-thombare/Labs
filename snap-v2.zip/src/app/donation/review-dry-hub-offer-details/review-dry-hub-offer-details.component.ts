import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-review-dry-hub-offer-details',
  templateUrl: './review-dry-hub-offer-details.component.html',
  styleUrls: ['./review-dry-hub-offer-details.component.scss']
})
export class ReviewDryHubOfferDetailsComponent implements OnInit {
  donationDetail: any;
  donationId: any;
  constructor(
    private notificationService: NotificationService,
    private router: Router,
    private utilityService: UtilityService,
    private generalService: GeneralService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.donationId = this.activatedRoute.snapshot.paramMap.get('id');
    this.getDonationDetails();
  }

  getDonationDetails() {
    this.generalService.getDonationById(this.donationId).subscribe(res => {
      
      this.donationDetail = res;
      this.donationDetail.offerDate = this.utilityService.convertToLocalTimeZone(new Date(this.donationDetail.offerDate), 'DD MMM,yyyy');
    });
  }
}
