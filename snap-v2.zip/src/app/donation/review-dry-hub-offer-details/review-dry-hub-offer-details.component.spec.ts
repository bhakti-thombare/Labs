import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewDryHubOfferDetailsComponent } from './review-dry-hub-offer-details.component';

describe('ReviewDryHubOfferDetailsComponent', () => {
  let component: ReviewDryHubOfferDetailsComponent;
  let fixture: ComponentFixture<ReviewDryHubOfferDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewDryHubOfferDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewDryHubOfferDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
