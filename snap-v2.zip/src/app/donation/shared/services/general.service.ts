import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { RestService } from 'src/app/core/services/rest.service';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {
  baseUrl = environment.apiUrl;
  constructor(private restService: RestService) { }


  // submit donation form by donor
  createDonation(data, tokenValue) {
    return this.restService.put(`${this.baseUrl}​/api/v1/donor/update-donationForm`, data, { token: tokenValue }, true);
  }

  // get donations list for admin
  getDonations(queries) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/getAllDonation`, queries, true);
  }

  getAllDonations(queries) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/getAllDonationWithOutAnyFilter`, queries, true);

  }

  // get donation by id for admin
  getDonationById(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donor/getDonationById/${id}`, undefined, true);
  }

  // approve or reject donation by admin
  handleDonationRequest(data, id) {
    return this.restService.put(`${this.baseUrl}/api/v1/donation/action/${id}`, data, undefined, true);
  }

  // select donation allocation method
  setDonationAllocationMethod(data) {
    return this.restService.put(`${this.baseUrl}/api/v1/donor/donationAllocation`, data, undefined, true);
  }

  // select zone, deadline, and send offer to foodbanks
  sendDonationOffer(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/donation/setDonationDeadline`, data, undefined, true);
  }

  uploadFile(data, id) {
    return this.restService.upload('POST', `${this.baseUrl}/api/v1/donation/upload-document${!id ? '' : '/' + id}`, data, undefined, true);
  }

  getFoodTempatureOptions() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donor/donation/food-temperature`, undefined, true);
  }

  getShipmentOptions() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donor/donation/shipment-options`, undefined, true);
  }

  getDonationWeightOptions() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donor/donation/donation-weighted`, undefined, true);
  }

  getFoodCategoryOptions() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donor/donation/food-category`, undefined, true);
  }

  updateDonation(data, id) {
    return this.restService.put(`${this.baseUrl}​​/api/v1/donor/edit-donationForm/${id}`, data, undefined, true);
  }

  addDonorLocation(data, id) {
    return this.restService.put(`${this.baseUrl}​​/api/v1/donor/add-anotherLocation/${id}`, data, undefined, true);
  }


  createDonationByAdmin(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/donor/create-donationForm`, data, undefined, true);

  }
  // get all
  getFoodBanksByName(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/foodbank/profile/byName`, data, { hideLoader: true }, true);
  }
  // get all
  getDonorsByName(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/donor/searchDonorByName`, data, { hideLoader: true }, true);
  }

  getDonationDocuments(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/getDocumentById/${id}`, undefined, true);

  }

  deleteDocumentById(id) {
    return this.restService.delete(`${this.baseUrl}/api/v1/donation/delete-document/${id}`, undefined, undefined, true);
  }

  getDropdownOptions(id?) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donor/donation/form-options${!id ? '' : '/' + id}`, undefined, true);

  }

  getFoodBankDropdownOptions() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/form-options`, undefined, true);

  }

  deleteDonation(id) {
    return this.restService.delete(`${this.baseUrl}/api/v1/donor/delete-donationForm/${id}`, undefined, undefined, true);
  }


  // Direct offer
  getFoodBanksForDirectOffer(id, queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/direct-offer/${id}`, queryParams, true);
  }

  getDirectOfferReviewDetails(id, queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/direct-review-offer/${id}`, queryParams, true);
  }

  submitDirectOffer(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/donation/direct-offer`, data, undefined, true);
  }


  // Dry hub offer
  getFoodBanksForDryHubOffer(id, queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/dry-hub-offer/${id}`, queryParams, true);
  }

  submitDryHubOffer(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/donation/dry-hub-offer`, data, undefined, true);
  }
  // Food offer
  getFoodBanksForFoodOffer(id, queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/foodOffer/${id}`, queryParams, true);
  }

  getFoodOfferReviewDetails(id, queryParam?) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/ReviewfoodOffers/${id}`, queryParam, true);
  }

  submitFoodOffer(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/donation/foodOffer`, data, undefined, true);
  }

  // get donation shipment confirmation
  getDonationShipmentConfirmations(queries) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/food-bank/donation/allocations_deliveries`, queries, true);
  }

  completeDonation(id) {
    return this.restService.put(`${this.baseUrl}/api/v1/donor/completeDonation/${id}`, undefined, undefined, true);
  }

  getCarrierList() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/carrier/`, undefined, true);
  }

  getFoodBankById(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/profile/${id}`, undefined, true);
  }

  createBillOfLading(data, id) {
    return this.restService.post(`${this.baseUrl}/api/v1/shipment/create-bill-of-lading/${id}`, data, undefined, true);
  }

  getFoodBankOverViewDetails(id, queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/getFoodBankDetailsByHovering/${id}`, queryParams, true);
  }

  getPdf(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/shipment/bill-of-lading/status/${id}`, {hideLoader:true}, true);
  }

  downloadPdf(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/shipment/bill-of-lading/download/${id}`,{hideLoader:true} , true);

  }
}
