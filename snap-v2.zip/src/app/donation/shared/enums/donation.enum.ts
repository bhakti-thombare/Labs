// donation report tab sorting params

export enum donationListSortParam {
  FEED_ONTARIO_ID = 'feedOntarioId',
  OFFER_DATE = 'offerDate',
  FOOD_CATEGORY = 'foodCategory',
  FOOD_TEMP = 'foodTemperature',
  PRODUCT_DESC = 'productDescription',
  ALLOCATION_METHOD = 'allocationMethod',
  WEIGHT_PER_PALLET_OR_BOX = 'weightPerPalletOrBox',
}


// food offer allocation table

export enum foodOfferAllocationTableSortParam {
  NAME = 'name',
  HUNGER_COUNT = 'hungerCount',
  HUNGER_COUNT_PERCENT = 'hcPercent',
  FOOD_PERCENT = 'foodPercent',
  DELTA = 'delta',
  REQUESTED = 'requested',
  ALLOCATED = 'allocated',
  STATUS = 'status'
}


// direct offer allocation table

export enum directOfferAllocationTableSortParam {
  NAME = 'name',
  LAST_ALLOCATED_ON = 'lastAllocatedOn',
  CAPACITY = 'capacity',
  HUNGER_COUNT = 'hungerCount',
  HUNGER_COUNT_PERCENT = 'hcPercent',
  DIRECT_PERCENT = 'directPercent',
  DELTA = 'delta',
  OFFERED = 'offered',
  REQUESTED = 'requested',
  ALLOCATED = 'allocated',
  STATUS = 'status'
}


// dry hub offer allocation table

export enum dryHubOfferAllocationTableSortParam {
  NAME = 'name',
  DELTA = 'delta',
  HUNGER_COUNT = 'hungerCount',
  HUNGER_COUNT_PERCENT = 'hcPercent',
  DRY_HUB_PERCENT = 'dryHubPercent',
  ALLOCATED = 'allocated'
}