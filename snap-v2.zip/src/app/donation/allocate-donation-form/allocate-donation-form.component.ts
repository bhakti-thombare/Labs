import { Component, OnInit, Input, OnChanges, AfterViewInit, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { GeneralService } from '../shared/services/general.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import * as moment from 'moment';
import { UtilityService } from 'src/app/core/services/utility.service';

@Component({
  selector: 'app-allocate-donation-form',
  templateUrl: './allocate-donation-form.component.html',
  styleUrls: ['./allocate-donation-form.component.scss']
})
export class AllocateDonationFormComponent implements OnInit, OnChanges, AfterViewInit {

  @Input() donationDetail: any;
  @Output() allocationMethodSelected: EventEmitter<any> = new EventEmitter<any>();
  @Output() deadlineSelected: EventEmitter<any> = new EventEmitter<any>();
  selectedAllocationMethod = 'Food offer';
  id: string;
  allocationMethodSet = false;
  selectedZones = [];
  selectedTime = 800;
  selectedDate = new Date();
  minDate = new Date();
  zones: any[] = [];
  time = [
    { label: '8:00AM', value: 800 },
    { label: '8:30AM', value: 830 },
    { label: '9:00AM', value: 900 },
    { label: '9:30AM', value: 930 },
    { label: '10:00AM', value: 1000 },
    { label: '10:30AM', value: 1030 },
    { label: '11:00AM', value: 1100 },
    { label: '11:30AM', value: 1130 },
    { label: '12:00PM', value: 1200 },
    { label: '12:30PM', value: 1230 },
    { label: '1:00PM', value: 1300 },
    { label: '1:30PM', value: 1330 },
    { label: '2:00PM', value: 1400 },
    { label: '2:30PM', value: 1430 },
    { label: '3:00PM', value: 1500 },
    { label: '3:30PM', value: 1530 },
    { label: '4:00PM', value: 1600 },
    { label: '4:30PM', value: 1630 },
    { label: '5:00PM', value: 1700 },
    { label: '5:30PM', value: 1730 },
    { label: '6:00PM', value: 1800 },
    { label: '6:30PM', value: 1830 },
  ];
  invalidTime = false;
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private cdRef: ChangeDetectorRef,
    private notificationService: NotificationService,
    private activatedRoute: ActivatedRoute,
    private generalService: GeneralService) { }


  ngOnInit() {
    this.getZones();
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
  }

  getZones() {
    this.generalService.getFoodBankDropdownOptions().subscribe(res => {
      for (const element of res.payload.zones) {
        this.zones.push({
          title: element,
          selected: false
        });
      }
    });
  }
  ngOnChanges() {
    if (this.donationDetail) {
      if (this.donationDetail.approval && !this.donationDetail.deadline) {
        this.allocationMethodSet = false;
      }
      if (this.donationDetail.approval && this.donationDetail.deadline) {
        this.allocationMethodSet = false;
      }
    }
  }

  ngAfterViewInit() {
    this.cdRef.detectChanges();
  }

  continue() {
    const data = {
      allocationMethod: this.selectedAllocationMethod.toString().toUpperCase().replace(/ /g, '_'),
      id: this.id
    };

    this.generalService.setDonationAllocationMethod(data).subscribe(res => {

      this.allocationMethodSet = true;
      this.allocationMethodSelected.emit(true);
      this.notificationService.showSuccess('Allocation method is set.');
    });
  }

  allocationMethodSeleted() {
    this.allocationMethodSelected.emit(true);
  }

  selectZone(zone, event) {
    const index = this.zones.findIndex(item => item.title === zone);
    if (index !== -1) {
      this.selectedZones.push(this.zones[index].title);
      this.zones[index].selected = event.target.checked;
    }
  }

  formatTimeIn24Hr(time) {
    if (time) {

      const meridiem = time[time.length - 2] + time[time.length - 1];

      let num = +time.slice(0, -2);
      if (meridiem === 'PM') {
        num = num === 12 ? 12 : num + 12;
      }

      return num;
    } else {
      return undefined;
    }
  }

  sendOffer() {
    if (this.checkOfferValidity()) {

      const tempDate = new Date(this.selectedDate);

      const { hour, min } = this.getTime({ value: this.selectedTime });

      const data = {
        id: this.id,
        zone: Array.from(new Set(this.selectedZones)),
        deadlinedate: moment(
          this.utilityService.convertToUtc(
            this.selectedDate.setHours(hour, min, 0)
          )
        ).format('YYYY-MM-DD HH:mm:ss'),
      };
      this.generalService.sendDonationOffer(data).subscribe(res => {
        this.deadlineSelected.emit(true);
        // this.router.navigate(['/donation/list']);
        this.notificationService.showSuccess('Offer sent successfully');
      });
    }
  }

  checkOfferValidity() {
    if (!this.selectedZones.length) {
      this.notificationService.showError('Please select at least one zone.');
      return false;
    }
    if (!this.selectedDate || !this.selectedTime) {
      this.notificationService.showError('Please select a date and time.');
      return false;
    }

    if (this.selectedDate && this.selectedTime) {
      this.timeSelected({ value: this.selectedTime });
      if (this.invalidTime) {
        return false;
      }
    }
    return true;
  }

  timeSelected(event) {
    const { hour, min } = this.getTime(event);

    const date = new Date(JSON.parse(JSON.stringify(this.selectedDate)));

    if (!moment(new Date()).isBefore(date.setHours(hour, min, 0))) {
      this.notificationService.showError('Please select time greater than current time');
      this.invalidTime = true;
      // return false;
    } else {
      this.invalidTime = false;
    }

    // return true;

  }

  getTime(event) {
    const hour = event.value.toString().length === 4 ? event.value.toString().substring(0, 2) : event.value.toString().substring(0, 1);
    const min = event.value.toString().slice(-2);
    return { hour, min };
  }

}
