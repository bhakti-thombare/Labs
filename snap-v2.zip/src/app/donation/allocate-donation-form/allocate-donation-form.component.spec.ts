import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocateDonationFormComponent } from './allocate-donation-form.component';

describe('AllocateDonationFormComponent', () => {
  let component: AllocateDonationFormComponent;
  let fixture: ComponentFixture<AllocateDonationFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllocateDonationFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllocateDonationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
