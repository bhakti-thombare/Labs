import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SignInFormComponent } from './sign-in-form/sign-in-form.component';
import { ForgotPasswordFormComponent } from './forgot-password-form/forgot-password-form.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ResetPasswordFormComponent } from './reset-password-form/reset-password-form.component';
import { AuthRoutingModule } from './auth-routing.module';
import { AuthDashboardComponent } from './auth-dashboard/auth-dashboard.component';
import { EmailUpdatedDetailsComponent } from './email-updated-details/email-updated-details.component';



@NgModule({
  declarations: [SignInFormComponent, ForgotPasswordFormComponent, ResetPasswordFormComponent, AuthDashboardComponent, EmailUpdatedDetailsComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    AuthRoutingModule
  ]
})
export class AuthModule { }
