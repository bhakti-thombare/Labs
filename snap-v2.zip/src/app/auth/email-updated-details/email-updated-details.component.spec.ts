import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailUpdatedDetailsComponent } from './email-updated-details.component';

describe('EmailUpdatedDetailsComponent', () => {
  let component: EmailUpdatedDetailsComponent;
  let fixture: ComponentFixture<EmailUpdatedDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmailUpdatedDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailUpdatedDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
