import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { GeneralService } from 'src/app/user/shared/services/general.service';
import { Cookie } from '../../core/services/cookie';
@Component({
  selector: 'app-email-updated-details',
  templateUrl: './email-updated-details.component.html',
  styleUrls: ['./email-updated-details.component.scss']
})
export class EmailUpdatedDetailsComponent implements OnInit {

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private generalService: GeneralService
  ) { }

  ngOnInit() {
    this.updateEmail();
  }

  updateEmail() {
    const queryParams = {
      token: this.activatedRoute.snapshot.queryParamMap.get('token'),
      email: this.activatedRoute.snapshot.queryParamMap.get('email'),
      updatedEmail: this.activatedRoute.snapshot.queryParamMap.get('updatedEmail')
    }
    this.generalService.updateEmailAddress(queryParams).subscribe(res => {
      this.freshLogin();
    });
  }


  freshLogin() {
    this.authService.logout().subscribe((logoutRes: any) => {
      window.location.href = '/';

    });
  }

}
