import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auth-dashboard',
  templateUrl: './auth-dashboard.component.html',
  styleUrls: ['./auth-dashboard.component.scss']
})
export class AuthDashboardComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

}
