import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { CookieService } from 'ngx-cookie-service';
import { UtilityService } from 'src/app/core/services/utility.service';
@Component({
  selector: 'app-reset-password-form',
  templateUrl: './reset-password-form.component.html',
  styleUrls: ['./reset-password-form.component.scss']
})
export class ResetPasswordFormComponent implements OnInit {

  resetPasswordForm: FormGroup;
  submitted: boolean;
  title: string;
  setPassword: boolean;
  token: string;
  setPasswordFlag: number;
  currentUser: any;
  submitClicked: boolean;
  resetPasswordDone = false;

  constructor(
    private cookieService: CookieService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private utilityService: UtilityService,
    private notificationService: NotificationService,
    private formBuilder: FormBuilder,
    private authService: AuthService) { }

  ngOnInit() {
    this.token = this.activatedRoute.snapshot.queryParamMap.get('token');
    if (this.router.url.includes('set-password')) {
      this.title = 'Set password';
      this.setPasswordFlag = 0;
    }
    if (this.router.url.includes('reset-password')) {
      this.title = 'Reset password';
      this.setPasswordFlag = 1;
    }
    if (this.router.url.includes('change-password')) {
      this.title = 'Reset password';
      this.setPasswordFlag = 2;
    }
    this.buildForm();
    this.loadUser();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  buildForm() {

    this.resetPasswordForm = this.formBuilder.group({
      newPassword: ['', Validators.required],
      confirmPassword: ['', Validators.required],
    }, {
      validator: this.MustMatch('newPassword', 'confirmPassword')
    });

    this.resetPasswordForm.valueChanges.subscribe(value => {
      if (value) {
        this.submitClicked = false;
      }
    });
  }

  submit() {
    this.submitClicked = true;
    if (this.resetPasswordForm.valid) {
      const data: any = {
        password: this.resetPasswordForm.value.newPassword,
        confirmPassword: this.resetPasswordForm.value.confirmPassword
      };

      if (this.setPasswordFlag === 0) {
        this.authService.setPassword(data, this.token).subscribe(res => {
          this.notificationService.showSuccess('You have set your password successfully.');
          this.router.navigateByUrl('/');
          this.submitClicked = false;
        });
      } else if (this.setPasswordFlag === 1) {
        this.authService.resetPassword(data, this.token).subscribe(res => {
          this.submitClicked = false;
          this.router.navigateByUrl('/');
          this.notificationService.showSuccess('You have reset your password successfully.');
        });
      } else if (this.setPasswordFlag === 2) {
        data.email = this.currentUser && this.currentUser.username || undefined;
        this.authService.changePassword(data).subscribe(res => {
          this.resetPasswordDone = true;
          this.submitClicked = false;
          this.authService.removeAuthCookie();
          this.authService.logout().subscribe((logoutRes: any) => {
          });
        });
      }
      this.submitted = true;
    } else {
    }
  }


  // custom validator to check that two fields match
  MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        // return if another validator has already found an error on the matchingControl
        return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }

  length(event, field) {
    if (this.resetPasswordForm.get(field).value && this.resetPasswordForm.get(field).value.length >= 15) {
      this.notificationService.showError('Only 15 characters allowed for this field.');
    }
  }
}
