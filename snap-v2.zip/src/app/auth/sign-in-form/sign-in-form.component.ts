import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { UtilityService } from 'src/app/core/services/utility.service';

@Component({
  selector: 'app-sign-in-form',
  templateUrl: './sign-in-form.component.html',
  styleUrls: ['./sign-in-form.component.scss']
})
export class SignInFormComponent implements OnInit {

  constructor(
    private utilityService: UtilityService,
    private authService: AuthService,
    private notificationService: NotificationService,
    private formBuilder: FormBuilder,
    private router: Router) { }
  activeState = 0;
  signInForm: FormGroup;
  submitted = false;
  emailPattern = this.utilityService.emailPattern;
  ngOnInit() {
    this.buildForm();
  }

  buildForm() {
    this.signInForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      password: ['', Validators.required]
    });


    this.signInForm.valueChanges.subscribe(value => {
      if (value) {
        this.submitted = false;
      }
    });
  }

  switchActiveState(value) {
    this.activeState = value;
  }

  submit() {
    if (this.signInForm.valid) {
      this.submitted = true;
      const data = {
        username: this.signInForm.value.email,
        password: this.signInForm.value.password
      };
      this.authService.login(data);
    } else {
      this.notificationService.showError('Please enter valid email address and password');
    }
  }

  navigateTo(route) {
    this.router.navigateByUrl(route);
  }
  
  length(event){
    if (this.signInForm.get('password').value.length >= 15) {
      this.notificationService.showError('Only 15 characters allowed for this field.');
    }
  }

}
