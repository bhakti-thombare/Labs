import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AuthService } from 'src/app/core/services/auth.service';
import { UtilityService } from 'src/app/core/services/utility.service';

@Component({
  selector: 'app-forgot-password-form',
  templateUrl: './forgot-password-form.component.html',
  styleUrls: ['./forgot-password-form.component.scss']
})
export class ForgotPasswordFormComponent implements OnInit {

  forgotPasswordForm: FormGroup;
  emailPattern = this.utilityService.emailPattern;
  submitted = false;
  @Output() backToLogin: EventEmitter<any> = new EventEmitter<any>();
  email: any;
  constructor(private utilityService: UtilityService, private formBuilder: FormBuilder, private authService: AuthService) { }

  ngOnInit() {
    this.buildForm();
  }

  buildForm() {

    this.forgotPasswordForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
    });
  }

  goBackToLogin() {
    this.backToLogin.emit(true);
  }

  submit() {
    if (this.forgotPasswordForm.valid) {
      this.email = this.forgotPasswordForm.value.email;
      this.authService.forgotPassword(this.email).subscribe(res => {
        this.submitted = true;
      });
    }
  }
}
