import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignInFormComponent } from './sign-in-form/sign-in-form.component';
import { ForgotPasswordFormComponent } from './forgot-password-form/forgot-password-form.component';
import { ResetPasswordFormComponent } from './reset-password-form/reset-password-form.component';
import { AuthDashboardComponent } from './auth-dashboard/auth-dashboard.component';
import { PublicPageGuard } from '../core/guards/public-page.guard';
import { EmailUpdatedDetailsComponent } from './email-updated-details/email-updated-details.component';


const routes: Routes = [
    {
        path: '', component: AuthDashboardComponent, children: [
            { path: '', redirectTo: 'sign-in', pathMatch: 'full' },
            { path: 'sign-in', canActivate: [PublicPageGuard], component: SignInFormComponent },
            { path: 'forgot-password', canActivate: [PublicPageGuard], component: ForgotPasswordFormComponent },
            { path: 'reset-password', component: ResetPasswordFormComponent },
            { path: 'set-password', component: ResetPasswordFormComponent },
            { path: 'update/email', component: EmailUpdatedDetailsComponent },
            { path: 'change-password', component: ResetPasswordFormComponent }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AuthRoutingModule { }
