import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { SharedModule } from '../shared/shared.module';
import { UserAccountDetailComponent } from './user-account-detail/user-account-detail.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserCreateFormComponent } from './user-create-form/user-create-form.component';
import { UserImportFormComponent } from './user-import-form/user-import-form.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { FoodBankProfileListComponent } from './food-bank-profile-list/food-bank-profile-list.component';
import { FoodBankProfileFormComponent } from './food-bank-profile-form/food-bank-profile-form.component';
import { DonorProfileFormComponent } from './donor-profile-form/donor-profile-form.component';
import { DonorProfileListComponent } from './donor-profile-list/donor-profile-list.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { UserAccountFormComponent } from './user-account-form/user-account-form.component';
import { FoodBankProfileDetailsComponent } from './food-bank-profile-details/food-bank-profile-details.component';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';

import { NgxMaskModule, IConfig } from "ngx-mask";

export const options: Partial<IConfig> | (() => Partial<IConfig>) = null;

@NgModule({
  declarations: [
    UserAccountFormComponent,
    UserDashboardComponent,
    UserAccountDetailComponent,
    UserListComponent,
    UserCreateFormComponent,
    UserImportFormComponent,
    FoodBankProfileListComponent,
    FoodBankProfileFormComponent,
    DonorProfileFormComponent,
    DonorProfileListComponent,
    FoodBankProfileDetailsComponent],
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    TimepickerModule.forRoot(),
    ModalModule.forRoot(),
    PopoverModule.forRoot(),
    NgxMaskModule.forRoot(),
    SharedModule,
    ConfirmDialogModule,
    NgSelectModule,
    UserRoutingModule
  ],
  exports: [
    FoodBankProfileListComponent,
    FoodBankProfileDetailsComponent
  ],
  providers: [ConfirmationService]
})
export class UserModule { }
