import { ChangeDetectorRef, Component, OnInit, HostListener, ViewChild, TemplateRef, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GeneralService } from '../shared/services/general.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { combineLatest, Subscription } from 'rxjs';
import { ThrowStmt } from '@angular/compiler';
@Component({
  selector: 'app-user-create-form',
  templateUrl: './user-create-form.component.html',
  styleUrls: ['./user-create-form.component.scss']
})
export class UserCreateFormComponent implements OnInit, OnDestroy {
  public lettersOnlyCustomPatterns = {'S': { pattern: new RegExp('\[a-zA-Z \]')}};
  public lettersAndNumbersCustomPatterns = {'A': { pattern: new RegExp('\[a-zA-Z0-9 \]')}};
  foodBanks = ['food bank 1', 'food bank 2', 'food bank 3', 'food bank 4', 'food bank 5'];
  userForm: FormGroup;
  emailPattern = this.utilityService.emailPattern;
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  currentUser: any;
  foodBankList: any;
  userDetails: any;
  selectedFoodBank: any;
  userId: any;
  roles: any;
  allFoodBanks = [];
  messages: any;
  subscriptions: Subscription[] = [];
  modalRef: BsModalRef;
  updateEmailForm: FormGroup;
  showNewEmail = false;
  newEmail: any;

  @HostListener('window:resize', ['$event'])
  onResize(event?) {
    this.setClass();
  }

  constructor(
    private modalService: BsModalService,
    private utilityService: UtilityService,
    private changeDetection: ChangeDetectorRef,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private authService: AuthService,
    private formBuilder: FormBuilder,
    private generalService: GeneralService,
    private notificationService: NotificationService) { }
  ngOnInit() {
    this.userId = this.activatedRoute.snapshot.paramMap.get('id');
    this.loadUser();
    if (this.userId) { this.getUserById(); }
    if (!this.userId) {
      this.getAllFoodBanks();
      this.getDropDownOptions();
    }
    this.setClass();
    this.buildForm();
    this.builUpdatedEmailForm();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }


  buildForm() {
    if (!this.userId) {
      this.userForm = this.formBuilder.group({
        email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
        name: ['', Validators.required],
        phone: [''],
        role: [null, Validators.required],
        foodbank: [null, Validators.required],
        notification: [false],
        title: [''],
        active: [false]

      });
      this.userForm.controls.notification.setValue(true);
    } else {
      this.userForm = this.formBuilder.group({
        email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
        name: ['', Validators.required],
        phone: [''],
        role: [null, Validators.required],
        foodbank: [null, Validators.required],
        notification: [false],
        title: [''],
        active: [false],
        password: [''],
        reEnterPassword: ['']

      }, {
        validator: this.MustMatch('password', 'reEnterPassword')
      });

      this.userForm.controls.notification.setValue(true);
    }

  }
  setClass() {
    const nodes: any = document.querySelectorAll('[id="input-title"]');
    if (window.outerWidth < 768) {
      nodes.forEach(node => {
        node.classList.remove('text-right');
      });
    } else {
      nodes.forEach(node => {
        node.classList.add('text-right');
      });
    }
  }

  radioSelected(value) {
    this.userForm.controls.notification.setValue(value);

  }

  submit() {
    if (this.checkValidity()) {

      const data = this.userForm.getRawValue();
      data.phone = data.phone && data.phone.toString();
      data.role = data.role.toUpperCase() === 'ADMIN' ? 'ADMIN' : 'FOOD_BANK';
      data.foodBankId = data.foodbank;
      if (this.userId) {
        data.adminEmail = this.currentUser.username;
        if (!data.password) {
          data.password = null;
        }
        if (!data.reEnterPassword) {
          data.reEnterPassword = null;
        }
        if (data.role === 'ADMIN') {
          data.foodBankId = '';
          data.foodbank = '';
        }
        if (!this.updateEmailForm.get('retype').value) {
          data.updateEmail = data.email;
        } else {
          data.updateEmail = this.newEmail;
        }
        data.updateEmail = this.newEmail || data.email;
        if (+this.currentUser.id === +this.userId) {

          this.updateSelfAccountDetails(data);
        } else {

          this.generalService.updateUser(data).subscribe(res => {
            this.notificationService.showSuccess('User profile updated successfully.');
            this.router.navigateByUrl('/user/list');
          });
        }
      } else {
        data.adminusername = this.currentUser.username;

        this.generalService.createUser(data).subscribe(res => {
          this.notificationService.showSuccess('User created successfully.');
          this.router.navigateByUrl('/user/list');
        });
      }
    }

  }

  updateSelfAccountDetails(data) {
    const newData = {
      name: data.name,
      phone: data.phone,
      title: data.title
    };
    this.generalService.updateSelfAccount(newData).subscribe(res => {
      this.notificationService.showSuccess('User updated successfully.');
      this.router.navigateByUrl('/user/list');
    });
  }
  checkValidity() {
    console.log('this.userForm', this.userForm)
    if (this.userForm.invalid) {
      this.notificationService.showError('Please fill all mandatory fields');
      return false;
    } else {

      if (this.userId) {
        if (this.userForm.controls.password) {
          if (this.userForm.controls.reEnterPassword) {
            return true;
          } else {
            return false;
          }
        }
      }
      return true;
    }

  }

  getAllFoodBanks() {
    this.generalService.getFoodBanks({ pageNo: 0, pageSize: 1000, status: 'Active' }).subscribe(res => {
      this.allFoodBanks = JSON.parse(JSON.stringify(res.payload.foodBankList));
      this.foodBankList = res.payload.foodBankList;
      if (localStorage.getItem('new_org_member')) {
        const queryParam = JSON.parse(localStorage.getItem('new_org_member'));
        this.userForm.get('role').setValue(queryParam.role === 'Admin' ? 'Admin' : 'Food bank');
        this.selectedFoodBank = this.foodBankList.filter(item => item.id === +queryParam.foodBank)[0];
        this.userForm.get('foodbank').setValue(this.selectedFoodBank.id);
      }
    });
  }

  getUserById() {
    this.generalService.getUserById(this.userId).subscribe(res => {
      this.userDetails = res;

      this.patchForm();
    });
  }

  roleChanged(event) {
    if (event.toString().toLowerCase() === 'admin') {

      this.userForm.get('foodbank').setValue('');
      this.userForm.get('foodbank').clearValidators();
      this.userForm.get('foodbank').updateValueAndValidity();
      console.log('this.allFoodBanks.filter(item => item.name === \'Feed Ontario\' || item.name === \'Feed Ontario \')', ...this.allFoodBanks.filter(item => item.name.toString().toLowerCase().trim() === 'feed ontario'))
      this.foodBankList = [...this.allFoodBanks.filter(item => item.name === 'Feed Ontario' || item.name === 'Feed Ontario ')];
      this.selectedFoodBank = this.foodBankList[0];
    } else {
      this.userForm.get('foodbank').setValidators([Validators.required]);
      this.userForm.get('foodbank').updateValueAndValidity();


      if (!this.userId) {
        console.log('this.allFoodBanks.filter(item => item.name !== \'Feed Ontario\' || item.name !== \'Feed Ontario \')', this.allFoodBanks.filter(item => item.name.toString().toLowerCase().trim() !== 'feed ontario'))
        this.foodBankList = [...this.allFoodBanks.filter(item => item.name.toString().toLowerCase().trim() !== 'feed ontario')];
        this.selectedFoodBank = this.foodBankList[0];
      }
      if (this.selectedFoodBank) { this.userForm.get('foodbank').setValue(this.selectedFoodBank.id); }
    }
    console.log(this.foodBankList);
  }

  patchForm() {
    if (this.userDetails) {
      this.selectedFoodBank = {
        id: this.userDetails.foodbank && this.userDetails.foodbank.id || null,
        name: this.userDetails.foodbank && this.userDetails.foodbank.name || null
      };
      const data = this.userDetails;

      this.userForm.patchValue({
        email: data.email,
        name: data.name,
        phone: data.phone || null,
        role: data.role === 'ADMIN' ? 'Admin' : 'Food bank',
        foodbank: this.selectedFoodBank.id,
        notification: data.notification,
        title: data.title,
        active: data.active,
        password: '',
        reEnterPassword: ''
      });
      this.roleChanged(data.role);
      this.userForm.get('notification').setValue(data.notification);
      this.userForm.controls.role.disable();
      this.userForm.controls.foodbank.disable();
      this.userForm.controls.email.disable();
    }
  }



  // custom validator to check that two fields match
  MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        // return if another validator has already found an error on the matchingControl
        return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }

  deleteUser() {

    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: 'Are you sure that you want to perform this action?',
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {
          const data: any = {
            adminEmail: this.currentUser.username,
            email: this.userForm.value.email
          };

          this.generalService.deleteUser(data).subscribe(res => {
            this.notificationService.showSuccess('User deleted successfully.');
            this.router.navigateByUrl('/user/list');
          });
        }
      },
    });
  }

  foodbankSelected(event) {
    this.selectedFoodBank = event;
    this.userForm.get('foodbank').setValue(this.selectedFoodBank.id);
  }

  onlyNumberKey(evt) {
    return this.utilityService.onlyNumberKey(evt);
  }

  lettersOnly(event, field, limit) {
    if (this.userForm.get(field).value.length >= limit) {
      // debugger;
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
    // return this.utilityService.lettersOnly(event);
    if(this.utilityService.lettersOnly(event)){
      return true;
    }
    else{
      this.notificationService.showError('Only letters are allowed.');
      return false;
    }
  }



  numbersAndLettersOnly(event) {
    if (this.userForm.get('phone').value.length >= 12) {
      this.notificationService.showError('Only 12 digits allowed.');
    }
    if (this.utilityService.onlyNumberKey(event) || this.utilityService.lettersOnly(event)) {
      return true;
    } else {
       this.notificationService.showError('Only numbers and letters are allowed.');
      return false;
    }
  }

  getDropDownOptions() {
    this.generalService.getDropdownOptions().subscribe(res => {

      this.roles = [];
      res.payload.roles.forEach(item => {
        this.roles.push((item === 'ADMIN' ? 'Admin' : 'Food bank'));
      });
    });
  }

  builUpdatedEmailForm() {
    this.updateEmailForm = this.formBuilder.group({
      updatedEmail: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      retype: ['', [Validators.required, Validators.pattern(this.emailPattern)]]
    }, {
      validator: this.MustMatch('updatedEmail', 'retype')
    });
  }

  openEmailUpdateModal(template: TemplateRef<any>) {
    this.modalCloseHandler();
    this.modalRef = this.modalService.show(template, { ignoreBackdropClick: true });
    // this.updateEmailForm.patchValue({
    //   retype:this.updateEmailForm.value.updatedEmail
    // })
  }
  
  modalCloseHandler(value?) {
    const combine = combineLatest(
      this.modalService.onShow,
      this.modalService.onShown,
      this.modalService.onHide,
      this.modalService.onHidden
    ).subscribe(() => this.changeDetection.markForCheck());

    this.subscriptions.push(
      this.modalService.onHide.subscribe((reason: string | any) => {

        this.closeModal();
        this.unsubscribe();
      })
    );
    this.subscriptions.push(combine);

  }

  unsubscribe() {
    this.subscriptions.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
    this.subscriptions = [];
  }

  closeModal(value?) {
    if (this.modalRef) {
      if (value === 'CANCEL') {

        if (!this.updateEmailForm.value.retype || !this.updateEmailForm.value.updatedEmail && this.updateEmailForm.value.retype !== this.updateEmailForm.value.updatedEmail) {
          this.updateEmailForm.reset();
          this.newEmail = '';
        }

        if (this.currentUser.role !== 'ADMIN') {
          if (!this.showNewEmail) {
            this.updateEmailForm.reset();
            this.newEmail = '';
          }
        }
      }
      this.modalRef.hide();
      this.updateEmailForm.reset();
    }
  }

  submitUpdatedEmail() {

    if (this.updateEmailForm.valid) {
      this.newEmail = JSON.parse(JSON.stringify(this.updateEmailForm.value.retype));
      // self update

      if (+this.currentUser.id === +this.userId) {
        const data = this.updateEmailForm.value;
        this.generalService.updateSelfEmail(data).subscribe(res => {
          this.showNewEmail = true;
          this.notificationService.showSuccess('Please check your email, you must have received an email with further instructions.');
          this.modalRef.hide();
        });
      } else {
        // update admin

        this.showNewEmail = true;
        // this.updatedEmail = this.updateEmailForm.get('updatedEmail').value;
        this.notificationService.showSuccess('Please click on save, to update the user email address.');
        this.modalRef.hide();

      }
    } else {
      this.utilityService.turnFormControlsDirty(this.updateEmailForm);
    }
  }

  ngOnDestroy() {
    if (localStorage.getItem('new_org_member')) {
      localStorage.removeItem('new_org_member');
    }
  }

}
