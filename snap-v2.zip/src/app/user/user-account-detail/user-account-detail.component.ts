import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-account-detail',
  templateUrl: './user-account-detail.component.html',
  styleUrls: ['./user-account-detail.component.scss']
})
export class UserAccountDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
