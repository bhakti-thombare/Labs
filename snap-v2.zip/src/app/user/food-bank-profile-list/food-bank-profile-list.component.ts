import { Component, OnInit } from '@angular/core';
import { GeneralService } from '../shared/services/general.service';
import { Router } from '@angular/router';
import { foodBankProfileSortParam } from '../shared/enums/user.enum';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-food-bank-profile-list',
  templateUrl: './food-bank-profile-list.component.html',
  styleUrls: ['./food-bank-profile-list.component.scss']
})
export class FoodBankProfileListComponent implements OnInit {

  foodBankList = [];
  currentPage = 1;
  pageSize = 15;
  total = 0;
  delta = 2;
  totalPages: number;

  sortParam: any;
  order = 'ASC';
  currentUser: any;
  zones: any[];
  zone = 'all';
  orgTypes: any[];
  orgType = 'all';
  orgStatus = 'all';
  orgStatuses: any[];
  public get foodBankProfileSortParam(): typeof foodBankProfileSortParam {
    return foodBankProfileSortParam;
  }
  constructor(
    private router: Router,
    private authService: AuthService,
    private generalService: GeneralService
  ) {
    this.loadUser();
  }



  ngOnInit() {
    this.getzones();
    this.getFoodBanks();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  getFoodBanks() {
    const queryParams: any = {
      pageSize: this.pageSize,
      pageNo: this.currentPage - 1
    };
    if (this.zone !== 'all') {
      queryParams.zone = this.zone;
    }

    if (this.orgType !== 'all') {
      queryParams.orgType = this.orgType;
    }

    if (this.orgStatus !== 'all') {
      queryParams.status = this.orgStatus;
    }



    if (this.sortParam && this.order) {
      queryParams.sort = this.sortParam;
      queryParams.order = this.order;
    }


    this.generalService.getFoodBanks(queryParams).subscribe(res => {
      this.total = res.payload.count;
      this.foodBankList = res.payload.foodBankList;
      this.roundOffFloatValues(this.foodBankList);
    });
  }

  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getFoodBanks();
  }


  sortList(sortParam) {
    this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
    this.sortParam = sortParam;
    this.getFoodBanks();
  }

  zoneChanged(event) {
    
  }

  orgTypeChanged(event) {
    
  }
  orgStatusChanged(event) {
    
  }
  getzones() {
    this.generalService.getFoodBankDropdownOptions().subscribe(res => {
      const zoneTemp = []
      const orgTypeTemp = []
      const orgStatusTemp = []

      //zones
      zoneTemp.push({
        label: 'All', value: 'all'
      });
      for (const zone of res.payload.zones) {
        zoneTemp.push({
          label: zone, value: zone
        });
      }
      this.zones = zoneTemp;

      // org types
      orgTypeTemp.push({
        label: 'All', value: 'all'
      });
      for (const type of res.payload['org-types']) {
        orgTypeTemp.push({
          label: type, value: type
        });
      }
      this.orgTypes = orgTypeTemp;

      // org status
      orgStatusTemp.push({
        label: 'All', value: 'all'
      });
      for (const type of res.payload.status) {
        orgStatusTemp.push({
          label: type, value: type
        });
      }
      this.orgStatuses = orgStatusTemp;

    });
  }

  submitFilter() {
    this.currentPage = 1;
    this.getFoodBanks();
  }


  roundOffFloatValues(list) {
    for (const item of list) {
      item.orgProfile.hcPercent = item.orgProfile.hcPercent && +item.orgProfile.hcPercent.toFixed(2) || 0;
      item.orgProfile.overallPercent = item.orgProfile.overallPercent && +item.orgProfile.overallPercent.toFixed(2) || 0;
    }
  }
}
