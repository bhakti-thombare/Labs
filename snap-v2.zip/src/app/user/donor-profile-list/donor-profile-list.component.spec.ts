import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonorProfileListComponent } from './donor-profile-list.component';

describe('DonorProfileListComponent', () => {
  let component: DonorProfileListComponent;
  let fixture: ComponentFixture<DonorProfileListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonorProfileListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonorProfileListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
