import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { donorProfileSortParam } from '../shared/enums/user.enum';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-donor-profile-list',
  templateUrl: './donor-profile-list.component.html',
  styleUrls: ['./donor-profile-list.component.scss']
})
export class DonorProfileListComponent implements OnInit {

  donorsList = [];
  currentUser: any;
  modalRef: BsModalRef;
  link: any;
  primaryEmail: any;
  currentPage = 1;
  pageSize = 15;
  total = 0;
  delta = 2;
  totalPages: number;

  sortParam: any;
  order = 'ASC';
  public get donorProfileSortParam(): typeof donorProfileSortParam {
    return donorProfileSortParam;
  }
  constructor(
    private notificationService: NotificationService,
    private modalService: BsModalService,
    private generalService: GeneralService,
    private authService: AuthService
  ) { }

  ngOnInit() {
    this.loadUser();
    this.getDonors();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  getDonors() {
    const queries: any = {
      pageNo: this.currentPage - 1,
      pageSize: this.pageSize
    }
    if (this.sortParam && this.order) {
      queries.sort = this.sortParam;
      queries.order = this.order;
    }
    this.generalService.getDonors(queries).subscribe(res => {
      this.total = res.payload && res.payload.count || 0;
      this.donorsList = res.payload && res.payload.donorResponseDtos || [];
      console.log('this.donorsList', this.donorsList)
      this.donorsList.forEach(element => {
        if(element.contactInformation && element.contactInformation.length) {

          const index = element.contactInformation.findIndex(item => item.primary === true);
          // console.log(element);
          element.primaryEmail = element.contactInformation[index].email;
        }
      });
    });
  }

  openModal(template: TemplateRef<any>) {

    this.modalRef = this.modalService.show(template, { ignoreBackdropClick: true });

  }
  closeModal() {
    if (this.modalRef) {
      this.modalRef.hide();
    }
  }

  createDonation(template, donor) {
    const data = {
      donorId: donor.id,
      primaryEmail: donor.primaryEmail,
      adminEmail: this.currentUser.username
    };
    this.generalService.getDonationLink(data).subscribe(res => {
      
      this.link = res.payload;
      this.primaryEmail = donor.primaryEmail;
      this.openModal(template);
    });
    // create donation
    // get link
  }

  sendDonationEmail() {
    const data = {
      donorEmail: this.primaryEmail,
      link: this.link
    };
    this.generalService.sendEmailToDonor(data).subscribe(res => {
      this.notificationService.showSuccess('Email sent successfully.');
    });
  }

  copyLink() {
    const element = document.getElementById('link');
    if (this.link) {
      // 
      const dummy = document.createElement('textarea');
      // to avoid breaking orgain page when copying more words
      // cant copy when adding below this code
      // dummy.style.display = 'none'
      document.body.appendChild(dummy);
      // Be careful if you use texarea. setAttribute('value', value), which works with "input" does not work with "textarea". – Eduard
      dummy.value = this.link;
      dummy.select();
      document.execCommand('copy');
      document.body.removeChild(dummy);
      element.classList.add('alert-success');
    }
    this.notificationService.showSuccess('Link copied to clipboard.');
  }


  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {
    // 
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getDonors();
  }

  sortList(sortParam) {
    this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
    this.sortParam = sortParam;
    this.getDonors();
  }
}

