import { Component, OnInit, ViewChild } from '@angular/core';
import { GeneralService } from '../shared/services/general.service';
import { DataSharingService } from 'src/app/core/services/data-sharing.service';
import { ConfirmationService } from 'primeng/api';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { userProfileSortParam } from '../shared/enums/user.enum';
@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {
  userList: any[] = [];
  currentUser: any;
  currentPage = 1;
  pageSize = 15;
  total = 0;
  delta = 2;
  totalPages: number;
  sortParam: any;
  order = 'ASC';
  public get userProfileSortParam(): typeof userProfileSortParam {
    return userProfileSortParam;
  }
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;

  constructor(
    private authService: AuthService,
    private notificationService: NotificationService,
    private confirmationService: ConfirmationService,
    private generalService: GeneralService,
    private dataSharingService: DataSharingService) { }

  ngOnInit() {
    this.getUsers();
    this.loadUser();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }


  getUsers() {
    const queries: any = {
      pageNo: this.currentPage - 1,
      pageSize: this.pageSize
    };
    if (this.sortParam && this.order) {
      queries.sort = this.sortParam;
      queries.order = this.order;
    }
    this.generalService.getUsers(queries).subscribe(res => {
      this.total = res.payload && res.payload.count || 0;
      this.userList = res.payload && res.payload.usersDtoList || [];
    });
  }

  setUserData(user) {
    this.dataSharingService.selectedUserData = user;
  }


  deleteUser(user) {

    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: 'Are you sure that you want to perform this action?',
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {
          const data: any = {
            adminEmail: this.currentUser.username,
            email: user.email
          };
          this.generalService.deleteUser(data).subscribe(res => {
            this.notificationService.showSuccess('User deleted successfully.');
            this.getUsers();
          });
        }
      },
    });
  }

  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getUsers();
  }

  sortList(sortParam) {
    this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
    this.sortParam = sortParam;
    this.getUsers();
  }




}