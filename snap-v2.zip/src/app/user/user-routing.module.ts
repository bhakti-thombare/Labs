import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserCreateFormComponent } from './user-create-form/user-create-form.component';
import { UserAccountDetailComponent } from './user-account-detail/user-account-detail.component';
import { UserImportFormComponent } from './user-import-form/user-import-form.component';
import { AdminAuthGuard } from '../core/guards/admin-auth.guard';
import { FoodBankProfileListComponent } from './food-bank-profile-list/food-bank-profile-list.component';
import { DonorProfileListComponent } from './donor-profile-list/donor-profile-list.component';
import { DonorProfileFormComponent } from './donor-profile-form/donor-profile-form.component';
import { PageUnderDevelopmentComponent } from '../shared/components/page-under-development/page-under-development.component';
import { FoodBankProfileFormComponent } from './food-bank-profile-form/food-bank-profile-form.component';
import { FoodBankProfileDetailsComponent } from './food-bank-profile-details/food-bank-profile-details.component';


const routes: Routes = [
  {
    path: '', component: UserDashboardComponent, children: [

      // food bank user and self user account
      { path: 'edit/:id', component: UserCreateFormComponent },
      { path: 'account/edit/:id', component: UserCreateFormComponent },
      { path: 'list', canActivate: [AdminAuthGuard], component: UserListComponent },
      { path: 'new', canActivate: [AdminAuthGuard], component: UserCreateFormComponent },
      { path: 'view/:id', component: UserAccountDetailComponent },
      { path: 'import', component: UserImportFormComponent },

      // donor profile
      { path: 'donor/list', component: DonorProfileListComponent },
      { path: 'donor/new', component: DonorProfileFormComponent },
      { path: 'donor/view/:id', component: PageUnderDevelopmentComponent },
      { path: 'donor/edit/:id', component: DonorProfileFormComponent },
      { path: 'donor/donations/:id', component: PageUnderDevelopmentComponent },

      // food bank profile
      { path: 'food-bank/list', component: FoodBankProfileListComponent },
      { path: 'food-bank/new', component: FoodBankProfileFormComponent },
      { path: 'food-bank/view/:id', component: FoodBankProfileDetailsComponent },
      { path: 'food-bank/edit/:id', component: FoodBankProfileFormComponent },
      { path: 'food-bank/offers/:id', component: PageUnderDevelopmentComponent }
    ]
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
