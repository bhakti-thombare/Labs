export enum donorProfileSortParam {
  NAME = 'name',
  QUALITY = 'quality'
}

export enum userProfileSortParam {
  NAME = 'profile_name',
  EMAIL = 'profile_email',
  ROLE = 'role',
  FOODBANK = 'foodbank_name',
}
export enum foodBankProfileSortParam {
  NAME = 'name',
  CITY = 'city',
  ZONE = 'zone_name',
  HUNGER_COUNT = 'hunger_count',
  HC_PERCENT = 'hc_percent',
  OVERALL_PERCENT = 'overall_percent',
}