import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  baseUrl = environment.apiUrl;
  constructor(private restService: RestService, private http: HttpClient) { }

  // FOOD BANK USERS

  createUser(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/user/registration`, data, undefined, true);
  }

  getUsers(queryParams?) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/user/getAllUsers`, queryParams, true);
  }

  deleteUser(data) {
    return this.restService.delete(`${this.baseUrl}/api/v1/user/deleteuser`, data, undefined, true);
  }

  updateUser(body) {
    return this.restService.put(`${this.baseUrl}/api/v1/user/updateUserProfile`, body, undefined, true);
  }

  getUserById(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/user/getUser/${id}`, undefined, true);
  }


  // DONOR PROFILE

  // create
  createDonor(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/donor/createDonor`, data, undefined, true);
  }

  // update
  updateDonor(data) {
    return this.restService.put(`${this.baseUrl}/api/v1/donor/updateDonor`, data, undefined, true);
  }


  // get all
  getDonors(queries?) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donor/getAllDonor`, queries, true);
  }

  // get by primary contact email
  getDonorDetails(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/donor/getDonorByEmail`, data, undefined, true);
  }

  // delete by primary contact email
  deleteDonor(data) {
    return this.restService.delete(`${this.baseUrl}/api/v1/donor/deleteDonor`, data, undefined, true);
  }

  // send email
  sendEmail(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/donor/updateDonor/sendEmail`, data, undefined, true);
  }

  // FOOD BANK PROFILE

  // create
  createFoodBank(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/foodbank/profile`, data, undefined, true);
  }

  // update
  updateFoodBank(data, id) {
    return this.restService.put(`${this.baseUrl}/api/v1/foodbank/profile/${id}`, data, undefined, true);
  }

  // get by id
  getFoodBankDetails(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/profile/${id}`, undefined, true);
  }

  // get by id
  getFoodBankDetailsForView(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/myoffersTab/profile/${id}`, undefined, true);
  }

  // get all
  getFoodBanks(queryParams?) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/profile`, queryParams, true);
  }

  getParentHubs() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/profile`, undefined, true);

    // return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/parent-hub`, undefined, true);
  }

  getStatus() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/status`, undefined, true);

  }
  getOrganizationTypes() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/org-types`, undefined, true);

  }

  getFoodBankDropdownOptions() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/form-options`, undefined, true);

  }

  // delete
  deleteFoodBank(id) {
    return this.restService.delete(`${this.baseUrl}/api/v1/foodbank/profile/${id}`, undefined, undefined, true);
  }


  // get user roles
  getFoodBankUserRoles() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/user/roles`, undefined, true);

  }

  // get user form options
  getDropdownOptions() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/user/form-options`, undefined, true);

  }

  getDonationLink(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/donor/sendEmailAndCopyLink`, data, undefined, true);

  }

  sendEmailToDonor(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/donor/sendMailToDonor`, data, undefined, true);
  }

  updateSelfAccount(data) {
    return this.restService.put(`${this.baseUrl}/api/v1/user/updateSelfProfile`, data, undefined, true);
  }


  updateSelfEmail(data) {
    return this.restService.put(`${this.baseUrl}/api/v1/user/updateUserEmail`, data, undefined, true);
  }

  updateEmailAddress(queryParams) {
    return this.restService.put(`${this.baseUrl}/api/v1/user/updateEmail`, undefined, queryParams, true);
  }
}
