import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GeneralService } from '../shared/services/general.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { ConfirmationService } from 'primeng/api';
import { DataSharingService } from 'src/app/core/services/data-sharing.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { UtilityService } from 'src/app/core/services/utility.service';

@Component({
  selector: 'app-user-account-form',
  templateUrl: './user-account-form.component.html',
  styleUrls: ['./user-account-form.component.scss']
})
export class UserAccountFormComponent implements OnInit {

  foodBanks = ['food bank 1', 'food bank 2', 'food bank 3', 'food bank 4', 'food bank 5'];
  editUserAdminForm: FormGroup;
  editUserForm: FormGroup;
  emailPattern = this.utilityService.emailPattern;
  currentUser: any;
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  userDetails: any;
  userId: string;
  @HostListener('window:resize', ['$event'])
  onResize(event?) {
    this.setClass();
  }

  constructor(
    private utilityService: UtilityService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private formBuilder: FormBuilder,
    private generalService: GeneralService,
    private notificationService: NotificationService,
    private dataSharingService: DataSharingService) { }
  ngOnInit() {
    this.userId = this.activatedRoute.snapshot.paramMap.get('id');
    if (this.userId) {
      this.getUserById();
    }
    this.setClass();
    this.buildForm();
    this.loadUser();
    // this.patchForm();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  patchForm() {
    if (this.userDetails) {
      const data = this.userDetails;
      this.editUserAdminForm.patchValue({
        email: data.email,
        name: data.name,
        phone: parseInt(data.phone, 10),
        role: data.role,
        foodbank: 'food bank 1',
        notification: data.notification,
        title: data.title,
        active: data.active,
        password: '',
        reEnterPassword: ''
      });
    }
  }


  buildForm() {
    this.editUserAdminForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      name: ['', Validators.required],
      phone: [''],
      role: [null, Validators.required],
      foodbank: [null, Validators.required],
      notification: [false],
      title: [''],
      active: [false],
      password: [''],
      reEnterPassword: ['']

    }, {
      validator: this.MustMatch('password', 'reEnterPassword')
    });
    this.editUserAdminForm.controls.notification.setValue(true);
  }
  setClass() {
    const nodes: any = document.querySelectorAll('[id="input-title"]');
    if (window.outerWidth < 768) {
      nodes.forEach(node => {
        node.classList.remove('text-right');
      });
    } else {
      nodes.forEach(node => {
        node.classList.add('text-right');
      });
    }
  }

  radioSelected(value) {
    this.editUserAdminForm.controls.notification.setValue(value);

  }

  submit() {
    if (this.checkValidity()) {
      const data = this.editUserAdminForm.value || null;
      data.phone = data.phone && data.phone.toString();
      data.adminEmail = this.currentUser.username;
      if (!data.password) {
        data.password = null;
      }
      if (!data.reEnterPassword) {
        data.reEnterPassword = null;
      }
      this.generalService.updateUser(data).subscribe(res => {
        this.notificationService.showSuccess('User updated successfully.');
        this.router.navigateByUrl('/user/list');
      });
    }
  }
  checkValidity() {
    if (this.editUserAdminForm.invalid) {
      this.notificationService.showError('Please fill all mandatory fields correctly.');
      return false;
    } else {

      if (this.editUserAdminForm.controls.password) {
        if (this.editUserAdminForm.controls.reEnterPassword) {
          return true;
        } else {
          return false;
        }
      }
      return true;
    }

  }


  // custom validator to check that two fields match
  MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        // return if another validator has already found an error on the matchingControl
        return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }

  deleteUser() {

    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: 'Are you sure that you want to perform this action?',
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {
          const data: any = {
            adminEmail: this.currentUser.username,
            email: this.editUserAdminForm.value.email
          };
          this.generalService.deleteUser(data).subscribe(res => {
            this.notificationService.showSuccess('User deleted successfully.');
            this.router.navigateByUrl('/user/list');
          });
        }
      },
    });
  }

  onlyNumberKey(evt) {
    return this.utilityService.onlyNumberKey(evt);
  }

  getUserById() {
    this.generalService.getUserById(this.userId).subscribe(res => {
      this.userDetails = res.payload;
      this.patchForm();
    });
  }

}
