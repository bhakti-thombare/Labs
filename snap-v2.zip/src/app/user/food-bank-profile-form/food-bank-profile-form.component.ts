import { ChangeDetectorRef, Component, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { NotificationService } from 'src/app/core/services/notification.service';
import { Router, ActivatedRoute } from '@angular/router';
import { GeneralService } from '../shared/services/general.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { UtilityService } from 'src/app/core/services/utility.service';
import * as _ from 'lodash';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import * as moment from 'moment';
import { combineLatest, Subscription } from 'rxjs';
@Component({
  selector: 'app-food-bank-profile-form',
  templateUrl: './food-bank-profile-form.component.html',
  styleUrls: ['./food-bank-profile-form.component.scss']
})
export class FoodBankProfileFormComponent implements OnInit, OnDestroy {
  public lettersOnlyCustomPatterns = {'S': { pattern: new RegExp('\[a-zA-Z \]')}};
  public lettersAndNumbersCustomPatterns = {'A': { pattern: new RegExp('\[a-zA-Z0-9 \]')}};
  public numbersOnlycustomPatterns = {'0': { pattern: new RegExp('^[0-9 ]*$')}};
  truckList = [
    { index: 0, text: '15 truck', selected: false },
    { index: 1, text: '18 truck', selected: false },
    { index: 2, text: '20 truck', selected: false },
    { index: 3, text: '24 truck', selected: false },
    { index: 4, text: '48 trailer', selected: false },
    { index: 5, text: '53 trailer', selected: false },
    { index: 6, text: 'cube truck', selected: false },
    { index: 7, text: 'fork lift', selected: false },
    { index: 8, text: 'lift gate', selected: false },
    { index: 9, text: 'loading dock', selected: false },
    { index: 10, text: 'pallet jack', selected: false },
    { index: 11, text: 'van', selected: false },
    { index: 12, text: 'none of the above', selected: false }
  ];

  days = [
    { label: 'Monday', value: 'monday' },
    { label: 'Tuesday', value: 'tuesday' },
    { label: 'Wednesday', value: 'wednesday' },
    { label: 'Thursday', value: 'thursday' },
    { label: 'Friday', value: 'friday' },
    { label: 'Saturday', value: 'saturday' },
    { label: 'Sunday', value: 'sunday' },
  ];

  daysList = JSON.parse(JSON.stringify(this.days));

  startTime = [
    { label: '12:00 AM', value: 0 },
    { label: '12:30 AM', value: 30 },
    { label: '1:00 AM', value: 100 },
    { label: '1:30 AM', value: 130 },
    { label: '2:00 AM', value: 200 },
    { label: '2:30 AM', value: 230 },
    { label: '3:00 AM', value: 300 },
    { label: '3:30 AM', value: 330 },
    { label: '4:00 AM', value: 400 },
    { label: '4:30 AM', value: 430 },
    { label: '5:00 AM', value: 500 },
    { label: '5:30 AM', value: 530 },
    { label: '6:00 AM', value: 600 },
    { label: '6:30 AM', value: 630 },
    { label: '7:00 AM', value: 700 },
    { label: '7:30 AM', value: 730 },
    { label: '8:00 AM', value: 800 },
    { label: '8:30 AM', value: 830 },
    { label: '9:00 AM', value: 900 },
    { label: '9:30 AM', value: 930 },
    { label: '10:00 AM', value: 1000 },
    { label: '10:30 AM', value: 1030 },
    { label: '11:00 AM', value: 1100 },
    { label: '11:30 AM', value: 1130 },
    { label: '12:00 PM', value: 1200 },
    { label: '12:30 PM', value: 1230 },
    { label: '1:00 PM', value: 1300 },
    { label: '1:30 PM', value: 1330 },
    { label: '2:00 PM', value: 1400 },
    { label: '2:30 PM', value: 1430 },
    { label: '3:00 PM', value: 1500 },
    { label: '3:30 PM', value: 1530 },
    { label: '4:00 PM', value: 1600 },
    { label: '4:30 PM', value: 1630 },
    { label: '5:00 PM', value: 1700 },
    { label: '5:30 PM', value: 1730 },
    { label: '6:00 PM', value: 1800 },
    { label: '6:30 PM', value: 1830 },
    { label: '7:00 PM', value: 1900 },
    { label: '7:30 PM', value: 1930 },
    { label: '8:00 PM', value: 2000 },
    { label: '8:30 PM', value: 2030 },
    { label: '9:00 PM', value: 2100 },
    { label: '9:30 PM', value: 2130 },
    { label: '10:00 PM', value: 2200 },
    { label: '10:30 PM', value: 2230 },
    { label: '11:00 PM', value: 2300 },
    { label: '11:30 PM', value: 2330 }
  ];

  endTimeList = [
    { label: '12:00 AM', value: 0 },
    { label: '12:30 AM', value: 30 },
    { label: '1:00 AM', value: 100 },
    { label: '1:30 AM', value: 130 },
    { label: '2:00 AM', value: 200 },
    { label: '2:30 AM', value: 230 },
    { label: '3:00 AM', value: 300 },
    { label: '3:30 AM', value: 330 },
    { label: '4:00 AM', value: 400 },
    { label: '4:30 AM', value: 430 },
    { label: '5:00 AM', value: 500 },
    { label: '5:30 AM', value: 530 },
    { label: '6:00 AM', value: 600 },
    { label: '6:30 AM', value: 630 },
    { label: '7:00 AM', value: 700 },
    { label: '7:30 AM', value: 730 },
    { label: '8:00 AM', value: 800 },
    { label: '8:30 AM', value: 830 },
    { label: '9:00 AM', value: 900 },
    { label: '9:30 AM', value: 930 },
    { label: '10:00 AM', value: 1000 },
    { label: '10:30 AM', value: 1030 },
    { label: '11:00 AM', value: 1100 },
    { label: '11:30 AM', value: 1130 },
    { label: '12:00 PM', value: 1200 },
    { label: '12:30 PM', value: 1230 },
    { label: '1:00 PM', value: 1300 },
    { label: '1:30 PM', value: 1330 },
    { label: '2:00 PM', value: 1400 },
    { label: '2:30 PM', value: 1430 },
    { label: '3:00 PM', value: 1500 },
    { label: '3:30 PM', value: 1530 },
    { label: '4:00 PM', value: 1600 },
    { label: '4:30 PM', value: 1630 },
    { label: '5:00 PM', value: 1700 },
    { label: '5:30 PM', value: 1730 },
    { label: '6:00 PM', value: 1800 },
    { label: '6:30 PM', value: 1830 },
    { label: '7:00 PM', value: 1900 },
    { label: '7:30 PM', value: 1930 },
    { label: '8:00 PM', value: 2000 },
    { label: '8:30 PM', value: 2030 },
    { label: '9:00 PM', value: 2100 },
    { label: '9:30 PM', value: 2130 },
    { label: '10:00 PM', value: 2200 },
    { label: '10:30 PM', value: 2230 },
    { label: '11:00 PM', value: 2300 },
    { label: '11:30 PM', value: 2330 }
  ];
  endTime = [];
  selectedHoursOfOperation: any = {
    day: '',
    startTime: '',
    endTime: ''
  };
  hoursOfOperations: any[] = [];
  countries = this.utilityService.countries;
  foodBankForm: FormGroup;
  urlPattern = this.utilityService.urlPattern;
  emailPattern = this.utilityService.emailPattern;
  submitted = false;
  selectedTrucks = [];
  foodBankId;
  foodBankDetails: any = {};
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  deletedLocations = [];
  deletedTrucks = [];
  organizationTypes: any;
  parentHubs: any;
  status: any;
  selectedParentHub: any;
  selectedLocationIndex: any;
  modalRef: BsModalRef;
  zones: any;
  isStartTimeSelected = false;
  subscriptions: Subscription[] = [];
  messages: any;
  constructor(
    private cdRef: ChangeDetectorRef,
    private modalService: BsModalService,
    private utilityService: UtilityService,
    private activatedRoute: ActivatedRoute,
    private generalService: GeneralService,
    private router: Router,
    private notificationService: NotificationService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.foodBankDetails.locations = [];
    this.foodBankId = this.activatedRoute.snapshot.paramMap.get('id');
    this.buildFoodBankForm();
    this.getDropdownOptions();
    this.getFoodBanks();
    if (this.foodBankId) {
      this.getFoodBankDetails();
    }
  }

  handleFlag(formControl, event) {
    this.foodBankForm.get(formControl).setValue(event.target.checked);
  }


  getDropdownOptions() {
    this.generalService.getFoodBankDropdownOptions().subscribe(res => {
      const data = res.payload;
      this.organizationTypes = data['org-types'];
      this.status = data.status;
      this.zones = data.zones;
      // this.parentHubs = data['parent-hub'];
    });
  }

  getFoodBanks() {
    this.generalService.getFoodBanks({ pageNo: 0, pageSize: 1000, status: 'Active' }).subscribe(res => {
      this.parentHubs = this.foodBankId ?
        res.payload.foodBankList.filter(
          item => this.foodBankId && item.id.toString() !== this.foodBankId.toString()) : res.payload.foodBankList;
      if (!this.foodBankId) {
        this.setDefaultParentHub();
      }
    });
  }
  getFoodBankDetails() {
    this.generalService.getFoodBankDetails(this.foodBankId).subscribe(res => {
      const payload = res.payload;
      this.foodBankDetails = payload.orgProfile || undefined;
      if (this.foodBankDetails.locations && this.foodBankDetails.locations.length) {
        for (const element of this.foodBankDetails.locations) {
          element.hoursOfOperations = this.convertHoursOfOperation(element.hoursOfOperationReceiving);
        }
      }
      this.foodBankDetails.zone = payload.zone || undefined;
      this.foodBankDetails.name = payload.name || undefined;
      this.foodBankDetails.status = payload.status || undefined;
      this.patchFoodBankForm();
    });
  }

  patchFoodBankForm() {
    this.selectedParentHub = this.foodBankDetails.parentHub;
    const data = {
      name: this.foodBankDetails.name,
      shortName: this.foodBankDetails.shortName,
      organizationType: this.foodBankDetails.orgType,
      acceptShipments: this.foodBankDetails.acceptingShipment,
      // acceptStandingOrders: this.foodBankDetails.acceptingStandingOrders,
      parentHub: this.selectedParentHub && this.selectedParentHub.id || '',
      city: this.foodBankDetails.city,
      zone: this.foodBankDetails.zone,
      email: this.foodBankDetails.email,
      // website: this.foodBankDetails.website,
      status: this.foodBankDetails.status,
      hungerCount: this.foodBankDetails.hungerCount,
      receivingHours: this.foodBankDetails.receivingHours || '',
      comments: this.foodBankDetails.hungerComment,
      locations: [],
      dryStorageCapacity: this.foodBankDetails.dryStorageCapacity,
      chilledStorageCapacity: this.foodBankDetails.chilledStorageCapacity,
      frozenStorageCapacity: this.foodBankDetails.frozenStorageCapacity,
    };

    (this.foodBankForm.get('locations') as FormArray).clear();
    this.foodBankDetails.locations.forEach((location: any) => {
      (this.foodBankForm.get('locations') as FormArray).push(this.buildFoodBankLocationForm());
      data.locations.push({
        city: location.city,
        country: location.country,
        locationName: location.locationName,
        phone: location.phoneNumber,
        postalCode: location.postalCode,
        province: location.province,
        street: location.street,
        fax: location.fax,
        hoursOfOperations: location.hoursOfOperationReceiving
      });
    });
    this.foodBankForm.patchValue(data);


    this.selectChecklistOptions(this.foodBankDetails.transports);
  }

  formatTimeInString(time) {

    if (time.includes(':')) {
      const newtime = moment(new Date('Mon Nov 09 2020 ' + time)).format('hh:mm A');
      return newtime;
    } else {
      const newtime2 = moment(new Date('Mon Nov 09 2020 ' + this.formatTimeIn24Hr(time) + ':00:00')).format('hh:mm A');
      return newtime2;
    }

  }
  formatTimeIn24Hr(time) {
    const meridiem = time[time.length - 2] + time[time.length - 1];
    let num = +time.slice(0, -2);
    if (meridiem === 'PM') {
      num = num === 12 ? 12 : num + 12;
    }
    return num;
  }

  convertHoursOfOperation(hoursOfOperation) {

    const temp = [];
    for (const element of hoursOfOperation) {

      if (!element.deleted) {
        if (element.startTime.includes('AM') || element.startTime.includes('PM')) {
          temp.push({
            day: element.day,
            startTime: this.utilityService.convertToLocalTimeZone(new Date().setHours(element.startTime, 0, 0), 'LT'),
            endTime: this.utilityService.convertToLocalTimeZone(new Date().setHours(element.endTime, 0, 0), 'LT'),
            startTimeValue: element.startTimeValue,
            endTimeValue: element.endTimeValue
          });
        } else {
          const startHour = +element.startTime.split(':')[0];
          const startmin = +element.startTime.split(':')[1];
          const endHour = +element.endTime.split(':')[0];
          const endmin = +element.endTime.split(':')[1];
          temp.push({
            day: element.day,
            startTime: this.utilityService.convertToLocalTimeZone(new Date().setHours(startHour, startmin, 0), 'LT'),
            endTime: this.utilityService.convertToLocalTimeZone(new Date().setHours(endHour, endmin, 0), 'LT'),
            startTimeValue: +(startHour + '' + startmin),
            endTimeValue: +(endHour + '' + endmin)
          });
        }
      }
    }
    return temp;
  }


  buildFoodBankForm() {
    this.foodBankForm = this.formBuilder.group({
      name: ['', Validators.required],
      shortName: ['', Validators.required],
      organizationType: [null, Validators.required],
      acceptShipments: [false],
      // acceptStandingOrders: [false],
      parentHub: [null],
      city: ['', Validators.required],
      zone: ['', Validators.required],
      email: ['', [Validators.pattern(this.emailPattern), Validators.required]],
      // website: ['', Validators.pattern(this.urlPattern)],
      status: [null, Validators.required],
      hungerCount: ['', Validators.required],
      comments: [''],
      receivingHours: [''],
      locations: this.formBuilder.array([]),
      dryStorageCapacity: ['', Validators.required],
      chilledStorageCapacity: ['', Validators.required],
      frozenStorageCapacity: ['', Validators.required],
      checklist: []
    });

    if (localStorage.getItem('zone')) {
      this.foodBankForm.get('zone').setValue(localStorage.getItem('zone'));
    }
  }
  buildFoodBankLocationForm() {
    return this.formBuilder.group({
      locationName: ['', Validators.required],
      street: ['', Validators.required],
      city: ['', Validators.required],
      province: ['Ontario', Validators.required],
      postalCode: ['', Validators.required],
      country: ['Canada', Validators.required],
      phone: ['', Validators.required],
      fax: [''],
      locationContact: [''],
      contactEmail: [''],
      hoursOfOperations: [],
      delete: [false]
    });
  }
  addLocation(template?) {
    this.modifyDaysArray([]);
    if (this.foodBankForm.get('locations').value.length >= 3) {
      this.notificationService.showError('More than 3 locations cannot be added');
    } else {
      (this.foodBankForm.get('locations') as FormArray).push(this.buildFoodBankLocationForm());
      this.selectedLocationIndex = (this.foodBankForm.get('locations') as FormArray).length - 1;
      this.openLocationModal(template);
    }
  }

  editLocation(index, template) {
    this.selectedLocationIndex = index;



    console.log('this.foodBankDetails.locations[index].hoursOfOperations', this.foodBankDetails.locations[index].hoursOfOperations)
    this.modifyDaysArray(this.foodBankDetails.locations[index].hoursOfOperations);
    this.openLocationModal(template);
  }

  saveLocationData(i) {
    if (this.checkLocationValidity(i)) {
      if (this.checkReceivingHourValidity(i)) {
        this.selectedLocationIndex = i;
        const element = (this.foodBankForm.get('locations') as FormArray).at(this.selectedLocationIndex).value;


        if (this.foodBankDetails.locations[this.selectedLocationIndex]) {
          const data = this.foodBankDetails.locations[this.selectedLocationIndex];
          data.locationName = element.locationName;
          data.street = element.street;
          data.city = element.city;
          data.province = element.province;
          data.postalCode = element.postalCode;
          data.country = element.country;
          data.phoneNumber = element.phone;
          data.fax = element.fax;
          data.hoursOfOperations = element.hoursOfOperations || null;
          data.locationContact = parseInt(element.locationContact, 10) || null;
          data.contactEmail = element.contactEmail;
          data.delete = false;
        } else {
          this.foodBankDetails.locations.push({
            locationName: element.locationName,
            street: element.street,
            city: element.city,
            province: element.province,
            postalCode: element.postalCode,
            country: element.country,
            phoneNumber: element.phone,
            fax: element.fax,
            hoursOfOperations: element.hoursOfOperations || null,
            locationContact: parseInt(element.locationContact, 10) || null,
            contactEmail: element.contactEmail,
            delete: false
          });

        }
        this.patchFoodBankLocationForm();
        if (this.modalRef) {
          this.modalRef.hide();
        }
      }
    }
  }

  patchFoodBankLocationForm() {
    const data: any = {
      locations: []
    };
    (this.foodBankForm.get('locations') as FormArray).clear();
    this.foodBankDetails.locations.forEach((location: any) => {

      (this.foodBankForm.get('locations') as FormArray).push(this.buildFoodBankLocationForm());

      data.locations.push({
        city: location.city,
        country: location.country,
        locationName: location.locationName,
        phone: location.phoneNumber,
        postalCode: location.postalCode,
        province: location.province,
        street: location.street,
        locationContact: location.locationContact,
        contactEmail: location.contactEmail,
        hoursOfOperations: location.hoursOfOperations,
        fax: location.fax,
        delete: location.delete
      });
    });

    this.foodBankForm.get('locations').patchValue(data.locations);


  }


  checkLocationValidity(i) {
    const locationForm: FormGroup = ((this.foodBankForm.get('locations') as FormArray).at(i) as FormGroup);
    if (locationForm.invalid) {
      this.notificationService.showError('Please fill data in all fields.');
      return false;
    }
    return true;
  }

  openLocationModal(template: TemplateRef<any>) {
    const combine = combineLatest(
      this.modalService.onShow,
      this.modalService.onShown,
      this.modalService.onHide,
      this.modalService.onHidden
    ).subscribe(() => this.cdRef.markForCheck());

    this.subscriptions.push(
      this.modalService.onHide.subscribe((reason: string | any) => {

        this.closeModal('REMOVE_LOCATION');
        this.unsubscribe();
      })
    );


    this.subscriptions.push(combine);
    this.modalRef = this.modalService.show(template, { class: 'custom-width-modal', ignoreBackdropClick: true });
  }

  unsubscribe() {

    this.subscriptions.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
    this.subscriptions = [];
  }


  closeModal(value?) {


    if (value && value === 'REMOVE_HOUR') {
      this.days = [...this.daysList]
    }
    if (value && value === 'REMOVE_LOCATION') {
      this.patchLocations();
      this.selectedHoursOfOperation.day = '';
      this.selectedHoursOfOperation.startTime = '';
      this.selectedHoursOfOperation.endTime = '';
    }
    if (this.modalRef) {
      this.modalRef.hide();
    }
  }

  patchLocations() {
    const locations = [];
    let i = 0;
    (this.foodBankForm.get('locations') as FormArray).clear();
    for (const element of this.foodBankDetails.locations) {
      const locationData = {
        locationName: element.locationName,
        street: element.street,
        city: element.city,
        province: element.province,
        postalCode: element.postalCode,
        country: element.country,
        phone: element.phoneNumber,
        contactEmail: element.contactEmai || '',
        locationContact: element.locationContact || '',
        hoursOfOperations: element.hoursOfOperations || element.hoursOfOperationReceiving || [],
        fax: element.fax || '',
        delete: element.delete
      };
      (this.foodBankForm.get('locations') as FormArray).push(this.buildFoodBankLocationForm());

      (this.foodBankForm.get('locations') as FormArray).at(i).setValue(locationData);
      locations.push(locationData);
      i++;
    }
  }


  removeLocation(i) {
    const location = (this.foodBankForm.get('locations') as FormArray).at(i);
    this.deletedLocations.push({
      city: location.get('city').value,
      country: location.get('country').value,
      locationName: location.get('locationName').value,
      phoneNumber: location.get('phone').value,
      postalCode: location.get('postalCode').value,
      province: location.get('province').value,
      street: location.get('street').value,
      locationContact: location.get('locationContact').value,
      contactEmail: location.get('contactEmail').value,
      hoursOfOperations: location.get('hoursOfOperations').value,
      fax: location.get('fax').value,
      delete: true
    });
    this.foodBankDetails.locations.splice(i, 1);
    (this.foodBankForm.get('locations') as FormArray).removeAt(i);
  }

  getDeletedLocations(data) {
    const newData = data;
    if (this.deletedLocations.length) {
      newData.locations = newData.locations.concat(this.deletedLocations);
    }
    return newData;
  }
  submit() {
    this.submitted = true;
    if (this.checkValidity()) {
      if (true) {
        if (this.isChecklistSelected()) {



          const foodBankData = this.foodBankForm.value;
          let data: any = {
            name: foodBankData.name,
            shortName: foodBankData.shortName,
            orgType: foodBankData.organizationType,
            parentHub: foodBankData.parentHub,
            parentHubId: foodBankData.parentHub,
            parentId: foodBankData.parentHub,
            city: foodBankData.city,
            zone: foodBankData.zone,
            email: foodBankData.email,
            // website: foodBankData.website || '',
            status: foodBankData.status,
            hungerCount: foodBankData.hungerCount,
            hungerComment: foodBankData.comments,
            receivingHours: foodBankData.receivingHours || '',
            acceptingShipment: foodBankData.acceptShipments,
            // acceptingStandingOrders: foodBankData.acceptStandingOrders,
            locations: [],
            dryStorageCapacity: foodBankData.dryStorageCapacity,
            chilledStorageCapacity: foodBankData.chilledStorageCapacity,
            frozenStorageCapacity: foodBankData.frozenStorageCapacity,
            transports: []
          };

          foodBankData.locations.forEach((location: any) => {
            data.locations.push({
              city: location.city,
              country: location.country,
              locationName: location.locationName,
              phoneNumber: location.phone,
              postalCode: location.postalCode,
              province: location.province,
              hoursOfOperationReceiving: this.getHoursOfOperationForServer(this.convertHoursOfOperation(location.hoursOfOperations)),
              locationContact: location.locationContact,
              contactEmail: location.contactEmail,
              street: location.street,
              fax: location.fax,
              delete: false
            });
          });
          if (this.foodBankId) { data = this.getDeletedLocations(data); }

          data.transports = this.selectedTrucks;
          if (this.deletedTrucks.length) {
            data.transports = data.transports.concat(this.deletedTrucks);
          }

          if (!this.isLocationPresent()) {
            return;
          }
          if (!this.foodBankId) {
            this.generalService.createFoodBank(data).subscribe(res => {
              this.notificationService.showSuccess('Food bank profile is created successfully.');
              this.submitted = false;
              this.selectedTrucks = [];
              this.router.navigateByUrl('/user/food-bank/list');
            });
          }

          if (this.foodBankId) {
            this.generalService.updateFoodBank(data, this.foodBankId).subscribe(res => {
              this.notificationService.showSuccess('Food bank profile is updated successfully.');
              this.submitted = false;
              this.selectedTrucks = [];
              this.router.navigateByUrl('/user/food-bank/list');
            });
          }

        }
      }
    }

  }

  organizationTypeSelected(event) {

  }

  checkValidity() {

    if (this.foodBankForm.invalid) {
      if (this.foodBankForm.get('locations').invalid) {
        this.notificationService.showError('Please fill all fields in location form.');
        return false;
      }
      this.turnFormControlsDirty(this.foodBankForm);
      this.notificationService.showError('Please fill all mandatory fields with valid data.');
      return false;
    }
    return true;
  }

  isLocationPresent() {
    let deletedLoc = 0;
    let isHoursOfOperationPresent = true;
    if (this.foodBankForm.value.locations.length) {
      for (let location of this.foodBankForm.value.locations) {
        if (location.delete) {
          deletedLoc += 1;
        } else {

          if (!location.hoursOfOperations || !location.hoursOfOperations.length) {
            isHoursOfOperationPresent = false;
          }
        }
      }

      if (deletedLoc === this.foodBankForm.value.length) {

        this.notificationService.showError('Please add location');
        return false;
      }
      if (!isHoursOfOperationPresent) {
        this.notificationService.showError('Please add receiving hours of operation in location');
        return false;
      }
    } else {
      this.notificationService.showError('Please add location');
      return false;
    }
    return true;
  }

  turnFormControlsDirty(form: any) {
    this.utilityService.turnFormControlsDirty(form);
  }

  onlyNumberKey(evt, field, limit) {
    if (this.foodBankForm.get(field).value.length >= limit) {
      // debugger;
      this.notificationService.showError('Only ' + limit + ' characters Allowed.');
    }
    // return this.utilityService.onlyNumberKey(evt);
    if(this.utilityService.onlyNumberKey(evt)){
      return true;
    }
    else{
      this.notificationService.showError('Only numbers are allowed.');
      return false;
    }
  }


  selectChecklistOptions(checklist) {


    if (checklist && checklist.length) {
      this.truckList.forEach((element, i) => {


        element.selected = (checklist.findIndex(item => item.name === element.text) !== -1);

        if (element.selected) {
          this.selectedTrucks.push({
            name: this.truckList[i].text,
            deleted: false
          });
        }
      });

      this.selectedTrucks = _.uniqBy(this.selectedTrucks, 'name');


    }
  }
  checklistItemSelected(event, index) {

    this.cdRef.detectChanges();


    this.truckList[index].selected = event.target.checked;
    if (this.truckList[index].text === 'none of the above') {
      this.noneOptionSelected();
    } else {
      if (this.selectedTrucks.findIndex(item => item.name === 'none of the above') !== -1) {
        this.deselectNoneOption();
      }
    }
    if (this.truckList[index].selected) {
      this.selectedTrucks.push({
        name: this.truckList[index].text,
        deleted: false
      });
      const index2 = this.deletedTrucks.findIndex(item => item.name === this.truckList[index].text);
      if (index2 !== -1) { this.deletedTrucks.splice(index2, 1); }
    }
    if (!this.truckList[index].selected) {
      const index2 = this.selectedTrucks.findIndex(item => item.name === this.truckList[index].text);
      if (index2 !== -1) { this.selectedTrucks.splice(index2, 1); }
      this.deletedTrucks.push({
        name: this.truckList[index].text,
        deleted: true
      });
    }


    this.selectedTrucks = _.uniqBy(this.selectedTrucks, 'name');
    this.deletedTrucks = _.uniqBy(this.deletedTrucks, 'name');
    this.cdRef.detectChanges();
  }

  noneOptionSelected() {

    for (const element of this.selectedTrucks) {
      this.deletedTrucks.push({
        name: element.name,
        deleted: true
      });
    }
    this.selectedTrucks = [];
    this.truckList.forEach(element => {
      if (element.text !== 'none of the above') {
        element.selected = false;
      }
    });
    this.deletedTrucks = _.uniqBy(this.deletedTrucks, 'name');

    this.cdRef.detectChanges();
  }

  deselectNoneOption() {
    const selectedIndex = this.selectedTrucks.findIndex(item => item.name === 'none of the above');
    if (selectedIndex !== -1) {
      this.selectedTrucks.splice(selectedIndex, 1);
      this.deletedTrucks.push({
        name: 'none of the above',
        deleted: true
      });
    }
    const index = this.truckList.findIndex(item => item.text === 'none of the above');
    if (index !== -1) {
      this.truckList[index].selected = false;
    }
    this.cdRef.detectChanges();
  }

  isChecklistSelected() {
    if (!this.selectedTrucks.length) {
      this.notificationService.showError('Please select at least one option form checklist.');
      return false;
    }
    return true;
  }


  deleteFoodBank() {

    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'Cancel',
      confirmText: 'Delete',
      text: `Are you sure that you want to delete ${this.foodBankDetails.name || ''} food bank profile?`,
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {

          this.generalService.deleteFoodBank(this.foodBankId).subscribe(res => {
            this.notificationService.showSuccess('Food bank deleted successfully.');
            this.router.navigateByUrl('/user/food-bank/list');
          });
        }
      },
    });
  }

  dayChanged(event) {

  }

  endTimeChanged(event) {

  }

  startTimeChanged(event) {

    this.isStartTimeSelected = true;
    this.adjustEndTime(event.value);
  }

  adjustEndTime(selectedEndTime) {
    this.endTime = this.endTimeList.filter(item => item.value > selectedEndTime);
  }

  addHourOfOperation(template) {
    this.openLocationModal(template);

  }
  removeHourOfOperation(locationIndex, i) {
    console.log((this.foodBankForm.get('locations') as FormArray).at(locationIndex).get('hoursOfOperations').value[i]);
    (this.foodBankForm.get('locations') as FormArray).at(locationIndex).get('hoursOfOperations').value[i].deleted = true;

    this.selectedHoursOfOperation.day = '';
    this.selectedHoursOfOperation.startTime = '';
    this.selectedHoursOfOperation.endTime = '';
    this.modifyDaysArray((this.foodBankForm.get('locations') as FormArray).at(locationIndex).get('hoursOfOperations').value);
  }
  saveHourOfOperation(locationIndex) {
    if (this.selectedHoursOfOperation.day && this.selectedHoursOfOperation.startTime && this.selectedHoursOfOperation.endTime) {
      const hoursOfOperations = [...(this.foodBankForm.get('locations') as FormArray).at(locationIndex).get('hoursOfOperations').value || [], {
        day: this.selectedHoursOfOperation.day.value,
        startTime: this.selectedHoursOfOperation.startTime.label,
        startTimeValue: this.selectedHoursOfOperation.startTime.value,
        endTime: this.selectedHoursOfOperation.endTime.label,
        endTimeValue: this.selectedHoursOfOperation.endTime.value,
        deleted: false
      }];
      const index = this.days.findIndex(item => item === this.selectedHoursOfOperation.day);
      this.days.splice(index, 1);
      this.days = [...this.days];
      this.endTime = [...[]];
      this.isStartTimeSelected = false;

      (this.foodBankForm.get('locations') as FormArray).at(locationIndex).get('hoursOfOperations').setValue(hoursOfOperations);

      this.selectedHoursOfOperation.day = '';
      this.selectedHoursOfOperation.startTime = '';
      this.selectedHoursOfOperation.endTime = '';
    }
  }


  getHoursOfOperationForServer(arr) {
    const tempArr = [];
    for (const element of arr) {
      const startHour = this.getHour(element.startTimeValue.toString());
      const startMin = this.getMin(element.startTimeValue.toString());
      const endHour = this.getHour(element.endTimeValue.toString());
      const endMin = this.getMin(element.startTimeValue.toString());
      tempArr.push({
        day: element.day,
        startTime: moment(new Date().setHours(startHour, startMin, 0)).format('HH:mm:ss'),
        endTime: moment(new Date().setHours(endHour, endMin, 0)).format('HH:mm:ss'),
        deleted: element.deleted
      });
    }
    return tempArr;
  }

  getHour(value) {
    const newValue = value.length >= 3 ? (value.length === 3 ? value[0] : value.substring(0, 2)) : 0;
    return newValue.toString();
  }

  getMin(value) {
    const newValue = value.length >= 3 ? value.slice(-2) : (value.length === 2 ? value : 0);
    return newValue.toString();
  }

  checkReceivingHourValidity(i) {
    if (!(this.foodBankForm.get('locations') as FormArray).at(i).get('hoursOfOperations').value ||
      !((this.foodBankForm.get('locations') as FormArray).at(i).get('hoursOfOperations').value.length)) {
      this.notificationService.showError('Please fill in receiving hours and day and click on plus button to add it.');
      return false;
    }
    let deletedCount = 0;
    for (const element of (this.foodBankForm.get('locations') as FormArray).at(i).get('hoursOfOperations').value) {
      if (element.deleted) {
        deletedCount += 1;
      }
    }
    if (deletedCount === (this.foodBankForm.get('locations') as FormArray)
      .at(i)
      .get('hoursOfOperations').value.length) {
      this.notificationService.showError('Please add receiving hours and day.');
      return false;
    }
    return true;
  }

  modifyDaysArray(operations) {
    operations = operations === undefined ? [] : (operations.length ? operations : this.daysList);
    // if (operations.length === 7) {
    //   this.days = [...operations];
    //   return;
    // }
    const days = [];
    for (const element of operations) {
      if (!element.deleted) {
        console.log('pushing element', element)
        days.push(element.day);
      }
    }
    console.log('days', days)
    console.log('this.daysList', this.daysList)
    const updatedDays = this.daysList
      .filter(item => !days.includes(item.value));
    this.days = [...updatedDays];
    console.log('updatedDays', updatedDays);
  }

  setDefaultParentHub() {
    const defaultParent = this.parentHubs.filter(item => item.name.toString().toLowerCase().trim() === 'feed ontario');
    if (defaultParent && defaultParent[0]) {
      this.selectedParentHub = defaultParent[0];
      this.foodBankForm.get('parentHub').setValue(this.selectedParentHub.id);
    }
  }

  ngOnDestroy() {
    if (localStorage.getItem('zone')) {
      localStorage.removeItem('zone');
    }
  }

  numbersAndLettersOnly(event, field?, limit?) {
    if (field && field === 'comments') {
      if (this.foodBankForm.get(field).value.length >= limit) {
        // debugger;
        this.notificationService.showError('Only ' + limit + ' characters allowed.');
      }
    }
    if (this.utilityService.onlyNumberKey(event) || this.utilityService.lettersOnly(event)) {
      return true;
    } else {
      this.notificationService.showError('Only numbers and letters are allowed.');
      return false;
    }
  }

  isCharLengthValid(value, limit, event?) {
    if (value && value.toString().length >= limit) {
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
    if (event) {
      if (this.utilityService.onlyNumberKey(event) || this.utilityService.lettersOnly(event)) {
        return true;
      } else {
        this.notificationService.showError('Only numbers and letters are allowed.');
        return false;
      }
    }
  } 
  
  lettersOnly(event, field, limit) {
    if (this.foodBankForm.get(field).value.length >= limit) {
      // debugger;
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
    // return this.utilityService.lettersOnly(event);
    if(this.utilityService.lettersOnly(event)){
      return true;
    }
    else{
      this.notificationService.showError('Only letters are allowed.');
      return false;
    }
  }

}
