import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-import-form',
  templateUrl: './user-import-form.component.html',
  styleUrls: ['./user-import-form.component.scss']
})
export class UserImportFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
