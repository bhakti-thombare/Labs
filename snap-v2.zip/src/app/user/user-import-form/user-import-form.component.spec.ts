import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserImportFormComponent } from './user-import-form.component';

describe('UserImportFormComponent', () => {
  let component: UserImportFormComponent;
  let fixture: ComponentFixture<UserImportFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserImportFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserImportFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
