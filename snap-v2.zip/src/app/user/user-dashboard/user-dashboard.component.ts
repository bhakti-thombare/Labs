import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.scss']
})
export class UserDashboardComponent implements OnInit, OnDestroy {
  selectedTab: string;
  currentUser: any;
  selectedUserData: any;
  subscription: Subscription;
  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private authService: AuthService
  ) {
    this.authService.currentUser$.subscribe(user => {
      if (user) {
        this.currentUser = user;
        if (this.currentUser && this.currentUser.role.toString().toLowerCase() !== 'admin') {
          this.userOptions = [
            { title: 'Edit', url: '/user/edit/12', selected: true },
          ];
        }
      }
    });
    this.subscription = router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.modifyUserTabs();
    });
  }
  userOptions = [
    { title: 'List', url: '/user/list', selected: false },
    { title: 'New', url: '/user/new', selected: false },
    { title: 'Edit', url: '/user/edit/12', selected: true },
  ];
  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      if (user) {
        this.currentUser = user;
        if (this.currentUser && this.currentUser.role.toString().toLowerCase() !== 'admin') {
          this.userOptions = [
            { title: 'Edit', url: '/user/edit/12', selected: true },
          ];
        }
      }
    });

  }

  modifyUserTabs() {

    const userId = this.activatedRoute.firstChild.snapshot.paramMap.get('id');
    if (this.currentUser && this.currentUser.role.toString().toLowerCase() === 'admin') {

      // food bank users
      if (!userId) {
        this.userOptions = [
          { title: 'List', url: '/user/list', selected: false },
          { title: 'New', url: '/user/new', selected: false }
        ];
      } else {
        this.userOptions = [
          { title: 'List', url: '/user/list', selected: false },
          { title: 'New', url: '/user/new', selected: false },
          { title: 'Edit', url: '/user/edit/' + userId, selected: true }
        ];
      }

      // donor profile
      if (this.router.url.includes('donor')) {

        if (!userId) {
          this.userOptions = [
            { title: 'List', url: '/user/donor/list', selected: false },
            { title: 'New', url: '/user/donor/new', selected: false }
          ];
        } else {
          this.userOptions = [
            { title: 'List', url: '/user/donor/list', selected: false },
            { title: 'New', url: '/user/donor/new', selected: false },
            // { title: 'View', url: '/user/donor/view/' + userId, selected: false },
            // { title: 'Donations', url: '/user/donor/donations/' + userId, selected: false },
            { title: 'Edit', url: '/user/donor/edit/' + userId, selected: false }
          ];
        }

      }
      if (this.router.url.includes('food-bank')) {
        if (!userId) {
          this.userOptions = [
            { title: 'List', url: '/user/food-bank/list', selected: false },
            { title: 'New', url: '/user/food-bank/new', selected: false }
          ];
        } else {
          this.userOptions = [
            { title: 'List', url: '/user/food-bank/list', selected: false },
            { title: 'New', url: '/user/food-bank/new', selected: false },
            { title: 'View', url: '/user/food-bank/view/' + userId, selected: false },
            // { title: 'Offers', url: '/user/food-bank/offers/' + userId, selected: false },
            { title: 'Edit', url: '/user/food-bank/edit/' + userId, selected: false }
          ];
        }

      }
    } else {
      this.userOptions = [
        { title: 'Edit', url: '/user/account/edit/' + userId, selected: true },
      ];
    }
    this.tabSelected(this.router.url);
  }

  tabSelected(url) {
    for (const option of this.userOptions) {
      if (url.includes(option.url) || option.url.includes(url)) {
        this.selectedTab = this.getHeader(option.title, url);
        option.selected = true;
        this.router.navigateByUrl(url);
      } else {
        option.selected = false;
      }
    }
  }
  getHeader(option, url) {
    option = option.toString().toLowerCase();
    let entity = 'user';
    if (url.includes('/user/donor/')) {
      entity = 'donor';
    }
    if (url.includes('/user/food-bank/')) {
      entity = 'food bank';
    }
    switch (option) {
      case 'list':
        return entity + 's';
      case 'new':
        return 'Create new ' + entity;
      case 'edit':
        return 'Edit ' + entity;
      case 'view':
        return entity + ' details';
      case 'shipment confirmation':
        return 'Shipment confirmation';
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
