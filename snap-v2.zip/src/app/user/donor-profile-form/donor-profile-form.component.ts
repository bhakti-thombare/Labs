import { ChangeDetectorRef, Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GeneralService } from '../shared/services/general.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { UtilityService } from 'src/app/core/services/utility.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { combineLatest, Subscription } from 'rxjs';
@Component({
  selector: 'app-donor-profile-form',
  templateUrl: './donor-profile-form.component.html',
  styleUrls: ['./donor-profile-form.component.scss']
})
export class DonorProfileFormComponent implements OnInit {
  public lettersOnlyCustomPatterns = { 'S': { pattern: new RegExp('\[a-zA-Z \]') } };
  public lettersAndNumbersCustomPatterns = { 'A': { pattern: new RegExp('\[a-zA-Z0-9 \]') } };

  donorForm: FormGroup;
  donorContactForm: FormGroup;
  donorLocationForm: FormGroup;
  countries = this.utilityService.countries;
  donorId: string;
  emailPattern = this.utilityService.emailPattern;
  currentUser: any;
  contactMustUniqueEmail = false;
  primaryEmail: string;
  donorDetails = {
    id: null,
    name: '',
    comments: '',
    contactInformation: [],
    locations: []
  };
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  isEdit = false;
  deletedContacts = [];
  deletedLocations = [];
  patchData: { name: any; comments: any; contacts: any[]; locations: any[]; };
  selectedContactIndex: any;
  modalRef: BsModalRef;
  selectedLocationIndex: any;
  messages: any;
  subscriptions: Subscription[] = [];
  constructor(
    private changeDetection: ChangeDetectorRef,
    private modalService: BsModalService,
    private utilityService: UtilityService,
    private router: Router,
    private authService: AuthService,
    private generalService: GeneralService,
    private activatedRoute: ActivatedRoute,
    private notificationService: NotificationService,
    private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.loadUser();
    this.primaryEmail = this.activatedRoute.snapshot.paramMap.get('id');
    this.buildDonorForm();
    if (this.primaryEmail) {
      this.isEdit = true;
      const data = {
        primaryEmail: this.primaryEmail,
        adminEmail: this.currentUser.username
      };
      this.getDonorDetails(data);
    }
  }

  getDonorDetails(data) {
    this.generalService.getDonorDetails(data).subscribe(res => {

      this.donorDetails = res;
      this.patchDonorForm();
    });
  }

  patchDonorForm() {
    this.patchData = {
      name: this.isEdit ? this.donorDetails.name : this.donorForm.value.name,
      comments: this.isEdit ? this.donorDetails.comments : this.donorForm.value.comments,
      contacts: [],
      locations: []
    };
    (this.donorForm.get('contacts') as FormArray).clear();
    let i = 0;
    for (const element of this.donorDetails.contactInformation) {
      const contactData = {
        name: element.name,
        email: element.email,
        phone: element.phoneNumber,
        primary: element.primary,
        delete: false
      };
      (this.donorForm.get('contacts') as FormArray).push(this.buildDonorContactForm(element.primary));
      (this.donorForm.get('contacts') as FormArray).at(i).setValue(contactData);

      this.patchData.contacts.push(contactData);
      i++;
    }

    (this.donorForm.get('locations') as FormArray).clear();
    for (const element of this.donorDetails.locations) {
      (this.donorForm.get('locations') as FormArray).push(this.buildDonorLocationForm());
      const locationData = {
        locationName: element.locationName,
        street: element.street,
        city: element.city,
        province: element.province,
        postalCode: element.postalCode,
        country: element.country,
        phone: element.phoneNumber,
        // hoursOfOperation: element.hoursOfOperation || null,
        // locationContact: parseInt(element.locationContact, 10) || null,
        // contactEmail: element.contactEmail,
        delete: element.delete
      };
      this.patchData.locations.push(locationData);
    }

    this.donorForm.patchValue(this.patchData);

  }
  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }


  patchContacts() {
    (this.donorForm.get('contacts') as FormArray).clear();
    let i = 0;
    const contacts = [];
    for (const element of this.donorDetails.contactInformation) {
      const contactData = {
        name: element.name,
        email: element.email,
        phone: element.phoneNumber,
        primary: element.primary,
        delete: false
      };
      (this.donorForm.get('contacts') as FormArray).push(this.buildDonorContactForm(element.primary));
      (this.donorForm.get('contacts') as FormArray).at(i).setValue(contactData);

      contacts.push(contactData);
      i++;
    }
  }

  patchLocations() {
    const locations = [];
    let i = 0;
    (this.donorForm.get('locations') as FormArray).clear();
    for (const element of this.donorDetails.locations) {
      const locationData = {
        locationName: element.locationName,
        street: element.street,
        city: element.city,
        province: element.province,
        postalCode: element.postalCode,
        country: element.country,
        phone: element.phoneNumber,
        // hoursOfOperation: element.hoursOfOperation || null,
        // locationContact: parseInt(element.locationContact, 10) || null,
        // contactEmail: element.contactEmail,
        delete: element.delete
      };
      (this.donorForm.get('locations') as FormArray).push(this.buildDonorLocationForm());
      (this.donorForm.get('locations') as FormArray).at(i).setValue(locationData);
      locations.push(locationData);
      i++;
    }
  }
  buildDonorForm() {
    this.donorId = this.activatedRoute.snapshot.paramMap.get('id');
    this.donorForm = this.formBuilder.group({
      name: ['', Validators.required],
      comments: [''],
      contacts: this.formBuilder.array([this.buildDonorContactForm(false)]),
      locations: this.formBuilder.array([this.buildDonorLocationForm()])
    });

    this.donorForm.get('contacts').valueChanges.subscribe(contacts => {
      if (contacts.length > 1) {
        if (this.donorForm.get('contacts').valid) {

          if (this.isEmailUnique(contacts)) {
            this.contactMustUniqueEmail = false;
          } else {
            this.contactMustUniqueEmail = true;
          }
        }
      }

    });
  }
  isEmailUnique(arr) {
    const tmpArr = [];
    for (const obj in arr) {

      if (tmpArr.indexOf(arr[obj].email) < 0) {
        tmpArr.push(arr[obj].email);
      } else {
        return false;
      }

    }
    return true;
  }

  buildDonorContactForm(disable) {
    return this.formBuilder.group({
      name: ['', Validators.required],
      phone: ['', Validators.required],
      email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      primary: [false],
      delete: [false]
    });
  }
  buildDonorLocationForm() {
    return this.formBuilder.group({
      locationName: ['', Validators.required],
      street: ['', Validators.required],
      city: ['', Validators.required],
      province: ['Ontario', Validators.required],
      postalCode: ['', Validators.required],
      country: ['Canada', Validators.required],
      phone: ['', Validators.required],
      // hoursOfOperation: ['', Validators.required],
      // locationContact: ['', Validators.required],
      // contactEmail: ['', [Validators.pattern(this.emailPattern), Validators.required]],
      delete: [false]
    });
  }

  addContact(template) {
    if (this.donorDetails.contactInformation.length >= 3) {
      this.notificationService.showError('More than 3 contacts cannot be added.');
    } else {
      (this.donorForm.get('contacts') as FormArray).push(this.buildDonorContactForm(false));
      this.selectedContactIndex = (this.donorForm.get('contacts') as FormArray).length - 1;
      this.openContactModal(template);
    }
  }

  saveContactData(i) {
    if (this.checkContactValidity(i)) {
      this.selectedContactIndex = i;
      const element = (this.donorForm.get('contacts') as FormArray).at(this.selectedContactIndex).value;

      if (this.donorDetails.contactInformation[this.selectedContactIndex]) {
        const data = this.donorDetails.contactInformation[this.selectedContactIndex];
        data.name = element.name;
        data.phoneNumber = element.phone;
        data.email = element.email;
        data.primary = element.primary;
        data.isDeleted = false;
      } else {
        this.donorDetails.contactInformation.push({
          name: element.name,
          phoneNumber: element.phone,
          email: element.email,
          primary: element.primary,
          isDeleted: false
        });

      }
      // !this.isEdit && 
      if (element.primary) {
        this.primaryContactFlagChanged({ target: { checked: element.primary } }, i);
      }
      this.patchContacts();
      this.modalRef.hide();
    }
  }

  editContact(index, template) {
    this.selectedContactIndex = index;

    this.openContactModal(template);
  }

  openContactModal(template: TemplateRef<any>) {
    this.modalCloseHandler('REMOVE_CONTACT');
    this.modalRef = this.modalService.show(template, { ignoreBackdropClick: true });
  }


  modalCloseHandler(value) {
    const combine = combineLatest(
      this.modalService.onShow,
      this.modalService.onShown,
      this.modalService.onHide,
      this.modalService.onHidden
    ).subscribe(() => this.changeDetection.markForCheck());

    this.subscriptions.push(
      this.modalService.onHide.subscribe((reason: string | any) => {

        this.closeModal(value);
        this.unsubscribe();
      })
    );
    this.subscriptions.push(combine);

  }

  unsubscribe() {

    this.subscriptions.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
    this.subscriptions = [];
  }

  closeModal(value?) {
    if (value === 'REMOVE_CONTACT') {
      this.patchContacts();
    }
    if (value === 'REMOVE_LOCATION') {
      this.patchLocations();
    }
    if (this.modalRef) {
      this.modalRef.hide();
    }
  }

  removeContact(i) {
    const contact: any = (this.donorForm.get('contacts') as FormArray).at(i);
    this.deletedContacts.push(
      {
        name: contact.get('name').value,
        phoneNumber: contact.get('phone').value,
        email: contact.get('email').value,
        primary: false,
        isDeleted: true
      }
    );
    this.donorDetails.contactInformation.splice(i, 1);
    (this.donorForm.get('contacts') as FormArray).removeAt(i);
  }

  addLocation(template) {
    if (this.donorDetails.locations.length >= 3) {
      this.notificationService.showError('More than 3 locations cannot be added');
    } else {
      (this.donorForm.get('locations') as FormArray).push(this.buildDonorLocationForm());
      this.selectedLocationIndex = (this.donorForm.get('locations') as FormArray).length - 1;
      this.openLocationModal(template);
    }
  }

  editLocation(index, template) {
    this.selectedLocationIndex = index;

    this.openLocationModal(template);
  }

  openLocationModal(template: TemplateRef<any>) {
    this.modalCloseHandler('REMOVE_LOCATION');
    this.modalRef = this.modalService.show(template, { ignoreBackdropClick: true });
  }

  saveLocationData(i) {
    if (this.checkLocationValidity(i)) {
      this.selectedLocationIndex = i;
      const element = (this.donorForm.get('locations') as FormArray).at(this.selectedLocationIndex).value;
      if (this.donorDetails.locations[this.selectedLocationIndex]) {
        const data = this.donorDetails.locations[this.selectedLocationIndex];
        data.locationName = element.locationName;
        data.street = element.street;
        data.city = element.city;
        data.province = element.province;
        data.postalCode = element.postalCode;
        data.country = element.country;
        data.phoneNumber = element.phone;
        // data.hoursOfOperation = element.hoursOfOperation || null;
        // data.locationContact = parseInt(element.locationContact, 10) || null;
        // data.contactEmail = element.contactEmail;
        data.isDelete = false;
        data.delete = false;

      } else {
        this.donorDetails.locations.push({
          locationName: element.locationName,
          street: element.street,
          city: element.city,
          province: element.province,
          postalCode: element.postalCode,
          country: element.country,
          phoneNumber: element.phone,
          // hoursOfOperation: element.hoursOfOperation || null,
          // locationContact: parseInt(element.locationContact, 10) || null,
          // contactEmail: element.contactEmail,
          isDelete: false,
          delete: false
        });

      }
      this.patchLocations();
      this.modalRef.hide();
    }
  }
  removeLocation(i) {
    const location: any = (this.donorForm.get('locations') as FormArray).at(i);
    this.deletedLocations.push({
      locationName: location.get('locationName').value,
      street: location.get('street').value,
      city: location.get('city').value,
      province: location.get('province').value,
      postalCode: location.get('postalCode').value,
      country: location.get('country').value,
      phoneNumber: location.get('phone').value,
      // hoursOfOperation: location.get('hoursOfOperation').value || null,
      // locationContact: parseInt(location.get('locationContact').value, 10),
      // contactEmail: location.get('contactEmail').value,
      isDelete: true,
      delete: true
    });
    this.donorDetails.locations.splice(i, 1);
    (this.donorForm.get('locations') as FormArray).removeAt(i);
  }

  locationDeleteFlagChanged(event, locationIndex) {

    (this.donorForm.get('locations') as FormArray)
      .at(locationIndex)
      .get('delete').setValue(event.target.checked);
  }
  contactDeleteFlagChanged(event, contactIndex) {

    (this.donorForm.get('contacts') as FormArray)
      .at(contactIndex)
      .get('delete').setValue(event.target.checked);
  }

  primaryContactFlagSelected(event, contactIndex) {
    (this.donorForm.get('contacts') as FormArray)
      .at(contactIndex)
      .get('primary').setValue(event.target.checked);
  }

  primaryContactFlagChanged(event, contactIndex) {

    contactIndex = this.selectedContactIndex;
    if (event.target.checked) {
      (this.donorForm.get('contacts') as FormArray)
        .at(contactIndex)
        .get('primary').setValue(event.target.checked);
      if (this.donorDetails.contactInformation.length && this.donorDetails.contactInformation[contactIndex]) {

        this.donorDetails.contactInformation[contactIndex].primary = event.target.checked;
      }
      for (const [i, contactForm] of ((this.donorForm.get('contacts') as FormArray).controls).entries()) {
        if (contactIndex !== i) {
          contactForm.get('primary').setValue(false);
          if (this.donorDetails.contactInformation.length && this.donorDetails.contactInformation[contactIndex]) {
            this.donorDetails.contactInformation[i].primary = false;
          }
        }
      }
    } else {
      let i = 0;
      for (const contactForm of (this.donorForm.get('contacts') as FormArray).controls) {
        contactForm.get('primary').setValue(false);
        if (this.donorDetails.contactInformation.length && this.donorDetails.contactInformation[contactIndex]) {
          this.donorDetails.contactInformation[i].primary = false;
        }
        i++;
      }
    }

  }

  submit() {
    if (this.checkValidity()) {
      const donorData = this.isEdit ? this.donorForm.getRawValue() : this.donorForm.value;

      let data: any = {

        adminEmail: this.currentUser.username,
        name: donorData.name,
        comments: donorData.comments,
        contactInformation: [],
        locations: []
      };
      donorData.contacts.forEach((element: any) => {
        if (element.primary) {
          data.primaryEmail = element.email;
        }
        data.contactInformation.push({
          name: element.name,
          phoneNumber: element.phone,
          email: element.email,
          primary: element.primary,
          isDeleted: false
        });
      });

      donorData.locations.forEach((element: any) => {
        data.locations.push({
          locationName: element.locationName,
          street: element.street,
          city: element.city,
          province: element.province,
          postalCode: element.postalCode,
          country: element.country,
          phoneNumber: element.phone,
          // hoursOfOperation: element.hoursOfOperation || null,
          // locationContact: parseInt(element.locationContact, 10) || null,
          // contactEmail: element.contactEmail,
          isDelete: false
        });
      });
      data = this.getDeletedContacts(data);
      data = this.getDeletedLocations(data);

      if (!this.primaryEmail) {
        this.generalService.createDonor(data).subscribe(res => {
          this.notificationService.showSuccess('Donor created successfully.');
          this.router.navigateByUrl('/user/donor/list');
        });
      }
      if (this.primaryEmail) {
        data.id = this.donorDetails.id;
        this.generalService.updateDonor(data).subscribe(res => {
          this.notificationService.showSuccess('Donor updated successfully.');
          this.router.navigateByUrl('/user/donor/list');
        });
      }
    }
  }

  getDeletedContacts(data) {
    const newData = data;
    if (this.deletedContacts.length) {
      newData.contactInformation = newData.contactInformation.concat(this.deletedContacts);
    }
    return newData;
  }

  getDeletedLocations(data) {
    const newData = data;
    if (this.deletedLocations.length) {
      newData.locations = newData.locations.concat(this.deletedLocations);
    }
    return newData;
  }

  checkValidity() {
    console.log('this.donorForm', this.donorForm)
    if (this.donorForm.get('name').value) {

      const index = this.donorForm.get('contacts').value.findIndex(item => item.primary === true);

      if (!this.donorDetails.contactInformation || !this.donorDetails.contactInformation.length) {
        this.notificationService.showError('Please add at least one contact.');
        return false;
      }

      if (!this.donorDetails.locations || !this.donorDetails.locations.length) {
        this.notificationService.showError('Please add at least one location.');
        return false;
      }
      if (index === -1) {
        this.notificationService.showError('Please select a primary contact.');
        return false;
      }
      if (this.contactMustUniqueEmail) {
        this.notificationService.showError('Please make sure emails are unique accross all then contacts');
        return false;
      }


      return true;
    } else {
      this.turnFormControlsDirty(this.donorForm);
      this.notificationService.showError('Please fill in the mandatory fields with valid data.');
      return false;
    }
  }
  checkLocationValidity(i) {
    const locationForm: FormGroup = ((this.donorForm.get('locations') as FormArray).at(i) as FormGroup);
    let isDataPresent = false;
    if (locationForm.invalid) {
      this.turnFormControlsDirty(locationForm);
      this.notificationService.showError('Please fill in the mandatory fields with valid data.');
      return false;
    }
    // for (const key in locationForm.value) {
    //   if (locationForm.value[key] && locationForm.value[key].toString().trim()) {
    //     isDataPresent = true;
    //     break;
    //   }
    // }

    // if (!isDataPresent) {
    //   this.notificationService.showError('Please fill at least one field');
    //   return false;
    // }

    // if (locationForm.get('contactEmail').value && locationForm.get('contactEmail').invalid) {
    //   this.notificationService.showError('Please fill in the fields with valid data.');
    //   return false;
    // }
    return true;
  }

  checkContactValidity(i) {
    const contactForm: FormGroup = ((this.donorForm.get('contacts') as FormArray).at(i) as FormGroup);
    if (contactForm.invalid) {
      this.turnFormControlsDirty(contactForm);
      this.notificationService.showError('Please fill in the mandatory fields with valid data.');
      return false;
    }
    if (this.contactMustUniqueEmail) {
      this.notificationService.showError('Please make sure emails are unique accross all then contacts');
      return false;
    }
    return true;
  }

  turnFormControlsDirty(form: any) {
    this.utilityService.turnFormControlsDirty(form);
  }


  onlyNumberKey(evt) {
    return this.utilityService.onlyNumberKey(evt);
  }


  deleteDonor() {

    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'Cancel',
      confirmText: 'Delete',
      text: `Are you sure that you want to delete ${this.donorDetails.name} donor profile?`,
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {
          const data: any = {
            adminEmail: this.currentUser.username,
            primaryEmail: this.primaryEmail
          };

          this.generalService.deleteDonor(data).subscribe(res => {
            this.notificationService.showSuccess('Donor deleted successfully.');
            this.router.navigateByUrl('/user/donor/list');
          });
        }
      },
    });
  }

  sendEmail() {
    this.generalService.sendEmail({
      primaryEmail: this.primaryEmail,
      adminEmail: this.currentUser.username
    }).subscribe(res => {
      this.notificationService.showSuccess('Email sent successfully.');
    });
  }

  allowOnlyFloat(txt, event) {
    return this.utilityService.allowOnlyFloat(txt, event);
  }

  lettersOnly(event, field, limit) {
    if (this.donorForm.get(field).value.length >= limit) {
      // debugger;
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
    // return this.utilityService.lettersOnly(event);
    if (this.utilityService.lettersOnly(event)) {
      return true;
    }
    else {
      this.notificationService.showError('Only letters are allowed.');
      return false;
    }
  }

  numbersAndLettersOnly(event, field?, limit?) {
    if (field && field === 'comments') {
      if (this.donorForm.get(field).value.length >= limit) {
        // debugger;
        this.notificationService.showError('Only ' + limit + ' characters allowed.');
      }
    }
    if (this.utilityService.onlyNumberKey(event) || this.utilityService.lettersOnly(event)) {
      return true;
    } else {
      this.notificationService.showError('Only numbers and letters are allowed.');
      return false;
    }
  }

  isCharLengthValid(value, limit, event?) {
    if (value && value.toString().length >= limit) {
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
    if (event) {
      if (this.utilityService.onlyNumberKey(event) || this.utilityService.lettersOnly(event)) {
        return true;
      } else {
        this.notificationService.showError('Only numbers and letters are allowed.');
        return false;
      }
    }
  }

}

