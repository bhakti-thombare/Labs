import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-food-bank-profile-details',
  templateUrl: './food-bank-profile-details.component.html',
  styleUrls: ['./food-bank-profile-details.component.scss']
})
export class FoodBankProfileDetailsComponent implements OnInit {

  foodBankId: any;
  foodBankDetails: any;
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  currentUser: any;

  constructor(
    private router: Router,
    private generalService: GeneralService,
    private activatedRoute: ActivatedRoute,
    private notificationService: NotificationService,
    private authService: AuthService
  ) { }

  ngOnInit() {
    this.loadUser();
    this.foodBankId = this.activatedRoute.snapshot.paramMap.get('id');
    this.getFoodBankDetails();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  getFoodBankDetails() {
    this.generalService.getFoodBankDetailsForView(this.foodBankId).subscribe(res => {
      this.foodBankDetails = res.payload;
    });

  }



  deleteUser(user) {

    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: 'Are you sure that you want to perform this action?',
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {
          const data: any = {
            adminEmail: this.currentUser.username,
            email: user.email
          };
          this.generalService.deleteUser(data).subscribe(res => {
            this.notificationService.showSuccess('User deleted successfully.');
            this.getFoodBankDetails();
          });
        }
      },
    });
  }

  navigateTo() {
    const queryParams = {
      role: 'food_bank',
      foodBank: this.foodBankId
    }
    localStorage.setItem('new_org_member', JSON.stringify(queryParams));
    // window.location.href = '/user/new?role=foodbank';
    this.router.navigateByUrl('/user/new');
  }
}
