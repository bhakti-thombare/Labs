
import { Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class ErrorService {

    getClientMessage(error: Error): string {
        if (!navigator.onLine) {
            return 'No Internet Connection';
        }
        return error.message ? error.message : error.toString();
    }

    getClientStack(error: Error): string {
        return error.stack;
    }

    getServerMessage(httpError: HttpErrorResponse): string {
        if (httpError.status === 0) {
            return 'Something went, please try again';
        }
        if (httpError.error && httpError.error.errors && httpError.error.errors.message) {
            return httpError.error.errors.message;
        }
        return 'Something went wrong';
    }

    getServerStack(error: HttpErrorResponse): string {
        // handle stack trace
        return error.message;
    }
}
