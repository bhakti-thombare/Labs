import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataSharingService {

  // user module data
  selectedUserData: any;

  directOfferReviewData: any;

  constructor() { }
}
