import { Injectable } from '@angular/core';
import { ReplaySubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Cookie } from './cookie';
import { NotificationService } from './notification.service';
import { CookieService } from 'ngx-cookie-service';
import { take } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private currentUser: ReplaySubject<any> = new ReplaySubject<any>(undefined);
  private accessToken: ReplaySubject<string> = new ReplaySubject(1);
  private loggedIn: ReplaySubject<boolean> = new ReplaySubject(1);

  /**
   * Current user
   *
   */
  currentUser$: Observable<any> = this.currentUser.asObservable();

  /**
   * Token for current user
   */
  accessToken$: Observable<any> = this.accessToken.asObservable();

  /**
   * Current logged in status
   */
  loggedIn$: Observable<boolean> = this.loggedIn.asObservable();

  baseApi = environment.baseUrl || '';
  production = environment.production || false;

  /**
   * Base host of app
   */
  public baseHost(): string {
    return window.location.hostname;
  }

  constructor(
    private cookieService: CookieService,
    private http: HttpClient,
    public router: Router,
    private notificationService: NotificationService
  ) {
    this.init();
  }

  init() {
    const accessToken = Cookie.get('accessToken');
    if (accessToken) {
      this.accessToken.next(accessToken);
      this.loggedIn.next(true);

      this.loadCurrentUser();
    } else {
      this.loggedIn.next(false);
    }
  }

  login(body: any): Observable<string> {
    const url = environment.apiUrl + '/api/v1/user/login';
    const request: any = this.http.post<any>(url, body, { observe: 'response' as 'body' }).pipe(take(1));
    request.subscribe((r: any) => this.handleLogin(r));
    return request;
  }

  logout(): Observable<any> {
    return new Observable<any>((observer: any) => {
      // clear accessToken$ remove user from local storage to log user out
      this.removeAuthCookie();
      this.currentUser.next(null);
      this.loggedIn.next(false);
      observer.next();
    });
  }
  removeAuthCookie() {
    localStorage.removeItem('activeUser');
    if (Cookie.get('accessToken')) {
      Cookie.delete('accessToken', '/', this.baseHost());
    }
  }

  signUp(user: any): Observable<any> {
    const url = environment.apiUrl + '/v2/api/user/sign-up';
    const request = this.http.post(url, user);
    return request;
  }

  verifyActivationLink(accessToken$: string): Observable<any> {
    const url = '/api/user/self';
    const request = this.http.get(url, { headers: { Authorization: `${accessToken$}` } });
    return request;
  }

  changePassword(setPassword: any): Observable<any> {
    const url = environment.apiUrl + '/api/v1/user/change-password';
    const accessToken = Cookie.get('accessToken');
    const request = this.http.put(url, setPassword, { headers: { Authorization: `${accessToken}` } });
    return request;
  }


  setPassword(setPassword: any, token: string): Observable<any> {
    const url = environment.apiUrl + '/api/v1/user/set-password' + `?token=${token}`;
    const request = this.http.post(url, setPassword);
    return request;
  }

  resetPassword(body: any, token: any): Observable<any> {
    const url = environment.apiUrl + '/api/v1/user/reset-password' + `?token=${token}`;
    const accessToken = Cookie.get('accessToken');
    const request = this.http.post(url, body, {
      headers: { Authorization: `${accessToken}` },
    });
    return request;
  }

  forgotPassword(emailValue: any): Observable<any> {
    const url = environment.apiUrl + '/api/v1/user/forgot-password';
    const request = this.http.post(url, { email: emailValue });
    return request;
  }

  confirmPassword(data: any): Observable<any> {
    const url = environment.apiUrl + '/api/v1/user/confirm-forgot-password';
    const request = this.http.put(url, data);
    return request;
  }

  loadCurrentUser() {
    const a = localStorage.getItem('activeUser');
    this.currentUser.next(JSON.parse(a));
  }

  refreshAvatar(res: any) {
    const user = JSON.parse(localStorage.getItem('activeUser'));
    user.updatedAt = res.updatedAt;
    user.avatar = res.avatar;
    localStorage.setItem('activeUser', JSON.stringify(user));
    this.currentUser.next(user);
  }


  private handleLogin(response: any) {

    // login successful if there's a jwt accessToken$ in the response
    if (response.status !== 500 || response.status !== 401) {
      if (response) {
        const activeUser = response.body.payload;
        const accessToken: string = (response.headers.get('Authorization') || response.headers.get('authorization') || '').trim();
        try {

          Cookie.set(
            'accessToken',
            accessToken,
            1,
            '/',
            this.baseHost(),
            environment.production || environment.env === 'qa' ? true : undefined
          );


        } catch (e) {
          console.log(e);
        }
        delete activeUser.token;
        localStorage.setItem('activeUser', JSON.stringify(activeUser));
        this.currentUser.next(activeUser);
        this.accessToken.next(accessToken);
        this.loggedIn.next(true);
        this.router.navigateByUrl('/home');
      }
    } else {

      this.notificationService.showError(response.message);
    }
  }

  /**
   * update current user in local storage
   */
  updateCurrentUser(updateUser: any) {
    const activeUser: any = JSON.parse(localStorage.getItem('activeUser'));
    const newActiveUser = Object.assign({}, activeUser, updateUser);
    localStorage.setItem('language', updateUser.language);
    localStorage.setItem('activeUser', JSON.stringify(newActiveUser));
    this.currentUser.next(newActiveUser);
  }

}
