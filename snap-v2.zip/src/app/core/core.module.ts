import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RestService } from './services/rest.service';
import { LoaderService } from './services/loader.service';
import { LoaderInterceptor } from './interceptors/loader.interceptor';
import { HttpClientModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { DataSharingService } from './services/data-sharing.service';
import { CookieService } from 'ngx-cookie-service';
import { GeneralPurposeInterceptor } from './interceptors/general-purpose.interceptor';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HttpClientModule,
    ToastrModule.forRoot({
      preventDuplicates: true,
      onActivateTick: true
      // maxOpened: 4,
      // newestOnTop: true
    })
  ],
  providers: [CookieService, RestService, LoaderService, LoaderInterceptor, GeneralPurposeInterceptor, DataSharingService]
})
export class CoreModule { }
