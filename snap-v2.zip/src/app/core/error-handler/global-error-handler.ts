import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

import { LoggingService } from '../services/logging.service';
import { ErrorService } from '../services/error.service';
import { NotificationService } from '../services/notification.service';
import { Cookie } from '../services/cookie';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {

    constructor(private injector: Injector) { }

    handleError(error: Error | HttpErrorResponse) {

        const errorService = this.injector.get(ErrorService);
        
        const logger = this.injector.get(LoggingService);
        
        const notifier = this.injector.get(NotificationService);
        const router = this.injector.get(Router);
        const authService = this.injector.get(AuthService);

        let message;
        let stackTrace;

        if (error instanceof HttpErrorResponse) {
            // Server Error
            
            console.log('Server Error');
            message = errorService.getServerMessage(error);
            stackTrace = errorService.getServerStack(error);
            if (!Cookie.get('accessToken') && error.status === 401 && message === 'Something went wrong') {

            } 

            else if (Cookie.get('accessToken') && error.status === 401) {
                authService.logout().subscribe();
                notifier.showInfo('Session expired, please login again');
                router.navigate(['/sign-in']);
                

            }

            else {
                notifier.showError(message);
            }

        } 
        else {
            // Client Error
            console.log('Client Error');
            message = errorService.getClientMessage(error);
            stackTrace = errorService.getClientStack(error);
            // notifier.showError(message);
        }

        // log errors
        logger.logError(message, stackTrace);

        console.error(error);
    }
}
