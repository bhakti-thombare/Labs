import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { first, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AdminAuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return this.authService.currentUser$.pipe(first(), map(user => {
      if (user) {
        if (user.role && user.role.toString().toLowerCase() === 'admin') {
          return true;
        } else {
          this.router.navigateByUrl('/home');
          return false;
        }
      } else {
        this.router.navigate(['/sign-in']);
        return false;
      }
    }));
  }

}
