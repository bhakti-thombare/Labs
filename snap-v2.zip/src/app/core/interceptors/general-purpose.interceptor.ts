// loader.interceptors.ts
import { Injectable } from '@angular/core';
import {
    HttpResponse,
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpParams
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { UtilityService } from '../services/utility.service';
import { first, map } from 'rxjs/operators';
import { Cookie } from '../services/cookie';
import { NotificationService } from '../services/notification.service';

@Injectable()
export class GeneralPurposeInterceptor implements HttpInterceptor {
    private requests: HttpRequest<any>[] = [];
    currentUser: any;

    constructor(
        private notificationService: NotificationService,
        private router: Router,
        private utilityService: UtilityService,
        private authService: AuthService) {
        authService.currentUser$.subscribe(user => {
            this.currentUser = user;
        });
    }


    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (!req.url.includes('/api/v1/user/login')) {
            this.isUserPresent(req.url).subscribe(res => {
                
            });
        }
        // for every PUT POST request, trim all strings, and remove empty in request body
        if (req.method === 'PUT' || req.method === 'POST') {
            let newBody = req.body;
            newBody = this.utilityService.removeEmptyStringAndTrim(req.body);
            const body = req.body;
            const modifiedRequest = req.clone({
                body: newBody
            });
            req = modifiedRequest;
        }


        // tslint:disable-next-line: deprecation
        return Observable.create((observer: any) => {
            const subscription = next.handle(req)
                .subscribe(
                    event => {
                        if (event instanceof HttpResponse) {
                            // this.removeRequest(req);
                            observer.next(event);
                        }
                    },
                    err => {
                        // alert('error returned');
                        // this.removeRequest(req);
                        observer.error(err);
                    },
                    () => {
                        // this.removeRequest(req);
                        observer.complete();
                    });
            // remove request from queue when cancelled
            return () => {
                // this.removeRequest(req);
                subscription.unsubscribe();
            };
        });
    }
    isUserPresent(url) {
        
        if (!Cookie.get('accessToken')) {
            this.authService.logout().subscribe();
        }
        return this.authService.loggedIn$.pipe(first(), map(result => {

            if (!result) {
                
                if (!url.includes('/api/v1/user/forgot-password') &&
                    !url.includes('/api/v1/user/reset-password') &&
                    !url.includes('/api/v1/user/set-password') &&
                    !url.includes('/api/v1/donor/donation/form-options') &&
                    !url.includes('/api/v1/donor/update-donationForm')) {
                    this.notificationService.showInfo('Session expired, please login again');
                    this.router.navigate(['/sign-in']);
                }
            }
            return result;
        }));
    }
}


