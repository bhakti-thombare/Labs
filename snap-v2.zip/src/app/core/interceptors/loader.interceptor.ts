// loader.interceptors.ts
import { Injectable } from '@angular/core';
import {
    HttpResponse,
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpParams
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoaderService } from '../services/loader.service';

@Injectable()
export class LoaderInterceptor implements HttpInterceptor {
    private requests: HttpRequest<any>[] = [];

    constructor(private loaderService: LoaderService) { }

    removeRequest(req: HttpRequest<any>) {
        const showLoader = req.params.get('hideLoader');
        const i = this.requests.indexOf(req);
        if (i >= 0) {
            this.requests.splice(i, 1);
        }
        if (!showLoader) {
            this.loaderService.isLoading.next(this.requests.length > 0);
        }
    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const hideLoader = req.params.get('hideLoader');
        if (!hideLoader) {
            this.loaderService.isLoading.next(true);
        }
        if (req.params.has('hideLoader')) {
            const queryParams = {};
            req.params.keys().forEach(key => {
                queryParams[key] = req.params.get(key);
            });
            const proxyReq = req.clone({ params: this.serializeParams(queryParams) });
            req = proxyReq;
        }
        // tslint:disable-next-line: deprecation
        return Observable.create((observer: any) => {
            const subscription = next.handle(req)
                .subscribe(
                    event => {
                        if (event instanceof HttpResponse) {
                            this.removeRequest(req);
                            observer.next(event);
                        }
                    },
                    err => {
                        this.removeRequest(req);
                        observer.error(err);
                    },
                    () => {
                        this.removeRequest(req);
                        observer.complete();
                    });
            // remove request from queue when cancelled
            return () => {
                this.removeRequest(req);
                subscription.unsubscribe();
            };
        });
    }

    /**
     * Serialize search object to params
     */
    serializeParams(obj: any): HttpParams {
        let params = new HttpParams();
        for (const p in obj) {
            if (obj.hasOwnProperty(p)) {
                params = params.append(p, obj[p]);
            }
        }
        return params;
    }
}
