import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YourFoodBankDashboardComponent } from './your-food-bank-dashboard.component';

describe('YourFoodBankDashboardComponent', () => {
  let component: YourFoodBankDashboardComponent;
  let fixture: ComponentFixture<YourFoodBankDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YourFoodBankDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YourFoodBankDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
