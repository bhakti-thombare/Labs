import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-your-food-bank-dashboard',
  templateUrl: './your-food-bank-dashboard.component.html',
  styleUrls: ['./your-food-bank-dashboard.component.scss']
})
export class YourFoodBankDashboardComponent implements OnInit {

  currentUser: any;
  foodBankId: any;
  subscription: Subscription;
  selectedTab;
  yourFoodBankTabOptions = [
    { title: 'View', url: '/your-food-bank/view/', selected: false },
    { title: 'Edit', url: '/your-food-bank/edit/', selected: false },
    { title: 'Submitted donations', url: '/your-food-bank/submitted-donations', selected: false },
    { title: 'Offers', url: '/your-food-bank/offers', selected: false }
  ];
  currentRoute: any;
  showQuickLinks: boolean;
  constructor(
    private router: Router,
    private authService: AuthService,
    private activatedRoute: ActivatedRoute,
  ) {
    this.loadUser();

    this.subscription = router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {

      if (
        event.url.includes('your-food-bank/submitted-donations') ||
        event.url.includes('your-food-bank/offers')) {
        this.showQuickLinks = false;
      } else {
        this.showQuickLinks = true;
      }
      this.currentRoute = event.url;
      this.modifyUserTabs();
    });
  }

  ngOnInit() {
    this.foodBankId = this.currentUser.foodbank.id;
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  modifyUserTabs() {
    const zoneId = this.currentUser.foodbank.id;
    if (this.currentUser) {

      // food bank users
      this.yourFoodBankTabOptions = [
        { title: 'View', url: '/your-food-bank/view/', selected: false },
        { title: 'Edit', url: '/your-food-bank/edit/', selected: false },
        { title: 'Submitted donations', url: '/your-food-bank/submitted-donations', selected: false },
        { title: 'Offers', url: '/your-food-bank/offers', selected: false }
      ];

      for (const option of this.yourFoodBankTabOptions) {
        if (this.currentRoute.includes(option.url) || option.url.includes(this.currentRoute)) {
          this.selectedTab = this.getHeader(option.title);
          break;
        }
      }
    }
  }

  tabSelected(url) {
    for (const option of this.yourFoodBankTabOptions) {
      if (url.includes(option.url) || option.url.includes(url)) {
        this.selectedTab = this.getHeader(option.title);
        option.selected = true;
        this.router.navigateByUrl(url);
      } else {
        option.selected = false;
      }
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getHeader(option) {
    option = option.toString().toLowerCase();
    switch (option) {
      case 'view':
        return 'your food bank details';
      case 'submitted donations':
        return 'Submitted donations';
      case 'edit':
        return 'Edit you food bank';
      case 'offers':
        return 'Offers';
    }
  }
}
