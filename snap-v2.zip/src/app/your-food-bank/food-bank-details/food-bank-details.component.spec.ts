import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodBankDetailsComponent } from './food-bank-details.component';

describe('FoodBankDetailsComponent', () => {
  let component: FoodBankDetailsComponent;
  let fixture: ComponentFixture<FoodBankDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoodBankDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodBankDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
