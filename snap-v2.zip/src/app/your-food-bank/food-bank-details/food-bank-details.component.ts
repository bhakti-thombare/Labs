import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-food-bank-details',
  templateUrl: './food-bank-details.component.html',
  styleUrls: ['./food-bank-details.component.scss']
})
export class FoodBankDetailsComponent implements OnInit {
  currentUser: any;
  foodBankDetails: any;
  showUserList = true;
  foodBankId: string;
  constructor(
    private activatedRoute: ActivatedRoute,
    private generalService: GeneralService,
    private authService: AuthService,
    private router: Router,
  ) {
    this.loadUser();
  }

  ngOnInit() {
    this.foodBankId = this.activatedRoute.snapshot.paramMap.get('id');
    const url = this.router.url;
    if (url.includes('other-food-bank/details')) {
      this.showUserList = false;
    }
    if (!this.foodBankId) {
      this.foodBankId = this.currentUser.foodbank.id;
    }
    this.getFoodBankDetails(this.foodBankId);
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;

      if (this.currentUser) {
      }
    });
  }

  getFoodBankDetails(foodBankId) {
    this.generalService.getFoodBankById(foodBankId).subscribe(res => {
      this.foodBankDetails = res.payload;
    });
  }

}
