import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {
  // `/api/v1/myOfferTab/view/${id}`  -- get food bank by id
  // `/api/v1/myOfferTab/getSubmittedDonationReports` get donations submitted
  // ​`/api​/v1/myOfferTab/getOffer` get offers
  // `/api/v1/myOfferTab/editprofile/${id}`


  baseUrl = environment.apiUrl;
  constructor(private restService: RestService, private http: HttpClient) { }


  getFoodBankById(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/myOfferTab/view/${id}`, undefined, true);
  }

  // getFoodBankById2(id) {
  //   return this.restService.fetch(`${this.baseUrl}/api/v1/myOffersTab/profile/${id}`, undefined, true);
  // }

  getSubmittedDonations(queries) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/myOfferTab/getSubmittedDonationReports`, queries, true);

  }

  getOffersByFoodBank(queries) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/myOfferTab/getOffer`, queries, true);

  }
  // get food bank by id
  getFoodBankDetails(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/profile/${id}`, undefined, true);
  }


  getFoodBankDropdownOptions() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/form-options`, undefined, true);
  }

  // update
  updateFoodBank(data, id) {
    return this.restService.put(`${this.baseUrl}/api/v1/myOfferTab/editprofile/${id}`, data, undefined, true);
  }

  
  // get all
  getFoodBanksByName(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/foodbank/profile/byName`, data, { hideLoader: true }, true);
  }

}
