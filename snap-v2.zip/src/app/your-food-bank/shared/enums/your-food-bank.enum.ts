// donation report tab sorting params

export enum submittedDonationsSortParam {
  FEED_ONTARIO_ID = 'feedOntarioId',
  OFFER_DATE = 'offerDate',
  FOOD_TEMP = 'foodTemperature',
  FOOD_CATEGORY = 'foodCategory',
  TOTAL_WEIGHT = 'totalWeight',
  PRODUCT_DESC = 'productDescription',
  ALLOCATION_METHOD = 'allocationMethod',
  WEIGHT_PER_PALLET_OR_BOX = 'weightPerPalletOrBox',
  QUANTITY_PALLETS = 'quantityPallets',
}


export enum offersSortParam {
  OFFERED_QUANTITY = 'offeredQuantity',
  RECEIVED_QUANTITY = 'receivedQuantity',
  ALLOCATED_QUANTITY = 'allocatedQuantity',
  REQUESTED_QUANTITY = 'requestedQuantity',
  FEED_ONTARIO_ID = 'feedOntarioId',
  OFFER_DATE = 'offerDate',
  FOOD_TEMP = 'foodTemperature',
  FOOD_CATEGORY = 'foodCategory',
  TOTAL_WEIGHT = 'totalWeight',
  PRODUCT_DESC = 'productDescription',
  ALLOCATION_METHOD = 'allocationMethod',
  WEIGHT_PER_PALLET_OR_BOX = 'weightPerPalletOrBox',
  QUANTITY_PALLETS = 'quantityPallets',
}

