import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserAuthGuard } from '../core/guards/user-auth.guard';
import { FoodBankDetailsComponent } from './food-bank-details/food-bank-details.component';
import { FoodBankFormComponent } from './food-bank-form/food-bank-form.component';
import { OfferListComponent } from './offer-list/offer-list.component';
import { SubmittedDonationsListComponent } from './submitted-donations-list/submitted-donations-list.component';
import { YourFoodBankDashboardComponent } from './your-food-bank-dashboard/your-food-bank-dashboard.component';


const routes: Routes = [
  {
    path: '', canActivate: [UserAuthGuard], component: YourFoodBankDashboardComponent, children: [
      { path: '', redirectTo: 'view', pathMatch: 'full' },
      { path: 'view', component: FoodBankDetailsComponent },
      { path: 'edit', component: FoodBankFormComponent },
      { path: 'submitted-donations', component: SubmittedDonationsListComponent },
      { path: 'offers', component: OfferListComponent },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YourFoodBankRoutingModule { }
