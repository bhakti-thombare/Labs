import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { YourFoodBankRoutingModule } from './your-food-bank-routing.module';
import { YourFoodBankDashboardComponent } from './your-food-bank-dashboard/your-food-bank-dashboard.component';
import { FoodBankDetailsComponent } from './food-bank-details/food-bank-details.component';
import { FoodBankFormComponent } from './food-bank-form/food-bank-form.component';
import { SubmittedDonationsListComponent } from './submitted-donations-list/submitted-donations-list.component';
import { OfferListComponent } from './offer-list/offer-list.component';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

@NgModule({
  declarations: [
    YourFoodBankDashboardComponent,
    FoodBankDetailsComponent,
    FoodBankFormComponent,
    SubmittedDonationsListComponent,
    OfferListComponent],
  imports: [

    BsDatepickerModule.forRoot(),

    ModalModule.forRoot(),
    PopoverModule.forRoot(),
    NgSelectModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    SharedModule,
    YourFoodBankRoutingModule
  ],
  exports: [
    FoodBankDetailsComponent
  ]
})
export class YourFoodBankModule { }
