import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodBankFormComponent } from './food-bank-form.component';

describe('FoodBankFormComponent', () => {
  let component: FoodBankFormComponent;
  let fixture: ComponentFixture<FoodBankFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoodBankFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodBankFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
