import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmittedDonationsListComponent } from './submitted-donations-list.component';

describe('SubmittedDonationsListComponent', () => {
  let component: SubmittedDonationsListComponent;
  let fixture: ComponentFixture<SubmittedDonationsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubmittedDonationsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmittedDonationsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
