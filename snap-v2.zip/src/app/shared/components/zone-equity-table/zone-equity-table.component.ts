import { Component, CUSTOM_ELEMENTS_SCHEMA, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GeneralService } from 'src/app/shared/services/general.service';

@Component({
  selector: 'app-zone-equity-table',
  templateUrl: './zone-equity-table.component.html',
  styleUrls: ['./zone-equity-table.component.scss']
})
export class ZoneEquityTableComponent implements OnInit {
  zones = []
  zoneId: number;
  zone: string;
  directOfferPercent: number;
  foodOfferPercent: number;
  dryHubOfferPercent: number;
  overallPercent: number;

  constructor(private generalService: GeneralService, private router: Router) { }

  ngOnInit() {
    this.getZones();
  }

  getZones() {
    this.generalService.getZoneEquity().subscribe(
      data => {
        this.zones = data.payload;
        this.roundOffFloatValues(this.zones);
      });
  }

  navigateTo(zone) {
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
      this.router.navigate(['/zone/view/' + zone.zoneId]));
  }

  roundOffFloatValues(list) {
    for (const item of list) {
      item.hcPercent = item.hcPercent && +item.hcPercent.toFixed(2) || 0;
      item.overallPercent = item.overallPercent && +item.overallPercent.toFixed(2) || 0;
      item.directOfferPercent = item.directOfferPercent && +item.directOfferPercent.toFixed(2) || 0;
      item.foodOfferPercent = item.foodOfferPercent && +item.foodOfferPercent.toFixed(2) || 0;
      item.dryHubOfferPercent = item.dryHubOfferPercent && +item.dryHubOfferPercent.toFixed(2) || 0;
    }

  }
}
