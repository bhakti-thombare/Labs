import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZoneEquityTableComponent } from './zone-equity-table.component';

describe('ZoneEquityTableComponent', () => {
  let component: ZoneEquityTableComponent;
  let fixture: ComponentFixture<ZoneEquityTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZoneEquityTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZoneEquityTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
