import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-quick-link',
  templateUrl: './quick-link.component.html',
  styleUrls: ['./quick-link.component.scss']
})
export class QuickLinkComponent implements OnInit {

  quickLinks = [
    { title: 'All food banks', url: '/user/food-bank/list' },
    { title: 'Donors', url: '/user/donor/list' },
    { title: 'Zones', url: '/zone/list' },
    { title: 'Carriers', url: '/carrier/list' },
    { title: 'Email templates', url: '/email-template/list' },
    { title: 'Settings', url: '/miscellaneous/settings' },
    { title: 'Users', url: '/user/list' },
    // { title: 'Distribution lists', url: '' },
    // { title: 'Deleted items', url: '' },
    { title: 'Update Hunger Counts', url: '/miscellaneous/food-bank-hunger-count-list' }
  ];
  currentUser: any;

  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (this.currentUser && this.currentUser.role.toString().toLowerCase() !== 'admin') {
        this.quickLinks = [
          { title: 'Food banks', url: '/miscellaneous/other-food-bank/list' },
          { title: 'Zones', url: '/zone/list' },
          { title: 'Create donation', url: '/donation/new' },
        ];
      }
    });
  }


  goToUrl(event, url) {
    event.stopPropagation();
    event.preventDefault();
    if (url) {
      this.router.navigateByUrl(url);
    }

  }
}
