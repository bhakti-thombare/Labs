import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { Router } from '@angular/router';
import { GeneralService } from 'src/app/shared/services/general.service';
import { NotificationService } from 'src/app/core/services/notification.service';

@Component({
  selector: 'app-top-navigation-bar',
  templateUrl: './top-navigation-bar.component.html',
  styleUrls: ['./top-navigation-bar.component.scss']
})
export class TopNavigationBarComponent implements OnInit {

  @ViewChild('dropdown', { static: false }) nameDropdown: any;
  currentUser: any;
  feedOntarioId: any;
  @Output() noResultEvent: EventEmitter<any> = new EventEmitter<any>()
  constructor(
    private notificationService: NotificationService,
    private generalService: GeneralService, private authService: AuthService, private router: Router) { }
  selectedCity1: any;
  cities1 = [
    { label: 'Select City', value: null },
    { label: 'New York', value: { id: 1, name: 'New York', code: 'NY' } },
    { label: 'Rome', value: { id: 2, name: 'Rome', code: 'RM' } },
    { label: 'London', value: { id: 3, name: 'London', code: 'LDN' } },
    { label: 'Istanbul', value: { id: 4, name: 'Istanbul', code: 'IST' } },
    { label: 'Paris', value: { id: 5, name: 'Paris', code: 'PRS' } }
  ];
  secondaryNavOptions = [
    { selected: false, title: 'Home', url: '/home' },
    { selected: false, title: 'Donations', url: '/donation' },
    // { selected: false, title: 'Shipping', url: '/shipping' },
    // { selected: false, title: 'Offers', url: '/offers' },
    { selected: false, title: 'Reports', url: '/report' },
  ];
  ngOnInit() {
    
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (this.currentUser) {
        if (this.currentUser.role.toString().toLowerCase() !== 'admin') {
          this.secondaryNavOptions = [
            { selected: false, title: 'Home', url: '/home' },
            { selected: false, title: 'Your food bank', url: '/your-food-bank' },
            { selected: false, title: 'Reports', url: '/report' },
          ];
        }
      }
    });

    
    
    const moduleRoute = '/' + this.router.url.split('/')[1];
    
    const index = this.secondaryNavOptions.findIndex(item => moduleRoute.includes(item.url));
    if (index !== -1) {
      this.secondaryOptionSelected(index);
    }
  }

  secondaryOptionSelected(i) {
    
    if (!this.secondaryNavOptions[i].selected) {
      for (const navOption of this.secondaryNavOptions) {
        navOption.selected = false;
      }
      
      this.secondaryNavOptions[i].selected = true;
      
      
      if (this.secondaryNavOptions[i].url.includes('home') ||
        this.secondaryNavOptions[i].url.includes('donation') ||
        this.secondaryNavOptions[i].url.includes('report') ||
        this.secondaryNavOptions[i].url.includes('your-food-bank')) {
        
        this.router.navigateByUrl(this.secondaryNavOptions[i].url);
      }
    }
  }


  logout() {
    this.authService.logout().subscribe(res => {
      window.location.href = '/';
    });
  }
  navigateTo(url) {
    window.location.href = url;
  }

  searchByFeedOntarioId() {
    if (this.feedOntarioId && this.feedOntarioId.trim()) {
      this.generalService.searchByFeedOntarioId(this.feedOntarioId && this.feedOntarioId.toString().trim()).subscribe(res => {
        
        if (typeof res.payload === 'string') {
          // this.router.navigate(['/home/current-offers']);

          this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
            this.router.navigate(['/home/current-offers']));

          this.notificationService
            .showError(`Could not find donation with ID ${this.feedOntarioId}. Please enter an OAFB ID in the Find box (ex: 11B-005), or go to the Offers page to view all of your offers.
        `)
        } else {
          if (this.currentUser.role === 'ADMIN') {
            // this.router.navigate(['/donation/view-allocate/' + res.payload.donationId]);
            this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
              this.router.navigate(['/donation/view-allocate/' + res.payload.donationId]));
          } else {
            // this.router.navigate(['/offer/donation-details/' + res.payload.donationId]);

            this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
              this.router.navigate(['/offer/donation-details/' + res.payload.donationId]));
          }
        }
      });
    }
  }
}
