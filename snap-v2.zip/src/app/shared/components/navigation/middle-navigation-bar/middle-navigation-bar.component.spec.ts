import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MiddleNavigationBarComponent } from './middle-navigation-bar.component';

describe('MiddleNavigationBarComponent', () => {
  let component: MiddleNavigationBarComponent;
  let fixture: ComponentFixture<MiddleNavigationBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MiddleNavigationBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MiddleNavigationBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
