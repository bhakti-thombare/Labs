import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-middle-navigation-bar',
  templateUrl: './middle-navigation-bar.component.html',
  styleUrls: ['./middle-navigation-bar.component.scss']
})
export class MiddleNavigationBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
