import { Component, OnInit, Input, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from 'src/app/core/services/auth.service';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-lower-navigation-bar',
  templateUrl: './lower-navigation-bar.component.html',
  styleUrls: ['./lower-navigation-bar.component.scss']
})
export class LowerNavigationBarComponent implements OnInit, OnChanges, OnDestroy {

  @Input() tabOptions: any;
  subscription: Subscription;
  currentUser: any;
  @Input() selectedTab: any;
  currentRoute: string;
  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private authService: AuthService
  ) {
    this.subscription = router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: any) => {
      
      // if (this.router.url.indexOf('page') > -1) {
      
      
      
      this.tabSelected(this.router.url);
      // }
    });
  }

  ngOnInit() {
    
    // this.currentRoute = this.router.url;
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
    this.tabSelected(this.currentRoute);
  }

  ngOnChanges(changes: SimpleChanges) {
    
    this.currentRoute = this.router.url;
    this.tabSelected(this.currentRoute);
    
    
  }

  tabSelected(url, doNavigate = true) {
    
    if (this.currentUser) {
      
      if (this.tabOptions && this.tabOptions.length) {
        // tslint:disable-next-line: prefer-for-of
        for (let i = 0; i < this.tabOptions.length; i++) {
          const option = this.tabOptions[i];
          if (url.includes(option.url) || option.url.includes(url)) {
            // this.selectedTab = this.selectedTab === option.title ? this.selectedTab : option.title;
            option.selected = true;
            const index =
              this.tabOptions.findIndex(item => (item.url === this.currentRoute));

            
            
            
            
            this.router.navigate([url]);
          } else {
            
            
            
            option.selected = false;
            this.router.navigate([url]);
          }
        }
      }
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  navigateTo(url) {
    
    this.tabSelected(url, true);
  }

}
