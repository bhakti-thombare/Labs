import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LowerNavigationBarComponent } from './lower-navigation-bar.component';

describe('LowerNavigationBarComponent', () => {
  let component: LowerNavigationBarComponent;
  let fixture: ComponentFixture<LowerNavigationBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LowerNavigationBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LowerNavigationBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
