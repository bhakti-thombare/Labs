import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-under-development',
  templateUrl: './page-under-development.component.html',
  styleUrls: ['./page-under-development.component.scss']
})
export class PageUnderDevelopmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
