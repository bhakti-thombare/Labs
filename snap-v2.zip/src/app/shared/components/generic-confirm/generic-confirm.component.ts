import { Component, OnInit, ViewChild, Output, Input, EventEmitter } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';

export interface ModalData {
  text: string;
  hideNoButton?: boolean;
  notConfirmText?: string;
  confirmText?: string;
  headlineText?: string;
  callback?: any;
}
@Component({
  selector: 'app-generic-confirm',
  templateUrl: './generic-confirm.component.html',
  styleUrls: ['./generic-confirm.component.scss']
})
export class GenericConfirmComponent implements OnInit {

  @ViewChild('formModal', { static: true }) formModal: ModalDirective;
  @Input() showCancel = true;

  data: ModalData = {} as ModalData;

  constructor() { }

  ngOnInit() { }

  hide() {
    this.formModal.hide();
  }

  onConfirm() {
    this.hide();
    if (this.data.callback) {
      this.data.callback(true);
    }
  }

  show(data: ModalData) {
    this.data = data;
    this.formModal.show();
  }

  cancel() {
    this.formModal.hide();
    if (this.data.callback) {
      this.data.callback(false);
    }
  }

}
