import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderComponent } from './components/loader/loader.component';
import { TopNavigationBarComponent } from './components/navigation/top-navigation-bar/top-navigation-bar.component';
import { MiddleNavigationBarComponent } from './components/navigation/middle-navigation-bar/middle-navigation-bar.component';
import { LowerNavigationBarComponent } from './components/navigation/lower-navigation-bar/lower-navigation-bar.component';
import { QuickLinkComponent } from './components/navigation/quick-link/quick-link.component';
import { RouterModule } from '@angular/router';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule } from '@angular/forms';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { GenericConfirmComponent } from './components/generic-confirm/generic-confirm.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { PageUnderDevelopmentComponent } from './components/page-under-development/page-under-development.component';
import { PaginationComponent } from './components/pagination/pagination.component';
import { ZoneEquityTableComponent } from './components/zone-equity-table/zone-equity-table.component';
@NgModule({
  declarations: [
    LoaderComponent,
    TopNavigationBarComponent,
    MiddleNavigationBarComponent,
    LowerNavigationBarComponent,
    QuickLinkComponent,
    PageNotFoundComponent,
    GenericConfirmComponent,
    PageUnderDevelopmentComponent,
    PaginationComponent,
    ZoneEquityTableComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    DropdownModule,
    ModalModule.forRoot(),
    BsDropdownModule.forRoot()
  ],
  exports: [
    PaginationComponent,
    LoaderComponent,
    TopNavigationBarComponent,
    MiddleNavigationBarComponent,
    LowerNavigationBarComponent,
    GenericConfirmComponent,
    PageUnderDevelopmentComponent,
    QuickLinkComponent,
    ZoneEquityTableComponent
  ]
})
export class SharedModule { }
