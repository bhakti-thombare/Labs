import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  baseUrl = environment.apiUrl;
  constructor(
    private restService: RestService
  ) { }

  searchByFeedOntarioId(feedOntarioId) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/getDonationByFeedOntarioId/${feedOntarioId}`);
  }

  getZoneEquity() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/report/zone-equity-overview`, { hideLoader: true }, true);

  }
}
