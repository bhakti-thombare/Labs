import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmailTemplateDashboardComponent } from './email-template-dashboard/email-template-dashboard.component';
import { EmailTemplateFormComponent } from './email-template-form/email-template-form.component';
import { EmailTemplateListComponent } from './email-template-list/email-template-list.component';


const routes: Routes = [
  {
    path: '', component: EmailTemplateDashboardComponent, children: [
      { path: '', redirectTo: 'list', pathMatch: 'full' },
      { path: 'list', component: EmailTemplateListComponent },
      { path: 'edit/:id', component: EmailTemplateFormComponent },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmailTemplateRoutingModule { }
