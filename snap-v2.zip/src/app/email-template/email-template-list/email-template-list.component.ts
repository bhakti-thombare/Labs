import { Component, OnInit, ViewChild } from '@angular/core';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-email-template-list',
  templateUrl: './email-template-list.component.html',
  styleUrls: ['./email-template-list.component.scss']
})
export class EmailTemplateListComponent implements OnInit {

  emailTemplateList = [];
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;

  constructor(
    private notificationService: NotificationService,
    private generalService: GeneralService,
  ) { }

  ngOnInit() {
    this.getEmailTemplates();
  }

  getEmailTemplates() {
    this.generalService.getEmailTemplateList().subscribe(res => {
      this.emailTemplateList = res.payload.mailTemplates;
    });
  }


}
