import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-email-template-dashboard',
  templateUrl: './email-template-dashboard.component.html',
  styleUrls: ['./email-template-dashboard.component.scss']
})
export class EmailTemplateDashboardComponent implements OnInit, OnDestroy {
  currentUser: any;
  emailTemplateId: any;
  subscription: Subscription;
  selectedTab = 'Email templates';
  emailTempTabOptions = [
    { title: 'List', url: '/email-template/list', selected: true }];
  currentRoute: any;
  constructor(
    private router: Router,
    private authService: AuthService,
    private activatedRoute: ActivatedRoute,
  ) {

    this.subscription = router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      
      this.currentRoute = event.url;
      this.modifyUserTabs();
    });
  }

  ngOnInit() {
    this.emailTemplateId = this.activatedRoute.snapshot.paramMap.get('id') || this.activatedRoute.firstChild.snapshot.paramMap.get('id');
    this.loadUser();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      this.modifyUserTabs();
    });
  }

  modifyUserTabs() {

    const emailTemplateId = this.activatedRoute.snapshot.paramMap.get('id') || this.activatedRoute.firstChild.snapshot.paramMap.get('id');
    
    if (this.currentUser) {

      if (this.currentUser.role === 'ADMIN') {
        if (!emailTemplateId || emailTemplateId === null) {
          this.emailTempTabOptions = [
            { title: 'List', url: '/email-template/list', selected: false }];
        } else {
          this.emailTempTabOptions = [
            { title: 'List', url: '/email-template/list', selected: false },
            { title: 'Edit', url: '/email-template/edit/' + emailTemplateId, selected: false },
          ];
        }
      }
      for (const option of this.emailTempTabOptions) {
        if (this.currentRoute.includes(option.url) || option.url.includes(this.currentRoute)) {
          this.selectedTab = this.getHeader(option.title);
        }
      }
    }
  }

  tabSelected(url) {
    for (const option of this.emailTempTabOptions) {
      if (url.includes(option.url) || option.url.includes(url)) {
        this.selectedTab = this.getHeader(option.title);
        option.selected = true;
        this.router.navigateByUrl(url);
      } else {
        option.selected = false;
      }
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getHeader(option) {
    option = option.toString().toLowerCase();
    switch (option) {
      case 'list':
        return 'Email templates';
      case 'edit':
        return 'Edit email template';
    }
  }
}
