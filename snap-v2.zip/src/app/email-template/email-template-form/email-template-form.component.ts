import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-email-template-form',
  templateUrl: './email-template-form.component.html',
  styleUrls: ['./email-template-form.component.scss']
})
export class EmailTemplateFormComponent implements OnInit {
  emailTemplateId: string;
  emailTemplateForm: FormGroup;
  emailTemplateDetails: any;
  defaultHtmlTempCollapsed = true;
  defaultTextTempCollapsed = true;
  statuses = [
    { status: 'Enabled', value: 'enabled' },
    { status: 'Disabled', value: 'disbaled' }
  ];
  constructor(
    private router: Router,
    private notificationService: NotificationService,
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private generalService: GeneralService
  ) { }

  ngOnInit() {
    this.emailTemplateId = this.activatedRoute.snapshot.paramMap.get('id');
    this.buildEmailTemplateForm();
    this.getEmailTemplateById();
  }

  buildEmailTemplateForm() {
    this.emailTemplateForm = this.formBuilder.group({
      language: ['', Validators.required],
      subject: ['', Validators.required],
      textTemplate: ['', Validators.required],
      htmlTemplate: ['', Validators.required],
      description: [''],
      status: [false, Validators.required]
    });
  }

  patchForm() {
    this.emailTemplateForm.patchValue({
      language: this.emailTemplateDetails.language,
      subject: this.emailTemplateDetails.subject,
      textTemplate: this.emailTemplateDetails.textTemplate,
      htmlTemplate: this.emailTemplateDetails.htmlTemplate,
      description: this.emailTemplateDetails.description || '',
      status: this.emailTemplateDetails.status ? 'enabled' : 'disabled'
    });

    (document.getElementById(this.emailTemplateDetails.status ? 'enabled' : 'disabled') as HTMLInputElement).checked = true;
  }

  getEmailTemplateById() {
    this.generalService.getEmailTemplateById(this.emailTemplateId).subscribe(res => {
      
      this.emailTemplateDetails = res.payload;
      this.patchForm();
    });
  }

  submit() {
    if (this.emailTemplateForm.valid) {
      
      const data = this.emailTemplateForm.value;
      data.status = data.status === 'enabled' ? true : false;
      
      this.generalService.updateEmailTemplate(this.emailTemplateForm.value, this.emailTemplateId).subscribe(res => {
        this.notificationService.showSuccess('Email template updated successfully');
        this.router.navigateByUrl('/email-template/list');
      });
    } else {
      this.notificationService.showError('Please fill all mandatory fields data.');
    }
  }

  resetToDefault() {
    this.emailTemplateForm.get('htmlTemplate').setValue(this.emailTemplateDetails.htmlTemplateDefault);
    this.emailTemplateForm.get('textTemplate').setValue(this.emailTemplateDetails.textTemplateDefault);
    this.notificationService.showSuccess('Please click save to reflect the changes.');
  }
}
