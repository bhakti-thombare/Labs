import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmailTemplateRoutingModule } from './email-template-routing.module';
import { EmailTemplateDashboardComponent } from './email-template-dashboard/email-template-dashboard.component';
import { EmailTemplateListComponent } from './email-template-list/email-template-list.component';
import { EmailTemplateFormComponent } from './email-template-form/email-template-form.component';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CollapseModule } from 'ngx-bootstrap/collapse';


@NgModule({
  declarations: [EmailTemplateDashboardComponent, EmailTemplateListComponent, EmailTemplateFormComponent],
  imports: [
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    CollapseModule.forRoot(),
    CommonModule,
    EmailTemplateRoutingModule
  ]
})
export class EmailTemplateModule { }
