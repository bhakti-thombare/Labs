import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {
  constructor(
    private restService: RestService
  ) { }

  baseUrl = environment.apiUrl;

  getEmailTemplateList() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/mail/template/`, undefined, true);
  }

  getEmailTemplateById(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/mail/template/${id}`, undefined, true);
  }

  updateEmailTemplate(data, id) {
    return this.restService.put(`${this.baseUrl}/api/v1/mail/template/${id}`, data, undefined, true);
  }

}
