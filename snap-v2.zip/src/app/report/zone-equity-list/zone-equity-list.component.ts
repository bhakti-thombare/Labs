import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { element } from 'protractor';
import { concat, Observable, of, Subject } from 'rxjs';
import { distinctUntilChanged, tap, switchMap, catchError, map } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { zoneEquityReportSortParam } from '../shared/enums/report.enum';
import { GeneralService } from '../shared/services/general.service';
@Component({
  selector: 'app-zone-equity-list',
  templateUrl: './zone-equity-list.component.html',
  styleUrls: ['./zone-equity-list.component.scss']
})
export class ZoneEquityListComponent implements OnInit {

  zoneEquityList = [];

  foodTemperatures = [
    { label: 'All', value: 'all' },
    { label: 'Chilled', value: 'Chilled' },
    { label: 'Dry', value: 'Dry' },
    { label: 'Frozen', value: 'Frozen' },
  ];
  zones = [
    { label: 'All', value: 'all' }
  ];
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  currentUser: any;
  currentPage = 1;
  pageSize = 15;
  total = 0;
  delta = 2;
  totalPages: number;
  toolTipContent = '';
  zone = 'all';
  foodTemperature = 'all';
  foodBank: any;
  selectedDateRange: any = [];
  selectedStartDate: any;
  selectedEndDate: any;
  downloadSpreadSheet = false;
  foodBanks$: Observable<any[]>;
  foodBankLoading = false;
  foodBankInput$ = new Subject<string>();
  selectedFoodBankIds = [];

  donors$: Observable<any[]>;
  donorLoading = false;
  donorInput$ = new Subject<string>();
  selectedDonorIds = [];
  bsRangeValue: Date[];



  sortParam: any;
  order = 'ASC';
  zoneEquityDetails: any;
  currentDate: any;
  endDate: any;
  public get zoneEquityReportSortParam(): typeof zoneEquityReportSortParam {
    return zoneEquityReportSortParam;
  }
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private authService: AuthService,
    private generalService: GeneralService,
    private notificationService: NotificationService
  ) {


  }

  ngOnInit() {

    if (this.router.url.includes('zone-equity')) {
      this.currentDate = new Date()
      this.endDate = new Date();
      this.endDate.setMonth(this.endDate.getMonth() - 6);

      this.selectedDateRange = [this.endDate, this.currentDate];
      console.log('this.selectedDateRange', this.selectedDateRange)
      // this.selectedDateRange[0]=  endDate.toLocaleDateString(); 
      // this.selectedDateRange[1]=  currentDate; 

    }

    this.loadUser();
    this.getZoneEquity();
    this.loadFoodBanks();

    // let currentDate = new Date()
    // var endDate = new Date();
    // console.log(endDate.toLocaleDateString());
    // endDate.setMonth(endDate.getMonth() - 6);
    // console.log(endDate.toLocaleDateString());
    // this.selectedDateRange[0]=  endDate.toLocaleDateString(); 
    // this.selectedDateRange[1]=  currentDate;

  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }
  getZoneEquity() {
    const queries: any = {
      pageNo: this.currentPage - 1,
      pageSize: this.pageSize,
      download: this.downloadSpreadSheet,
      foodTemperature: this.foodTemperature,
      source: this.selectedFoodBankIds.join(',') || 'all'
    };

    if (this.sortParam && this.order) {
      queries.sort = this.sortParam;
      queries.order = this.order;
    }

    if (this.selectedDateRange && this.selectedDateRange.length) {
      queries.startDate = moment(
        this.utilityService.convertToUtc(new Date(this.selectedDateRange[0]).setHours(0, 0, 0))
      ).format('YYYY-MM-DD HH:mm:ss'),
        queries.endDate = moment(
          this.utilityService.convertToUtc(new Date(this.selectedDateRange[1]).setHours(23, 59, 59))
        ).format('YYYY-MM-DD HH:mm:ss'),
        queries.from = moment(
          this.utilityService.convertToUtc(new Date(this.selectedDateRange[0]).setHours(0, 0, 0))
        ).format('YYYY-MM-DD HH:mm:ss');
      queries.to = moment(
        this.utilityService.convertToUtc(new Date(this.selectedDateRange[1]).setHours(23, 59, 59))
      ).format('YYYY-MM-DD HH:mm:ss');
    }

    this.generalService.getZoneEquity(queries).subscribe(response => {
      const res = response.payload;
      if (!queries.download) {
        this.zoneEquityDetails = res;
        this.zoneEquityList = res.zoneEquityDtoList;
        this.roundOffFloatValues(this.zoneEquityList);

      } else if (queries.download) {
        this.downloadSpreadSheet = false;
        window.open(res, '_blank');
      }
    });
  }

  zoneChanged(event) {

  }

  foodTemperatureChanged(event) {

  }

  fiscalYearChanged(event) {

  }

  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {
    // 
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getZoneEquity();
  }


  submitFilter() {

    if (this.checkValidity()) {
      this.currentPage = 1;
      this.getZoneEquity();
    }
  }

  checkValidity() {
    if (!this.foodTemperature && !this.zone) {
      this.notificationService.showError('Please at least one option before applying filter.');
      return false;
    }
    return true;
  }


  trackByFn(item: any) {
    return item.id;
  }


  foodBankSelected(event) {


    this.foodBanks$ = new Observable<any[]>();
    this.loadFoodBanks();
  }

  private loadFoodBanks() {
    this.foodBanks$ = concat(
      of([]), // default items
      this.foodBankInput$.pipe(
        distinctUntilChanged(),
        tap(() => this.foodBankLoading = true),
        switchMap(term => {

          if (!term) {
            this.foodBankLoading = false;
            return of([]);
          } else {
            return this.generalService.getFoodBanksByName({ name: term }).pipe(
              catchError(() => of([])), // empty list on error
              map((data: any) => data && data.payload || []),
              tap((res) => this.foodBankLoading = false)
            );
          }
        })
      )
    );
  }



  sortList(sortParam) {
    this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
    this.sortParam = sortParam;
    this.getZoneEquity();
  }

  roundOffFloatValues(list) {
    for (const item of list) {
      item.foodOfferPercent = item.foodOfferPercent && +item.foodOfferPercent.toFixed(2) || 0;
      item.directOfferPercent = item.directOfferPercent && +item.directOfferPercent.toFixed(2) || 0;
      item.dryHubOfferPercent = item.dryHubOfferPercent && +item.dryHubOfferPercent.toFixed(2) || 0;
      item.overallPercent = item.overallPercent && +item.overallPercent.toFixed(2) || 0;
      item.hcPercent = item.hcPercent && +item.hcPercent.toFixed(2) || 0;
    }
  }
}
