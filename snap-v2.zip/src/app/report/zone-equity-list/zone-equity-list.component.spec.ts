import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZoneEquityListComponent } from './zone-equity-list.component';

describe('ZoneEquityListComponent', () => {
  let component: ZoneEquityListComponent;
  let fixture: ComponentFixture<ZoneEquityListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZoneEquityListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZoneEquityListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
