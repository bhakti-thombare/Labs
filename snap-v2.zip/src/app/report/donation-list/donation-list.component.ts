import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { DONATION_STATUS } from 'src/app/home/shared/donation';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { GeneralService } from '../shared/services/general.service';
import * as moment from 'moment';
import { concat, Observable, of, Subject } from 'rxjs';
import { distinctUntilChanged, tap, switchMap, catchError, map } from 'rxjs/operators';
import { donationReportSortParam } from '../shared/enums/report.enum';
@Component({
  selector: 'app-donation-list',
  templateUrl: './donation-list.component.html',
  styleUrls: ['./donation-list.component.scss']
})
export class DonationListComponent implements OnInit {

  newDonationList = [];

  allocationMethods = [
    { label: 'All', value: 'all' },
    { label: 'Dry hub offer', value: 'DRY_HUB_OFFER' },
    { label: 'Food offer', value: 'FOOD_OFFER' },
    { label: 'Direct offer', value: 'DIRECT_OFFER' }
  ];
  foodCategories = [
    { label: 'All', value: 'all' },
    { label: 'Pantry', value: 'Pantry' },
    { label: 'Fruits and vegetables', value: 'Fruits-and-Vegetables' },
    { label: 'Non food', value: 'Non-Food' },
    { label: 'Dairy', value: 'Dairy' },
    { label: 'Protein', value: 'Protein' },
    { label: 'Prepared', value: 'Prepared' }
  ]
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  currentUser: any;
  currentPage = 1;
  pageSize = 15;
  total = 0;
  delta = 2;
  totalPages: number;
  toolTipContent = '';
  foodTemperature: any;
  foodCategory = 'all';
  allocationMethod = 'all';
  foodBank: any;
  selectedDateRange: any=[];
  selectedStartDate: any;
  selectedEndDate: any;
  downloadSpreadSheet = false;
  foodBanks$: Observable<any[]>;
  foodBankLoading = false;
  foodBankInput$ = new Subject<string>();
  selectedFoodBankIds = [];
  showSource = false;
  sortParam: any;
  order = 'ASC';
  public get donationReportSortParam(): typeof donationReportSortParam {
    return donationReportSortParam;
  }
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private authService: AuthService,
    private generalService: GeneralService,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {

    if (this.router.url.includes('donations')) {
      this.showSource = true;
      let currentDate = new Date()
    var endDate = new Date(); 
    console.log(endDate.toLocaleDateString()); 
    endDate.setMonth(endDate.getMonth() - 6); 
    console.log(endDate.toLocaleDateString());
    this.selectedDateRange[0]=  endDate.toLocaleDateString(); 
    this.selectedDateRange[1]=  currentDate; 
      
    } else {
      this.showSource = false;
    }
    this.loadUser();
    this.getDonations();
    this.loadFoodBanks();

    let currentDate = new Date()
    var endDate = new Date(); 
    console.log(endDate.toLocaleDateString()); 
    endDate.setMonth(endDate.getMonth() - 6); 
    console.log(endDate.toLocaleDateString());
    this.selectedDateRange[0]=  endDate.toLocaleDateString(); 
    this.selectedDateRange[1]=  currentDate; 
  
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }
  getDonations() {
    const queries: any = {
      pageNo: this.currentPage - 1,
      pageSize: this.pageSize,
      allocationMethod: this.allocationMethod || '',
      foodCategory: this.foodCategory || '',
      download: this.downloadSpreadSheet,
      startDate: this.selectedDateRange,
      endDate: this.selectedDateRange,
    };

    if (this.sortParam && this.order) {
      queries.sort = this.sortParam;
      queries.order = this.order;
    }

    if (this.selectedFoodBankIds && this.selectedFoodBankIds.length) {
      queries.source = this.selectedFoodBankIds.join(',');
    }
    if (this.selectedDateRange && this.selectedDateRange.length) {
      
      queries.startDate = moment(
        this.utilityService.convertToUtc(new Date(this.selectedDateRange[0]).setHours(0, 0, 0))).format('YYYY-MM-DD HH:mm:ss');
      queries.endDate = moment(
        this.utilityService.convertToUtc(new Date(this.selectedDateRange[1]).setHours(23, 59, 59))).format('YYYY-MM-DD HH:mm:ss');

    } else {
      delete queries.startDate; delete queries.endDate;
    }
    
    
    
    
    this.generalService.getDonationList(queries).subscribe(response => {
      const res = response.payload;
      if (!queries.download) {
        this.total = parseInt(res.count || 0, 10);
        this.newDonationList = res.donationList;
        
      } else if (queries.download) {
        this.downloadSpreadSheet = false;
        window.open(res, '_blank');
      }
    });
  }

  foodCategoryChanged(event) {
    
  }

  allocationMethodChanged(event) {
    
  }

  fiscalYearChanged(event) {
    
  }

  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {
    // 
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getDonations();
  }
  completeDonation(id) {
    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: `Are you sure that you want perform this action?`,
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {

          this.generalService.completeDonation(id).subscribe(res => {
            this.notificationService.showSuccess('Donation marked completed.');
            this.getDonations();
          });
        }
      },
    });

  }

  submitFilter() {

    if (this.checkValidity()) {
      this.currentPage = 1;
      this.getDonations();
    }
  }

  checkValidity() {
    if (!this.allocationMethod && !this.foodCategory) {
      this.notificationService.showError('Please at least one option before applying filter.');
      return false;
    }
    return true;
  }


  trackByFn(item: any) {
    return item.id;
  }


  foodBankSelected(event) {
    
    
    this.foodBanks$ = new Observable<any[]>();
    this.loadFoodBanks();
  }

  private loadFoodBanks() {
    this.foodBanks$ = concat(
      of([]), // default items
      this.foodBankInput$.pipe(
        distinctUntilChanged(),
        tap(() => this.foodBankLoading = true),
        switchMap(term => {
          
          if (!term) {
            this.foodBankLoading = false;
            return of([]);
          } else {
            return this.generalService.getFoodBanksByName({ name: term }).pipe(
              catchError(() => of([])), // empty list on error
              map((data: any) => data && data.payload || []),
              tap((res) => this.foodBankLoading = false)
            );
          }
        })
      )
    );
  }


  sortList(sortParam) {
    this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
    this.sortParam = sortParam;
    this.getDonations();
  }

}

