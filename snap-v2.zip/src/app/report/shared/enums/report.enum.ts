// user report tab sorting params
export enum userReportSortParam {
  NAME = 'profile_name',
  EMAIL = 'profile_email',
  ROLE = 'role',
  STATUS = 'active',
}


// food bank report tab sorting params

export enum foodBankReportSortParam {
  FEED_ONTARIO_ID = 'donation_feedOntarioId',
  OFFER_DATE = 'donation_offerDate',
  PRODUCT_DESC = 'donation_productDescription',
  FOOD_CATEGORY = 'donation_foodCategory',
  ALLOCATION_METHOD = 'donation_allocationMethod',
  WEIGHT_PER_PALLET_OR_BOX = 'donation_weightPerPalletOrBox',
  ORG_NAME = 'organization_name',
  ALLOCATION_QUANTITY = 'allocatedQuantity'
}



// capacity report tab sorting params

export enum capacityReportSortParam {
  NAME = 'name',
  DRY_CAPACITY = 'orgProfile_dryStorageCapacity',
  CHILLED_CAPACITY = 'orgProfile_chilledStorageCapacity',
  FROZEN_CAPACITY = 'orgProfile_frozenStorageCapacity'
}



// shipment report tab sorting params

export enum shipmentReportSortParam {
  FEED_ONTARIO_ID = 'donation_feedOntarioId',
  LAST_ALLOCATED_ON = 'lastAllocatedOn',
  FOOD_CATEGORY = 'donation_foodCategory',
  ORG_NAME = 'organization_name',
  PRODUCT_DESC = 'donation_productDescription',
  QUALITY = 'quality',
  ALLOCATION_QUANTITY = 'allocatedQuantity'
}



// donation report tab sorting params

export enum donationReportSortParam {
  FEED_ONTARIO_ID = 'feedOntarioId',
  OFFER_DATE = 'offerDate',
  FOOD_TEMP = 'foodTemperature',
  FOOD_CATEGORY = 'foodCategory',
  PRODUCT_DESC = 'productDescription',
  ALLOCATION_METHOD = 'allocationMethod',
  WEIGHT_PER_PALLET_OR_BOX = 'weightPerPalletOrBox',
  QUANTITY_PALLETS = 'quantityPallets',
}



// food bank equity report tab sorting params

export enum foodBankEquityReportSortParam {
  ZONE = 'zone',
  CITY = 'city',
  NAME = 'name',
  HC_TOTAL = 'hcTotal',
  HC_PERCENT = 'hcPercent',
  FOOD_OFFER_TOTAL = 'foodOfferTotal',
  FOOD_OFFER_LBS = 'foodOfferLbs',
  FOOD_OFFER_PERCENT = 'foodOfferPercent',
  DIRECT_OFFER_TOTAL = 'directOfferTotal',
  DIRECT_OFFER_LBS = 'directOfferLbs',
  DIRECT_OFFER_PERCENT = 'directOfferPercent',
  DRY_HUB_OFFER_TOTAL = 'dryHubOfferTotal',
  DRY_HUB_OFFER_LBS = 'dryHubOfferLbs',
  DRY_HUB_OFFER_PERCENT = 'dryHubOfferPercent',
  TOTAL = 'total',
  TOTAL_LBS = 'totalLbs',
  OVER_ALL_PERCENT = 'overallPercent'
}




// zone equity report tab sorting params

export enum zoneEquityReportSortParam {
  ZONE_NAME = 'zone_name',
  HUNGER_COUNT_TOTAL = 'hc_total',
  HUNGER_COUNT_PERCENT = 'hc_percent',
  FOOD_OFFER_TOTAL = 'foodOffer_total',
  FOOD_OFFER_LBS = 'foodOffer_lbs',
  FOOD_OFFER_PERCENT = 'foodOffer_percent',
  DIRECT_OFFER_TOTAL = 'directOffer_total',
  DIRECT_OFFER_LBS = 'directOffer_lbs',
  DIRECT_OFFER_PERCENT = 'directOffer_percent',
  DRY_HUB_OFFER_TOTAL = 'dryHubOffer_total',
  DRY_HUB_OFFER_LBS = 'dryHubOffer_lbs',
  DRY_HUB_OFFER_PERCENT = 'dryHubOffer_percent',
  TOTAL = 'total',
  TOTAL_LBS = 'total_lbs',
  OVERALL_PERCENT = 'overall_percent'
}


// By donor report tab sorting params

export enum donorDonationsReportSortParam {

  SOURCE_NAME = 'source_name',
  FOOD_OFFER_QUANTITY = 'foodOffer_quantity',
  FOOD_OFFER_LBS = 'foodOffer_lbs',
  DIRECT_OFFER_QUANTITY = 'directOffer_quantity',
  DIRECT_OFFER_LBS = 'directOffer_lbs',
  DRY_HUB_OFFER_QUANTITY = 'dryHubOffer_quantity',
  DRY_HUB_OFFER_LBS = 'dryHubOffer_lbs',
  TOTAL_QUANTITY = 'total_quantity',
  TOTAL_LBS = 'total_lbs',

}



// By source report tab sorting params

export enum sourceDonationsReportSortParam {
  DONOR_NAME = 'donor_name',
  AVERAGE_QUALITY = 'average_quality',
  FOOD_OFFER_QUANTITY = 'foodOffer_quantity',
  FOOD_OFFER_LBS = 'foodOffer_lbs',
  DIRECT_OFFER_QUANTITY = 'directOffer_quantity',
  DIRECT_OFFER_LBS = 'directOffer_lbs',
  DRY_HUB_OFFER_QUANTITY = 'dryHubOffer_quantity',
  DRY_HUB_OFFER_LBS = 'dryHubOffer_lbs',
  TOTAL_QUANTITY = 'total_quantity',
  TOTAL_LBS = 'total_lbs',

}