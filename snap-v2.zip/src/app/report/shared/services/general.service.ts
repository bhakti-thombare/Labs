import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  baseUrl = environment.apiUrl;
  constructor(
    private restService: RestService
  ) { }


  getDonationList(queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/getAllDonationForReports`, queryParams, true);
  }

  getDonationListByFoodBanks(queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/report/food-bank-allocations`, queryParams, true);
  }

  getFoodBankEquity(queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/report/food-bank-equity`, queryParams, true);

  }

  getZoneEquity(queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/report/zone-equity`, queryParams, true);

  }

  completeDonation(id) {
    return this.restService.put(`${this.baseUrl}/api/v1/donor/completeDonation/${id}`, undefined, undefined, true);
  }

  getFoodBanksCapacityList(queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/report/food-bank-capacity`, queryParams, true);
  }

  downloadSpreadSheet() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/xxx/`, undefined, true);
  }

  // get all
  getFoodBanksByName(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/foodbank/profile/byName`, data, { hideLoader: true }, true);
  }

  // get all
  getDonorsByName(data) {
    return this.restService.post(`${this.baseUrl}/api/v1/donor/searchDonorByName`, data, { hideLoader: true }, true);
  }
  getUsersList(queryParams) {
    return this.restService.fetch(`${this.baseUrl}​/api/v1/report/getActiveUser`, queryParams, true);
  }

  getDonationListByShipment(queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/getShipmentReports`, queryParams, true);
  }

  getSourceWiseDonations(queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/getSourceDonationForReports`, queryParams, true);
  }

  getDonorWiseDonations(queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/donation/getDonationByDonorId`, queryParams, true);

  }

  getFoodBankDropdownOptions() {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/form-options`, undefined, true);

  }
}


