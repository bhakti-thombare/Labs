import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GeneralService } from '../shared/services/general.service';
import { userReportSortParam } from '../shared/enums/report.enum';
@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.scss']
})
export class UsersListComponent implements OnInit {

  userList = [];
  currentUser: any;
  currentPage = 1;
  pageSize = 15;
  total = 0;
  delta = 2;
  totalPages: number;
  toolTipContent = '';
  userTypes = [
    { label: 'Admin', value: 'ADMIN' },
    { label: 'Food bank', value: 'FOOD_BANK' }
  ];

  userStatuses = [
    { label: 'Active', value: true },
    { label: 'Inactive', value: false }
  ];
  userType = 'FOOD_BANK';
  userStatus = true;
  selectedDateRange: any=[];
  selectedStartDate: any;
  selectedEndDate: any;
  sortParam: any;
  order = 'ASC';
  public get userReportSortParam(): typeof userReportSortParam {
    return userReportSortParam;
  }
  downloadSpreadSheet = false;
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private authService: AuthService,
    private generalService: GeneralService,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {
    
    if(this.router.url.includes('users-list')){
      let currentDate = new Date()
    var endDate = new Date(); 
    endDate.setMonth(endDate.getMonth() - 6); 
    this.selectedDateRange[0]=  endDate.toLocaleDateString(); 
    this.selectedDateRange[1]=  currentDate; 
    } 

    this.loadUser();
    this.getUsers();

    let currentDate = new Date()
    var endDate = new Date(); 
    console.log(endDate.toLocaleDateString()); 
    endDate.setMonth(endDate.getMonth() - 6); 
    console.log(endDate.toLocaleDateString());
    this.selectedDateRange[0]=  endDate.toLocaleDateString(); 
    this.selectedDateRange[1]=  currentDate;
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }
  getUsers() {
    const queries: any = {
      pageNo: this.currentPage - 1,
      pageSize: this.pageSize,
      status: this.userStatus || '',
      userType: this.userType || '',
      download: this.downloadSpreadSheet,
      startDate: this.selectedDateRange,
      endDate: this.selectedDateRange,
    };

    if (this.sortParam && this.order) {
      queries.sort = this.sortParam;
      queries.order = this.order;
    }

    if (this.selectedDateRange && this.selectedDateRange.length) {
      
      queries.startDate = moment(
        this.utilityService.convertToUtc(new Date(this.selectedDateRange[0]).setHours(0, 0, 0))).format('YYYY-MM-DD HH:mm:ss');
      queries.endDate = moment(
        this.utilityService.convertToUtc(new Date(this.selectedDateRange[1]).setHours(23, 59, 59))).format('YYYY-MM-DD HH:mm:ss');

    } else {
      delete queries.startDate; delete queries.endDate;
    }
    this.generalService.getUsersList(queries).subscribe(response => {
      const res = response.payload;
      if (!queries.download) {
        this.total = parseInt(res.count || 0, 10);
        this.userList = res.allUsersDto;
        
      } else if (queries.download) {
        this.downloadSpreadSheet = false;
        window.open(res, '_blank');
      }
    });
  }

  statusChanged(event) {
    
  }

  userTypeChanged(event) {
    
  }



  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {
    // 
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getUsers();
  }

  submitFilter() {
    this.currentPage = 1;
    this.getUsers();
  }

  sortList(sortParam) {
    this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
    this.sortParam = sortParam;
    this.getUsers()
  }
}
