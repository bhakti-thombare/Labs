import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SourceDonationListComponent } from './source-donation-list.component';

describe('SourceDonationListComponent', () => {
  let component: SourceDonationListComponent;
  let fixture: ComponentFixture<SourceDonationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SourceDonationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SourceDonationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
