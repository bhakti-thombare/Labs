import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonationsByFoodBankListComponent } from './donations-by-food-bank-list.component';

describe('DonationsByFoodBankListComponent', () => {
  let component: DonationsByFoodBankListComponent;
  let fixture: ComponentFixture<DonationsByFoodBankListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonationsByFoodBankListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonationsByFoodBankListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
