import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { concat, Observable, of, Subject } from 'rxjs';
import { distinctUntilChanged, tap, switchMap, catchError, map } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { capacityReportSortParam } from '../shared/enums/report.enum';
import { GeneralService } from '../shared/services/general.service';
@Component({
  selector: 'app-food-bank-capacity-list',
  templateUrl: './food-bank-capacity-list.component.html',
  styleUrls: ['./food-bank-capacity-list.component.scss']
})
export class FoodBankCapacityListComponent implements OnInit {

  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  currentUser: any;
  currentPage = 1;
  selectedCapacityType = 'all';
  selectedFoodBankIds = [];
  selectedFoodBanks: any;
  selectedCapacityTypeBuffer = 'all';
  pageSize = 15;
  total = 0;
  delta = 2;
  totalPages: number;
  toolTipContent = '';
  downloadSpreadSheet = false;
  foodBanklist = [];
  storageCapacityTypes = [
    { label: 'All', value: 'all' },
    { label: 'Dry', value: 'dry' },
    { label: 'Chilled', value: 'chilled' },
    { label: 'Frozen', value: 'frozen' },
  ];
  foodBanks$: Observable<any[]>;
  foodBankLoading = false;
  foodBankInput$ = new Subject<string>();
  backupQueries: any;
  sortParam: any;
  order = 'ASC';
  public get capacityReportSortParam(): typeof capacityReportSortParam {
    return capacityReportSortParam;
  }
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private authService: AuthService,
    private generalService: GeneralService,
    private notificationService: NotificationService
  ) { }

  ngOnInit() {
    this.loadUser();
    this.getFoodBanks();
    this.loadFoodBanks();
  }

  getFoodBanks() {
    const queryParams: any = {
      pageSize: this.pageSize,
      pageNo: this.currentPage - 1,
      capacity: this.selectedCapacityTypeBuffer,
      food_bank: this.selectedFoodBankIds.join(','),
      download: this.downloadSpreadSheet
    };
    this.selectedCapacityType = this.selectedCapacityTypeBuffer;
    if (this.sortParam && this.order) {
      queryParams.sort = this.sortParam;
      queryParams.order = this.order;
    }

    return this.generalService.getFoodBanksCapacityList(queryParams).subscribe(res => {
      this.backupQueries = JSON.parse(JSON.stringify(queryParams));
      if (!queryParams.download) {
        this.total = res.payload.count;
        this.foodBanklist = res.payload.capacityOverview;
      } else if (queryParams.download) {
        window.open(res.payload, '_blank');
        this.downloadSpreadSheet = false;
      }
    });
  }



  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  storageCapacityTypeChanged(event) {
    
  }

  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {
    // 
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getFoodBanks();
  }


  submitFilter() {

    if (this.checkValidity()) {
      this.currentPage = 1;
      this.getFoodBanks();
    }
  }

  checkValidity() {
    return true;
  }

  trackByFn(item: any) {
    return item.id;
  }


  foodBankSelected(event) {
    
    
    this.foodBanks$ = new Observable<any[]>();
    this.loadFoodBanks();
  }

  private loadFoodBanks() {

    this.foodBanks$ = concat(
      of([]), // default items
      this.foodBankInput$.pipe(
        distinctUntilChanged(),
        tap(() => this.foodBankLoading = true),
        switchMap(term => {
          
          if (!term) {
            this.foodBankLoading = false;
            return of([]);
          } else {
            return this.generalService.getFoodBanksByName({ name: term }).pipe(
              catchError(() => of([])), // empty list on error
              map((data: any) => data && data.payload || []),
              tap((res) => this.foodBankLoading = false)
            );
          }
        })
      )
    );
  }

  sortList(sortParam) {
    this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
    this.sortParam = sortParam;
    this.getFoodBanks();
  }

}
