import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodBankCapacityListComponent } from './food-bank-capacity-list.component';

describe('FoodBankCapacityListComponent', () => {
  let component: FoodBankCapacityListComponent;
  let fixture: ComponentFixture<FoodBankCapacityListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoodBankCapacityListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodBankCapacityListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
