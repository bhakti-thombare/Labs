import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportRoutingModule } from './report-routing.module';
import { ReportDashboardComponent } from './report-dashboard/report-dashboard.component';
import { DonationListComponent } from './donation-list/donation-list.component';
import { SharedModule } from '../shared/shared.module';
import { FormsModule } from '@angular/forms';
import { ReportMenuComponent } from './report-menu/report-menu.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { FoodBankCapacityListComponent } from './food-bank-capacity-list/food-bank-capacity-list.component';
import { DonationsByFoodBankListComponent } from './donations-by-food-bank-list/donations-by-food-bank-list.component';
import { SourceDonationListComponent } from './source-donation-list/source-donation-list.component';
import { UsersListComponent } from './users-list/users-list.component';
import { ShipmentWiseDonationListComponent } from './shipment-wise-donation-list/shipment-wise-donation-list.component';
import { DonorDonationListComponent } from './donor-donation-list/donor-donation-list.component';
import { FoodBankEquityListComponent } from './food-bank-equity-list/food-bank-equity-list.component';
import { ZoneEquityListComponent } from './zone-equity-list/zone-equity-list.component';


@NgModule({
  declarations: [ReportDashboardComponent, DonationListComponent, ReportMenuComponent, FoodBankCapacityListComponent, DonationsByFoodBankListComponent, SourceDonationListComponent, UsersListComponent, ShipmentWiseDonationListComponent, DonorDonationListComponent, FoodBankEquityListComponent, ZoneEquityListComponent],
  imports: [
    PopoverModule.forRoot(),
    BsDatepickerModule.forRoot(),
    NgSelectModule,
    FormsModule,
    SharedModule,
    CommonModule,
    ReportRoutingModule
  ]
})
export class ReportModule { }
