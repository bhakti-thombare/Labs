import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodBankEquityListComponent } from './food-bank-equity-list.component';

describe('FoodBankEquityListComponent', () => {
  let component: FoodBankEquityListComponent;
  let fixture: ComponentFixture<FoodBankEquityListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoodBankEquityListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodBankEquityListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
