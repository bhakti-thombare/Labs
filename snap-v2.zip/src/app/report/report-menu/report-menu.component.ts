import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-report-menu',
  templateUrl: './report-menu.component.html',
  styleUrls: ['./report-menu.component.scss']
})
export class ReportMenuComponent implements OnInit {
  currentUser: any;
  reportMenus = [
    [
      { url: '/report/dashboard/donor-donations', title: 'By donor', icon: 'fa fa-user' },
      { url: '/report/dashboard/food-bank-donations', title: 'By food bank', icon: 'fa fa-user' },
      { url: '/report/dashboard/source-donations', title: 'By source', icon: 'fa fa-user' },
      { url: '/report/dashboard/food-bank-capacity', title: 'Capacity', icon: 'fa fa-user' },
      { url: '/report/dashboard/donations', title: 'Donations', icon: 'fa fa-user' }
    ],
    [
      { url: '/report/dashboard/food-bank-equity', title: 'Food bank equity', icon: 'fa fa-user' },
      { url: '/report/dashboard/shipments-donations', title: 'Shipments', icon: 'fa fa-user' },
      { url: '/report/dashboard/users-list', title: 'Users', icon: 'fa fa-user' },
      { url: '/report/dashboard/zone-equity', title: 'Zone equity', icon: 'fa fa-user' }
    ]

  ]
  constructor(
    private authService: AuthService
  ) {
    this.loadUser();
  }

  ngOnInit() {
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      
      if (this.currentUser.role !== 'ADMIN') {
        this.reportMenus = [
          [{ url: '/report/dashboard/food-bank-equity', title: 'Food bank equity', icon: 'fa fa-university' },
          { url: '/report/dashboard/zone-equity', title: 'Zone equity', icon: 'fa fa-globe' }]
        ]
      } else {
        this.reportMenus = [
          [
            { url: '/report/dashboard/donor-donations', title: 'By donor', icon: 'fa fa-user' },
            { url: '/report/dashboard/food-bank-donations', title: 'By food bank', icon: 'fa fa-archive' },
            { url: '/report/dashboard/source-donations', title: 'By source', icon: 'fa fa-sitemap' },
            { url: '/report/dashboard/food-bank-capacity', title: 'Capacity', icon: 'fa fa-building' },
            { url: '/report/dashboard/donations', title: 'Donations', icon: 'fa fa-cubes' }
          ],
          [
            { url: '/report/dashboard/food-bank-equity', title: 'Food bank equity', icon: 'fa fa-university' },
            { url: '/report/dashboard/shipments-donations', title: 'Shipments', icon: 'fa fa-truck' },
            { url: '/report/dashboard/users-list', title: 'Users', icon: 'fa fa-users' },
            { url: '/report/dashboard/zone-equity', title: 'Zone equity', icon: 'fa fa-globe' }
          ]

        ]
      }
    });

  }

}
