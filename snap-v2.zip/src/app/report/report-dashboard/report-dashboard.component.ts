import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-report-dashboard',
  templateUrl: './report-dashboard.component.html',
  styleUrls: ['./report-dashboard.component.scss']
})
export class ReportDashboardComponent implements OnInit {

  reportTabOptions = [
    { title: 'By donor', url: '/report/dashboard/donor-donations', selected: false },
    { title: 'By food bank', url: '/report/dashboard/food-bank-donations', selected: false },
    { title: 'By source', url: '/report/dashboard/source-donations', selected: false },
    { title: 'Capacity', url: '/report/dashboard/food-bank-capacity', selected: false },
    { title: 'Donations', url: '/report/dashboard/donations', selected: false },
    { title: 'Food bank equity', url: '/report/dashboard/food-bank-equity', selected: false },
    { title: 'Shipments', url: '/report/dashboard/shipments-donations', selected: false },
    { title: 'Users', url: '/report/dashboard/users-list', selected: false },
    { title: 'Zone equity', url: '/report/dashboard/zone-equity', selected: false },
  ];
  selectedTab: any;
  currentUser: any;
  currentRoute: any;
  constructor(
    private router: Router,
    private authService: AuthService
  ) {
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {

      this.currentRoute = event.url;
      this.setLowerTabOptions();
    });
  }

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      
      if (this.currentUser.role !== 'ADMIN') {
        this.reportTabOptions = [
          { title: 'Food bank equity', url: '/report/dashboard/food-bank-equity', selected: false },
          { title: 'Zone equity', url: '/report/dashboard/zone-equity', selected: false },
        ];
      }
    });
  }



  setLowerTabOptions() {

    for (const option of this.reportTabOptions) {
      if (this.currentRoute.includes(option.url) || option.url.includes(this.currentRoute)) {
        this.selectedTab = option.title;
        break;
      }
    }
  }

  getHeader(option) {
    option = option.toString().toLowerCase();
    
    switch (option) {
      case 'list':
        return 'Donations';
      case 'new':
        return 'Create new donation';
      case 'edit':
        return 'Edit donation';
      case 'view/allocate':
        return 'Donation details';
      case 'shipment confirmation':
        return 'Shipment confirmation';

    }
  }

}
