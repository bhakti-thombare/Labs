import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShipmentWiseDonationListComponent } from './shipment-wise-donation-list.component';

describe('ShipmentWiseDonationListComponent', () => {
  let component: ShipmentWiseDonationListComponent;
  let fixture: ComponentFixture<ShipmentWiseDonationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShipmentWiseDonationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShipmentWiseDonationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
