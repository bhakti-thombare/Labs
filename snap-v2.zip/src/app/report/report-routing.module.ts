import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DonationsByFoodBankListComponent } from './donations-by-food-bank-list/donations-by-food-bank-list.component';
import { DonationListComponent } from './donation-list/donation-list.component';
import { FoodBankCapacityListComponent } from './food-bank-capacity-list/food-bank-capacity-list.component';
import { ReportDashboardComponent } from './report-dashboard/report-dashboard.component';
import { ReportMenuComponent } from './report-menu/report-menu.component';
import { UsersListComponent } from './users-list/users-list.component';
import { ShipmentWiseDonationListComponent } from './shipment-wise-donation-list/shipment-wise-donation-list.component';
import { SourceDonationListComponent } from './source-donation-list/source-donation-list.component';
import { DonorDonationListComponent } from './donor-donation-list/donor-donation-list.component';
import { AdminAuthGuard } from '../core/guards/admin-auth.guard';
import { FoodBankEquityListComponent } from './food-bank-equity-list/food-bank-equity-list.component';
import { ZoneEquityListComponent } from './zone-equity-list/zone-equity-list.component';


const routes: Routes = [
  { path: '', component: ReportMenuComponent },
  {
    path: 'dashboard', component: ReportDashboardComponent, children: [
      { path: '', redirectTo: 'donations', pathMatch: 'full' },
      { path: 'donations', canActivate: [AdminAuthGuard], component: DonationListComponent },
      { path: 'food-bank-capacity', canActivate: [AdminAuthGuard], component: FoodBankCapacityListComponent },
      { path: 'food-bank-donations', canActivate: [AdminAuthGuard], component: DonationsByFoodBankListComponent },
      { path: 'source-donations', canActivate: [AdminAuthGuard], component: SourceDonationListComponent },
      { path: 'users-list', canActivate: [AdminAuthGuard], component: UsersListComponent },
      { path: 'shipments-donations', canActivate: [AdminAuthGuard], component: ShipmentWiseDonationListComponent },
      { path: 'donor-donations', canActivate: [AdminAuthGuard], component: DonorDonationListComponent },
      { path: 'food-bank-equity', component: FoodBankEquityListComponent },
      { path: 'zone-equity', component: ZoneEquityListComponent }

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportRoutingModule { }
