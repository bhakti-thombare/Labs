import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonorDonationListComponent } from './donor-donation-list.component';

describe('DonorDonationListComponent', () => {
  let component: DonorDonationListComponent;
  let fixture: ComponentFixture<DonorDonationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonorDonationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonorDonationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
