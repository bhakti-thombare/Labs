import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { Observable, Subject, concat, of } from 'rxjs';
import { distinctUntilChanged, tap, switchMap, catchError, map } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';
import { NotificationService } from 'src/app/core/services/notification.service';
import { UtilityService } from 'src/app/core/services/utility.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { donorDonationsReportSortParam } from '../shared/enums/report.enum';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-donor-donation-list',
  templateUrl: './donor-donation-list.component.html',
  styleUrls: ['./donor-donation-list.component.scss']
})
export class DonorDonationListComponent implements OnInit {


  donorDonationList = [];

  allocationMethods = [
    { label: 'All', value: 'all' },
    { label: 'Dry hub offer', value: 'DRY_HUB_OFFER' },
    { label: 'Food offer', value: 'FOOD_OFFER' },
    { label: 'Direct offer', value: 'DIRECT_OFFER' }
  ];
  foodCategories = [
    { label: 'All', value: 'all' },
    { label: 'Pantry', value: 'Pantry' },
    { label: 'Fruits and vegetables', value: 'Fruits-and-Vegetables' },
    { label: 'Non food', value: 'Non-Food' },
    { label: 'Dairy', value: 'Dairy' },
    { label: 'Protein', value: 'Protein' },
    { label: 'Prepared', value: 'Prepared' }
  ]
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  currentUser: any;
  currentPage = 1;
  pageSize = 15;
  total = 0;
  delta = 2;
  totalPages: number;
  toolTipContent = '';
  foodTemperature: any;
  foodCategory = 'all';
  allocationMethod = 'all';
  foodBank: any;
  selectedDateRange: any = [];
  selectedStartDate: any;
  selectedEndDate: any;
  downloadSpreadSheet = false;
  donors$: Observable<any[]>;
  donorLoading = false;
  donorInput$ = new Subject<string>();
  selectedDonorIds = [];
  showDonor = false; donorDonationsDetails: any;
  sortParam: any;
  order = 'ASC';
  public get donorDonationsReportSortParam(): typeof donorDonationsReportSortParam {
    return donorDonationsReportSortParam;
  }
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private authService: AuthService,
    private generalService: GeneralService,
    private notificationService: NotificationService
  ) {

  }

  ngOnInit() {

    if (this.router.url.includes('donor-donations')) {
      this.showDonor = true;

      let currentDate = new Date()
      var endDate = new Date();
      endDate.setMonth(endDate.getMonth() - 6);
      this.selectedDateRange[0] = endDate.toLocaleDateString();
      this.selectedDateRange[1] = currentDate;
    }
    else {
      this.showDonor = false;
    }
    this.loadUser();
    this.getDonorWiseDonations();
    this.loadDonors();

    let currentDate = new Date()
    var endDate = new Date();
    console.log(endDate.toLocaleDateString());
    endDate.setMonth(endDate.getMonth() - 6);
    console.log(endDate.toLocaleDateString());
    this.selectedDateRange[0] = endDate.toLocaleDateString();
    this.selectedDateRange[1] = currentDate;

  }
  addMonths(date, months) {
    date.setMonth(date.getMonth() + months);
    return date;
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }
  getDonorWiseDonations() {
    const queries: any = {
      pageNo: this.currentPage - 1,
      pageSize: this.pageSize,
      allocation_method: this.allocationMethod || '',
      food_category: this.foodCategory || '',
      download: this.downloadSpreadSheet,
      donor: 'all',
      startDate: this.selectedDateRange,
      endDate: this.selectedDateRange,
    };
    if (this.sortParam && this.order) {
      queries.sort = this.sortParam;
      queries.order = this.order;
    }

    if (this.selectedDonorIds && this.selectedDonorIds.length) {
      queries.donor = this.selectedDonorIds.join(',');
    }
    if (this.selectedDateRange && this.selectedDateRange.length) {

      queries.startDate = moment(
        this.utilityService.convertToUtc(new Date(this.selectedDateRange[0]).setHours(0, 0, 0))).format('YYYY-MM-DD HH:mm:ss');
      queries.endDate = moment(
        this.utilityService.convertToUtc(new Date(this.selectedDateRange[1]).setHours(23, 59, 59))).format('YYYY-MM-DD HH:mm:ss');
      // console.log(this.selectedDateRange.startDate)
    }

    else {
      delete queries.startDate; delete queries.endDate;
    }




    this.generalService.getDonorWiseDonations(queries).subscribe(response => {
      const res = response.payload;
      if (!queries.download) {

        this.donorDonationList = res.donorAllocationDto;
        this.donorDonationsDetails = res.totalDetails;

      } else if (queries.download) {
        this.downloadSpreadSheet = false;
        window.open(res, '_blank');
      }
    });
  }

  foodCategoryChanged(event) {

  }

  allocationMethodChanged(event) {

  }
  selectedDateMethod(event) {

  }

  fiscalYearChanged(event) {

  }

  onTotalPagesCount(totalPages: number) {
    this.totalPages = totalPages;
  }

  onPageChange(event: { page: number }) {
    // 
    // this.searchTerm = '';
    this.currentPage = event.page;
    this.getDonorWiseDonations();
  }
  completeDonation(id) {
    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: `Are you sure that you want perform this action?`,
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {

          this.generalService.completeDonation(id).subscribe(res => {
            this.notificationService.showSuccess('Donation marked completed.');
            this.getDonorWiseDonations();
          });
        }
      },
    });

  }

  submitFilter() {

    if (this.checkValidity()) {
      this.currentPage = 1;
      this.getDonorWiseDonations();
    }
  }

  checkValidity() {
    if (!this.allocationMethod && !this.foodCategory) {
      this.notificationService.showError('Please at least one option before applying filter.');
      return false;
    }
    return true;
  }


  trackByFn(item: any) {
    return item.id;
  }


  donorSelected(event) {


    this.donors$ = new Observable<any[]>();
    this.loadDonors();
  }

  private loadDonors() {
    this.donors$ = concat(
      of([]), // default items
      this.donorInput$.pipe(
        distinctUntilChanged(),
        tap(() => this.donorLoading = true),
        switchMap(term => {

          if (!term) {
            this.donorLoading = false;
            return of([]);
          } else {
            return this.generalService.getDonorsByName({ donorName: term }).pipe(
              catchError(() => of([])), // empty list on error
              map((data: any) => data || []),
              tap((res) => this.donorLoading = false)
            );
          }
        })
      )
    );
  }

  sortList(sortParam) {
    this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
    this.sortParam = sortParam;
    this.getDonorWiseDonations();
  }
}
