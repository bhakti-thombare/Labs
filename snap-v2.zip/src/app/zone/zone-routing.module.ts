import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminAuthGuard } from '../core/guards/admin-auth.guard';
import { UserAuthGuard } from '../core/guards/user-auth.guard';
import { ZonalFoodBankListComponent } from './zonal-food-bank-list/zonal-food-bank-list.component';
import { ZoneDashboardComponent } from './zone-dashboard/zone-dashboard.component';
import { ZoneFormComponent } from './zone-form/zone-form.component';
import { ZoneListComponent } from './zone-list/zone-list.component';


const routes: Routes = [
  {
    path: '', component: ZoneDashboardComponent, children: [
      { path: '', redirectTo: 'list', pathMatch: 'full' },
      { path: 'list', component: ZoneListComponent },
      { path: 'new', canActivate: [AdminAuthGuard], component: ZoneFormComponent },
      { path: 'edit/:id', canActivate: [UserAuthGuard], component: ZoneFormComponent },
      { path: 'view/:id', component: ZonalFoodBankListComponent },

    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ZoneRoutingModule { }
