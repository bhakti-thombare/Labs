import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZonalFoodBankListComponent } from './zonal-food-bank-list.component';

describe('ZonalFoodBankListComponent', () => {
  let component: ZonalFoodBankListComponent;
  let fixture: ComponentFixture<ZonalFoodBankListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZonalFoodBankListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZonalFoodBankListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
