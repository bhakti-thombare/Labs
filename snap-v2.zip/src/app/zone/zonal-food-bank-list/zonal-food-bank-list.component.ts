import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { zonalFoodBankSortParam } from '../shared/enums/zone.enum';
import { GeneralService } from '../shared/services/general.service';

@Component({
  selector: 'app-zonal-food-bank-list',
  templateUrl: './zonal-food-bank-list.component.html',
  styleUrls: ['./zonal-food-bank-list.component.scss']
})
export class ZonalFoodBankListComponent implements OnInit {
  foodBankList = [];
  selectedZone: any;
  zoneId: string;
  currentUser: any;
  zoneHungerCount: number;
  zoneHcPercent: number;
  zoneName: any;
  sortParam: any;
  order = 'ASC';

  public get zonalFoodBankSortParam(): typeof zonalFoodBankSortParam {
    return zonalFoodBankSortParam;
  }
  constructor(
    private router: Router,
    private authService: AuthService,
    private activatedRoute: ActivatedRoute,
    private generalService: GeneralService
  ) { }

  ngOnInit() {
    this.loadUser();
    this.zoneId = this.activatedRoute.snapshot.paramMap.get('id');
    this.getZonalFoodBankList();
  }


  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  getZonalFoodBankList() {
    this.generalService.getZoneById(this.zoneId).subscribe(res => {
      this.zoneName = res.payload.name;
      const queryParams: any = {
        zonename: res.payload.name,
        pageSize: 1000,
        pageNo: 0
      };

      if (this.sortParam) {
        queryParams.sort = this.sortParam;
        queryParams.order = this.order;
      }

      this.generalService.getZonalFoodBankList(queryParams).subscribe(res2 => {
        if (res2.payload) {
          this.foodBankList = res2.payload.foodbank;
          this.roundOffFloatValues(this.foodBankList);
          this.zoneHungerCount = res2.payload.hungerCount;
          this.zoneHcPercent = res2.payload.pcOfTotalllHungerCount;
        } else {
          this.foodBankList = [];
        }
      });
    });
  }

  createZonalFoodBank() {
    localStorage.setItem('zone', this.zoneName);
    this.router.navigateByUrl('/user/food-bank/new');
  }

  sortList(sortParam) {
    if (sortParam) {
      this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
      this.sortParam = sortParam;
      this.getZonalFoodBankList();
    }
  }
  roundOffFloatValues(list) {
    for (const item of list) {
      item.overallPC = item.overallPC && parseFloat(item.overallPC).toFixed(2) || 0;
      item.hungerCountPC = item.hungerCountPC && parseFloat(item.hungerCountPC).toFixed(2) || 0;
    }
  }
}
