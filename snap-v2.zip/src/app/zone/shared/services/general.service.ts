import { Injectable } from '@angular/core';
import { RestService } from 'src/app/core/services/rest.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  constructor(
    private restService: RestService
  ) { }

  baseUrl = environment.apiUrl;

  getZoneList(queryParams?) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/zone/getallzone`, queryParams, true);
  }

  getZoneById(id) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/zone/${id}`, undefined, true);
  }

  createZone(data) {

    return this.restService.post(`${this.baseUrl}/api/v1/zone/create-zone`, data, undefined, true);
  }

  updateZone(data, id) {
    return this.restService.put(`${this.baseUrl}/api/v1/zone/update-zone/${id}`, data, undefined, true);
  }

  deleteZone(id) {
    return this.restService.delete(`${this.baseUrl}/api/v1/zone/${id}`, undefined, undefined, true);
  }

  getZonalFoodBankList(queryParams) {
    return this.restService.fetch(`${this.baseUrl}/api/v1/foodbank/hungercount`, queryParams, true);
  }
}
