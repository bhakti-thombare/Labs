export enum zonesSortParam {
  NAME = 'name',
  ABBREVIATION = 'abbreviation',
  HC_PERCENT = 'hc_percent',
  OVERALL_PERCENT = 'overall_percent'
}

export enum zonalFoodBankSortParam {
  NAME = 'name',
  CITY = 'city',
  HUNGER_COUNT = 'hunger_count',
  HUNGER_COUNT_PERCENT = 'hc_percent',
  OVERALL_PERCENT = 'overall_percent'
}