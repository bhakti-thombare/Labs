import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/core/services/notification.service';
import { GeneralService } from '../shared/services/general.service';
import { UtilityService } from 'src/app/core/services/utility.service';
@Component({
  selector: 'app-zone-form',
  templateUrl: './zone-form.component.html',
  styleUrls: ['./zone-form.component.scss']
})
export class ZoneFormComponent implements OnInit {
  public lettersOnlyCustomPatterns = {'S': { pattern: new RegExp('\[a-zA-Z \]')}};
  
  zoneForm: FormGroup;
  zoneId: any;
  zoneDetails: any;
  @Output() zoneUpdated: EventEmitter<any> = new EventEmitter<any>();
  constructor(
    private notificationService: NotificationService,
    private generalService: GeneralService,
    private utilityService: UtilityService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.buildZoneForm();
    this.zoneId = this.activatedRoute.snapshot.paramMap.get('id');
    if (this.zoneId) {
      this.getZoneDetails();
    }
  }

  buildZoneForm() {
    this.zoneForm = this.formBuilder.group({
      name: ['', Validators.required],
      abbreviation: ['', Validators.required],
      deleted: [false]
    });
  }

  getZoneDetails() {
    this.generalService.getZoneById(this.zoneId).subscribe(res => {
      this.zoneDetails = res.payload;
      this.patchZoneDetails();
    });
  }

  patchZoneDetails() {
    this.zoneForm.patchValue({
      name: this.zoneDetails.name,
      abbreviation: this.zoneDetails.abbreviation,
      deleted: this.zoneDetails.deleted
    });
  }

  submit() {
    if (this.checkValidity()) {
      const data = this.zoneForm.value;
      if (!this.zoneId) {
        this.generalService.createZone(data).subscribe(res => {
          this.zoneUpdated.emit(true);
          this.notificationService.showSuccess('Zone created successfully.');
          // this.router.navigateByUrl('/zone/list');
          this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
            this.router.navigate(['/zone/list']));
        });
      } else {
        this.generalService.updateZone(data, this.zoneId).subscribe(res => {
          this.notificationService.showSuccess('Zone updated successfully.');
          this.zoneUpdated.emit(true);
          // this.router.navigateByUrl('/zone/list');
          this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
            this.router.navigate(['/zone/list']));
        });
      }
    } else {
      this.notificationService.showError('Please fill mandatory fields.');
    }

  }

  checkValidity() {
    return this.zoneForm.valid;
  }

  lettersOnly(event, field, limit) {
    if (this.zoneForm.get(field).value.length >= limit) {
      // debugger;
      this.notificationService.showError('Only ' + limit + ' characters allowed.');
    }
    // return this.utilityService.lettersOnly(event);
    if(this.utilityService.lettersOnly(event)){
      return true;
    }
    else{
      this.notificationService.showError('Only letters are allowed.');
      return false;
    }
  }


}
