import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { AuthService } from 'src/app/core/services/auth.service';
import { ZoneEquityTableComponent } from 'src/app/shared/components/zone-equity-table/zone-equity-table.component';
import { ZoneFormComponent } from '../zone-form/zone-form.component';
import { ZoneListComponent } from '../zone-list/zone-list.component';
@Component({
  selector: 'app-zone-dashboard',
  templateUrl: './zone-dashboard.component.html',
  styleUrls: ['./zone-dashboard.component.scss']
})
export class ZoneDashboardComponent implements OnInit, OnDestroy {
  currentUser: any;
  zoneId: any;
  subscription: Subscription;
  selectedTab = 'Zones';
  zoneTabOptions = [
    { title: 'List', url: '/zone/list', selected: true },
    { title: 'New', url: '/zone/new', selected: false }
  ];
  currentRoute: any;

  @ViewChild(ZoneFormComponent, { static: true }) zoneFormComponent: ZoneFormComponent;

  @ViewChild(ZoneListComponent, { static: true }) zoneListComponent: ZoneListComponent;

  @ViewChild(ZoneEquityTableComponent, { static: true }) zoneEquityTableComponent: ZoneEquityTableComponent;


  constructor(
    private router: Router,
    private authService: AuthService,
    private activatedRoute: ActivatedRoute,
  ) {

    this.subscription = router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.currentRoute = event.url;
      this.modifyUserTabs();
    });
  }

  ngOnInit() {
    this.zoneId = this.activatedRoute.snapshot.paramMap.get('id') || this.activatedRoute.firstChild.snapshot.paramMap.get('id');
    this.loadUser();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      this.modifyUserTabs();
      // if (this.currentUser.role !== 'ADMIN') {

      //   if (!this.zoneId || this.zoneId === null) {
      //     this.zoneTabOptions = [
      //       { title: 'List', url: '/zone/list', selected: false }
      //     ];
      //   } else {
      //     this.zoneTabOptions = [
      //       { title: 'List', url: '/zone/list', selected: false },
      //       { title: 'View', url: '/zone/view/' + this.zoneId, selected: false }
      //     ];
      //   }
      // }
    });
  }

  modifyUserTabs() {

    const zoneId = this.activatedRoute.snapshot.paramMap.get('id') || this.activatedRoute.firstChild.snapshot.paramMap.get('id');
    if (this.currentUser) {

      if (this.currentUser.role === 'ADMIN') {
        if (!zoneId || zoneId === null) {
          this.zoneTabOptions = [
            { title: 'List', url: '/zone/list', selected: false },
            { title: 'New', url: '/zone/new', selected: false }
          ];
        } else {
          this.zoneTabOptions = [
            { title: 'List', url: '/zone/list', selected: false },
            { title: 'New', url: '/zone/new', selected: false },
            { title: 'Edit', url: '/zone/edit/' + zoneId, selected: false },
            { title: 'View', url: '/zone/view/' + zoneId, selected: false }
          ];
        }
      }

      if (this.currentUser.role !== 'ADMIN') {

        if (!zoneId || zoneId === null) {
          this.zoneTabOptions = [
            { title: 'List', url: '/zone/list', selected: false }
          ];
        } else {
          this.zoneTabOptions = [
            { title: 'List', url: '/zone/list', selected: false },
            { title: 'View', url: '/zone/view/' + zoneId, selected: false }
          ];
        }
      }

      for (const option of this.zoneTabOptions) {
        if (this.currentRoute.includes(option.url) || option.url.includes(this.currentRoute)) {
          this.selectedTab = this.getHeader(option.title);
        }
      }
    }
  }

  tabSelected(url) {
    for (const option of this.zoneTabOptions) {
      if (url.includes(option.url) || option.url.includes(url)) {
        this.selectedTab = this.getHeader(option.title);
        option.selected = true;
        this.router.navigateByUrl(url);
      } else {
        option.selected = false;
      }
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getHeader(option) {
    option = option.toString().toLowerCase();
    switch (option) {
      case 'list':
        return 'Zones';
      case 'new':
        return 'Create zone';
      case 'edit':
        return 'Edit Zone';
      case 'view':
        return 'View';
    }
  }
  onActivate(event) {
    console.log('event', event)
    console.log('this.zoneFormComponent', this.zoneFormComponent)
    console.log('this.zoneListComponent', this.zoneListComponent)
    console.log('this.zoneEquityTableComponent', this.zoneEquityTableComponent)
    if (event.updateZoneTable) {
      event.zoneUpdated.subscribe(event => {
        console.log(event, 'blah');
        this.zoneEquityTableComponent.ngOnInit();
      })
      console.log('this.zoneFormComponent', this.zoneFormComponent)
      this.zoneEquityTableComponent.ngOnInit();

    }

  }
}
