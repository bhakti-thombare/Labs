import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ZoneRoutingModule } from './zone-routing.module';
import { ZoneListComponent } from './zone-list/zone-list.component';
import { ZoneFormComponent } from './zone-form/zone-form.component';
import { ZonalFoodBankListComponent } from './zonal-food-bank-list/zonal-food-bank-list.component';
import { ZoneDashboardComponent } from './zone-dashboard/zone-dashboard.component';
import { SharedModule } from '../shared/shared.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { NgxMaskModule, IConfig } from "ngx-mask";

export const options: Partial<IConfig> | (() => Partial<IConfig>) = null;

@NgModule({
  declarations: [ZoneListComponent, ZoneFormComponent, ZonalFoodBankListComponent, ZoneDashboardComponent],
  imports: [
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    CommonModule,
    ZoneRoutingModule,
    NgxMaskModule.forRoot()
  ]
})
export class ZoneModule { }
