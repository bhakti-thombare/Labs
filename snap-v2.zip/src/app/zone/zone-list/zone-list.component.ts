import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { GeneralService } from '../shared/services/general.service';
import { GenericConfirmComponent } from 'src/app/shared/components/generic-confirm/generic-confirm.component';
import { NotificationService } from 'src/app/core/services/notification.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { zonesSortParam } from '../shared/enums/zone.enum';

@Component({
  selector: 'app-zone-list',
  templateUrl: './zone-list.component.html',
  styleUrls: ['./zone-list.component.scss']
})
export class ZoneListComponent implements OnInit {
  zoneList = [];
  @ViewChild('genericConfirm', { static: true }) genericConfirm: GenericConfirmComponent;
  currentUser: any;
  updateZoneTable = true;
  sortParam: any;
  order = 'ASC';
  @Output('activate') zoneUpdated: EventEmitter<any> = new EventEmitter<any>();

  public get zonesSortParam(): typeof zonesSortParam {
    return zonesSortParam;
  }

  constructor(
    private authService: AuthService,
    private notificationService: NotificationService,
    private generalService: GeneralService,
  ) { }

  ngOnInit() {
    this.loadUser();
    this.getZones();
  }

  loadUser() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  getZones() {
    const queryParams: any = {};
    if (this.sortParam) {
      queryParams.sort = this.sortParam;
      queryParams.order = this.order;
    }
    this.generalService.getZoneList(queryParams).subscribe(res => {
      this.zoneList = res.payload;
    });
  }
  deleteZone(zone) {

    this.genericConfirm.show({
      headlineText: 'Confirmation',
      notConfirmText: 'No',
      confirmText: 'Yes',
      text: 'Are you sure that you want to perform this action?',
      callback: (result) => {
        // Actual logic to perform a confirmation
        // api call to delete
        if (result) {
          this.generalService.deleteZone(zone.id).subscribe(res => {
            this.notificationService.showSuccess('User deleted successfully.');
            this.zoneUpdated.emit(true)
            this.getZones();
          });
        }
      },
    });
  }

  sortList(sortParam) {
    if (sortParam) {
      this.order = this.sortParam === sortParam ? (this.order === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
      this.sortParam = sortParam;
      this.getZones();
    }
  }
}
