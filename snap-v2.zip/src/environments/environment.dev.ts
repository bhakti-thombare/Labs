export const environment = {
    production: false,
    baseUrl: '',
    env: 'dev',
    apiUrl: 'http://feed-ontario-dev-alb-805247678.us-east-1.elb.amazonaws.com'
    // apiUrl: 'https://d351q52nf2zebv.cloudfront.net'
    // apiUrl: 'https://localhost:3000'
    // apiUrl: 'http://34.201.35.33:8080'
};
