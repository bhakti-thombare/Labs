export const environment = {
    production: false,
    baseUrl: '',
    env: 'qa',
    // apiUrl: 'https://feed-ontgario-qa-alb-2072069085.us-east-1.elb.amazonaws.com'
    apiUrl: 'https://snap.feedontario.ca'
};
